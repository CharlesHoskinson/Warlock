require('./binary.js')();
