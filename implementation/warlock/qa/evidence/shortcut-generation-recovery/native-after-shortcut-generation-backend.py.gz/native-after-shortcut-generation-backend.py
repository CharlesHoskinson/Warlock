import sys,json,threading,time
from pathlib import Path
sys.path.insert(0,'/home/hoskinson/omarchy-windows-parity/implementation/warlock/adapter')
import daemon
original=daemon.send
arm=Path('/home/hoskinson/window-integration-qa/warlock-window-feedback-1791640416873494252/shortcut-hold.arm');held=Path('/home/hoskinson/window-integration-qa/warlock-window-feedback-1791640416873494252/shortcut-hold.json');release=Path('/home/hoskinson/window-integration-qa/warlock-window-feedback-1791640416873494252/shortcut-hold.release');delivered=Path('/home/hoskinson/window-integration-qa/warlock-window-feedback-1791640416873494252/shortcut-hold.delivered')
lock=threading.Lock();stopped=threading.Event()
def send(frame):
 with lock:
  if frame.get('kind')=='shell-shortcuts' and arm.exists() and int(frame['serial'])>int(arm.read_text()):
   if not held.exists():held.write_text(json.dumps(frame))
   return
  original(frame)
def dispatch():
 while not stopped.wait(.01):
  if release.exists():
   with lock:
    frame=json.loads(held.read_text());original(frame);arm.unlink();release.unlink();delivered.write_text(json.dumps(frame))
   return
daemon.send=send
thread=threading.Thread(target=dispatch,daemon=True);thread.start()
try:result=daemon.run()
finally:stopped.set();thread.join(1)
raise SystemExit(result)
