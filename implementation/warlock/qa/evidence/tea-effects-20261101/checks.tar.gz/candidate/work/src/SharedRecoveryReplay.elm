port module SharedRecoveryReplay exposing (main)

import Desktop
import Effects
import Menu
import MenuBridge
import Provider
import UInt64
import TaskbarShell
import Json.Decode as D
import Json.Encode as E
import OutputController as Outputs
import Platform
import Shell
import SurfaceController as Controller

port incoming : (D.Value -> msg) -> Sub msg
port outgoing : E.Value -> Cmd msg

type Msg = Run D.Value

main : Program () () Msg
main = Platform.worker {init=\_ -> ((),Cmd.none),subscriptions=\_ -> incoming Run,update=\(Run raw) _ ->
    let events=D.decodeValue (D.list D.value) raw |> Result.withDefault []
        (_,rows)=List.foldl apply (Outputs.initial,[]) events
    in ((),outgoing (E.list identity (List.reverse rows)))}

apply : D.Value -> (Outputs.Model,List E.Value) -> (Outputs.Model,List E.Value)
apply raw (model,rows) =
    let value name=D.decodeValue (D.field name D.value) raw |> Result.withDefault E.null
        event=case D.decodeValue (D.field "kind" D.string) raw |> Result.withDefault "" of
            "geometry-attach" -> Just (Outputs.Interaction (Desktop.Window (TaskbarShell.Native Shell.GeometryAttach)))
            "topology" -> Just (Outputs.Topology (value "frame"))
            "native" -> Just (Outputs.Interaction (Desktop.Incoming (value "frame")))
            "action" -> Just (Outputs.Renderer (value "frame"))
            "dismiss" -> Just (Outputs.Dismiss (value "frame"))
            "reflow" -> Just (Outputs.Reflow (value "frame"))
            _ -> Nothing
        (next,effects)=event |> Maybe.map (\message -> Outputs.update message model) |> Maybe.withDefault (model,[])
        requests=List.filterMap (\effect -> case effect of
            Controller.DesktopEffect (Desktop.Send wire) -> Just wire
            Controller.DesktopEffect (Desktop.WindowEffect (Shell.Send wire)) -> Just wire
            Controller.DesktopEffect (Desktop.WindowEffect Shell.RestartBackend) -> Just (E.object [("protocolVersion",E.int 3),("kind",E.string "host-reconnect")])
            Controller.DesktopEffect (Desktop.WindowEffect (Shell.ArmPrepared _)) -> Nothing
            _ -> Nothing) effects
        focus=List.filterMap (\effect -> case effect of
            Controller.DesktopEffect (Desktop.Focus target) -> Just (E.string target)
            _ -> Nothing) effects
        windows = (Controller.desktop (Outputs.controller next)).windows
        unresolved = E.list (\t -> E.object [("effectProtocol",E.int t.effectProtocol),("intent",Effects.encodeIntent t.intent),("status",E.string (Effects.statusName t.status))]) windows.shell.effects.unresolved
        prepared = MenuBridge.preparedSnapshot windows.menus
        scopeValue ownerScope = E.object [("outputId",E.string (UInt64.string ownerScope.outputId)),("providerId",E.string (UInt64.string ownerScope.providerId))]
        row=E.object [("preparedToken",prepared |> Maybe.map (.token >> UInt64.string >> E.string) |> Maybe.withDefault E.null),("ownerScope",(Controller.desktop (Outputs.controller next)).ownerScope |> Maybe.map scopeValue |> Maybe.withDefault E.null),("ownerExhausted",E.bool (Controller.desktop (Outputs.controller next)).ownerExhausted),("shell",Shell.encode windows.shell),("unresolved",unresolved),("frame",Controller.frame (Outputs.controller next)),("projection",Outputs.frame next),("requests",E.list identity requests),("focus",E.list identity focus),("effects",E.int (List.length effects))]
    in (next,row::rows)
