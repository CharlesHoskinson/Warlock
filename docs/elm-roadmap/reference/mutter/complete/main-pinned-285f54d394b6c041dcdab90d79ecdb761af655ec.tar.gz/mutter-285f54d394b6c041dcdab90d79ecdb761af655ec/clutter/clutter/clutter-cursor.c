/*
 * Copyright 2013 Red Hat, Inc.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Giovanni Campagna <gcampagn@redhat.com>
 */

#include "config.h"

#include "clutter-color-state.h"
#include "clutter-cursor-private.h"
#include "clutter-enum-types.h"

#include "cogl/cogl.h"

enum
{
  PROP_0,
  PROP_COLOR_STATE,
  PROP_CURSOR_TYPE,
  N_PROPS
};

static GParamSpec *obj_props[N_PROPS] = { 0, };

enum
{
  IMAGE_CHANGED,
  N_SIGNALS,
};

static guint signals[N_SIGNALS] = { 0, };

typedef struct _ClutterCursorPrivate
{
  GObject parent;

  float scale;
  MtkMonitorTransform transform;
  gboolean has_viewport_src_rect;
  graphene_rect_t viewport_src_rect;
  gboolean has_viewport_dst_size;
  int viewport_dst_width;
  int viewport_dst_height;
  ClutterCursorType cursor_type;

  ClutterColorState *color_state;
} ClutterCursorPrivate;

G_DEFINE_ABSTRACT_TYPE_WITH_PRIVATE (ClutterCursor,
                                     clutter_cursor,
                                     G_TYPE_OBJECT)

gboolean
clutter_cursor_is_animated (ClutterCursor *cursor)
{
  ClutterCursorClass *klass = CLUTTER_CURSOR_GET_CLASS (cursor);

  if (klass->is_animated)
    return klass->is_animated (cursor);
  else
    return FALSE;
}

void
clutter_cursor_tick_frame (ClutterCursor *cursor)
{
  return CLUTTER_CURSOR_GET_CLASS (cursor)->tick_frame (cursor);
}

unsigned int
clutter_cursor_get_current_frame_time (ClutterCursor *cursor)
{
  return CLUTTER_CURSOR_GET_CLASS (cursor)->get_current_frame_time (cursor);
}

void
clutter_cursor_set_scale (ClutterCursor *cursor,
                                  float          scale)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (G_APPROX_VALUE (priv->scale, scale, FLT_EPSILON))
    return;

  priv->scale = scale;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_set_transform (ClutterCursor       *cursor,
                                      MtkMonitorTransform  transform)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (priv->transform == transform)
    return;

  priv->transform = transform;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_set_viewport_src_rect (ClutterCursor         *cursor,
                                      const graphene_rect_t *src_rect)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (priv->has_viewport_src_rect &&
      G_APPROX_VALUE (priv->viewport_src_rect.origin.x,
                      src_rect->origin.x, FLT_EPSILON) &&
      G_APPROX_VALUE (priv->viewport_src_rect.origin.y,
                      src_rect->origin.y, FLT_EPSILON) &&
      G_APPROX_VALUE (priv->viewport_src_rect.size.width,
                      src_rect->size.width, FLT_EPSILON) &&
      G_APPROX_VALUE (priv->viewport_src_rect.size.height,
                      src_rect->size.height, FLT_EPSILON))
    return;

  priv->has_viewport_src_rect = TRUE;
  priv->viewport_src_rect = *src_rect;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_reset_viewport_src_rect (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (!priv->has_viewport_src_rect)
    return;

  priv->has_viewport_src_rect = FALSE;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_set_viewport_dst_size (ClutterCursor *cursor,
                                      int            dst_width,
                                      int            dst_height)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (priv->has_viewport_dst_size &&
      priv->viewport_dst_width == dst_width &&
      priv->viewport_dst_height == dst_height)
    return;

  priv->has_viewport_dst_size = TRUE;
  priv->viewport_dst_width = dst_width;
  priv->viewport_dst_height = dst_height;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_reset_viewport_dst_size (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (!priv->has_viewport_dst_size)
    return;

  priv->has_viewport_dst_size = FALSE;
  clutter_cursor_invalidate (cursor);
}

void
clutter_cursor_get_geometry (ClutterCursor *cursor,
                             int           *width,
                             int           *height,
                             int           *hot_x,
                             int           *hot_y)
{
  CLUTTER_CURSOR_GET_CLASS (cursor)->get_geometry (cursor,
                                                   width, height,
                                                   hot_x, hot_y);
}

uint8_t *
clutter_cursor_get_data (ClutterCursor *cursor,
                         int           *out_stride)
{
  if (!CLUTTER_CURSOR_GET_CLASS (cursor)->get_data)
    return NULL;

  return CLUTTER_CURSOR_GET_CLASS (cursor)->get_data (cursor, out_stride);
}

CoglTexture *
clutter_cursor_get_texture (ClutterCursor *cursor)
{
  return CLUTTER_CURSOR_GET_CLASS (cursor)->get_texture (cursor);
}

float
clutter_cursor_get_scale (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  return priv->scale;
}

MtkMonitorTransform
clutter_cursor_get_transform (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  return priv->transform;
}

const graphene_rect_t *
clutter_cursor_get_viewport_src_rect (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (!priv->has_viewport_src_rect)
    return NULL;

  return &priv->viewport_src_rect;
}

gboolean
clutter_cursor_get_viewport_dst_size (ClutterCursor *cursor,
                                      int           *dst_width,
                                      int           *dst_height)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  if (!priv->has_viewport_dst_size)
    return FALSE;

  *dst_width = priv->viewport_dst_width;
  *dst_height = priv->viewport_dst_height;
  return TRUE;
}

void
clutter_cursor_prepare_at (ClutterCursor   *cursor,
                           float            best_scale,
                           float            x,
                           float            y)
{
  ClutterCursorClass *cursor_class = CLUTTER_CURSOR_GET_CLASS (cursor);

  if (cursor_class->prepare_at)
    cursor_class->prepare_at (cursor, best_scale, x, y);
}

void
clutter_cursor_invalidate (ClutterCursor *cursor)
{
  ClutterCursorClass *cursor_class = CLUTTER_CURSOR_GET_CLASS (cursor);

  if (cursor_class->invalidate)
    cursor_class->invalidate (cursor);
}

static void
clutter_cursor_init (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  priv->scale = 1.0f;
  priv->transform = MTK_MONITOR_TRANSFORM_NORMAL;
}

static void
clutter_cursor_finalize (GObject *object)
{
  ClutterCursor *cursor = CLUTTER_CURSOR (object);
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  g_clear_object (&priv->color_state);

  G_OBJECT_CLASS (clutter_cursor_parent_class)->finalize (object);
}

static void
clutter_cursor_set_property (GObject      *object,
                             guint         prop_id,
                             const GValue *value,
                             GParamSpec   *pspec)
{
  ClutterCursor *cursor = CLUTTER_CURSOR (object);
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  switch (prop_id)
    {
    case PROP_COLOR_STATE:
      g_set_object (&priv->color_state, g_value_get_object (value));
      break;
    case PROP_CURSOR_TYPE:
      priv->cursor_type = g_value_get_enum (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
    }
}

static void
clutter_cursor_class_init (ClutterCursorClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->finalize = clutter_cursor_finalize;
  object_class->set_property = clutter_cursor_set_property;

  obj_props[PROP_COLOR_STATE] =
    g_param_spec_object ("color-state", NULL, NULL,
                         CLUTTER_TYPE_COLOR_STATE,
                         G_PARAM_WRITABLE |
                         G_PARAM_CONSTRUCT_ONLY |
                         G_PARAM_STATIC_STRINGS);
  obj_props[PROP_CURSOR_TYPE] =
    g_param_spec_enum ("cursor-type", NULL, NULL,
                       CLUTTER_TYPE_CURSOR_TYPE,
                       CLUTTER_CURSOR_INHERIT,
                       G_PARAM_WRITABLE |
                       G_PARAM_CONSTRUCT_ONLY |
                       G_PARAM_STATIC_STRINGS);

  g_object_class_install_properties (object_class, N_PROPS, obj_props);

  signals[IMAGE_CHANGED] =
    g_signal_new ("image-changed",
                  G_TYPE_FROM_CLASS (object_class),
                  G_SIGNAL_RUN_LAST,
                  0, NULL, NULL, NULL,
                  G_TYPE_NONE, 0);
}

ClutterColorState *
clutter_cursor_get_color_state (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  return priv->color_state;
}

void
clutter_cursor_emit_image_changed (ClutterCursor *cursor)
{
  g_signal_emit (cursor, signals[IMAGE_CHANGED], 0);
}

ClutterCursorType
clutter_cursor_get_cursor_type (ClutterCursor *cursor)
{
  ClutterCursorPrivate *priv =
    clutter_cursor_get_instance_private (cursor);

  return priv->cursor_type;
}

const char *
clutter_cursor_type_to_name (ClutterCursorType cursor)
{
  switch (cursor)
    {
    case CLUTTER_CURSOR_DEFAULT:
      return "default";
    case CLUTTER_CURSOR_CONTEXT_MENU:
      return "context-menu";
    case CLUTTER_CURSOR_HELP:
      return "help";
    case CLUTTER_CURSOR_POINTER:
      return "pointer";
    case CLUTTER_CURSOR_PROGRESS:
      return "progress";
    case CLUTTER_CURSOR_WAIT:
      return "wait";
    case CLUTTER_CURSOR_CELL:
      return "cell";
    case CLUTTER_CURSOR_CROSSHAIR:
      return "crosshair";
    case CLUTTER_CURSOR_TEXT:
      return "text";
    case CLUTTER_CURSOR_VERTICAL_TEXT:
      return "vertical-text";
    case CLUTTER_CURSOR_ALIAS:
      return "alias";
    case CLUTTER_CURSOR_COPY:
      return "copy";
    case CLUTTER_CURSOR_MOVE:
      return "move";
    case CLUTTER_CURSOR_NO_DROP:
      return "no-drop";
    case CLUTTER_CURSOR_NOT_ALLOWED:
      return "not-allowed";
    case CLUTTER_CURSOR_GRAB:
      return "grab";
    case CLUTTER_CURSOR_GRABBING:
      return "grabbing";
    case CLUTTER_CURSOR_E_RESIZE:
      return "e-resize";
    case CLUTTER_CURSOR_N_RESIZE:
      return "n-resize";
    case CLUTTER_CURSOR_NE_RESIZE:
      return "ne-resize";
    case CLUTTER_CURSOR_NW_RESIZE:
      return "nw-resize";
    case CLUTTER_CURSOR_S_RESIZE:
      return "s-resize";
    case CLUTTER_CURSOR_SE_RESIZE:
      return "se-resize";
    case CLUTTER_CURSOR_SW_RESIZE:
      return "sw-resize";
    case CLUTTER_CURSOR_W_RESIZE:
      return "w-resize";
    case CLUTTER_CURSOR_EW_RESIZE:
      return "ew-resize";
    case CLUTTER_CURSOR_NS_RESIZE:
      return "ns-resize";
    case CLUTTER_CURSOR_NESW_RESIZE:
      return "nesw-resize";
    case CLUTTER_CURSOR_NWSE_RESIZE:
      return "nwse-resize";
    case CLUTTER_CURSOR_COL_RESIZE:
      return "col-resize";
    case CLUTTER_CURSOR_ROW_RESIZE:
      return "row-resize";
    case CLUTTER_CURSOR_ALL_SCROLL:
      return "all-scroll";
    case CLUTTER_CURSOR_ZOOM_IN:
      return "zoom-in";
    case CLUTTER_CURSOR_ZOOM_OUT:
      return "zoom-out";
    case CLUTTER_CURSOR_DND_ASK:
      return "dnd-ask";
    case CLUTTER_CURSOR_ALL_RESIZE:
      return "all-resize";
    case CLUTTER_CURSOR_INHERIT:
    case CLUTTER_CURSOR_NONE:
      break;
    }

  g_assert_not_reached ();
  return NULL;
}
