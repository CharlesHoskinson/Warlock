/*
 * Cogl
 *
 * A Low Level GPU Graphics and Utilities API
 *
 * Copyright (C) 2007,2008,2009 Intel Corporation.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#pragma once

#if !defined(__COGL_H_INSIDE__) && !defined(COGL_COMPILATION)
#error "Only <cogl/cogl.h> can be included directly."
#endif

#include "cogl/cogl-types.h"
#include "cogl/cogl-pixel-format.h"
#include "cogl/cogl-driver.h"
#include "cogl/winsys/cogl-winsys.h"

#include <glib-object.h>

G_BEGIN_DECLS

/**
 * CoglRenderer:
 *
 * Choosing a means to render
 *
 * A #CoglRenderer represents a means to render. It encapsulates the
 * selection of an underlying driver, such as OpenGL or OpenGL-ES.
 *
 * A #CoglRenderer has two states, "unconnected" and "connected".
 *
 * After configuration a #CoglRenderer can (optionally) be explicitly
 * connected using cogl_renderer_connect() which allows for the
 * handling of connection errors so that fallback configurations can
 * be tried if necessary. Applications that don't support any
 * fallbacks though can skip using cogl_renderer_connect() and leave
 * Cogl to automatically connect the renderer.
 */


/**
 * COGL_RENDERER_ERROR:
 *
 * An error domain for exceptions reported by Cogl
 */
#define COGL_RENDERER_ERROR cogl_renderer_error_quark ()

COGL_EXPORT uint32_t
cogl_renderer_error_quark (void);

/**
 * CoglDriverId:
 * @COGL_DRIVER_ID_ANY: Implies no preference for which driver is used
 * @COGL_DRIVER_ID_NOP: A No-Op driver.
 * @COGL_DRIVER_ID_GL3: An OpenGL driver using the core GL 3.1 profile
 * @COGL_DRIVER_ID_GLES2: An OpenGL ES 2.0 driver.
 *
 * Identifiers for underlying hardware drivers that may be used by
 * Cogl for rendering.
 */
typedef enum
{
  COGL_DRIVER_ID_ANY,
  COGL_DRIVER_ID_NOP,
  COGL_DRIVER_ID_GL3,
  COGL_DRIVER_ID_GLES2,
} CoglDriverId;


#define COGL_TYPE_RENDERER (cogl_renderer_get_type ())

struct _CoglRendererClass
{
  GObjectClass parent_class;

  void (* bind_api) (CoglRenderer *renderer);

  gboolean (* load_driver) (CoglRenderer  *renderer,
                            CoglDriverId   driver_id,
                            GError       **error);

  GCallback (* get_proc_address) (CoglRenderer *renderer,
                                  const char   *name);

  gboolean (* connect) (CoglRenderer  *renderer,
                        GError       **error);

  GArray * (* query_drm_modifiers) (CoglRenderer           *renderer,
                                    CoglPixelFormat         format,
                                    CoglDrmModifierFilter   filter,
                                    GError                **error);

  uint64_t (* get_implicit_drm_modifier) (CoglRenderer *renderer);

  CoglDmaBufHandle * (* create_dma_buf) (CoglRenderer     *renderer,
                                         CoglPixelFormat   format,
                                         uint64_t         *modifiers,
                                         int               n_modifiers,
                                         int               width,
                                         int               height,
                                         GError          **error);

  gboolean (* is_dma_buf_supported) (CoglRenderer *renderer);

  CoglFramebuffer * (* create_dma_buf_framebuffer) (CoglRenderer     *renderer,
                                                    CoglContext      *context,
                                                    uint32_t          width,
                                                    uint32_t          height,
                                                    uint32_t          drm_format,
                                                    CoglPixelFormat   cogl_format,
                                                    int               n_planes,
                                                    const int        *fds,
                                                    const uint32_t   *strides,
                                                    const uint32_t   *offsets,
                                                    const uint64_t   *modifiers,
                                                    GError          **error);

  gboolean (* is_hardware_accelerated) (CoglRenderer *renderer);

  void (* update_sync) (CoglRenderer *renderer);

  int (* get_sync_fd) (CoglRenderer *renderer);
};

COGL_EXPORT
G_DECLARE_DERIVABLE_TYPE (CoglRenderer,
                          cogl_renderer,
                          COGL,
                          RENDERER,
                          GObject)

/* Final connection API */

/**
 * cogl_renderer_connect:
 * @renderer: An unconnected #CoglRenderer
 * @error: a pointer to a #GError for reporting exceptions
 *
 * Connects the configured @renderer. Renderer connection isn't a
 * very active process, it basically just means validating that
 * any given constraint criteria can be satisfied and that a
 * usable driver and window system backend can be found.
 *
 * Return value: %TRUE if there was no error while connecting the
 *               given @renderer. %FALSE if there was an error.
 */
COGL_EXPORT gboolean
cogl_renderer_connect (CoglRenderer *renderer, GError **error);

/**
 * cogl_renderer_get_driver_id:
 * @renderer: A connected #CoglRenderer
 *
 * Queries what underlying driver is being used by Cogl.
 *
 * This may only be called on a connected #CoglRenderer.
 */
COGL_EXPORT CoglDriverId
cogl_renderer_get_driver_id (CoglRenderer *renderer);


/**
 * cogl_renderer_query_drm_modifiers: (skip)
 * @renderer: A #CoglRenderer
 * @format: The #CoglPixelFormat
 * @error: (nullable): return location for a #GError
 */
COGL_EXPORT GArray *
cogl_renderer_query_drm_modifiers (CoglRenderer           *renderer,
                                   CoglPixelFormat         format,
                                   CoglDrmModifierFilter   filter,
                                   GError                **error);

COGL_EXPORT uint64_t
cogl_renderer_get_implicit_drm_modifier (CoglRenderer *renderer);

COGL_EXPORT gboolean
cogl_renderer_is_implicit_drm_modifier (CoglRenderer *renderer,
                                        uint64_t      modifier);

/**
 * cogl_renderer_create_dma_buf: (skip)
 * @renderer: A #CoglRenderer
 * @format: A #CoglPixelFormat
 * @modifiers: array of DRM format modifiers
 * @n_modifiers: length of modifiers array
 * @width: width of the new
 * @height: height of the new
 * @error: (nullable): return location for a #GError
 *
 * Creates a new #CoglFramebuffer with @width x @height, with pixel
 * format @format, and exports the new framebuffer's DMA buffer
 * handle.
 *
 * Passing an empty modifier array (passing a 0 n_modifiers) means implicit
 * modifiers will be used.
 *
 * Returns: (nullable)(transfer full): a #CoglDmaBufHandle. The
 * return result must be released with cogl_dma_buf_handle_free()
 * after use.
 */
COGL_EXPORT CoglDmaBufHandle *
cogl_renderer_create_dma_buf (CoglRenderer     *renderer,
                              CoglPixelFormat   format,
                              uint64_t         *modifiers,
                              int               n_modifiers,
                              int               width,
                              int               height,
                              GError          **error);

/**
 * cogl_renderer_is_dma_buf_supported:
 * @renderer: A #CoglRenderer
 *
 * Returns: %TRUE if DMA buffers can be allocated
 */
COGL_EXPORT gboolean
cogl_renderer_is_dma_buf_supported (CoglRenderer *renderer);

/**
 * cogl_renderer_create_dma_buf_framebuffer: (skip)
 */
COGL_EXPORT CoglFramebuffer *
cogl_renderer_create_dma_buf_framebuffer (CoglRenderer     *renderer,
                                          CoglContext      *context,
                                          uint32_t          width,
                                          uint32_t          height,
                                          uint32_t          drm_format,
                                          CoglPixelFormat   cogl_format,
                                          int               n_planes,
                                          const int        *fds,
                                          const uint32_t   *strides,
                                          const uint32_t   *offsets,
                                          const uint64_t   *modifiers,
                                          GError          **error);

/**
 * cogl_renderer_is_hardware_accelerated:
 * @renderer: A connected #CoglRenderer
 *
 * Returns: %TRUE if the renderer is backed by hardware acceleration
 */
COGL_EXPORT gboolean
cogl_renderer_is_hardware_accelerated (CoglRenderer *renderer);

/**
 * cogl_renderer_bind_api:
 */
COGL_EXPORT void
cogl_renderer_bind_api (CoglRenderer *renderer);

/**
 * cogl_renderer_get_proc_address:
 * @renderer: A #CoglRenderer.
 * @name: the name of the function.
 *
 * Gets a pointer to a given GL or GL ES extension function. This acts
 * as a wrapper around glXGetProcAddress() or whatever is the
 * appropriate function for the current backend.
 *
 * This function should not be used to query core opengl API
 * symbols since eglGetProcAddress for example doesn't allow this and
 * and may return a junk pointer if you do.
 *
 * Return value: a pointer to the requested function or %NULL if the
 *   function is not available.
 */
COGL_EXPORT void *
cogl_renderer_get_proc_address (CoglRenderer *renderer,
                                const char   *name);

/**
 * cogl_renderer_get_latest_sync_fd
 * @renderer: a #CoglRenderer
 *
 * This function is used to get support for waiting on previous
 * GPU work through sync fds. It will return a sync fd which will
 * signal when the previous work has completed.
 *
 * Return value: sync fd for latest GPU submission if available,
 * returns -1 if not.
 */
COGL_EXPORT
int cogl_renderer_get_latest_sync_fd (CoglRenderer *renderer);

G_END_DECLS
