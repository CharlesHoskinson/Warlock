/*
 * Cogl
 *
 * A Low Level GPU Graphics and Utilities API
 *
 * Copyright (C) 2012 Intel Corporation.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#include "config.h"

#include <strings.h>

#include "cogl/cogl-context-private.h"
#include "cogl/cogl-texture-private.h"
#include "cogl/cogl-texture-2d-private.h"
#include "cogl/cogl-util.h"
#include "cogl/driver/gl/cogl-driver-gl-private.h"
#include "cogl/driver/gl/cogl-texture-2d-gl-private.h"
#include "cogl/driver/gl/cogl-texture-gl-private.h"
#include "cogl/driver/gl/cogl-pipeline-gl-private.h"

static inline int
calculate_alignment (int rowstride)
{
  int alignment = 1 << (ffs (rowstride) - 1);

  return MIN (alignment, 8);
}

void
_cogl_texture_gl_prep_alignment_for_pixels_upload (CoglContext *ctx,
                                                   int pixels_rowstride)
{
  CoglDriver *driver = cogl_context_get_driver (ctx);

  GE (driver, glPixelStorei (GL_UNPACK_ALIGNMENT,
                             calculate_alignment (pixels_rowstride)));
}

void
_cogl_texture_gl_prep_alignment_for_pixels_download (CoglDriver *driver,
                                                     int         bpp,
                                                     int         width,
                                                     int         rowstride)
{
  int alignment;

  /* If no padding is needed then we can always use an alignment of 1.
   * We want to do this even though it is equivalent to the alignment
   * of the rowstride because the Intel driver in Mesa currently has
   * an optimisation when reading data into a PBO that only works if
   * the alignment is exactly 1.
   *
   * https://bugs.freedesktop.org/show_bug.cgi?id=46632
   */

  if (rowstride == bpp * width)
    alignment = 1;
  else
    alignment = calculate_alignment (rowstride);

  GE (driver, glPixelStorei (GL_PACK_ALIGNMENT, alignment));
}

GLenum
_cogl_texture_gl_get_format (CoglTexture *texture)
{
  CoglTexture2D *leaf = cogl_texture_get_first_leaf (texture);

  g_return_val_if_fail (leaf != NULL, GL_RGBA);

  return COGL_TEXTURE_2D_GL (leaf)->gl_internal_format;
}

gboolean
cogl_texture_get_gl_texture (CoglTexture *texture,
                             GLuint      *out_gl_handle,
                             GLenum      *out_gl_target)
{
  CoglTexture2D *leaf;
  CoglTexture2DGL *leaf_gl;

  g_return_val_if_fail (COGL_IS_TEXTURE (texture), FALSE);

  if (!cogl_texture_is_allocated (texture))
    cogl_texture_allocate (texture, NULL);

  leaf = cogl_texture_get_first_leaf (texture);
  if (!leaf)
    return FALSE;

  leaf_gl = COGL_TEXTURE_2D_GL (leaf);

  if (out_gl_handle)
    *out_gl_handle = leaf_gl->gl_texture;

  if (out_gl_target)
    *out_gl_target = leaf_gl->gl_target;

  return leaf_gl->gl_texture ? TRUE : FALSE;
}
