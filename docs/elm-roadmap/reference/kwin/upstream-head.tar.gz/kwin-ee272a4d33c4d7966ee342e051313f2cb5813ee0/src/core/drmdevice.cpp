/*
    KWin - the KDE window manager
    This file is part of the KDE project.

    SPDX-FileCopyrightText: 2024 Xaver Hugl <xaver.hugl@gmail.com>

    SPDX-License-Identifier: GPL-2.0-or-later
*/
#include "drmdevice.h"

#include "gbmgraphicsbufferallocator.h"
#include "utils/common.h"

#include <fcntl.h>
#include <gbm.h>
#include <sys/stat.h>
#include <xf86drm.h>
#include <xf86drmMode.h>

namespace KWin
{

static QByteArray getDriverName(const FileDescriptor &fd)
{
    auto version = drmGetVersion(fd.get());
    if (version) {
        auto ret = QByteArray(version->name, version->name_len);
        drmFreeVersion(version);
        return ret;
    } else {
        return QByteArray();
    }
}

DrmDevice::DrmDevice(const QString &path, dev_t id, FileDescriptor &&fd, gbm_device *gbmDevice)
    : m_path(path)
    , m_id(id)
    , m_fd(std::move(fd))
    , m_gbmDevice(gbmDevice)
    , m_driverName(getDriverName(m_fd))
    , m_isNvidia(m_driverName == "nvidia-drm")
    , m_isNouveau(m_driverName == "nouveau")
    , m_isI915(m_driverName == "i915")
    , m_isIntelXE(m_driverName == "xe")
    , m_isAmdgpu(m_driverName == "amdgpu")
    , m_isRadeon(m_driverName == "radeon")
    , m_isVmwgfx(m_driverName == "vmwgfx")
    , m_isVirtualMachine(m_driverName == "virtio_gpu" || m_driverName == "qxl" || m_driverName == "vmwgfx" || m_driverName == "vboxvideo")
    , m_isKMS(drmIsKMS(m_fd.get()))
    , m_allocator(std::make_unique<GbmGraphicsBufferAllocator>(this))
{
    drmGetDevice2(m_fd.get(), 0, &m_libdrmDevice);
    uint64_t value = 0;
    m_supportsSyncObjTimelines = drmGetCap(m_fd.get(), DRM_CAP_SYNCOBJ_TIMELINE, &value) == 0 && value != 0;
}

DrmDevice::~DrmDevice()
{
    gbm_device_destroy(m_gbmDevice);
    if (m_libdrmDevice) {
        drmFreeDevice(&m_libdrmDevice);
    }
}

QString DrmDevice::path() const
{
    return m_path;
}

dev_t DrmDevice::deviceId() const
{
    return m_id;
}

gbm_device *DrmDevice::gbmDevice() const
{
    return m_gbmDevice;
}

GraphicsBufferAllocator *DrmDevice::allocator() const
{
    return m_allocator.get();
}

int DrmDevice::fileDescriptor() const
{
    return m_fd.get();
}

bool DrmDevice::supportsSyncObjTimelines() const
{
    return m_supportsSyncObjTimelines;
}

std::optional<drmPciDeviceInfo> DrmDevice::pciDeviceInfo() const
{
    if (!m_libdrmDevice || m_libdrmDevice->bustype != DRM_BUS_PCI) {
        return std::nullopt;
    }
    return *m_libdrmDevice->deviceinfo.pci;
}

bool DrmDevice::equals(DrmDevice *other) const
{
    return drmDevicesEqual(m_libdrmDevice, other->m_libdrmDevice);
}

drmDevice *DrmDevice::libdrmDevice() const
{
    return m_libdrmDevice;
}

std::optional<int> DrmDevice::busType() const
{
    return m_libdrmDevice ? m_libdrmDevice->bustype : std::optional<int>();
}

QByteArray DrmDevice::driverName() const
{
    return m_driverName;
}

bool DrmDevice::isNvidia() const
{
    return m_isNvidia;
}

bool DrmDevice::isNouveau() const
{
    return m_isNouveau;
}

bool DrmDevice::isI915() const
{
    return m_isI915;
}

bool DrmDevice::isIntelXE() const
{
    return m_isIntelXE;
}

bool DrmDevice::isAmdgpu() const
{
    return m_isAmdgpu;
}

bool DrmDevice::isRadeon() const
{
    return m_isRadeon;
}

bool DrmDevice::isVmwgfx() const
{
    return m_isVmwgfx;
}

bool DrmDevice::isVirtualMachine() const
{
    return m_isVirtualMachine;
}

bool DrmDevice::isKMS() const
{
    return m_isKMS;
}

std::unique_ptr<DrmDevice> DrmDevice::open(const QString &path)
{
    return openWithAuthentication(path, -1);
}

std::unique_ptr<DrmDevice> DrmDevice::openWithAuthentication(const QString &path, int authenticatedFd)
{
    FileDescriptor fd(::open(path.toLocal8Bit(), O_RDWR | O_CLOEXEC));
    if (!fd.isValid()) {
        qCWarning(KWIN_CORE, "Failed to open drm node %s: %s", qPrintable(path), strerror(errno));
        return nullptr;
    }
    struct stat buf;
    if (fstat(fd.get(), &buf) == -1) {
        qCWarning(KWIN_CORE) << "Failed to fstat drm fd" << path;
        return nullptr;
    }
    if (authenticatedFd != -1) {
        drm_magic_t magic;
        if (drmGetMagic(fd.get(), &magic) < 0) {
            qCDebug(KWIN_CORE) << "Failed to get the drm magic token for" << path;
        }
        if (drmAuthMagic(authenticatedFd, magic) < 0) {
            qCWarning(KWIN_CORE) << "Failed to authenticate the drm magic token. path:" << path << "error:" << strerror(errno);
        }
    }
    gbm_device *device = gbm_create_device(fd.get());
    if (!device) {
        qCWarning(KWIN_CORE) << "Failed to create gbm device for" << path;
        return nullptr;
    }
    return std::unique_ptr<DrmDevice>(new DrmDevice(path, buf.st_rdev, std::move(fd), device));
}

}
