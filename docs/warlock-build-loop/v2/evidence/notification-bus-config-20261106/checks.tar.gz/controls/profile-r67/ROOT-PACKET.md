# Notification config fixed profile

This private patch adds a closed `--notification-config` ARM profile. It builds the ordinary runtime library and one test suite with the unchanged Root 30-control Main. The suite sees no production home modules or CPP. The wrapper pins and copies the fixed test image, creates one private storage root and passes only that argument; the helper checks the single normal receipt, copied image pin and exact thirty ordered `True` results. Existing profiles and fixtures are preserved.

Root’s narrow source review covers the candidate Backend and fixture; Q7 must independently review this exact new profile before Root adoption. The first authorized protected build uses the current Backend, which lacks `configuredNotificationBusAddress`: an actual missing-export compiler failure is API RED, not a semantic fixture result. Root can then independently select the reviewed Backend candidate and rerun the exact fixture; only an actual normal receipt and all thirty ordered literals establish the scoped data GREEN. No execution occurred here.

The selected address is data, not proof of an authenticated socket or notification producer. No daemon, service, issuer, native or original UX031 acceptance is implied.
