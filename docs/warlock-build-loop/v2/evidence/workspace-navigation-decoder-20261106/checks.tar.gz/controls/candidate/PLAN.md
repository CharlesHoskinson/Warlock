# Existing workspace-navigation wire decoder

Implement the existing protocol3/workspaceProtocol1 data schema in a separate opaque Haskell module. Do not modify Desktop request dispatch or native authority.

The existing workspace-navigation Quint model constrains navigation state, refusal, retirement and replay. This decoder changes none of those transitions. Its wire predicates come from WorkspaceNavigation.elm, WorkspaceInventory.elm and canonical Identity/Wire decoders. Do not change the model or its original budgets.

1. Write ordinary linked source fixtures against the proposed public decoder. Record them as unexecuted until Root freezes the protected packet.
2. Implement the standalone opaque request and recovery data decoder. Preserve exact fields, nested request identity, canonical counters, signed ordinary workspace identity range and binding/context correspondence. Recovery has no invented request counter.
3. Obtain independent source and formal-boundary review. Reject this packet if its schema differs from the actual producer or native admission is implied.
4. Use the governed participant and protected QA preflight before any shared adoption or compiler execution. Require actual RED, GREEN, old decoder regression and unchanged model checks under original limits. Private source alone proves none of these.

The current Desktop decoder still refuses navigation. This increment supplies a required schema parser only. Actual owner transport, provider custody, dispatch, native receipts and original acceptance remain separate mandatory work.
