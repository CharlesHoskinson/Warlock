# UI-006 DOM profile review — CHANGES_REQUIRED

The peer candidate cannot be copied over current Root helpers: it predates the current `--workspace-owner-component-red` mode. The review is limited to execution, custody and source binding; Q5 separately owns predicate semantics. Fixed Node/Elm paths, source pins, existing private network/PID isolation, pinned ARM toolchain, one JSON receipt and all named true controls remain requirements. The 138-file cache figure is read from the tracked SDK manifest, not from the cache.

`peer-copy-binding-correction.patch` addresses two specific transient input gaps in the peer helper: the private `src` inventory must equal the pre-copy source inventory, and the exact elm.json bytes parsed must match the reviewed SHA-256. This is our own unreviewed successor, based on peer r58, not an apply-ready patch against current Root. Root must reconcile only the reviewed DOM addition and the correction with its current exact tools, preserving all existing selectors, budgets and prior RED/GREEN modes. A peer review must check this successor and any reconciled version independently.

Root's protected preflight must bind complete source/fixture/tool/SDK closure, confirm 19-check inventory, fixed image identity and receipt, keep 180-second command and 3500-second outer limits and retain actual failure evidence. The fake DOM is not a browser or physical input, and no native/AT/IME, opaque Cmd, capacity or original scenario acceptance follows. No tests, compilers, validators, models, SDK/cache operations, native work or network ran.

During this read-only review, current Root Surface changed from 175d4432 to 9b49b673. The latter matches the DOM profile candidate pin; Root must recheck the complete final tuple before any protected run.
