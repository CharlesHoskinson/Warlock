# Fixed original Task View ARM profile — private draft

The additive patch introduces only --workspace-original and its exact source roster; prior modes are preserved. It compiles the existing three workers and runs the separate fixed consumer with its 78/7/16 literal check inventory. Existing workers, generic harnesses and subscription mode remain untouched. Source/cache, copied QA, image and receipt hashes are checked; the launcher retains existing 180-second commands and 3500-second outer scope.

This is uncompiled, unexecuted and unreviewed. Independent Q8 must inspect all changed call sites and strict receipt semantics, SDK policy and original inventory correspondence. Root alone can adopt and run it. root-review-request.json contains staged candidate hashes and MUST be refreshed and reviewed after Root stages the exact files. No result claims native, keyboard, accessibility or original UI-006 acceptance.
