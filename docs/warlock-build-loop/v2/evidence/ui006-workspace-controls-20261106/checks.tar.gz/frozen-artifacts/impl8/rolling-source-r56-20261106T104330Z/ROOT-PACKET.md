# UI-006 policy-to-candidate packet

Current 175d Surface lacks management rows. Candidate 9b49 adds three disabled, no-message rows in normal Task View. The exact frozen INTERACTION policy and owner/resolver mapping are in policy-to-candidate.json. No new product source counterexample was found in this mapping; no production patch is proposed.

I7 r54 is terminal and retains r53 candidate and 24-check fixture. Its Root oracle review requires the same fixture for baseline RED and candidate GREEN. The separately authored fixture-successor.patch adds a 25th check covering each management row for keyboard and pointer through Surface.resolve and OutputController.Renderer. It requires independent review and explicit fixed-profile integration; do not silently replace the reviewed 24-check profile. No compiler, tests or QA were run.

All five original oracles, native authority, pixels, eligible focus, accessibility, identity retirement, capacity and returned Cmd remain open. Keep existing budgets and gates. Root alone reviews, adopts and runs the protected profile.
