# Corrected original Task View ARM profile

The Q8 correction exactly matches reviewed-staging-binding.patch and binds the source tree, read-once elm.json bytes and both cache copies to the reviewed source/ARM manifest values. The private assembly carries only that correction on top of I8 r60; launcher, fixed consumer, 101 named checks and command budgets are unchanged. This is an independent review of the Q8 correction, not approval of the I8 original profile or this assembly.

Q8 should independently review this assembled helper, full combined patch, request and source/hash roster. Root must review and stage exact files before refreshing/reviewing the request and running the protected profile. No compiler, tests, QA or native observations were performed. Original UI-006, native, AT, physical, opaque Cmd and capacity gates remain open.
