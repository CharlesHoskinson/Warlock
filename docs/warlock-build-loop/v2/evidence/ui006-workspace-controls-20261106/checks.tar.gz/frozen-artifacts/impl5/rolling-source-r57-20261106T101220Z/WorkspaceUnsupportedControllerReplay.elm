port module WorkspaceUnsupportedControllerReplay exposing (main)

{- Source-only fixture: input protocol examples are not native receipts. -}
import Desktop
import ActionProjection as Scene
import Effects
import Json.Decode as D
import Json.Encode as E
import Platform
import Shell
import Surface
import SurfaceRenderer
import SurfaceController as Controller
import TaskView
import UInt64

port outgoing : E.Value -> Cmd msg

counter s = D.decodeValue UInt64.decoder (E.string s) |> Result.withDefault UInt64.zero
binding frontend = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string frontend)]
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",binding "1")]
pointer = E.object [("protocolVersion",E.int 3),("kind",E.string "pointer-ownership"),("ownershipProtocol",E.int 1),("binding",binding "1"),("requestId",E.string "1"),("serial",E.string "1"),("state",E.string "idle"),("owner",E.null)]
window id label minimized = E.object [("incarnation",E.string id),("label",E.string label),("owner",E.null),("application",E.string label),("minimized",E.bool minimized),("available",E.bool True)]
projection request frontend epoch target = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",binding frontend),("requestId",E.string request),("context",E.object [("lifetime",E.string "1"),("epoch",E.string epoch),("output",E.string "1"),("revision",E.string "1")]),("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),("windows",E.list identity [window "1" "Editor" False,window "2" "Files" True])])]
negotiate = E.object [("protocolVersion",E.int 3),("kind",E.string "host-geometry-negotiate")]
geometryAttached = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-attached"),("geometryProtocol",E.int 3),("binding",binding "1"),("requestId",E.string "2"),("capabilities",E.object [("observe",E.bool True),("effects",E.bool True),("effectProtocol",E.int 2),("operations",E.list E.string ["maximize","restore-geometry","snap","transfer-workspace","pin","unpin","exit-fullscreen"]),("placementCapacity",E.int 256),("canonicalScene",E.bool False)])]
policyProjection logical visual configure = E.object [("logical",E.list E.float logical),("visual",visual),("real",E.list E.float logical),("configure",E.list E.float configure)]
sizePolicy = E.object [("inputs",E.object [("profile",E.string "wayland-zero-origin-v1"),("rawMinimum",E.list E.float [1,1]),("rawMaximum",E.list E.float [0,0]),("layoutMinimum",E.list E.float [1,1]),("layoutMaximum",E.list E.float [10000,10000]),("geometryOrigin",E.list E.float [0,0]),("reservedTopLeft",E.list E.float [0,0]),("reservedBottomRight",E.list E.float [0,0]),("monitorScale",E.float 1)]),("maximize",policyProjection [0,0,800,600] E.null [800,600]),("restoreGeometry",policyProjection [10,20,320,240] (E.list E.float [10,20,320,240]) [320,240])]
geometryRow id workspace minimized = E.object [("incarnation",E.string id),("owner",E.null),("workspace",E.string workspace),("workspaceGeneration",E.string workspace),("monitor",E.string "0"),("outputOwnershipGeneration",E.string "1"),("workAreaRevision",E.string "1"),("workArea",E.list E.float [0,0,800,600]),("logicalGeometry",E.list E.float [10,20,320,240]),("visualGeometry",E.list E.float [10,20,320,240]),("nativeMode",E.string "ordinary"),("clientMode",E.string "ordinary"),("minimized",E.bool minimized),("floating",E.bool True),("grouped",E.bool False),("fixedSize",E.bool False),("constrainedSize",E.bool True),("geometryEligible",E.bool (workspace=="1" && not minimized)),("ordinaryPlacementKnown",E.bool False),("capabilities",E.object [("maximize",E.bool False),("restoreGeometry",E.bool False)]),("sizePolicy",sizePolicy),("pin",E.object [("pinned",E.bool False),("eligible",E.bool False)])]
workspace id = E.object [("identity",E.string id),("generation",E.string id),("monitor",E.string "0"),("outputOwnershipGeneration",E.string "1")]
geometry request sequence = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-facts"),("geometryProtocol",E.int 3),("binding",binding "1"),("requestId",E.string request),("sequence",E.string sequence),("revision",E.string "1"),("outputGeneration",E.string "1"),("facts",E.object [("focused",E.string "1"),("inputBlocked",E.bool False),("windows",E.list identity [geometryRow "1" "1" False,geometryRow "2" "2" True]),("workspaces",E.list identity [workspace "1",workspace "2"]),("activeWorkspace",E.string "1")])]
step event model = Controller.update event model |> Tuple.first
native value model = step (Controller.Interaction (Desktop.Incoming value)) model
beforeRecovery = Controller.initial |> native attached |> native (projection "1" "1" "1" "2") |> native pointer |> native negotiate |> native geometryAttached |> native (geometry "3" "1")

-- The publication and lease are input credentials from the actual frame,
-- not expected values and not native authority.
action role id trigger model =
    let frame = Controller.frame model
        field name = D.decodeValue (D.field name D.string) frame |> Result.withDefault "0"
    in E.object [("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("surface",E.string role),("publication",E.string (field "publication")),("lease",E.string (field "lease")),("id",E.string id),("trigger",E.string trigger)]
fire role id trigger model = Controller.update (Controller.Renderer (action role id trigger model)) model
wires effects = effects |> List.filterMap (\effect -> case effect of
    Controller.DesktopEffect (Desktop.WindowEffect (Shell.Send raw)) -> Just raw
    Controller.DesktopEffect (Desktop.Send raw) -> Just raw
    _ -> Nothing)
kind raw = D.decodeValue (D.field "kind" D.string) raw |> Result.withDefault ""
mutations effects = wires effects |> List.filter (kind >> (==) "window-effect")
readIds effects = wires effects |> List.filter (kind >> (==) "projection-request") |> List.filterMap (D.decodeValue (D.field "requestId" D.string) >> Result.toMaybe)
expectedWire = E.object [("protocolVersion",E.int 3),("kind",E.string "window-effect"),("effectProtocol",E.int 1),("binding",binding "1"),("intent",E.object [("request",E.string "1"),("generation",E.string "1"),("incarnation",E.string "2"),("operation",E.string "activate"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")])])]
isExactActivation raw =
    let str path = D.decodeValue (D.at path D.string) raw
    in E.encode 0 raw==E.encode 0 expectedWire
       && D.decodeValue (D.field "protocolVersion" D.int) raw==Ok 3
       && D.decodeValue (D.field "effectProtocol" D.int) raw==Ok 1
       && str ["binding","lifetime"]==Ok "1" && str ["binding","session"]==Ok "1" && str ["binding","frontend"]==Ok "1"
       && str ["intent","request"]==Ok "1" && str ["intent","generation"]==Ok "1"
       && str ["intent","incarnation"]==Ok "2" && str ["intent","operation"]==Ok "activate"
       && str ["intent","context","lifetime"]==Ok "1" && str ["intent","context","epoch"]==Ok "1"
       && str ["intent","context","output"]==Ok "1" && str ["intent","context","revision"]==Ok "1"








-- Decoder input examples only; not producer receipts or visible outcomes.
hostRefresh = E.object [("protocolVersion",E.int 3),("kind",E.string "host-refresh")]
replacementProjection = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",binding "1"),("requestId",E.string "4"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "2")]),("scene",E.object [("revision",E.string "2"),("focused",E.string "1"),("windows",E.list identity [window "1" "Editor" False,window "3" "Files" True])])]
replacementGeometry = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-facts"),("geometryProtocol",E.int 3),("binding",binding "1"),("requestId",E.string "5"),("sequence",E.string "2"),("revision",E.string "2"),("outputGeneration",E.string "1"),("facts",E.object [("focused",E.string "1"),("inputBlocked",E.bool False),("windows",E.list identity [geometryRow "1" "1" False,geometryRow "3" "2" True]),("workspaces",E.list identity [workspace "1",workspace "2"]),("activeWorkspace",E.string "1")])]
outcome frontend request incarnation status = E.object [("protocolVersion",E.int 3),("kind",E.string "effect-outcome"),("effectProtocol",E.int 1),("binding",binding frontend),("intent",E.object [("request",E.string request),("generation",E.string "1"),("incarnation",E.string incarnation),("operation",E.string "restore"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")])]),("status",E.string status),("reason",E.string (if status=="Unknown" then "effect-unproven" else if status=="Committed" then "applied" else "exclusive-input")),("revision",E.string "1"),("outputGeneration",E.string "1")]
navigationRefusal = E.object [("protocolVersion",E.int 3),("kind",E.string "effect-outcome"),("effectProtocol",E.int 1),("binding",binding "1"),("intent",E.object [("request",E.string "1"),("generation",E.string "1"),("incarnation",E.string "2"),("operation",E.string "restore"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")])]),("status",E.string "Refused"),("reason",E.string "navigation-refused"),("revision",E.string "1"),("outputGeneration",E.string "1")]
focuses effects = effects |> List.filterMap (\effect -> case effect of
    Controller.DesktopEffect (Desktop.Focus target) -> Just target
    _ -> Nothing)
receive raw model = Controller.update (Controller.Interaction (Desktop.Incoming raw)) model
mutationWires effects = wires effects |> List.filter (kind >> (==) "window-effect")
expectedRestore request generation incarnation revision = E.object [("protocolVersion",E.int 3),("kind",E.string "window-effect"),("effectProtocol",E.int 1),("binding",binding "1"),("intent",E.object [("request",E.string request),("generation",E.string generation),("incarnation",E.string incarnation),("operation",E.string "restore"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string revision)])])]
membership model = (Controller.desktop model).windows.shell.geometry |> Maybe.andThen (\g -> g.windows |> List.filter (\w -> w.incarnation==counter "2") |> List.head) |> Maybe.andThen .workspace
result =
    let original = beforeRecovery
        originalAction = action "bar" "bar:group:application:Files" "keyboard" original
        (refreshing,_) = receive hostRefresh original
        (newAction,_) = receive replacementProjection refreshing
        (replacement,_) = receive replacementGeometry newAction
        (oldClick,oldClickEffects) = Controller.update (Controller.Renderer originalAction) replacement
        (explicitReplacement,replacementEffects) = fire "bar" "bar:group:application:Files" "keyboard" oldClick
        (pending,issuedEffects) = Controller.update (Controller.Renderer originalAction) original
        (duplicate,duplicateEffects) = Controller.update (Controller.Renderer originalAction) pending
        (wrongRequest,wrongRequestEffects) = receive (outcome "1" "99" "2" "Refused") pending
        (foreign,foreignEffects) = receive (outcome "2" "1" "2" "Refused") wrongRequest
        (wrongTarget,wrongTargetEffects) = receive (outcome "1" "1" "3" "Refused") foreign
        (navigationRefused,navigationEffects) = receive navigationRefusal pending
        (refused,refusalEffects) = receive (outcome "1" "1" "2" "Refused") wrongTarget
        (duplicateRefusal,duplicateRefusalEffects) = receive (outcome "1" "1" "2" "Refused") refused
        (stale,staleEffects) = receive (projection "99" "1" "1" "2") refused
        (actionRead,actionEffects) = receive (projection "4" "1" "1" "2") stale
        (readyAgain,geometryEffects) = receive (geometry "5" "2") actionRead
        (retried,retryEffects) = fire "bar" "bar:group:application:Files" "keyboard" readyAgain
        (committed,committedEffects) = receive (outcome "1" "1" "2" "Committed") pending
        (unknown,unknownEffects) = receive (outcome "1" "1" "2" "Unknown") pending
        (unknownAction,unknownActionEffects) = receive (projection "4" "1" "1" "2") unknown
        (unknownRead,unknownReadEffects) = receive (geometry "5" "2") unknownAction
        (unknownRepeat,unknownRepeatEffects) = fire "bar" "bar:group:application:Files" "keyboard" unknownRead
        (unknownForeign,unknownForeignEffects) = receive (outcome "2" "1" "2" "Refused") unknownRead
        (settled,settledEffects) = receive navigationRefusal unknownForeign
        (settledAgain,settledAgainEffects) = receive navigationRefusal settled
        (settledAction,settledActionEffects) = receive (projection "6" "1" "1" "2") settledAgain
        (settledReady,settledReadyEffects) = receive (geometry "7" "3") settledAction
        (explicitAgain,explicitAgainEffects) = fire "bar" "bar:group:application:Files" "keyboard" settledReady
        shell model = (Controller.desktop model).windows.shell
        observedFocus model = (shell model).effects.observed |> Maybe.andThen (.scene >> Scene.focused)
        (overview,overviewEffects) = fire "bar" "bar:overview" "keyboard" original
        overviewDesktop=Controller.desktop overview
        unsupportedIds=["overview:workspace-create","overview:workspace-delete","overview:workspace-rename"]
        controls=Surface.controls overviewDesktop |> List.filter (\control -> List.member control.id unsupportedIds)
        controlRows=List.map (\control -> (control.id,control.ariaLabel,(control.detail,control.enabled,control.message==Nothing))) controls
        tryUnsupported id trigger current = fire "popup" id trigger current
        attempts=List.concatMap (\id -> List.map (\trigger -> tryUnsupported id trigger overview) ["keyboard","pointer"]) unsupportedIds
        (closed,closeEffects)=fire "popup" "control:close" "keyboard" overview
        checks =
            [("controllerOpensOverviewFromBar",overviewDesktop.overview && List.isEmpty (mutationWires overviewEffects))
            ,("controllerShowsLiteralUnsupportedControls",controlRows==[("overview:workspace-create","Create workspace; unavailable",("Not supported",False,True)),("overview:workspace-delete","Delete workspace; unavailable",("Not supported",False,True)),("overview:workspace-rename","Rename workspace; unavailable",("Not supported",False,True))])
            ,("controllerRefusesUnsupportedPointerAndKeyboard",List.all (\(next,effects) -> next==overview && List.isEmpty effects) attempts)
            ,("controllerCloseStillAvailable",not (Controller.desktop closed).overview && List.isEmpty (mutationWires closeEffects))
            ,("targetIsMinimizedOnWorkspaceTwoInExample",membership original==Just "2" && ((shell original).geometry |> Maybe.map (\g -> List.any (\w -> w.incarnation==counter "2" && w.minimized) g.windows) |> Maybe.withDefault False))
            ,("taskbarRestoreHasExactIntent",List.map (E.encode 0) (mutationWires issuedEffects)==[E.encode 0 (expectedRestore "1" "1" "2" "1")] && membership pending==Just "2")
            ,("duplicateCannotReexecute",duplicate==pending && List.isEmpty duplicateEffects)
            ,("retiredClickCannotSelectReplacement",oldClick==replacement && List.isEmpty oldClickEffects && List.map (E.encode 0) (mutationWires replacementEffects)==[E.encode 0 (expectedRestore "1" "1" "3" "2")] && (shell explicitReplacement).effects.transaction/=Nothing)
            ,("foreignStaleAndWrongTargetOutcomesInert",wrongRequest==pending && foreign==pending && wrongTarget==pending && List.isEmpty wrongRequestEffects && List.isEmpty foreignEffects && List.isEmpty wrongTargetEffects)
            ,("refusalRequestsFreshReadsWithoutRestore",(shell refused).expected==Just (counter "4") && (shell refused).geometryExpected==Just (counter "5") && List.isEmpty (mutationWires refusalEffects))
            ,("refusalIsCorrelatedAndDoesNotInventFocus",((shell refused).effects.transaction |> Maybe.map (\t -> (t.intent.incarnation,t.status)))==Just (counter "2",Effects.Refused) && Surface.windowNotice (Controller.desktop refused)=="Restore: refused for Files. Refresh window status, then choose again." && observedFocus refused==Just (counter "1") && List.isEmpty (focuses refusalEffects))
            ,("navigationRefusalIsOnlyASeparateInput",((shell navigationRefused).effects.transaction |> Maybe.map .status)==Just Effects.Refused && Surface.windowNotice (Controller.desktop navigationRefused)=="Restore: refused for Files. Refresh window status, then choose again." && List.isEmpty (mutationWires navigationEffects))
            ,("duplicateRefusalDoesNotReplay",duplicateRefusal==refused && List.isEmpty duplicateRefusalEffects)
            ,("oldReadDoesNotSettle",stale==refused && List.isEmpty staleEffects)
            ,("explicitRetryUsesNewIdentity",List.isEmpty (mutationWires actionEffects) && List.isEmpty (mutationWires geometryEffects) && List.map (E.encode 0) (mutationWires retryEffects)==[E.encode 0 (expectedRestore "2" "2" "2" "1")] && membership retried==Just "2")
            ,("commitEnvelopeDoesNotProveMovement",((shell committed).effects.transaction |> Maybe.map .status)==Just Effects.Committed && membership committed==Just "2" && List.isEmpty (mutationWires committedEffects))
            ,("foreignTerminalCannotSettleUnknown",unknownForeign==unknownRead && List.isEmpty unknownForeignEffects && ((shell unknownForeign).effects.transaction |> Maybe.map .status)==Just Effects.Unknown)
            ,("exactTerminalSettlesButDoesNotReplay",((shell settled).effects.transaction |> Maybe.map .status)==Just Effects.Refused && (shell settled).expected==Just (counter "6") && (shell settled).geometryExpected==Just (counter "7") && List.isEmpty (mutationWires settledEffects))
            ,("duplicateTerminalCannotSettleTwice",settledAgain==settled && List.isEmpty settledAgainEffects)
            ,("onlyExplicitActionAfterTerminalCanRetry",List.isEmpty (mutationWires settledActionEffects) && List.isEmpty (mutationWires settledReadyEffects) && List.map (E.encode 0) (mutationWires explicitAgainEffects)==[E.encode 0 (expectedRestore "2" "2" "2" "1")] && ((shell explicitAgain).effects.transaction |> Maybe.map .status)==Just Effects.Pending)
            ,("unknownRetainsCustodyWithoutReplay",((shell unknownRead).effects.transaction |> Maybe.map .status)==Just Effects.Unknown && List.isEmpty (mutationWires unknownEffects) && List.isEmpty (mutationWires unknownActionEffects) && List.isEmpty (mutationWires unknownReadEffects) && List.isEmpty (mutationWires unknownRepeatEffects) && unknownRepeat==unknownRead)]
    in E.object [("checks",E.object (List.map (Tuple.mapSecond E.bool) checks)),("scope",E.string "Synthetic Unknown/Refused inputs test custody only; no native fallback or compensation is established.")]
main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\_ state -> (state,Cmd.none),subscriptions=\_ -> Sub.none}
