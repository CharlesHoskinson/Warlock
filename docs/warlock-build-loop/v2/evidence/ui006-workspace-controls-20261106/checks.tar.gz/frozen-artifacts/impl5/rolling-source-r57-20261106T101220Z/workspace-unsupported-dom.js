/* Disposable browser fixture only. No action reaches a host or native service. */
'use strict';
window.runWorkspaceUnsupportedDomChecks = async function () {
  const fail = message => { throw new Error(message); };
  const requireThat = (condition, message) => { if (!condition) fail(message); };
  const root = document.getElementById('workspace-unsupported-fixture');
  const mount = document.getElementById('workspace-unsupported-mount');
  requireThat(root && mount && root.contains(mount) && mount.childNodes.length === 0, 'missing or reused fixture root');
  const app = window.Elm.WorkspaceUnsupportedDomReplay.init({node:mount,flags:null});
  const messages = [];
  app.ports.outgoing.subscribe(value => messages.push(value));
  const frame = () => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  await frame();
  const cases = [
    ['overview:workspace-create','Create workspace'],
    ['overview:workspace-delete','Delete workspace'],
    ['overview:workspace-rename','Rename workspace']
  ];
  const element = id => {
    const rows = root.querySelectorAll('[data-surface-control]');
    const matches = Array.from(rows).filter(row => row.getAttribute('data-surface-control') === id);
    requireThat(matches.length === 1, `${id}: missing or duplicate rendered control`);
    return matches[0];
  };
  requireThat(root.querySelector('[data-mode="overview"]'), 'not a rendered overview');
  const wantedOrder = ['control:close','overview:all',...cases.map(row => row[0])];
  const actualOrder = Array.from(root.querySelectorAll('[data-surface-control]'))
    .map(row => row.getAttribute('data-surface-control')).filter(id => wantedOrder.includes(id));
  requireThat(JSON.stringify(actualOrder) === JSON.stringify(wantedOrder), 'control order');
  const close = element('control:close');
  close.focus();
  requireThat(document.activeElement === close, 'close cannot receive DOM focus');
  for (const [id,label] of cases) {
    const button = element(id), visibleLabel = button.querySelector('.control-label');
    const style = getComputedStyle(button);
    requireThat(button.tagName === 'BUTTON' && button.getAttribute('role') === 'button', `${id}: element or role`);
    requireThat(visibleLabel && visibleLabel.textContent === label, `${id}: visible label`);
    requireThat(button.getAttribute('aria-label') === `${label}; unavailable`, `${id}: accessible label`);
    requireThat(button.disabled === true && button.getAttribute('aria-disabled') === 'true', `${id}: disabled semantics`);
    requireThat(button.getAttribute('data-focus-only') === 'false', `${id}: focus-only/tab order`);
    const detail = button.querySelector('.control-detail');
    requireThat(detail && detail.textContent === 'Not supported', `${id}: plain detail`);
    requireThat(style.display !== 'none' && style.visibility === 'visible' && button.getClientRects().length > 0, `${id}: not rendered`);
    button.focus();
    requireThat(document.activeElement === close, `${id}: disabled control took DOM focus`);
    button.click();
    button.dispatchEvent(new MouseEvent('click',{bubbles:true}));
    // Counterfactual: if the disabled property is lost, no event handler must exist either.
    button.disabled = false;
    button.dispatchEvent(new MouseEvent('click',{bubbles:true}));
    button.disabled = true;
  }
  await frame();
  requireThat(messages.length === 0, 'disabled controls emitted an action');
  app.ports.probe.send(null);
  await frame();
  requireThat(messages.length === 1 && JSON.stringify(messages[0]) === JSON.stringify({kind:'probe',snapshotChecks:true,sourceChecks:true,rowChecks:true,staleChecks:true}), 'snapshot/source refusal failed');
  requireThat(close.tagName === 'BUTTON' && !close.disabled && close.getAttribute('aria-disabled') === 'false', 'close is not enabled');
  requireThat(close.getAttribute('aria-label') === 'Close Task View and return to windows' && close.getAttribute('data-focus-only') === 'false', 'close accessible label or focus-only');
  close.click();
  await frame();
  const expected = {kind:'tap',action:{surface:'popup',surfaceProtocol:2,kind:'surface-action',publication:'1',lease:'1',id:'control:close'}};
  requireThat(messages.length === 2 && JSON.stringify(messages[1]) === JSON.stringify(expected), 'close action mismatch or duplicate');
  return {status:'passed',scope:'synthetic DOM only',disabledControls:3,closeActions:1,originalAccepted:false,nativeAccepted:false};
};
