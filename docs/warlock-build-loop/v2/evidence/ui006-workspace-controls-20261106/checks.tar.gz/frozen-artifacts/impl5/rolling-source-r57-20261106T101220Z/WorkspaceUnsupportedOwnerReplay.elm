port module WorkspaceUnsupportedOwnerReplay exposing (main)

{- Synthetic replay of the public owner route. It asserts data and effects,
   not host issuance, keyboard input, accessibility focus or native outcomes. -}
import Desktop
import DesktopPolicy as Policy
import Json.Decode as D
import Json.Encode as E
import OutputController as Outputs
import OutputRetirementReplay as Fixture
import Platform
import Shell
import Surface
import SurfaceController as Controller

port outgoing : E.Value -> Cmd msg

field name model = D.decodeValue (D.at ["frame",name] D.string) (Outputs.frame model) |> Result.withDefault "0"
scope id generation = E.object [("id",E.string id),("generation",E.string generation)]
action owner generation shown token id trigger = E.object
    [("viewProtocol",E.int 1),("kind",E.string "view-action"),("scope",scope owner generation)
    ,("action",E.object [("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("surface",E.string "popup"),("publication",E.string shown),("lease",E.string token),("id",E.string id),("trigger",E.string trigger)])]
bridge payload = E.object [("bridgeProtocol",E.int 1),("kind",E.string "view-action"),("payload",payload)]
escape owner generation shown token = E.object [("scope",scope owner generation),("publication",E.string shown),("lease",E.string token)]
mutations effects = effects |> List.filterMap (\effect -> case effect of
    Controller.DesktopEffect (Desktop.WindowEffect (Shell.Send wire)) -> D.decodeValue (D.field "kind" D.string) wire |> Result.toMaybe
    Controller.DesktopEffect (Desktop.Send wire) -> D.decodeValue (D.field "kind" D.string) wire |> Result.toMaybe
    _ -> Nothing) |> List.filter (\kind -> List.member kind ["window-effect","workspace-navigation","application-launch","taskbar-pins-write"])

result =
    let
        ready=Fixture.base [("1",Fixture.left)]
        (opened,openEffects)=Desktop.capture (Fixture.desktop ready) |> Maybe.map (\stamp -> Outputs.update (Outputs.Interaction (Desktop.OpenOverview stamp)) ready) |> Maybe.withDefault (ready,[])
        publication=field "publication" opened
        token=field "lease" opened
        rows=Surface.controls (Fixture.desktop opened) |> List.filter (\c -> List.member c.id ["overview:workspace-create","overview:workspace-delete","overview:workspace-rename"])
        summary=List.map (\c -> (c.id,c.ariaLabel,(c.detail,c.enabled,c.message==Nothing))) rows
        expected=[("overview:workspace-create","Create workspace; unavailable",("Not supported",False,True)),("overview:workspace-delete","Delete workspace; unavailable",("Not supported",False,True)),("overview:workspace-rename","Rename workspace; unavailable",("Not supported",False,True))]
        (create,createEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "overview:workspace-create" "keyboard")) opened
        (delete,deleteEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "overview:workspace-delete" "pointer")) create
        (rename,renameEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "overview:workspace-rename" "keyboard")) delete
        (foreign,foreignEffects)=Outputs.update (Outputs.Renderer (action "2" "1" publication token "overview:workspace-create" "keyboard")) rename
        (replacement,replacementEffects)=Outputs.update (Outputs.Renderer (action "1" "2" publication token "overview:workspace-create" "keyboard")) foreign
        (stale,staleEffects)=Outputs.update (Outputs.Renderer (action "1" "1" "0" token "overview:workspace-create" "keyboard")) replacement
        (foreignClose,foreignCloseEffects)=Outputs.update (Outputs.Renderer (action "2" "1" publication token "control:close" "keyboard")) stale
        (replacementClose,replacementCloseEffects)=Outputs.update (Outputs.Renderer (action "1" "2" publication token "control:close" "keyboard")) foreignClose
        (staleClose,staleCloseEffects)=Outputs.update (Outputs.Renderer (action "1" "1" "0" token "control:close" "keyboard")) replacementClose
        (validClose,validCloseEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "control:close" "keyboard")) staleClose
        (duplicateClose,duplicateCloseEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "control:close" "keyboard")) validClose
        policyGiven={controller=opened}
        (policyForeign,policyForeignEffects)=Policy.update (Policy.Incoming (bridge (action "2" "1" publication token "control:close" "keyboard"))) policyGiven
        (policyReplacement,policyReplacementEffects)=Policy.update (Policy.Incoming (bridge (action "1" "2" publication token "control:close" "keyboard"))) policyForeign
        (policyStale,policyStaleEffects)=Policy.update (Policy.Incoming (bridge (action "1" "1" "0" token "control:close" "keyboard"))) policyReplacement
        (closed,closeEffects)=Outputs.update (Outputs.Escape (escape "1" "1" publication token)) stale
        (duplicate,duplicateEffects)=Outputs.update (Outputs.Escape (escape "1" "1" publication token)) closed
        (empty,emptyEffects)=Outputs.update (Outputs.Topology (Fixture.topology "2" [])) opened
        (retiredAction,retiredEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "overview:workspace-create" "keyboard")) empty
        (returned,returnEffects)=Outputs.update (Outputs.Topology (Fixture.topology "3" [("2",Fixture.right)])) retiredAction
        (oldOwner,oldOwnerEffects)=Outputs.update (Outputs.Renderer (action "1" "1" publication token "overview:workspace-create" "keyboard")) returned
        (registeredEmpty,emptyCommand)=Outputs.register retiredEffects retiredAction
        checks=
            [ ("overviewOwnerAndLiteralUnsupportedControls",(Fixture.desktop opened).overview && Fixture.owner opened==Just "1" && summary==expected)
            , ("keyboardAndPointerUnsupportedCallbacksStutter",create==opened && delete==opened && rename==opened && List.isEmpty createEffects && List.isEmpty deleteEffects && List.isEmpty renameEffects)
            , ("foreignReplacementAndStaleCallbacksStutter",foreign==opened && replacement==opened && stale==opened && List.isEmpty foreignEffects && List.isEmpty replacementEffects && List.isEmpty staleEffects)
            , ("foreignEnabledCloseCannotDismiss",foreignClose==opened && List.isEmpty foreignCloseEffects)
            , ("replacementEnabledCloseCannotDismiss",replacementClose==opened && List.isEmpty replacementCloseEffects)
            , ("staleEnabledCloseCannotDismiss",staleClose==opened && List.isEmpty staleCloseEffects)
            , ("validEnabledCloseAfterRefusalsWorks",not (Fixture.desktop validClose).overview && List.isEmpty (mutations validCloseEffects))
            , ("duplicateEnabledCloseCannotReapply",duplicateClose==validClose && List.isEmpty duplicateCloseEffects)
            , ("policyRejectsInvalidScopesWithoutEffects",policyForeign==policyGiven && policyReplacement==policyGiven && policyStale==policyGiven && List.isEmpty policyForeignEffects && List.isEmpty policyReplacementEffects && List.isEmpty policyStaleEffects)
            , ("validEscapeAfterRefusalsClosesWithoutMutation",not (Fixture.desktop closed).overview && List.isEmpty (mutations (openEffects++closeEffects)))
            , ("zeroOutputRetiresUnsupportedOwner",Fixture.owner empty==Nothing && not (Fixture.desktop empty).overview && retiredAction==empty && List.isEmpty retiredEffects)
            , ("returnedOutputRejectsRetiredOwner",Fixture.owner returned==Just "2" && oldOwner==returned && List.isEmpty oldOwnerEffects)
            , ("noOpEffectsDoNotRegisterCommand",registeredEmpty==retiredAction && emptyCommand==Nothing)
            , ("topologyTransitionsDoNotMutateWorkspace",List.isEmpty (mutations (emptyEffects++returnEffects)))
            , ("duplicateEscapeIsInert",duplicate==closed && List.isEmpty duplicateEffects)
            ]
    in E.object [("requirement",E.string "ELM-UI-006"),("scenario",E.string "workspace-management-unavailable"),("scope",E.string "synthetic owner callbacks; local control and dismissal only"),("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]

main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\_ model -> (model,Cmd.none),subscriptions=\_ -> Sub.none}
