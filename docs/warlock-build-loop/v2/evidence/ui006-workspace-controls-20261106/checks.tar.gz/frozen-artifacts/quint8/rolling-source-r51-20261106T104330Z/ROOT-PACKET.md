# Root verification packet — ELM-UI-006

The independently reviewed Surface candidate has the same SHA-256 in impl7 r53 and impl5 r57. Its three plain unavailable labels match the recovered policy for undeclared operations. This is a source-only finding, not a compilation or acceptance result.

The r53 retired-owner check is not discriminating: it sends the disabled create action after zero-output dismissal. Add the named reopen/current-token/enabled-close comparison in named-expected-fixtures.json and retain all existing checks. Prove the controller can reopen on the returned output before treating the case as reachable. Independent review any new fixture; Root alone integrates and executes it.

The r57 browser fixture tests synthetic DOM and local port values. Preserve its literal role, label, order, disabled, forced-click and enabled-close assertions, but do not elevate scripted focus/click or surface packet counters to native focus, keyboard, pointer, AT, issuer or workspace evidence. Check the status-dependent aria-describedby risk recorded in candidate-review.json.

Keep prior check inventories, budgets and original RED. Root must establish full ordered effects and actual command observability, capacity boundaries, and the five original scenario gates through the actual native owner/receipt and observation paths. No new capability or authority is implied.
