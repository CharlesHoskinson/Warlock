# Root packet — standalone original 101 assembly

The r61 helper is byte-identical to the full helper produced by the approved staging-binding correction; the patch bytes match Root’s exact nonauthor review. Launcher, 101 consumer and command matrix are unchanged from r60. The projected request changes only the helper digest. Root and I8 reviewed the correction; this review checks its assembly and does not self-approve it.

The projected request expects the candidate launcher and helper plus the new fixed consumer; those remain unstaged in current Root. Root must review the combined DOM+101 closure and produce the corresponding exact request before protected execution. Keep all prior 24-case evidence and original 101 names. No compiler, tests, QA or model ran here, and native, AT/IME, physical, opaque Cmd, capacity and original five scenario gates remain open.
