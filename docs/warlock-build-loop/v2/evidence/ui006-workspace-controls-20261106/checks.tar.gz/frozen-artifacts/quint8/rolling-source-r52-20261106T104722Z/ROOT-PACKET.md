# Root packet — UI-006 peer r56

The 25-case successor adds six synthetic refusal combinations but lacks a valid pointer control. The private positive-control.patch adds enabled close after the existing refusals for each origin at the public resolver and owner controller while retaining the 25-name inventory. It is unreviewed and unexecuted.

The r53 protected GREEN profile hard-codes the older fixture, runner and 24 names. Root can preserve that separate narrow reviewed comparison, or separately review and bind one identical 25-case successor to both baseline RED and candidate GREEN. Never count a mismatched-profile failure as semantic RED. Preserve all existing budgets and source closure; Root alone runs protected tools.

This component check cannot establish native focus, keyboard, pointer, accessibility, receipt authority, complete opaque model or Cmd, capacity, or the original five outcomes. The stale-owner-after-output-return case remains a separate lifecycle gap.
