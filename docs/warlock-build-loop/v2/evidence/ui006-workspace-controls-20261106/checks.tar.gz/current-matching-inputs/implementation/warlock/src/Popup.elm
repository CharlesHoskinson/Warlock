port module Popup exposing (main, Model, Msg(..), Composition(..), Effect(..), Subscription(..), initial, subscriptionPlan, subscriptions, update, transition, view, pendingConfirmations, encodeConsumed)

import Browser
import Announcement
import Html exposing (div, p, text)
import Html.Attributes exposing (attribute)
import Json.Decode as D
import Json.Encode as E
import RetainedPreviewPresenter as Preview
import NativePreviewRealm as Realm
import NativePreviewProposalIngress as Ingress
import Presentation
import PreviewPaintGate
import SurfaceRenderer
import SurfaceTheme
import UInt64

port presentation : (D.Value -> msg) -> Sub msg
port announcements : (D.Value -> msg) -> Sub msg
port requestAction : (D.Value -> msg) -> Sub msg
port actions : E.Value -> Cmd msg

port nativePreviews : (D.Value -> msg) -> Sub msg
port previewCommands : E.Value -> Cmd msg
port previewConsumed : E.Value -> Cmd msg
port previewPaintRequests : E.Value -> Cmd msg
port previewPainted : (D.Value -> msg) -> Sub msg
port nativePreviewGrants : (D.Value -> msg) -> Sub msg
port nativePreviewQuarantine : (D.Value -> msg) -> Sub msg
port nativePreviewClosed : (D.Value -> msg) -> Sub msg
port nativePreviewIssued : (D.Value -> msg) -> Sub msg
port nativePreviewRetry : (D.Value -> msg) -> Sub msg
port nativePreviewRetirement : (D.Value -> msg) -> Sub msg

type Msg = Announce D.Value | Present D.Value | Action E.Value | LocalAction E.Value | NativePreview D.Value | PreviewPainted D.Value | NativeGrant D.Value | NativeQuarantine D.Value | NativeClosed D.Value | NativeIssued D.Value | NativeRetry D.Value | NativeRetirement D.Value | ConfirmationTransportCompleted Ingress.AcceptedTicket
type Composition = Idle | Preediting { baseline : String, before : Maybe String }

-- Pure effect descriptions are shared by the statically selected transports.
type Effect = Dispatch E.Value | PreviewCommand E.Value | PaintRequest E.Value | TicketConsumed Ingress.AcceptedTicket

type Subscription
    = PresentationChannel
    | AnnouncementsChannel
    | RequestActionChannel
    | NativePreviewsChannel
    | PreviewPaintedChannel
    | NativePreviewGrantsChannel
    | NativePreviewQuarantineChannel
    | NativePreviewClosedChannel
    | NativePreviewIssuedChannel
    | NativePreviewRetryChannel
    | NativePreviewRetirementChannel

type alias Model = { announcements : Announcement.Model, presentation : Presentation.Model, previews : Preview.Model, paintGate : PreviewPaintGate.Model, pendingQuery : Maybe String, composition : Composition, lastQuery : Maybe (String, UInt64.Counter, UInt64.Counter), confirmationOutbox : List Ingress.AcceptedTicket }

initial : Model
initial = {announcements=Announcement.initial,presentation=Presentation.initial,previews=Preview.initial,paintGate=PreviewPaintGate.initial,pendingQuery=Nothing,composition=Idle,lastQuery=Nothing,confirmationOutbox=[]}

pendingConfirmations : Model -> List Ingress.AcceptedTicket
pendingConfirmations model = model.confirmationOutbox

encodeConsumed : Ingress.AcceptedTicket -> E.Value
encodeConsumed = Ingress.encodeConsumed

isComposing : Model -> Bool
isComposing model = model.composition/=Idle

subscriptionPlan : Model -> List Subscription
subscriptionPlan model =
    let
        snapshot =
            Presentation.current model.presentation

        hasAcceptedSnapshot =
            snapshot /= Nothing

        visibleOverlayConsumer =
            snapshot |> Maybe.map (\shown -> SurfaceRenderer.mode shown /= "closed") |> Maybe.withDefault False

        visiblePreviewConsumer =
            snapshot |> Maybe.map (\shown -> SurfaceRenderer.mode shown == "picker") |> Maybe.withDefault False

        previewActive =
            visiblePreviewConsumer || Preview.hasRetainedControlOrTransactions model.previews

        paintPending =
            PreviewPaintGate.hasPending model.paintGate

        activeIngress =
            Preview.hasActiveIngress model.previews
    in
    [ Just PresentationChannel
    , if hasAcceptedSnapshot then Just AnnouncementsChannel else Nothing
    , if visibleOverlayConsumer then Just RequestActionChannel else Nothing
    , if previewActive then Just NativePreviewsChannel else Nothing
    , if paintPending then Just PreviewPaintedChannel else Nothing
    , Just NativePreviewGrantsChannel
    , Just NativePreviewQuarantineChannel
    , Just NativePreviewClosedChannel
    , if activeIngress then Just NativePreviewIssuedChannel else Nothing
    , if activeIngress then Just NativePreviewRetryChannel else Nothing
    , Just NativePreviewRetirementChannel
    ]
        |> List.filterMap identity

subscriptions : Model -> Sub Msg
subscriptions model =
    Sub.batch
        (List.map
            (\channel ->
                case channel of
                    PresentationChannel ->
                        presentation Present

                    AnnouncementsChannel ->
                        announcements Announce

                    RequestActionChannel ->
                        requestAction Action

                    NativePreviewsChannel ->
                        nativePreviews NativePreview

                    PreviewPaintedChannel ->
                        previewPainted PreviewPainted

                    NativePreviewGrantsChannel ->
                        nativePreviewGrants NativeGrant

                    NativePreviewQuarantineChannel ->
                        nativePreviewQuarantine NativeQuarantine

                    NativePreviewClosedChannel ->
                        nativePreviewClosed NativeClosed

                    NativePreviewIssuedChannel ->
                        nativePreviewIssued NativeIssued

                    NativePreviewRetryChannel ->
                        nativePreviewRetry NativeRetry

                    NativePreviewRetirementChannel ->
                        nativePreviewRetirement NativeRetirement
            )
            (subscriptionPlan model)
        )

main : Program () Model Msg
main = Browser.element
    { init=\_ -> (initial,Cmd.none)
    , subscriptions=subscriptions
    , view=view
    , update=update
    }

view : Model -> Html.Html Msg
view model =
    let overlay snapshot =
            snapshot
                |> (\current -> model.pendingQuery |> Maybe.map (\query -> SurfaceRenderer.honestPendingQuery query current) |> Maybe.withDefault current)
                |> (if isComposing model then SurfaceRenderer.composingPopup else identity)
    in case Presentation.current model.presentation of
        Just snapshot ->
            div [attribute "data-input-composing" (if isComposing model then "true" else "false")] [SurfaceRenderer.viewWithPreviewPending (\identity -> Preview.visual snapshot identity model.previews) (model.pendingQuery/=Nothing || isComposing model) True LocalAction (overlay snapshot),Announcement.view model.announcements]
        Nothing ->
            div ([attribute "data-input-composing" (if isComposing model then "true" else "false"),attribute "data-popup-state" "waiting"] ++ SurfaceTheme.preFramePopupStyles) [p ([attribute "role" "status",attribute "aria-live" "polite",attribute "aria-atomic" "true"] ++ SurfaceTheme.preFramePopupStatusStyles) [text "Waiting for desktop state…"]]

update : Msg -> Model -> (Model,Cmd Msg)
update message model =
    let (next,effects)=transition message model
        interpret effect = case effect of
            Dispatch value -> actions value
            PreviewCommand value -> previewCommands value
            PaintRequest value -> previewPaintRequests value
            TicketConsumed ticket -> previewConsumed (encodeConsumed ticket)
    in (next,Cmd.batch (List.map interpret effects))

transition : Msg -> Model -> (Model,List Effect)
transition message model =
    case message of
        PreviewPainted raw ->
            let (gate,commands)=PreviewPaintGate.painted raw model.paintGate
            in ({model | paintGate=gate},[PreviewCommand commands])
        LocalAction value ->
            let kind=D.decodeValue (D.field "kind" D.string) value |> Result.withDefault ""
            in if List.member kind ["surface-query","surface-preedit","surface-composition-start","surface-composition-end"] then
                Presentation.localEdit value model.presentation |> Maybe.map (\current -> transition (Action current) model) |> Maybe.withDefault (model,[])
            else transition (Action value) model
        Announce raw -> ({model | announcements=Announcement.receive True (Presentation.current model.presentation) raw model.announcements},[])
        Action value ->
            let kind=D.decodeValue (D.field "kind" D.string) value |> Result.withDefault ""
                sendQuery query wire current =
                    let key=Presentation.current current.presentation |> Maybe.map (\snapshot -> (query,SurfaceRenderer.publication snapshot,SurfaceRenderer.lease snapshot))
                        -- Matching the old label cannot settle a newer local edit
                        -- while an issued query can still enter that same scope.
                        -- A newer accepted publication makes older query scopes
                        -- stale at the sole controller; HTTP delivery does not.
                        unsettledHere = case (current.pendingQuery,current.lastQuery,Presentation.current current.presentation) of
                            (Nothing,_,_) -> False
                            (_,Nothing,_) -> False
                            (_,Just (_,shown,token),Just snapshot) -> SurfaceRenderer.lease snapshot/=token || UInt64.compare (SurfaceRenderer.publication snapshot) shown/=GT
                            _ -> True
                        unchanged=not unsettledHere && (Presentation.current current.presentation |> Maybe.andThen SurfaceRenderer.queryValue |> (==) (Just query))
                        duplicate=key/=Nothing && key==current.lastQuery
                    in ({current | pendingQuery=if unchanged then Nothing else Just query,lastQuery=key},if unchanged || duplicate then [] else [Dispatch wire])
                before = {baseline=model.pendingQuery |> Maybe.withDefault (Presentation.current model.presentation |> Maybe.andThen SurfaceRenderer.queryValue |> Maybe.withDefault ""),before=model.pendingQuery}
            in if List.member kind ["surface-query","surface-preedit","surface-composition-start","surface-composition-end"] then
                case Presentation.editQuery value model.presentation of
                    Just (query,wire) ->
                        if kind=="surface-composition-start" then
                            ({model | composition=Preediting {baseline=query,before=model.pendingQuery},pendingQuery=Just query},[])
                        else if kind=="surface-composition-end" then
                            case model.composition of
                                Idle -> (model,[])
                                Preediting held ->
                                    if query==held.baseline then
                                        case held.before of
                                            Nothing -> ({model | composition=Idle,pendingQuery=Nothing},[])
                                            Just prior ->
                                                -- The DOM baseline can differ from the retained
                                                -- intent. Rebuild its current scoped wire and
                                                -- reuse the ordinary settlement/dedupe rule.
                                                let restored = {model | composition=Idle,pendingQuery=Just prior}
                                                in Presentation.query prior restored.presentation
                                                    |> Maybe.map (\priorWire -> sendQuery prior priorWire restored)
                                                    |> Maybe.withDefault (restored,[])
                                    else sendQuery query wire {model | composition=Idle}
                        else if kind=="surface-preedit" || isComposing model then
                            ({model | composition=if isComposing model then model.composition else Preediting before,pendingQuery=Just query},[])
                        else sendQuery query wire model
                    Nothing -> (model,[])
            else if isComposing model || (model.pendingQuery/=Nothing && (D.decodeValue (D.field "id" D.string) value |> Result.map SurfaceRenderer.pendingQueryBlocked |> Result.withDefault False)) then (model,[])
            else (model,Presentation.dispatch True value model.presentation |> Maybe.map (Dispatch >> List.singleton) |> Maybe.withDefault [])
        Present raw ->
            let acceptedPresentation = Presentation.accept raw model.presentation
                (previews,commands) = Preview.present (Presentation.current acceptedPresentation) model.previews
                sameField = case (Presentation.current model.presentation,Presentation.current acceptedPresentation) of
                    (Just old,Just next) -> SurfaceRenderer.lease old==SurfaceRenderer.lease next && List.member (SurfaceRenderer.mode next) ["applications","files"] && SurfaceRenderer.mode old==SurfaceRenderer.mode next && SurfaceRenderer.enabled True (SurfaceRenderer.fieldIdentity next) next
                    _ -> False
                composition = if sameField then model.composition else Idle
                composing = composition/=Idle
                pending = if not sameField then Nothing else if composing then model.pendingQuery else model.pendingQuery |> Maybe.andThen (\query -> case Presentation.current acceptedPresentation of
                    Just snapshot -> if SurfaceRenderer.queryValue snapshot/=Just query then Just query else Nothing
                    Nothing -> Nothing)
                key = pending |> Maybe.andThen (\query -> Presentation.current acceptedPresentation |> Maybe.map (\snapshot -> (query,SurfaceRenderer.publication snapshot,SurfaceRenderer.lease snapshot)))
                queryCommand = if composing || key==model.lastQuery then [] else pending |> Maybe.andThen (\query -> Presentation.query query acceptedPresentation) |> Maybe.map (Dispatch >> List.singleton) |> Maybe.withDefault []
                lastQuery = if not sameField then Nothing else if composing || pending==Nothing then model.lastQuery else key
                (updatedPopup,previewEffects)=emitPreview commands {model | presentation=acceptedPresentation,previews=previews,pendingQuery=pending,composition=composition,lastQuery=lastQuery}
            in (updatedPopup,previewEffects++queryCommand)
        NativePreview raw ->
            let (previews,commands) =
                    case D.decodeValue Realm.envelopeDecoder raw of
                        Ok _ -> Preview.receiveRealm (Presentation.current model.presentation) raw model.previews
                        Err _ -> Preview.receive (Presentation.current model.presentation) raw model.previews
            in emitPreview commands {model | previews=previews}
        NativeRetirement raw ->
            let (previews,commands) = Preview.retireLegacy raw model.previews
            in emitPreview commands {model | previews=previews}
        NativeGrant raw ->
            let previews = D.decodeValue Realm.grantDecoder raw |> Result.toMaybe |> Maybe.andThen (\grant -> Preview.enrollRealm grant model.previews) |> Maybe.withDefault model.previews
            in ({model | previews=previews},[])
        NativeQuarantine raw ->
            let (previews,commands) = D.decodeValue Realm.domainDecoder raw |> Result.map (\domain -> Preview.quarantineRealm domain model.previews) |> Result.withDefault (model.previews,E.list identity [])
            in emitPreview commands {model | previews=previews}
        NativeIssued raw ->
            let (previews,accepted) = Preview.issuedWithConfirmation raw model.previews
            in case accepted of
                Just ticket ->
                    if List.length model.confirmationOutbox < 1065 then
                        ({model | previews=previews,confirmationOutbox=model.confirmationOutbox ++ [ticket]},[TicketConsumed ticket])
                    else (model,[])
                Nothing -> (model,[])
        ConfirmationTransportCompleted ticket ->
            let removeFirst remaining = case remaining of
                    [] -> []
                    first :: rest -> if Ingress.sameAcceptedTicket ticket first then rest else first :: removeFirst rest
            in ({model | confirmationOutbox=removeFirst model.confirmationOutbox},[])
        NativeRetry raw ->
            let (previews,commands) = D.decodeValue Realm.domainDecoder raw |> Result.map (\domain -> Preview.retry domain model.previews) |> Result.withDefault (model.previews,E.list identity [])
            in emitPreview commands {model | previews=previews}
        NativeClosed raw ->
            let previews = D.decodeValue Realm.domainDecoder raw |> Result.toMaybe |> Maybe.andThen (\domain -> Preview.closeRealm domain model.previews) |> Maybe.withDefault model.previews
            in ({model | previews=previews},[])

emitPreview : E.Value -> Model -> (Model,List Effect)
emitPreview commands model =
    let (gate,immediate,requests)=PreviewPaintGate.queue commands model.paintGate
    in ({model | paintGate=gate},[PreviewCommand immediate,PaintRequest requests])
