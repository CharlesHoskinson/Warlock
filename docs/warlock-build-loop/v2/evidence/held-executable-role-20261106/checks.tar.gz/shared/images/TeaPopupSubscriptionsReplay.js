(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}

console.warn('Compiled in DEV mode. Follow the advice at https://elm-lang.org/0.19.2/optimize for better performance and smaller assets.');


var _List_Nil_UNUSED = { $: 0 };
var _List_Nil = { $: '[]' };

function _List_Cons_UNUSED(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log_UNUSED = F2(function(tag, value)
{
	return value;
});

var _Debug_log = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString_UNUSED(value)
{
	return '<internals>';
}

function _Debug_toString(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash_UNUSED(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.start.line === region.end.line)
	{
		return 'on line ' + region.start.line;
	}
	return 'on lines ' + region.start.line + ' through ' + region.end.line;
}



// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**_UNUSED/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**_UNUSED/
	if (typeof x.$ === 'undefined')
	//*/
	/**/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0_UNUSED = 0;
var _Utils_Tuple0 = { $: '#0' };

function _Utils_Tuple2_UNUSED(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3_UNUSED(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr_UNUSED(c) { return c; }
function _Utils_chr(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap(value) { return { $: 0, a: value }; }
function _Json_unwrap(value) { return value.a; }

function _Json_wrap_UNUSED(value) { return value; }
function _Json_unwrap_UNUSED(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}



var _Bitwise_and = F2(function(a, b)
{
	return a & b;
});

var _Bitwise_or = F2(function(a, b)
{
	return a | b;
});

var _Bitwise_xor = F2(function(a, b)
{
	return a ^ b;
});

function _Bitwise_complement(a)
{
	return ~a;
};

var _Bitwise_shiftLeftBy = F2(function(offset, a)
{
	return a << offset;
});

var _Bitwise_shiftRightBy = F2(function(offset, a)
{
	return a >> offset;
});

var _Bitwise_shiftRightZfBy = F2(function(offset, a)
{
	return a >>> offset;
});
var $elm$core$Basics$EQ = {$: 'EQ'};
var $elm$core$Basics$LT = {$: 'LT'};
var $elm$core$List$cons = _List_cons;
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (node.$ === 'SubTree') {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === 'RBEmpty_elm_builtin') {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0.a;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Basics$GT = {$: 'GT'};
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $author$project$TeaPopupSubscriptionsReplay$Input = function (a) {
	return {$: 'Input', a: a};
};
var $elm$core$Result$Err = function (a) {
	return {$: 'Err', a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 'Failure', a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 'Field', a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 'Index', a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 'Ok', a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 'OneOf', a: a};
};
var $elm$core$Basics$False = {$: 'False'};
var $elm$core$Basics$add = _Basics_add;
var $elm$core$Maybe$Just = function (a) {
	return {$: 'Just', a: a};
};
var $elm$core$Maybe$Nothing = {$: 'Nothing'};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$core$Basics$append = _Utils_append;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\u000A    ',
		A2($elm$core$String$split, '\u000A', str));
};
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\u000A\u000A(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 'Field':
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 'Nothing') {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\u0027' + (f + '\u0027]'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'Index':
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'OneOf':
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\u000A\u000A',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\u000A\u000A';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\u000A\u000A    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\u000A\u000A' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 'Array_elm_builtin', a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 'Leaf', a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$eq = _Utils_equal;
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 'SubTree', a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.nodeListSize) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.tail);
		} else {
			var treeLen = builder.nodeListSize * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.nodeList) : builder.nodeList;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.nodeListSize);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.tail);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{nodeList: nodeList, nodeListSize: (len / $elm$core$Array$branchFactor) | 0, tail: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Basics$True = {$: 'True'};
var $elm$core$Result$isOk = function (result) {
	if (result.$ === 'Ok') {
		return true;
	} else {
		return false;
	}
};
var $elm$json$Json$Decode$value = _Json_decodeValue;
var $author$project$TeaPopupSubscriptionsReplay$incoming = _Platform_incomingPort('incoming', $elm$json$Json$Decode$value);
var $author$project$Popup$Idle = {$: 'Idle'};
var $author$project$Announcement$Model = function (a) {
	return {$: 'Model', a: a};
};
var $author$project$UInt64$Counter = function (a) {
	return {$: 'Counter', a: a};
};
var $author$project$UInt64$zero = $author$project$UInt64$Counter('0');
var $author$project$Announcement$initial = $author$project$Announcement$Model(
	{active: false, last: $author$project$UInt64$zero, message: $elm$core$Maybe$Nothing});
var $author$project$Presentation$Model = function (a) {
	return {$: 'Model', a: a};
};
var $author$project$Presentation$initial = $author$project$Presentation$Model(
	{last: $author$project$UInt64$zero, lease: $author$project$UInt64$zero, snapshot: $elm$core$Maybe$Nothing});
var $author$project$PreviewPaintGate$Model = F2(
	function (a, b) {
		return {$: 'Model', a: a, b: b};
	});
var $elm$core$Dict$RBEmpty_elm_builtin = {$: 'RBEmpty_elm_builtin'};
var $elm$core$Dict$empty = $elm$core$Dict$RBEmpty_elm_builtin;
var $author$project$PreviewPaintGate$initial = A2($author$project$PreviewPaintGate$Model, $author$project$UInt64$zero, $elm$core$Dict$empty);
var $author$project$RetainedPreviewPresenter$Model = F4(
	function (a, b, c, d) {
		return {$: 'Model', a: a, b: b, c: c, d: d};
	});
var $author$project$PreviewPresenter$Model = F4(
	function (a, b, c, d) {
		return {$: 'Model', a: a, b: b, c: c, d: d};
	});
var $author$project$NativeActorRetirement$empty = {channel: $elm$core$Maybe$Nothing, observed: $elm$core$Maybe$Nothing, processed: $author$project$UInt64$zero, settled: $elm$core$Maybe$Nothing};
var $author$project$PreviewPresenter$emptyScoped = {closed: false, closing: false, completed: $elm$core$Dict$empty, grant: $elm$core$Maybe$Nothing, processed: $author$project$UInt64$zero};
var $author$project$PreviewPresenter$initial = A4($author$project$PreviewPresenter$Model, $elm$core$Dict$empty, $elm$core$Maybe$Nothing, $author$project$NativeActorRetirement$empty, $author$project$PreviewPresenter$emptyScoped);
var $author$project$RetainedPreviewPresenter$initial = A4($author$project$RetainedPreviewPresenter$Model, $author$project$PreviewPresenter$initial, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing, _List_Nil);
var $author$project$Popup$initial = {announcements: $author$project$Announcement$initial, composition: $author$project$Popup$Idle, confirmationOutbox: _List_Nil, lastQuery: $elm$core$Maybe$Nothing, paintGate: $author$project$PreviewPaintGate$initial, pendingQuery: $elm$core$Maybe$Nothing, presentation: $author$project$Presentation$initial, previews: $author$project$RetainedPreviewPresenter$initial};
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $author$project$Popup$Action = function (a) {
	return {$: 'Action', a: a};
};
var $author$project$Popup$Announce = function (a) {
	return {$: 'Announce', a: a};
};
var $author$project$Popup$LocalAction = function (a) {
	return {$: 'LocalAction', a: a};
};
var $author$project$Popup$NativeClosed = function (a) {
	return {$: 'NativeClosed', a: a};
};
var $author$project$Popup$NativeGrant = function (a) {
	return {$: 'NativeGrant', a: a};
};
var $author$project$Popup$NativeIssued = function (a) {
	return {$: 'NativeIssued', a: a};
};
var $author$project$Popup$NativePreview = function (a) {
	return {$: 'NativePreview', a: a};
};
var $author$project$Popup$NativeQuarantine = function (a) {
	return {$: 'NativeQuarantine', a: a};
};
var $author$project$Popup$NativeRetirement = function (a) {
	return {$: 'NativeRetirement', a: a};
};
var $author$project$Popup$NativeRetry = function (a) {
	return {$: 'NativeRetry', a: a};
};
var $author$project$Popup$Present = function (a) {
	return {$: 'Present', a: a};
};
var $author$project$Popup$PreviewPainted = function (a) {
	return {$: 'PreviewPainted', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$ResetEffects = {$: 'ResetEffects'};
var $elm$json$Json$Encode$bool = _Json_wrap;
var $elm$json$Json$Encode$int = _Json_wrap;
var $elm$json$Json$Encode$object = function (pairs) {
	return _Json_wrap(
		A3(
			$elm$core$List$foldl,
			F2(
				function (_v0, obj) {
					var k = _v0.a;
					var v = _v0.b;
					return A3(_Json_addField, k, v, obj);
				}),
			_Json_emptyObject(_Utils_Tuple0),
			pairs));
};
var $author$project$TeaPopupSubscriptionsReplay$outgoing = _Platform_outgoingPort('outgoing', $elm$core$Basics$identity);
var $elm$json$Json$Encode$string = _Json_wrap;
var $author$project$TeaPopupSubscriptionsReplay$ack = F4(
	function (caseId, step, ok, reason) {
		return $author$project$TeaPopupSubscriptionsReplay$outgoing(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'caseId',
						$elm$json$Json$Encode$string(caseId)),
						_Utils_Tuple2(
						'step',
						$elm$json$Json$Encode$int(step)),
						_Utils_Tuple2(
						'ok',
						$elm$json$Json$Encode$bool(ok)),
						_Utils_Tuple2(
						'error',
						$elm$json$Json$Encode$string(reason))
					])));
	});
var $author$project$TeaPopupSubscriptionsReplay$PopupEffects = function (a) {
	return {$: 'PopupEffects', a: a};
};
var $elm$core$Debug$log = _Debug_log;
var $author$project$Popup$AnnouncementsChannel = {$: 'AnnouncementsChannel'};
var $author$project$Popup$NativePreviewClosedChannel = {$: 'NativePreviewClosedChannel'};
var $author$project$Popup$NativePreviewGrantsChannel = {$: 'NativePreviewGrantsChannel'};
var $author$project$Popup$NativePreviewIssuedChannel = {$: 'NativePreviewIssuedChannel'};
var $author$project$Popup$NativePreviewQuarantineChannel = {$: 'NativePreviewQuarantineChannel'};
var $author$project$Popup$NativePreviewRetirementChannel = {$: 'NativePreviewRetirementChannel'};
var $author$project$Popup$NativePreviewRetryChannel = {$: 'NativePreviewRetryChannel'};
var $author$project$Popup$NativePreviewsChannel = {$: 'NativePreviewsChannel'};
var $author$project$Popup$PresentationChannel = {$: 'PresentationChannel'};
var $author$project$Popup$PreviewPaintedChannel = {$: 'PreviewPaintedChannel'};
var $author$project$Popup$RequestActionChannel = {$: 'RequestActionChannel'};
var $author$project$Presentation$current = function (_v0) {
	var model = _v0.a;
	return model.snapshot;
};
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$maybeCons = F3(
	function (f, mx, xs) {
		var _v0 = f(mx);
		if (_v0.$ === 'Just') {
			var x = _v0.a;
			return A2($elm$core$List$cons, x, xs);
		} else {
			return xs;
		}
	});
var $elm$core$List$filterMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			$elm$core$List$maybeCons(f),
			_List_Nil,
			xs);
	});
var $elm$core$Basics$composeR = F3(
	function (f, g, x) {
		return g(
			f(x));
	});
var $elm$core$List$isEmpty = function (xs) {
	if (!xs.b) {
		return true;
	} else {
		return false;
	}
};
var $elm$core$Maybe$map = F2(
	function (f, maybe) {
		if (maybe.$ === 'Just') {
			var value = maybe.a;
			return $elm$core$Maybe$Just(
				f(value));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$core$Basics$not = _Basics_not;
var $author$project$NativePreviewProposalIngress$pending = function (_v0) {
	var rows = _v0.b;
	return rows;
};
var $elm$core$Maybe$withDefault = F2(
	function (_default, maybe) {
		if (maybe.$ === 'Just') {
			var value = maybe.a;
			return value;
		} else {
			return _default;
		}
	});
var $author$project$RetainedPreviewPresenter$hasActiveIngress = function (_v0) {
	var ingress = _v0.c;
	var deferred = _v0.d;
	return (!$elm$core$List$isEmpty(deferred)) || A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				$author$project$NativePreviewProposalIngress$pending,
				A2($elm$core$Basics$composeR, $elm$core$List$isEmpty, $elm$core$Basics$not)),
			ingress));
};
var $elm$core$Dict$isEmpty = function (dict) {
	if (dict.$ === 'RBEmpty_elm_builtin') {
		return true;
	} else {
		return false;
	}
};
var $author$project$PreviewPaintGate$hasPending = function (_v0) {
	var pending = _v0.b;
	return !$elm$core$Dict$isEmpty(pending);
};
var $elm$core$Basics$neq = _Utils_notEqual;
var $author$project$PreviewPresenter$hasRetainedControlOrTransactions = function (_v0) {
	var entries = _v0.a;
	var catalog = _v0.b;
	var ledger = _v0.c;
	var scoped = _v0.d;
	return (!$elm$core$Dict$isEmpty(entries)) || ((!_Utils_eq(catalog, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(ledger, $author$project$NativeActorRetirement$empty)) || (((!_Utils_eq(scoped.grant, $elm$core$Maybe$Nothing)) && (!scoped.closed)) || (!$elm$core$Dict$isEmpty(scoped.completed)))));
};
var $author$project$RetainedPreviewPresenter$hasRetainedControlOrTransactions = function (model) {
	var policy = model.a;
	return $author$project$PreviewPresenter$hasRetainedControlOrTransactions(policy) || $author$project$RetainedPreviewPresenter$hasActiveIngress(model);
};
var $author$project$SurfaceSnapshot$mode = function (_v0) {
	var snapshot = _v0.a;
	return snapshot.mode;
};
var $author$project$SurfaceRenderer$mode = $author$project$SurfaceSnapshot$mode;
var $author$project$Popup$subscriptionPlan = function (model) {
	var snapshot = $author$project$Presentation$current(model.presentation);
	var visibleOverlayConsumer = A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (shown) {
				return $author$project$SurfaceRenderer$mode(shown) !== 'closed';
			},
			snapshot));
	var visiblePreviewConsumer = A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (shown) {
				return $author$project$SurfaceRenderer$mode(shown) === 'picker';
			},
			snapshot));
	var previewActive = visiblePreviewConsumer || $author$project$RetainedPreviewPresenter$hasRetainedControlOrTransactions(model.previews);
	var paintPending = $author$project$PreviewPaintGate$hasPending(model.paintGate);
	var hasAcceptedSnapshot = !_Utils_eq(snapshot, $elm$core$Maybe$Nothing);
	var activeIngress = $author$project$RetainedPreviewPresenter$hasActiveIngress(model.previews);
	return A2(
		$elm$core$List$filterMap,
		$elm$core$Basics$identity,
		_List_fromArray(
			[
				$elm$core$Maybe$Just($author$project$Popup$PresentationChannel),
				hasAcceptedSnapshot ? $elm$core$Maybe$Just($author$project$Popup$AnnouncementsChannel) : $elm$core$Maybe$Nothing,
				visibleOverlayConsumer ? $elm$core$Maybe$Just($author$project$Popup$RequestActionChannel) : $elm$core$Maybe$Nothing,
				previewActive ? $elm$core$Maybe$Just($author$project$Popup$NativePreviewsChannel) : $elm$core$Maybe$Nothing,
				paintPending ? $elm$core$Maybe$Just($author$project$Popup$PreviewPaintedChannel) : $elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just($author$project$Popup$NativePreviewGrantsChannel),
				$elm$core$Maybe$Just($author$project$Popup$NativePreviewQuarantineChannel),
				$elm$core$Maybe$Just($author$project$Popup$NativePreviewClosedChannel),
				activeIngress ? $elm$core$Maybe$Just($author$project$Popup$NativePreviewIssuedChannel) : $elm$core$Maybe$Nothing,
				activeIngress ? $elm$core$Maybe$Just($author$project$Popup$NativePreviewRetryChannel) : $elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just($author$project$Popup$NativePreviewRetirementChannel)
			]));
};
var $author$project$TeaPopupSubscriptionsReplay$observe = F3(
	function (request, model, effects) {
		var observed = {
			model: model,
			subscriptions: $author$project$Popup$subscriptionPlan(model)
		};
		var _v0 = A2(
			$elm$core$Debug$log,
			'TEA_SUBSCRIPTIONS_OBSERVE_V1',
			_Utils_Tuple2(observed, effects));
		var capturedState = _v0.a;
		return _Utils_Tuple2(
			capturedState.model,
			A4($author$project$TeaPopupSubscriptionsReplay$ack, request.caseId, request.step, true, ''));
	});
var $author$project$Popup$Dispatch = function (a) {
	return {$: 'Dispatch', a: a};
};
var $author$project$Popup$Preediting = function (a) {
	return {$: 'Preediting', a: a};
};
var $author$project$Popup$PreviewCommand = function (a) {
	return {$: 'PreviewCommand', a: a};
};
var $author$project$Popup$TicketConsumed = function (a) {
	return {$: 'TicketConsumed', a: a};
};
var $elm$core$Basics$compare = _Utils_compare;
var $elm$core$String$length = _String_length;
var $author$project$UInt64$compare = F2(
	function (_v0, _v1) {
		var left = _v0.a;
		var right = _v1.a;
		var _v2 = A2(
			$elm$core$Basics$compare,
			$elm$core$String$length(left),
			$elm$core$String$length(right));
		if (_v2.$ === 'EQ') {
			return A2($elm$core$Basics$compare, left, right);
		} else {
			var order = _v2;
			return order;
		}
	});
var $author$project$SurfaceSnapshot$Snapshot = function (a) {
	return {$: 'Snapshot', a: a};
};
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$core$Result$andThen = F2(
	function (callback, result) {
		if (result.$ === 'Ok') {
			var value = result.a;
			return callback(value);
		} else {
			var msg = result.a;
			return $elm$core$Result$Err(msg);
		}
	});
var $elm$core$List$any = F2(
	function (isOkay, list) {
		any:
		while (true) {
			if (!list.b) {
				return false;
			} else {
				var x = list.a;
				var xs = list.b;
				if (isOkay(x)) {
					return true;
				} else {
					var $temp$isOkay = isOkay,
						$temp$list = xs;
					isOkay = $temp$isOkay;
					list = $temp$list;
					continue any;
				}
			}
		}
	});
var $elm$json$Json$Decode$bool = _Json_decodeBool;
var $elm$core$String$any = _String_any;
var $elm$json$Json$Decode$fail = _Json_fail;
var $elm$json$Json$Decode$string = _Json_decodeString;
var $author$project$SurfaceSnapshot$bounded = function (limit) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return ((_Utils_cmp(
				$elm$core$String$length(value),
				limit) < 1) && (!A2(
				$elm$core$String$any,
				function (c) {
					return $elm$core$Char$toCode(c) < 32;
				},
				value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Presentation text');
		},
		$elm$json$Json$Decode$string);
};
var $elm$json$Json$Decode$field = _Json_decodeField;
var $elm$json$Json$Decode$keyValuePairs = _Json_decodeKeyValuePairs;
var $elm$json$Json$Decode$list = _Json_decodeList;
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$json$Json$Decode$map3 = _Json_map3;
var $elm$json$Json$Decode$map6 = _Json_map6;
var $elm$core$List$member = F2(
	function (x, xs) {
		return A2(
			$elm$core$List$any,
			function (a) {
				return _Utils_eq(a, x);
			},
			xs);
	});
var $elm$core$List$sortBy = _List_sortBy;
var $elm$core$List$sort = function (xs) {
	return A2($elm$core$List$sortBy, $elm$core$Basics$identity, xs);
};
var $author$project$SurfaceSnapshot$strict = F2(
	function (names, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (fields) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
					$elm$core$List$sort(names)) ? decoder : $elm$json$Json$Decode$fail('Presentation fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$SurfaceSnapshot$controls = function (maximum) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (values) {
			return (_Utils_cmp(
				$elm$core$List$length(values),
				maximum) > 0) ? $elm$json$Json$Decode$fail('Presentation capacity') : $elm$json$Json$Decode$list(
				A2(
					$elm$json$Json$Decode$andThen,
					function (pairs) {
						var hasChecked = A2(
							$elm$core$List$member,
							'checked',
							A2($elm$core$List$map, $elm$core$Tuple$first, pairs));
						var extended = A2(
							$elm$core$List$member,
							'focusOnly',
							A2($elm$core$List$map, $elm$core$Tuple$first, pairs));
						var base = A7(
							$elm$json$Json$Decode$map6,
							F6(
								function (identity, domId, label, ariaLabel, detail, available) {
									return {ariaLabel: ariaLabel, checked: $elm$core$Maybe$Nothing, detail: detail, domId: domId, enabled: available, focusOnly: false, identity: identity, label: label};
								}),
							A2(
								$elm$json$Json$Decode$field,
								'id',
								$author$project$SurfaceSnapshot$bounded(512)),
							A2(
								$elm$json$Json$Decode$field,
								'domId',
								$author$project$SurfaceSnapshot$bounded(1024)),
							A2(
								$elm$json$Json$Decode$field,
								'label',
								$author$project$SurfaceSnapshot$bounded(1024)),
							A2(
								$elm$json$Json$Decode$field,
								'ariaLabel',
								$author$project$SurfaceSnapshot$bounded(1024)),
							A2(
								$elm$json$Json$Decode$field,
								'detail',
								$author$project$SurfaceSnapshot$bounded(128)),
							A2($elm$json$Json$Decode$field, 'enabled', $elm$json$Json$Decode$bool));
						return (hasChecked && (!extended)) ? $elm$json$Json$Decode$fail('Checked presentation requires current control shape') : A2(
							$author$project$SurfaceSnapshot$strict,
							_Utils_ap(
								_List_fromArray(
									['id', 'domId', 'label', 'ariaLabel', 'detail', 'enabled']),
								_Utils_ap(
									extended ? _List_fromArray(
										['focusOnly']) : _List_Nil,
									hasChecked ? _List_fromArray(
										['checked']) : _List_Nil)),
							A4(
								$elm$json$Json$Decode$map3,
								F3(
									function (row, focusOnly, checked) {
										return _Utils_update(
											row,
											{checked: checked, focusOnly: focusOnly});
									}),
								base,
								extended ? A2($elm$json$Json$Decode$field, 'focusOnly', $elm$json$Json$Decode$bool) : $elm$json$Json$Decode$succeed(false),
								hasChecked ? A2(
									$elm$json$Json$Decode$field,
									'checked',
									A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, $elm$json$Json$Decode$bool)) : $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing)));
					},
					$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value)));
		},
		$elm$json$Json$Decode$list($elm$json$Json$Decode$value));
};
var $elm$json$Json$Decode$decodeValue = _Json_run;
var $elm$core$Basics$ge = _Utils_ge;
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $elm$core$String$startsWith = _String_startsWith;
var $author$project$UInt64$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return ((!$elm$core$String$isEmpty(value)) && (A2(
			$elm$core$String$all,
			function (c) {
				return (_Utils_cmp(
					c,
					_Utils_chr('0')) > -1) && (_Utils_cmp(
					c,
					_Utils_chr('9')) < 1);
			},
			value) && (((value === '0') || (!A2($elm$core$String$startsWith, '0', value))) && (($elm$core$String$length(value) <= 20) && (($elm$core$String$length(value) < 20) || (value <= '18446744073709551615')))))) ? $elm$json$Json$Decode$succeed(
			$author$project$UInt64$Counter(value)) : $elm$json$Json$Decode$fail('Expected canonical uint64 string');
	},
	$elm$json$Json$Decode$string);
var $author$project$Settings$Night = {$: 'Night'};
var $author$project$Settings$defaults = {effectsOff: false, reducedTransparency: false, textScale: 100, theme: $author$project$Settings$Night};
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $elm$core$Set$Set_elm_builtin = function (a) {
	return {$: 'Set_elm_builtin', a: a};
};
var $elm$core$Set$empty = $elm$core$Set$Set_elm_builtin($elm$core$Dict$empty);
var $elm$core$Dict$Black = {$: 'Black'};
var $elm$core$Dict$RBNode_elm_builtin = F5(
	function (a, b, c, d, e) {
		return {$: 'RBNode_elm_builtin', a: a, b: b, c: c, d: d, e: e};
	});
var $elm$core$Dict$Red = {$: 'Red'};
var $elm$core$Dict$balance = F5(
	function (color, key, value, left, right) {
		if ((right.$ === 'RBNode_elm_builtin') && (right.a.$ === 'Red')) {
			var _v1 = right.a;
			var rK = right.b;
			var rV = right.c;
			var rLeft = right.d;
			var rRight = right.e;
			if ((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Red')) {
				var _v3 = left.a;
				var lK = left.b;
				var lV = left.c;
				var lLeft = left.d;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Red,
					key,
					value,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					rK,
					rV,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, key, value, left, rLeft),
					rRight);
			}
		} else {
			if ((((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Red')) && (left.d.$ === 'RBNode_elm_builtin')) && (left.d.a.$ === 'Red')) {
				var _v5 = left.a;
				var lK = left.b;
				var lV = left.c;
				var _v6 = left.d;
				var _v7 = _v6.a;
				var llK = _v6.b;
				var llV = _v6.c;
				var llLeft = _v6.d;
				var llRight = _v6.e;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Red,
					lK,
					lV,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, llK, llV, llLeft, llRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, key, value, lRight, right));
			} else {
				return A5($elm$core$Dict$RBNode_elm_builtin, color, key, value, left, right);
			}
		}
	});
var $elm$core$Dict$insertHelp = F3(
	function (key, value, dict) {
		if (dict.$ === 'RBEmpty_elm_builtin') {
			return A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, key, value, $elm$core$Dict$RBEmpty_elm_builtin, $elm$core$Dict$RBEmpty_elm_builtin);
		} else {
			var nColor = dict.a;
			var nKey = dict.b;
			var nValue = dict.c;
			var nLeft = dict.d;
			var nRight = dict.e;
			var _v1 = A2($elm$core$Basics$compare, key, nKey);
			switch (_v1.$) {
				case 'LT':
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						A3($elm$core$Dict$insertHelp, key, value, nLeft),
						nRight);
				case 'EQ':
					return A5($elm$core$Dict$RBNode_elm_builtin, nColor, nKey, value, nLeft, nRight);
				default:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						nLeft,
						A3($elm$core$Dict$insertHelp, key, value, nRight));
			}
		}
	});
var $elm$core$Dict$insert = F3(
	function (key, value, dict) {
		var _v0 = A3($elm$core$Dict$insertHelp, key, value, dict);
		if ((_v0.$ === 'RBNode_elm_builtin') && (_v0.a.$ === 'Red')) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Set$insert = F2(
	function (key, _v0) {
		var dict = _v0.a;
		return $elm$core$Set$Set_elm_builtin(
			A3($elm$core$Dict$insert, key, _Utils_Tuple0, dict));
	});
var $elm$core$Set$fromList = function (list) {
	return A3($elm$core$List$foldl, $elm$core$Set$insert, $elm$core$Set$empty, list);
};
var $elm$json$Json$Decode$int = _Json_decodeInt;
var $elm$json$Json$Decode$map8 = _Json_map8;
var $elm$core$Result$mapError = F2(
	function (f, result) {
		if (result.$ === 'Ok') {
			var v = result.a;
			return $elm$core$Result$Ok(v);
		} else {
			var e = result.a;
			return $elm$core$Result$Err(
				f(e));
		}
	});
var $elm$core$Dict$sizeHelp = F2(
	function (n, dict) {
		sizeHelp:
		while (true) {
			if (dict.$ === 'RBEmpty_elm_builtin') {
				return n;
			} else {
				var left = dict.d;
				var right = dict.e;
				var $temp$n = A2($elm$core$Dict$sizeHelp, n + 1, right),
					$temp$dict = left;
				n = $temp$n;
				dict = $temp$dict;
				continue sizeHelp;
			}
		}
	});
var $elm$core$Dict$size = function (dict) {
	return A2($elm$core$Dict$sizeHelp, 0, dict);
};
var $elm$core$Set$size = function (_v0) {
	var dict = _v0.a;
	return $elm$core$Dict$size(dict);
};
var $elm$core$Result$toMaybe = function (result) {
	if (result.$ === 'Ok') {
		var v = result.a;
		return $elm$core$Maybe$Just(v);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Settings$Values = F4(
	function (theme, textScale, effectsOff, reducedTransparency) {
		return {effectsOff: effectsOff, reducedTransparency: reducedTransparency, textScale: textScale, theme: theme};
	});
var $elm$json$Json$Decode$map4 = _Json_map4;
var $author$project$Settings$scaleDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (scale) {
		return A2(
			$elm$core$List$member,
			scale,
			_List_fromArray(
				[100, 125, 150, 200])) ? $elm$json$Json$Decode$succeed(scale) : $elm$json$Json$Decode$fail('Text scale unavailable');
	},
	$elm$json$Json$Decode$int);
var $author$project$Settings$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Settings fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Settings$Dawn = {$: 'Dawn'};
var $author$project$Settings$HighContrast = {$: 'HighContrast'};
var $author$project$Settings$themeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'night':
				return $elm$json$Json$Decode$succeed($author$project$Settings$Night);
			case 'dawn':
				return $elm$json$Json$Decode$succeed($author$project$Settings$Dawn);
			case 'high-contrast':
				return $elm$json$Json$Decode$succeed($author$project$Settings$HighContrast);
			default:
				return $elm$json$Json$Decode$fail('Theme unavailable');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Settings$currentValues = A2(
	$author$project$Settings$strict,
	_List_fromArray(
		['theme', 'textScale', 'effectsOff', 'reducedTransparency']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$Settings$Values,
		A2($elm$json$Json$Decode$field, 'theme', $author$project$Settings$themeDecoder),
		A2($elm$json$Json$Decode$field, 'textScale', $author$project$Settings$scaleDecoder),
		A2($elm$json$Json$Decode$field, 'effectsOff', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'reducedTransparency', $elm$json$Json$Decode$bool)));
var $elm$json$Json$Decode$map2 = _Json_map2;
var $author$project$Settings$legacyValues = A2(
	$author$project$Settings$strict,
	_List_fromArray(
		['theme', 'textScale']),
	A3(
		$elm$json$Json$Decode$map2,
		F2(
			function (theme, scale) {
				return {effectsOff: false, reducedTransparency: false, textScale: scale, theme: theme};
			}),
		A2($elm$json$Json$Decode$field, 'theme', $author$project$Settings$themeDecoder),
		A2($elm$json$Json$Decode$field, 'textScale', $author$project$Settings$scaleDecoder)));
var $elm$json$Json$Decode$oneOf = _Json_oneOf;
var $author$project$Settings$valuesDecoder = $elm$json$Json$Decode$oneOf(
	_List_fromArray(
		[$author$project$Settings$currentValues, $author$project$Settings$legacyValues]));
var $author$project$SurfaceSnapshot$decode = function (raw) {
	var legacy = _Utils_eq(
		$elm$core$Maybe$Nothing,
		$elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'appearance', $elm$json$Json$Decode$value),
				raw)));
	var hasParent = !_Utils_eq(
		$elm$core$Maybe$Nothing,
		$elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'keyboardParent', $elm$json$Json$Decode$value),
				raw)));
	var parentDecoder = hasParent ? A2(
		$elm$json$Json$Decode$field,
		'keyboardParent',
		A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, $elm$json$Json$Decode$bool)) : $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing);
	var hasMotion = !_Utils_eq(
		$elm$core$Maybe$Nothing,
		$elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'motion', $elm$json$Json$Decode$value),
				raw)));
	var motionDecoder = hasMotion ? A2(
		$elm$json$Json$Decode$field,
		'motion',
		A2(
			$elm$json$Json$Decode$andThen,
			function (v) {
				return A2(
					$elm$core$List$member,
					v,
					_List_fromArray(
						['reduced', 'full'])) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Motion profile');
			},
			$elm$json$Json$Decode$string)) : $elm$json$Json$Decode$succeed('reduced');
	var decoder = A2(
		$author$project$SurfaceSnapshot$strict,
		_Utils_ap(
			_List_fromArray(
				['surfaceProtocol', 'publication', 'lease', 'mode', 'status', 'bar', 'popup']),
			_Utils_ap(
				legacy ? _List_Nil : _List_fromArray(
					['appearance']),
				_Utils_ap(
					hasMotion ? _List_fromArray(
						['motion']) : _List_Nil,
					hasParent ? _List_fromArray(
						['keyboardParent']) : _List_Nil))),
		A4(
			$elm$json$Json$Decode$map3,
			F3(
				function (motion, parent, record) {
					return _Utils_Tuple3(motion, parent, record);
				}),
			motionDecoder,
			parentDecoder,
			A9(
				$elm$json$Json$Decode$map8,
				F8(
					function (version, shown, scoped, current, notice, bar, popup, appearance) {
						return {appearance: appearance, bar: bar, current: current, notice: notice, popup: popup, scoped: scoped, shown: shown, version: version};
					}),
				A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
				A2(
					$elm$json$Json$Decode$field,
					'mode',
					$author$project$SurfaceSnapshot$bounded(16)),
				A2(
					$elm$json$Json$Decode$field,
					'status',
					$author$project$SurfaceSnapshot$bounded(1024)),
				A2(
					$elm$json$Json$Decode$field,
					'bar',
					$author$project$SurfaceSnapshot$controls(300)),
				A2(
					$elm$json$Json$Decode$field,
					'popup',
					$author$project$SurfaceSnapshot$controls(2150)),
				legacy ? $elm$json$Json$Decode$succeed($author$project$Settings$defaults) : A2($elm$json$Json$Decode$field, 'appearance', $author$project$Settings$valuesDecoder))));
	return A2(
		$elm$core$Result$andThen,
		function (_v0) {
			var motion = _v0.a;
			var parent = _v0.b;
			var record = _v0.c;
			var unique = function (names) {
				return _Utils_eq(
					$elm$core$List$length(names),
					$elm$core$Set$size(
						$elm$core$Set$fromList(names)));
			};
			var overviewFilter = function (control) {
				return (control.identity === 'overview:all') || (A2($elm$core$String$startsWith, 'overview:workspace:', control.identity) && (_Utils_cmp(
					$elm$core$String$length(control.identity),
					$elm$core$String$length('overview:workspace:')) > 0));
			};
			var overviewFilters = A2($elm$core$List$filter, overviewFilter, record.popup);
			var checkedRows = A2(
				$elm$core$List$filter,
				function (control) {
					return !_Utils_eq(control.checked, $elm$core$Maybe$Nothing);
				},
				record.popup);
			var checkedScopeInvalid = A2(
				$elm$core$List$any,
				function (control) {
					return !_Utils_eq(control.checked, $elm$core$Maybe$Nothing);
				},
				record.bar) || A2(
				$elm$core$List$any,
				function (control) {
					return (record.current === 'menu') ? (!A2($elm$core$String$startsWith, 'menu:', control.identity)) : ((record.current === 'overview') ? (!overviewFilter(control)) : true);
				},
				checkedRows);
			var checkedSelectionInvalid = ((record.current === 'overview') && (!$elm$core$List$isEmpty(checkedRows))) ? (A2(
				$elm$core$List$any,
				function (control) {
					return _Utils_eq(control.checked, $elm$core$Maybe$Nothing);
				},
				overviewFilters) || ($elm$core$List$length(
				A2(
					$elm$core$List$filter,
					function (control) {
						return _Utils_eq(
							control.checked,
							$elm$core$Maybe$Just(true));
					},
					overviewFilters)) !== 1)) : ($elm$core$List$length(checkedRows) > 1);
			var all = _Utils_ap(record.bar, record.popup);
			var identities = A2(
				$elm$core$List$map,
				function ($) {
					return $.identity;
				},
				all);
			return ((record.version !== 2) || (_Utils_eq(record.shown, $author$project$UInt64$zero) || ((!A2(
				$elm$core$List$member,
				record.current,
				_List_fromArray(
					['closed', 'picker', 'applications', 'menu', 'overview', 'switcher', 'snap', 'settings', 'notifications', 'system', 'files', 'jump']))) || (((record.current !== 'closed') && _Utils_eq(record.scoped, $author$project$UInt64$zero)) || (((record.current === 'closed') && (!$elm$core$List$isEmpty(record.popup))) || ((!unique(identities)) || ((!unique(
				A2(
					$elm$core$List$map,
					function ($) {
						return $.domId;
					},
					all))) || (A2(
				$elm$core$List$any,
				function (control) {
					return $elm$core$String$isEmpty(control.identity) || ($elm$core$String$isEmpty(control.domId) || (control.focusOnly && control.enabled));
				},
				all) || (A2(
				$elm$core$List$any,
				function ($) {
					return $.focusOnly;
				},
				record.bar) || ((A2(
				$elm$core$List$any,
				function ($) {
					return $.focusOnly;
				},
				record.popup) && (record.current !== 'notifications')) || (($elm$core$List$length(
				A2(
					$elm$core$List$filter,
					function ($) {
						return $.focusOnly;
					},
					record.popup)) > 1) || (checkedScopeInvalid || checkedSelectionInvalid)))))))))))) ? $elm$core$Result$Err('Invalid presentation scope/identities') : $elm$core$Result$Ok(
				$author$project$SurfaceSnapshot$Snapshot(
					{appearance: record.appearance, bar: record.bar, keyboardParent: parent, lease: record.scoped, mode: record.current, motion: motion, popup: record.popup, publication: record.shown, status: record.notice}));
		},
		A2(
			$elm$core$Result$mapError,
			$elm$json$Json$Decode$errorToString,
			A2($elm$json$Json$Decode$decodeValue, decoder, raw)));
};
var $author$project$SurfaceSnapshot$lease = function (_v0) {
	var snapshot = _v0.a;
	return snapshot.lease;
};
var $author$project$SurfaceSnapshot$publication = function (_v0) {
	var snapshot = _v0.a;
	return snapshot.publication;
};
var $author$project$Presentation$accept = F2(
	function (raw, prior) {
		var model = prior.a;
		var _v0 = $author$project$SurfaceSnapshot$decode(raw);
		if (_v0.$ === 'Err') {
			return $author$project$Presentation$Model(
				_Utils_update(
					model,
					{snapshot: $elm$core$Maybe$Nothing}));
		} else {
			var snapshot = _v0.a;
			return ((!_Utils_eq(
				A2(
					$author$project$UInt64$compare,
					$author$project$SurfaceSnapshot$publication(snapshot),
					model.last),
				$elm$core$Basics$GT)) || _Utils_eq(
				A2(
					$author$project$UInt64$compare,
					$author$project$SurfaceSnapshot$lease(snapshot),
					model.lease),
				$elm$core$Basics$LT)) ? prior : $author$project$Presentation$Model(
				{
					last: $author$project$SurfaceSnapshot$publication(snapshot),
					lease: $author$project$SurfaceSnapshot$lease(snapshot),
					snapshot: $elm$core$Maybe$Just(snapshot)
				});
		}
	});
var $elm$core$Maybe$andThen = F2(
	function (callback, maybeValue) {
		if (maybeValue.$ === 'Just') {
			var value = maybeValue.a;
			return callback(value);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$NativePreviewRealm$same = F2(
	function (left, right) {
		return _Utils_eq(left, right);
	});
var $author$project$PreviewPresenter$closeRealm = F2(
	function (domain, _v0) {
		var entries = _v0.a;
		var catalog = _v0.b;
		var ledger = _v0.c;
		var scoped = _v0.d;
		return ($elm$core$Dict$isEmpty(entries) && A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (grant) {
					return A2($author$project$NativePreviewRealm$same, grant.domain, domain);
				},
				scoped.grant))) ? $elm$core$Maybe$Just(
			A4(
				$author$project$PreviewPresenter$Model,
				entries,
				catalog,
				ledger,
				_Utils_update(
					scoped,
					{closed: true, closing: true}))) : $elm$core$Maybe$Nothing;
	});
var $author$project$RetainedPreviewPresenter$closeRealm = F2(
	function (domain, _v0) {
		var policy = _v0.a;
		var grant = _v0.b;
		var ingress = _v0.c;
		var deferred = _v0.d;
		return ((!$elm$core$List$isEmpty(deferred)) || A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				A2(
					$elm$core$Basics$composeR,
					$author$project$NativePreviewProposalIngress$pending,
					A2($elm$core$Basics$composeR, $elm$core$List$isEmpty, $elm$core$Basics$not)),
				ingress))) ? $elm$core$Maybe$Nothing : A2(
			$elm$core$Maybe$map,
			function (next) {
				return A4($author$project$RetainedPreviewPresenter$Model, next, grant, ingress, deferred);
			},
			A2($author$project$PreviewPresenter$closeRealm, domain, policy));
	});
var $author$project$CapturedAction$CapturedAction = function (a) {
	return {$: 'CapturedAction', a: a};
};
var $elm$json$Json$Decode$map7 = _Json_map7;
var $author$project$CapturedAction$decode = function (raw) {
	var hasTrigger = !_Utils_eq(
		$elm$core$Maybe$Nothing,
		$elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'trigger', $elm$json$Json$Decode$value),
				raw)));
	var origin = hasTrigger ? A2(
		$elm$json$Json$Decode$field,
		'trigger',
		A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return A2(
					$elm$core$List$member,
					value,
					_List_fromArray(
						['pointer', 'keyboard'])) ? $elm$json$Json$Decode$succeed(
					$elm$core$Maybe$Just(value)) : $elm$json$Json$Decode$fail('Action origin');
			},
			$elm$json$Json$Decode$string)) : $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing);
	var fields = _Utils_ap(
		_List_fromArray(
			['id', 'kind', 'lease', 'publication', 'surface', 'surfaceProtocol']),
		hasTrigger ? _List_fromArray(
			['trigger']) : _List_Nil);
	var decoder = A2(
		$elm$json$Json$Decode$andThen,
		function (pairs) {
			return (!_Utils_eq(
				$elm$core$List$sort(
					A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
				fields)) ? $elm$json$Json$Decode$fail('Action fields') : A2(
				$elm$json$Json$Decode$andThen,
				function (_v0) {
					var version = _v0.a;
					var kind = _v0.b;
					var value = _v0.c;
					return ((version === 2) && ((kind === 'surface-action') && ((!_Utils_eq(value.publication, $author$project$UInt64$zero)) && (A2(
						$elm$core$List$member,
						value.surface,
						_List_fromArray(
							['bar', 'popup'])) && ((!$elm$core$String$isEmpty(value.identity)) && (($elm$core$String$length(value.identity) <= 512) && (!A2(
						$elm$core$String$any,
						function (c) {
							return $elm$core$Char$toCode(c) < 32;
						},
						value.identity)))))))) ? $elm$json$Json$Decode$succeed(
						$author$project$CapturedAction$CapturedAction(value)) : $elm$json$Json$Decode$fail('Action scope');
				},
				A8(
					$elm$json$Json$Decode$map7,
					F7(
						function (version, kind, shown, scoped, role, name, trigger) {
							return _Utils_Tuple3(
								version,
								kind,
								{identity: name, lease: scoped, publication: shown, surface: role, trigger: trigger});
						}),
					A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
					A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
					A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string),
					A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
					origin));
		},
		$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	return A2($elm$json$Json$Decode$decodeValue, decoder, raw);
};
var $author$project$SurfaceSnapshot$enabled = F3(
	function (popup, identity, _v0) {
		var snapshot = _v0.a;
		return A2(
			$elm$core$List$any,
			function (control) {
				return _Utils_eq(control.identity, identity) && control.enabled;
			},
			popup ? snapshot.popup : snapshot.bar);
	});
var $author$project$UInt64$string = function (_v0) {
	var value = _v0.a;
	return value;
};
var $author$project$CapturedAction$encode = function (_v0) {
	var value = _v0.a;
	return $elm$json$Json$Encode$object(
		_Utils_ap(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'surface',
					$elm$json$Json$Encode$string(value.surface)),
					_Utils_Tuple2(
					'surfaceProtocol',
					$elm$json$Json$Encode$int(2)),
					_Utils_Tuple2(
					'kind',
					$elm$json$Json$Encode$string('surface-action')),
					_Utils_Tuple2(
					'publication',
					$elm$json$Json$Encode$string(
						$author$project$UInt64$string(value.publication))),
					_Utils_Tuple2(
					'lease',
					$elm$json$Json$Encode$string(
						$author$project$UInt64$string(value.lease))),
					_Utils_Tuple2(
					'id',
					$elm$json$Json$Encode$string(value.identity))
				]),
			A2(
				$elm$core$Maybe$withDefault,
				_List_Nil,
				A2(
					$elm$core$Maybe$map,
					function (trigger) {
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'trigger',
								$elm$json$Json$Encode$string(trigger))
							]);
					},
					value.trigger))));
};
var $author$project$CapturedAction$identity = function (_v0) {
	var value = _v0.a;
	return value.identity;
};
var $author$project$CapturedAction$lease = function (_v0) {
	var value = _v0.a;
	return value.lease;
};
var $author$project$CapturedAction$publication = function (_v0) {
	var value = _v0.a;
	return value.publication;
};
var $author$project$CapturedAction$surface = function (_v0) {
	var value = _v0.a;
	return value.surface;
};
var $author$project$Presentation$dispatch = F3(
	function (popup, raw, _v0) {
		var model = _v0.a;
		var _v1 = _Utils_Tuple2(
			model.snapshot,
			$author$project$CapturedAction$decode(raw));
		if ((_v1.a.$ === 'Just') && (_v1.b.$ === 'Ok')) {
			var snapshot = _v1.a.a;
			var event = _v1.b.a;
			return (_Utils_eq(
				$author$project$CapturedAction$publication(event),
				$author$project$SurfaceSnapshot$publication(snapshot)) && (_Utils_eq(
				$author$project$CapturedAction$lease(event),
				$author$project$SurfaceSnapshot$lease(snapshot)) && (_Utils_eq(
				$author$project$CapturedAction$surface(event),
				popup ? 'popup' : 'bar') && A3(
				$author$project$SurfaceSnapshot$enabled,
				popup,
				$author$project$CapturedAction$identity(event),
				snapshot)))) ? $elm$core$Maybe$Just(
				$author$project$CapturedAction$encode(event)) : $elm$core$Maybe$Nothing;
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$NativePreviewRealm$Domain = F4(
	function (lifetime, session, frontend, receiverEpoch) {
		return {frontend: frontend, lifetime: lifetime, receiverEpoch: receiverEpoch, session: session};
	});
var $author$project$NativePreviewRealm$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (n) {
		return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Positive native realm identity');
	},
	$author$project$UInt64$decoder);
var $author$project$NativePreviewRealm$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Exact native preview realm fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativePreviewRealm$domainDecoder = A3(
	$elm$json$Json$Decode$map2,
	F2(
		function (_v0, epoch) {
			var lifetime = _v0.a;
			var session = _v0.b;
			var frontend = _v0.c;
			return A4($author$project$NativePreviewRealm$Domain, lifetime, session, frontend, epoch);
		}),
	A2(
		$elm$json$Json$Decode$field,
		'binding',
		A2(
			$author$project$NativePreviewRealm$strict,
			_List_fromArray(
				['lifetime', 'session', 'frontend']),
			A4(
				$elm$json$Json$Decode$map3,
				F3(
					function (a, b, c) {
						return _Utils_Tuple3(a, b, c);
					}),
				A2($elm$json$Json$Decode$field, 'lifetime', $author$project$NativePreviewRealm$positive),
				A2($elm$json$Json$Decode$field, 'session', $author$project$NativePreviewRealm$positive),
				A2($elm$json$Json$Decode$field, 'frontend', $author$project$NativePreviewRealm$positive)))),
	A2($elm$json$Json$Decode$field, 'receiverEpoch', $author$project$NativePreviewRealm$positive));
var $author$project$SurfaceSnapshot$fieldIdentity = function (_v0) {
	var snapshot = _v0.a;
	return (snapshot.mode === 'files') ? 'control:files-path' : 'control:search';
};
var $elm$json$Json$Decode$map5 = _Json_map5;
var $author$project$Presentation$query = F2(
	function (value, _v0) {
		var model = _v0.a;
		return ((_Utils_cmp(
			$elm$core$String$length(value),
			A2(
				$elm$core$Maybe$withDefault,
				256,
				A2(
					$elm$core$Maybe$map,
					function (snapshot) {
						return ($author$project$SurfaceSnapshot$mode(snapshot) === 'files') ? 512 : 256;
					},
					model.snapshot))) > 0) || A2(
			$elm$core$String$any,
			function (c) {
				return ($elm$core$Char$toCode(c) < 32) || ($elm$core$Char$toCode(c) === 127);
			},
			value)) ? $elm$core$Maybe$Nothing : A2(
			$elm$core$Maybe$andThen,
			function (snapshot) {
				return ((!A2(
					$elm$core$List$member,
					$author$project$SurfaceSnapshot$mode(snapshot),
					_List_fromArray(
						['applications', 'files']))) || (!A3(
					$author$project$SurfaceSnapshot$enabled,
					true,
					$author$project$SurfaceSnapshot$fieldIdentity(snapshot),
					snapshot))) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'surfaceProtocol',
								$elm$json$Json$Encode$int(2)),
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('surface-query')),
								_Utils_Tuple2(
								'surface',
								$elm$json$Json$Encode$string('popup')),
								_Utils_Tuple2(
								'publication',
								$elm$json$Json$Encode$string(
									$author$project$UInt64$string(
										$author$project$SurfaceSnapshot$publication(snapshot)))),
								_Utils_Tuple2(
								'lease',
								$elm$json$Json$Encode$string(
									$author$project$UInt64$string(
										$author$project$SurfaceSnapshot$lease(snapshot)))),
								_Utils_Tuple2(
								'id',
								$elm$json$Json$Encode$string(
									$author$project$SurfaceSnapshot$fieldIdentity(snapshot))),
								_Utils_Tuple2(
								'query',
								$elm$json$Json$Encode$string(value))
							])));
			},
			model.snapshot);
	});
var $author$project$Presentation$editQuery = F2(
	function (raw, currentModel) {
		var model = currentModel.a;
		var decoder = A6(
			$elm$json$Json$Decode$map5,
			F5(
				function (version, surface, publication, lease, value) {
					return {lease: lease, publication: publication, surface: surface, value: value, version: version};
				}),
			A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
			A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
			A2($elm$json$Json$Decode$field, 'query', $elm$json$Json$Decode$string));
		var _v0 = _Utils_Tuple2(
			A2($elm$json$Json$Decode$decodeValue, decoder, raw),
			model.snapshot);
		if ((_v0.a.$ === 'Ok') && (_v0.b.$ === 'Just')) {
			var event = _v0.a.a;
			var snapshot = _v0.b.a;
			return ((event.version !== 2) || ((event.surface !== 'popup') || ((!_Utils_eq(
				event.publication,
				$author$project$SurfaceSnapshot$publication(snapshot))) || ((!_Utils_eq(
				event.lease,
				$author$project$SurfaceSnapshot$lease(snapshot))) || (!_Utils_eq(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
					raw),
				$elm$core$Result$Ok(
					$author$project$SurfaceSnapshot$fieldIdentity(snapshot)))))))) ? $elm$core$Maybe$Nothing : A2(
				$elm$core$Maybe$map,
				function (wire) {
					return _Utils_Tuple2(event.value, wire);
				},
				A2($author$project$Presentation$query, event.value, currentModel));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Popup$PaintRequest = function (a) {
	return {$: 'PaintRequest', a: a};
};
var $elm$core$Tuple$pair = F2(
	function (a, b) {
		return _Utils_Tuple2(a, b);
	});
var $author$project$PreviewPaintGate$batchDecoder = function () {
	var item = A3(
		$elm$json$Json$Decode$map2,
		$elm$core$Tuple$pair,
		A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
		A2(
			$elm$json$Json$Decode$field,
			'commands',
			$elm$json$Json$Decode$list($elm$json$Json$Decode$value)));
	var rows = $elm$json$Json$Decode$list(item);
	var scopedRows = $elm$json$Json$Decode$list(
		A2(
			$elm$json$Json$Decode$andThen,
			function (fields) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
					_List_fromArray(
						['commands', 'identity'])) ? item : $elm$json$Json$Decode$fail('Exact scoped proposal row');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value)));
	var scoped = A2(
		$elm$json$Json$Decode$andThen,
		function (fields) {
			return (!_Utils_eq(
				$elm$core$List$sort(
					A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
				_List_fromArray(
					['binding', 'entries', 'kind', 'previewProtocol', 'receiverEpoch']))) ? $elm$json$Json$Decode$fail('Exact preview proposal fields') : A2(
				$elm$json$Json$Decode$andThen,
				function (packet) {
					return ((packet.version === 3) && (packet.kind === 'preview-proposals')) ? $elm$json$Json$Decode$succeed(
						_Utils_Tuple2(
							$elm$core$Maybe$Just(packet.domain),
							packet.entries)) : $elm$json$Json$Decode$fail('Typed preview proposal envelope');
				},
				A5(
					$elm$json$Json$Decode$map4,
					F4(
						function (version, kind, domain, entries) {
							return {domain: domain, entries: entries, kind: kind, version: version};
						}),
					A2($elm$json$Json$Decode$field, 'previewProtocol', $elm$json$Json$Decode$int),
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					$author$project$NativePreviewRealm$domainDecoder,
					A2($elm$json$Json$Decode$field, 'entries', scopedRows)));
		},
		$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				A2(
				$elm$json$Json$Decode$map,
				function (entries) {
					return _Utils_Tuple2($elm$core$Maybe$Nothing, entries);
				},
				rows),
				scoped
			]));
}();
var $elm$core$List$append = F2(
	function (xs, ys) {
		if (!ys.b) {
			return xs;
		} else {
			return A3($elm$core$List$foldr, $elm$core$List$cons, ys, xs);
		}
	});
var $elm$core$List$concat = function (lists) {
	return A3($elm$core$List$foldr, $elm$core$List$append, _List_Nil, lists);
};
var $elm$core$List$concatMap = F2(
	function (f, list) {
		return $elm$core$List$concat(
			A2($elm$core$List$map, f, list));
	});
var $author$project$NativePreviewRealm$bindingValue = function (domain) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(domain.lifetime))),
				_Utils_Tuple2(
				'session',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(domain.session))),
				_Utils_Tuple2(
				'frontend',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(domain.frontend)))
			]));
};
var $author$project$NativePreviewRealm$commands = F2(
	function (domain, entries) {
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'previewProtocol',
					$elm$json$Json$Encode$int(3)),
					_Utils_Tuple2(
					'kind',
					$elm$json$Json$Encode$string('preview-proposals')),
					_Utils_Tuple2(
					'binding',
					$author$project$NativePreviewRealm$bindingValue(domain)),
					_Utils_Tuple2(
					'receiverEpoch',
					$elm$json$Json$Encode$string(
						$author$project$UInt64$string(domain.receiverEpoch))),
					_Utils_Tuple2('entries', entries)
				]));
	});
var $author$project$PreviewPaintGate$identityValue = function (value) {
	return value;
};
var $elm$json$Json$Encode$list = F2(
	function (func, entries) {
		return _Json_wrap(
			A3(
				$elm$core$List$foldl,
				_Json_addEntry(func),
				_Json_emptyArray(_Utils_Tuple0),
				entries));
	});
var $author$project$PreviewPaintGate$encodeBatch = F2(
	function (realm, entries) {
		var rows = A2($elm$json$Json$Encode$list, $author$project$PreviewPaintGate$identityValue, entries);
		return A2(
			$elm$core$Maybe$withDefault,
			rows,
			A2(
				$elm$core$Maybe$map,
				function (domain) {
					return A2($author$project$NativePreviewRealm$commands, domain, rows);
				},
				realm));
	});
var $elm$core$Dict$foldl = F3(
	function (func, acc, dict) {
		foldl:
		while (true) {
			if (dict.$ === 'RBEmpty_elm_builtin') {
				return acc;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldl, func, acc, left)),
					$temp$dict = right;
				func = $temp$func;
				acc = $temp$acc;
				dict = $temp$dict;
				continue foldl;
			}
		}
	});
var $elm$core$Dict$filter = F2(
	function (isGood, dict) {
		return A3(
			$elm$core$Dict$foldl,
			F3(
				function (k, v, d) {
					return A2(isGood, k, v) ? A3($elm$core$Dict$insert, k, v, d) : d;
				}),
			$elm$core$Dict$empty,
			dict);
	});
var $author$project$PreviewPaintGate$jobKey = function (command) {
	return A2(
		$elm$core$Maybe$map,
		$elm$json$Json$Encode$encode(0),
		$elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'job', $elm$json$Json$Decode$value),
				command)));
};
var $elm$core$Char$fromCode = _Char_fromCode;
var $elm$core$String$fromList = _String_fromList;
var $elm$core$String$foldr = _String_foldr;
var $elm$core$String$toList = function (string) {
	return A3($elm$core$String$foldr, $elm$core$List$cons, _List_Nil, string);
};
var $author$project$UInt64$next = function (_v0) {
	var value = _v0.a;
	var add = function (digits) {
		if (!digits.b) {
			return _List_fromArray(
				[
					_Utils_chr('1')
				]);
		} else {
			if ('9' === digits.a.valueOf()) {
				var rest = digits.b;
				return A2(
					$elm$core$List$cons,
					_Utils_chr('0'),
					add(rest));
			} else {
				var digit = digits.a;
				var rest = digits.b;
				return A2(
					$elm$core$List$cons,
					$elm$core$Char$fromCode(
						$elm$core$Char$toCode(digit) + 1),
					rest);
			}
		}
	};
	return (value === '18446744073709551615') ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
		$author$project$UInt64$Counter(
			$elm$core$String$fromList(
				$elm$core$List$reverse(
					add(
						$elm$core$List$reverse(
							$elm$core$String$toList(value)))))));
};
var $author$project$PreviewPaintGate$row = F2(
	function (identity, command) {
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'identity',
					$elm$json$Json$Encode$string(identity)),
					_Utils_Tuple2(
					'commands',
					A2(
						$elm$json$Json$Encode$list,
						$author$project$PreviewPaintGate$identityValue,
						_List_fromArray(
							[command])))
				]));
	});
var $elm$core$Dict$values = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, valueList) {
				return A2($elm$core$List$cons, value, valueList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Result$withDefault = F2(
	function (def, result) {
		if (result.$ === 'Ok') {
			var a = result.a;
			return a;
		} else {
			return def;
		}
	});
var $author$project$PreviewPaintGate$queue = F2(
	function (raw, initialModel) {
		var _v0 = A2(
			$elm$core$Result$withDefault,
			_Utils_Tuple2($elm$core$Maybe$Nothing, _List_Nil),
			A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewPaintGate$batchDecoder, raw));
		var realm = _v0.a;
		var entries = _v0.b;
		var commands = A2(
			$elm$core$List$concatMap,
			function (_v9) {
				var identity = _v9.a;
				var items = _v9.b;
				return A2(
					$elm$core$List$map,
					$elm$core$Tuple$pair(identity),
					items);
			},
			entries);
		var step = F2(
			function (_v6, _v7) {
				var identity = _v6.a;
				var command = _v6.b;
				var _v8 = _v7.a;
				var ordinal = _v8.a;
				var pending = _v8.b;
				var immediate = _v7.b;
				var tickets = _v7.c;
				var kind = A2(
					$elm$core$Result$withDefault,
					'',
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
						command));
				var job = $author$project$PreviewPaintGate$jobKey(command);
				var _v2 = _Utils_Tuple2(kind, job);
				if (_v2.a === 'acquire') {
					if (_v2.b.$ === 'Just') {
						var key = _v2.b.a;
						var _v3 = $author$project$UInt64$next(ordinal);
						if (_v3.$ === 'Nothing') {
							return _Utils_Tuple3(
								A2($author$project$PreviewPaintGate$Model, ordinal, pending),
								immediate,
								tickets);
						} else {
							var next = _v3.a;
							if (A2(
								$elm$core$List$any,
								function (held) {
									return _Utils_eq(held.realm, realm) && (_Utils_eq(held.identity, identity) && _Utils_eq(held.job, key));
								},
								$elm$core$Dict$values(pending))) {
								return _Utils_Tuple3(
									A2($author$project$PreviewPaintGate$Model, ordinal, pending),
									immediate,
									tickets);
							} else {
								var ticket = $author$project$UInt64$string(next);
								return _Utils_Tuple3(
									A2(
										$author$project$PreviewPaintGate$Model,
										next,
										A3(
											$elm$core$Dict$insert,
											ticket,
											{command: command, identity: identity, job: key, realm: realm},
											pending)),
									immediate,
									_Utils_ap(
										tickets,
										_List_fromArray(
											[
												$elm$json$Json$Encode$object(
												_List_fromArray(
													[
														_Utils_Tuple2(
														'ticket',
														$elm$json$Json$Encode$string(ticket))
													]))
											])));
							}
						}
					} else {
						var _v4 = _v2.b;
						return _Utils_Tuple3(
							A2($author$project$PreviewPaintGate$Model, ordinal, pending),
							immediate,
							tickets);
					}
				} else {
					var retained = (kind === 'cancel') ? A2(
						$elm$core$Dict$filter,
						F2(
							function (_v5, held) {
								return !(_Utils_eq(held.realm, realm) && (_Utils_eq(held.identity, identity) && _Utils_eq(
									$elm$core$Maybe$Just(held.job),
									job)));
							}),
						pending) : pending;
					return _Utils_Tuple3(
						A2($author$project$PreviewPaintGate$Model, ordinal, retained),
						_Utils_ap(
							immediate,
							_List_fromArray(
								[
									A2($author$project$PreviewPaintGate$row, identity, command)
								])),
						tickets);
				}
			});
		var _v1 = A3(
			$elm$core$List$foldl,
			step,
			_Utils_Tuple3(initialModel, _List_Nil, _List_Nil),
			commands);
		var updatedModel = _v1.a;
		var commandsNow = _v1.b;
		var paintRequests = _v1.c;
		return _Utils_Tuple3(
			updatedModel,
			A2($author$project$PreviewPaintGate$encodeBatch, realm, commandsNow),
			A2($elm$json$Json$Encode$list, $author$project$PreviewPaintGate$identityValue, paintRequests));
	});
var $author$project$Popup$emitPreview = F2(
	function (commands, model) {
		var _v0 = A2($author$project$PreviewPaintGate$queue, commands, model.paintGate);
		var gate = _v0.a;
		var immediate = _v0.b;
		var requests = _v0.c;
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{paintGate: gate}),
			_List_fromArray(
				[
					$author$project$Popup$PreviewCommand(immediate),
					$author$project$Popup$PaintRequest(requests)
				]));
	});
var $author$project$SurfaceRenderer$enabled = $author$project$SurfaceSnapshot$enabled;
var $author$project$NativePreviewProposalIngress$Model = F2(
	function (a, b) {
		return {$: 'Model', a: a, b: b};
	});
var $author$project$NativePreviewProposalIngress$empty = function (grant) {
	return A2($author$project$NativePreviewProposalIngress$Model, grant, _List_Nil);
};
var $author$project$NativePreviewRealm$owner = function (domain) {
	return A2(
		$elm$core$String$join,
		':',
		A2(
			$elm$core$List$map,
			$author$project$UInt64$string,
			_List_fromArray(
				[domain.lifetime, domain.session, domain.frontend])));
};
var $author$project$PreviewPresenter$enrollRealm = F2(
	function (grant, prior) {
		var entries = prior.a;
		var catalog = prior.b;
		var ledger = prior.c;
		var scoped = prior.d;
		var _v0 = scoped.grant;
		if (_v0.$ === 'Nothing') {
			return ($elm$core$Dict$isEmpty(entries) && (_Utils_eq(catalog, $elm$core$Maybe$Nothing) && _Utils_eq(ledger, $author$project$NativeActorRetirement$empty))) ? $elm$core$Maybe$Just(
				A4(
					$author$project$PreviewPresenter$Model,
					entries,
					catalog,
					_Utils_update(
						ledger,
						{
							channel: $elm$core$Maybe$Just(
								$author$project$NativePreviewRealm$owner(grant.domain))
						}),
					_Utils_update(
						$author$project$PreviewPresenter$emptyScoped,
						{
							grant: $elm$core$Maybe$Just(grant)
						}))) : $elm$core$Maybe$Nothing;
		} else {
			var old = _v0.a;
			return (_Utils_eq(old, grant) && (!scoped.closed)) ? $elm$core$Maybe$Just(prior) : ((scoped.closed && ($elm$core$Dict$isEmpty(entries) && (_Utils_eq(
				$author$project$NativePreviewRealm$owner(old.domain),
				$author$project$NativePreviewRealm$owner(grant.domain)) && _Utils_eq(
				A2($author$project$UInt64$compare, grant.domain.receiverEpoch, old.domain.receiverEpoch),
				$elm$core$Basics$GT)))) ? $elm$core$Maybe$Just(
				A4(
					$author$project$PreviewPresenter$Model,
					entries,
					catalog,
					_Utils_update(
						ledger,
						{
							channel: $elm$core$Maybe$Just(
								$author$project$NativePreviewRealm$owner(grant.domain)),
							processed: $author$project$UInt64$zero
						}),
					_Utils_update(
						$author$project$PreviewPresenter$emptyScoped,
						{
							grant: $elm$core$Maybe$Just(grant)
						}))) : $elm$core$Maybe$Nothing);
		}
	});
var $author$project$RetainedPreviewPresenter$enrollRealm = F2(
	function (grant, prior) {
		var policy = prior.a;
		var old = prior.b;
		var ingress = prior.c;
		var deferred = prior.d;
		return ((!$elm$core$List$isEmpty(deferred)) || A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				A2(
					$elm$core$Basics$composeR,
					$author$project$NativePreviewProposalIngress$pending,
					A2($elm$core$Basics$composeR, $elm$core$List$isEmpty, $elm$core$Basics$not)),
				ingress))) ? (_Utils_eq(
			old,
			$elm$core$Maybe$Just(grant)) ? $elm$core$Maybe$Just(prior) : $elm$core$Maybe$Nothing) : A2(
			$elm$core$Maybe$map,
			function (next) {
				return A4(
					$author$project$RetainedPreviewPresenter$Model,
					next,
					$elm$core$Maybe$Just(grant),
					$elm$core$Maybe$Just(
						$author$project$NativePreviewProposalIngress$empty(grant)),
					_List_Nil);
			},
			A2($author$project$PreviewPresenter$enrollRealm, grant, policy));
	});
var $author$project$NativePreviewRealm$Envelope = F2(
	function (a, b) {
		return {$: 'Envelope', a: a, b: b};
	});
var $author$project$NativePreviewRealm$envelopeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var protocol = _v0.a;
		var kind = _v0.b;
		var envelope = _v0.c;
		return ((protocol === 3) && (kind === 'native-preview-realm-event')) ? $elm$json$Json$Decode$succeed(envelope) : $elm$json$Json$Decode$fail('Typed native preview event envelope');
	},
	A2(
		$author$project$NativePreviewRealm$strict,
		_List_fromArray(
			['previewProtocol', 'kind', 'binding', 'receiverEpoch', 'event']),
		A5(
			$elm$json$Json$Decode$map4,
			F4(
				function (protocol, kind, domain, event) {
					return _Utils_Tuple3(
						protocol,
						kind,
						A2($author$project$NativePreviewRealm$Envelope, domain, event));
				}),
			A2($elm$json$Json$Decode$field, 'previewProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			$author$project$NativePreviewRealm$domainDecoder,
			A2($elm$json$Json$Decode$field, 'event', $elm$json$Json$Decode$value))));
var $author$project$SurfaceRenderer$fieldIdentity = $author$project$SurfaceSnapshot$fieldIdentity;
var $author$project$NativePreviewRealm$Grant = F2(
	function (domain, capacity) {
		return {capacity: capacity, domain: domain};
	});
var $author$project$NativePreviewRealm$grantDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (grant) {
		return ((grant.capacity > 0) && (grant.capacity <= 1065)) ? $elm$json$Json$Decode$succeed(grant) : $elm$json$Json$Decode$fail('Original bounded native reservation grant');
	},
	A2(
		$author$project$NativePreviewRealm$strict,
		_List_fromArray(
			['binding', 'receiverEpoch', 'capacity']),
		A3(
			$elm$json$Json$Decode$map2,
			$author$project$NativePreviewRealm$Grant,
			$author$project$NativePreviewRealm$domainDecoder,
			A2($elm$json$Json$Decode$field, 'capacity', $elm$json$Json$Decode$int))));
var $author$project$Popup$isComposing = function (model) {
	return !_Utils_eq(model.composition, $author$project$Popup$Idle);
};
var $author$project$NativePreviewProposalIngress$AcceptedTicket = F3(
	function (a, b, c) {
		return {$: 'AcceptedTicket', a: a, b: b, c: c};
	});
var $author$project$NativePreviewProposalIngress$Packet = F5(
	function (protocol, kind, domain, ordinal, intents) {
		return {domain: domain, intents: intents, kind: kind, ordinal: ordinal, protocol: protocol};
	});
var $author$project$NativePreviewProposalIngress$Ticket = F6(
	function (protocol, kind, domain, ordinal, advisory, wire) {
		return {advisory: advisory, domain: domain, kind: kind, ordinal: ordinal, protocol: protocol, wire: wire};
	});
var $elm$core$String$foldl = _String_foldl;
var $author$project$NativePreviewProposalIngress$bytes = A2(
	$elm$core$String$foldl,
	F2(
		function (c, n) {
			return n + (($elm$core$Char$toCode(c) < 128) ? 1 : (($elm$core$Char$toCode(c) < 2048) ? 2 : (($elm$core$Char$toCode(c) < 65536) ? 3 : 4)));
		}),
	0);
var $elm$json$Json$Decode$decodeString = _Json_runOnString;
var $author$project$NativePreviewProposalIngress$Intent = F2(
	function (identity, command) {
		return {command: command, identity: identity};
	});
var $author$project$NativePreviewProposalIngress$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Exact proposal intent fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativePreviewProposalIngress$intentDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var name = _v0.a;
		var commands = _v0.b;
		if (commands.b && (!commands.b.b)) {
			var command = commands.a;
			if ((name !== '') && ($author$project$NativePreviewProposalIngress$bytes(name) <= 512)) {
				var _v2 = A2(
					$elm$json$Json$Decode$decodeValue,
					$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value),
					command);
				if (_v2.$ === 'Ok') {
					return $elm$json$Json$Decode$succeed(
						A2($author$project$NativePreviewProposalIngress$Intent, name, command));
				} else {
					return $elm$json$Json$Decode$fail('Object policy command');
				}
			} else {
				return $elm$json$Json$Decode$fail('Bounded original identity');
			}
		} else {
			return $elm$json$Json$Decode$fail('Singleton original policy command');
		}
	},
	A2(
		$author$project$NativePreviewProposalIngress$strict,
		_List_fromArray(
			['identity', 'commands']),
		A3(
			$elm$json$Json$Decode$map2,
			$elm$core$Tuple$pair,
			A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
			A2(
				$elm$json$Json$Decode$field,
				'commands',
				$elm$json$Json$Decode$list($elm$json$Json$Decode$value)))));
var $author$project$NativePreviewProposalIngress$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (n) {
		return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Positive native ticket ordinal');
	},
	$author$project$UInt64$decoder);
var $author$project$NativePreviewProposalIngress$sameIntent = F2(
	function (a, b) {
		return _Utils_eq(a.identity, b.identity) && _Utils_eq(a.command, b.command);
	});
var $author$project$NativePreviewProposalIngress$issuedWithConfirmation = F2(
	function (raw, _v0) {
		var grant = _v0.a;
		var rows = _v0.b;
		var ticket = A2(
			$author$project$NativePreviewProposalIngress$strict,
			_List_fromArray(
				['previewProtocol', 'kind', 'binding', 'receiverEpoch', 'controlOrdinal', 'alreadyDelivered', 'wire']),
			A7(
				$elm$json$Json$Decode$map6,
				$author$project$NativePreviewProposalIngress$Ticket,
				A2($elm$json$Json$Decode$field, 'previewProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				$author$project$NativePreviewRealm$domainDecoder,
				A2($elm$json$Json$Decode$field, 'controlOrdinal', $author$project$NativePreviewProposalIngress$positive),
				A2($elm$json$Json$Decode$field, 'alreadyDelivered', $elm$json$Json$Decode$bool),
				A2($elm$json$Json$Decode$field, 'wire', $elm$json$Json$Decode$string)));
		var packet = A2(
			$author$project$NativePreviewProposalIngress$strict,
			_List_fromArray(
				['previewProtocol', 'kind', 'binding', 'receiverEpoch', 'controlOrdinal', 'entries']),
			A6(
				$elm$json$Json$Decode$map5,
				$author$project$NativePreviewProposalIngress$Packet,
				A2($elm$json$Json$Decode$field, 'previewProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				$author$project$NativePreviewRealm$domainDecoder,
				A2($elm$json$Json$Decode$field, 'controlOrdinal', $author$project$NativePreviewProposalIngress$positive),
				A2(
					$elm$json$Json$Decode$field,
					'entries',
					$elm$json$Json$Decode$list($author$project$NativePreviewProposalIngress$intentDecoder))));
		return A2(
			$elm$core$Maybe$andThen,
			function (fact) {
				return ((fact.protocol !== 3) || ((fact.kind !== 'preview-control-ticket') || ((!A2($author$project$NativePreviewRealm$same, fact.domain, grant.domain)) || ($author$project$NativePreviewProposalIngress$bytes(fact.wire) > 4096)))) ? $elm$core$Maybe$Nothing : A2(
					$elm$core$Maybe$andThen,
					function (decoded) {
						var _v1 = decoded.intents;
						if (_v1.b && (!_v1.b.b)) {
							var intent = _v1.a;
							return ((decoded.protocol === 3) && ((decoded.kind === 'preview-commands') && (A2($author$project$NativePreviewRealm$same, decoded.domain, grant.domain) && (_Utils_eq(decoded.ordinal, fact.ordinal) && A2(
								$elm$core$List$any,
								$author$project$NativePreviewProposalIngress$sameIntent(intent),
								rows))))) ? $elm$core$Maybe$Just(
								_Utils_Tuple2(
									A2(
										$author$project$NativePreviewProposalIngress$Model,
										grant,
										A2(
											$elm$core$List$filter,
											function (row) {
												return !A2($author$project$NativePreviewProposalIngress$sameIntent, intent, row);
											},
											rows)),
									A3($author$project$NativePreviewProposalIngress$AcceptedTicket, fact.domain, fact.ordinal, fact.wire))) : $elm$core$Maybe$Nothing;
						} else {
							return $elm$core$Maybe$Nothing;
						}
					},
					$elm$core$Result$toMaybe(
						A2($elm$json$Json$Decode$decodeString, packet, fact.wire)));
			},
			$elm$core$Result$toMaybe(
				A2($elm$json$Json$Decode$decodeValue, ticket, raw)));
	});
var $author$project$RetainedPreviewPresenter$issuedWithConfirmation = F2(
	function (raw, prior) {
		var policy = prior.a;
		var grant = prior.b;
		var ingress = prior.c;
		var deferred = prior.d;
		var _v0 = A2(
			$elm$core$Maybe$andThen,
			$author$project$NativePreviewProposalIngress$issuedWithConfirmation(raw),
			ingress);
		if (_v0.$ === 'Just') {
			var _v1 = _v0.a;
			var next = _v1.a;
			var ticket = _v1.b;
			return _Utils_Tuple2(
				A4(
					$author$project$RetainedPreviewPresenter$Model,
					policy,
					grant,
					$elm$core$Maybe$Just(next),
					deferred),
				$elm$core$Maybe$Just(ticket));
		} else {
			return _Utils_Tuple2(prior, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$SurfaceRenderer$lease = $author$project$SurfaceSnapshot$lease;
var $author$project$Presentation$localEdit = F2(
	function (raw, currentModel) {
		var model = currentModel.a;
		var decoder = A8(
			$elm$json$Json$Decode$map7,
			F7(
				function (version, surface, publication, lease, identity, kind, value) {
					return {identity: identity, kind: kind, lease: lease, publication: publication, surface: surface, value: value, version: version};
				}),
			A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
			A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
			A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'query', $elm$json$Json$Decode$string));
		var _v0 = _Utils_Tuple2(
			A2($elm$json$Json$Decode$decodeValue, decoder, raw),
			model.snapshot);
		if ((_v0.a.$ === 'Ok') && (_v0.b.$ === 'Just')) {
			var event = _v0.a.a;
			var snapshot = _v0.b.a;
			return ((event.version !== 2) || ((event.surface !== 'popup') || (_Utils_eq(event.publication, $author$project$UInt64$zero) || (_Utils_eq(
				A2(
					$author$project$UInt64$compare,
					event.publication,
					$author$project$SurfaceSnapshot$publication(snapshot)),
				$elm$core$Basics$GT) || ((!_Utils_eq(
				event.lease,
				$author$project$SurfaceSnapshot$lease(snapshot))) || ((!_Utils_eq(
				event.identity,
				$author$project$SurfaceSnapshot$fieldIdentity(snapshot))) || (!A2(
				$elm$core$List$member,
				event.kind,
				_List_fromArray(
					['surface-query', 'surface-preedit', 'surface-composition-start', 'surface-composition-end']))))))))) ? $elm$core$Maybe$Nothing : A2(
				$elm$core$Maybe$andThen,
				function (wire) {
					return A2(
						$elm$core$Maybe$map,
						function (fields) {
							return $elm$json$Json$Encode$object(
								A2(
									$elm$core$List$map,
									function (_v1) {
										var name = _v1.a;
										var value = _v1.b;
										return _Utils_Tuple2(
											name,
											(name === 'kind') ? $elm$json$Json$Encode$string(event.kind) : value);
									},
									fields));
						},
						$elm$core$Result$toMaybe(
							A2(
								$elm$json$Json$Decode$decodeValue,
								$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value),
								wire)));
				},
				A2($author$project$Presentation$query, event.value, currentModel));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$core$Result$map = F2(
	function (func, ra) {
		if (ra.$ === 'Ok') {
			var a = ra.a;
			return $elm$core$Result$Ok(
				func(a));
		} else {
			var e = ra.a;
			return $elm$core$Result$Err(e);
		}
	});
var $elm$core$Dict$get = F2(
	function (targetKey, dict) {
		get:
		while (true) {
			if (dict.$ === 'RBEmpty_elm_builtin') {
				return $elm$core$Maybe$Nothing;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var _v1 = A2($elm$core$Basics$compare, targetKey, key);
				switch (_v1.$) {
					case 'LT':
						var $temp$targetKey = targetKey,
							$temp$dict = left;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
					case 'EQ':
						return $elm$core$Maybe$Just(value);
					default:
						var $temp$targetKey = targetKey,
							$temp$dict = right;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
				}
			}
		}
	});
var $elm$core$Dict$getMin = function (dict) {
	getMin:
	while (true) {
		if ((dict.$ === 'RBNode_elm_builtin') && (dict.d.$ === 'RBNode_elm_builtin')) {
			var left = dict.d;
			var $temp$dict = left;
			dict = $temp$dict;
			continue getMin;
		} else {
			return dict;
		}
	}
};
var $elm$core$Dict$moveRedLeft = function (dict) {
	if (((dict.$ === 'RBNode_elm_builtin') && (dict.d.$ === 'RBNode_elm_builtin')) && (dict.e.$ === 'RBNode_elm_builtin')) {
		if ((dict.e.d.$ === 'RBNode_elm_builtin') && (dict.e.d.a.$ === 'Red')) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var lLeft = _v1.d;
			var lRight = _v1.e;
			var _v2 = dict.e;
			var rClr = _v2.a;
			var rK = _v2.b;
			var rV = _v2.c;
			var rLeft = _v2.d;
			var _v3 = rLeft.a;
			var rlK = rLeft.b;
			var rlV = rLeft.c;
			var rlL = rLeft.d;
			var rlR = rLeft.e;
			var rRight = _v2.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				$elm$core$Dict$Red,
				rlK,
				rlV,
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, lK, lV, lLeft, lRight),
					rlL),
				A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, rK, rV, rlR, rRight));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v4 = dict.d;
			var lClr = _v4.a;
			var lK = _v4.b;
			var lV = _v4.c;
			var lLeft = _v4.d;
			var lRight = _v4.e;
			var _v5 = dict.e;
			var rClr = _v5.a;
			var rK = _v5.b;
			var rV = _v5.c;
			var rLeft = _v5.d;
			var rRight = _v5.e;
			if (clr.$ === 'Black') {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$moveRedRight = function (dict) {
	if (((dict.$ === 'RBNode_elm_builtin') && (dict.d.$ === 'RBNode_elm_builtin')) && (dict.e.$ === 'RBNode_elm_builtin')) {
		if ((dict.d.d.$ === 'RBNode_elm_builtin') && (dict.d.d.a.$ === 'Red')) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var _v2 = _v1.d;
			var _v3 = _v2.a;
			var llK = _v2.b;
			var llV = _v2.c;
			var llLeft = _v2.d;
			var llRight = _v2.e;
			var lRight = _v1.e;
			var _v4 = dict.e;
			var rClr = _v4.a;
			var rK = _v4.b;
			var rV = _v4.c;
			var rLeft = _v4.d;
			var rRight = _v4.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				$elm$core$Dict$Red,
				lK,
				lV,
				A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, llK, llV, llLeft, llRight),
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					lRight,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, rK, rV, rLeft, rRight)));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v5 = dict.d;
			var lClr = _v5.a;
			var lK = _v5.b;
			var lV = _v5.c;
			var lLeft = _v5.d;
			var lRight = _v5.e;
			var _v6 = dict.e;
			var rClr = _v6.a;
			var rK = _v6.b;
			var rV = _v6.c;
			var rLeft = _v6.d;
			var rRight = _v6.e;
			if (clr.$ === 'Black') {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					$elm$core$Dict$Black,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$removeHelpPrepEQGT = F7(
	function (targetKey, dict, color, key, value, left, right) {
		if ((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Red')) {
			var _v1 = left.a;
			var lK = left.b;
			var lV = left.c;
			var lLeft = left.d;
			var lRight = left.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				lK,
				lV,
				lLeft,
				A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Red, key, value, lRight, right));
		} else {
			_v2$2:
			while (true) {
				if ((right.$ === 'RBNode_elm_builtin') && (right.a.$ === 'Black')) {
					if (right.d.$ === 'RBNode_elm_builtin') {
						if (right.d.a.$ === 'Black') {
							var _v3 = right.a;
							var _v4 = right.d;
							var _v5 = _v4.a;
							return $elm$core$Dict$moveRedRight(dict);
						} else {
							break _v2$2;
						}
					} else {
						var _v6 = right.a;
						var _v7 = right.d;
						return $elm$core$Dict$moveRedRight(dict);
					}
				} else {
					break _v2$2;
				}
			}
			return dict;
		}
	});
var $elm$core$Dict$removeMin = function (dict) {
	if ((dict.$ === 'RBNode_elm_builtin') && (dict.d.$ === 'RBNode_elm_builtin')) {
		var color = dict.a;
		var key = dict.b;
		var value = dict.c;
		var left = dict.d;
		var lColor = left.a;
		var lLeft = left.d;
		var right = dict.e;
		if (lColor.$ === 'Black') {
			if ((lLeft.$ === 'RBNode_elm_builtin') && (lLeft.a.$ === 'Red')) {
				var _v3 = lLeft.a;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					key,
					value,
					$elm$core$Dict$removeMin(left),
					right);
			} else {
				var _v4 = $elm$core$Dict$moveRedLeft(dict);
				if (_v4.$ === 'RBNode_elm_builtin') {
					var nColor = _v4.a;
					var nKey = _v4.b;
					var nValue = _v4.c;
					var nLeft = _v4.d;
					var nRight = _v4.e;
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						$elm$core$Dict$removeMin(nLeft),
						nRight);
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			}
		} else {
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				key,
				value,
				$elm$core$Dict$removeMin(left),
				right);
		}
	} else {
		return $elm$core$Dict$RBEmpty_elm_builtin;
	}
};
var $elm$core$Dict$removeHelp = F2(
	function (targetKey, dict) {
		if (dict.$ === 'RBEmpty_elm_builtin') {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		} else {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_cmp(targetKey, key) < 0) {
				if ((left.$ === 'RBNode_elm_builtin') && (left.a.$ === 'Black')) {
					var _v4 = left.a;
					var lLeft = left.d;
					if ((lLeft.$ === 'RBNode_elm_builtin') && (lLeft.a.$ === 'Red')) {
						var _v6 = lLeft.a;
						return A5(
							$elm$core$Dict$RBNode_elm_builtin,
							color,
							key,
							value,
							A2($elm$core$Dict$removeHelp, targetKey, left),
							right);
					} else {
						var _v7 = $elm$core$Dict$moveRedLeft(dict);
						if (_v7.$ === 'RBNode_elm_builtin') {
							var nColor = _v7.a;
							var nKey = _v7.b;
							var nValue = _v7.c;
							var nLeft = _v7.d;
							var nRight = _v7.e;
							return A5(
								$elm$core$Dict$balance,
								nColor,
								nKey,
								nValue,
								A2($elm$core$Dict$removeHelp, targetKey, nLeft),
								nRight);
						} else {
							return $elm$core$Dict$RBEmpty_elm_builtin;
						}
					}
				} else {
					return A5(
						$elm$core$Dict$RBNode_elm_builtin,
						color,
						key,
						value,
						A2($elm$core$Dict$removeHelp, targetKey, left),
						right);
				}
			} else {
				return A2(
					$elm$core$Dict$removeHelpEQGT,
					targetKey,
					A7($elm$core$Dict$removeHelpPrepEQGT, targetKey, dict, color, key, value, left, right));
			}
		}
	});
var $elm$core$Dict$removeHelpEQGT = F2(
	function (targetKey, dict) {
		if (dict.$ === 'RBNode_elm_builtin') {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_eq(targetKey, key)) {
				var _v1 = $elm$core$Dict$getMin(right);
				if (_v1.$ === 'RBNode_elm_builtin') {
					var minKey = _v1.b;
					var minValue = _v1.c;
					return A5(
						$elm$core$Dict$balance,
						color,
						minKey,
						minValue,
						left,
						$elm$core$Dict$removeMin(right));
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			} else {
				return A5(
					$elm$core$Dict$balance,
					color,
					key,
					value,
					left,
					A2($elm$core$Dict$removeHelp, targetKey, right));
			}
		} else {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		}
	});
var $elm$core$Dict$remove = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$removeHelp, key, dict);
		if ((_v0.$ === 'RBNode_elm_builtin') && (_v0.a.$ === 'Red')) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, $elm$core$Dict$Black, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $author$project$PreviewPaintGate$painted = F2(
	function (raw, model) {
		var ordinal = model.a;
		var pending = model.b;
		var decoder = A2(
			$elm$json$Json$Decode$andThen,
			function (fields) {
				return _Utils_eq(
					A2($elm$core$List$map, $elm$core$Tuple$first, fields),
					_List_fromArray(
						['ticket'])) ? A2($elm$json$Json$Decode$field, 'ticket', $author$project$UInt64$decoder) : $elm$json$Json$Decode$fail('Exact paint ticket');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
		var _v0 = A2(
			$elm$core$Maybe$andThen,
			function (ticket) {
				return A2(
					$elm$core$Maybe$map,
					$elm$core$Tuple$pair(ticket),
					A2($elm$core$Dict$get, ticket, pending));
			},
			A2(
				$elm$core$Maybe$map,
				$author$project$UInt64$string,
				$elm$core$Result$toMaybe(
					A2($elm$json$Json$Decode$decodeValue, decoder, raw))));
		if (_v0.$ === 'Just') {
			var _v1 = _v0.a;
			var ticket = _v1.a;
			var held = _v1.b;
			return _Utils_Tuple2(
				A2(
					$author$project$PreviewPaintGate$Model,
					ordinal,
					A2($elm$core$Dict$remove, ticket, pending)),
				A2(
					$author$project$PreviewPaintGate$encodeBatch,
					held.realm,
					_List_fromArray(
						[
							A2($author$project$PreviewPaintGate$row, held.identity, held.command)
						])));
		} else {
			return _Utils_Tuple2(
				model,
				A2($elm$json$Json$Encode$list, $author$project$PreviewPaintGate$identityValue, _List_Nil));
		}
	});
var $author$project$SurfaceSnapshot$pendingQueryBlocked = function (identity) {
	return A2($elm$core$String$startsWith, 'entry:', identity) || (A2($elm$core$String$startsWith, 'pin:', identity) || (A2($elm$core$String$startsWith, 'unpin:', identity) || (A2($elm$core$String$startsWith, 'pin-left:', identity) || (A2($elm$core$String$startsWith, 'pin-right:', identity) || (A2($elm$core$String$startsWith, 'jump:open:', identity) || ((identity === 'control:page-previous') || ((identity === 'control:page-next') || ((identity === 'files:open-path') || (A2($elm$core$String$startsWith, 'files:collection:', identity) || (identity === 'files:home'))))))))));
};
var $author$project$SurfaceRenderer$pendingQueryBlocked = $author$project$SurfaceSnapshot$pendingQueryBlocked;
var $author$project$NativePreviewProposalIngress$Proposal = F4(
	function (protocol, kind, domain, rows) {
		return {domain: domain, kind: kind, protocol: protocol, rows: rows};
	});
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm$core$List$all = F2(
	function (isOkay, list) {
		return !A2(
			$elm$core$List$any,
			A2($elm$core$Basics$composeL, $elm$core$Basics$not, isOkay),
			list);
	});
var $author$project$NativePreviewProposalIngress$encode = function (intent) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'identity',
				$elm$json$Json$Encode$string(intent.identity)),
				_Utils_Tuple2(
				'commands',
				A2(
					$elm$json$Json$Encode$list,
					$elm$core$Basics$identity,
					_List_fromArray(
						[intent.command])))
			]));
};
var $author$project$NativePreviewProposalIngress$unique = A2(
	$elm$core$List$foldl,
	F2(
		function (intent, rows) {
			return A2(
				$elm$core$List$any,
				$author$project$NativePreviewProposalIngress$sameIntent(intent),
				rows) ? rows : _Utils_ap(
				rows,
				_List_fromArray(
					[intent]));
		}),
	_List_Nil);
var $author$project$NativePreviewProposalIngress$decode = F2(
	function (grant, raw) {
		var decoder = A2(
			$author$project$NativePreviewProposalIngress$strict,
			_List_fromArray(
				['previewProtocol', 'kind', 'binding', 'receiverEpoch', 'entries']),
			A5(
				$elm$json$Json$Decode$map4,
				$author$project$NativePreviewProposalIngress$Proposal,
				A2($elm$json$Json$Decode$field, 'previewProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				$author$project$NativePreviewRealm$domainDecoder,
				A2(
					$elm$json$Json$Decode$field,
					'entries',
					$elm$json$Json$Decode$list($author$project$NativePreviewProposalIngress$intentDecoder))));
		return A2(
			$elm$core$Maybe$andThen,
			function (proposal) {
				return ((proposal.protocol === 3) && ((proposal.kind === 'preview-proposals') && (A2($author$project$NativePreviewRealm$same, proposal.domain, grant.domain) && (($elm$core$List$length(proposal.rows) <= 1065) && A2(
					$elm$core$List$all,
					function (row) {
						return $author$project$NativePreviewProposalIngress$bytes(
							A2(
								$elm$json$Json$Encode$encode,
								0,
								A2(
									$author$project$NativePreviewRealm$commands,
									grant.domain,
									A2(
										$elm$json$Json$Encode$list,
										$author$project$NativePreviewProposalIngress$encode,
										_List_fromArray(
											[row]))))) <= 4096;
					},
					proposal.rows))))) ? $elm$core$Maybe$Just(
					$author$project$NativePreviewProposalIngress$unique(proposal.rows)) : $elm$core$Maybe$Nothing;
			},
			$elm$core$Result$toMaybe(
				A2($elm$json$Json$Decode$decodeValue, decoder, raw)));
	});
var $author$project$RetainedPreviewPresenter$emptyOutput = function (grant) {
	return A2(
		$elm$core$Maybe$withDefault,
		A2($elm$json$Json$Encode$list, $elm$core$Basics$identity, _List_Nil),
		A2(
			$elm$core$Maybe$map,
			function (g) {
				return A2(
					$author$project$NativePreviewRealm$commands,
					g.domain,
					A2($elm$json$Json$Encode$list, $elm$core$Basics$identity, _List_Nil));
			},
			grant));
};
var $author$project$NativePreviewProposalIngress$proposals = function (_v0) {
	var grant = _v0.a;
	var rows = _v0.b;
	return A2(
		$author$project$NativePreviewRealm$commands,
		grant.domain,
		A2($elm$json$Json$Encode$list, $author$project$NativePreviewProposalIngress$encode, rows));
};
var $elm$core$List$drop = F2(
	function (n, list) {
		drop:
		while (true) {
			if (n <= 0) {
				return list;
			} else {
				if (!list.b) {
					return list;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs;
					n = $temp$n;
					list = $temp$list;
					continue drop;
				}
			}
		}
	});
var $elm$core$List$takeReverse = F3(
	function (n, list, kept) {
		takeReverse:
		while (true) {
			if (n <= 0) {
				return kept;
			} else {
				if (!list.b) {
					return kept;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs,
						$temp$kept = A2($elm$core$List$cons, x, kept);
					n = $temp$n;
					list = $temp$list;
					kept = $temp$kept;
					continue takeReverse;
				}
			}
		}
	});
var $elm$core$List$takeTailRec = F2(
	function (n, list) {
		return $elm$core$List$reverse(
			A3($elm$core$List$takeReverse, n, list, _List_Nil));
	});
var $elm$core$List$takeFast = F3(
	function (ctr, n, list) {
		if (n <= 0) {
			return _List_Nil;
		} else {
			var _v0 = _Utils_Tuple2(n, list);
			_v0$1:
			while (true) {
				_v0$5:
				while (true) {
					if (!_v0.b.b) {
						return list;
					} else {
						if (_v0.b.b.b) {
							switch (_v0.a) {
								case 1:
									break _v0$1;
								case 2:
									var _v2 = _v0.b;
									var x = _v2.a;
									var _v3 = _v2.b;
									var y = _v3.a;
									return _List_fromArray(
										[x, y]);
								case 3:
									if (_v0.b.b.b.b) {
										var _v4 = _v0.b;
										var x = _v4.a;
										var _v5 = _v4.b;
										var y = _v5.a;
										var _v6 = _v5.b;
										var z = _v6.a;
										return _List_fromArray(
											[x, y, z]);
									} else {
										break _v0$5;
									}
								default:
									if (_v0.b.b.b.b && _v0.b.b.b.b.b) {
										var _v7 = _v0.b;
										var x = _v7.a;
										var _v8 = _v7.b;
										var y = _v8.a;
										var _v9 = _v8.b;
										var z = _v9.a;
										var _v10 = _v9.b;
										var w = _v10.a;
										var tl = _v10.b;
										return (ctr > 1000) ? A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A2($elm$core$List$takeTailRec, n - 4, tl))))) : A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A3($elm$core$List$takeFast, ctr + 1, n - 4, tl)))));
									} else {
										break _v0$5;
									}
							}
						} else {
							if (_v0.a === 1) {
								break _v0$1;
							} else {
								break _v0$5;
							}
						}
					}
				}
				return list;
			}
			var _v1 = _v0.b;
			var x = _v1.a;
			return _List_fromArray(
				[x]);
		}
	});
var $elm$core$List$take = F2(
	function (n, list) {
		return A3($elm$core$List$takeFast, 0, n, list);
	});
var $author$project$NativePreviewProposalIngress$split = F2(
	function (offered, _v0) {
		var grant = _v0.a;
		var rows = _v0.b;
		var fresh = A2(
			$elm$core$List$filter,
			function (intent) {
				return !A2(
					$elm$core$List$any,
					$author$project$NativePreviewProposalIngress$sameIntent(intent),
					rows);
			},
			$author$project$NativePreviewProposalIngress$unique(offered));
		var available = A2(
			$elm$core$Basics$max,
			0,
			grant.capacity - $elm$core$List$length(rows));
		return _Utils_Tuple2(
			A2(
				$author$project$NativePreviewProposalIngress$Model,
				grant,
				_Utils_ap(
					rows,
					A2($elm$core$List$take, available, fresh))),
			A2($elm$core$List$drop, available, fresh));
	});
var $author$project$RetainedPreviewPresenter$commit = F2(
	function (prior, _v0) {
		var grant = prior.b;
		var ingress = prior.c;
		var deferred = prior.d;
		var candidate = _v0.a;
		var output = _v0.b;
		if (!$elm$core$List$isEmpty(deferred)) {
			return _Utils_Tuple2(
				prior,
				$author$project$RetainedPreviewPresenter$emptyOutput(grant));
		} else {
			var _v1 = _Utils_Tuple2(grant, ingress);
			if ((_v1.a.$ === 'Just') && (_v1.b.$ === 'Just')) {
				var g = _v1.a.a;
				var queue = _v1.b.a;
				var _v2 = A2($author$project$NativePreviewProposalIngress$decode, g, output);
				if (_v2.$ === 'Nothing') {
					return _Utils_Tuple2(
						prior,
						$author$project$RetainedPreviewPresenter$emptyOutput(grant));
				} else {
					var intents = _v2.a;
					var _v3 = A2($author$project$NativePreviewProposalIngress$split, intents, queue);
					var retained = _v3.a;
					var waiting = _v3.b;
					return _Utils_Tuple2(
						A4(
							$author$project$RetainedPreviewPresenter$Model,
							candidate,
							grant,
							$elm$core$Maybe$Just(retained),
							waiting),
						$author$project$NativePreviewProposalIngress$proposals(retained));
				}
			} else {
				return _Utils_Tuple2(
					A4($author$project$RetainedPreviewPresenter$Model, candidate, grant, ingress, deferred),
					output);
			}
		}
	});
var $author$project$NativePreviewSource$PickerFamily = {$: 'PickerFamily'};
var $author$project$PreviewLifecycle$Receipt = F2(
	function (a, b) {
		return {$: 'Receipt', a: a, b: b};
	});
var $author$project$PreviewLifecycle$Attach = F2(
	function (a, b) {
		return {$: 'Attach', a: a, b: b};
	});
var $author$project$PreviewLifecycle$Cancelled = function (a) {
	return {$: 'Cancelled', a: a};
};
var $author$project$PreviewLifecycle$Clock = F3(
	function (a, b, c) {
		return {$: 'Clock', a: a, b: b, c: c};
	});
var $author$project$PreviewLifecycle$Close = {$: 'Close'};
var $author$project$PreviewLifecycle$Exhausted = function (a) {
	return {$: 'Exhausted', a: a};
};
var $author$project$PreviewLifecycle$Expired = function (a) {
	return {$: 'Expired', a: a};
};
var $author$project$PreviewLifecycle$Fence = function (a) {
	return {$: 'Fence', a: a};
};
var $author$project$PreviewLifecycle$Observe = function (a) {
	return {$: 'Observe', a: a};
};
var $author$project$PreviewLifecycle$Offer = function (a) {
	return {$: 'Offer', a: a};
};
var $author$project$PreviewLifecycle$Open = {$: 'Open'};
var $author$project$PreviewLifecycle$Refused = function (a) {
	return {$: 'Refused', a: a};
};
var $author$project$PreviewLifecycle$Released = function (a) {
	return {$: 'Released', a: a};
};
var $author$project$PreviewLifecycle$Request = function (a) {
	return {$: 'Request', a: a};
};
var $author$project$PreviewLifecycle$SourceDenied = F2(
	function (a, b) {
		return {$: 'SourceDenied', a: a, b: b};
	});
var $author$project$PreviewLifecycle$Binding = F3(
	function (lifetime, session, frontend) {
		return {frontend: frontend, lifetime: lifetime, session: session};
	});
var $author$project$PreviewIdentity$Identity = function (a) {
	return {$: 'Identity', a: a};
};
var $author$project$PreviewIdentity$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (counter) {
		return _Utils_eq(counter, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Positive native identity') : $elm$json$Json$Decode$succeed(
			$author$project$PreviewIdentity$Identity(counter));
	},
	$author$project$UInt64$decoder);
var $author$project$PreviewLifecycle$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Preview lifecycle fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$PreviewLifecycle$bindingDecoder = A2(
	$author$project$PreviewLifecycle$strict,
	_List_fromArray(
		['lifetime', 'session', 'frontend']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$PreviewLifecycle$Binding,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'session', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$PreviewIdentity$positive)));
var $author$project$PreviewLifecycle$Job = F6(
	function (binding, context, request, origin, clock, deadline) {
		return {binding: binding, clock: clock, context: context, deadline: deadline, origin: origin, request: request};
	});
var $author$project$PreviewLifecycle$Context = F7(
	function (lifetime, incarnation, output, privacy, rendering, scene, content) {
		return {content: content, incarnation: incarnation, lifetime: lifetime, output: output, privacy: privacy, rendering: rendering, scene: scene};
	});
var $author$project$PreviewLifecycle$contextDecoder = A2(
	$author$project$PreviewLifecycle$strict,
	_List_fromArray(
		['lifetime', 'incarnation', 'output', 'privacy', 'rendering', 'scene', 'content']),
	A8(
		$elm$json$Json$Decode$map7,
		$author$project$PreviewLifecycle$Context,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'output', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'privacy', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'rendering', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'scene', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'content', $author$project$PreviewIdentity$positive)));
var $author$project$PreviewLifecycle$jobDecoder = A2(
	$author$project$PreviewLifecycle$strict,
	_List_fromArray(
		['binding', 'context', 'request', 'origin', 'clock', 'deadline']),
	A7(
		$elm$json$Json$Decode$map6,
		$author$project$PreviewLifecycle$Job,
		A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewLifecycle$bindingDecoder),
		A2($elm$json$Json$Decode$field, 'context', $author$project$PreviewLifecycle$contextDecoder),
		A2($elm$json$Json$Decode$field, 'request', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'origin', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'clock', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'deadline', $author$project$PreviewIdentity$positive)));
var $author$project$PreviewLifecycle$NativeScope = F9(
	function (binding, context, observation, clock, now, present, sourceLive, locked, gpuReady) {
		return {binding: binding, clock: clock, context: context, gpuReady: gpuReady, locked: locked, now: now, observation: observation, present: present, sourceLive: sourceLive};
	});
var $author$project$PreviewLifecycle$nativeScopeDecoder = A2(
	$author$project$PreviewLifecycle$strict,
	_List_fromArray(
		['binding', 'context', 'observation', 'clock', 'now', 'present', 'sourceLive', 'locked', 'gpuReady']),
	A3(
		$elm$json$Json$Decode$map2,
		F2(
			function (constructor, gpu) {
				return constructor(gpu);
			}),
		A9(
			$elm$json$Json$Decode$map8,
			$author$project$PreviewLifecycle$NativeScope,
			A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewLifecycle$bindingDecoder),
			A2($elm$json$Json$Decode$field, 'context', $author$project$PreviewLifecycle$contextDecoder),
			A2($elm$json$Json$Decode$field, 'observation', $author$project$PreviewIdentity$positive),
			A2($elm$json$Json$Decode$field, 'clock', $author$project$PreviewIdentity$positive),
			A2($elm$json$Json$Decode$field, 'now', $author$project$PreviewIdentity$positive),
			A2($elm$json$Json$Decode$field, 'present', $elm$json$Json$Decode$bool),
			A2($elm$json$Json$Decode$field, 'sourceLive', $elm$json$Json$Decode$bool),
			A2($elm$json$Json$Decode$field, 'locked', $elm$json$Json$Decode$bool)),
		A2($elm$json$Json$Decode$field, 'gpuReady', $elm$json$Json$Decode$bool)));
var $author$project$PreviewLifecycle$ClientContent = {$: 'ClientContent'};
var $author$project$PreviewLifecycle$ComposedFamily = {$: 'ComposedFamily'};
var $author$project$PreviewLifecycle$LeaseHandle = function (a) {
	return {$: 'LeaseHandle', a: a};
};
var $author$project$PreviewLifecycle$Packet = F7(
	function (job, handle, owned, signaled, fidelity, coverage, expires) {
		return {coverage: coverage, expires: expires, fidelity: fidelity, handle: handle, job: job, owned: owned, signaled: signaled};
	});
var $elm$core$Dict$diff = F2(
	function (t1, t2) {
		return A3(
			$elm$core$Dict$foldl,
			F3(
				function (k, v, t) {
					return A2($elm$core$Dict$remove, k, t);
				}),
			t1,
			t2);
	});
var $elm$core$Set$diff = F2(
	function (_v0, _v1) {
		var dict1 = _v0.a;
		var dict2 = _v1.a;
		return $elm$core$Set$Set_elm_builtin(
			A2($elm$core$Dict$diff, dict1, dict2));
	});
var $elm$core$Set$isEmpty = function (_v0) {
	var dict = _v0.a;
	return $elm$core$Dict$isEmpty(dict);
};
var $elm$core$Bitwise$and = _Bitwise_and;
var $elm$core$Bitwise$shiftRightBy = _Bitwise_shiftRightBy;
var $elm$core$String$repeatHelp = F3(
	function (n, chunk, result) {
		return (n <= 0) ? result : A3(
			$elm$core$String$repeatHelp,
			n >> 1,
			_Utils_ap(chunk, chunk),
			(!(n & 1)) ? result : _Utils_ap(result, chunk));
	});
var $elm$core$String$repeat = F2(
	function (n, chunk) {
		return A3($elm$core$String$repeatHelp, n, chunk, '');
	});
var $author$project$PreviewLifecycle$opaqueDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (($elm$core$String$length(value) === 64) && ((!_Utils_eq(
			value,
			A2($elm$core$String$repeat, 64, '0'))) && A2(
			$elm$core$String$all,
			function (c) {
				return ((_Utils_cmp(
					c,
					_Utils_chr('0')) > -1) && (_Utils_cmp(
					c,
					_Utils_chr('9')) < 1)) || ((_Utils_cmp(
					c,
					_Utils_chr('a')) > -1) && (_Utils_cmp(
					c,
					_Utils_chr('f')) < 1));
			},
			value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Opaque native resource token');
	},
	$elm$json$Json$Decode$string);
var $author$project$PreviewLifecycle$packetDecoder = function () {
	var fidelity = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			switch (value) {
				case 'client':
					return $elm$json$Json$Decode$succeed($author$project$PreviewLifecycle$ClientContent);
				case 'family':
					return $elm$json$Json$Decode$succeed($author$project$PreviewLifecycle$ComposedFamily);
				default:
					return $elm$json$Json$Decode$fail('Preview fidelity');
			}
		},
		$elm$json$Json$Decode$string);
	var coverage = A2(
		$elm$json$Json$Decode$andThen,
		function (values) {
			var unique = $elm$core$Set$fromList(values);
			return (($elm$core$List$length(values) <= 4) && (_Utils_eq(
				$elm$core$List$length(values),
				$elm$core$Set$size(unique)) && $elm$core$Set$isEmpty(
				A2(
					$elm$core$Set$diff,
					unique,
					$elm$core$Set$fromList(
						_List_fromArray(
							['client', 'decoration', 'modal', 'popup'])))))) ? $elm$json$Json$Decode$succeed(unique) : $elm$json$Json$Decode$fail('Preview coverage');
		},
		$elm$json$Json$Decode$list($elm$json$Json$Decode$string));
	return A2(
		$author$project$PreviewLifecycle$strict,
		_List_fromArray(
			['job', 'handle', 'owned', 'signaled', 'fidelity', 'coverage', 'expires']),
		A8(
			$elm$json$Json$Decode$map7,
			$author$project$PreviewLifecycle$Packet,
			A2($elm$json$Json$Decode$field, 'job', $author$project$PreviewLifecycle$jobDecoder),
			A2(
				$elm$json$Json$Decode$field,
				'handle',
				A2($elm$json$Json$Decode$map, $author$project$PreviewLifecycle$LeaseHandle, $author$project$PreviewLifecycle$opaqueDecoder)),
			A2($elm$json$Json$Decode$field, 'owned', $elm$json$Json$Decode$bool),
			A2($elm$json$Json$Decode$field, 'signaled', $elm$json$Json$Decode$bool),
			A2($elm$json$Json$Decode$field, 'fidelity', fidelity),
			A2($elm$json$Json$Decode$field, 'coverage', coverage),
			A2($elm$json$Json$Decode$field, 'expires', $author$project$PreviewIdentity$positive)));
}();
var $author$project$PreviewLifecycle$Trigger = F5(
	function (binding, context, origin, clock, deadline) {
		return {binding: binding, clock: clock, context: context, deadline: deadline, origin: origin};
	});
var $author$project$PreviewLifecycle$triggerDecoder = A2(
	$author$project$PreviewLifecycle$strict,
	_List_fromArray(
		['binding', 'context', 'origin', 'clock', 'deadline']),
	A6(
		$elm$json$Json$Decode$map5,
		$author$project$PreviewLifecycle$Trigger,
		A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewLifecycle$bindingDecoder),
		A2($elm$json$Json$Decode$field, 'context', $author$project$PreviewLifecycle$contextDecoder),
		A2($elm$json$Json$Decode$field, 'origin', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'clock', $author$project$PreviewIdentity$positive),
		A2($elm$json$Json$Decode$field, 'deadline', $author$project$PreviewIdentity$positive)));
var $author$project$PreviewLifecycle$basicDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		switch (kind) {
			case 'open':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind']),
					$elm$json$Json$Decode$succeed($author$project$PreviewLifecycle$Open));
			case 'close':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind']),
					$elm$json$Json$Decode$succeed($author$project$PreviewLifecycle$Close));
			case 'request':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'trigger']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Request,
						A2($elm$json$Json$Decode$field, 'trigger', $author$project$PreviewLifecycle$triggerDecoder)));
			case 'offer':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'frame']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Offer,
						A2($elm$json$Json$Decode$field, 'frame', $author$project$PreviewLifecycle$packetDecoder)));
			case 'fence':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'frame']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Fence,
						A2($elm$json$Json$Decode$field, 'frame', $author$project$PreviewLifecycle$packetDecoder)));
			case 'observe':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'scope']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Observe,
						A2($elm$json$Json$Decode$field, 'scope', $author$project$PreviewLifecycle$nativeScopeDecoder)));
			case 'source-denied':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'job', 'reason']),
					A3(
						$elm$json$Json$Decode$map2,
						$author$project$PreviewLifecycle$SourceDenied,
						A2($elm$json$Json$Decode$field, 'job', $author$project$PreviewLifecycle$jobDecoder),
						A2(
							$elm$json$Json$Decode$field,
							'reason',
							A2(
								$elm$json$Json$Decode$andThen,
								function (reason) {
									return A2(
										$elm$core$List$member,
										reason,
										_List_fromArray(
											['locked', 'source-unavailable', 'output-unavailable', 'layout-unsupported'])) ? $elm$json$Json$Decode$succeed(reason) : $elm$json$Json$Decode$fail('Typed native source denial');
								},
								$elm$json$Json$Decode$string))));
			case 'attach':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'previous', 'scope']),
					A3(
						$elm$json$Json$Decode$map2,
						$author$project$PreviewLifecycle$Attach,
						A2($elm$json$Json$Decode$field, 'previous', $author$project$PreviewLifecycle$bindingDecoder),
						A2($elm$json$Json$Decode$field, 'scope', $author$project$PreviewLifecycle$nativeScopeDecoder)));
			case 'clock':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'binding', 'clock', 'now']),
					A4(
						$elm$json$Json$Decode$map3,
						$author$project$PreviewLifecycle$Clock,
						A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewLifecycle$bindingDecoder),
						A2($elm$json$Json$Decode$field, 'clock', $author$project$PreviewIdentity$positive),
						A2($elm$json$Json$Decode$field, 'now', $author$project$PreviewIdentity$positive)));
			case 'cancelled':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'job']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Cancelled,
						A2($elm$json$Json$Decode$field, 'job', $author$project$PreviewLifecycle$jobDecoder)));
			case 'released':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'frame']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Released,
						A2($elm$json$Json$Decode$field, 'frame', $author$project$PreviewLifecycle$packetDecoder)));
			case 'expired':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'frame']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Expired,
						A2($elm$json$Json$Decode$field, 'frame', $author$project$PreviewLifecycle$packetDecoder)));
			case 'exhausted':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'binding']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Exhausted,
						A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewLifecycle$bindingDecoder)));
			case 'refused':
				return A2(
					$author$project$PreviewLifecycle$strict,
					_List_fromArray(
						['kind', 'job']),
					A2(
						$elm$json$Json$Decode$map,
						$author$project$PreviewLifecycle$Refused,
						A2($elm$json$Json$Decode$field, 'job', $author$project$PreviewLifecycle$jobDecoder)));
			default:
				return $elm$json$Json$Decode$fail('Preview lifecycle event');
		}
	},
	A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
var $author$project$PreviewLifecycle$terminalJob = function (event) {
	switch (event.$) {
		case 'Cancelled':
			var job = event.a;
			return $elm$core$Maybe$Just(job);
		case 'Released':
			var frame = event.a;
			return $elm$core$Maybe$Just(frame.job);
		case 'Refused':
			var job = event.a;
			return $elm$core$Maybe$Just(job);
		default:
			return $elm$core$Maybe$Nothing;
	}
};
var $author$project$PreviewLifecycle$eventDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		if (kind === 'receipt') {
			var terminal = A2(
				$elm$json$Json$Decode$andThen,
				function (event) {
					return (!_Utils_eq(
						$author$project$PreviewLifecycle$terminalJob(event),
						$elm$core$Maybe$Nothing)) ? $elm$json$Json$Decode$succeed(event) : $elm$json$Json$Decode$fail('Terminal native receipt body');
				},
				$author$project$PreviewLifecycle$basicDecoder);
			return A2(
				$author$project$PreviewLifecycle$strict,
				_List_fromArray(
					['kind', 'sequence', 'event']),
				A3(
					$elm$json$Json$Decode$map2,
					$author$project$PreviewLifecycle$Receipt,
					A2($elm$json$Json$Decode$field, 'sequence', $author$project$PreviewIdentity$positive),
					A2($elm$json$Json$Decode$field, 'event', terminal)));
		} else {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (event) {
					return _Utils_eq(
						$author$project$PreviewLifecycle$terminalJob(event),
						$elm$core$Maybe$Nothing) ? $elm$json$Json$Decode$succeed(event) : $elm$json$Json$Decode$fail('Native cleanup receipt identity required');
				},
				$author$project$PreviewLifecycle$basicDecoder);
		}
	},
	A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
var $author$project$PreviewLifecycle$Acknowledge = F2(
	function (a, b) {
		return {$: 'Acknowledge', a: a, b: b};
	});
var $author$project$PreviewLifecycle$Model = function (a) {
	return {$: 'Model', a: a};
};
var $author$project$PreviewLifecycle$Accepted = function (a) {
	return {$: 'Accepted', a: a};
};
var $author$project$PreviewLifecycle$Acquire = function (a) {
	return {$: 'Acquire', a: a};
};
var $author$project$PreviewLifecycle$Capturing = function (a) {
	return {$: 'Capturing', a: a};
};
var $author$project$PreviewLifecycle$Connected = {$: 'Connected'};
var $author$project$PreviewLifecycle$Idle = {$: 'Idle'};
var $author$project$PreviewLifecycle$NeedsReconciliation = {$: 'NeedsReconciliation'};
var $author$project$PreviewLifecycle$SourceSuspended = {$: 'SourceSuspended'};
var $author$project$PreviewLifecycle$acceptedPacket = function (st) {
	return A2(
		$elm$core$Maybe$map,
		function (_v0) {
			var packet = _v0.a;
			return packet;
		},
		st.accepted);
};
var $author$project$PreviewLifecycle$Cancel = function (a) {
	return {$: 'Cancel', a: a};
};
var $author$project$PreviewLifecycle$emit = F2(
	function (command, work) {
		return _Utils_update(
			work,
			{
				effects: _Utils_ap(
					work.effects,
					_List_fromArray(
						[command]))
			});
	});
var $author$project$PreviewLifecycle$mapState = F2(
	function (f, work) {
		return _Utils_update(
			work,
			{
				state: f(work.state)
			});
	});
var $author$project$PreviewLifecycle$cancelCurrent = function (work) {
	var _v0 = work.state.capture;
	if (_v0.$ === 'Capturing') {
		var job = _v0.a;
		var cleared = A2(
			$author$project$PreviewLifecycle$mapState,
			function (st) {
				return _Utils_update(
					st,
					{capture: $author$project$PreviewLifecycle$Idle});
			},
			work);
		return A2($elm$core$List$member, job, work.state.cancelling) ? cleared : A2(
			$author$project$PreviewLifecycle$emit,
			$author$project$PreviewLifecycle$Cancel(job),
			A2(
				$author$project$PreviewLifecycle$mapState,
				function (st) {
					return _Utils_update(
						st,
						{
							cancelling: A2($elm$core$List$cons, job, st.cancelling)
						});
				},
				cleared));
	} else {
		return work;
	}
};
var $author$project$PreviewLifecycle$candidate = function (st) {
	var _v0 = st.capture;
	if (_v0.$ === 'WaitingFence') {
		var frame = _v0.a.a;
		return $elm$core$Maybe$Just(frame);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$PreviewIdentity$compare = F2(
	function (_v0, _v1) {
		var a = _v0.a;
		var b = _v1.a;
		return A2($author$project$UInt64$compare, a, b);
	});
var $author$project$PreviewLifecycle$notAfter = F2(
	function (a, b) {
		return !_Utils_eq(
			A2($author$project$PreviewIdentity$compare, a, b),
			$elm$core$Basics$GT);
	});
var $author$project$PreviewLifecycle$Release = function (a) {
	return {$: 'Release', a: a};
};
var $author$project$PreviewLifecycle$sameLease = F2(
	function (a, b) {
		return _Utils_eq(a.job, b.job) && _Utils_eq(a.handle, b.handle);
	});
var $author$project$PreviewLifecycle$retirePacket = F2(
	function (frame, work) {
		return A2(
			$elm$core$List$any,
			$author$project$PreviewLifecycle$sameLease(frame),
			work.state.retiring) ? work : A2(
			$author$project$PreviewLifecycle$emit,
			$author$project$PreviewLifecycle$Release(frame),
			A2(
				$author$project$PreviewLifecycle$mapState,
				function (st) {
					return _Utils_update(
						st,
						{
							retiring: A2($elm$core$List$cons, frame, st.retiring)
						});
				},
				work));
	});
var $author$project$PreviewLifecycle$retireAccepted = function (work) {
	var _v0 = $author$project$PreviewLifecycle$acceptedPacket(work.state);
	if (_v0.$ === 'Just') {
		var frame = _v0.a;
		return A2(
			$author$project$PreviewLifecycle$retirePacket,
			frame,
			A2(
				$author$project$PreviewLifecycle$mapState,
				function (st) {
					return _Utils_update(
						st,
						{accepted: $elm$core$Maybe$Nothing});
				},
				work));
	} else {
		return work;
	}
};
var $author$project$PreviewLifecycle$retireCandidate = function (work) {
	var _v0 = $author$project$PreviewLifecycle$candidate(work.state);
	if (_v0.$ === 'Just') {
		var frame = _v0.a;
		return A2(
			$author$project$PreviewLifecycle$retirePacket,
			frame,
			A2(
				$author$project$PreviewLifecycle$mapState,
				function (st) {
					return _Utils_update(
						st,
						{capture: $author$project$PreviewLifecycle$Idle});
				},
				work));
	} else {
		return work;
	}
};
var $author$project$PreviewLifecycle$advanceClock = F2(
	function (now, work) {
		var timed = A2(
			$author$project$PreviewLifecycle$mapState,
			function (st) {
				var sc = st.scope;
				return _Utils_update(
					st,
					{
						scope: _Utils_update(
							sc,
							{now: now})
					});
			},
			work);
		var jobTimed = function () {
			var _v2 = timed.state.capture;
			if (_v2.$ === 'Capturing') {
				var job = _v2.a;
				return A2($author$project$PreviewLifecycle$notAfter, job.deadline, now) ? $author$project$PreviewLifecycle$cancelCurrent(timed) : timed;
			} else {
				return timed;
			}
		}();
		var candidateTimed = function () {
			var _v1 = $author$project$PreviewLifecycle$candidate(jobTimed.state);
			if (_v1.$ === 'Just') {
				var frame = _v1.a;
				return (A2($author$project$PreviewLifecycle$notAfter, frame.job.deadline, now) || A2($author$project$PreviewLifecycle$notAfter, frame.expires, now)) ? $author$project$PreviewLifecycle$retireCandidate(jobTimed) : jobTimed;
			} else {
				return jobTimed;
			}
		}();
		var _v0 = $author$project$PreviewLifecycle$acceptedPacket(candidateTimed.state);
		if (_v0.$ === 'Just') {
			var frame = _v0.a;
			return A2($author$project$PreviewLifecycle$notAfter, frame.expires, now) ? $author$project$PreviewLifecycle$retireAccepted(candidateTimed) : candidateTimed;
		} else {
			return candidateTimed;
		}
	});
var $author$project$PreviewLifecycle$before = F2(
	function (a, b) {
		return _Utils_eq(
			A2($author$project$PreviewIdentity$compare, a, b),
			$elm$core$Basics$LT);
	});
var $author$project$PreviewLifecycle$generationMatches = F2(
	function (a, b) {
		return _Utils_eq(a.lifetime, b.lifetime) && (_Utils_eq(a.incarnation, b.incarnation) && (_Utils_eq(a.output, b.output) && (_Utils_eq(a.privacy, b.privacy) && _Utils_eq(a.rendering, b.rendering))));
	});
var $elm$core$Dict$member = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$get, key, dict);
		if (_v0.$ === 'Just') {
			return true;
		} else {
			return false;
		}
	});
var $elm$core$Set$member = F2(
	function (key, _v0) {
		var dict = _v0.a;
		return A2($elm$core$Dict$member, key, dict);
	});
var $author$project$PreviewLifecycle$authorized = F2(
	function (st, frame) {
		return _Utils_eq(st.connection, $author$project$PreviewLifecycle$Connected) && (st.scope.present && ((!st.scope.locked) && (st.scope.gpuReady && (frame.owned && (_Utils_eq(frame.job.binding, st.scope.binding) && (_Utils_eq(frame.job.clock, st.scope.clock) && (A2($author$project$PreviewLifecycle$generationMatches, st.scope.context, frame.job.context) && (A2($author$project$PreviewLifecycle$notAfter, frame.job.context.scene, st.scope.context.scene) && (A2($author$project$PreviewLifecycle$notAfter, frame.job.context.content, st.scope.context.content) && (A2($author$project$PreviewLifecycle$before, st.scope.now, frame.expires) && (A2($elm$core$Set$member, 'client', frame.coverage) && (_Utils_eq(frame.fidelity, $author$project$PreviewLifecycle$ClientContent) || _Utils_eq(
			frame.coverage,
			$elm$core$Set$fromList(
				_List_fromArray(
					['client', 'decoration', 'modal', 'popup'])))))))))))))));
	});
var $author$project$PreviewLifecycle$finishKnown = F2(
	function (job, work) {
		var st = work.state;
		var captureMatches = function () {
			var _v0 = st.capture;
			switch (_v0.$) {
				case 'Capturing':
					var current = _v0.a;
					return _Utils_eq(current, job);
				case 'WaitingFence':
					var current = _v0.a.a;
					return _Utils_eq(current.job, job);
				default:
					return false;
			}
		}();
		var stillHeld = captureMatches || (A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (f) {
					return _Utils_eq(f.job, job);
				},
				$author$project$PreviewLifecycle$acceptedPacket(st))) || (A2($elm$core$List$member, job, st.cancelling) || A2(
			$elm$core$List$any,
			function (f) {
				return _Utils_eq(f.job, job);
			},
			st.retiring)));
		return stillHeld ? work : A2(
			$author$project$PreviewLifecycle$mapState,
			function (state) {
				return _Utils_update(
					state,
					{
						known: A2(
							$elm$core$List$filter,
							$elm$core$Basics$neq(job),
							state.known)
					});
			},
			work);
	});
var $author$project$PreviewIdentity$nextRequest = function (_v0) {
	var counter = _v0.a;
	return A2(
		$elm$core$Maybe$map,
		$author$project$PreviewIdentity$Identity,
		$author$project$UInt64$next(counter));
};
var $author$project$PreviewLifecycle$Candidate = function (a) {
	return {$: 'Candidate', a: a};
};
var $author$project$PreviewLifecycle$WaitingFence = function (a) {
	return {$: 'WaitingFence', a: a};
};
var $author$project$PreviewLifecycle$heldHandle = F2(
	function (st, handle) {
		return A2(
			$elm$core$List$any,
			function (packet) {
				return _Utils_eq(packet.handle, handle);
			},
			_Utils_ap(
				A2(
					$elm$core$List$filterMap,
					$elm$core$Basics$identity,
					_List_fromArray(
						[
							$author$project$PreviewLifecycle$candidate(st),
							$author$project$PreviewLifecycle$acceptedPacket(st)
						])),
				st.retiring));
	});
var $author$project$PreviewLifecycle$offer = F2(
	function (frame, work) {
		var st = work.state;
		var matches = function () {
			var _v1 = st.capture;
			if (_v1.$ === 'Capturing') {
				var job = _v1.a;
				return st.demand && (_Utils_eq(job, frame.job) && (A2($author$project$PreviewLifecycle$authorized, st, frame) && (A2($author$project$PreviewLifecycle$before, st.scope.now, frame.job.deadline) && (!A2($author$project$PreviewLifecycle$heldHandle, st, frame.handle)))));
			} else {
				return false;
			}
		}();
		if (matches) {
			return frame.signaled ? A2(
				$author$project$PreviewLifecycle$mapState,
				function (state) {
					return _Utils_update(
						state,
						{
							accepted: $elm$core$Maybe$Just(
								$author$project$PreviewLifecycle$Accepted(frame)),
							capture: $author$project$PreviewLifecycle$Idle
						});
				},
				$author$project$PreviewLifecycle$retireAccepted(work)) : A2(
				$author$project$PreviewLifecycle$mapState,
				function (state) {
					return _Utils_update(
						state,
						{
							capture: $author$project$PreviewLifecycle$WaitingFence(
								$author$project$PreviewLifecycle$Candidate(frame))
						});
				},
				work);
		} else {
			if (A2($elm$core$List$member, frame.job, st.known) && (frame.owned && (!A2($author$project$PreviewLifecycle$heldHandle, st, frame.handle)))) {
				var cleanup = A2($author$project$PreviewLifecycle$retirePacket, frame, work);
				var _v0 = cleanup.state.capture;
				if (_v0.$ === 'Capturing') {
					var job = _v0.a;
					return _Utils_eq(job, frame.job) ? $author$project$PreviewLifecycle$cancelCurrent(cleanup) : cleanup;
				} else {
					return cleanup;
				}
			} else {
				return work;
			}
		}
	});
var $author$project$PreviewLifecycle$Reconcile = function (a) {
	return {$: 'Reconcile', a: a};
};
var $author$project$PreviewLifecycle$revoke = A2(
	$elm$core$Basics$composeR,
	$author$project$PreviewLifecycle$cancelCurrent,
	A2($elm$core$Basics$composeR, $author$project$PreviewLifecycle$retireCandidate, $author$project$PreviewLifecycle$retireAccepted));
var $author$project$PreviewLifecycle$reconcile = function (work) {
	return A2(
		$author$project$PreviewLifecycle$emit,
		$author$project$PreviewLifecycle$Reconcile(work.state.scope.binding),
		A2(
			$author$project$PreviewLifecycle$mapState,
			function (st) {
				return _Utils_update(
					st,
					{connection: $author$project$PreviewLifecycle$NeedsReconciliation});
			},
			$author$project$PreviewLifecycle$revoke(work)));
};
var $author$project$PreviewLifecycle$scopeCoherent = F2(
	function (previous, incoming) {
		return A2($author$project$PreviewLifecycle$notAfter, previous.context.output, incoming.context.output) && (A2($author$project$PreviewLifecycle$notAfter, previous.context.privacy, incoming.context.privacy) && (A2($author$project$PreviewLifecycle$notAfter, previous.context.rendering, incoming.context.rendering) && ((!_Utils_eq(incoming.context.incarnation, previous.context.incarnation)) || (A2($author$project$PreviewLifecycle$notAfter, previous.context.scene, incoming.context.scene) && (A2($author$project$PreviewLifecycle$notAfter, previous.context.content, incoming.context.content) && (_Utils_eq(incoming.sourceLive, previous.sourceLive) || A2($author$project$PreviewLifecycle$before, previous.context.scene, incoming.context.scene)))))));
	});
var $author$project$PreviewLifecycle$scopeValid = F2(
	function (previous, incoming) {
		return _Utils_eq(incoming.binding, previous.binding) && (_Utils_eq(incoming.clock, previous.clock) && (_Utils_eq(incoming.context.lifetime, incoming.binding.lifetime) && (A2($author$project$PreviewLifecycle$notAfter, previous.now, incoming.now) && A2($author$project$PreviewLifecycle$before, previous.observation, incoming.observation))));
	});
var $author$project$PreviewIdentity$zeroRequest = $author$project$PreviewIdentity$Identity($author$project$UInt64$zero);
var $author$project$PreviewLifecycle$updatePlain = F2(
	function (event, _v0) {
		var initial = _v0.a;
		var base = {effects: _List_Nil, state: initial};
		var _final = function () {
			switch (event.$) {
				case 'Open':
					return A2(
						$author$project$PreviewLifecycle$mapState,
						function (st) {
							return _Utils_update(
								st,
								{demand: true});
						},
						base);
				case 'Close':
					return A2(
						$author$project$PreviewLifecycle$mapState,
						function (st) {
							return _Utils_update(
								st,
								{demand: false});
						},
						$author$project$PreviewLifecycle$retireCandidate(
							$author$project$PreviewLifecycle$cancelCurrent(base)));
				case 'Request':
					var trigger = event.a;
					if (_Utils_eq(initial.connection, $author$project$PreviewLifecycle$Connected) && (initial.demand && (initial.scope.present && (initial.scope.sourceLive && ((!initial.scope.locked) && (initial.scope.gpuReady && (_Utils_eq(initial.capture, $author$project$PreviewLifecycle$Idle) && ($elm$core$List$isEmpty(initial.cancelling) && ($elm$core$List$isEmpty(initial.retiring) && (_Utils_eq(trigger.binding, initial.scope.binding) && (_Utils_eq(trigger.context, initial.scope.context) && (_Utils_eq(trigger.clock, initial.scope.clock) && A2($author$project$PreviewLifecycle$before, initial.scope.now, trigger.deadline))))))))))))) {
						var _v2 = initial.nextRequest;
						if (_v2.$ === 'Just') {
							var request = _v2.a;
							var job = {binding: initial.scope.binding, clock: initial.scope.clock, context: initial.scope.context, deadline: trigger.deadline, origin: trigger.origin, request: request};
							return A2(
								$author$project$PreviewLifecycle$emit,
								$author$project$PreviewLifecycle$Acquire(job),
								A2(
									$author$project$PreviewLifecycle$mapState,
									function (st) {
										return _Utils_update(
											st,
											{
												capture: $author$project$PreviewLifecycle$Capturing(job),
												known: A2($elm$core$List$cons, job, st.known),
												nextRequest: $author$project$PreviewIdentity$nextRequest(request)
											});
									},
									base));
						} else {
							return base;
						}
					} else {
						return base;
					}
				case 'Offer':
					var frame = event.a;
					return A2($author$project$PreviewLifecycle$offer, frame, base);
				case 'Fence':
					var incoming = event.a;
					var _v3 = $author$project$PreviewLifecycle$candidate(initial);
					if (_v3.$ === 'Just') {
						var frame = _v3.a;
						return (A2($author$project$PreviewLifecycle$sameLease, frame, incoming) && (initial.demand && (A2($author$project$PreviewLifecycle$authorized, initial, frame) && A2($author$project$PreviewLifecycle$before, initial.scope.now, frame.job.deadline)))) ? A2(
							$author$project$PreviewLifecycle$mapState,
							function (st) {
								return _Utils_update(
									st,
									{
										accepted: $elm$core$Maybe$Just(
											$author$project$PreviewLifecycle$Accepted(
												_Utils_update(
													frame,
													{signaled: true}))),
										capture: $author$project$PreviewLifecycle$Idle
									});
							},
							$author$project$PreviewLifecycle$retireAccepted(base)) : base;
					} else {
						return base;
					}
				case 'Observe':
					var incoming = event.a;
					if (!A2($author$project$PreviewLifecycle$scopeValid, initial.scope, incoming)) {
						return base;
					} else {
						if (!A2($author$project$PreviewLifecycle$scopeCoherent, initial.scope, incoming)) {
							return $author$project$PreviewLifecycle$reconcile(base);
						} else {
							var changed = ((!A2($author$project$PreviewLifecycle$generationMatches, initial.scope.context, incoming.context)) || ((!incoming.present) || (incoming.locked || (!incoming.gpuReady)))) ? $author$project$PreviewLifecycle$revoke(base) : base;
							return A2(
								$author$project$PreviewLifecycle$advanceClock,
								incoming.now,
								A2(
									$author$project$PreviewLifecycle$mapState,
									function (st) {
										return _Utils_update(
											st,
											{
												connection: (_Utils_eq(st.connection, $author$project$PreviewLifecycle$SourceSuspended) && (incoming.present && ((!incoming.locked) && incoming.gpuReady))) ? $author$project$PreviewLifecycle$Connected : st.connection,
												metadataHidden: incoming.locked,
												scope: incoming
											});
									},
									changed));
						}
					}
				case 'SourceDenied':
					var job = event.a;
					var reason = event.b;
					var current = function () {
						var _v4 = initial.capture;
						switch (_v4.$) {
							case 'Capturing':
								var active = _v4.a;
								return _Utils_eq(active, job);
							case 'WaitingFence':
								var frame = _v4.a.a;
								return _Utils_eq(frame.job, job);
							default:
								return false;
						}
					}();
					var accepted = _Utils_eq(initial.capture, $author$project$PreviewLifecycle$Idle) && A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (frame) {
								return _Utils_eq(frame.job, job);
							},
							$author$project$PreviewLifecycle$acceptedPacket(initial)));
					return (_Utils_eq(job.binding, initial.scope.binding) && (A2($elm$core$List$member, job, initial.known) && (current || accepted))) ? A2(
						$author$project$PreviewLifecycle$mapState,
						function (st) {
							return _Utils_update(
								st,
								{
									connection: _Utils_eq(st.connection, $author$project$PreviewLifecycle$NeedsReconciliation) ? $author$project$PreviewLifecycle$NeedsReconciliation : $author$project$PreviewLifecycle$SourceSuspended,
									metadataHidden: st.metadataHidden || (reason === 'locked')
								});
						},
						$author$project$PreviewLifecycle$revoke(base)) : base;
				case 'Attach':
					var previous = event.a;
					var incoming = event.b;
					return (_Utils_eq(previous, initial.scope.binding) && ((!_Utils_eq(incoming.binding, previous)) && _Utils_eq(incoming.context.lifetime, incoming.binding.lifetime))) ? A2(
						$author$project$PreviewLifecycle$mapState,
						function (st) {
							return _Utils_update(
								st,
								{
									connection: $author$project$PreviewLifecycle$Connected,
									metadataHidden: incoming.locked,
									nextRequest: $author$project$PreviewIdentity$nextRequest($author$project$PreviewIdentity$zeroRequest),
									scope: incoming
								});
						},
						$author$project$PreviewLifecycle$revoke(base)) : base;
				case 'Clock':
					var binding = event.a;
					var clock = event.b;
					var now = event.c;
					return (_Utils_eq(binding, initial.scope.binding) && (_Utils_eq(clock, initial.scope.clock) && A2($author$project$PreviewLifecycle$before, initial.scope.now, now))) ? A2($author$project$PreviewLifecycle$advanceClock, now, base) : base;
				case 'Cancelled':
					var job = event.a;
					return A2($elm$core$List$member, job, initial.cancelling) ? A2(
						$author$project$PreviewLifecycle$finishKnown,
						job,
						A2(
							$author$project$PreviewLifecycle$mapState,
							function (st) {
								return _Utils_update(
									st,
									{
										cancelling: A2(
											$elm$core$List$filter,
											$elm$core$Basics$neq(job),
											st.cancelling),
										retiring: A2(
											$elm$core$List$filter,
											function (f) {
												return !_Utils_eq(f.job, job);
											},
											st.retiring)
									});
							},
							base)) : base;
				case 'Released':
					var frame = event.a;
					return A2(
						$elm$core$List$any,
						$author$project$PreviewLifecycle$sameLease(frame),
						initial.retiring) ? A2(
						$author$project$PreviewLifecycle$finishKnown,
						frame.job,
						A2(
							$author$project$PreviewLifecycle$mapState,
							function (st) {
								return _Utils_update(
									st,
									{
										retiring: A2(
											$elm$core$List$filter,
											A2(
												$elm$core$Basics$composeR,
												$author$project$PreviewLifecycle$sameLease(frame),
												$elm$core$Basics$not),
											st.retiring)
									});
							},
							base)) : base;
				case 'Expired':
					var frame = event.a;
					return A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							$author$project$PreviewLifecycle$sameLease(frame),
							$author$project$PreviewLifecycle$candidate(initial))) ? $author$project$PreviewLifecycle$retireCandidate(base) : (A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							$author$project$PreviewLifecycle$sameLease(frame),
							$author$project$PreviewLifecycle$acceptedPacket(initial))) ? $author$project$PreviewLifecycle$retireAccepted(base) : base);
				case 'Exhausted':
					var binding = event.a;
					return _Utils_eq(binding, initial.scope.binding) ? $author$project$PreviewLifecycle$reconcile(base) : base;
				case 'Receipt':
					return base;
				default:
					var job = event.a;
					var _v5 = initial.capture;
					if (_v5.$ === 'Capturing') {
						var current = _v5.a;
						return _Utils_eq(current, job) ? A2(
							$author$project$PreviewLifecycle$finishKnown,
							job,
							A2(
								$author$project$PreviewLifecycle$mapState,
								function (st) {
									return _Utils_update(
										st,
										{capture: $author$project$PreviewLifecycle$Idle});
								},
								base)) : base;
					} else {
						return base;
					}
			}
		}();
		return _Utils_Tuple2(
			$author$project$PreviewLifecycle$Model(_final.state),
			_final.effects);
	});
var $author$project$PreviewLifecycle$update = F2(
	function (event, model) {
		if (event.$ === 'Receipt') {
			var sequence = event.a;
			var terminal = event.b;
			var _v1 = $author$project$PreviewLifecycle$terminalJob(terminal);
			if (_v1.$ === 'Just') {
				var job = _v1.a;
				var _v2 = model;
				var initial = _v2.a;
				var correlated = A2($elm$core$List$member, job, initial.known) || _Utils_eq(
					initial.lastTerminal,
					$elm$core$Maybe$Just(
						_Utils_Tuple2(job, sequence)));
				if (!correlated) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v3 = A2($author$project$PreviewLifecycle$updatePlain, terminal, model);
					var next = _v3.a;
					var commands = _v3.b;
					var _v4 = next;
					var state = _v4.a;
					return A2($elm$core$List$member, job, state.known) ? _Utils_Tuple2(next, commands) : _Utils_Tuple2(
						$author$project$PreviewLifecycle$Model(
							_Utils_update(
								state,
								{
									lastTerminal: $elm$core$Maybe$Just(
										_Utils_Tuple2(job, sequence))
								})),
						_Utils_ap(
							commands,
							_List_fromArray(
								[
									A2($author$project$PreviewLifecycle$Acknowledge, job, sequence)
								])));
				}
			} else {
				return A2($author$project$PreviewLifecycle$updatePlain, terminal, model);
			}
		} else {
			return A2($author$project$PreviewLifecycle$updatePlain, event, model);
		}
	});
var $author$project$PreviewPresenter$closeEntry = function (entry) {
	var _v0 = entry.model;
	if (_v0.$ === 'Nothing') {
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{local: $elm$core$Maybe$Nothing, stamp: $elm$core$Maybe$Nothing}),
			_List_Nil);
	} else {
		var lifecycle = _v0.a;
		var _v1 = A2(
			$elm$core$Result$withDefault,
			_Utils_Tuple2(lifecycle, _List_Nil),
			A2(
				$elm$core$Result$map,
				function (event) {
					return A2($author$project$PreviewLifecycle$update, event, lifecycle);
				},
				A2(
					$elm$json$Json$Decode$decodeValue,
					$author$project$PreviewLifecycle$eventDecoder,
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('close'))
							])))));
		var closed = _v1.a;
		var commands = _v1.b;
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{
					local: $elm$core$Maybe$Nothing,
					model: $elm$core$Maybe$Just(closed),
					stamp: $elm$core$Maybe$Nothing
				}),
			commands);
	}
};
var $author$project$PreviewIdentity$string = function (_v0) {
	var counter = _v0.a;
	return $author$project$UInt64$string(counter);
};
var $author$project$PreviewIdentity$encode = A2($elm$core$Basics$composeR, $author$project$PreviewIdentity$string, $elm$json$Json$Encode$string);
var $author$project$PreviewLifecycle$encodeBinding = function (binding) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$author$project$PreviewIdentity$encode(binding.lifetime)),
				_Utils_Tuple2(
				'session',
				$author$project$PreviewIdentity$encode(binding.session)),
				_Utils_Tuple2(
				'frontend',
				$author$project$PreviewIdentity$encode(binding.frontend))
			]));
};
var $author$project$PreviewLifecycle$encodeContext = function (context) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$author$project$PreviewIdentity$encode(context.lifetime)),
				_Utils_Tuple2(
				'incarnation',
				$author$project$PreviewIdentity$encode(context.incarnation)),
				_Utils_Tuple2(
				'output',
				$author$project$PreviewIdentity$encode(context.output)),
				_Utils_Tuple2(
				'privacy',
				$author$project$PreviewIdentity$encode(context.privacy)),
				_Utils_Tuple2(
				'rendering',
				$author$project$PreviewIdentity$encode(context.rendering)),
				_Utils_Tuple2(
				'scene',
				$author$project$PreviewIdentity$encode(context.scene)),
				_Utils_Tuple2(
				'content',
				$author$project$PreviewIdentity$encode(context.content))
			]));
};
var $author$project$PreviewLifecycle$encodeJob = function (job) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'binding',
				$author$project$PreviewLifecycle$encodeBinding(job.binding)),
				_Utils_Tuple2(
				'context',
				$author$project$PreviewLifecycle$encodeContext(job.context)),
				_Utils_Tuple2(
				'request',
				$author$project$PreviewIdentity$encode(job.request)),
				_Utils_Tuple2(
				'origin',
				$author$project$PreviewIdentity$encode(job.origin)),
				_Utils_Tuple2(
				'clock',
				$author$project$PreviewIdentity$encode(job.clock)),
				_Utils_Tuple2(
				'deadline',
				$author$project$PreviewIdentity$encode(job.deadline))
			]));
};
var $author$project$PreviewLifecycle$handleString = function (_v0) {
	var value = _v0.a;
	return value;
};
var $author$project$PreviewLifecycle$encodePacket = function (packet) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'job',
				$author$project$PreviewLifecycle$encodeJob(packet.job)),
				_Utils_Tuple2(
				'handle',
				$elm$json$Json$Encode$string(
					$author$project$PreviewLifecycle$handleString(packet.handle))),
				_Utils_Tuple2(
				'owned',
				$elm$json$Json$Encode$bool(packet.owned)),
				_Utils_Tuple2(
				'signaled',
				$elm$json$Json$Encode$bool(packet.signaled)),
				_Utils_Tuple2(
				'fidelity',
				$elm$json$Json$Encode$string(
					_Utils_eq(packet.fidelity, $author$project$PreviewLifecycle$ClientContent) ? 'client' : 'family')),
				_Utils_Tuple2(
				'coverage',
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$string,
					$elm$core$Set$toList(packet.coverage))),
				_Utils_Tuple2(
				'expires',
				$author$project$PreviewIdentity$encode(packet.expires))
			]));
};
var $author$project$PreviewLifecycle$encodeCommands = function (commands) {
	return A2(
		$elm$json$Json$Encode$list,
		function (command) {
			switch (command.$) {
				case 'Acknowledge':
					var job = command.a;
					var sequence = command.b;
					return $elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('acknowledge')),
								_Utils_Tuple2(
								'job',
								$author$project$PreviewLifecycle$encodeJob(job)),
								_Utils_Tuple2(
								'sequence',
								$author$project$PreviewIdentity$encode(sequence))
							]));
				case 'Acquire':
					var job = command.a;
					return $elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('acquire')),
								_Utils_Tuple2(
								'job',
								$author$project$PreviewLifecycle$encodeJob(job))
							]));
				case 'Cancel':
					var job = command.a;
					return $elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('cancel')),
								_Utils_Tuple2(
								'job',
								$author$project$PreviewLifecycle$encodeJob(job))
							]));
				case 'Release':
					var packet = command.a;
					return $elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('release')),
								_Utils_Tuple2(
								'frame',
								$author$project$PreviewLifecycle$encodePacket(packet))
							]));
				default:
					var binding = command.a;
					return $elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('reconcile')),
								_Utils_Tuple2(
								'binding',
								$author$project$PreviewLifecycle$encodeBinding(binding))
							]));
			}
		},
		commands);
};
var $author$project$PreviewPresenter$encode = function (outputs) {
	return A2(
		$elm$json$Json$Encode$list,
		function (out) {
			return $elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'identity',
						$elm$json$Json$Encode$string(out.identity)),
						_Utils_Tuple2(
						'commands',
						$author$project$PreviewLifecycle$encodeCommands(out.commands))
					]));
		},
		A2(
			$elm$core$List$filter,
			function (out) {
				return !$elm$core$List$isEmpty(out.commands);
			},
			outputs));
};
var $author$project$SurfaceRenderer$publication = $author$project$SurfaceSnapshot$publication;
var $author$project$PreviewPresenter$same = F2(
	function (stamp, snapshot) {
		return _Utils_eq(
			stamp.publication,
			$author$project$SurfaceRenderer$publication(snapshot)) && (_Utils_eq(
			stamp.lease,
			$author$project$SurfaceRenderer$lease(snapshot)) && ($author$project$SurfaceRenderer$mode(snapshot) === 'picker'));
	});
var $author$project$PreviewPresenter$wrap = F2(
	function (scoped, entries) {
		var row = A3(
			$elm$json$Json$Decode$map2,
			$elm$core$Tuple$pair,
			A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
			A2(
				$elm$json$Json$Decode$field,
				'commands',
				$elm$json$Json$Decode$list($elm$json$Json$Decode$value)));
		var canonical = A2(
			$elm$core$Result$withDefault,
			entries,
			A2(
				$elm$core$Result$map,
				function (rows) {
					return A2(
						$elm$json$Json$Encode$list,
						function (value) {
							return value;
						},
						A2(
							$elm$core$List$concatMap,
							function (_v0) {
								var identity = _v0.a;
								var commands = _v0.b;
								return A2(
									$elm$core$List$map,
									function (command) {
										return $elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'identity',
													$elm$json$Json$Encode$string(
														_Utils_eq(
															A2(
																$elm$json$Json$Decode$decodeValue,
																A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
																command),
															$elm$core$Result$Ok('reconcile')) ? A2(
															$elm$core$Maybe$withDefault,
															identity,
															A2(
																$elm$core$Maybe$map,
																function (grant) {
																	return 'binding:' + $author$project$NativePreviewRealm$owner(grant.domain);
																},
																scoped.grant)) : identity)),
													_Utils_Tuple2(
													'commands',
													A2(
														$elm$json$Json$Encode$list,
														function (value) {
															return value;
														},
														_List_fromArray(
															[command])))
												]));
									},
									commands);
							},
							rows));
				},
				A2(
					$elm$json$Json$Decode$decodeValue,
					$elm$json$Json$Decode$list(row),
					entries)));
		return A2(
			$elm$core$Maybe$withDefault,
			entries,
			A2(
				$elm$core$Maybe$map,
				function (grant) {
					return A2($author$project$NativePreviewRealm$commands, grant.domain, canonical);
				},
				scoped.grant));
	});
var $author$project$PreviewPresenter$present = F2(
	function (snapshot, _v0) {
		var entries = _v0.a;
		var catalog = _v0.b;
		var ledger = _v0.c;
		var scoped = _v0.d;
		var advance = F3(
			function (identity, entry, _v3) {
				var next = _v3.a;
				var outputs = _v3.b;
				var current = A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (stamp) {
							return A2(
								$elm$core$Maybe$withDefault,
								false,
								A2(
									$elm$core$Maybe$map,
									function (shown) {
										return A3($author$project$SurfaceRenderer$enabled, true, identity, shown) && (A2($author$project$PreviewPresenter$same, stamp, shown) || (_Utils_eq(
											entry.source,
											$elm$core$Maybe$Just($author$project$NativePreviewSource$PickerFamily)) && (($author$project$SurfaceRenderer$mode(shown) === 'picker') && (_Utils_eq(
											stamp.lease,
											$author$project$SurfaceRenderer$lease(shown)) && _Utils_eq(
											A2(
												$author$project$UInt64$compare,
												$author$project$SurfaceRenderer$publication(shown),
												stamp.publication),
											$elm$core$Basics$GT)))));
									},
									snapshot));
						},
						entry.stamp));
				if (current || _Utils_eq(entry.stamp, $elm$core$Maybe$Nothing)) {
					return _Utils_Tuple2(
						A3($elm$core$Dict$insert, identity, entry, next),
						outputs);
				} else {
					var _v2 = $author$project$PreviewPresenter$closeEntry(entry);
					var closed = _v2.a;
					var commands = _v2.b;
					return _Utils_Tuple2(
						((!scoped.closing) && (_Utils_eq(closed.model, $elm$core$Maybe$Nothing) && (_Utils_eq(closed.retirement, $elm$core$Maybe$Nothing) && _Utils_eq(closed.detachment, $elm$core$Maybe$Nothing)))) ? A2($elm$core$Dict$remove, identity, next) : A3($elm$core$Dict$insert, identity, closed, next),
						_Utils_ap(
							outputs,
							_List_fromArray(
								[
									{commands: commands, identity: identity}
								])));
				}
			});
		var _v1 = A3(
			$elm$core$Dict$foldl,
			advance,
			_Utils_Tuple2($elm$core$Dict$empty, _List_Nil),
			entries);
		var collected = _v1.a;
		var emissions = _v1.b;
		return _Utils_Tuple2(
			A4($author$project$PreviewPresenter$Model, collected, catalog, ledger, scoped),
			A2(
				$author$project$PreviewPresenter$wrap,
				scoped,
				$author$project$PreviewPresenter$encode(emissions)));
	});
var $author$project$RetainedPreviewPresenter$present = F2(
	function (snapshot, prior) {
		var policy = prior.a;
		return A2(
			$author$project$RetainedPreviewPresenter$commit,
			prior,
			A2($author$project$PreviewPresenter$present, snapshot, policy));
	});
var $author$project$PreviewLifecycle$retire = function (_v0) {
	var initial = _v0.a;
	var _final = A2(
		$author$project$PreviewLifecycle$mapState,
		function (st) {
			return _Utils_update(
				st,
				{demand: false});
		},
		$author$project$PreviewLifecycle$revoke(
			{effects: _List_Nil, state: initial}));
	return _Utils_Tuple2(
		$author$project$PreviewLifecycle$Model(_final.state),
		_final.effects);
};
var $author$project$PreviewPresenter$detachEntry = function (entry) {
	var _v0 = entry.model;
	if (_v0.$ === 'Nothing') {
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{local: $elm$core$Maybe$Nothing, stamp: $elm$core$Maybe$Nothing}),
			_List_Nil);
	} else {
		var lifecycle = _v0.a;
		var _v1 = $author$project$PreviewLifecycle$retire(lifecycle);
		var next = _v1.a;
		var emitted = _v1.b;
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{
					local: $elm$core$Maybe$Nothing,
					model: $elm$core$Maybe$Just(next),
					stamp: $elm$core$Maybe$Nothing
				}),
			emitted);
	}
};
var $author$project$PreviewPresenter$quarantineOwned = function (prior) {
	var entries = prior.a;
	var catalog = prior.b;
	var ledger = prior.c;
	var scoped = prior.d;
	if (scoped.closing) {
		return _Utils_Tuple2(
			prior,
			$author$project$PreviewPresenter$encode(_List_Nil));
	} else {
		var step = F3(
			function (identity, entry, _v2) {
				var next = _v2.a;
				var emitted = _v2.b;
				var _v1 = $author$project$PreviewPresenter$detachEntry(entry);
				var closed = _v1.a;
				var commands = _v1.b;
				return _Utils_Tuple2(
					A3($elm$core$Dict$insert, identity, closed, next),
					_Utils_ap(
						emitted,
						_List_fromArray(
							[
								{commands: commands, identity: identity}
							])));
			});
		var _v0 = A3(
			$elm$core$Dict$foldl,
			step,
			_Utils_Tuple2($elm$core$Dict$empty, _List_Nil),
			entries);
		var retained = _v0.a;
		var cleanup = _v0.b;
		return _Utils_Tuple2(
			A4(
				$author$project$PreviewPresenter$Model,
				retained,
				catalog,
				ledger,
				_Utils_update(
					scoped,
					{closing: true})),
			$author$project$PreviewPresenter$encode(cleanup));
	}
};
var $author$project$PreviewPresenter$quarantineRealm = F2(
	function (domain, prior) {
		var scoped = prior.d;
		if (scoped.closed || (scoped.closing || (!A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (grant) {
					return A2($author$project$NativePreviewRealm$same, grant.domain, domain);
				},
				scoped.grant))))) {
			return _Utils_Tuple2(
				prior,
				A2(
					$author$project$PreviewPresenter$wrap,
					scoped,
					$author$project$PreviewPresenter$encode(_List_Nil)));
		} else {
			var original = $elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'identity',
						$elm$json$Json$Encode$string(
							'binding:' + $author$project$NativePreviewRealm$owner(domain))),
						_Utils_Tuple2(
						'commands',
						A2(
							$elm$json$Json$Encode$list,
							$elm$core$Basics$identity,
							_List_fromArray(
								[
									$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'kind',
											$elm$json$Json$Encode$string('reconcile')),
											_Utils_Tuple2(
											'binding',
											$author$project$NativePreviewRealm$bindingValue(domain))
										]))
								])))
					]));
			var _v0 = $author$project$PreviewPresenter$quarantineOwned(prior);
			var next = _v0.a;
			var cleanup = _v0.b;
			var retained = A2(
				$elm$core$Result$withDefault,
				_List_Nil,
				A2(
					$elm$json$Json$Decode$decodeValue,
					$elm$json$Json$Decode$list($elm$json$Json$Decode$value),
					cleanup));
			return _Utils_Tuple2(
				next,
				A2(
					$author$project$PreviewPresenter$wrap,
					scoped,
					A2(
						$elm$json$Json$Encode$list,
						$elm$core$Basics$identity,
						A2($elm$core$List$cons, original, retained))));
		}
	});
var $author$project$RetainedPreviewPresenter$quarantineRealm = F2(
	function (domain, prior) {
		var policy = prior.a;
		var grant = prior.b;
		var ingress = prior.c;
		var deferred = prior.d;
		if ($elm$core$List$isEmpty(deferred)) {
			return A2(
				$author$project$RetainedPreviewPresenter$commit,
				prior,
				A2($author$project$PreviewPresenter$quarantineRealm, domain, policy));
		} else {
			var _v0 = _Utils_Tuple2(grant, ingress);
			if ((_v0.a.$ === 'Just') && (_v0.b.$ === 'Just')) {
				var g = _v0.a.a;
				var queue = _v0.b.a;
				if (!A2($author$project$NativePreviewRealm$same, g.domain, domain)) {
					return _Utils_Tuple2(
						prior,
						$author$project$RetainedPreviewPresenter$emptyOutput(grant));
				} else {
					var _v1 = A2($author$project$PreviewPresenter$quarantineRealm, domain, policy);
					var candidate = _v1.a;
					var output = _v1.b;
					var _v2 = A2($author$project$NativePreviewProposalIngress$decode, g, output);
					if ((_v2.$ === 'Just') && _v2.a.b) {
						var _v3 = _v2.a;
						var intents = A2(
							$elm$core$Maybe$withDefault,
							_List_Nil,
							A2($author$project$NativePreviewProposalIngress$decode, g, output));
						var _v4 = A2(
							$author$project$NativePreviewProposalIngress$split,
							_Utils_ap(deferred, intents),
							queue);
						var retained = _v4.a;
						var waiting = _v4.b;
						return _Utils_Tuple2(
							A4(
								$author$project$RetainedPreviewPresenter$Model,
								candidate,
								grant,
								$elm$core$Maybe$Just(retained),
								waiting),
							$author$project$NativePreviewProposalIngress$proposals(retained));
					} else {
						return _Utils_Tuple2(
							prior,
							$author$project$RetainedPreviewPresenter$emptyOutput(grant));
					}
				}
			} else {
				return _Utils_Tuple2(
					prior,
					$author$project$RetainedPreviewPresenter$emptyOutput(grant));
			}
		}
	});
var $elm$core$List$head = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(x);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$SurfaceSnapshot$queryValue = function (current) {
	var snapshot = current.a;
	return A2(
		$elm$core$Maybe$map,
		function ($) {
			return $.label;
		},
		$elm$core$List$head(
			A2(
				$elm$core$List$filter,
				function (item) {
					return _Utils_eq(
						item.identity,
						$author$project$SurfaceSnapshot$fieldIdentity(current));
				},
				snapshot.popup)));
};
var $author$project$SurfaceRenderer$queryValue = $author$project$SurfaceSnapshot$queryValue;
var $author$project$Announcement$bounded = function (limit) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return ((!$elm$core$String$isEmpty(value)) && ((_Utils_cmp(
				$elm$core$String$length(value),
				limit) < 1) && (!A2(
				$elm$core$String$any,
				function (c) {
					return $elm$core$Char$toCode(c) < 32;
				},
				value)))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Bounded announcement text');
		},
		$elm$json$Json$Decode$string);
};
var $author$project$Announcement$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (n) {
		return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Positive announcement identity');
	},
	$author$project$UInt64$decoder);
var $author$project$Announcement$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Closed announcement fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Announcement$messageDecoder = function () {
	var legacy = A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (sequence, correlation, value) {
				return {correlation: correlation, interrupt: false, sequence: sequence, text: value};
			}),
		A2($elm$json$Json$Decode$field, 'sequence', $author$project$Announcement$positive),
		A2(
			$elm$json$Json$Decode$field,
			'correlation',
			$author$project$Announcement$bounded(2048)),
		A2(
			$elm$json$Json$Decode$field,
			'text',
			$author$project$Announcement$bounded(1024)));
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				A2(
				$author$project$Announcement$strict,
				_List_fromArray(
					['sequence', 'correlation', 'text', 'interrupt']),
				A3(
					$elm$json$Json$Decode$map2,
					F2(
						function (message, interrupt) {
							return _Utils_update(
								message,
								{interrupt: interrupt});
						}),
					legacy,
					A2($elm$json$Json$Decode$field, 'interrupt', $elm$json$Json$Decode$bool))),
				A2(
				$author$project$Announcement$strict,
				_List_fromArray(
					['sequence', 'correlation', 'text']),
				legacy)
			]));
}();
var $elm$json$Json$Decode$null = _Json_decodeNull;
var $elm$json$Json$Decode$nullable = function (decoder) {
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				$elm$json$Json$Decode$null($elm$core$Maybe$Nothing),
				A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, decoder)
			]));
};
var $author$project$Announcement$scope = A2(
	$author$project$Announcement$strict,
	_List_fromArray(
		['id', 'generation']),
	A3(
		$elm$json$Json$Decode$map2,
		$elm$core$Tuple$pair,
		A2($elm$json$Json$Decode$field, 'id', $author$project$Announcement$positive),
		A2($elm$json$Json$Decode$field, 'generation', $author$project$Announcement$positive)));
var $author$project$Announcement$route = A2(
	$author$project$Announcement$strict,
	_List_fromArray(
		['scope', 'surface']),
	A3(
		$elm$json$Json$Decode$map2,
		$elm$core$Tuple$pair,
		A2($elm$json$Json$Decode$field, 'scope', $author$project$Announcement$scope),
		A2(
			$elm$json$Json$Decode$field,
			'surface',
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return A2(
						$elm$core$List$member,
						value,
						_List_fromArray(
							['bar', 'popup'])) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Announcement surface');
				},
				$elm$json$Json$Decode$string))));
var $elm$core$Tuple$second = function (_v0) {
	var y = _v0.b;
	return y;
};
var $author$project$Announcement$receive = F4(
	function (popup, snapshot, raw, prior) {
		var model = prior.a;
		var decoder = A2(
			$author$project$Announcement$strict,
			_List_fromArray(
				['announcementProtocol', 'kind', 'recipient', 'announcer', 'publication', 'lease', 'message', 'deliver']),
			A9(
				$elm$json$Json$Decode$map8,
				F8(
					function (version, kind, recipient, owner, publication, lease, message, deliver) {
						return {deliver: deliver, kind: kind, lease: lease, message: message, owner: owner, publication: publication, recipient: recipient, version: version};
					}),
				A2($elm$json$Json$Decode$field, 'announcementProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'recipient', $author$project$Announcement$route),
				A2(
					$elm$json$Json$Decode$field,
					'announcer',
					$elm$json$Json$Decode$nullable($author$project$Announcement$route)),
				A2($elm$json$Json$Decode$field, 'publication', $author$project$Announcement$positive),
				A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
				A2(
					$elm$json$Json$Decode$field,
					'message',
					$elm$json$Json$Decode$nullable($author$project$Announcement$messageDecoder)),
				A2($elm$json$Json$Decode$field, 'deliver', $elm$json$Json$Decode$bool)));
		var _v0 = _Utils_Tuple2(
			snapshot,
			A2($elm$json$Json$Decode$decodeValue, decoder, raw));
		if ((_v0.a.$ === 'Just') && (_v0.b.$ === 'Ok')) {
			var current = _v0.a.a;
			var packet = _v0.b.a;
			if ((packet.version !== 1) || ((packet.kind !== 'announcement-projection') || ((!_Utils_eq(
				packet.recipient.b,
				popup ? 'popup' : 'bar')) || ((!_Utils_eq(
				packet.publication,
				$author$project$SurfaceRenderer$publication(current))) || (!_Utils_eq(
				packet.lease,
				$author$project$SurfaceRenderer$lease(current))))))) {
				return prior;
			} else {
				if (!_Utils_eq(
					packet.owner,
					$elm$core$Maybe$Just(packet.recipient))) {
					return $author$project$Announcement$Model(
						_Utils_update(
							model,
							{active: false, message: $elm$core$Maybe$Nothing}));
				} else {
					var _v1 = packet.message;
					if (_v1.$ === 'Just') {
						var message = _v1.a;
						return (packet.deliver && _Utils_eq(
							A2($author$project$UInt64$compare, message.sequence, model.last),
							$elm$core$Basics$GT)) ? $author$project$Announcement$Model(
							{
								active: true,
								last: message.sequence,
								message: $elm$core$Maybe$Just(message)
							}) : ((model.active && _Utils_eq(
							model.message,
							$elm$core$Maybe$Just(message))) ? prior : $author$project$Announcement$Model(
							_Utils_update(
								model,
								{active: true, message: $elm$core$Maybe$Nothing})));
					} else {
						return $author$project$Announcement$Model(
							_Utils_update(
								model,
								{active: true, message: $elm$core$Maybe$Nothing}));
					}
				}
			}
		} else {
			return prior;
		}
	});
var $author$project$PreviewLifecycle$drawablePacket = function (current) {
	switch (current.$) {
		case 'Live':
			var packet = current.a.a;
			return $elm$core$Maybe$Just(packet);
		case 'Historical':
			var packet = current.a.a;
			return $elm$core$Maybe$Just(packet);
		default:
			return $elm$core$Maybe$Nothing;
	}
};
var $author$project$PreviewLifecycle$encodeScope = function (scope) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'binding',
				$author$project$PreviewLifecycle$encodeBinding(scope.binding)),
				_Utils_Tuple2(
				'context',
				$author$project$PreviewLifecycle$encodeContext(scope.context)),
				_Utils_Tuple2(
				'observation',
				$author$project$PreviewIdentity$encode(scope.observation)),
				_Utils_Tuple2(
				'clock',
				$author$project$PreviewIdentity$encode(scope.clock)),
				_Utils_Tuple2(
				'now',
				$author$project$PreviewIdentity$encode(scope.now)),
				_Utils_Tuple2(
				'present',
				$elm$json$Json$Encode$bool(scope.present)),
				_Utils_Tuple2(
				'sourceLive',
				$elm$json$Json$Encode$bool(scope.sourceLive)),
				_Utils_Tuple2(
				'locked',
				$elm$json$Json$Encode$bool(scope.locked)),
				_Utils_Tuple2(
				'gpuReady',
				$elm$json$Json$Encode$bool(scope.gpuReady))
			]));
};
var $elm$json$Json$Encode$null = _Json_encodeNull;
var $author$project$PreviewLifecycle$Historical = function (a) {
	return {$: 'Historical', a: a};
};
var $author$project$PreviewLifecycle$Live = function (a) {
	return {$: 'Live', a: a};
};
var $author$project$PreviewLifecycle$Loading = {$: 'Loading'};
var $author$project$PreviewLifecycle$Unavailable = {$: 'Unavailable'};
var $author$project$PreviewLifecycle$loadingStatus = function (st) {
	return (st.demand && (!_Utils_eq(st.capture, $author$project$PreviewLifecycle$Idle))) ? $author$project$PreviewLifecycle$Loading : $author$project$PreviewLifecycle$Unavailable;
};
var $author$project$PreviewLifecycle$status = function (st) {
	var _v0 = st.accepted;
	if (_v0.$ === 'Just') {
		var lease = _v0.a;
		var frame = lease.a;
		return (st.demand && A2($author$project$PreviewLifecycle$authorized, st, frame)) ? ((st.scope.sourceLive && (_Utils_eq(frame.job.context.scene, st.scope.context.scene) && _Utils_eq(frame.job.context.content, st.scope.context.content))) ? $author$project$PreviewLifecycle$Live(lease) : $author$project$PreviewLifecycle$Historical(lease)) : $author$project$PreviewLifecycle$loadingStatus(st);
	} else {
		return $author$project$PreviewLifecycle$loadingStatus(st);
	}
};
var $author$project$PreviewLifecycle$statusName = function (current) {
	switch (current.$) {
		case 'Live':
			return 'live';
		case 'Historical':
			return 'historical';
		case 'Loading':
			return 'loading';
		default:
			return 'unavailable';
	}
};
var $author$project$PreviewLifecycle$observe = function (_v0) {
	var st = _v0.a;
	var maybe = F2(
		function (encode, value) {
			return A2(
				$elm$core$Maybe$withDefault,
				$elm$json$Json$Encode$null,
				A2($elm$core$Maybe$map, encode, value));
		});
	var job = function () {
		var _v1 = st.capture;
		if (_v1.$ === 'Capturing') {
			var active = _v1.a;
			return $elm$core$Maybe$Just(active);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	}();
	var current = $author$project$PreviewLifecycle$status(st);
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'scope',
				$author$project$PreviewLifecycle$encodeScope(st.scope)),
				_Utils_Tuple2(
				'demand',
				$elm$json$Json$Encode$bool(st.demand)),
				_Utils_Tuple2(
				'ready',
				$elm$json$Json$Encode$bool(
					_Utils_eq(st.connection, $author$project$PreviewLifecycle$Connected))),
				_Utils_Tuple2(
				'nextRequest',
				A2(maybe, $author$project$PreviewIdentity$encode, st.nextRequest)),
				_Utils_Tuple2(
				'job',
				A2(maybe, $author$project$PreviewLifecycle$encodeJob, job)),
				_Utils_Tuple2(
				'candidate',
				A2(
					maybe,
					$author$project$PreviewLifecycle$encodePacket,
					$author$project$PreviewLifecycle$candidate(st))),
				_Utils_Tuple2(
				'accepted',
				A2(
					maybe,
					$author$project$PreviewLifecycle$encodePacket,
					$author$project$PreviewLifecycle$acceptedPacket(st))),
				_Utils_Tuple2(
				'known',
				A2($elm$json$Json$Encode$list, $author$project$PreviewLifecycle$encodeJob, st.known)),
				_Utils_Tuple2(
				'cancelling',
				A2($elm$json$Json$Encode$list, $author$project$PreviewLifecycle$encodeJob, st.cancelling)),
				_Utils_Tuple2(
				'retiring',
				A2($elm$json$Json$Encode$list, $author$project$PreviewLifecycle$encodePacket, st.retiring)),
				_Utils_Tuple2(
				'state',
				$elm$json$Json$Encode$string(
					$author$project$PreviewLifecycle$statusName(current))),
				_Utils_Tuple2(
				'image',
				A2(
					maybe,
					A2(
						$elm$core$Basics$composeR,
						function ($) {
							return $.handle;
						},
						A2(
							$elm$core$Basics$composeR,
							$author$project$PreviewLifecycle$handleString,
							A2(
								$elm$core$Basics$composeR,
								$elm$core$Basics$append('elm-shell://preview/'),
								$elm$json$Json$Encode$string))),
					$author$project$PreviewLifecycle$drawablePacket(current)))
			]));
};
var $author$project$PreviewPresenter$floorMatches = F2(
	function (entry, seed) {
		var _v0 = entry.model;
		if (_v0.$ === 'Nothing') {
			return _Utils_eq(seed.requestFloor, $author$project$UInt64$zero);
		} else {
			var lifecycle = _v0.a;
			return A2(
				$elm$core$Result$withDefault,
				false,
				A2(
					$elm$core$Result$map,
					function (next) {
						return _Utils_eq(
							next,
							$author$project$UInt64$next(seed.requestFloor));
					},
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2(
							$elm$json$Json$Decode$field,
							'nextRequest',
							$elm$json$Json$Decode$nullable($author$project$UInt64$decoder)),
						$author$project$PreviewLifecycle$observe(lifecycle))));
		}
	});
var $author$project$NativePreviewDetachment$ready = function (seed) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('detach-ready')),
				_Utils_Tuple2(
				'binding',
				$author$project$NativePreviewRealm$bindingValue(seed.domain)),
				_Utils_Tuple2(
				'receiverEpoch',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(seed.domain.receiverEpoch))),
				_Utils_Tuple2(
				'subject',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(seed.subject))),
				_Utils_Tuple2(
				'entry',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(seed.entry))),
				_Utils_Tuple2(
				'entryIssuedThrough',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(seed.entryIssuedThrough))),
				_Utils_Tuple2(
				'requestFloor',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(seed.requestFloor)))
			]));
};
var $author$project$NativeActorRetirement$bindingValue = function (value) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.lifetime))),
				_Utils_Tuple2(
				'session',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.session))),
				_Utils_Tuple2(
				'frontend',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.frontend)))
			]));
};
var $author$project$NativeActorRetirement$readyCommand = function (value) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('retire-ready')),
				_Utils_Tuple2(
				'binding',
				$author$project$NativeActorRetirement$bindingValue(value)),
				_Utils_Tuple2(
				'subject',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.subject))),
				_Utils_Tuple2(
				'observationRequest',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.request))),
				_Utils_Tuple2(
				'observationSequence',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.sequence)))
			]));
};
var $author$project$NativePreviewDetachment$acknowledgment = function (delivery) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('detach-delivery-ack')),
				_Utils_Tuple2(
				'binding',
				$author$project$NativePreviewRealm$bindingValue(delivery.seed.domain)),
				_Utils_Tuple2(
				'receiverEpoch',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(delivery.seed.domain.receiverEpoch))),
				_Utils_Tuple2(
				'deliveryOrdinal',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(delivery.ordinal)))
			]));
};
var $author$project$NativeActorRetirement$owner = function (value) {
	return A2(
		$elm$core$String$join,
		':',
		A2(
			$elm$core$List$map,
			$author$project$UInt64$string,
			_List_fromArray(
				[value.lifetime, value.session, value.frontend])));
};
var $author$project$NativeActorRetirement$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Positive native retirement identity');
	},
	$author$project$UInt64$decoder);
var $author$project$NativeActorRetirement$admittedAfter = F3(
	function (ledger, binding, raw) {
		var _v0 = ledger.settled;
		if (_v0.$ === 'Nothing') {
			return true;
		} else {
			var _final = _v0.a;
			var _v1 = A2(
				$elm$json$Json$Decode$decodeValue,
				A3(
					$elm$json$Json$Decode$map2,
					$elm$core$Tuple$pair,
					A2($elm$json$Json$Decode$field, 'clock', $author$project$NativeActorRetirement$positive),
					A2($elm$json$Json$Decode$field, 'now', $author$project$NativeActorRetirement$positive)),
				raw);
			if (_v1.$ === 'Ok') {
				var _v2 = _v1.a;
				var clock = _v2.a;
				var now = _v2.b;
				return _Utils_eq(
					binding,
					$author$project$NativeActorRetirement$owner(_final._native)) && (_Utils_eq(clock, _final._native.clock) && _Utils_eq(
					A2($author$project$UInt64$compare, now, _final._native.now),
					$elm$core$Basics$GT));
			} else {
				return false;
			}
		}
	});
var $author$project$PreviewPresenter$advanceFloor = F2(
	function (old, incoming) {
		var _v0 = _Utils_Tuple2(old, incoming);
		if (_v0.b.$ === 'Just') {
			if (_v0.a.$ === 'Just') {
				var previous = _v0.a.a;
				var next = _v0.b.a;
				return $elm$core$Maybe$Just(
					_Utils_eq(
						A2($author$project$UInt64$compare, next, previous),
						$elm$core$Basics$GT) ? next : previous);
			} else {
				var next = _v0.b.a;
				return $elm$core$Maybe$Just(next);
			}
		} else {
			return old;
		}
	});
var $elm$json$Json$Decode$at = F2(
	function (fields, decoder) {
		return A3($elm$core$List$foldr, $elm$json$Json$Decode$field, decoder, fields);
	});
var $author$project$PreviewPresenter$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Positive preview presentation identity');
	},
	$author$project$UInt64$decoder);
var $author$project$PreviewPresenter$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Preview presenter fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$PreviewPresenter$binding = A2(
	$author$project$PreviewPresenter$strict,
	_List_fromArray(
		['lifetime', 'session', 'frontend']),
	A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (a, b, c) {
				return A2(
					$elm$core$String$join,
					':',
					A2(
						$elm$core$List$map,
						$author$project$UInt64$string,
						_List_fromArray(
							[a, b, c])));
			}),
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$PreviewPresenter$positive),
		A2($elm$json$Json$Decode$field, 'session', $author$project$PreviewPresenter$positive),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$PreviewPresenter$positive)));
var $author$project$NativeActorRetirement$chronology = F2(
	function (incoming, previous) {
		var _v0 = A2($author$project$UInt64$compare, incoming.now, previous.now);
		if (_v0.$ === 'EQ') {
			return A2($author$project$UInt64$compare, incoming.sequence, previous.sequence);
		} else {
			var order = _v0;
			return order;
		}
	});
var $author$project$NativeActorRetirement$coherentFrontier = F2(
	function (ledger, fact) {
		var _v0 = ledger.settled;
		if (_v0.$ === 'Nothing') {
			return true;
		} else {
			var previous = _v0.a;
			var subjects = A2($author$project$UInt64$compare, fact._native.issuedThrough, previous._native.issuedThrough);
			var order = A2($author$project$NativeActorRetirement$chronology, fact._native, previous._native);
			var entries = A2($author$project$UInt64$compare, fact.entryIssuedThrough, previous.entryIssuedThrough);
			return _Utils_eq(
				$author$project$NativeActorRetirement$owner(fact._native),
				$author$project$NativeActorRetirement$owner(previous._native)) && (_Utils_eq(fact._native.clock, previous._native.clock) && (_Utils_eq(order, $elm$core$Basics$LT) ? ((!_Utils_eq(entries, $elm$core$Basics$GT)) && (!_Utils_eq(subjects, $elm$core$Basics$GT))) : ((!_Utils_eq(entries, $elm$core$Basics$LT)) && (!_Utils_eq(subjects, $elm$core$Basics$LT)))));
		}
	});
var $author$project$NativeActorRetirement$fresh = F2(
	function (previous, incoming) {
		return A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (old) {
					return _Utils_eq(
						$author$project$NativeActorRetirement$owner(incoming),
						$author$project$NativeActorRetirement$owner(old)) && (_Utils_eq(incoming.clock, old.clock) && (_Utils_eq(
						A2($author$project$UInt64$compare, incoming.request, old.request),
						$elm$core$Basics$GT) && (_Utils_eq(
						A2($author$project$UInt64$compare, incoming.sequence, old.sequence),
						$elm$core$Basics$GT) && ((!_Utils_eq(
						A2($author$project$UInt64$compare, incoming.now, old.now),
						$elm$core$Basics$LT)) && (!_Utils_eq(
						A2($author$project$UInt64$compare, incoming.issuedThrough, old.issuedThrough),
						$elm$core$Basics$LT))))));
				},
				previous));
	});
var $author$project$NativeActorRetirement$remember = F2(
	function (ledger, observation) {
		return A2($author$project$NativeActorRetirement$fresh, ledger.observed, observation) ? _Utils_update(
			ledger,
			{
				observed: $elm$core$Maybe$Just(observation)
			}) : ledger;
	});
var $author$project$NativeActorRetirement$confirm = F2(
	function (ledger, fact) {
		var updated = A2($author$project$NativeActorRetirement$remember, ledger, fact._native);
		var newest = A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (previous) {
					return !_Utils_eq(
						A2($author$project$NativeActorRetirement$chronology, fact._native, previous._native),
						$elm$core$Basics$LT);
				},
				ledger.settled));
		return newest ? _Utils_update(
			updated,
			{
				settled: $elm$core$Maybe$Just(fact)
			}) : updated;
	});
var $author$project$NativeActorRetirement$deliveryAcknowledgment = function (delivery) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('retire-delivery-ack')),
				_Utils_Tuple2(
				'binding',
				$author$project$NativeActorRetirement$bindingValue(delivery.fact._native)),
				_Utils_Tuple2(
				'deliveryOrdinal',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(delivery.ordinal)))
			]));
};
var $author$project$PreviewPresenter$eventOwns = F2(
	function (identity, wire) {
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			wire);
		_v0$2:
		while (true) {
			if (_v0.$ === 'Ok') {
				switch (_v0.a) {
					case 'observe':
						return A2(
							$elm$core$Result$withDefault,
							false,
							A2(
								$elm$core$Result$map,
								function (incarnation) {
									return _Utils_eq(
										identity,
										'family:' + $author$project$UInt64$string(incarnation));
								},
								A2(
									$elm$json$Json$Decode$decodeValue,
									A2(
										$elm$json$Json$Decode$at,
										_List_fromArray(
											['scope', 'context', 'incarnation']),
										$author$project$PreviewPresenter$positive),
									wire)));
					case 'attach':
						return A2(
							$elm$core$Result$withDefault,
							false,
							A2(
								$elm$core$Result$map,
								function (incarnation) {
									return _Utils_eq(
										identity,
										'family:' + $author$project$UInt64$string(incarnation));
								},
								A2(
									$elm$json$Json$Decode$decodeValue,
									A2(
										$elm$json$Json$Decode$at,
										_List_fromArray(
											['scope', 'context', 'incarnation']),
										$author$project$PreviewPresenter$positive),
									wire)));
					default:
						break _v0$2;
				}
			} else {
				break _v0$2;
			}
		}
		return true;
	});
var $author$project$PreviewPresenter$familyFrameOwns = F2(
	function (sourceKind, wire) {
		if (!function () {
			_v0$3:
			while (true) {
				if (sourceKind.$ === 'Just') {
					switch (sourceKind.a.$) {
						case 'StyleCroppedFamily':
							var _v1 = sourceKind.a;
							return true;
						case 'PickerFamily':
							var _v2 = sourceKind.a;
							return true;
						case 'GeneratedBackdropFamily':
							return true;
						default:
							break _v0$3;
					}
				} else {
					break _v0$3;
				}
			}
			return false;
		}()) {
			return true;
		} else {
			var shape = A3(
				$elm$json$Json$Decode$map2,
				F2(
					function (fidelity, coverage) {
						return (fidelity === 'family') && _Utils_eq(
							$elm$core$List$sort(coverage),
							_List_fromArray(
								['client', 'decoration', 'modal', 'popup']));
					}),
				A2($elm$json$Json$Decode$field, 'fidelity', $elm$json$Json$Decode$string),
				A2(
					$elm$json$Json$Decode$field,
					'coverage',
					$elm$json$Json$Decode$list($elm$json$Json$Decode$string)));
			var admit = function (path) {
				return A2(
					$elm$core$Result$withDefault,
					false,
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$at, path, shape),
						wire));
			};
			var _v3 = A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				wire);
			_v3$4:
			while (true) {
				if (_v3.$ === 'Ok') {
					switch (_v3.a) {
						case 'offer':
							return admit(
								_List_fromArray(
									['frame']));
						case 'fence':
							return admit(
								_List_fromArray(
									['frame']));
						case 'expired':
							return admit(
								_List_fromArray(
									['frame']));
						case 'receipt':
							var _v4 = A2(
								$elm$json$Json$Decode$decodeValue,
								A2(
									$elm$json$Json$Decode$at,
									_List_fromArray(
										['event', 'kind']),
									$elm$json$Json$Decode$string),
								wire);
							if ((_v4.$ === 'Ok') && (_v4.a === 'released')) {
								return admit(
									_List_fromArray(
										['event', 'frame']));
							} else {
								return true;
							}
						default:
							break _v3$4;
					}
				} else {
					break _v3$4;
				}
			}
			return true;
		}
	});
var $author$project$PreviewLifecycle$idle = function (_v0) {
	var st = _v0.a;
	return _Utils_eq(st.connection, $author$project$PreviewLifecycle$Connected) && (st.scope.present && (st.scope.sourceLive && ((!st.scope.locked) && (st.scope.gpuReady && ((!st.metadataHidden) && (_Utils_eq(st.capture, $author$project$PreviewLifecycle$Idle) && (_Utils_eq(st.accepted, $elm$core$Maybe$Nothing) && ($elm$core$List$isEmpty(st.known) && ($elm$core$List$isEmpty(st.cancelling) && $elm$core$List$isEmpty(st.retiring))))))))));
};
var $author$project$PreviewLifecycle$init = function (_v0) {
	var scope = _v0.a;
	return $author$project$PreviewLifecycle$Model(
		{
			accepted: $elm$core$Maybe$Nothing,
			cancelling: _List_Nil,
			capture: $author$project$PreviewLifecycle$Idle,
			connection: $author$project$PreviewLifecycle$Connected,
			demand: false,
			known: _List_Nil,
			lastTerminal: $elm$core$Maybe$Nothing,
			metadataHidden: scope.locked,
			nextRequest: $author$project$PreviewIdentity$nextRequest($author$project$PreviewIdentity$zeroRequest),
			retiring: _List_Nil,
			scope: scope
		});
};
var $author$project$PreviewPresenter$Catalog = F3(
	function (a, b, c) {
		return {$: 'Catalog', a: a, b: b, c: c};
	});
var $author$project$PreviewPresenter$DetachSeed = function (a) {
	return {$: 'DetachSeed', a: a};
};
var $author$project$PreviewPresenter$Detached = function (a) {
	return {$: 'Detached', a: a};
};
var $author$project$PreviewPresenter$Event = F3(
	function (a, b, c) {
		return {$: 'Event', a: a, b: b, c: c};
	});
var $author$project$PreviewPresenter$Feedback = F2(
	function (a, b) {
		return {$: 'Feedback', a: a, b: b};
	});
var $author$project$PreviewPresenter$Metadata = F8(
	function (a, b, c, d, e, f, g, h) {
		return {$: 'Metadata', a: a, b: b, c: c, d: d, e: e, f: f, g: g, h: h};
	});
var $author$project$PreviewPresenter$Retired = function (a) {
	return {$: 'Retired', a: a};
};
var $author$project$PreviewPresenter$Retirement = function (a) {
	return {$: 'Retirement', a: a};
};
var $author$project$PreviewPresenter$RetirementChannel = function (a) {
	return {$: 'RetirementChannel', a: a};
};
var $author$project$PreviewPresenter$RetirementDelivery = function (a) {
	return {$: 'RetirementDelivery', a: a};
};
var $author$project$PreviewPresenter$Seed = function (a) {
	return function (b) {
		return function (c) {
			return function (d) {
				return function (e) {
					return function (f) {
						return function (g) {
							return function (h) {
								return function (i) {
									return function (j) {
										return {$: 'Seed', a: a, b: b, c: c, d: d, e: e, f: f, g: g, h: h, i: i, j: j};
									};
								};
							};
						};
					};
				};
			};
		};
	};
};
var $author$project$PreviewPresenter$Stamp = F2(
	function (publication, lease) {
		return {lease: lease, publication: publication};
	});
var $author$project$NativeActorRetirement$Fact = F4(
	function (_native, entry, entryIssuedThrough, requestFloor) {
		return {entry: entry, entryIssuedThrough: entryIssuedThrough, _native: _native, requestFloor: requestFloor};
	});
var $author$project$NativeActorRetirement$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Exact native actor retirement fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativeActorRetirement$nativeDecoder = A3(
	$elm$json$Json$Decode$map2,
	F2(
		function (_v0, construct) {
			var lifetime = _v0.a;
			var session = _v0.b;
			var frontend = _v0.c;
			return A3(construct, lifetime, session, frontend);
		}),
	A2(
		$elm$json$Json$Decode$field,
		'binding',
		A2(
			$author$project$NativeActorRetirement$strict,
			_List_fromArray(
				['lifetime', 'session', 'frontend']),
			A4(
				$elm$json$Json$Decode$map3,
				F3(
					function (a, b, c) {
						return _Utils_Tuple3(a, b, c);
					}),
				A2($elm$json$Json$Decode$field, 'lifetime', $author$project$NativeActorRetirement$positive),
				A2($elm$json$Json$Decode$field, 'session', $author$project$NativeActorRetirement$positive),
				A2($elm$json$Json$Decode$field, 'frontend', $author$project$NativeActorRetirement$positive)))),
	A7(
		$elm$json$Json$Decode$map6,
		F6(
			function (subject, request, sequence, clock, now, issuedThrough) {
				return F3(
					function (lifetime, session, frontend) {
						return {clock: clock, frontend: frontend, issuedThrough: issuedThrough, lifetime: lifetime, now: now, request: request, sequence: sequence, session: session, subject: subject};
					});
			}),
		A2($elm$json$Json$Decode$field, 'subject', $author$project$NativeActorRetirement$positive),
		A2($elm$json$Json$Decode$field, 'request', $author$project$NativeActorRetirement$positive),
		A2($elm$json$Json$Decode$field, 'sequence', $author$project$NativeActorRetirement$positive),
		A2($elm$json$Json$Decode$field, 'clock', $author$project$NativeActorRetirement$positive),
		A2($elm$json$Json$Decode$field, 'now', $author$project$NativeActorRetirement$positive),
		A2($elm$json$Json$Decode$field, 'issuedThrough', $author$project$UInt64$decoder)));
var $author$project$NativeActorRetirement$validate = function (value) {
	return _Utils_eq(value.clock, value.lifetime) && (!_Utils_eq(
		A2($author$project$UInt64$compare, value.subject, value.issuedThrough),
		$elm$core$Basics$GT));
};
var $author$project$NativeActorRetirement$actorDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var fact = _v0.a;
		var _v1 = _v0.b;
		var identity = _v1.a;
		var kind = _v1.b;
		return ((kind === 'native-actor-retired') && ($author$project$NativeActorRetirement$validate(fact._native) && (_Utils_eq(
			identity,
			'family:' + $author$project$UInt64$string(fact._native.subject)) && (!_Utils_eq(
			A2($author$project$UInt64$compare, fact.entry, fact.entryIssuedThrough),
			$elm$core$Basics$GT))))) ? $elm$json$Json$Decode$succeed(fact) : $elm$json$Json$Decode$fail('Exact native aggregate retirement fact');
	},
	A2(
		$author$project$NativeActorRetirement$strict,
		_List_fromArray(
			['kind', 'identity', 'binding', 'subject', 'entry', 'entryIssuedThrough', 'requestFloor', 'request', 'sequence', 'clock', 'now', 'issuedThrough']),
		A7(
			$elm$json$Json$Decode$map6,
			F6(
				function (_native, entry, frontier, floor, identity, kind) {
					return _Utils_Tuple2(
						A4($author$project$NativeActorRetirement$Fact, _native, entry, frontier, floor),
						_Utils_Tuple2(identity, kind));
				}),
			$author$project$NativeActorRetirement$nativeDecoder,
			A2($elm$json$Json$Decode$field, 'entry', $author$project$NativeActorRetirement$positive),
			A2($elm$json$Json$Decode$field, 'entryIssuedThrough', $author$project$NativeActorRetirement$positive),
			A2($elm$json$Json$Decode$field, 'requestFloor', $author$project$UInt64$decoder),
			A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string))));
var $author$project$PreviewPresenter$bounded = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		var size = A3(
			$elm$core$String$foldl,
			F2(
				function (c, bytes) {
					return bytes + (($elm$core$Char$toCode(c) < 128) ? 1 : (($elm$core$Char$toCode(c) < 2048) ? 2 : (($elm$core$Char$toCode(c) < 65536) ? 3 : 4)));
				}),
			0,
			value);
		var control = function (c) {
			return ($elm$core$Char$toCode(c) < 32) || (($elm$core$Char$toCode(c) >= 127) && ($elm$core$Char$toCode(c) <= 159));
		};
		return ((size <= 1024) && (!A2($elm$core$String$any, control, value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Preview label');
	},
	$elm$json$Json$Decode$string);
var $author$project$NativeActorRetirement$channelDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var kind = _v0.a;
		var binding = _v0.b;
		return (kind === 'native-actor-retirement-channel') ? $elm$json$Json$Decode$succeed(binding) : $elm$json$Json$Decode$fail('Retained native retirement channel');
	},
	A2(
		$author$project$NativeActorRetirement$strict,
		_List_fromArray(
			['kind', 'binding']),
		A3(
			$elm$json$Json$Decode$map2,
			$elm$core$Tuple$pair,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2(
				$elm$json$Json$Decode$field,
				'binding',
				A2(
					$author$project$NativeActorRetirement$strict,
					_List_fromArray(
						['lifetime', 'session', 'frontend']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (a, b, c) {
								return A2(
									$elm$core$String$join,
									':',
									A2(
										$elm$core$List$map,
										$author$project$UInt64$string,
										_List_fromArray(
											[a, b, c])));
							}),
						A2($elm$json$Json$Decode$field, 'lifetime', $author$project$NativeActorRetirement$positive),
						A2($elm$json$Json$Decode$field, 'session', $author$project$NativeActorRetirement$positive),
						A2($elm$json$Json$Decode$field, 'frontend', $author$project$NativeActorRetirement$positive)))))));
var $author$project$NativePreviewSource$GeneratedBackdropFamily = function (a) {
	return {$: 'GeneratedBackdropFamily', a: a};
};
var $author$project$NativePreviewSource$Observation = function (a) {
	return {$: 'Observation', a: a};
};
var $author$project$NativePreviewSource$StyleCroppedFamily = {$: 'StyleCroppedFamily'};
var $author$project$NativeFamilyPreviewSource$GeneratedOpaque = function (a) {
	return {$: 'GeneratedOpaque', a: a};
};
var $author$project$NativeFamilyPreviewSource$PickerTransparent = {$: 'PickerTransparent'};
var $author$project$NativeFamilyPreviewSource$Transparent = {$: 'Transparent'};
var $author$project$NativeFamilyPreviewSource$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native family positive identity');
	},
	$author$project$UInt64$decoder);
var $author$project$NativeFamilyPreviewSource$strict = F2(
	function (fields, decode) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decode : $elm$json$Json$Decode$fail('Native family fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativeFamilyPreviewSource$backdropDecoder = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['kind', 'colorARGB']),
	A2(
		$elm$json$Json$Decode$andThen,
		function (_v0) {
			var kind = _v0.a;
			var color = _v0.b;
			var value = $author$project$UInt64$string(color);
			return ((kind === 'native-opaque-generated-color') && (($elm$core$String$length(value) === 10) && ((value >= '4278190080') && (value <= '4294967295')))) ? $elm$json$Json$Decode$succeed(color) : $elm$json$Json$Decode$fail('Opaque generated native color');
		},
		A3(
			$elm$json$Json$Decode$map2,
			$elm$core$Tuple$pair,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'colorARGB', $author$project$NativeFamilyPreviewSource$positive))));
var $author$project$NativeFamilyPreviewSource$Observation = function (a) {
	return {$: 'Observation', a: a};
};
var $author$project$NativeFamilyPreviewSource$binding = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['lifetime', 'session', 'frontend']),
	A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (a, b, c) {
				return _Utils_Tuple3(a, b, c);
			}),
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$NativeFamilyPreviewSource$positive),
		A2($elm$json$Json$Decode$field, 'session', $author$project$NativeFamilyPreviewSource$positive),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$NativeFamilyPreviewSource$positive)));
var $author$project$NativeFamilyPreviewSource$Crop = F5(
	function (x, y, width, height, scale) {
		return {height: height, scale: scale, width: width, x: x, y: y};
	});
var $author$project$NativeFamilyPreviewSource$boundedInt = F2(
	function (lower, upper) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return ((_Utils_cmp(value, lower) > -1) && (_Utils_cmp(value, upper) < 1)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native family integer bound');
			},
			$elm$json$Json$Decode$int);
	});
var $elm$json$Json$Decode$float = _Json_decodeFloat;
var $elm$core$Basics$isInfinite = _Basics_isInfinite;
var $elm$core$Basics$isNaN = _Basics_isNaN;
var $author$project$NativeFamilyPreviewSource$finite = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return ($elm$core$Basics$isNaN(value) || $elm$core$Basics$isInfinite(value)) ? $elm$json$Json$Decode$fail('Finite native family value') : $elm$json$Json$Decode$succeed(value);
	},
	$elm$json$Json$Decode$float);
var $elm$core$String$slice = _String_slice;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $author$project$NativeFamilyPreviewSource$signedPixel = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		var negative = A2($elm$core$String$startsWith, '-', value);
		var limit = negative ? '2147483648' : '2147483647';
		var digits = negative ? A2($elm$core$String$dropLeft, 1, value) : value;
		return ((!$elm$core$String$isEmpty(digits)) && (A2(
			$elm$core$String$all,
			function (c) {
				return (_Utils_cmp(
					c,
					_Utils_chr('0')) > -1) && (_Utils_cmp(
					c,
					_Utils_chr('9')) < 1);
			},
			digits) && (((digits === '0') || (!A2($elm$core$String$startsWith, '0', digits))) && ((!(negative && (digits === '0'))) && (($elm$core$String$length(digits) <= 10) && (($elm$core$String$length(digits) < 10) || (_Utils_cmp(digits, limit) < 1))))))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Canonical signed native crop origin');
	},
	$elm$json$Json$Decode$string);
var $author$project$NativeFamilyPreviewSource$cropDecoder = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['pixelX', 'pixelY', 'width', 'height', 'scale']),
	A6(
		$elm$json$Json$Decode$map5,
		$author$project$NativeFamilyPreviewSource$Crop,
		A2($elm$json$Json$Decode$field, 'pixelX', $author$project$NativeFamilyPreviewSource$signedPixel),
		A2($elm$json$Json$Decode$field, 'pixelY', $author$project$NativeFamilyPreviewSource$signedPixel),
		A2(
			$elm$json$Json$Decode$field,
			'width',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 1, 4096)),
		A2(
			$elm$json$Json$Decode$field,
			'height',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 1, 4096)),
		A2(
			$elm$json$Json$Decode$field,
			'scale',
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return (value > 0) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native positive scale');
				},
				$author$project$NativeFamilyPreviewSource$finite))));
var $author$project$NativeFamilyPreviewSource$Member = F6(
	function (incarnation, parent, content, order, flags, geometry) {
		return {content: content, flags: flags, geometry: geometry, incarnation: incarnation, order: order, parent: parent};
	});
var $author$project$NativeFamilyPreviewSource$fixed = F2(
	function (size, decode) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (values) {
				return _Utils_eq(
					$elm$core$List$length(values),
					size) ? $elm$json$Json$Decode$succeed(values) : $elm$json$Json$Decode$fail('Native family vector shape');
			},
			$elm$json$Json$Decode$list(decode));
	});
var $author$project$NativeFamilyPreviewSource$memberDecoder = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['incarnation', 'parent', 'content', 'renderOrder', 'flags', 'geometry']),
	A7(
		$elm$json$Json$Decode$map6,
		$author$project$NativeFamilyPreviewSource$Member,
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$NativeFamilyPreviewSource$positive),
		A2(
			$elm$json$Json$Decode$field,
			'parent',
			$elm$json$Json$Decode$nullable($author$project$NativeFamilyPreviewSource$positive)),
		A2($elm$json$Json$Decode$field, 'content', $author$project$NativeFamilyPreviewSource$positive),
		A2(
			$elm$json$Json$Decode$field,
			'renderOrder',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 0, 2147483647)),
		A2(
			$elm$json$Json$Decode$field,
			'flags',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 0, 511)),
		A2(
			$elm$json$Json$Decode$field,
			'geometry',
			A2($author$project$NativeFamilyPreviewSource$fixed, 8, $author$project$NativeFamilyPreviewSource$finite))));
var $elm$core$Basics$modBy = _Basics_modBy;
var $author$project$NativeFamilyPreviewSource$reachesRoot = F4(
	function (root, members, remaining, current) {
		if (remaining <= 0) {
			return false;
		} else {
			var _v0 = $elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (member) {
						return _Utils_eq(member.incarnation, current);
					},
					members));
			if (_v0.$ === 'Nothing') {
				return false;
			} else {
				var member = _v0.a;
				return _Utils_eq(current, root) ? _Utils_eq(member.parent, $elm$core$Maybe$Nothing) : A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						A3($author$project$NativeFamilyPreviewSource$reachesRoot, root, members, remaining - 1),
						member.parent));
			}
		}
	});
var $author$project$PreviewLifecycle$Scope = function (a) {
	return {$: 'Scope', a: a};
};
var $author$project$PreviewLifecycle$scopeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (scope) {
		return _Utils_eq(scope.context.lifetime, scope.binding.lifetime) ? $elm$json$Json$Decode$succeed(
			$author$project$PreviewLifecycle$Scope(scope)) : $elm$json$Json$Decode$fail('Scope lifetime does not match binding');
	},
	$author$project$PreviewLifecycle$nativeScopeDecoder);
var $author$project$NativeFamilyPreviewSource$Style = F4(
	function (incarnation, flags, channels, gradients) {
		return {channels: channels, flags: flags, gradients: gradients, incarnation: incarnation};
	});
var $author$project$NativeFamilyPreviewSource$Gradient = F2(
	function (angle, colors) {
		return {angle: angle, colors: colors};
	});
var $author$project$NativeFamilyPreviewSource$gradientDecoder = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['angle', 'colors']),
	A3(
		$elm$json$Json$Decode$map2,
		$author$project$NativeFamilyPreviewSource$Gradient,
		A2($elm$json$Json$Decode$field, 'angle', $author$project$NativeFamilyPreviewSource$finite),
		A2(
			$elm$json$Json$Decode$field,
			'colors',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 0, 65536))));
var $author$project$NativeFamilyPreviewSource$styleDecoder = A2(
	$author$project$NativeFamilyPreviewSource$strict,
	_List_fromArray(
		['incarnation', 'flags', 'channels', 'gradients']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$NativeFamilyPreviewSource$Style,
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$NativeFamilyPreviewSource$positive),
		A2(
			$elm$json$Json$Decode$field,
			'flags',
			A2($author$project$NativeFamilyPreviewSource$boundedInt, 0, 4095)),
		A2(
			$elm$json$Json$Decode$field,
			'channels',
			A2($author$project$NativeFamilyPreviewSource$fixed, 18, $author$project$NativeFamilyPreviewSource$finite)),
		A2(
			$elm$json$Json$Decode$field,
			'gradients',
			A2($author$project$NativeFamilyPreviewSource$fixed, 6, $author$project$NativeFamilyPreviewSource$gradientDecoder))));
var $author$project$NativeFamilyPreviewSource$familyDecoder = function (plane_) {
	var fields = function () {
		switch (plane_.$) {
			case 'Transparent':
				return _List_Nil;
			case 'PickerTransparent':
				return _List_Nil;
			default:
				return _List_fromArray(
					['generatedBackdrop']);
		}
	}();
	var expectedLabel = function () {
		switch (plane_.$) {
			case 'Transparent':
				return 'native-family-style-crop-channels-unqualified';
			case 'PickerTransparent':
				return 'picker-native-family-style-crop';
			default:
				return 'native-generated-backdrop-family-crop-unqualified';
		}
	}();
	var expectedKind = function () {
		switch (plane_.$) {
			case 'Transparent':
				return 'preview-family-style-crop-scope';
			case 'PickerTransparent':
				return 'preview-picker-family-scope';
			default:
				return 'preview-family-backdrop-crop-scope';
		}
	}();
	return A2(
		$author$project$NativeFamilyPreviewSource$strict,
		_Utils_ap(
			fields,
			_List_fromArray(
				['protocolVersion', 'kind', 'binding', 'requestId', 'scope', 'maximumTransferBytes', 'previewEligible', 'scopeKind', 'members', 'styles', 'crop'])),
		A2(
			$elm$json$Json$Decode$andThen,
			function (wire) {
				return A2(
					$elm$json$Json$Decode$andThen,
					function (_v0) {
						var members = _v0.a;
						var styles = _v0.b;
						var crop = _v0.c;
						var styleIds = A2(
							$elm$core$List$map,
							A2(
								$elm$core$Basics$composeR,
								function ($) {
									return $.incarnation;
								},
								$author$project$UInt64$string),
							styles);
						var maximum = $author$project$UInt64$string(wire.maximum);
						var withinBudget = ($elm$core$String$length(maximum) < 9) || (($elm$core$String$length(maximum) === 9) && (maximum <= '134217728'));
						var ids = A2(
							$elm$core$List$map,
							A2(
								$elm$core$Basics$composeR,
								function ($) {
									return $.incarnation;
								},
								$author$project$UInt64$string),
							members);
						var facts = A5(
							$elm$json$Json$Decode$map4,
							F4(
								function (own, lifetime, clock, root) {
									return {clock: clock, lifetime: lifetime, own: own, root: root};
								}),
							A2($elm$json$Json$Decode$field, 'binding', $author$project$NativeFamilyPreviewSource$binding),
							A2(
								$elm$json$Json$Decode$at,
								_List_fromArray(
									['context', 'lifetime']),
								$author$project$NativeFamilyPreviewSource$positive),
							A2($elm$json$Json$Decode$field, 'clock', $author$project$NativeFamilyPreviewSource$positive),
							A2(
								$elm$json$Json$Decode$at,
								_List_fromArray(
									['context', 'incarnation']),
								$author$project$NativeFamilyPreviewSource$positive));
						var aligned = !A3(
							$elm$core$String$foldl,
							F2(
								function (digit, remainder) {
									return A2(
										$elm$core$Basics$modBy,
										4096,
										((remainder * 10) + $elm$core$Char$toCode(digit)) - 48);
								}),
							0,
							$author$project$UInt64$string(wire.maximum));
						var _v1 = _Utils_Tuple2(
							A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewLifecycle$scopeDecoder, wire.raw),
							A2($elm$json$Json$Decode$decodeValue, facts, wire.raw));
						if ((_v1.a.$ === 'Ok') && (_v1.b.$ === 'Ok')) {
							var _native = _v1.a.a;
							var current = _v1.b.a;
							return ((wire.version === 3) && (_Utils_eq(wire.kind, expectedKind) && (_Utils_eq(wire.label, expectedLabel) && (_Utils_eq(
								wire.eligible,
								_Utils_eq(plane_, $author$project$NativeFamilyPreviewSource$PickerTransparent)) && (_Utils_eq(wire.owner, current.own) && (_Utils_eq(current.lifetime, current.clock) && (aligned && (withinBudget && (($elm$core$List$length(ids) > 0) && (($elm$core$List$length(ids) <= 256) && (_Utils_eq(
								$elm$core$Set$size(
									$elm$core$Set$fromList(ids)),
								$elm$core$List$length(ids)) && (_Utils_eq(
								$elm$core$List$sort(ids),
								$elm$core$List$sort(styleIds)) && A2(
								$elm$core$List$all,
								function (member) {
									return A4(
										$author$project$NativeFamilyPreviewSource$reachesRoot,
										current.root,
										members,
										$elm$core$List$length(members),
										member.incarnation);
								},
								members))))))))))))) ? $elm$json$Json$Decode$succeed(
								$author$project$NativeFamilyPreviewSource$Observation(
									{crop: crop, maximum: wire.maximum, members: members, _native: _native, plane: plane_, raw: wire.raw, request: wire.request, styles: styles})) : $elm$json$Json$Decode$fail('Native family correlation');
						} else {
							return $elm$json$Json$Decode$fail('Native family scope');
						}
					},
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (members, styles, crop) {
								return _Utils_Tuple3(members, styles, crop);
							}),
						A2(
							$elm$json$Json$Decode$field,
							'members',
							$elm$json$Json$Decode$list($author$project$NativeFamilyPreviewSource$memberDecoder)),
						A2(
							$elm$json$Json$Decode$field,
							'styles',
							$elm$json$Json$Decode$list($author$project$NativeFamilyPreviewSource$styleDecoder)),
						A2($elm$json$Json$Decode$field, 'crop', $author$project$NativeFamilyPreviewSource$cropDecoder)));
			},
			A9(
				$elm$json$Json$Decode$map8,
				F8(
					function (version, kind, owner, request, raw, maximum, eligible, label) {
						return {eligible: eligible, kind: kind, label: label, maximum: maximum, owner: owner, raw: raw, request: request, version: version};
					}),
				A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'binding', $author$project$NativeFamilyPreviewSource$binding),
				A2($elm$json$Json$Decode$field, 'requestId', $author$project$NativeFamilyPreviewSource$positive),
				A2($elm$json$Json$Decode$field, 'scope', $elm$json$Json$Decode$value),
				A2($elm$json$Json$Decode$field, 'maximumTransferBytes', $author$project$NativeFamilyPreviewSource$positive),
				A2($elm$json$Json$Decode$field, 'previewEligible', $elm$json$Json$Decode$bool),
				A2($elm$json$Json$Decode$field, 'scopeKind', $elm$json$Json$Decode$string))));
};
var $author$project$NativeFamilyPreviewSource$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		return (kind === 'preview-family-style-crop-scope') ? $author$project$NativeFamilyPreviewSource$familyDecoder($author$project$NativeFamilyPreviewSource$Transparent) : ((kind === 'preview-picker-family-scope') ? $author$project$NativeFamilyPreviewSource$familyDecoder($author$project$NativeFamilyPreviewSource$PickerTransparent) : ((kind === 'preview-family-backdrop-crop-scope') ? A2(
			$elm$json$Json$Decode$andThen,
			A2($elm$core$Basics$composeR, $author$project$NativeFamilyPreviewSource$GeneratedOpaque, $author$project$NativeFamilyPreviewSource$familyDecoder),
			A2($elm$json$Json$Decode$field, 'generatedBackdrop', $author$project$NativeFamilyPreviewSource$backdropDecoder)) : $elm$json$Json$Decode$fail('Explicit native family source kind')));
	},
	A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
var $author$project$NativePreviewSource$ClientMain = {$: 'ClientMain'};
var $author$project$NativePreviewSource$MonitorPlane = {$: 'MonitorPlane'};
var $author$project$NativePreviewSource$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (n) {
		return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Positive native source identity');
	},
	$author$project$UInt64$decoder);
var $author$project$NativePreviewSource$strict = F2(
	function (fields, decoder_) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder_ : $elm$json$Json$Decode$fail('Native source fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativePreviewSource$binding = A2(
	$author$project$NativePreviewSource$strict,
	_List_fromArray(
		['lifetime', 'session', 'frontend']),
	A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (a, b, c) {
				return _Utils_Tuple3(a, b, c);
			}),
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$NativePreviewSource$positive),
		A2($elm$json$Json$Decode$field, 'session', $author$project$NativePreviewSource$positive),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$NativePreviewSource$positive)));
var $author$project$NativePreviewSource$legacyDecoder = A2(
	$author$project$NativePreviewSource$strict,
	_List_fromArray(
		['protocolVersion', 'kind', 'binding', 'requestId', 'scope', 'maximumTransferBytes', 'previewEligible', 'scopeKind']),
	A2(
		$elm$json$Json$Decode$andThen,
		function (wire) {
			var source_ = function () {
				var _v2 = _Utils_Tuple2(wire.kind, wire.label);
				_v2$2:
				while (true) {
					switch (_v2.a) {
						case 'preview-capture-probe-scope':
							if (_v2.b === 'root-surface-commit-monitor-plane-unqualified') {
								return $elm$core$Maybe$Just($author$project$NativePreviewSource$MonitorPlane);
							} else {
								break _v2$2;
							}
						case 'preview-client-scope':
							if (_v2.b === 'isolated-root-client-unqualified') {
								return $elm$core$Maybe$Just($author$project$NativePreviewSource$ClientMain);
							} else {
								break _v2$2;
							}
						default:
							break _v2$2;
					}
				}
				return $elm$core$Maybe$Nothing;
			}();
			var facts = A4(
				$elm$json$Json$Decode$map3,
				F3(
					function (own, lifetime, clock) {
						return _Utils_Tuple3(own, lifetime, clock);
					}),
				A2($elm$json$Json$Decode$field, 'binding', $author$project$NativePreviewSource$binding),
				A2(
					$elm$json$Json$Decode$at,
					_List_fromArray(
						['context', 'lifetime']),
					$author$project$NativePreviewSource$positive),
				A2($elm$json$Json$Decode$field, 'clock', $author$project$NativePreviewSource$positive));
			var _v0 = _Utils_Tuple3(
				source_,
				A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewLifecycle$scopeDecoder, wire.raw),
				A2($elm$json$Json$Decode$decodeValue, facts, wire.raw));
			if (((_v0.a.$ === 'Just') && (_v0.b.$ === 'Ok')) && (_v0.c.$ === 'Ok')) {
				var admitted = _v0.a.a;
				var _native = _v0.b.a;
				var _v1 = _v0.c.a;
				var own = _v1.a;
				var lifetime = _v1.b;
				var clock = _v1.c;
				return ((wire.version === 3) && ((!wire.eligible) && (_Utils_eq(wire.owner, own) && (_Utils_eq(lifetime, clock) && (!A3(
					$elm$core$String$foldl,
					F2(
						function (digit, remainder) {
							return A2(
								$elm$core$Basics$modBy,
								4096,
								((remainder * 10) + $elm$core$Char$toCode(digit)) - 48);
						}),
					0,
					$author$project$UInt64$string(wire.maximum))))))) ? $elm$json$Json$Decode$succeed(
					$author$project$NativePreviewSource$Observation(
						{maximumTransferBytes: wire.maximum, _native: _native, raw: wire.raw, request: wire.request, source: admitted})) : $elm$json$Json$Decode$fail('Native source grant/clock/eligibility');
			} else {
				return $elm$json$Json$Decode$fail('Typed native source kind/scope');
			}
		},
		A9(
			$elm$json$Json$Decode$map8,
			F8(
				function (version, kind, owner, request, raw, maximum, eligible, label) {
					return {eligible: eligible, kind: kind, label: label, maximum: maximum, owner: owner, raw: raw, request: request, version: version};
				}),
			A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'binding', $author$project$NativePreviewSource$binding),
			A2($elm$json$Json$Decode$field, 'requestId', $author$project$NativePreviewSource$positive),
			A2($elm$json$Json$Decode$field, 'scope', $elm$json$Json$Decode$value),
			A2($elm$json$Json$Decode$field, 'maximumTransferBytes', $author$project$NativePreviewSource$positive),
			A2($elm$json$Json$Decode$field, 'previewEligible', $elm$json$Json$Decode$bool),
			A2($elm$json$Json$Decode$field, 'scopeKind', $elm$json$Json$Decode$string))));
var $author$project$NativeFamilyPreviewSource$maximumTransfer = function (_v0) {
	var value = _v0.a;
	return value.maximum;
};
var $author$project$NativeFamilyPreviewSource$plane = function (_v0) {
	var value = _v0.a;
	return value.plane;
};
var $author$project$NativeFamilyPreviewSource$rawScope = function (_v0) {
	var value = _v0.a;
	return value.raw;
};
var $author$project$NativeFamilyPreviewSource$requestIdentity = function (_v0) {
	var value = _v0.a;
	return value.request;
};
var $author$project$NativeFamilyPreviewSource$scope = function (_v0) {
	var value = _v0.a;
	return value._native;
};
var $author$project$NativePreviewSource$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		return ((kind === 'preview-family-style-crop-scope') || ((kind === 'preview-family-backdrop-crop-scope') || (kind === 'preview-picker-family-scope'))) ? A2(
			$elm$json$Json$Decode$map,
			function (family) {
				return $author$project$NativePreviewSource$Observation(
					{
						maximumTransferBytes: $author$project$NativeFamilyPreviewSource$maximumTransfer(family),
						_native: $author$project$NativeFamilyPreviewSource$scope(family),
						raw: $author$project$NativeFamilyPreviewSource$rawScope(family),
						request: $author$project$NativeFamilyPreviewSource$requestIdentity(family),
						source: function () {
							var _v0 = $author$project$NativeFamilyPreviewSource$plane(family);
							switch (_v0.$) {
								case 'Transparent':
									return $author$project$NativePreviewSource$StyleCroppedFamily;
								case 'PickerTransparent':
									return $author$project$NativePreviewSource$PickerFamily;
								default:
									var color = _v0.a;
									return $author$project$NativePreviewSource$GeneratedBackdropFamily(color);
							}
						}()
					});
			},
			$author$project$NativeFamilyPreviewSource$decoder) : $author$project$NativePreviewSource$legacyDecoder;
	},
	A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
var $author$project$NativeActorRetirement$Delivery = F2(
	function (ordinal, fact) {
		return {fact: fact, ordinal: ordinal};
	});
var $author$project$NativeActorRetirement$deliveryDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var kind = _v0.a;
		var delivery = _v0.b;
		return (kind === 'native-actor-retirement-delivery') ? $elm$json$Json$Decode$succeed(delivery) : $elm$json$Json$Decode$fail('Retained native retirement delivery');
	},
	A2(
		$author$project$NativeActorRetirement$strict,
		_List_fromArray(
			['kind', 'deliveryOrdinal', 'fact']),
		A4(
			$elm$json$Json$Decode$map3,
			F3(
				function (kind, ordinal, fact) {
					return _Utils_Tuple2(
						kind,
						A2($author$project$NativeActorRetirement$Delivery, ordinal, fact));
				}),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'deliveryOrdinal', $author$project$NativeActorRetirement$positive),
			A2($elm$json$Json$Decode$field, 'fact', $author$project$NativeActorRetirement$actorDecoder))));
var $author$project$NativePreviewDetachment$Delivery = F2(
	function (ordinal, seed) {
		return {ordinal: ordinal, seed: seed};
	});
var $author$project$NativePreviewDetachment$Seed = F5(
	function (domain, subject, entry, entryIssuedThrough, requestFloor) {
		return {domain: domain, entry: entry, entryIssuedThrough: entryIssuedThrough, requestFloor: requestFloor, subject: subject};
	});
var $author$project$NativePreviewDetachment$coherent = function (seed) {
	return !_Utils_eq(
		A2($author$project$UInt64$compare, seed.entry, seed.entryIssuedThrough),
		$elm$core$Basics$GT);
};
var $author$project$NativePreviewDetachment$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Positive scoped detachment identity');
	},
	$author$project$UInt64$decoder);
var $author$project$NativePreviewDetachment$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Exact scoped preview detachment fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativePreviewDetachment$eventDecoder = function (domain) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (_v0) {
			var kind = _v0.a;
			var identity = _v0.b;
			var seed = _v0.c;
			return ((kind === 'native-preview-actor-detached') && (_Utils_eq(
				identity,
				'family:' + $author$project$UInt64$string(seed.subject)) && $author$project$NativePreviewDetachment$coherent(seed))) ? $elm$json$Json$Decode$succeed(seed) : $elm$json$Json$Decode$fail('Distinct native preview membership completion');
		},
		A2(
			$author$project$NativePreviewDetachment$strict,
			_List_fromArray(
				['kind', 'identity', 'subject', 'entry', 'entryIssuedThrough', 'requestFloor']),
			A7(
				$elm$json$Json$Decode$map6,
				F6(
					function (kind, identity, subject, entry, frontier, floor) {
						return _Utils_Tuple3(
							kind,
							identity,
							A5($author$project$NativePreviewDetachment$Seed, domain, subject, entry, frontier, floor));
					}),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'subject', $author$project$NativePreviewDetachment$positive),
				A2($elm$json$Json$Decode$field, 'entry', $author$project$NativePreviewDetachment$positive),
				A2($elm$json$Json$Decode$field, 'entryIssuedThrough', $author$project$NativePreviewDetachment$positive),
				A2($elm$json$Json$Decode$field, 'requestFloor', $author$project$UInt64$decoder))));
};
var $author$project$NativePreviewDetachment$deliveryDecoder = A2(
	$author$project$NativePreviewDetachment$strict,
	_List_fromArray(
		['detachProtocol', 'kind', 'binding', 'receiverEpoch', 'deliveryOrdinal', 'event']),
	A2(
		$elm$json$Json$Decode$andThen,
		function (_v0) {
			var protocol = _v0.a;
			var kind = _v0.b;
			var _v1 = _v0.c;
			var domain = _v1.a;
			var ordinal = _v1.b;
			return ((protocol === 1) && (kind === 'native-preview-binding-detach-delivery')) ? A2(
				$elm$json$Json$Decode$map,
				$author$project$NativePreviewDetachment$Delivery(ordinal),
				A2(
					$elm$json$Json$Decode$field,
					'event',
					$author$project$NativePreviewDetachment$eventDecoder(domain))) : $elm$json$Json$Decode$fail('Distinct retained scoped detachment delivery');
		},
		A5(
			$elm$json$Json$Decode$map4,
			F4(
				function (protocol, kind, domain, ordinal) {
					return _Utils_Tuple3(
						protocol,
						kind,
						_Utils_Tuple2(domain, ordinal));
				}),
			A2($elm$json$Json$Decode$field, 'detachProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			$author$project$NativePreviewRealm$domainDecoder,
			A2($elm$json$Json$Decode$field, 'deliveryOrdinal', $author$project$NativePreviewDetachment$positive))));
var $author$project$PreviewLifecycle$IconHandle = function (a) {
	return {$: 'IconHandle', a: a};
};
var $author$project$PreviewLifecycle$iconDecoder = A2($elm$json$Json$Decode$map, $author$project$PreviewLifecycle$IconHandle, $author$project$PreviewLifecycle$opaqueDecoder);
var $author$project$NativeActorRetirement$observationDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var value = _v0.a;
		var state = _v0.b;
		return ((state === 'Retired') && $author$project$NativeActorRetirement$validate(value)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Exact permanent native retirement observation');
	},
	A2(
		$author$project$NativeActorRetirement$strict,
		_List_fromArray(
			['kind', 'binding', 'subject', 'request', 'sequence', 'clock', 'now', 'issuedThrough', 'state']),
		A3(
			$elm$json$Json$Decode$map2,
			$elm$core$Tuple$pair,
			$author$project$NativeActorRetirement$nativeDecoder,
			A2($elm$json$Json$Decode$field, 'state', $elm$json$Json$Decode$string))));
var $author$project$PreviewPresenter$Capacity = {$: 'Capacity'};
var $author$project$PreviewPresenter$Conflict = {$: 'Conflict'};
var $author$project$PreviewPresenter$Exhausted = {$: 'Exhausted'};
var $author$project$PreviewPresenter$Expired = {$: 'Expired'};
var $author$project$PreviewPresenter$Waiting = {$: 'Waiting'};
var $author$project$PreviewPresenter$outcomeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'capacity':
				return $elm$json$Json$Decode$succeed($author$project$PreviewPresenter$Capacity);
			case 'waiting':
				return $elm$json$Json$Decode$succeed($author$project$PreviewPresenter$Waiting);
			case 'expired':
				return $elm$json$Json$Decode$succeed($author$project$PreviewPresenter$Expired);
			case 'conflict':
				return $elm$json$Json$Decode$succeed($author$project$PreviewPresenter$Conflict);
			case 'exhausted':
				return $elm$json$Json$Decode$succeed($author$project$PreviewPresenter$Exhausted);
			default:
				return $elm$json$Json$Decode$fail('Typed local preview outcome');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$NativePreviewSource$scope = function (_v0) {
	var value = _v0.a;
	return value._native;
};
var $author$project$NativePreviewDetachment$seedDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var protocol = _v0.a;
		var kind = _v0.b;
		var _v1 = _v0.c;
		var identity = _v1.a;
		var seed = _v1.b;
		return ((protocol === 1) && ((kind === 'native-preview-detach-seed') && (_Utils_eq(
			identity,
			'family:' + $author$project$UInt64$string(seed.subject)) && $author$project$NativePreviewDetachment$coherent(seed)))) ? $elm$json$Json$Decode$succeed(seed) : $elm$json$Json$Decode$fail('Exact native scoped detachment seed');
	},
	A2(
		$author$project$NativePreviewDetachment$strict,
		_List_fromArray(
			['detachProtocol', 'kind', 'identity', 'binding', 'receiverEpoch', 'subject', 'entry', 'entryIssuedThrough', 'requestFloor']),
		A9(
			$elm$json$Json$Decode$map8,
			F8(
				function (protocol, kind, identity, domain, subject, entry, frontier, floor) {
					return _Utils_Tuple3(
						protocol,
						kind,
						_Utils_Tuple2(
							identity,
							A5($author$project$NativePreviewDetachment$Seed, domain, subject, entry, frontier, floor)));
				}),
			A2($elm$json$Json$Decode$field, 'detachProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'identity', $elm$json$Json$Decode$string),
			$author$project$NativePreviewRealm$domainDecoder,
			A2($elm$json$Json$Decode$field, 'subject', $author$project$NativePreviewDetachment$positive),
			A2($elm$json$Json$Decode$field, 'entry', $author$project$NativePreviewDetachment$positive),
			A2($elm$json$Json$Decode$field, 'entryIssuedThrough', $author$project$NativePreviewDetachment$positive),
			A2($elm$json$Json$Decode$field, 'requestFloor', $author$project$UInt64$decoder))));
var $author$project$NativePreviewSource$source = function (_v0) {
	var value = _v0.a;
	return value.source;
};
var $author$project$PreviewPresenter$Window = F4(
	function (subject, title, application, minimized) {
		return {application: application, minimized: minimized, subject: subject, title: title};
	});
var $author$project$PreviewPresenter$windows = A2(
	$elm$json$Json$Decode$andThen,
	function (rows) {
		return (($elm$core$List$length(rows) <= 256) && _Utils_eq(
			$elm$core$Set$size(
				$elm$core$Set$fromList(
					A2(
						$elm$core$List$map,
						A2(
							$elm$core$Basics$composeR,
							function ($) {
								return $.subject;
							},
							$author$project$UInt64$string),
						rows))),
			$elm$core$List$length(rows))) ? $elm$json$Json$Decode$succeed(rows) : $elm$json$Json$Decode$fail('Unique bounded catalog');
	},
	$elm$json$Json$Decode$list(
		A2(
			$author$project$PreviewPresenter$strict,
			_List_fromArray(
				['incarnation', 'application', 'label', 'minimized']),
			A5(
				$elm$json$Json$Decode$map4,
				$author$project$PreviewPresenter$Window,
				A2($elm$json$Json$Decode$field, 'incarnation', $author$project$PreviewPresenter$positive),
				A2($elm$json$Json$Decode$field, 'label', $author$project$PreviewPresenter$bounded),
				A2($elm$json$Json$Decode$field, 'application', $author$project$PreviewPresenter$bounded),
				A2($elm$json$Json$Decode$field, 'minimized', $elm$json$Json$Decode$bool)))));
var $author$project$PreviewPresenter$input = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		switch (kind) {
			case 'native-preview-detach-seed':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$DetachSeed, $author$project$NativePreviewDetachment$seedDecoder);
			case 'native-preview-binding-detach-delivery':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$Detached, $author$project$NativePreviewDetachment$deliveryDecoder);
			case 'native-incarnation-retirement':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$Retirement, $author$project$NativeActorRetirement$observationDecoder);
			case 'native-actor-retired':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$Retired, $author$project$NativeActorRetirement$actorDecoder);
			case 'native-actor-retirement-channel':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$RetirementChannel, $author$project$NativeActorRetirement$channelDecoder);
			case 'native-actor-retirement-delivery':
				return A2($elm$json$Json$Decode$map, $author$project$PreviewPresenter$RetirementDelivery, $author$project$NativeActorRetirement$deliveryDecoder);
			case 'demand-feedback':
				return A2(
					$author$project$PreviewPresenter$strict,
					_List_fromArray(
						['kind', 'identity', 'binding', 'subject', 'clock', 'publication', 'lease', 'sequence', 'deadline', 'outcome']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (identity, stamp, value) {
								return A2(
									$author$project$PreviewPresenter$Feedback,
									identity,
									_Utils_update(
										value,
										{stamp: stamp}));
							}),
						A2($elm$json$Json$Decode$field, 'identity', $author$project$PreviewPresenter$bounded),
						A3(
							$elm$json$Json$Decode$map2,
							$author$project$PreviewPresenter$Stamp,
							A2($elm$json$Json$Decode$field, 'publication', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'lease', $author$project$PreviewPresenter$positive)),
						A7(
							$elm$json$Json$Decode$map6,
							F6(
								function (owner, subject, clock, sequence, deadline, outcome) {
									return {
										clock: clock,
										deadline: deadline,
										outcome: outcome,
										owner: owner,
										sequence: sequence,
										stamp: {lease: $author$project$UInt64$zero, publication: $author$project$UInt64$zero},
										subject: subject
									};
								}),
							A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewPresenter$binding),
							A2($elm$json$Json$Decode$field, 'subject', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'clock', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'sequence', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'deadline', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'outcome', $author$project$PreviewPresenter$outcomeDecoder))));
			case 'catalog':
				return A2(
					$author$project$PreviewPresenter$strict,
					_List_fromArray(
						['protocolVersion', 'kind', 'publication', 'lease', 'binding', 'requestId', 'sequence', 'revision', 'windows']),
					A2(
						$elm$json$Json$Decode$andThen,
						function (_v1) {
							var protocol = _v1.a;
							var result = _v1.b;
							return (protocol === 3) ? $elm$json$Json$Decode$succeed(result) : $elm$json$Json$Decode$fail('Native catalog protocol');
						},
						A9(
							$elm$json$Json$Decode$map8,
							F8(
								function (protocol, publication, lease, owner, request, sequence, revision, rows) {
									return _Utils_Tuple2(
										protocol,
										A3(
											$author$project$PreviewPresenter$Catalog,
											{lease: lease, publication: publication},
											{binding: owner, request: request, revision: revision, sequence: sequence},
											rows));
								}),
							A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
							A2($elm$json$Json$Decode$field, 'publication', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'lease', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewPresenter$binding),
							A2($elm$json$Json$Decode$field, 'requestId', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'sequence', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'revision', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'windows', $author$project$PreviewPresenter$windows))));
			case 'seed':
				return A2(
					$author$project$PreviewPresenter$strict,
					_List_fromArray(
						['kind', 'publication', 'lease', 'identity', 'scope', 'title', 'application']),
					A2(
						$elm$json$Json$Decode$andThen,
						function (seed) {
							var _v2 = _Utils_Tuple2(
								A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewLifecycle$scopeDecoder, seed.raw),
								A2(
									$elm$json$Json$Decode$decodeValue,
									A2(
										$elm$json$Json$Decode$at,
										_List_fromArray(
											['context', 'incarnation']),
										$author$project$PreviewPresenter$positive),
									seed.raw));
							if ((_v2.a.$ === 'Ok') && (_v2.b.$ === 'Ok')) {
								var scope = _v2.a.a;
								var incarnation = _v2.b.a;
								return _Utils_eq(
									seed.identity,
									'family:' + $author$project$UInt64$string(incarnation)) ? $elm$json$Json$Decode$succeed(
									$author$project$PreviewPresenter$Seed(
										{lease: seed.lease, publication: seed.publication})(seed.identity)(scope)(seed.raw)(seed.title)(seed.application)(seed.owner)($elm$core$Maybe$Nothing)(false)($elm$core$Maybe$Nothing)) : $elm$json$Json$Decode$fail('Preview control incarnation mismatch');
							} else {
								return $elm$json$Json$Decode$fail('Native preview scope');
							}
						},
						A8(
							$elm$json$Json$Decode$map7,
							F7(
								function (publication, lease, identity, raw, title, application, owner) {
									return {application: application, identity: identity, lease: lease, owner: owner, publication: publication, raw: raw, title: title};
								}),
							A2($elm$json$Json$Decode$field, 'publication', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'lease', $author$project$PreviewPresenter$positive),
							A2($elm$json$Json$Decode$field, 'identity', $author$project$PreviewPresenter$bounded),
							A2($elm$json$Json$Decode$field, 'scope', $elm$json$Json$Decode$value),
							A2($elm$json$Json$Decode$field, 'title', $author$project$PreviewPresenter$bounded),
							A2($elm$json$Json$Decode$field, 'application', $author$project$PreviewPresenter$bounded),
							A2(
								$elm$json$Json$Decode$at,
								_List_fromArray(
									['scope', 'binding']),
								$author$project$PreviewPresenter$binding))));
			default:
				var sourceSeedKind = kind;
				if (A2(
					$elm$core$List$member,
					sourceSeedKind,
					_List_fromArray(
						['source-seed', 'demand-seed']))) {
					return A2(
						$author$project$PreviewPresenter$strict,
						_List_fromArray(
							['kind', 'publication', 'lease', 'identity', 'source', 'title', 'application']),
						A2(
							$elm$json$Json$Decode$andThen,
							function (seed) {
								var _v3 = _Utils_Tuple2(
									A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewSource$decoder, seed.raw),
									A2(
										$elm$json$Json$Decode$decodeValue,
										A4(
											$elm$json$Json$Decode$map3,
											F3(
												function (_native, incarnation, owner) {
													return _Utils_Tuple3(_native, incarnation, owner);
												}),
											A2($elm$json$Json$Decode$field, 'scope', $elm$json$Json$Decode$value),
											A2(
												$elm$json$Json$Decode$at,
												_List_fromArray(
													['scope', 'context', 'incarnation']),
												$author$project$PreviewPresenter$positive),
											A2(
												$elm$json$Json$Decode$at,
												_List_fromArray(
													['scope', 'binding']),
												$author$project$PreviewPresenter$binding)),
										seed.raw));
								if ((_v3.a.$ === 'Ok') && (_v3.b.$ === 'Ok')) {
									var observation = _v3.a.a;
									var _v4 = _v3.b.a;
									var _native = _v4.a;
									var incarnation = _v4.b;
									var owner = _v4.c;
									return _Utils_eq(
										seed.identity,
										'family:' + $author$project$UInt64$string(incarnation)) ? $elm$json$Json$Decode$succeed(
										$author$project$PreviewPresenter$Seed(
											{lease: seed.lease, publication: seed.publication})(seed.identity)(
											$author$project$NativePreviewSource$scope(observation))(_native)(seed.title)(seed.application)(owner)(
											$elm$core$Maybe$Just(
												$author$project$NativePreviewSource$source(observation)))(sourceSeedKind === 'demand-seed')(
											$elm$core$Result$toMaybe(
												A2(
													$elm$json$Json$Decode$decodeValue,
													A2($elm$json$Json$Decode$field, 'requestId', $author$project$PreviewPresenter$positive),
													seed.raw)))) : $elm$json$Json$Decode$fail('Typed source control incarnation mismatch');
								} else {
									return $elm$json$Json$Decode$fail('Typed native preview source');
								}
							},
							A7(
								$elm$json$Json$Decode$map6,
								F6(
									function (publication, lease, identity, raw, title, application) {
										return {application: application, identity: identity, lease: lease, publication: publication, raw: raw, title: title};
									}),
								A2($elm$json$Json$Decode$field, 'publication', $author$project$PreviewPresenter$positive),
								A2($elm$json$Json$Decode$field, 'lease', $author$project$PreviewPresenter$positive),
								A2($elm$json$Json$Decode$field, 'identity', $author$project$PreviewPresenter$bounded),
								A2($elm$json$Json$Decode$field, 'source', $elm$json$Json$Decode$value),
								A2($elm$json$Json$Decode$field, 'title', $author$project$PreviewPresenter$bounded),
								A2($elm$json$Json$Decode$field, 'application', $author$project$PreviewPresenter$bounded))));
				} else {
					switch (sourceSeedKind) {
						case 'metadata':
							return A2(
								$author$project$PreviewPresenter$strict,
								_List_fromArray(
									['kind', 'identity', 'binding', 'subject', 'revision', 'title', 'application', 'icon', 'iconKind']),
								A9(
									$elm$json$Json$Decode$map8,
									$author$project$PreviewPresenter$Metadata,
									A2($elm$json$Json$Decode$field, 'identity', $author$project$PreviewPresenter$bounded),
									A2($elm$json$Json$Decode$field, 'binding', $author$project$PreviewPresenter$binding),
									A2($elm$json$Json$Decode$field, 'subject', $author$project$PreviewPresenter$positive),
									A2($elm$json$Json$Decode$field, 'revision', $author$project$PreviewPresenter$positive),
									A2($elm$json$Json$Decode$field, 'title', $author$project$PreviewPresenter$bounded),
									A2($elm$json$Json$Decode$field, 'application', $author$project$PreviewPresenter$bounded),
									A2(
										$elm$json$Json$Decode$field,
										'icon',
										$elm$json$Json$Decode$nullable($author$project$PreviewLifecycle$iconDecoder)),
									A2(
										$elm$json$Json$Decode$field,
										'iconKind',
										A2(
											$elm$json$Json$Decode$andThen,
											function (resolution) {
												return A2(
													$elm$core$List$member,
													resolution,
													_List_fromArray(
														['application', 'generic', 'unavailable'])) ? $elm$json$Json$Decode$succeed(resolution) : $elm$json$Json$Decode$fail('Native icon resolution');
											},
											$elm$json$Json$Decode$string))));
						case 'event':
							return A2(
								$author$project$PreviewPresenter$strict,
								_List_fromArray(
									['kind', 'identity', 'event']),
								A4(
									$elm$json$Json$Decode$map3,
									$author$project$PreviewPresenter$Event,
									A2($elm$json$Json$Decode$field, 'identity', $author$project$PreviewPresenter$bounded),
									A2($elm$json$Json$Decode$field, 'event', $author$project$PreviewLifecycle$eventDecoder),
									A2($elm$json$Json$Decode$field, 'event', $elm$json$Json$Decode$value)));
						default:
							return $elm$json$Json$Decode$fail('Preview presenter kind');
					}
				}
		}
	},
	A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
var $author$project$PreviewPresenter$eventRealmOwned = F2(
	function (domain, wire) {
		var owns = function (path) {
			return _Utils_eq(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$at, path, $author$project$PreviewPresenter$binding),
					wire),
				$elm$core$Result$Ok(
					$author$project$NativePreviewRealm$owner(domain)));
		};
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			wire);
		if (_v0.$ === 'Ok') {
			switch (_v0.a) {
				case 'open':
					return true;
				case 'close':
					return true;
				case 'request':
					return owns(
						_List_fromArray(
							['trigger', 'binding']));
				case 'observe':
					return owns(
						_List_fromArray(
							['scope', 'binding']));
				case 'attach':
					return owns(
						_List_fromArray(
							['previous'])) && owns(
						_List_fromArray(
							['scope', 'binding']));
				case 'clock':
					return owns(
						_List_fromArray(
							['binding']));
				case 'exhausted':
					return owns(
						_List_fromArray(
							['binding']));
				case 'source-denied':
					return owns(
						_List_fromArray(
							['job', 'binding']));
				case 'refused':
					return owns(
						_List_fromArray(
							['job', 'binding']));
				case 'cancelled':
					return owns(
						_List_fromArray(
							['job', 'binding']));
				case 'receipt':
					return A2(
						$elm$core$Result$withDefault,
						false,
						A2(
							$elm$core$Result$map,
							$author$project$PreviewPresenter$eventRealmOwned(domain),
							A2(
								$elm$json$Json$Decode$decodeValue,
								A2($elm$json$Json$Decode$field, 'event', $elm$json$Json$Decode$value),
								wire)));
				default:
					var kind = _v0.a;
					return A2(
						$elm$core$List$member,
						kind,
						_List_fromArray(
							['offer', 'fence', 'expired', 'released'])) && owns(
						_List_fromArray(
							['frame', 'job', 'binding']));
			}
		} else {
			return false;
		}
	});
var $author$project$PreviewPresenter$inputRealmOwned = F2(
	function (scoped, decoded) {
		var _v0 = scoped.grant;
		if (_v0.$ === 'Nothing') {
			return true;
		} else {
			var grant = _v0.a;
			var own = function (owner) {
				return _Utils_eq(
					owner,
					$author$project$NativePreviewRealm$owner(grant.domain));
			};
			switch (decoded.$) {
				case 'Seed':
					var owner = decoded.g;
					return own(owner);
				case 'Catalog':
					var current = decoded.b;
					return own(current.binding);
				case 'Metadata':
					var owner = decoded.b;
					return own(owner);
				case 'Feedback':
					var local = decoded.b;
					return own(local.owner);
				case 'Event':
					var wire = decoded.c;
					return A2($author$project$PreviewPresenter$eventRealmOwned, grant.domain, wire);
				case 'Retirement':
					var observation = decoded.a;
					return own(
						$author$project$NativeActorRetirement$owner(observation));
				case 'Retired':
					var fact = decoded.a;
					return own(
						$author$project$NativeActorRetirement$owner(fact._native));
				case 'RetirementChannel':
					var owner = decoded.a;
					return own(owner);
				case 'RetirementDelivery':
					var delivery = decoded.a;
					return own(
						$author$project$NativeActorRetirement$owner(delivery.fact._native));
				case 'DetachSeed':
					var seed = decoded.a;
					return A2($author$project$NativePreviewRealm$same, grant.domain, seed.domain);
				default:
					var delivery = decoded.a;
					return A2($author$project$NativePreviewRealm$same, grant.domain, delivery.seed.domain);
			}
		}
	});
var $author$project$PreviewPresenter$retireEntry = function (entry) {
	var _v0 = entry.model;
	if (_v0.$ === 'Nothing') {
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{local: $elm$core$Maybe$Nothing, stamp: $elm$core$Maybe$Nothing}),
			_List_Nil);
	} else {
		var lifecycle = _v0.a;
		var _v1 = $author$project$PreviewLifecycle$retire(lifecycle);
		var retiring = _v1.a;
		var commands = _v1.b;
		return _Utils_Tuple2(
			_Utils_update(
				entry,
				{
					local: $elm$core$Maybe$Nothing,
					model: $elm$core$Maybe$Just(retiring),
					stamp: $elm$core$Maybe$Nothing
				}),
			commands);
	}
};
var $author$project$PreviewPresenter$sameSourcePlane = F2(
	function (old, current) {
		var _v0 = _Utils_Tuple2(old, current);
		if ((((_v0.a.$ === 'Just') && (_v0.a.a.$ === 'GeneratedBackdropFamily')) && (_v0.b.$ === 'Just')) && (_v0.b.a.$ === 'GeneratedBackdropFamily')) {
			return true;
		} else {
			return _Utils_eq(old, current);
		}
	});
var $author$project$NativeActorRetirement$scopeBefore = F2(
	function (observation, raw) {
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A3(
				$elm$json$Json$Decode$map2,
				$elm$core$Tuple$pair,
				A2($elm$json$Json$Decode$field, 'clock', $author$project$NativeActorRetirement$positive),
				A2($elm$json$Json$Decode$field, 'now', $author$project$NativeActorRetirement$positive)),
			raw);
		if (_v0.$ === 'Ok') {
			var _v1 = _v0.a;
			var clock = _v1.a;
			var now = _v1.b;
			return _Utils_eq(clock, observation.clock) && (!_Utils_eq(
				A2($author$project$UInt64$compare, observation.now, now),
				$elm$core$Basics$LT));
		} else {
			return false;
		}
	});
var $author$project$PreviewLifecycle$settled = function (_v0) {
	var st = _v0.a;
	return (!st.demand) && (_Utils_eq(st.capture, $author$project$PreviewLifecycle$Idle) && (_Utils_eq(st.accepted, $elm$core$Maybe$Nothing) && ($elm$core$List$isEmpty(st.known) && ($elm$core$List$isEmpty(st.cancelling) && $elm$core$List$isEmpty(st.retiring)))));
};
var $author$project$NativeActorRetirement$settles = F2(
	function (pending, fact) {
		return _Utils_eq(fact._native.subject, pending.subject) && A2(
			$author$project$NativeActorRetirement$fresh,
			$elm$core$Maybe$Just(pending),
			fact._native);
	});
var $elm$core$Dict$update = F3(
	function (targetKey, alter, dictionary) {
		var _v0 = alter(
			A2($elm$core$Dict$get, targetKey, dictionary));
		if (_v0.$ === 'Just') {
			var value = _v0.a;
			return A3($elm$core$Dict$insert, targetKey, value, dictionary);
		} else {
			return A2($elm$core$Dict$remove, targetKey, dictionary);
		}
	});
var $author$project$PreviewPresenter$receiveInput = F3(
	function (snapshot, raw, prior) {
		var entries = prior.a;
		var previousCatalog = prior.b;
		var ledger = prior.c;
		var scoped = prior.d;
		var _v0 = A2(
			$elm$core$Result$andThen,
			function (decoded) {
				return A2($author$project$PreviewPresenter$inputRealmOwned, scoped, decoded) ? $elm$core$Result$Ok(decoded) : $elm$core$Result$Err(
					A2($elm$json$Json$Decode$Failure, 'Original native realm owns the inner event', raw));
			},
			A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewPresenter$input, raw));
		if (_v0.$ === 'Err') {
			return _Utils_Tuple2(
				prior,
				$author$project$PreviewPresenter$encode(_List_Nil));
		} else {
			switch (_v0.a.$) {
				case 'DetachSeed':
					var seed = _v0.a.a;
					var own = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (grant) {
								return A2($author$project$NativePreviewRealm$same, grant.domain, seed.domain);
							},
							scoped.grant));
					var identity = 'family:' + $author$project$UInt64$string(seed.subject);
					if ((!own) || scoped.closed) {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var _v1 = A2($elm$core$Dict$get, identity, entries);
						if (_v1.$ === 'Nothing') {
							return _Utils_Tuple2(
								prior,
								$author$project$PreviewPresenter$encode(_List_Nil));
						} else {
							var entry = _v1.a;
							if ((!_Utils_eq(
								entry.binding,
								$author$project$NativePreviewRealm$owner(seed.domain))) || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || ((!A2($author$project$PreviewPresenter$floorMatches, entry, seed)) || ((!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)) && (!_Utils_eq(
								entry.detachment,
								$elm$core$Maybe$Just(seed))))))) {
								return _Utils_Tuple2(
									prior,
									$author$project$PreviewPresenter$encode(_List_Nil));
							} else {
								var _v2 = $author$project$PreviewPresenter$quarantineOwned(prior);
								var _v3 = _v2.a;
								var retained = _v3.a;
								var catalog = _v3.b;
								var held = _v3.c;
								var nextScoped = _v3.d;
								var cleanup = _v2.b;
								var updated = A3(
									$elm$core$Dict$update,
									identity,
									$elm$core$Maybe$map(
										function (row) {
											return _Utils_update(
												row,
												{
													detachment: $elm$core$Maybe$Just(seed)
												});
										}),
									retained);
								return _Utils_Tuple2(
									A4($author$project$PreviewPresenter$Model, updated, catalog, held, nextScoped),
									cleanup);
							}
						}
					}
				case 'Detached':
					var delivery = _v0.a.a;
					var seed = delivery.seed;
					var own = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (grant) {
								return A2($author$project$NativePreviewRealm$same, grant.domain, seed.domain);
							},
							scoped.grant));
					var identity = 'family:' + $author$project$UInt64$string(seed.subject);
					var ack = A2(
						$elm$json$Json$Encode$list,
						function (value) {
							return value;
						},
						_List_fromArray(
							[
								$elm$json$Json$Encode$object(
								_List_fromArray(
									[
										_Utils_Tuple2(
										'identity',
										$elm$json$Json$Encode$string(identity)),
										_Utils_Tuple2(
										'commands',
										A2(
											$elm$json$Json$Encode$list,
											function (value) {
												return value;
											},
											_List_fromArray(
												[
													$author$project$NativePreviewDetachment$acknowledgment(delivery)
												])))
									]))
							]));
					if ((!own) || scoped.closed) {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						if (!_Utils_eq(
							A2($author$project$UInt64$compare, delivery.ordinal, scoped.processed),
							$elm$core$Basics$GT)) {
							return _Utils_eq(
								A2($elm$core$Dict$get, identity, scoped.completed),
								$elm$core$Maybe$Just(
									_Utils_Tuple2(delivery.ordinal, seed))) ? _Utils_Tuple2(prior, ack) : _Utils_Tuple2(
								prior,
								$author$project$PreviewPresenter$encode(_List_Nil));
						} else {
							if (!_Utils_eq(
								$author$project$UInt64$next(scoped.processed),
								$elm$core$Maybe$Just(delivery.ordinal))) {
								return _Utils_Tuple2(
									prior,
									$author$project$PreviewPresenter$encode(_List_Nil));
							} else {
								var _v4 = A2($elm$core$Dict$get, identity, entries);
								if (_v4.$ === 'Nothing') {
									return _Utils_Tuple2(
										prior,
										$author$project$PreviewPresenter$encode(_List_Nil));
								} else {
									var entry = _v4.a;
									return ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || ((!entry.detachReadySent) || ((!_Utils_eq(
										entry.detachment,
										$elm$core$Maybe$Just(seed))) || ((!A2($author$project$PreviewPresenter$floorMatches, entry, seed)) || ((!A2(
										$elm$core$Maybe$withDefault,
										true,
										A2($elm$core$Maybe$map, $author$project$PreviewLifecycle$settled, entry.model))) || ($elm$core$Dict$size(scoped.completed) >= 256)))))) ? _Utils_Tuple2(
										prior,
										$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
										A4(
											$author$project$PreviewPresenter$Model,
											A2($elm$core$Dict$remove, identity, entries),
											previousCatalog,
											ledger,
											_Utils_update(
												scoped,
												{
													completed: A3(
														$elm$core$Dict$insert,
														identity,
														_Utils_Tuple2(delivery.ordinal, seed),
														scoped.completed),
													processed: delivery.ordinal
												})),
										ack);
								}
							}
						}
					}
				case 'RetirementChannel':
					var owner = _v0.a.a;
					var known = ((!$elm$core$Dict$isEmpty(entries)) || A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (catalog) {
								return _Utils_eq(catalog.binding, owner);
							},
							previousCatalog))) && A2(
						$elm$core$List$all,
						function (entry) {
							return _Utils_eq(entry.binding, owner);
						},
						$elm$core$Dict$values(entries));
					return _Utils_eq(
						ledger.channel,
						$elm$core$Maybe$Just(owner)) ? _Utils_Tuple2(
						prior,
						$author$project$PreviewPresenter$encode(_List_Nil)) : (((!_Utils_eq(ledger.channel, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(ledger.observed, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(ledger.settled, $elm$core$Maybe$Nothing)) || (!known)))) ? _Utils_Tuple2(
						prior,
						$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
						A4(
							$author$project$PreviewPresenter$Model,
							entries,
							previousCatalog,
							_Utils_update(
								ledger,
								{
									channel: $elm$core$Maybe$Just(owner)
								}),
							scoped),
						$author$project$PreviewPresenter$encode(_List_Nil)));
				case 'RetirementDelivery':
					var delivery = _v0.a.a;
					var fact = delivery.fact;
					var identity = 'family:' + $author$project$UInt64$string(fact._native.subject);
					var acknowledge = A2(
						$elm$json$Json$Encode$list,
						function (value) {
							return value;
						},
						_List_fromArray(
							[
								$elm$json$Json$Encode$object(
								_List_fromArray(
									[
										_Utils_Tuple2(
										'identity',
										$elm$json$Json$Encode$string(identity)),
										_Utils_Tuple2(
										'commands',
										A2(
											$elm$json$Json$Encode$list,
											function (value) {
												return value;
											},
											_List_fromArray(
												[
													$author$project$NativeActorRetirement$deliveryAcknowledgment(delivery)
												])))
									]))
							]));
					if (!_Utils_eq(
						ledger.channel,
						$elm$core$Maybe$Just(
							$author$project$NativeActorRetirement$owner(fact._native)))) {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						if (!_Utils_eq(
							A2($author$project$UInt64$compare, delivery.ordinal, ledger.processed),
							$elm$core$Basics$GT)) {
							return _Utils_Tuple2(prior, acknowledge);
						} else {
							if (!_Utils_eq(
								$author$project$UInt64$next(ledger.processed),
								$elm$core$Maybe$Just(delivery.ordinal))) {
								return _Utils_Tuple2(
									prior,
									$author$project$PreviewPresenter$encode(_List_Nil));
							} else {
								var _v5 = A2($elm$core$Dict$get, identity, entries);
								if (_v5.$ === 'Nothing') {
									return _Utils_Tuple2(
										prior,
										$author$project$PreviewPresenter$encode(_List_Nil));
								} else {
									var entry = _v5.a;
									var settled = A2(
										$elm$core$Maybe$withDefault,
										true,
										A2($elm$core$Maybe$map, $author$project$PreviewLifecycle$settled, entry.model));
									var exact = A2(
										$elm$core$Maybe$withDefault,
										false,
										A2(
											$elm$core$Maybe$map,
											function (pending) {
												return A2($author$project$NativeActorRetirement$settles, pending, fact);
											},
											entry.retirement));
									if ((!entry.readySent) || ((!settled) || ((!exact) || (!A2($author$project$NativeActorRetirement$coherentFrontier, ledger, fact))))) {
										return _Utils_Tuple2(
											prior,
											$author$project$PreviewPresenter$encode(_List_Nil));
									} else {
										var confirmed = A2($author$project$NativeActorRetirement$confirm, ledger, fact);
										return _Utils_Tuple2(
											A4(
												$author$project$PreviewPresenter$Model,
												A2($elm$core$Dict$remove, identity, entries),
												previousCatalog,
												_Utils_update(
													confirmed,
													{processed: delivery.ordinal}),
												scoped),
											acknowledge);
									}
								}
							}
						}
					}
				case 'Retirement':
					var observation = _v0.a.a;
					var identity = 'family:' + $author$project$UInt64$string(observation.subject);
					var _v6 = A2($elm$core$Dict$get, identity, entries);
					if (_v6.$ === 'Nothing') {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var entry = _v6.a;
						if (((!_Utils_eq(ledger.channel, $elm$core$Maybe$Nothing)) && (!_Utils_eq(
							ledger.channel,
							$elm$core$Maybe$Just(
								$author$project$NativeActorRetirement$owner(observation))))) || ((!_Utils_eq(
							entry.binding,
							$author$project$NativeActorRetirement$owner(observation))) || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)) || (!A2(
							$elm$core$Maybe$withDefault,
							true,
							A2(
								$elm$core$Maybe$map,
								function (lifecycle) {
									return A2(
										$elm$core$Result$withDefault,
										false,
										A2(
											$elm$core$Result$map,
											$author$project$NativeActorRetirement$scopeBefore(observation),
											A2(
												$elm$json$Json$Decode$decodeValue,
												A2($elm$json$Json$Decode$field, 'scope', $elm$json$Json$Decode$value),
												$author$project$PreviewLifecycle$observe(lifecycle))));
								},
								entry.model))))))) {
							return _Utils_Tuple2(
								prior,
								$author$project$PreviewPresenter$encode(_List_Nil));
						} else {
							var _v7 = $author$project$PreviewPresenter$retireEntry(entry);
							var closed = _v7.a;
							var commands = _v7.b;
							var pending = _Utils_update(
								closed,
								{
									readySent: false,
									retirement: $elm$core$Maybe$Just(observation)
								});
							return _Utils_Tuple2(
								A4(
									$author$project$PreviewPresenter$Model,
									A3($elm$core$Dict$insert, identity, pending, entries),
									previousCatalog,
									A2($author$project$NativeActorRetirement$remember, ledger, observation),
									scoped),
								$author$project$PreviewPresenter$encode(
									_List_fromArray(
										[
											{commands: commands, identity: identity}
										])));
						}
					}
				case 'Retired':
					var fact = _v0.a.a;
					var identity = 'family:' + $author$project$UInt64$string(fact._native.subject);
					var _v8 = A2($elm$core$Dict$get, identity, entries);
					if (_v8.$ === 'Nothing') {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var entry = _v8.a;
						var settled = A2(
							$elm$core$Maybe$withDefault,
							true,
							A2($elm$core$Maybe$map, $author$project$PreviewLifecycle$settled, entry.model));
						var frontier = A2($author$project$NativeActorRetirement$coherentFrontier, ledger, fact);
						var exact = A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (pending) {
									return A2($author$project$NativeActorRetirement$settles, pending, fact);
								},
								entry.retirement));
						return ((!_Utils_eq(ledger.channel, $elm$core$Maybe$Nothing)) || ((!entry.readySent) || ((!settled) || ((!exact) || (!frontier))))) ? _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
							A4(
								$author$project$PreviewPresenter$Model,
								A2($elm$core$Dict$remove, identity, entries),
								previousCatalog,
								A2($author$project$NativeActorRetirement$confirm, ledger, fact),
								scoped),
							$author$project$PreviewPresenter$encode(_List_Nil));
					}
				case 'Catalog':
					var _v9 = _v0.a;
					var stamp = _v9.a;
					var current = _v9.b;
					var rows = _v9.c;
					var ownersMatch = A2(
						$elm$core$List$all,
						function (entry) {
							return _Utils_eq(entry.binding, current.binding);
						},
						$elm$core$Dict$values(entries));
					var monotonic = A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							function (previous) {
								return _Utils_eq(current.binding, previous.binding) && (_Utils_eq(
									A2($author$project$UInt64$compare, current.request, previous.request),
									$elm$core$Basics$GT) && (_Utils_eq(
									A2($author$project$UInt64$compare, current.sequence, previous.sequence),
									$elm$core$Basics$GT) && (!_Utils_eq(
									A2($author$project$UInt64$compare, current.revision, previous.revision),
									$elm$core$Basics$LT))));
							},
							previousCatalog));
					var enroll = F2(
						function (row, next) {
							var identity = 'family:' + $author$project$UInt64$string(row.subject);
							var _v13 = A2($elm$core$Dict$get, identity, next);
							if (_v13.$ === 'Just') {
								var entry = _v13.a;
								return (scoped.closing || (A2($elm$core$Dict$member, identity, scoped.completed) || ((!_Utils_eq(entry.model, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || (!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)))))) ? next : A3(
									$elm$core$Dict$insert,
									identity,
									_Utils_update(
										entry,
										{
											application: row.application,
											metadataRevision: $elm$core$Maybe$Just(current.request),
											minimized: $elm$core$Maybe$Just(row.minimized),
											stamp: $elm$core$Maybe$Just(stamp),
											title: row.title
										}),
									next);
							} else {
								return (scoped.closing || A2($elm$core$Dict$member, identity, scoped.completed)) ? next : A3(
									$elm$core$Dict$insert,
									identity,
									{
										application: row.application,
										binding: current.binding,
										detachReadySent: false,
										detachment: $elm$core$Maybe$Nothing,
										feedbackFloor: $elm$core$Maybe$Nothing,
										icon: $elm$core$Maybe$Nothing,
										iconKind: 'unavailable',
										local: $elm$core$Maybe$Nothing,
										metadataRevision: $elm$core$Maybe$Just(current.request),
										minimized: $elm$core$Maybe$Just(row.minimized),
										model: $elm$core$Maybe$Nothing,
										readySent: false,
										retirement: $elm$core$Maybe$Nothing,
										source: $elm$core$Maybe$Nothing,
										stamp: $elm$core$Maybe$Just(stamp),
										title: row.title
									},
									next);
							}
						});
					var allowed = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							$author$project$PreviewPresenter$same(stamp),
							snapshot));
					var admitted = A2(
						$elm$core$List$filter,
						function (row) {
							return A2(
								$elm$core$Maybe$withDefault,
								false,
								A2(
									$elm$core$Maybe$map,
									A2(
										$author$project$SurfaceRenderer$enabled,
										true,
										'family:' + $author$project$UInt64$string(row.subject)),
									snapshot));
						},
						rows);
					var identities = $elm$core$Set$fromList(
						A2(
							$elm$core$List$map,
							A2(
								$elm$core$Basics$composeR,
								function ($) {
									return $.subject;
								},
								A2(
									$elm$core$Basics$composeR,
									$author$project$UInt64$string,
									$elm$core$Basics$append('family:'))),
							admitted));
					var prune = F3(
						function (identity, entry, _v12) {
							var next = _v12.a;
							var outputs = _v12.b;
							if (A2($elm$core$Set$member, identity, identities)) {
								return _Utils_Tuple2(
									A3($elm$core$Dict$insert, identity, entry, next),
									outputs);
							} else {
								var _v11 = $author$project$PreviewPresenter$closeEntry(entry);
								var closed = _v11.a;
								var commands = _v11.b;
								return _Utils_Tuple2(
									((!scoped.closing) && (_Utils_eq(closed.model, $elm$core$Maybe$Nothing) && (_Utils_eq(closed.retirement, $elm$core$Maybe$Nothing) && _Utils_eq(closed.detachment, $elm$core$Maybe$Nothing)))) ? next : A3($elm$core$Dict$insert, identity, closed, next),
									_Utils_ap(
										outputs,
										_List_fromArray(
											[
												{commands: commands, identity: identity}
											])));
							}
						});
					var _v10 = A3(
						$elm$core$Dict$foldl,
						prune,
						_Utils_Tuple2($elm$core$Dict$empty, _List_Nil),
						entries);
					var retained = _v10.a;
					var cleanup = _v10.b;
					var enrolled = A3($elm$core$List$foldl, enroll, retained, admitted);
					return ((!allowed) || ((!monotonic) || ((!ownersMatch) || (A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (_final) {
								return !_Utils_eq(
									A2($author$project$UInt64$compare, current.request, _final._native.request),
									$elm$core$Basics$GT);
							},
							ledger.settled)) || ($elm$core$Dict$size(enrolled) > 2051))))) ? _Utils_Tuple2(
						prior,
						$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
						A4(
							$author$project$PreviewPresenter$Model,
							enrolled,
							$elm$core$Maybe$Just(current),
							ledger,
							scoped),
						$author$project$PreviewPresenter$encode(cleanup));
				case 'Metadata':
					var _v14 = _v0.a;
					var identity = _v14.a;
					var owner = _v14.b;
					var subject = _v14.c;
					var revision = _v14.d;
					var title = _v14.e;
					var application = _v14.f;
					var icon = _v14.g;
					var iconKind = _v14.h;
					var _v15 = A2($elm$core$Dict$get, identity, entries);
					if (_v15.$ === 'Just') {
						var entry = _v15.a;
						return (scoped.closing || ((!_Utils_eq(
							identity,
							'family:' + $author$project$UInt64$string(subject))) || ((!_Utils_eq(entry.binding, owner)) || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(
							_Utils_eq(icon, $elm$core$Maybe$Nothing),
							iconKind === 'unavailable')) || A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (previous) {
									return !_Utils_eq(
										A2($author$project$UInt64$compare, revision, previous),
										$elm$core$Basics$GT);
								},
								entry.metadataRevision)))))))) ? _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
							A4(
								$author$project$PreviewPresenter$Model,
								A3(
									$elm$core$Dict$insert,
									identity,
									_Utils_update(
										entry,
										{
											application: application,
											icon: icon,
											iconKind: iconKind,
											metadataRevision: $elm$core$Maybe$Just(revision),
											title: title
										}),
									entries),
								previousCatalog,
								ledger,
								scoped),
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					}
				case 'Feedback':
					var _v16 = _v0.a;
					var identity = _v16.a;
					var local = _v16.b;
					var _v17 = A2($elm$core$Dict$get, identity, entries);
					if (_v17.$ === 'Nothing') {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var entry = _v17.a;
						var scopeMatches = A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (lifecycle) {
									return $author$project$PreviewLifecycle$idle(lifecycle) && _Utils_eq(
										A2(
											$elm$json$Json$Decode$decodeValue,
											A2(
												$elm$json$Json$Decode$at,
												_List_fromArray(
													['scope', 'clock']),
												$author$project$PreviewPresenter$positive),
											$author$project$PreviewLifecycle$observe(lifecycle)),
										$elm$core$Result$Ok(local.clock));
								},
								entry.model));
						var newer = A2(
							$elm$core$Maybe$withDefault,
							true,
							A2(
								$elm$core$Maybe$map,
								function (floor) {
									return _Utils_eq(
										A2($author$project$UInt64$compare, local.sequence, floor),
										$elm$core$Basics$GT);
								},
								entry.feedbackFloor));
						var current = A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (shown) {
									return A2($author$project$PreviewPresenter$same, local.stamp, shown) && A3($author$project$SurfaceRenderer$enabled, true, identity, shown);
								},
								snapshot));
						return (scoped.closing || ((!current) || ((!scopeMatches) || ((!newer) || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(entry.binding, local.owner)) || (!_Utils_eq(
							identity,
							'family:' + $author$project$UInt64$string(local.subject)))))))))) ? _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil)) : _Utils_Tuple2(
							A4(
								$author$project$PreviewPresenter$Model,
								A3(
									$elm$core$Dict$insert,
									identity,
									_Utils_update(
										entry,
										{
											feedbackFloor: $elm$core$Maybe$Just(local.sequence),
											local: $elm$core$Maybe$Just(local),
											stamp: $elm$core$Maybe$Just(local.stamp)
										}),
									entries),
								previousCatalog,
								ledger,
								scoped),
							$author$project$PreviewPresenter$encode(_List_Nil));
					}
				case 'Event':
					var _v18 = _v0.a;
					var identity = _v18.a;
					var event = _v18.b;
					var wire = _v18.c;
					var _v19 = A2($elm$core$Dict$get, identity, entries);
					if (_v19.$ === 'Nothing') {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var entry = _v19.a;
						if (entry.readySent || ((!(A2($author$project$PreviewPresenter$eventOwns, identity, wire) && A2($author$project$PreviewPresenter$familyFrameOwns, entry.source, wire))) || ((scoped.closing || ((!_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing)) || (!_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing)))) && A2(
							$elm$core$Result$withDefault,
							true,
							A2(
								$elm$core$Result$map,
								function (kind) {
									return A2(
										$elm$core$List$member,
										kind,
										_List_fromArray(
											['open', 'request', 'attach', 'observe']));
								},
								A2(
									$elm$json$Json$Decode$decodeValue,
									A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
									wire)))))) {
							return _Utils_Tuple2(
								prior,
								$author$project$PreviewPresenter$encode(_List_Nil));
						} else {
							var _v20 = entry.model;
							if (_v20.$ === 'Nothing') {
								return _Utils_Tuple2(
									prior,
									$author$project$PreviewPresenter$encode(_List_Nil));
							} else {
								var lifecycle = _v20.a;
								var _v21 = A2($author$project$PreviewLifecycle$update, event, lifecycle);
								var next = _v21.a;
								var commands = _v21.b;
								var owner = A2(
									$elm$core$Result$withDefault,
									entry.binding,
									A2(
										$elm$json$Json$Decode$decodeValue,
										A2(
											$elm$json$Json$Decode$at,
											_List_fromArray(
												['scope', 'binding']),
											$author$project$PreviewPresenter$binding),
										$author$project$PreviewLifecycle$observe(next)));
								var updated = _Utils_eq(owner, entry.binding) ? _Utils_update(
									entry,
									{
										local: $author$project$PreviewLifecycle$idle(next) ? entry.local : $elm$core$Maybe$Nothing,
										model: $elm$core$Maybe$Just(next)
									}) : _Utils_update(
									entry,
									{
										application: '',
										binding: owner,
										feedbackFloor: $elm$core$Maybe$Nothing,
										icon: $elm$core$Maybe$Nothing,
										iconKind: 'unavailable',
										local: $elm$core$Maybe$Nothing,
										metadataRevision: $elm$core$Maybe$Nothing,
										model: $elm$core$Maybe$Just(next),
										title: 'Preview unavailable'
									});
								return _Utils_Tuple2(
									A4(
										$author$project$PreviewPresenter$Model,
										A3($elm$core$Dict$insert, identity, updated, entries),
										previousCatalog,
										ledger,
										scoped),
									$author$project$PreviewPresenter$encode(
										_List_fromArray(
											[
												{commands: commands, identity: identity}
											])));
							}
						}
					}
				default:
					var _v22 = _v0.a;
					var stamp = _v22.a;
					var identity = _v22.b;
					var scope = _v22.c;
					var _native = _v22.d;
					var title = _v22.e;
					var application = _v22.f;
					var owner = _v22.g;
					var sourceKind = _v22.h;
					var unissued = _v22.i;
					var sequence = _v22.j;
					var openEvent = A2(
						$elm$json$Json$Decode$decodeValue,
						$author$project$PreviewLifecycle$eventDecoder,
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('open'))
								])));
					var old = A2($elm$core$Dict$get, identity, entries);
					var observeEvent = A2(
						$elm$json$Json$Decode$decodeValue,
						$author$project$PreviewLifecycle$eventDecoder,
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('observe')),
									_Utils_Tuple2('scope', _native)
								])));
					var matching = A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							function (entry) {
								return (!scoped.closing) && (_Utils_eq(entry.binding, owner) && (_Utils_eq(entry.retirement, $elm$core$Maybe$Nothing) && (_Utils_eq(entry.detachment, $elm$core$Maybe$Nothing) && (_Utils_eq(entry.model, $elm$core$Maybe$Nothing) || (A2($author$project$PreviewPresenter$sameSourcePlane, entry.source, sourceKind) && ((!unissued) || A2(
									$elm$core$Maybe$withDefault,
									true,
									A2($elm$core$Maybe$map, $author$project$PreviewLifecycle$idle, entry.model))))))));
							},
							old));
					var allowed = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (shown) {
								return A2($author$project$PreviewPresenter$same, stamp, shown) && A3($author$project$SurfaceRenderer$enabled, true, identity, shown);
							},
							snapshot));
					if (scoped.closing || ((!allowed) || ((!matching) || ((_Utils_eq(old, $elm$core$Maybe$Nothing) && (!A3($author$project$NativeActorRetirement$admittedAfter, ledger, owner, _native))) || (_Utils_eq(old, $elm$core$Maybe$Nothing) && ($elm$core$Dict$size(entries) >= 2051)))))) {
						return _Utils_Tuple2(
							prior,
							$author$project$PreviewPresenter$encode(_List_Nil));
					} else {
						var floor = A2(
							$elm$core$Maybe$andThen,
							function ($) {
								return $.feedbackFloor;
							},
							old);
						var base = A2(
							$elm$core$Maybe$withDefault,
							$author$project$PreviewLifecycle$init(scope),
							A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.model;
								},
								old));
						var _v23 = A2(
							$elm$core$Result$withDefault,
							_Utils_Tuple2(base, _List_Nil),
							A2(
								$elm$core$Result$map,
								function (event) {
									return A2($author$project$PreviewLifecycle$update, event, base);
								},
								observeEvent));
						var observed = _v23.a;
						var first = _v23.b;
						var _v24 = unissued ? _Utils_Tuple2(observed, _List_Nil) : A2(
							$elm$core$Result$withDefault,
							_Utils_Tuple2(observed, _List_Nil),
							A2(
								$elm$core$Result$map,
								function (event) {
									return A2($author$project$PreviewLifecycle$update, event, observed);
								},
								openEvent));
						var opened = _v24.a;
						var second = _v24.b;
						var entry = {
							application: A2(
								$elm$core$Maybe$withDefault,
								application,
								A2(
									$elm$core$Maybe$map,
									function ($) {
										return $.application;
									},
									old)),
							binding: owner,
							detachReadySent: false,
							detachment: $elm$core$Maybe$Nothing,
							feedbackFloor: unissued ? floor : A2($author$project$PreviewPresenter$advanceFloor, floor, sequence),
							icon: A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.icon;
								},
								old),
							iconKind: A2(
								$elm$core$Maybe$withDefault,
								'unavailable',
								A2(
									$elm$core$Maybe$map,
									function ($) {
										return $.iconKind;
									},
									old)),
							local: unissued ? A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.local;
								},
								old) : $elm$core$Maybe$Nothing,
							metadataRevision: A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.metadataRevision;
								},
								old),
							minimized: A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.minimized;
								},
								old),
							model: $elm$core$Maybe$Just(opened),
							readySent: false,
							retirement: $elm$core$Maybe$Nothing,
							source: sourceKind,
							stamp: $elm$core$Maybe$Just(stamp),
							title: A2(
								$elm$core$Maybe$withDefault,
								title,
								A2(
									$elm$core$Maybe$map,
									function ($) {
										return $.title;
									},
									old))
						};
						return _Utils_Tuple2(
							A4(
								$author$project$PreviewPresenter$Model,
								A3($elm$core$Dict$insert, identity, entry, entries),
								previousCatalog,
								ledger,
								scoped),
							$author$project$PreviewPresenter$encode(
								_List_fromArray(
									[
										{
										commands: _Utils_ap(first, second),
										identity: identity
									}
									])));
					}
			}
		}
	});
var $author$project$PreviewPresenter$receiveOwned = F3(
	function (snapshot, raw, prior) {
		var settled = function (entry) {
			return A2(
				$elm$core$Maybe$withDefault,
				true,
				A2($elm$core$Maybe$map, $author$project$PreviewLifecycle$settled, entry.model));
		};
		var advance = F3(
			function (identity, entry, _v5) {
				var next = _v5.a;
				var ready = _v5.b;
				var _v3 = entry.retirement;
				if (_v3.$ === 'Just') {
					var observation = _v3.a;
					return ((!entry.readySent) && settled(entry)) ? _Utils_Tuple2(
						A3(
							$elm$core$Dict$insert,
							identity,
							_Utils_update(
								entry,
								{readySent: true}),
							next),
						_Utils_ap(
							ready,
							_List_fromArray(
								[
									$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'identity',
											$elm$json$Json$Encode$string(identity)),
											_Utils_Tuple2(
											'commands',
											A2(
												$elm$json$Json$Encode$list,
												function (command) {
													return command;
												},
												_List_fromArray(
													[
														$author$project$NativeActorRetirement$readyCommand(observation)
													])))
										]))
								]))) : _Utils_Tuple2(
						A3($elm$core$Dict$insert, identity, entry, next),
						ready);
				} else {
					var _v4 = entry.detachment;
					if (_v4.$ === 'Just') {
						var seed = _v4.a;
						return ((!entry.detachReadySent) && (settled(entry) && A2($author$project$PreviewPresenter$floorMatches, entry, seed))) ? _Utils_Tuple2(
							A3(
								$elm$core$Dict$insert,
								identity,
								_Utils_update(
									entry,
									{detachReadySent: true}),
								next),
							_Utils_ap(
								ready,
								_List_fromArray(
									[
										$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'identity',
												$elm$json$Json$Encode$string(identity)),
												_Utils_Tuple2(
												'commands',
												A2(
													$elm$json$Json$Encode$list,
													function (value) {
														return value;
													},
													_List_fromArray(
														[
															$author$project$NativePreviewDetachment$ready(seed)
														])))
											]))
									]))) : _Utils_Tuple2(
							A3($elm$core$Dict$insert, identity, entry, next),
							ready);
					} else {
						return _Utils_Tuple2(
							A3($elm$core$Dict$insert, identity, entry, next),
							ready);
					}
				}
			});
		var _v0 = A3($author$project$PreviewPresenter$receiveInput, snapshot, raw, prior);
		var _v1 = _v0.a;
		var entries = _v1.a;
		var catalog = _v1.b;
		var ledger = _v1.c;
		var scoped = _v1.d;
		var emitted = _v0.b;
		var cleanup = A2(
			$elm$core$Result$withDefault,
			_List_Nil,
			A2(
				$elm$json$Json$Decode$decodeValue,
				$elm$json$Json$Decode$list($elm$json$Json$Decode$value),
				emitted));
		var _v2 = A3(
			$elm$core$Dict$foldl,
			advance,
			_Utils_Tuple2($elm$core$Dict$empty, _List_Nil),
			entries);
		var retained = _v2.a;
		var barriers = _v2.b;
		return _Utils_Tuple2(
			A4($author$project$PreviewPresenter$Model, retained, catalog, ledger, scoped),
			A2(
				$elm$json$Json$Encode$list,
				$elm$core$Basics$identity,
				_Utils_ap(cleanup, barriers)));
	});
var $author$project$PreviewPresenter$receive = F3(
	function (snapshot, raw, prior) {
		var scoped = prior.d;
		return (!_Utils_eq(scoped.grant, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(
			prior,
			$author$project$PreviewPresenter$encode(_List_Nil)) : A3($author$project$PreviewPresenter$receiveOwned, snapshot, raw, prior);
	});
var $author$project$RetainedPreviewPresenter$receive = F3(
	function (snapshot, raw, prior) {
		var policy = prior.a;
		return A2(
			$author$project$RetainedPreviewPresenter$commit,
			prior,
			A3($author$project$PreviewPresenter$receive, snapshot, raw, policy));
	});
var $author$project$NativePreviewRealm$unwrap = F2(
	function (current, _v0) {
		var domain = _v0.a;
		var event = _v0.b;
		return A2($author$project$NativePreviewRealm$same, current, domain) ? $elm$core$Maybe$Just(event) : $elm$core$Maybe$Nothing;
	});
var $author$project$PreviewPresenter$receiveRealm = F3(
	function (snapshot, raw, prior) {
		var scoped = prior.d;
		var _v0 = _Utils_Tuple2(
			scoped.grant,
			A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$envelopeDecoder, raw));
		if ((_v0.a.$ === 'Just') && (_v0.b.$ === 'Ok')) {
			var grant = _v0.a.a;
			var envelope = _v0.b.a;
			var _v1 = scoped.closed ? $elm$core$Maybe$Nothing : A2($author$project$NativePreviewRealm$unwrap, grant.domain, envelope);
			if (_v1.$ === 'Nothing') {
				return _Utils_Tuple2(
					prior,
					A2(
						$author$project$PreviewPresenter$wrap,
						scoped,
						$author$project$PreviewPresenter$encode(_List_Nil)));
			} else {
				var event = _v1.a;
				var _v2 = A3($author$project$PreviewPresenter$receiveOwned, snapshot, event, prior);
				var next = _v2.a;
				var emitted = _v2.b;
				return _Utils_Tuple2(
					next,
					A2($author$project$PreviewPresenter$wrap, scoped, emitted));
			}
		} else {
			return _Utils_Tuple2(
				prior,
				A2(
					$author$project$PreviewPresenter$wrap,
					scoped,
					$author$project$PreviewPresenter$encode(_List_Nil)));
		}
	});
var $author$project$RetainedPreviewPresenter$receiveRealm = F3(
	function (snapshot, raw, prior) {
		var policy = prior.a;
		return A2(
			$author$project$RetainedPreviewPresenter$commit,
			prior,
			A3($author$project$PreviewPresenter$receiveRealm, snapshot, raw, policy));
	});
var $author$project$PreviewPresenter$retireLegacy = F2(
	function (raw, prior) {
		var entries = prior.a;
		var scoped = prior.d;
		var _v0 = A2($elm$json$Json$Decode$decodeValue, $author$project$PreviewPresenter$binding, raw);
		if (_v0.$ === 'Ok') {
			var owner = _v0.a;
			return (_Utils_eq(scoped.grant, $elm$core$Maybe$Nothing) && A2(
				$elm$core$List$all,
				function (entry) {
					return _Utils_eq(entry.binding, owner);
				},
				$elm$core$Dict$values(entries))) ? $author$project$PreviewPresenter$quarantineOwned(prior) : _Utils_Tuple2(
				prior,
				$author$project$PreviewPresenter$encode(_List_Nil));
		} else {
			return _Utils_Tuple2(
				prior,
				$author$project$PreviewPresenter$encode(_List_Nil));
		}
	});
var $author$project$RetainedPreviewPresenter$retireLegacy = F2(
	function (raw, prior) {
		var policy = prior.a;
		return A2(
			$author$project$RetainedPreviewPresenter$commit,
			prior,
			A2($author$project$PreviewPresenter$retireLegacy, raw, policy));
	});
var $author$project$RetainedPreviewPresenter$retry = F2(
	function (domain, prior) {
		var policy = prior.a;
		var grant = prior.b;
		var ingress = prior.c;
		var deferred = prior.d;
		var _v0 = _Utils_Tuple2(grant, ingress);
		if ((_v0.a.$ === 'Just') && (_v0.b.$ === 'Just')) {
			var g = _v0.a.a;
			var queue = _v0.b.a;
			if (A2($author$project$NativePreviewRealm$same, g.domain, domain)) {
				var _v1 = A2($author$project$NativePreviewProposalIngress$split, deferred, queue);
				var next = _v1.a;
				var waiting = _v1.b;
				return _Utils_Tuple2(
					A4(
						$author$project$RetainedPreviewPresenter$Model,
						policy,
						grant,
						$elm$core$Maybe$Just(next),
						waiting),
					$author$project$NativePreviewProposalIngress$proposals(next));
			} else {
				return _Utils_Tuple2(
					prior,
					$author$project$RetainedPreviewPresenter$emptyOutput(grant));
			}
		} else {
			return _Utils_Tuple2(
				prior,
				$author$project$RetainedPreviewPresenter$emptyOutput(grant));
		}
	});
var $author$project$NativePreviewProposalIngress$sameAcceptedTicket = F2(
	function (_v0, _v1) {
		var leftDomain = _v0.a;
		var leftOrdinal = _v0.b;
		var leftWire = _v0.c;
		var rightDomain = _v1.a;
		var rightOrdinal = _v1.b;
		var rightWire = _v1.c;
		return A2($author$project$NativePreviewRealm$same, leftDomain, rightDomain) && (_Utils_eq(leftOrdinal, rightOrdinal) && _Utils_eq(leftWire, rightWire));
	});
var $elm$core$List$singleton = function (value) {
	return _List_fromArray(
		[value]);
};
var $author$project$Popup$transition = F2(
	function (message, model) {
		transition:
		while (true) {
			switch (message.$) {
				case 'PreviewPainted':
					var raw = message.a;
					var _v1 = A2($author$project$PreviewPaintGate$painted, raw, model.paintGate);
					var gate = _v1.a;
					var commands = _v1.b;
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{paintGate: gate}),
						_List_fromArray(
							[
								$author$project$Popup$PreviewCommand(commands)
							]));
				case 'LocalAction':
					var value = message.a;
					var kind = A2(
						$elm$core$Result$withDefault,
						'',
						A2(
							$elm$json$Json$Decode$decodeValue,
							A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
							value));
					if (A2(
						$elm$core$List$member,
						kind,
						_List_fromArray(
							['surface-query', 'surface-preedit', 'surface-composition-start', 'surface-composition-end']))) {
						return A2(
							$elm$core$Maybe$withDefault,
							_Utils_Tuple2(model, _List_Nil),
							A2(
								$elm$core$Maybe$map,
								function (current) {
									return A2(
										$author$project$Popup$transition,
										$author$project$Popup$Action(current),
										model);
								},
								A2($author$project$Presentation$localEdit, value, model.presentation)));
					} else {
						var $temp$message = $author$project$Popup$Action(value),
							$temp$model = model;
						message = $temp$message;
						model = $temp$model;
						continue transition;
					}
				case 'Announce':
					var raw = message.a;
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{
								announcements: A4(
									$author$project$Announcement$receive,
									true,
									$author$project$Presentation$current(model.presentation),
									raw,
									model.announcements)
							}),
						_List_Nil);
				case 'Action':
					var value = message.a;
					var sendQuery = F3(
						function (query, wire, current) {
							var unsettledHere = function () {
								var _v6 = _Utils_Tuple3(
									current.pendingQuery,
									current.lastQuery,
									$author$project$Presentation$current(current.presentation));
								_v6$0:
								while (true) {
									if (_v6.b.$ === 'Nothing') {
										if (_v6.a.$ === 'Nothing') {
											break _v6$0;
										} else {
											var _v8 = _v6.b;
											return false;
										}
									} else {
										if (_v6.a.$ === 'Nothing') {
											break _v6$0;
										} else {
											if (_v6.c.$ === 'Just') {
												var _v9 = _v6.b.a;
												var shown = _v9.b;
												var token = _v9.c;
												var snapshot = _v6.c.a;
												return (!_Utils_eq(
													$author$project$SurfaceRenderer$lease(snapshot),
													token)) || (!_Utils_eq(
													A2(
														$author$project$UInt64$compare,
														$author$project$SurfaceRenderer$publication(snapshot),
														shown),
													$elm$core$Basics$GT));
											} else {
												return true;
											}
										}
									}
								}
								var _v7 = _v6.a;
								return false;
							}();
							var unchanged = (!unsettledHere) && _Utils_eq(
								$elm$core$Maybe$Just(query),
								A2(
									$elm$core$Maybe$andThen,
									$author$project$SurfaceRenderer$queryValue,
									$author$project$Presentation$current(current.presentation)));
							var key = A2(
								$elm$core$Maybe$map,
								function (snapshot) {
									return _Utils_Tuple3(
										query,
										$author$project$SurfaceRenderer$publication(snapshot),
										$author$project$SurfaceRenderer$lease(snapshot));
								},
								$author$project$Presentation$current(current.presentation));
							var duplicate = (!_Utils_eq(key, $elm$core$Maybe$Nothing)) && _Utils_eq(key, current.lastQuery);
							return _Utils_Tuple2(
								_Utils_update(
									current,
									{
										lastQuery: key,
										pendingQuery: unchanged ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(query)
									}),
								(unchanged || duplicate) ? _List_Nil : _List_fromArray(
									[
										$author$project$Popup$Dispatch(wire)
									]));
						});
					var kind = A2(
						$elm$core$Result$withDefault,
						'',
						A2(
							$elm$json$Json$Decode$decodeValue,
							A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
							value));
					var before = {
						baseline: A2(
							$elm$core$Maybe$withDefault,
							A2(
								$elm$core$Maybe$withDefault,
								'',
								A2(
									$elm$core$Maybe$andThen,
									$author$project$SurfaceRenderer$queryValue,
									$author$project$Presentation$current(model.presentation))),
							model.pendingQuery),
						before: model.pendingQuery
					};
					if (A2(
						$elm$core$List$member,
						kind,
						_List_fromArray(
							['surface-query', 'surface-preedit', 'surface-composition-start', 'surface-composition-end']))) {
						var _v2 = A2($author$project$Presentation$editQuery, value, model.presentation);
						if (_v2.$ === 'Just') {
							var _v3 = _v2.a;
							var query = _v3.a;
							var wire = _v3.b;
							if (kind === 'surface-composition-start') {
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{
											composition: $author$project$Popup$Preediting(
												{baseline: query, before: model.pendingQuery}),
											pendingQuery: $elm$core$Maybe$Just(query)
										}),
									_List_Nil);
							} else {
								if (kind === 'surface-composition-end') {
									var _v4 = model.composition;
									if (_v4.$ === 'Idle') {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var held = _v4.a;
										if (_Utils_eq(query, held.baseline)) {
											var _v5 = held.before;
											if (_v5.$ === 'Nothing') {
												return _Utils_Tuple2(
													_Utils_update(
														model,
														{composition: $author$project$Popup$Idle, pendingQuery: $elm$core$Maybe$Nothing}),
													_List_Nil);
											} else {
												var prior = _v5.a;
												var restored = _Utils_update(
													model,
													{
														composition: $author$project$Popup$Idle,
														pendingQuery: $elm$core$Maybe$Just(prior)
													});
												return A2(
													$elm$core$Maybe$withDefault,
													_Utils_Tuple2(restored, _List_Nil),
													A2(
														$elm$core$Maybe$map,
														function (priorWire) {
															return A3(sendQuery, prior, priorWire, restored);
														},
														A2($author$project$Presentation$query, prior, restored.presentation)));
											}
										} else {
											return A3(
												sendQuery,
												query,
												wire,
												_Utils_update(
													model,
													{composition: $author$project$Popup$Idle}));
										}
									}
								} else {
									if ((kind === 'surface-preedit') || $author$project$Popup$isComposing(model)) {
										return _Utils_Tuple2(
											_Utils_update(
												model,
												{
													composition: $author$project$Popup$isComposing(model) ? model.composition : $author$project$Popup$Preediting(before),
													pendingQuery: $elm$core$Maybe$Just(query)
												}),
											_List_Nil);
									} else {
										return A3(sendQuery, query, wire, model);
									}
								}
							}
						} else {
							return _Utils_Tuple2(model, _List_Nil);
						}
					} else {
						if ($author$project$Popup$isComposing(model) || ((!_Utils_eq(model.pendingQuery, $elm$core$Maybe$Nothing)) && A2(
							$elm$core$Result$withDefault,
							false,
							A2(
								$elm$core$Result$map,
								$author$project$SurfaceRenderer$pendingQueryBlocked,
								A2(
									$elm$json$Json$Decode$decodeValue,
									A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
									value))))) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							return _Utils_Tuple2(
								model,
								A2(
									$elm$core$Maybe$withDefault,
									_List_Nil,
									A2(
										$elm$core$Maybe$map,
										A2($elm$core$Basics$composeR, $author$project$Popup$Dispatch, $elm$core$List$singleton),
										A3($author$project$Presentation$dispatch, true, value, model.presentation))));
						}
					}
				case 'Present':
					var raw = message.a;
					var acceptedPresentation = A2($author$project$Presentation$accept, raw, model.presentation);
					var sameField = function () {
						var _v13 = _Utils_Tuple2(
							$author$project$Presentation$current(model.presentation),
							$author$project$Presentation$current(acceptedPresentation));
						if ((_v13.a.$ === 'Just') && (_v13.b.$ === 'Just')) {
							var old = _v13.a.a;
							var next = _v13.b.a;
							return _Utils_eq(
								$author$project$SurfaceRenderer$lease(old),
								$author$project$SurfaceRenderer$lease(next)) && (A2(
								$elm$core$List$member,
								$author$project$SurfaceRenderer$mode(next),
								_List_fromArray(
									['applications', 'files'])) && (_Utils_eq(
								$author$project$SurfaceRenderer$mode(old),
								$author$project$SurfaceRenderer$mode(next)) && A3(
								$author$project$SurfaceRenderer$enabled,
								true,
								$author$project$SurfaceRenderer$fieldIdentity(next),
								next)));
						} else {
							return false;
						}
					}();
					var composition = sameField ? model.composition : $author$project$Popup$Idle;
					var composing = !_Utils_eq(composition, $author$project$Popup$Idle);
					var pending = (!sameField) ? $elm$core$Maybe$Nothing : (composing ? model.pendingQuery : A2(
						$elm$core$Maybe$andThen,
						function (query) {
							var _v12 = $author$project$Presentation$current(acceptedPresentation);
							if (_v12.$ === 'Just') {
								var snapshot = _v12.a;
								return (!_Utils_eq(
									$author$project$SurfaceRenderer$queryValue(snapshot),
									$elm$core$Maybe$Just(query))) ? $elm$core$Maybe$Just(query) : $elm$core$Maybe$Nothing;
							} else {
								return $elm$core$Maybe$Nothing;
							}
						},
						model.pendingQuery));
					var key = A2(
						$elm$core$Maybe$andThen,
						function (query) {
							return A2(
								$elm$core$Maybe$map,
								function (snapshot) {
									return _Utils_Tuple3(
										query,
										$author$project$SurfaceRenderer$publication(snapshot),
										$author$project$SurfaceRenderer$lease(snapshot));
								},
								$author$project$Presentation$current(acceptedPresentation));
						},
						pending);
					var lastQuery = (!sameField) ? $elm$core$Maybe$Nothing : ((composing || _Utils_eq(pending, $elm$core$Maybe$Nothing)) ? model.lastQuery : key);
					var queryCommand = (composing || _Utils_eq(key, model.lastQuery)) ? _List_Nil : A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						A2(
							$elm$core$Maybe$map,
							A2($elm$core$Basics$composeR, $author$project$Popup$Dispatch, $elm$core$List$singleton),
							A2(
								$elm$core$Maybe$andThen,
								function (query) {
									return A2($author$project$Presentation$query, query, acceptedPresentation);
								},
								pending)));
					var _v10 = A2(
						$author$project$RetainedPreviewPresenter$present,
						$author$project$Presentation$current(acceptedPresentation),
						model.previews);
					var previews = _v10.a;
					var commands = _v10.b;
					var _v11 = A2(
						$author$project$Popup$emitPreview,
						commands,
						_Utils_update(
							model,
							{composition: composition, lastQuery: lastQuery, pendingQuery: pending, presentation: acceptedPresentation, previews: previews}));
					var updatedPopup = _v11.a;
					var previewEffects = _v11.b;
					return _Utils_Tuple2(
						updatedPopup,
						_Utils_ap(previewEffects, queryCommand));
				case 'NativePreview':
					var raw = message.a;
					var _v14 = function () {
						var _v15 = A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$envelopeDecoder, raw);
						if (_v15.$ === 'Ok') {
							return A3(
								$author$project$RetainedPreviewPresenter$receiveRealm,
								$author$project$Presentation$current(model.presentation),
								raw,
								model.previews);
						} else {
							return A3(
								$author$project$RetainedPreviewPresenter$receive,
								$author$project$Presentation$current(model.presentation),
								raw,
								model.previews);
						}
					}();
					var previews = _v14.a;
					var commands = _v14.b;
					return A2(
						$author$project$Popup$emitPreview,
						commands,
						_Utils_update(
							model,
							{previews: previews}));
				case 'NativeRetirement':
					var raw = message.a;
					var _v16 = A2($author$project$RetainedPreviewPresenter$retireLegacy, raw, model.previews);
					var previews = _v16.a;
					var commands = _v16.b;
					return A2(
						$author$project$Popup$emitPreview,
						commands,
						_Utils_update(
							model,
							{previews: previews}));
				case 'NativeGrant':
					var raw = message.a;
					var previews = A2(
						$elm$core$Maybe$withDefault,
						model.previews,
						A2(
							$elm$core$Maybe$andThen,
							function (grant) {
								return A2($author$project$RetainedPreviewPresenter$enrollRealm, grant, model.previews);
							},
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$grantDecoder, raw))));
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{previews: previews}),
						_List_Nil);
				case 'NativeQuarantine':
					var raw = message.a;
					var _v17 = A2(
						$elm$core$Result$withDefault,
						_Utils_Tuple2(
							model.previews,
							A2($elm$json$Json$Encode$list, $elm$core$Basics$identity, _List_Nil)),
						A2(
							$elm$core$Result$map,
							function (domain) {
								return A2($author$project$RetainedPreviewPresenter$quarantineRealm, domain, model.previews);
							},
							A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$domainDecoder, raw)));
					var previews = _v17.a;
					var commands = _v17.b;
					return A2(
						$author$project$Popup$emitPreview,
						commands,
						_Utils_update(
							model,
							{previews: previews}));
				case 'NativeIssued':
					var raw = message.a;
					var _v18 = A2($author$project$RetainedPreviewPresenter$issuedWithConfirmation, raw, model.previews);
					var previews = _v18.a;
					var accepted = _v18.b;
					if (accepted.$ === 'Just') {
						var ticket = accepted.a;
						return ($elm$core$List$length(model.confirmationOutbox) < 1065) ? _Utils_Tuple2(
							_Utils_update(
								model,
								{
									confirmationOutbox: _Utils_ap(
										model.confirmationOutbox,
										_List_fromArray(
											[ticket])),
									previews: previews
								}),
							_List_fromArray(
								[
									$author$project$Popup$TicketConsumed(ticket)
								])) : _Utils_Tuple2(model, _List_Nil);
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				case 'ConfirmationTransportCompleted':
					var ticket = message.a;
					var removeFirst = function (remaining) {
						if (!remaining.b) {
							return _List_Nil;
						} else {
							var first = remaining.a;
							var rest = remaining.b;
							return A2($author$project$NativePreviewProposalIngress$sameAcceptedTicket, ticket, first) ? rest : A2(
								$elm$core$List$cons,
								first,
								removeFirst(rest));
						}
					};
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{
								confirmationOutbox: removeFirst(model.confirmationOutbox)
							}),
						_List_Nil);
				case 'NativeRetry':
					var raw = message.a;
					var _v21 = A2(
						$elm$core$Result$withDefault,
						_Utils_Tuple2(
							model.previews,
							A2($elm$json$Json$Encode$list, $elm$core$Basics$identity, _List_Nil)),
						A2(
							$elm$core$Result$map,
							function (domain) {
								return A2($author$project$RetainedPreviewPresenter$retry, domain, model.previews);
							},
							A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$domainDecoder, raw)));
					var previews = _v21.a;
					var commands = _v21.b;
					return A2(
						$author$project$Popup$emitPreview,
						commands,
						_Utils_update(
							model,
							{previews: previews}));
				default:
					var raw = message.a;
					var previews = A2(
						$elm$core$Maybe$withDefault,
						model.previews,
						A2(
							$elm$core$Maybe$andThen,
							function (domain) {
								return A2($author$project$RetainedPreviewPresenter$closeRealm, domain, model.previews);
							},
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, $author$project$NativePreviewRealm$domainDecoder, raw))));
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{previews: previews}),
						_List_Nil);
			}
		}
	});
var $author$project$TeaPopupSubscriptionsReplay$applyPopup = F3(
	function (request, message, model) {
		var _v0 = A2($author$project$Popup$transition, message, model);
		var nextPopup = _v0.a;
		var effects = _v0.b;
		return A3(
			$author$project$TeaPopupSubscriptionsReplay$observe,
			request,
			nextPopup,
			$author$project$TeaPopupSubscriptionsReplay$PopupEffects(effects));
	});
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $author$project$TeaPopupSubscriptionsReplay$PopupAction = function (a) {
	return {$: 'PopupAction', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupAnnounce = function (a) {
	return {$: 'PopupAnnounce', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupLocalAction = function (a) {
	return {$: 'PopupLocalAction', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeClosed = function (a) {
	return {$: 'PopupNativeClosed', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeGrant = function (a) {
	return {$: 'PopupNativeGrant', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeIssued = function (a) {
	return {$: 'PopupNativeIssued', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativePreview = function (a) {
	return {$: 'PopupNativePreview', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeQuarantine = function (a) {
	return {$: 'PopupNativeQuarantine', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeRetirement = function (a) {
	return {$: 'PopupNativeRetirement', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupNativeRetry = function (a) {
	return {$: 'PopupNativeRetry', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupPresent = function (a) {
	return {$: 'PopupPresent', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$PopupPreviewPainted = function (a) {
	return {$: 'PopupPreviewPainted', a: a};
};
var $author$project$TeaPopupSubscriptionsReplay$Request = F3(
	function (caseId, step, command) {
		return {caseId: caseId, command: command, step: step};
	});
var $author$project$TeaPopupSubscriptionsReplay$Reset = {$: 'Reset'};
var $author$project$TeaPopupSubscriptionsReplay$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('unexpected command fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$TeaPopupSubscriptionsReplay$requestDecoder = function () {
	var nonnegative = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return (value >= 0) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('negative step');
		},
		$elm$json$Json$Decode$int);
	var caseId = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return $elm$core$String$isEmpty(value) ? $elm$json$Json$Decode$fail('empty caseId') : $elm$json$Json$Decode$succeed(value);
		},
		$elm$json$Json$Decode$string);
	var request = F2(
		function (fields, command) {
			return A2(
				$author$project$TeaPopupSubscriptionsReplay$strict,
				A2(
					$elm$core$List$cons,
					'caseId',
					A2(
						$elm$core$List$cons,
						'step',
						A2($elm$core$List$cons, 'kind', fields))),
				A4(
					$elm$json$Json$Decode$map3,
					$author$project$TeaPopupSubscriptionsReplay$Request,
					A2($elm$json$Json$Decode$field, 'caseId', caseId),
					A2($elm$json$Json$Decode$field, 'step', nonnegative),
					command));
		});
	return A2(
		$elm$json$Json$Decode$andThen,
		function (kind) {
			switch (kind) {
				case 'reset':
					return A2(
						request,
						_List_Nil,
						$elm$json$Json$Decode$succeed($author$project$TeaPopupSubscriptionsReplay$Reset));
				case 'popup-present':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupPresent,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-action':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupAction,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-local-action':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupLocalAction,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-announce':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupAnnounce,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-preview':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativePreview,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-preview-painted':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupPreviewPainted,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-grant':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeGrant,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-quarantine':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeQuarantine,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-closed':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeClosed,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-issued':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeIssued,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-retry':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeRetry,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				case 'popup-native-retirement':
					return A2(
						request,
						_List_fromArray(
							['value']),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$TeaPopupSubscriptionsReplay$PopupNativeRetirement,
							A2($elm$json$Json$Decode$field, 'value', $elm$json$Json$Decode$value)));
				default:
					return $elm$json$Json$Decode$fail('unsupported command');
			}
		},
		A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
}();
var $author$project$TeaPopupSubscriptionsReplay$update = F2(
	function (_v0, model) {
		var raw = _v0.a;
		var _v1 = A2($elm$json$Json$Decode$decodeValue, $author$project$TeaPopupSubscriptionsReplay$requestDecoder, raw);
		if (_v1.$ === 'Err') {
			var problem = _v1.a;
			var step = A2(
				$elm$core$Result$withDefault,
				-1,
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'step', $elm$json$Json$Decode$int),
					raw));
			var caseId = A2(
				$elm$core$Result$withDefault,
				'',
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'caseId', $elm$json$Json$Decode$string),
					raw));
			return _Utils_Tuple2(
				model,
				A4(
					$author$project$TeaPopupSubscriptionsReplay$ack,
					caseId,
					step,
					false,
					$elm$json$Json$Decode$errorToString(problem)));
		} else {
			var request = _v1.a;
			var _v2 = request.command;
			switch (_v2.$) {
				case 'Reset':
					return A3($author$project$TeaPopupSubscriptionsReplay$observe, request, $author$project$Popup$initial, $author$project$TeaPopupSubscriptionsReplay$ResetEffects);
				case 'PopupPresent':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$Present(value),
						model);
				case 'PopupAction':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$Action(value),
						model);
				case 'PopupLocalAction':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$LocalAction(value),
						model);
				case 'PopupAnnounce':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$Announce(value),
						model);
				case 'PopupNativePreview':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativePreview(value),
						model);
				case 'PopupPreviewPainted':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$PreviewPainted(value),
						model);
				case 'PopupNativeGrant':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeGrant(value),
						model);
				case 'PopupNativeQuarantine':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeQuarantine(value),
						model);
				case 'PopupNativeClosed':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeClosed(value),
						model);
				case 'PopupNativeIssued':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeIssued(value),
						model);
				case 'PopupNativeRetry':
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeRetry(value),
						model);
				default:
					var value = _v2.a;
					return A3(
						$author$project$TeaPopupSubscriptionsReplay$applyPopup,
						request,
						$author$project$Popup$NativeRetirement(value),
						model);
			}
		}
	});
var $elm$core$Platform$worker = _Platform_worker;
var $author$project$TeaPopupSubscriptionsReplay$main = $elm$core$Platform$worker(
	{
		init: function (_v0) {
			return _Utils_Tuple2($author$project$Popup$initial, $elm$core$Platform$Cmd$none);
		},
		subscriptions: function (_v1) {
			return $author$project$TeaPopupSubscriptionsReplay$incoming($author$project$TeaPopupSubscriptionsReplay$Input);
		},
		update: $author$project$TeaPopupSubscriptionsReplay$update
	});
_Platform_export({'TeaPopupSubscriptionsReplay':{'init':$author$project$TeaPopupSubscriptionsReplay$main(
	$elm$json$Json$Decode$succeed(_Utils_Tuple0))(0)}});}(this));