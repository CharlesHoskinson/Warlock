(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}

console.warn('Compiled in DEV mode. Follow the advice at https://elm-lang.org/0.19.2/optimize for better performance and smaller assets.');


// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**_UNUSED/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**_UNUSED/
	if (typeof x.$ === 'undefined')
	//*/
	/**/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0_UNUSED = 0;
var _Utils_Tuple0 = { $: '#0' };

function _Utils_Tuple2_UNUSED(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3_UNUSED(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr_UNUSED(c) { return c; }
function _Utils_chr(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



var _List_Nil_UNUSED = { $: 0 };
var _List_Nil = { $: '[]' };

function _List_Cons_UNUSED(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log_UNUSED = F2(function(tag, value)
{
	return value;
});

var _Debug_log = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString_UNUSED(value)
{
	return '<internals>';
}

function _Debug_toString(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash_UNUSED(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.start.line === region.end.line)
	{
		return 'on line ' + region.start.line;
	}
	return 'on lines ' + region.start.line + ' through ' + region.end.line;
}



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap(value) { return { $: 0, a: value }; }
function _Json_unwrap(value) { return value.a; }

function _Json_wrap_UNUSED(value) { return value; }
function _Json_unwrap_UNUSED(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}




// HELPERS


var _VirtualDom_divertHrefToApp;

var _VirtualDom_doc = typeof document !== 'undefined' ? document : {};


function _VirtualDom_appendChild(parent, child)
{
	parent.appendChild(child);
}

var _VirtualDom_init = F4(function(virtualNode, flagDecoder, debugMetadata, args)
{
	// NOTE: this function needs _Platform_export available to work

	/**_UNUSED/
	var node = args['node'];
	//*/
	/**/
	var node = args && args['node'] ? args['node'] : _Debug_crash(0);
	//*/

	node.parentNode.replaceChild(
		_VirtualDom_render(virtualNode, function() {}),
		node
	);

	return {};
});



// TEXT


function _VirtualDom_text(string)
{
	return {
		$: 0,
		a: string
	};
}



// NODE


var _VirtualDom_nodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 1,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_node = _VirtualDom_nodeNS(undefined);



// KEYED NODE


var _VirtualDom_keyedNodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 2,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_keyedNode = _VirtualDom_keyedNodeNS(undefined);



// CUSTOM


function _VirtualDom_custom(factList, model, render, diff)
{
	return {
		$: 3,
		d: _VirtualDom_organizeFacts(factList),
		g: model,
		h: render,
		i: diff
	};
}



// MAP


var _VirtualDom_map = F2(function(tagger, node)
{
	return {
		$: 4,
		j: tagger,
		k: node,
		b: 1 + (node.b || 0)
	};
});



// LAZY


function _VirtualDom_thunk(refs, thunk)
{
	return {
		$: 5,
		l: refs,
		m: thunk,
		k: undefined
	};
}

var _VirtualDom_lazy = F2(function(func, a)
{
	return _VirtualDom_thunk([func, a], function() {
		return func(a);
	});
});

var _VirtualDom_lazy2 = F3(function(func, a, b)
{
	return _VirtualDom_thunk([func, a, b], function() {
		return A2(func, a, b);
	});
});

var _VirtualDom_lazy3 = F4(function(func, a, b, c)
{
	return _VirtualDom_thunk([func, a, b, c], function() {
		return A3(func, a, b, c);
	});
});

var _VirtualDom_lazy4 = F5(function(func, a, b, c, d)
{
	return _VirtualDom_thunk([func, a, b, c, d], function() {
		return A4(func, a, b, c, d);
	});
});

var _VirtualDom_lazy5 = F6(function(func, a, b, c, d, e)
{
	return _VirtualDom_thunk([func, a, b, c, d, e], function() {
		return A5(func, a, b, c, d, e);
	});
});

var _VirtualDom_lazy6 = F7(function(func, a, b, c, d, e, f)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f], function() {
		return A6(func, a, b, c, d, e, f);
	});
});

var _VirtualDom_lazy7 = F8(function(func, a, b, c, d, e, f, g)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g], function() {
		return A7(func, a, b, c, d, e, f, g);
	});
});

var _VirtualDom_lazy8 = F9(function(func, a, b, c, d, e, f, g, h)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g, h], function() {
		return A8(func, a, b, c, d, e, f, g, h);
	});
});



// FACTS


var _VirtualDom_on = F2(function(key, handler)
{
	return {
		$: 'a0',
		n: key,
		o: handler
	};
});
var _VirtualDom_style = F2(function(key, value)
{
	return {
		$: 'a1',
		n: key,
		o: value
	};
});
var _VirtualDom_property = F2(function(key, value)
{
	return {
		$: 'a2',
		n: key,
		o: value
	};
});
var _VirtualDom_attribute = F2(function(key, value)
{
	return {
		$: 'a3',
		n: key,
		o: value
	};
});
var _VirtualDom_attributeNS = F3(function(namespace, key, value)
{
	return {
		$: 'a4',
		n: key,
		o: { f: namespace, o: value }
	};
});



// XSS ATTACK VECTOR CHECKS
//
// For some reason, tabs can appear in href protocols and it still works.
// So '\tjava\tSCRIPT:alert("!!!")' and 'javascript:alert("!!!")' are the same
// in practice. That is why _VirtualDom_RE_js and _VirtualDom_RE_js_html look
// so freaky.
//
// Pulling the regular expressions out to the top level gives a slight speed
// boost in small benchmarks (4-10%) but hoisting values to reduce allocation
// can be unpredictable in large programs where JIT may have a harder time with
// functions are not fully self-contained. The benefit is more that the js and
// js_html ones are so weird that I prefer to see them near each other.


var _VirtualDom_RE_script = /^script$/i;
var _VirtualDom_RE_on_formAction = /^(on|formAction$)/i;
var _VirtualDom_RE_js = /^\s*j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:/i;
var _VirtualDom_RE_js_html = /^\s*(j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:|d\s*a\s*t\s*a\s*:\s*t\s*e\s*x\s*t\s*\/\s*h\s*t\s*m\s*l\s*(,|;))/i;


function _VirtualDom_noScript(tag)
{
	return _VirtualDom_RE_script.test(tag) ? 'p' : tag;
}

function _VirtualDom_noOnOrFormAction(key)
{
	return _VirtualDom_RE_on_formAction.test(key) ? 'data-' + key : key;
}

function _VirtualDom_noInnerHtmlOrFormAction(key)
{
	return key == 'innerHTML' || key == 'formAction' ? 'data-' + key : key;
}

function _VirtualDom_noJavaScriptUri(value)
{
	return _VirtualDom_RE_js.test(value)
		? /**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlUri(value)
{
	return _VirtualDom_RE_js_html.test(value)
		? /**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlJson(value)
{
	return (typeof _Json_unwrap(value) === 'string' && _VirtualDom_RE_js_html.test(_Json_unwrap(value)))
		? _Json_wrap(
			/**_UNUSED/''//*//**/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		) : value;
}



// MAP FACTS


var _VirtualDom_mapAttribute = F2(function(func, attr)
{
	return (attr.$ === 'a0')
		? A2(_VirtualDom_on, attr.n, _VirtualDom_mapHandler(func, attr.o))
		: attr;
});

function _VirtualDom_mapHandler(func, handler)
{
	var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

	// 0 = Normal
	// 1 = MayStopPropagation
	// 2 = MayPreventDefault
	// 3 = Custom

	return {
		$: handler.$,
		a:
			!tag
				? A2($elm$json$Json$Decode$map, func, handler.a)
				:
			A3($elm$json$Json$Decode$map2,
				tag < 3
					? _VirtualDom_mapEventTuple
					: _VirtualDom_mapEventRecord,
				$elm$json$Json$Decode$succeed(func),
				handler.a
			)
	};
}

var _VirtualDom_mapEventTuple = F2(function(func, tuple)
{
	return _Utils_Tuple2(func(tuple.a), tuple.b);
});

var _VirtualDom_mapEventRecord = F2(function(func, record)
{
	return {
		message: func(record.message),
		stopPropagation: record.stopPropagation,
		preventDefault: record.preventDefault
	}
});



// ORGANIZE FACTS


function _VirtualDom_organizeFacts(factList)
{
	for (var facts = {}; factList.b; factList = factList.b) // WHILE_CONS
	{
		var entry = factList.a;

		var tag = entry.$;
		var key = entry.n;
		var value = entry.o;

		if (tag === 'a2')
		{
			(key === 'className')
				? _VirtualDom_addClass(facts, key, _Json_unwrap(value))
				: facts[key] = _Json_unwrap(value);

			continue;
		}

		var subFacts = facts[tag] || (facts[tag] = {});
		(tag === 'a3' && key === 'class')
			? _VirtualDom_addClass(subFacts, key, value)
			: subFacts[key] = value;
	}

	return facts;
}

function _VirtualDom_addClass(object, key, newClass)
{
	var classes = object[key];
	object[key] = classes ? classes + ' ' + newClass : newClass;
}



// RENDER


function _VirtualDom_render(vNode, eventNode)
{
	var tag = vNode.$;

	if (tag === 5)
	{
		return _VirtualDom_render(vNode.k || (vNode.k = vNode.m()), eventNode);
	}

	if (tag === 0)
	{
		return _VirtualDom_doc.createTextNode(vNode.a);
	}

	if (tag === 4)
	{
		var subNode = vNode.k;
		var tagger = vNode.j;

		while (subNode.$ === 4)
		{
			typeof tagger !== 'object'
				? tagger = [tagger, subNode.j]
				: tagger.push(subNode.j);

			subNode = subNode.k;
		}

		var subEventRoot = { j: tagger, p: eventNode };
		var domNode = _VirtualDom_render(subNode, subEventRoot);
		domNode.elm_event_node_ref = subEventRoot;
		return domNode;
	}

	if (tag === 3)
	{
		var domNode = vNode.h(vNode.g);
		_VirtualDom_applyFacts(domNode, eventNode, vNode.d);
		return domNode;
	}

	// at this point `tag` must be 1 or 2

	var domNode = vNode.f
		? _VirtualDom_doc.createElementNS(vNode.f, vNode.c)
		: _VirtualDom_doc.createElement(vNode.c);

	if (_VirtualDom_divertHrefToApp && vNode.c == 'a')
	{
		domNode.addEventListener('click', _VirtualDom_divertHrefToApp(domNode));
	}

	_VirtualDom_applyFacts(domNode, eventNode, vNode.d);

	for (var kids = vNode.e, i = 0; i < kids.length; i++)
	{
		_VirtualDom_appendChild(domNode, _VirtualDom_render(tag === 1 ? kids[i] : kids[i].b, eventNode));
	}

	return domNode;
}



// APPLY FACTS


function _VirtualDom_applyFacts(domNode, eventNode, facts)
{
	for (var key in facts)
	{
		var value = facts[key];

		key === 'a1'
			? _VirtualDom_applyStyles(domNode, value)
			:
		key === 'a0'
			? _VirtualDom_applyEvents(domNode, eventNode, value)
			:
		key === 'a3'
			? _VirtualDom_applyAttrs(domNode, value)
			:
		key === 'a4'
			? _VirtualDom_applyAttrsNS(domNode, value)
			:
		((key !== 'value' && key !== 'checked') || domNode[key] !== value) && (domNode[key] = value);
	}
}



// APPLY STYLES


function _VirtualDom_applyStyles(domNode, styles)
{
	var domNodeStyle = domNode.style;

	for (var key in styles)
	{
		domNodeStyle[key] = styles[key];
	}
}



// APPLY ATTRS


function _VirtualDom_applyAttrs(domNode, attrs)
{
	for (var key in attrs)
	{
		var value = attrs[key];
		typeof value !== 'undefined'
			? domNode.setAttribute(key, value)
			: domNode.removeAttribute(key);
	}
}



// APPLY NAMESPACED ATTRS


function _VirtualDom_applyAttrsNS(domNode, nsAttrs)
{
	for (var key in nsAttrs)
	{
		var pair = nsAttrs[key];
		var namespace = pair.f;
		var value = pair.o;

		typeof value !== 'undefined'
			? domNode.setAttributeNS(namespace, key, value)
			: domNode.removeAttributeNS(namespace, key);
	}
}



// APPLY EVENTS


function _VirtualDom_applyEvents(domNode, eventNode, events)
{
	var allCallbacks = domNode.elmFs || (domNode.elmFs = {});

	for (var key in events)
	{
		var newHandler = events[key];
		var oldCallback = allCallbacks[key];

		if (!newHandler)
		{
			domNode.removeEventListener(key, oldCallback);
			allCallbacks[key] = undefined;
			continue;
		}

		if (oldCallback)
		{
			var oldHandler = oldCallback.q;
			if (oldHandler.$ === newHandler.$)
			{
				oldCallback.q = newHandler;
				continue;
			}
			domNode.removeEventListener(key, oldCallback);
		}

		oldCallback = _VirtualDom_makeCallback(eventNode, newHandler);
		domNode.addEventListener(key, oldCallback,
			_VirtualDom_passiveSupported
			&& { passive: $elm$virtual_dom$VirtualDom$toHandlerInt(newHandler) < 2 }
		);
		allCallbacks[key] = oldCallback;
	}
}



// PASSIVE EVENTS


var _VirtualDom_passiveSupported;

try
{
	window.addEventListener('t', null, Object.defineProperty({}, 'passive', {
		get: function() { _VirtualDom_passiveSupported = true; }
	}));
}
catch(e) {}



// EVENT HANDLERS


function _VirtualDom_makeCallback(eventNode, initialHandler)
{
	function callback(event)
	{
		var handler = callback.q;
		var result = _Json_runHelp(handler.a, event);

		if (!$elm$core$Result$isOk(result))
		{
			return;
		}

		var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

		// 0 = Normal
		// 1 = MayStopPropagation
		// 2 = MayPreventDefault
		// 3 = Custom

		var value = result.a;
		var message = !tag ? value : tag < 3 ? value.a : value.message;
		var stopPropagation = tag == 1 ? value.b : tag == 3 && value.stopPropagation;
		var currentEventNode = (
			stopPropagation && event.stopPropagation(),
			(tag == 2 ? value.b : tag == 3 && value.preventDefault) && event.preventDefault(),
			eventNode
		);
		var tagger;
		var i;
		while (tagger = currentEventNode.j)
		{
			if (typeof tagger == 'function')
			{
				message = tagger(message);
			}
			else
			{
				for (var i = tagger.length; i--; )
				{
					message = tagger[i](message);
				}
			}
			currentEventNode = currentEventNode.p;
		}
		currentEventNode(message, stopPropagation); // stopPropagation implies isSync
	}

	callback.q = initialHandler;

	return callback;
}

function _VirtualDom_equalEvents(x, y)
{
	return x.$ == y.$ && _Json_equality(x.a, y.a);
}



// DIFF


// TODO: Should we do patches like in iOS?
//
// type Patch
//   = At Int Patch
//   | Batch (List Patch)
//   | Change ...
//
// How could it not be better?
//
function _VirtualDom_diff(x, y)
{
	var patches = [];
	_VirtualDom_diffHelp(x, y, patches, 0);
	return patches;
}


function _VirtualDom_pushPatch(patches, type, index, data)
{
	var patch = {
		$: type,
		r: index,
		s: data,
		t: undefined,
		u: undefined
	};
	patches.push(patch);
	return patch;
}


function _VirtualDom_diffHelp(x, y, patches, index)
{
	if (x === y)
	{
		return;
	}

	var xType = x.$;
	var yType = y.$;

	// Bail if you run into different types of nodes. Implies that the
	// structure has changed significantly and it's not worth a diff.
	if (xType !== yType)
	{
		if (xType === 1 && yType === 2)
		{
			y = _VirtualDom_dekey(y);
			yType = 1;
		}
		else
		{
			_VirtualDom_pushPatch(patches, 0, index, y);
			return;
		}
	}

	// Now we know that both nodes are the same $.
	switch (yType)
	{
		case 5:
			var xRefs = x.l;
			var yRefs = y.l;
			var i = xRefs.length;
			var same = i === yRefs.length;
			while (same && i--)
			{
				same = xRefs[i] === yRefs[i];
			}
			if (same)
			{
				y.k = x.k;
				return;
			}
			y.k = y.m();
			var subPatches = [];
			_VirtualDom_diffHelp(x.k, y.k, subPatches, 0);
			subPatches.length > 0 && _VirtualDom_pushPatch(patches, 1, index, subPatches);
			return;

		case 4:
			// gather nested taggers
			var xTaggers = x.j;
			var yTaggers = y.j;
			var nesting = false;

			var xSubNode = x.k;
			while (xSubNode.$ === 4)
			{
				nesting = true;

				typeof xTaggers !== 'object'
					? xTaggers = [xTaggers, xSubNode.j]
					: xTaggers.push(xSubNode.j);

				xSubNode = xSubNode.k;
			}

			var ySubNode = y.k;
			while (ySubNode.$ === 4)
			{
				nesting = true;

				typeof yTaggers !== 'object'
					? yTaggers = [yTaggers, ySubNode.j]
					: yTaggers.push(ySubNode.j);

				ySubNode = ySubNode.k;
			}

			// Just bail if different numbers of taggers. This implies the
			// structure of the virtual DOM has changed.
			if (nesting && xTaggers.length !== yTaggers.length)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			// check if taggers are "the same"
			if (nesting ? !_VirtualDom_pairwiseRefEqual(xTaggers, yTaggers) : xTaggers !== yTaggers)
			{
				_VirtualDom_pushPatch(patches, 2, index, yTaggers);
			}

			// diff everything below the taggers
			_VirtualDom_diffHelp(xSubNode, ySubNode, patches, index + 1);
			return;

		case 0:
			if (x.a !== y.a)
			{
				_VirtualDom_pushPatch(patches, 3, index, y.a);
			}
			return;

		case 1:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKids);
			return;

		case 2:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKeyedKids);
			return;

		case 3:
			if (x.h !== y.h)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
			factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

			var patch = y.i(x.g, y.g);
			patch && _VirtualDom_pushPatch(patches, 5, index, patch);

			return;
	}
}

// assumes the incoming arrays are the same length
function _VirtualDom_pairwiseRefEqual(as, bs)
{
	for (var i = 0; i < as.length; i++)
	{
		if (as[i] !== bs[i])
		{
			return false;
		}
	}

	return true;
}

function _VirtualDom_diffNodes(x, y, patches, index, diffKids)
{
	// Bail if obvious indicators have changed. Implies more serious
	// structural changes such that it's not worth it to diff.
	if (x.c !== y.c || x.f !== y.f)
	{
		_VirtualDom_pushPatch(patches, 0, index, y);
		return;
	}

	var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
	factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

	diffKids(x, y, patches, index);
}



// DIFF FACTS


// TODO Instead of creating a new diff object, it's possible to just test if
// there *is* a diff. During the actual patch, do the diff again and make the
// modifications directly. This way, there's no new allocations. Worth it?
function _VirtualDom_diffFacts(x, y, category)
{
	var diff;

	// look for changes and removals
	for (var xKey in x)
	{
		if (xKey === 'a1' || xKey === 'a0' || xKey === 'a3' || xKey === 'a4')
		{
			var subDiff = _VirtualDom_diffFacts(x[xKey], y[xKey] || {}, xKey);
			if (subDiff)
			{
				diff = diff || {};
				diff[xKey] = subDiff;
			}
			continue;
		}

		// remove if not in the new facts
		if (!(xKey in y))
		{
			diff = diff || {};
			diff[xKey] =
				!category
					? (typeof x[xKey] === 'string' ? '' : null)
					:
				(category === 'a1')
					? ''
					:
				(category === 'a0' || category === 'a3')
					? undefined
					:
				{ f: x[xKey].f, o: undefined };

			continue;
		}

		var xValue = x[xKey];
		var yValue = y[xKey];

		// reference equal, so don't worry about it
		if (xValue === yValue && xKey !== 'value' && xKey !== 'checked'
			|| category === 'a0' && _VirtualDom_equalEvents(xValue, yValue))
		{
			continue;
		}

		diff = diff || {};
		diff[xKey] = yValue;
	}

	// add new stuff
	for (var yKey in y)
	{
		if (!(yKey in x))
		{
			diff = diff || {};
			diff[yKey] = y[yKey];
		}
	}

	return diff;
}



// DIFF KIDS


function _VirtualDom_diffKids(xParent, yParent, patches, index)
{
	var xKids = xParent.e;
	var yKids = yParent.e;

	var xLen = xKids.length;
	var yLen = yKids.length;

	// FIGURE OUT IF THERE ARE INSERTS OR REMOVALS

	if (xLen > yLen)
	{
		_VirtualDom_pushPatch(patches, 6, index, {
			v: yLen,
			i: xLen - yLen
		});
	}
	else if (xLen < yLen)
	{
		_VirtualDom_pushPatch(patches, 7, index, {
			v: xLen,
			e: yKids
		});
	}

	// PAIRWISE DIFF EVERYTHING ELSE

	for (var minLen = xLen < yLen ? xLen : yLen, i = 0; i < minLen; i++)
	{
		var xKid = xKids[i];
		_VirtualDom_diffHelp(xKid, yKids[i], patches, ++index);
		index += xKid.b || 0;
	}
}



// KEYED DIFF


function _VirtualDom_diffKeyedKids(xParent, yParent, patches, rootIndex)
{
	var localPatches = [];

	var changes = {}; // Dict String Entry
	var inserts = []; // Array { index : Int, entry : Entry }
	// type Entry = { tag : String, vnode : VNode, index : Int, data : _ }

	var xKids = xParent.e;
	var yKids = yParent.e;
	var xLen = xKids.length;
	var yLen = yKids.length;
	var xIndex = 0;
	var yIndex = 0;

	var index = rootIndex;

	while (xIndex < xLen && yIndex < yLen)
	{
		var x = xKids[xIndex];
		var y = yKids[yIndex];

		var xKey = x.a;
		var yKey = y.a;
		var xNode = x.b;
		var yNode = y.b;

		var newMatch = undefined;
		var oldMatch = undefined;

		// check if keys match

		if (xKey === yKey)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNode, localPatches, index);
			index += xNode.b || 0;

			xIndex++;
			yIndex++;
			continue;
		}

		// look ahead 1 to detect insertions and removals.

		var xNext = xKids[xIndex + 1];
		var yNext = yKids[yIndex + 1];

		if (xNext)
		{
			var xNextKey = xNext.a;
			var xNextNode = xNext.b;
			oldMatch = yKey === xNextKey;
		}

		if (yNext)
		{
			var yNextKey = yNext.a;
			var yNextNode = yNext.b;
			newMatch = xKey === yNextKey;
		}


		// swap x and y
		if (newMatch && oldMatch)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			_VirtualDom_insertNode(changes, localPatches, xKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNextNode, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		// insert y
		if (newMatch)
		{
			index++;
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			index += xNode.b || 0;

			xIndex += 1;
			yIndex += 2;
			continue;
		}

		// remove x
		if (oldMatch)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 1;
			continue;
		}

		// remove x, insert y
		if (xNext && xNextKey === yNextKey)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNextNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		break;
	}

	// eat up any remaining nodes with removeNode and insertNode

	while (xIndex < xLen)
	{
		index++;
		var x = xKids[xIndex];
		var xNode = x.b;
		_VirtualDom_removeNode(changes, localPatches, x.a, xNode, index);
		index += xNode.b || 0;
		xIndex++;
	}

	while (yIndex < yLen)
	{
		var endInserts = endInserts || [];
		var y = yKids[yIndex];
		_VirtualDom_insertNode(changes, localPatches, y.a, y.b, undefined, endInserts);
		yIndex++;
	}

	if (localPatches.length > 0 || inserts.length > 0 || endInserts)
	{
		_VirtualDom_pushPatch(patches, 8, rootIndex, {
			w: localPatches,
			x: inserts,
			y: endInserts
		});
	}
}



// CHANGES FROM KEYED DIFF


var _VirtualDom_POSTFIX = '_elmW6BL';


function _VirtualDom_insertNode(changes, localPatches, key, vnode, yIndex, inserts)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		entry = {
			c: 0,
			z: vnode,
			r: yIndex,
			s: undefined
		};

		inserts.push({ r: yIndex, A: entry });
		changes[key] = entry;

		return;
	}

	// this key was removed earlier, a match!
	if (entry.c === 1)
	{
		inserts.push({ r: yIndex, A: entry });

		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(entry.z, vnode, subPatches, entry.r);
		entry.r = yIndex;
		entry.s.s = {
			w: subPatches,
			A: entry
		};

		return;
	}

	// this key has already been inserted or moved, a duplicate!
	_VirtualDom_insertNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, yIndex, inserts);
}


function _VirtualDom_removeNode(changes, localPatches, key, vnode, index)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		var patch = _VirtualDom_pushPatch(localPatches, 9, index, undefined);

		changes[key] = {
			c: 1,
			z: vnode,
			r: index,
			s: patch
		};

		return;
	}

	// this key was inserted earlier, a match!
	if (entry.c === 0)
	{
		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(vnode, entry.z, subPatches, index);

		_VirtualDom_pushPatch(localPatches, 9, index, {
			w: subPatches,
			A: entry
		});

		return;
	}

	// this key has already been removed or moved, a duplicate!
	_VirtualDom_removeNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, index);
}



// ADD DOM NODES
//
// Each DOM node has an "index" assigned in order of traversal. It is important
// to minimize our crawl over the actual DOM, so these indexes (along with the
// descendantsCount of virtual nodes) let us skip touching entire subtrees of
// the DOM if we know there are no patches there.


function _VirtualDom_addDomNodes(domNode, vNode, patches, eventNode)
{
	_VirtualDom_addDomNodesHelp(domNode, vNode, patches, 0, 0, vNode.b, eventNode);
}


// assumes `patches` is non-empty and indexes increase monotonically.
function _VirtualDom_addDomNodesHelp(domNode, vNode, patches, i, low, high, eventNode)
{
	var patch = patches[i];
	var index = patch.r;

	while (index === low)
	{
		var patchType = patch.$;

		if (patchType === 1)
		{
			_VirtualDom_addDomNodes(domNode, vNode.k, patch.s, eventNode);
		}
		else if (patchType === 8)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var subPatches = patch.s.w;
			if (subPatches.length > 0)
			{
				_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
			}
		}
		else if (patchType === 9)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var data = patch.s;
			if (data)
			{
				data.A.s = domNode;
				var subPatches = data.w;
				if (subPatches.length > 0)
				{
					_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
				}
			}
		}
		else
		{
			patch.t = domNode;
			patch.u = eventNode;
		}

		i++;

		if (!(patch = patches[i]) || (index = patch.r) > high)
		{
			return i;
		}
	}

	var tag = vNode.$;

	if (tag === 4)
	{
		var subNode = vNode.k;

		while (subNode.$ === 4)
		{
			subNode = subNode.k;
		}

		return _VirtualDom_addDomNodesHelp(domNode, subNode, patches, i, low + 1, high, domNode.elm_event_node_ref);
	}

	// tag must be 1 or 2 at this point

	var vKids = vNode.e;
	var childNodes = domNode.childNodes;
	for (var j = 0; j < vKids.length; j++)
	{
		low++;
		var vKid = tag === 1 ? vKids[j] : vKids[j].b;
		var nextLow = low + (vKid.b || 0);
		if (low <= index && index <= nextLow)
		{
			i = _VirtualDom_addDomNodesHelp(childNodes[j], vKid, patches, i, low, nextLow, eventNode);
			if (!(patch = patches[i]) || (index = patch.r) > high)
			{
				return i;
			}
		}
		low = nextLow;
	}
	return i;
}



// APPLY PATCHES


function _VirtualDom_applyPatches(rootDomNode, oldVirtualNode, patches, eventNode)
{
	if (patches.length === 0)
	{
		return rootDomNode;
	}

	_VirtualDom_addDomNodes(rootDomNode, oldVirtualNode, patches, eventNode);
	return _VirtualDom_applyPatchesHelp(rootDomNode, patches);
}

function _VirtualDom_applyPatchesHelp(rootDomNode, patches)
{
	for (var i = 0; i < patches.length; i++)
	{
		var patch = patches[i];
		var localDomNode = patch.t
		var newNode = _VirtualDom_applyPatch(localDomNode, patch);
		if (localDomNode === rootDomNode)
		{
			rootDomNode = newNode;
		}
	}
	return rootDomNode;
}

function _VirtualDom_applyPatch(domNode, patch)
{
	switch (patch.$)
	{
		case 0:
			return _VirtualDom_applyPatchRedraw(domNode, patch.s, patch.u);

		case 4:
			_VirtualDom_applyFacts(domNode, patch.u, patch.s);
			return domNode;

		case 3:
			domNode.replaceData(0, domNode.length, patch.s);
			return domNode;

		case 1:
			return _VirtualDom_applyPatchesHelp(domNode, patch.s);

		case 2:
			if (domNode.elm_event_node_ref)
			{
				domNode.elm_event_node_ref.j = patch.s;
			}
			else
			{
				domNode.elm_event_node_ref = { j: patch.s, p: patch.u };
			}
			return domNode;

		case 6:
			var data = patch.s;
			for (var i = 0; i < data.i; i++)
			{
				domNode.removeChild(domNode.childNodes[data.v]);
			}
			return domNode;

		case 7:
			var data = patch.s;
			var kids = data.e;
			var i = data.v;
			var theEnd = domNode.childNodes[i];
			for (; i < kids.length; i++)
			{
				domNode.insertBefore(_VirtualDom_render(kids[i], patch.u), theEnd);
			}
			return domNode;

		case 9:
			var data = patch.s;
			if (!data)
			{
				domNode.parentNode.removeChild(domNode);
				return domNode;
			}
			var entry = data.A;
			if (typeof entry.r !== 'undefined')
			{
				domNode.parentNode.removeChild(domNode);
			}
			entry.s = _VirtualDom_applyPatchesHelp(domNode, data.w);
			return domNode;

		case 8:
			return _VirtualDom_applyPatchReorder(domNode, patch);

		case 5:
			return patch.s(domNode);

		default:
			_Debug_crash(10); // 'Ran into an unknown patch!'
	}
}


function _VirtualDom_applyPatchRedraw(domNode, vNode, eventNode)
{
	var parentNode = domNode.parentNode;
	var newNode = _VirtualDom_render(vNode, eventNode);

	if (!newNode.elm_event_node_ref)
	{
		newNode.elm_event_node_ref = domNode.elm_event_node_ref;
	}

	if (parentNode && newNode !== domNode)
	{
		parentNode.replaceChild(newNode, domNode);
	}
	return newNode;
}


function _VirtualDom_applyPatchReorder(domNode, patch)
{
	var data = patch.s;

	// remove end inserts
	var frag = _VirtualDom_applyPatchReorderEndInsertsHelp(data.y, patch);

	// removals
	domNode = _VirtualDom_applyPatchesHelp(domNode, data.w);

	// inserts
	var inserts = data.x;
	for (var i = 0; i < inserts.length; i++)
	{
		var insert = inserts[i];
		var entry = insert.A;
		var node = entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u);
		domNode.insertBefore(node, domNode.childNodes[insert.r]);
	}

	// add end inserts
	if (frag)
	{
		_VirtualDom_appendChild(domNode, frag);
	}

	return domNode;
}


function _VirtualDom_applyPatchReorderEndInsertsHelp(endInserts, patch)
{
	if (!endInserts)
	{
		return;
	}

	var frag = _VirtualDom_doc.createDocumentFragment();
	for (var i = 0; i < endInserts.length; i++)
	{
		var insert = endInserts[i];
		var entry = insert.A;
		_VirtualDom_appendChild(frag, entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u)
		);
	}
	return frag;
}


function _VirtualDom_virtualize(node)
{
	// TEXT NODES

	if (node.nodeType === 3)
	{
		return _VirtualDom_text(node.textContent);
	}


	// WEIRD NODES

	if (node.nodeType !== 1)
	{
		return _VirtualDom_text('');
	}


	// ELEMENT NODES

	var attrList = _List_Nil;
	var attrs = node.attributes;
	for (var i = attrs.length; i--; )
	{
		var attr = attrs[i];
		var name = attr.name;
		var value = attr.value;
		attrList = _List_Cons( A2(_VirtualDom_attribute, name, value), attrList );
	}

	var tag = node.tagName.toLowerCase();
	var kidList = _List_Nil;
	var kids = node.childNodes;

	for (var i = kids.length; i--; )
	{
		kidList = _List_Cons(_VirtualDom_virtualize(kids[i]), kidList);
	}
	return A3(_VirtualDom_node, tag, attrList, kidList);
}

function _VirtualDom_dekey(keyedNode)
{
	var keyedKids = keyedNode.e;
	var len = keyedKids.length;
	var kids = new Array(len);
	for (var i = 0; i < len; i++)
	{
		kids[i] = keyedKids[i].b;
	}

	return {
		$: 1,
		c: keyedNode.c,
		d: keyedNode.d,
		e: kids,
		f: keyedNode.f,
		b: keyedNode.b
	};
}




// ELEMENT


var _Debugger_element;

var _Browser_element = _Debugger_element || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function(sendToApp, initialModel) {
			var view = impl.view;
			/**_UNUSED/
			var domNode = args['node'];
			//*/
			/**/
			var domNode = args && args['node'] ? args['node'] : _Debug_crash(0);
			//*/
			var currNode = _VirtualDom_virtualize(domNode);

			return _Browser_makeAnimator(initialModel, function(model)
			{
				var nextNode = view(model);
				var patches = _VirtualDom_diff(currNode, nextNode);
				domNode = _VirtualDom_applyPatches(domNode, currNode, patches, sendToApp);
				currNode = nextNode;
			});
		}
	);
});



// DOCUMENT


var _Debugger_document;

var _Browser_document = _Debugger_document || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.init,
		impl.update,
		impl.subscriptions,
		function(sendToApp, initialModel) {
			var divertHrefToApp = impl.setup && impl.setup(sendToApp)
			var view = impl.view;
			var title = _VirtualDom_doc.title;
			var bodyNode = _VirtualDom_doc.body;
			var currNode = _VirtualDom_virtualize(bodyNode);
			return _Browser_makeAnimator(initialModel, function(model)
			{
				_VirtualDom_divertHrefToApp = divertHrefToApp;
				var doc = view(model);
				var nextNode = _VirtualDom_node('body')(_List_Nil)(doc.body);
				var patches = _VirtualDom_diff(currNode, nextNode);
				bodyNode = _VirtualDom_applyPatches(bodyNode, currNode, patches, sendToApp);
				currNode = nextNode;
				_VirtualDom_divertHrefToApp = 0;
				(title !== doc.title) && (_VirtualDom_doc.title = title = doc.title);
			});
		}
	);
});



// ANIMATION


var _Browser_cancelAnimationFrame =
	typeof cancelAnimationFrame !== 'undefined'
		? cancelAnimationFrame
		: function(id) { clearTimeout(id); };

var _Browser_requestAnimationFrame =
	typeof requestAnimationFrame !== 'undefined'
		? requestAnimationFrame
		: function(callback) { return setTimeout(callback, 1000 / 60); };


function _Browser_makeAnimator(model, draw)
{
	draw(model);

	var state = 0;

	function updateIfNeeded()
	{
		state = state === 1
			? 0
			: ( _Browser_requestAnimationFrame(updateIfNeeded), draw(model), 1 );
	}

	return function(nextModel, isSync)
	{
		model = nextModel;

		isSync
			? ( draw(model),
				state === 2 && (state = 1)
				)
			: ( state === 0 && _Browser_requestAnimationFrame(updateIfNeeded),
				state = 2
				);
	};
}



// APPLICATION


function _Browser_application(impl)
{
	var onUrlChange = impl.onUrlChange;
	var onUrlRequest = impl.onUrlRequest;
	var key = function() { key.a(onUrlChange(_Browser_getUrl())); };

	return _Browser_document({
		setup: function(sendToApp)
		{
			key.a = sendToApp;
			_Browser_window.addEventListener('popstate', key);
			_Browser_window.navigator.userAgent.indexOf('Trident') < 0 || _Browser_window.addEventListener('hashchange', key);

			return F2(function(domNode, event)
			{
				if (!event.ctrlKey && !event.metaKey && !event.shiftKey && event.button < 1 && !domNode.target && !domNode.hasAttribute('download'))
				{
					event.preventDefault();
					var href = domNode.href;
					var curr = _Browser_getUrl();
					var next = $elm$url$Url$fromString(href).a;
					sendToApp(onUrlRequest(
						(next
							&& curr.protocol === next.protocol
							&& curr.host === next.host
							&& curr.port_.a === next.port_.a
						)
							? $elm$browser$Browser$Internal(next)
							: $elm$browser$Browser$External(href)
					));
				}
			});
		},
		init: function(flags)
		{
			return A3(impl.init, flags, _Browser_getUrl(), key);
		},
		view: impl.view,
		update: impl.update,
		subscriptions: impl.subscriptions
	});
}

function _Browser_getUrl()
{
	return $elm$url$Url$fromString(_VirtualDom_doc.location.href).a || _Debug_crash(1);
}

var _Browser_go = F2(function(key, n)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		n && history.go(n);
		key();
	}));
});

var _Browser_pushUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.pushState({}, '', url);
		key();
	}));
});

var _Browser_replaceUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.replaceState({}, '', url);
		key();
	}));
});



// GLOBAL EVENTS


var _Browser_fakeNode = { addEventListener: function() {}, removeEventListener: function() {} };
var _Browser_doc = typeof document !== 'undefined' ? document : _Browser_fakeNode;
var _Browser_window = typeof window !== 'undefined' ? window : _Browser_fakeNode;

var _Browser_on = F3(function(node, eventName, sendToSelf)
{
	return _Scheduler_spawn(_Scheduler_binding(function(callback)
	{
		function handler(event)	{ _Scheduler_rawSpawn(sendToSelf(event)); }
		node.addEventListener(eventName, handler, _VirtualDom_passiveSupported && { passive: true });
		return function() { node.removeEventListener(eventName, handler); };
	}));
});

var _Browser_decodeEvent = F2(function(decoder, event)
{
	var result = _Json_runHelp(decoder, event);
	return $elm$core$Result$isOk(result) ? $elm$core$Maybe$Just(result.a) : $elm$core$Maybe$Nothing;
});



// PAGE VISIBILITY


function _Browser_visibilityInfo()
{
	return (typeof _VirtualDom_doc.hidden !== 'undefined')
		? { hidden: 'hidden', change: 'visibilitychange' }
		:
	(typeof _VirtualDom_doc.mozHidden !== 'undefined')
		? { hidden: 'mozHidden', change: 'mozvisibilitychange' }
		:
	(typeof _VirtualDom_doc.msHidden !== 'undefined')
		? { hidden: 'msHidden', change: 'msvisibilitychange' }
		:
	(typeof _VirtualDom_doc.webkitHidden !== 'undefined')
		? { hidden: 'webkitHidden', change: 'webkitvisibilitychange' }
		: { hidden: 'hidden', change: 'visibilitychange' };
}



// ANIMATION FRAMES


function _Browser_rAF()
{
	return _Scheduler_binding(function(callback)
	{
		var id = _Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(Date.now()));
		});

		return function() {
			_Browser_cancelAnimationFrame(id);
		};
	});
}


function _Browser_now()
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(Date.now()));
	});
}



// DOM STUFF


function _Browser_withNode(id, doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			var node = document.getElementById(id);
			callback(node
				? _Scheduler_succeed(doStuff(node))
				: _Scheduler_fail($elm$browser$Browser$Dom$NotFound(id))
			);
		});
	});
}


function _Browser_withWindow(doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(doStuff()));
		});
	});
}


// FOCUS and BLUR


var _Browser_call = F2(function(functionName, id)
{
	return _Browser_withNode(id, function(node) {
		node[functionName]();
		return _Utils_Tuple0;
	});
});



// WINDOW VIEWPORT


function _Browser_getViewport()
{
	return {
		scene: _Browser_getScene(),
		viewport: {
			x: _Browser_window.pageXOffset,
			y: _Browser_window.pageYOffset,
			width: _Browser_doc.documentElement.clientWidth,
			height: _Browser_doc.documentElement.clientHeight
		}
	};
}

function _Browser_getScene()
{
	var body = _Browser_doc.body;
	var elem = _Browser_doc.documentElement;
	return {
		width: Math.max(body.scrollWidth, body.offsetWidth, elem.scrollWidth, elem.offsetWidth, elem.clientWidth),
		height: Math.max(body.scrollHeight, body.offsetHeight, elem.scrollHeight, elem.offsetHeight, elem.clientHeight)
	};
}

var _Browser_setViewport = F2(function(x, y)
{
	return _Browser_withWindow(function()
	{
		_Browser_window.scroll(x, y);
		return _Utils_Tuple0;
	});
});



// ELEMENT VIEWPORT


function _Browser_getViewportOf(id)
{
	return _Browser_withNode(id, function(node)
	{
		return {
			scene: {
				width: node.scrollWidth,
				height: node.scrollHeight
			},
			viewport: {
				x: node.scrollLeft,
				y: node.scrollTop,
				width: node.clientWidth,
				height: node.clientHeight
			}
		};
	});
}


var _Browser_setViewportOf = F3(function(id, x, y)
{
	return _Browser_withNode(id, function(node)
	{
		node.scrollLeft = x;
		node.scrollTop = y;
		return _Utils_Tuple0;
	});
});



// ELEMENT


function _Browser_getElement(id)
{
	return _Browser_withNode(id, function(node)
	{
		var rect = node.getBoundingClientRect();
		var x = _Browser_window.pageXOffset;
		var y = _Browser_window.pageYOffset;
		return {
			scene: _Browser_getScene(),
			viewport: {
				x: x,
				y: y,
				width: _Browser_doc.documentElement.clientWidth,
				height: _Browser_doc.documentElement.clientHeight
			},
			element: {
				x: x + rect.left,
				y: y + rect.top,
				width: rect.width,
				height: rect.height
			}
		};
	});
}



// LOAD and RELOAD


function _Browser_reload(skipCache)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		_VirtualDom_doc.location.reload(skipCache);
	}));
}

function _Browser_load(url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		try
		{
			_Browser_window.location = url;
		}
		catch(err)
		{
			// Only Firefox can throw a NS_ERROR_MALFORMED_URI exception here.
			// Other browsers reload the page, so let's be consistent about that.
			_VirtualDom_doc.location.reload(false);
		}
	}));
}
var $elm$core$Basics$EQ = {$: 'EQ'};
var $elm$core$Basics$GT = {$: 'GT'};
var $elm$core$Basics$LT = {$: 'LT'};
var $elm$core$List$cons = _List_cons;
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === 'RBEmpty_elm_builtin') {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0.a;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (node.$ === 'SubTree') {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Result$Err = function (a) {
	return {$: 'Err', a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 'Failure', a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 'Field', a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 'Index', a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 'Ok', a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 'OneOf', a: a};
};
var $elm$core$Basics$False = {$: 'False'};
var $elm$core$Basics$add = _Basics_add;
var $elm$core$Maybe$Just = function (a) {
	return {$: 'Just', a: a};
};
var $elm$core$Maybe$Nothing = {$: 'Nothing'};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$core$Basics$append = _Utils_append;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\u000A    ',
		A2($elm$core$String$split, '\u000A', str));
};
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\u000A\u000A(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 'Field':
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 'Nothing') {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\u0027' + (f + '\u0027]'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'Index':
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 'OneOf':
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\u000A\u000A',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\u000A\u000A';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\u000A\u000A    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\u000A\u000A' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 'Array_elm_builtin', a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 'Leaf', a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$eq = _Utils_equal;
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 'SubTree', a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.nodeListSize) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.tail);
		} else {
			var treeLen = builder.nodeListSize * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.nodeList) : builder.nodeList;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.nodeListSize);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.tail) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.tail);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{nodeList: nodeList, nodeListSize: (len / $elm$core$Array$branchFactor) | 0, tail: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Basics$True = {$: 'True'};
var $elm$core$Result$isOk = function (result) {
	if (result.$ === 'Ok') {
		return true;
	} else {
		return false;
	}
};
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$json$Json$Decode$map2 = _Json_map2;
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $elm$virtual_dom$VirtualDom$toHandlerInt = function (handler) {
	switch (handler.$) {
		case 'Normal':
			return 0;
		case 'MayStopPropagation':
			return 1;
		case 'MayPreventDefault':
			return 2;
		default:
			return 3;
	}
};
var $elm$browser$Browser$External = function (a) {
	return {$: 'External', a: a};
};
var $elm$browser$Browser$Internal = function (a) {
	return {$: 'Internal', a: a};
};
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $elm$browser$Browser$Dom$NotFound = function (a) {
	return {$: 'NotFound', a: a};
};
var $elm$url$Url$Http = {$: 'Http'};
var $elm$url$Url$Https = {$: 'Https'};
var $elm$url$Url$Url = F6(
	function (protocol, host, port_, path, query, fragment) {
		return {fragment: fragment, host: host, path: path, port_: port_, protocol: protocol, query: query};
	});
var $elm$core$String$contains = _String_contains;
var $elm$core$String$length = _String_length;
var $elm$core$String$slice = _String_slice;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $elm$core$String$indexes = _String_indexes;
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $elm$core$String$left = F2(
	function (n, string) {
		return (n < 1) ? '' : A3($elm$core$String$slice, 0, n, string);
	});
var $elm$core$String$toInt = _String_toInt;
var $elm$url$Url$chompBeforePath = F5(
	function (protocol, path, params, frag, str) {
		if ($elm$core$String$isEmpty(str) || A2($elm$core$String$contains, '@', str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, ':', str);
			if (!_v0.b) {
				return $elm$core$Maybe$Just(
					A6($elm$url$Url$Url, protocol, str, $elm$core$Maybe$Nothing, path, params, frag));
			} else {
				if (!_v0.b.b) {
					var i = _v0.a;
					var _v1 = $elm$core$String$toInt(
						A2($elm$core$String$dropLeft, i + 1, str));
					if (_v1.$ === 'Nothing') {
						return $elm$core$Maybe$Nothing;
					} else {
						var port_ = _v1;
						return $elm$core$Maybe$Just(
							A6(
								$elm$url$Url$Url,
								protocol,
								A2($elm$core$String$left, i, str),
								port_,
								path,
								params,
								frag));
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}
		}
	});
var $elm$url$Url$chompBeforeQuery = F4(
	function (protocol, params, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '/', str);
			if (!_v0.b) {
				return A5($elm$url$Url$chompBeforePath, protocol, '/', params, frag, str);
			} else {
				var i = _v0.a;
				return A5(
					$elm$url$Url$chompBeforePath,
					protocol,
					A2($elm$core$String$dropLeft, i, str),
					params,
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompBeforeFragment = F3(
	function (protocol, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '?', str);
			if (!_v0.b) {
				return A4($elm$url$Url$chompBeforeQuery, protocol, $elm$core$Maybe$Nothing, frag, str);
			} else {
				var i = _v0.a;
				return A4(
					$elm$url$Url$chompBeforeQuery,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompAfterProtocol = F2(
	function (protocol, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '#', str);
			if (!_v0.b) {
				return A3($elm$url$Url$chompBeforeFragment, protocol, $elm$core$Maybe$Nothing, str);
			} else {
				var i = _v0.a;
				return A3(
					$elm$url$Url$chompBeforeFragment,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$core$String$startsWith = _String_startsWith;
var $elm$url$Url$fromString = function (str) {
	return A2($elm$core$String$startsWith, 'http://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		$elm$url$Url$Http,
		A2($elm$core$String$dropLeft, 7, str)) : (A2($elm$core$String$startsWith, 'https://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		$elm$url$Url$Https,
		A2($elm$core$String$dropLeft, 8, str)) : $elm$core$Maybe$Nothing);
};
var $elm$core$Basics$never = function (_v0) {
	never:
	while (true) {
		var nvr = _v0.a;
		var $temp$_v0 = nvr;
		_v0 = $temp$_v0;
		continue never;
	}
};
var $elm$core$Task$Perform = function (a) {
	return {$: 'Perform', a: a};
};
var $elm$core$Task$succeed = _Scheduler_succeed;
var $elm$core$Task$init = $elm$core$Task$succeed(_Utils_Tuple0);
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$core$Task$andThen = _Scheduler_andThen;
var $elm$core$Task$map = F2(
	function (func, taskA) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return $elm$core$Task$succeed(
					func(a));
			},
			taskA);
	});
var $elm$core$Task$map2 = F3(
	function (func, taskA, taskB) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return A2(
					$elm$core$Task$andThen,
					function (b) {
						return $elm$core$Task$succeed(
							A2(func, a, b));
					},
					taskB);
			},
			taskA);
	});
var $elm$core$Task$sequence = function (tasks) {
	return A3(
		$elm$core$List$foldr,
		$elm$core$Task$map2($elm$core$List$cons),
		$elm$core$Task$succeed(_List_Nil),
		tasks);
};
var $elm$core$Platform$sendToApp = _Platform_sendToApp;
var $elm$core$Task$spawnCmd = F2(
	function (router, _v0) {
		var task = _v0.a;
		return _Scheduler_spawn(
			A2(
				$elm$core$Task$andThen,
				$elm$core$Platform$sendToApp(router),
				task));
	});
var $elm$core$Task$onEffects = F3(
	function (router, commands, state) {
		return A2(
			$elm$core$Task$map,
			function (_v0) {
				return _Utils_Tuple0;
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$map,
					$elm$core$Task$spawnCmd(router),
					commands)));
	});
var $elm$core$Task$onSelfMsg = F3(
	function (_v0, _v1, _v2) {
		return $elm$core$Task$succeed(_Utils_Tuple0);
	});
var $elm$core$Task$cmdMap = F2(
	function (tagger, _v0) {
		var task = _v0.a;
		return $elm$core$Task$Perform(
			A2($elm$core$Task$map, tagger, task));
	});
_Platform_effectManagers['Task'] = _Platform_createManager($elm$core$Task$init, $elm$core$Task$onEffects, $elm$core$Task$onSelfMsg, $elm$core$Task$cmdMap);
var $elm$core$Task$command = _Platform_leaf('Task');
var $elm$core$Task$perform = F2(
	function (toMessage, task) {
		return $elm$core$Task$command(
			$elm$core$Task$Perform(
				A2($elm$core$Task$map, toMessage, task)));
	});
var $elm$browser$Browser$element = _Browser_element;
var $author$project$SiteMain$CategoryAll = {$: 'CategoryAll'};
var $author$project$SiteMain$MotionStandard = {$: 'MotionStandard'};
var $author$project$SiteMain$SampleObserved = {$: 'SampleObserved'};
var $author$project$SiteMain$SurfaceTaskbar = {$: 'SurfaceTaskbar'};
var $author$project$SiteMain$ThemeNight = {$: 'ThemeNight'};
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $author$project$SiteMain$init = function (_v0) {
	return _Utils_Tuple2(
		{
			category: $author$project$SiteMain$CategoryAll,
			cues: {activeApplication: true, switcherCandidate: false, windowFocused: true},
			lastTabFocusMiss: $elm$core$Maybe$Nothing,
			mobileNavOpen: false,
			motion: $author$project$SiteMain$MotionStandard,
			outcomeSample: $author$project$SiteMain$SampleObserved,
			spotlight: $author$project$SiteMain$SurfaceTaskbar,
			tabFocusSeq: 0,
			theme: $author$project$SiteMain$ThemeNight
		},
		$elm$core$Platform$Cmd$none);
};
var $elm$core$Platform$Sub$batch = _Platform_batch;
var $elm$core$Platform$Sub$none = $elm$core$Platform$Sub$batch(_List_Nil);
var $author$project$SiteMain$MotionReduced = {$: 'MotionReduced'};
var $author$project$SiteMain$TabFocusSettled = F3(
	function (a, b, c) {
		return {$: 'TabFocusSettled', a: a, b: b, c: c};
	});
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm$core$Task$onError = _Scheduler_onError;
var $elm$core$Task$attempt = F2(
	function (resultToMessage, task) {
		return $elm$core$Task$command(
			$elm$core$Task$Perform(
				A2(
					$elm$core$Task$onError,
					A2(
						$elm$core$Basics$composeL,
						A2($elm$core$Basics$composeL, $elm$core$Task$succeed, resultToMessage),
						$elm$core$Result$Err),
					A2(
						$elm$core$Task$andThen,
						A2(
							$elm$core$Basics$composeL,
							A2($elm$core$Basics$composeL, $elm$core$Task$succeed, resultToMessage),
							$elm$core$Result$Ok),
						task))));
	});
var $elm$browser$Browser$Dom$focus = _Browser_call('focus');
var $elm$core$Basics$neq = _Utils_notEqual;
var $elm$core$Basics$not = _Basics_not;
var $author$project$SiteMain$findSurfaceIndex = F3(
	function (idx, target, remaining) {
		findSurfaceIndex:
		while (true) {
			if (!remaining.b) {
				return 0;
			} else {
				var first = remaining.a;
				var rest = remaining.b;
				if (_Utils_eq(first, target)) {
					return idx;
				} else {
					var $temp$idx = idx + 1,
						$temp$target = target,
						$temp$remaining = rest;
					idx = $temp$idx;
					target = $temp$target;
					remaining = $temp$remaining;
					continue findSurfaceIndex;
				}
			}
		}
	});
var $elm$core$Basics$modBy = _Basics_modBy;
var $author$project$SiteMain$CategoryAppsFiles = {$: 'CategoryAppsFiles'};
var $author$project$SiteMain$CategorySystem = {$: 'CategorySystem'};
var $author$project$SiteMain$CategoryWindows = {$: 'CategoryWindows'};
var $author$project$SiteMain$SurfaceFiles = {$: 'SurfaceFiles'};
var $author$project$SiteMain$SurfaceLauncher = {$: 'SurfaceLauncher'};
var $author$project$SiteMain$SurfaceNotifications = {$: 'SurfaceNotifications'};
var $author$project$SiteMain$SurfaceSettings = {$: 'SurfaceSettings'};
var $author$project$SiteMain$SurfaceSnap = {$: 'SurfaceSnap'};
var $author$project$SiteMain$SurfaceSwitcher = {$: 'SurfaceSwitcher'};
var $author$project$SiteMain$SurfaceTaskView = {$: 'SurfaceTaskView'};
var $author$project$SiteMain$taskbarSurface = {anchorId: 'taskbar', category: $author$project$SiteMain$CategoryWindows, chord: 'Super + 1-9', elmAuthority: 'Group ordering, primary action routing (activate, minimize, restore, or picker), active indicator projection, and accessible status text.', heading: 'Your apps, one bar away', hostObservation: 'Observed window families, per-output focus and minimized state, CAS pin-store revisions, and effect completion receipts.', imageAlt: 'The Warlock taskbar across the top of the desktop with pinned applications, Start, Task View and the tray', imageHeight: 330, imageSrc: './assets/site/feature-taskbar.png', imageWidth: 1600, label: 'Taskbar', scenarioCta: 'Try the taskbar', scenarioHref: './test-drive/index.html?scenario=taskbar', specHref: './components/taskbar/index.html', summary: 'Pinned and running applications share the top bar. A neutral pill marks running apps and turns lacquer red for the active application alongside Start, Task View, Alt-Tab, notifications, Files, System, and Settings.', surfaceId: $author$project$SiteMain$SurfaceTaskbar};
var $author$project$SiteMain$allSurfaces = _List_fromArray(
	[
		$author$project$SiteMain$taskbarSurface,
		{anchorId: 'launcher', category: $author$project$SiteMain$CategoryAppsFiles, chord: 'Super + Alt + Space', elmAuthority: 'IME-safe search composition, deterministic ranking, bounded paging, compact metadata disclosure, and pin causality guards.', heading: 'Search, then launch', hostObservation: 'Haskell catalog snapshots, durable pin-store revisions, and Submitted, Refused, or Unknown launch receipts distinct from window mapping.', imageAlt: 'The Start-style launcher with its search field, application actions and launch tiles', imageHeight: 620, imageSrc: './assets/site/feature-launcher.png', imageWidth: 1000, label: 'Launcher', scenarioCta: 'Try the launcher', scenarioHref: './test-drive/index.html?scenario=launcher', specHref: './components/launcher/index.html', summary: 'Open Applications, type a query with IME composition safety, and launch the matching entry. The top result exposes application actions and recent items while pinned apps reorder cleanly.', surfaceId: $author$project$SiteMain$SurfaceLauncher},
		{anchorId: 'switcher', category: $author$project$SiteMain$CategoryWindows, chord: 'Alt + Tab', elmAuthority: 'Candidate traversal order, ARIA selection state, commit vs cancel transitions, and steady card geometry across live or fallback previews.', heading: 'Switch windows the way you expect', hostObservation: 'Window incarnation identities, preview stream grants or fallbacks, and verified Hyprland focus change after commit.', imageAlt: 'The Alt-Tab window switcher with the selected window highlighted', imageHeight: 620, imageSrc: './assets/site/feature-switcher.png', imageWidth: 1000, label: 'Alt-Tab', scenarioCta: 'Try Alt-Tab', scenarioHref: './test-drive/index.html?scenario=switcher', specHref: './components/window-switcher/index.html', summary: 'Hold Alt and tap Tab to step through open windows. Corner candidate brackets mark the prospective window before you commit, and Escape leaves focus untouched.', surfaceId: $author$project$SiteMain$SurfaceSwitcher},
		{anchorId: 'task-view', category: $author$project$SiteMain$CategoryWindows, chord: 'Task View', elmAuthority: 'Workspace filter toggles, transfer destination selection, and generation-bound navigation intents.', heading: 'Every desktop at a glance', hostObservation: 'Observed workspace topology, monitor ownership, and post-command workspace or transfer verification.', imageAlt: 'Task View showing workspaces with their windows', imageHeight: 620, imageSrc: './assets/site/feature-task-view.png', imageWidth: 1000, label: 'Task View', scenarioCta: 'Try Task View', scenarioHref: './test-drive/index.html?scenario=task-view', specHref: './components/task-view/index.html', summary: 'Inspect workspaces and their windows side by side, transfer a window to another desktop, or switch straight to an empty or populated workspace.', surfaceId: $author$project$SiteMain$SurfaceTaskView},
		{anchorId: 'snap', category: $author$project$SiteMain$CategoryWindows, chord: 'Snap chooser', elmAuthority: 'Region selection state, explicit Apply confirmation, and separation of snapped state from maximized restore.', heading: 'Snap into place', hostObservation: 'Floating window eligibility checks, observed work-area geometry, and post-placement bounds confirmation.', imageAlt: 'The snap layout chooser with half and quarter screen regions', imageHeight: 620, imageSrc: './assets/site/feature-snap.png', imageWidth: 1000, label: 'Snap layouts', scenarioCta: 'Try snap layouts', scenarioHref: './test-drive/index.html?scenario=snap', specHref: './components/snap-layouts/index.html', summary: 'Choose a half or quarter of the screen from the snap chooser and apply deliberately. Warlock asks Hyprland to place the window and retains pre-snap bounds for clean restore.', surfaceId: $author$project$SiteMain$SurfaceSnap},
		{anchorId: 'notifications', category: $author$project$SiteMain$CategorySystem, chord: 'Tray · Bell', elmAuthority: 'History presentation, Do Not Disturb toggle state, and single-surface accessible announcement routing.', heading: 'Stay in the loop', hostObservation: 'Desktop notification service snapshots, action invocation receipts, and dismissal settlements.', imageAlt: 'The notification center with live notifications, their actions and do not disturb', imageHeight: 620, imageSrc: './assets/site/feature-notifications.png', imageWidth: 1000, label: 'Notifications', scenarioCta: 'Try notifications', scenarioHref: './test-drive/index.html?scenario=notifications', specHref: './components/notifications/index.html', summary: 'Live notifications preserve their producer actions, bounded history keeps what you missed, and Do Not Disturb holds interruptions while you focus.', surfaceId: $author$project$SiteMain$SurfaceNotifications},
		{anchorId: 'settings', category: $author$project$SiteMain$CategorySystem, chord: 'Explicit Save', elmAuthority: 'Draft vs committed appearance state, revision-bound Save proposals, and immediate reduced-motion precedence.', heading: 'Make it yours', hostObservation: 'Atomic preference writes, storage revision receipts, and system reduced-motion observations.', imageAlt: 'Warlock Settings with theme, text size, motion and effects choices', imageHeight: 620, imageSrc: './assets/site/feature-settings.png', imageWidth: 1000, label: 'Settings', scenarioCta: 'Try Settings', scenarioHref: './test-drive/index.html?scenario=settings', specHref: './components/appearance-settings/index.html', summary: 'Review Night, Dawn, or High contrast, 100-200% text size, reduced motion, and portal effect tiers as a draft, then commit atomically with Save.', surfaceId: $author$project$SiteMain$SurfaceSettings},
		{anchorId: 'files', category: $author$project$SiteMain$CategoryAppsFiles, chord: 'Tray · Files', elmAuthority: 'Quick-access tile controls, path input state, and non-replaying outcome feedback when a path is refused or unconfirmed.', heading: 'Your folders, one click away', hostObservation: 'Quint-specified file operation checks, validated path resolution, and peer launch receipts.', imageAlt: 'Files with quick-access tiles for Home, Recent and the collections', imageHeight: 620, imageSrc: './assets/site/feature-files.png', imageWidth: 1000, label: 'Files', scenarioCta: 'Try Files', scenarioHref: './test-drive/index.html?scenario=files', specHref: './components/files/index.html', summary: 'Open Home, Recent, Downloads, Documents, or collections from quick-access tiles, or submit a folder path for checked handoff to Omarchy\u0027s Files application.', surfaceId: $author$project$SiteMain$SurfaceFiles}
	]);
var $author$project$SiteMain$orderedSurfaceIds = A2(
	$elm$core$List$map,
	function ($) {
		return $.surfaceId;
	},
	$author$project$SiteMain$allSurfaces);
var $author$project$SiteMain$surfaceAt = F2(
	function (idx, remaining) {
		surfaceAt:
		while (true) {
			if (!remaining.b) {
				return $author$project$SiteMain$SurfaceTaskbar;
			} else {
				var first = remaining.a;
				var rest = remaining.b;
				if (idx <= 0) {
					return first;
				} else {
					var $temp$idx = idx - 1,
						$temp$remaining = rest;
					idx = $temp$idx;
					remaining = $temp$remaining;
					continue surfaceAt;
				}
			}
		}
	});
var $author$project$SiteMain$stepSurface = F2(
	function (delta, currentId) {
		var total = $elm$core$List$length($author$project$SiteMain$orderedSurfaceIds);
		var currentIdx = A3($author$project$SiteMain$findSurfaceIndex, 0, currentId, $author$project$SiteMain$orderedSurfaceIds);
		var nextIdx = A2(
			$elm$core$Basics$modBy,
			A2($elm$core$Basics$max, 1, total),
			currentIdx + delta);
		return A2($author$project$SiteMain$surfaceAt, nextIdx, $author$project$SiteMain$orderedSurfaceIds);
	});
var $author$project$SiteMain$findSurfaceSpec = function (target) {
	var pick = function (items) {
		pick:
		while (true) {
			if (!items.b) {
				return $author$project$SiteMain$taskbarSurface;
			} else {
				var first = items.a;
				var rest = items.b;
				if (_Utils_eq(first.surfaceId, target)) {
					return first;
				} else {
					var $temp$items = rest;
					items = $temp$items;
					continue pick;
				}
			}
		}
	};
	return pick($author$project$SiteMain$allSurfaces);
};
var $author$project$SiteMain$surfaceTabDomId = function (target) {
	return 'wl-tab-' + $author$project$SiteMain$findSurfaceSpec(target).anchorId;
};
var $author$project$SiteMain$update = F2(
	function (msg, currentModel) {
		switch (msg.$) {
			case 'SelectTheme':
				var chosenTheme = msg.a;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{theme: chosenTheme}),
					$elm$core$Platform$Cmd$none);
			case 'ToggleMotion':
				var nextMotion = function () {
					var _v1 = currentModel.motion;
					if (_v1.$ === 'MotionStandard') {
						return $author$project$SiteMain$MotionReduced;
					} else {
						return $author$project$SiteMain$MotionStandard;
					}
				}();
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{motion: nextMotion}),
					$elm$core$Platform$Cmd$none);
			case 'ToggleMobileNav':
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{mobileNavOpen: !currentModel.mobileNavOpen}),
					$elm$core$Platform$Cmd$none);
			case 'CloseMobileNav':
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{mobileNavOpen: false}),
					$elm$core$Platform$Cmd$none);
			case 'SelectSpotlight':
				var surfaceId = msg.a;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{lastTabFocusMiss: $elm$core$Maybe$Nothing, spotlight: surfaceId}),
					$elm$core$Platform$Cmd$none);
			case 'StepSpotlight':
				var delta = msg.a;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{
							lastTabFocusMiss: $elm$core$Maybe$Nothing,
							spotlight: A2($author$project$SiteMain$stepSurface, delta, currentModel.spotlight)
						}),
					$elm$core$Platform$Cmd$none);
			case 'KeyboardStepSpotlight':
				var delta = msg.a;
				var targetSurface = A2($author$project$SiteMain$stepSurface, delta, currentModel.spotlight);
				var nextSeq = currentModel.tabFocusSeq + 1;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{lastTabFocusMiss: $elm$core$Maybe$Nothing, spotlight: targetSurface, tabFocusSeq: nextSeq}),
					A2(
						$elm$core$Task$attempt,
						A2($author$project$SiteMain$TabFocusSettled, nextSeq, targetSurface),
						$elm$browser$Browser$Dom$focus(
							$author$project$SiteMain$surfaceTabDomId(targetSurface))));
			case 'KeyboardJumpSpotlight':
				var targetSurface = msg.a;
				var nextSeq = currentModel.tabFocusSeq + 1;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{lastTabFocusMiss: $elm$core$Maybe$Nothing, spotlight: targetSurface, tabFocusSeq: nextSeq}),
					A2(
						$elm$core$Task$attempt,
						A2($author$project$SiteMain$TabFocusSettled, nextSeq, targetSurface),
						$elm$browser$Browser$Dom$focus(
							$author$project$SiteMain$surfaceTabDomId(targetSurface))));
			case 'TabFocusSettled':
				var seq = msg.a;
				var targetSurface = msg.b;
				var focusOutcome = msg.c;
				if ((!_Utils_eq(seq, currentModel.tabFocusSeq)) || (!_Utils_eq(targetSurface, currentModel.spotlight))) {
					return _Utils_Tuple2(currentModel, $elm$core$Platform$Cmd$none);
				} else {
					if (focusOutcome.$ === 'Ok') {
						return _Utils_Tuple2(
							_Utils_update(
								currentModel,
								{lastTabFocusMiss: $elm$core$Maybe$Nothing}),
							$elm$core$Platform$Cmd$none);
					} else {
						var missingDomId = focusOutcome.a.a;
						return _Utils_Tuple2(
							_Utils_update(
								currentModel,
								{
									lastTabFocusMiss: $elm$core$Maybe$Just(missingDomId)
								}),
							$elm$core$Platform$Cmd$none);
					}
				}
			case 'SelectCategory':
				var chosenCategory = msg.a;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{category: chosenCategory}),
					$elm$core$Platform$Cmd$none);
			case 'ToggleWindowFocused':
				var prior = currentModel.cues;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{
							cues: _Utils_update(
								prior,
								{windowFocused: !prior.windowFocused})
						}),
					$elm$core$Platform$Cmd$none);
			case 'ToggleActiveApplication':
				var prior = currentModel.cues;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{
							cues: _Utils_update(
								prior,
								{activeApplication: !prior.activeApplication})
						}),
					$elm$core$Platform$Cmd$none);
			case 'ToggleSwitcherCandidate':
				var prior = currentModel.cues;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{
							cues: _Utils_update(
								prior,
								{switcherCandidate: !prior.switcherCandidate})
						}),
					$elm$core$Platform$Cmd$none);
			default:
				var sample = msg.a;
				return _Utils_Tuple2(
					_Utils_update(
						currentModel,
						{outcomeSample: sample}),
					$elm$core$Platform$Cmd$none);
		}
	});
var $elm$html$Html$a = _VirtualDom_node('a');
var $elm$virtual_dom$VirtualDom$attribute = F2(
	function (key, value) {
		return A2(
			_VirtualDom_attribute,
			_VirtualDom_noOnOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlUri(value));
	});
var $elm$html$Html$Attributes$attribute = $elm$virtual_dom$VirtualDom$attribute;
var $author$project$SiteMain$boolToken = function (flag) {
	return flag ? 'true' : 'false';
};
var $elm$json$Json$Encode$string = _Json_wrap;
var $elm$html$Html$Attributes$stringProperty = F2(
	function (key, string) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$string(string));
	});
var $elm$html$Html$Attributes$class = $elm$html$Html$Attributes$stringProperty('className');
var $elm$html$Html$div = _VirtualDom_node('div');
var $elm$html$Html$Attributes$href = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'href',
		_VirtualDom_noJavaScriptUri(url));
};
var $elm$html$Html$Attributes$id = $elm$html$Html$Attributes$stringProperty('id');
var $elm$html$Html$main_ = _VirtualDom_node('main');
var $author$project$SiteMain$motionSlug = function (chosenMotion) {
	if (chosenMotion.$ === 'MotionStandard') {
		return 'standard';
	} else {
		return 'reduced';
	}
};
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $elm$virtual_dom$VirtualDom$node = function (tag) {
	return _VirtualDom_node(
		_VirtualDom_noScript(tag));
};
var $elm$html$Html$node = $elm$virtual_dom$VirtualDom$node;
var $author$project$SiteMain$sharedHeadLinks = function () {
	var stylesheet = function (path) {
		return A3(
			$elm$html$Html$node,
			'link',
			_List_fromArray(
				[
					A2($elm$html$Html$Attributes$attribute, 'rel', 'stylesheet'),
					$elm$html$Html$Attributes$href(path)
				]),
			_List_Nil);
	};
	return _List_fromArray(
		[
			A3(
			$elm$html$Html$node,
			'link',
			_List_fromArray(
				[
					A2($elm$html$Html$Attributes$attribute, 'rel', 'icon'),
					$elm$html$Html$Attributes$href('./assets/brand/identity/warlock-mark-mono.svg')
				]),
			_List_Nil),
			stylesheet('./assets/shared/layers.css'),
			stylesheet('./assets/shared/tokens.css'),
			stylesheet('./assets/shared/fonts.css'),
			stylesheet('./assets/shared/site.css'),
			stylesheet('./assets/shared/glyphs.css'),
			stylesheet('./assets/shared/landing.css'),
			stylesheet('./assets/shared/effects.css')
		]);
}();
var $author$project$SiteMain$supplementalCss = '\u000A@layer base {\u000A  .wl-home-root {\u000A    min-height: 100vh;\u000A    overflow-x: clip;\u000A    color: var(--wl-sys-color-text, #F6EFE8);\u000A    background: var(--wl-sys-color-canvas, #100E0E);\u000A    font-family: var(--wl-sys-font-body, Inter, sans-serif);\u000A    line-height: 1.5;\u000A  }\u000A  .wl-home-root :where(*, *::before, *::after) { box-sizing: border-box; }\u000A  .wl-home-root :where(h1, h2, h3, p, ul, dl) { margin: 0; }\u000A  .wl-home-root img { max-width: 100%; height: auto; }\u000A  .wl-home-root a { color: inherit; text-underline-offset: 0.18em; }\u000A  .wl-home-root :where(button) { font: inherit; }\u000A  .wl-home-root :focus-visible {\u000A    outline: 2px solid var(--wl-sys-color-focus, #8EC8FF);\u000A    outline-offset: 3px;\u000A    box-shadow: 0 0 0 2px var(--wl-sys-color-focus-gap, #191516);\u000A  }\u000A}\u000A\u000A@layer components {\u000A  .wl-home-root[data-theme=\u0022dawn\u0022] .wl-hero {\u000A    background: linear-gradient(90deg, var(--wl-sys-color-canvas) 0%, color-mix(in srgb, var(--wl-sys-color-canvas) 70%, transparent) 42%, transparent 75%),\u000A                url(\u0022./test-drive/stage/assets/wallpaper-dawn.svg\u0022) center/cover no-repeat, var(--wl-sys-color-canvas);\u000A  }\u000A  .wl-home-root[data-theme=\u0022high-contrast\u0022] .wl-hero {\u000A    background: var(--wl-sys-color-canvas, #000000);\u000A  }\u000A  .wl-home-header { gap: 12px 20px; justify-content: space-between; }\u000A  .wl-home-bar { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }\u000A  .wl-home-mobile-actions { display: none; align-items: center; gap: 8px; margin-left: auto; }\u000A  .wl-home-drawer { display: flex; align-items: center; flex-wrap: wrap; gap: 12px 18px; flex: 1 1 auto; justify-content: flex-end; min-width: 0; }\u000A  .wl-home-nav { display: flex; align-items: center; flex-wrap: wrap; gap: 8px 16px; min-width: 0; }\u000A  .wl-home-nav a { padding: 4px 2px; overflow-wrap: anywhere; }\u000A  .wl-home-appearance, .wl-home-tabs, .wl-home-step-group, .wl-home-actions-row, .wl-home-badges {\u000A    display: flex; flex-wrap: wrap; align-items: center; gap: 8px; min-width: 0;\u000A  }\u000A  .wl-home-chip { text-decoration: none; font-size: 0.875rem; min-height: 2.25rem; padding: 6px 12px; }\u000A  .wl-home-chip.is-pressed {\u000A    background: var(--wl-sys-color-surface-selected, #331C1E);\u000A    border-color: var(--wl-sys-color-brand-text, #FCA399);\u000A    box-shadow: inset 0 -3px 0 0 var(--wl-sys-color-brand-text, #FCA399);\u000A    font-weight: 700;\u000A  }\u000A  .wl-home-readiness-strip {\u000A    list-style: none; padding: 0; margin: 0 0 20px;\u000A    display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 220px), 1fr)); gap: 10px;\u000A  }\u000A  .wl-home-readiness-item {\u000A    max-width: none; min-width: 0; padding: 10px 12px; border-radius: var(--wl-sys-radius-control, 6px);\u000A    background: var(--wl-sys-color-surface-recessed, #141112);\u000A    border: 1px solid var(--wl-sys-color-border-essential, #9E9290);\u000A    border-inline-start-width: 3px;\u000A    display: grid; align-content: start; gap: 4px; overflow-wrap: anywhere;\u000A  }\u000A  .wl-home-readiness-item.is-simulated { border-style: dashed; border-inline-start-style: solid; border-inline-start-color: var(--wl-sys-color-info, #8EC8FF); }\u000A  .wl-home-readiness-item.is-component { border-style: dashed; border-inline-start-style: solid; border-inline-start-color: var(--wl-sys-color-brand-text, #FCA399); }\u000A  .wl-home-readiness-item.is-historical { border-inline-start-color: var(--wl-sys-color-positive, #6ED6AC); }\u000A  .wl-home-readiness-item.is-open-gate { border-inline-start-width: 4px; border-inline-start-color: var(--wl-sys-color-warning, #F3C26E); }\u000A  .wl-home-readiness-kicker {\u000A    font-family: var(--wl-sys-font-code, monospace); font-size: 0.75rem; font-weight: 700;\u000A    letter-spacing: 0.05em; text-transform: uppercase; color: var(--wl-sys-color-text, #F6EFE8);\u000A  }\u000A  .wl-home-readiness-value { font-size: 0.8125rem; line-height: 1.4; color: var(--wl-sys-color-text-secondary, #BDB2AF); }\u000A  .wl-home-meta-badge {\u000A    display: inline-flex; align-items: center; width: fit-content; max-width: 100%; min-width: 0;\u000A    padding: 3px 9px; border-radius: var(--wl-sys-radius-control, 6px);\u000A    border: 1px dashed var(--wl-sys-color-border-essential, #9E9290);\u000A    background: var(--wl-sys-color-surface-recessed, #141112);\u000A    color: var(--wl-sys-color-text, #F6EFE8);\u000A    font-family: var(--wl-sys-font-code, monospace); font-size: 0.75rem; line-height: 1.35;\u000A    overflow-wrap: anywhere;\u000A  }\u000A  .wl-home-window .wl-home-meta-badge { background: var(--wl-sys-color-surface, #1C1819); }\u000A  .wl-home-root :where(.wl-doc-button, .wl-home-chip, .wl-feature-link, .wl-home-pill, .wl-home-kbd, .wl-home-meta-badge, .wl-home-dl, .wl-home-dl > div, .wl-home-dl dt, .wl-home-dl dd, .wl-home-window) {\u000A    min-width: 0; max-width: 100%; overflow-wrap: anywhere;\u000A  }\u000A  .wl-home-root .wl-doc-button { white-space: normal; text-align: center; }\u000A  .wl-home-root .wl-feature-link::after { flex: 0 0 auto; }\u000A  .wl-home-window p { margin: 0; }\u000A  .wl-home-scope-grid { grid-template-columns: repeat(auto-fit, minmax(min(100%, 250px), 1fr)); }\u000A  .wl-home-card-stack { display: grid; align-content: start; gap: 10px; min-width: 0; overflow-wrap: anywhere; }\u000A  .wl-home-detail { font-size: 0.875rem; color: var(--wl-sys-color-text-secondary, #BDB2AF); margin: 0; }\u000A  .wl-home-workbench { display: grid; gap: 24px; }\u000A  .wl-home-workbench-bar, .wl-home-filter-bar {\u000A    display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px;\u000A    padding-bottom: 16px; margin-bottom: 24px; border-bottom: 1px solid color-mix(in srgb, var(--wl-sys-color-text, #F6EFE8) 12%, transparent);\u000A  }\u000A  .wl-home-workbench .wl-home-workbench-bar { margin-bottom: 0; }\u000A  .wl-home-split { display: grid; grid-template-columns: minmax(0, 7fr) minmax(0, 5fr); gap: clamp(20px, 3vw, 40px); align-items: start; min-width: 0; }\u000A  .wl-home-specimen-grid { grid-template-columns: repeat(auto-fit, minmax(min(100%, 300px), 1fr)); margin-top: 24px; }\u000A  .wl-home-kbd { padding: 2px 8px; border-radius: 6px; border: 1px solid var(--wl-sys-color-border-essential, #9E9290); font-size: 0.75rem; }\u000A  .wl-home-dl { display: grid; gap: 10px; margin: 4px 0; padding: 12px; border-radius: 8px; background: var(--wl-sys-color-surface-recessed, #141112); border: 1px solid color-mix(in srgb, var(--wl-sys-color-text, #F6EFE8) 10%, transparent); }\u000A  .wl-home-dl dt { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--wl-sys-color-brand-text, #FCA399); }\u000A  .wl-home-dl dd { margin: 2px 0 0; font-size: 0.9rem; color: var(--wl-sys-color-text-secondary, #BDB2AF); }\u000A  .wl-home-window {\u000A    padding: 16px; border-radius: var(--wl-sys-radius-window, 8px);\u000A    background: var(--wl-sys-color-surface-recessed, #141112);\u000A    border: 2px solid var(--wl-sys-color-window-edge-unfocused, #707078);\u000A    display: grid; gap: 8px;\u000A  }\u000A  .wl-home-window.is-focused { border-color: var(--wl-sys-color-window-edge-focused, #F6EFE8); }\u000A  .wl-home-window.is-candidate { outline: 2px dashed var(--wl-sys-color-focus, #8EC8FF); outline-offset: 4px; }\u000A  .wl-home-pill { padding: 4px 10px; border-radius: 999px; border: 1px solid var(--wl-sys-color-border-essential, #9E9290); font-size: 0.8125rem; font-weight: 600; }\u000A  .wl-home-pill.is-active { background: var(--wl-sys-color-action-fill, #B02026); color: var(--wl-sys-color-on-action, #FFF8F5); border-color: var(--wl-sys-color-on-action, #FFF8F5); }\u000A  .wl-home-directory {\u000A    margin-top: 32px; padding-top: 28px; border-top: 1px solid color-mix(in srgb, var(--wl-sys-color-text, #F6EFE8) 12%, transparent);\u000A    display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 220px), 1fr)); gap: 24px;\u000A  }\u000A  .wl-home-links { list-style: none; padding: 0; margin: 0; display: grid; gap: 6px; font-size: 0.9rem; }\u000A  .wl-home-footer { align-items: center; }\u000A\u000A  @media (max-width: 900px) {\u000A    .wl-home-bar { width: 100%; justify-content: space-between; }\u000A    .wl-home-mobile-actions { display: inline-flex; }\u000A    .wl-home-root[data-nav-open=\u0022false\u0022] .wl-home-drawer { display: none; }\u000A    .wl-home-root[data-nav-open=\u0022true\u0022] .wl-home-drawer {\u000A      display: grid; width: 100%; justify-content: stretch; gap: 14px;\u000A      padding-top: 12px; border-top: 1px solid var(--wl-sys-color-border-essential, #9E9290);\u000A    }\u000A    .wl-home-split { grid-template-columns: minmax(0, 1fr); }\u000A    .wl-home-root[data-theme=\u0022dawn\u0022] .wl-hero {\u000A      background: linear-gradient(180deg, color-mix(in srgb, var(--wl-sys-color-canvas) 30%, transparent), var(--wl-sys-color-canvas) 92%),\u000A                  url(\u0022./test-drive/stage/assets/wallpaper-dawn.svg\u0022) center/cover no-repeat, var(--wl-sys-color-canvas);\u000A    }\u000A  }\u000A}\u000A\u000A@layer states {\u000A  .wl-home-chip.is-pressed:hover { background: var(--wl-sys-color-surface-selected-hover, #3A252A); }\u000A  .wl-home-chip.is-pressed:active { background: var(--wl-sys-color-surface-selected-pressed, #423035); }\u000A}\u000A\u000A@layer accessibility {\u000A  .wl-home-root[data-motion=\u0022reduced\u0022] *, .wl-home-root[data-motion=\u0022reduced\u0022] *::before, .wl-home-root[data-motion=\u0022reduced\u0022] *::after {\u000A    transition-duration: 0ms !important;\u000A    animation-duration: 0ms !important;\u000A  }\u000A  .wl-home-root[data-motion=\u0022reduced\u0022] .wl-hero-shot img { transform: none; }\u000A  @media (forced-colors: active) {\u000A    .wl-home-chip.is-pressed { outline: 2px solid Highlight; outline-offset: -2px; text-decoration: underline; }\u000A    .wl-home-window.is-focused { border-color: Highlight; }\u000A    .wl-home-readiness-item, .wl-home-meta-badge { border-color: CanvasText; }\u000A    .wl-home-readiness-item.is-open-gate { border-inline-start-color: Highlight; }\u000A  }\u000A}\u000A';
var $elm$html$Html$Attributes$tabindex = function (n) {
	return A2(
		_VirtualDom_attribute,
		'tabIndex',
		$elm$core$String$fromInt(n));
};
var $elm$virtual_dom$VirtualDom$text = _VirtualDom_text;
var $elm$html$Html$text = $elm$virtual_dom$VirtualDom$text;
var $author$project$SiteMain$themeSlug = function (chosenTheme) {
	switch (chosenTheme.$) {
		case 'ThemeNight':
			return 'night';
		case 'ThemeDawn':
			return 'dawn';
		default:
			return 'high-contrast';
	}
};
var $elm$html$Html$Attributes$alt = $elm$html$Html$Attributes$stringProperty('alt');
var $elm$html$Html$figure = _VirtualDom_node('figure');
var $elm$html$Html$h2 = _VirtualDom_node('h2');
var $elm$html$Html$h3 = _VirtualDom_node('h3');
var $elm$html$Html$Attributes$height = function (n) {
	return A2(
		_VirtualDom_attribute,
		'height',
		$elm$core$String$fromInt(n));
};
var $elm$html$Html$img = _VirtualDom_node('img');
var $elm$html$Html$p = _VirtualDom_node('p');
var $elm$html$Html$section = _VirtualDom_node('section');
var $elm$html$Html$Attributes$src = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'src',
		_VirtualDom_noJavaScriptOrHtmlUri(url));
};
var $elm$html$Html$Attributes$width = function (n) {
	return A2(
		_VirtualDom_attribute,
		'width',
		$elm$core$String$fromInt(n));
};
var $author$project$SiteMain$viewArchitectureSection = A2(
	$elm$html$Html$section,
	_List_fromArray(
		[
			$elm$html$Html$Attributes$id('architecture'),
			$elm$html$Html$Attributes$class('wl-band'),
			A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'architecture-title')
		]),
	_List_fromArray(
		[
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-section-head')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-doc-eyebrow')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Elm + Haskell architecture')
						])),
					A2(
					$elm$html$Html$h2,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('architecture-title')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('One policy authority per decision')
						])),
					A2(
					$elm$html$Html$p,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('Warlock-authored production code uses Elm and Haskell only. Elm owns every GUI element and interaction transition; Haskell owns system integration, Hyprland IPC, atomic storage, and reviewed native WebKit custody.')
						]))
				])),
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-home-split')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$figure,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-feature-shot')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$img,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$src('./assets/brand/readme/elm-architecture.png'),
									$elm$html$Html$Attributes$width(1200),
									$elm$html$Html$Attributes$height(800),
									A2($elm$html$Html$Attributes$attribute, 'loading', 'lazy'),
									$elm$html$Html$Attributes$alt('Diagram of Warlock\u0027s Elm policy engine connected through typed message contracts to Haskell runtime services and Hyprland observations')
								]),
							_List_Nil)
						])),
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$p,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-eyebrow')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('Verified 35-node / 68-edge model')
								])),
							A2(
							$elm$html$Html$h3,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text('Strict boundary between UI intent and compositor truth')
								])),
							A2(
							$elm$html$Html$p,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text('Quint specifications model workspace navigation, file operations, settings CAS revisions, and effect lifecycles. Fuzz and property checks test opaque boundary contracts while ELM-ARC-024 and ELM-DEL-014 govern private UI origin and WebKit engine isolation.')
								])),
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-home-actions-row')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$a,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$class('wl-doc-button wl-doc-button-primary'),
											$elm$html$Html$Attributes$href('./architecture/index.html')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('Explore interactive architecture')
										])),
									A2(
									$elm$html$Html$a,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$class('wl-doc-button'),
											$elm$html$Html$Attributes$href('./get-started/index.html')
										]),
									_List_fromArray(
										[
											$elm$html$Html$text('Read Elm + Haskell guide')
										]))
								]))
						]))
				]))
		]));
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $author$project$SiteMain$matchesCategory = F2(
	function (chosenCategory, spec) {
		if (chosenCategory.$ === 'CategoryAll') {
			return true;
		} else {
			return _Utils_eq(spec.category, chosenCategory);
		}
	});
var $author$project$SiteMain$SelectCategory = function (a) {
	return {$: 'SelectCategory', a: a};
};
var $author$project$SiteMain$countInCategory = function (chosenCategory) {
	return $elm$core$List$length(
		A2(
			$elm$core$List$filter,
			$author$project$SiteMain$matchesCategory(chosenCategory),
			$author$project$SiteMain$allSurfaces));
};
var $elm$html$Html$button = _VirtualDom_node('button');
var $elm$virtual_dom$VirtualDom$Normal = function (a) {
	return {$: 'Normal', a: a};
};
var $elm$virtual_dom$VirtualDom$on = _VirtualDom_on;
var $elm$html$Html$Events$on = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$Normal(decoder));
	});
var $elm$html$Html$Events$onClick = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'click',
		$elm$json$Json$Decode$succeed(msg));
};
var $elm$html$Html$Attributes$type_ = $elm$html$Html$Attributes$stringProperty('type');
var $author$project$SiteMain$viewToggleChip = F3(
	function (isPressed, clickMsg, chipLabel) {
		return A2(
			$elm$html$Html$button,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$type_('button'),
					$elm$html$Html$Attributes$class(
					isPressed ? 'wl-doc-button wl-home-chip is-pressed' : 'wl-doc-button wl-home-chip'),
					A2(
					$elm$html$Html$Attributes$attribute,
					'aria-pressed',
					$author$project$SiteMain$boolToken(isPressed)),
					$elm$html$Html$Events$onClick(clickMsg)
				]),
			_List_fromArray(
				[
					$elm$html$Html$text(chipLabel)
				]));
	});
var $author$project$SiteMain$viewCategoryButton = F3(
	function (activeCategory, targetCategory, labelText) {
		var countLabel = labelText + (' (' + ($elm$core$String$fromInt(
			$author$project$SiteMain$countInCategory(targetCategory)) + ')'));
		return A3(
			$author$project$SiteMain$viewToggleChip,
			_Utils_eq(activeCategory, targetCategory),
			$author$project$SiteMain$SelectCategory(targetCategory),
			countLabel);
	});
var $elm$html$Html$article = _VirtualDom_node('article');
var $author$project$SiteMain$viewFeatureArticle = function (spec) {
	return A2(
		$elm$html$Html$article,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-feature'),
				$elm$html$Html$Attributes$id(spec.anchorId)
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$figure,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-feature-shot')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$img,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$src(spec.imageSrc),
								$elm$html$Html$Attributes$width(spec.imageWidth),
								$elm$html$Html$Attributes$height(spec.imageHeight),
								A2($elm$html$Html$Attributes$attribute, 'loading', 'lazy'),
								$elm$html$Html$Attributes$alt(spec.imageAlt)
							]),
						_List_Nil)
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-feature-copy')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$p,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-doc-eyebrow')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(spec.label)
							])),
						A2(
						$elm$html$Html$h3,
						_List_Nil,
						_List_fromArray(
							[
								$elm$html$Html$text(spec.heading)
							])),
						A2(
						$elm$html$Html$p,
						_List_Nil,
						_List_fromArray(
							[
								$elm$html$Html$text(spec.summary)
							])),
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-actions-row')
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$a,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-feature-link'),
										$elm$html$Html$Attributes$href(spec.scenarioHref)
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(spec.scenarioCta + ' (simulated)')
									])),
								A2(
								$elm$html$Html$a,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-feature-link'),
										$elm$html$Html$Attributes$href(spec.specHref)
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(spec.label + ' specification')
									]))
							]))
					]))
			]));
};
var $author$project$SiteMain$viewFeaturesSection = function (currentModel) {
	var visibleSurfaces = A2(
		$elm$core$List$filter,
		$author$project$SiteMain$matchesCategory(currentModel.category),
		$author$project$SiteMain$allSurfaces);
	var totalCount = $elm$core$List$length($author$project$SiteMain$allSurfaces);
	var shownCount = $elm$core$List$length(visibleSurfaces);
	return A2(
		$elm$html$Html$section,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$id('features'),
				$elm$html$Html$Attributes$class('wl-features'),
				A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'features-title')
			]),
		_Utils_ap(
			_List_fromArray(
				[
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-section-head')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$p,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-eyebrow')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('What it does')
								])),
							A2(
							$elm$html$Html$h2,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$id('features-title')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('The desktop you know, on the compositor you love')
								])),
							A2(
							$elm$html$Html$p,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text('Filter by workflow area or browse all eight desktop surfaces.')
								]))
						])),
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-home-filter-bar')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-home-tabs'),
									A2($elm$html$Html$Attributes$attribute, 'role', 'group'),
									A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Filter desktop surfaces by area')
								]),
							_List_fromArray(
								[
									A3($author$project$SiteMain$viewCategoryButton, currentModel.category, $author$project$SiteMain$CategoryAll, 'All surfaces'),
									A3($author$project$SiteMain$viewCategoryButton, currentModel.category, $author$project$SiteMain$CategoryWindows, 'Windows & workspaces'),
									A3($author$project$SiteMain$viewCategoryButton, currentModel.category, $author$project$SiteMain$CategoryAppsFiles, 'Apps & files'),
									A3($author$project$SiteMain$viewCategoryButton, currentModel.category, $author$project$SiteMain$CategorySystem, 'System & tray')
								])),
							A2(
							$elm$html$Html$p,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-home-detail'),
									A2($elm$html$Html$Attributes$attribute, 'aria-live', 'polite')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text(
									'Showing ' + ($elm$core$String$fromInt(shownCount) + (' of ' + ($elm$core$String$fromInt(totalCount) + ' desktop surfaces.'))))
								]))
						]))
				]),
			A2($elm$core$List$map, $author$project$SiteMain$viewFeatureArticle, visibleSurfaces)));
};
var $elm$html$Html$footer = _VirtualDom_node('footer');
var $author$project$SiteMain$viewFooter = A2(
	$elm$html$Html$footer,
	_List_fromArray(
		[
			$elm$html$Html$Attributes$class('wl-doc-footer wl-home-footer')
		]),
	_List_fromArray(
		[
			A2(
			$elm$html$Html$p,
			_List_Nil,
			_List_fromArray(
				[
					$elm$html$Html$text('Warlock · Windows-style Elm + Haskell desktop for Omarchy and Hyprland.')
				])),
			A2(
			$elm$html$Html$a,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$href('./test-drive/index.html')
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('Browser test drive (simulated)')
				])),
			A2(
			$elm$html$Html$a,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$href('./reference/catalog/v6/index.html')
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('Frozen catalog v6')
				])),
			A2(
			$elm$html$Html$a,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$href('./get-started/contributing/index.html')
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('Contribute')
				])),
			A2(
			$elm$html$Html$a,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$href('./get-started/licenses/index.html')
				]),
			_List_fromArray(
				[
					$elm$html$Html$text('Licenses and attribution')
				])),
			A2(
			$elm$html$Html$p,
			_List_Nil,
			_List_fromArray(
				[
					$elm$html$Html$text('Apache License 2.0')
				]))
		]));
var $author$project$SiteMain$directoryGroups = _List_fromArray(
	[
		{
		heading: 'Foundations & styles',
		links: _List_fromArray(
			[
				_Utils_Tuple2('Design principles', './foundations/principles/index.html'),
				_Utils_Tuple2('Accessibility', './foundations/accessibility/index.html'),
				_Utils_Tuple2('Interaction', './foundations/interaction/index.html'),
				_Utils_Tuple2('Layered windows', './foundations/layered-windows/index.html'),
				_Utils_Tuple2('Color', './styles/color/index.html'),
				_Utils_Tuple2('Typography', './styles/typography/index.html'),
				_Utils_Tuple2('Shape & elevation', './styles/shape/index.html'),
				_Utils_Tuple2('Elevation & glow', './styles/elevation-glow/index.html'),
				_Utils_Tuple2('Motion', './styles/motion/index.html'),
				_Utils_Tuple2('Effects', './styles/effects/index.html'),
				_Utils_Tuple2('Iconography', './styles/iconography/index.html'),
				_Utils_Tuple2('CSS architecture', './styles/css-architecture/index.html')
			])
	},
		{
		heading: 'Core desktop components',
		links: _List_fromArray(
			[
				_Utils_Tuple2('Taskbar', './components/taskbar/index.html'),
				_Utils_Tuple2('Application groups', './components/application-groups/index.html'),
				_Utils_Tuple2('Launcher', './components/launcher/index.html'),
				_Utils_Tuple2('Window picker', './components/window-picker/index.html'),
				_Utils_Tuple2('Window switcher', './components/window-switcher/index.html'),
				_Utils_Tuple2('Task View', './components/task-view/index.html'),
				_Utils_Tuple2('Workspace transfer', './components/workspace-transfer/index.html'),
				_Utils_Tuple2('Previews', './components/previews/index.html'),
				_Utils_Tuple2('Popup surfaces', './components/popup-surfaces/index.html'),
				_Utils_Tuple2('Window menu', './components/window-menu/index.html')
			])
	},
		{
		heading: 'System, files & reference',
		links: _List_fromArray(
			[
				_Utils_Tuple2('Snap layouts', './components/snap-layouts/index.html'),
				_Utils_Tuple2('Application actions', './components/application-actions/index.html'),
				_Utils_Tuple2('Notifications', './components/notifications/index.html'),
				_Utils_Tuple2('Appearance settings', './components/appearance-settings/index.html'),
				_Utils_Tuple2('Motion & shortcuts help', './components/motion-shortcuts-help/index.html'),
				_Utils_Tuple2('Files', './components/files/index.html'),
				_Utils_Tuple2('System menu', './components/system-menu/index.html'),
				_Utils_Tuple2('Dialogs', './components/dialogs/index.html'),
				_Utils_Tuple2('Status & recovery', './components/status-recovery/index.html'),
				_Utils_Tuple2('Contributing', './get-started/contributing/index.html'),
				_Utils_Tuple2('Licenses & attribution', './get-started/licenses/index.html'),
				_Utils_Tuple2('Frozen catalog v6', './reference/catalog/v6/index.html')
			])
	}
	]);
var $author$project$SiteMain$guideCards = _List_fromArray(
	[
		{body: 'Principles, accessibility, keyboard interaction, and layered windows.', href: './foundations/index.html', title: 'Foundations'},
		{body: 'Lacquer color, typography, shape, elevation, motion, icons, and portal effects.', href: './styles/index.html', title: 'Styles'},
		{body: 'Specifications, anatomy, states, and specimens for all 19 desktop surfaces.', href: './components/index.html', title: 'Components'},
		{body: 'Follow Elm policy authority, Haskell services, and compositor boundaries.', href: './architecture/index.html', title: 'Architecture'},
		{body: 'Design tokens, Elm + Haskell workflow, contributor rules, and licenses.', href: './get-started/index.html', title: 'Get started'},
		{body: 'Search documentation routes or inspect the frozen v6 reference catalog.', href: './search/index.html', title: 'Search & frozen catalog'}
	]);
var $elm$html$Html$li = _VirtualDom_node('li');
var $elm$html$Html$nav = _VirtualDom_node('nav');
var $elm$html$Html$ul = _VirtualDom_node('ul');
var $author$project$SiteMain$viewDirectoryGroup = function (grp) {
	return A2(
		$elm$html$Html$nav,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-home-card-stack'),
				A2($elm$html$Html$Attributes$attribute, 'aria-label', grp.heading)
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$h3,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(grp.heading)
					])),
				A2(
				$elm$html$Html$ul,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-links')
					]),
				A2(
					$elm$core$List$map,
					function (_v0) {
						var linkText = _v0.a;
						var linkHref = _v0.b;
						return A2(
							$elm$html$Html$li,
							_List_Nil,
							_List_fromArray(
								[
									A2(
									$elm$html$Html$a,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$href(linkHref)
										]),
									_List_fromArray(
										[
											$elm$html$Html$text(linkText)
										]))
								]));
					},
					grp.links))
			]));
};
var $author$project$SiteMain$viewGuideSection = A2(
	$elm$html$Html$section,
	_List_fromArray(
		[
			$elm$html$Html$Attributes$id('guide'),
			$elm$html$Html$Attributes$class('wl-band'),
			A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'guide-title')
		]),
	_List_fromArray(
		[
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-section-head')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-doc-eyebrow')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('The design language')
						])),
					A2(
					$elm$html$Html$h2,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('guide-title')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Lacquer, in detail')
						])),
					A2(
					$elm$html$Html$p,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('Explore foundations, token-driven styles, all 19 component specifications, and the preserved v6 reference catalog.')
						]))
				])),
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-doc-grid')
				]),
			A2(
				$elm$core$List$map,
				function (card) {
					return A2(
						$elm$html$Html$a,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack'),
								$elm$html$Html$Attributes$href(card.href)
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$h3,
								_List_Nil,
								_List_fromArray(
									[
										$elm$html$Html$text(card.title)
									])),
								A2(
								$elm$html$Html$p,
								_List_Nil,
								_List_fromArray(
									[
										$elm$html$Html$text(card.body)
									]))
							]));
				},
				$author$project$SiteMain$guideCards)),
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-home-directory')
				]),
			A2($elm$core$List$map, $author$project$SiteMain$viewDirectoryGroup, $author$project$SiteMain$directoryGroups))
		]));
var $author$project$SiteMain$CloseMobileNav = {$: 'CloseMobileNav'};
var $author$project$SiteMain$SelectTheme = function (a) {
	return {$: 'SelectTheme', a: a};
};
var $author$project$SiteMain$ThemeDawn = {$: 'ThemeDawn'};
var $author$project$SiteMain$ThemeHighContrast = {$: 'ThemeHighContrast'};
var $author$project$SiteMain$ToggleMobileNav = {$: 'ToggleMobileNav'};
var $author$project$SiteMain$ToggleMotion = {$: 'ToggleMotion'};
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$json$Json$Decode$fail = _Json_fail;
var $elm$json$Json$Decode$field = _Json_decodeField;
var $elm$json$Json$Decode$string = _Json_decodeString;
var $author$project$SiteMain$decodeEscapeKey = function (escapeMsg) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (keyName) {
			return ((keyName === 'Escape') || (keyName === 'Esc')) ? $elm$json$Json$Decode$succeed(escapeMsg) : $elm$json$Json$Decode$fail('not escape');
		},
		A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
};
var $elm$html$Html$header = _VirtualDom_node('header');
var $author$project$SiteMain$primaryNavLinks = _List_fromArray(
	[
		_Utils_Tuple2('Try the desktop', './test-drive/index.html'),
		_Utils_Tuple2('Components', './components/index.html'),
		_Utils_Tuple2('Foundations', './foundations/index.html'),
		_Utils_Tuple2('Styles', './styles/index.html'),
		_Utils_Tuple2('Architecture', './architecture/index.html'),
		_Utils_Tuple2('Get started', './get-started/index.html'),
		_Utils_Tuple2('Search', './search/index.html')
	]);
var $elm$html$Html$span = _VirtualDom_node('span');
var $author$project$SiteMain$viewHeader = function (currentModel) {
	return A2(
		$elm$html$Html$header,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-doc-header wl-home-header'),
				A2(
				$elm$html$Html$Events$on,
				'keydown',
				$author$project$SiteMain$decodeEscapeKey($author$project$SiteMain$CloseMobileNav))
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-bar')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$a,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-doc-brand'),
								$elm$html$Html$Attributes$href('./index.html'),
								A2($elm$html$Html$Attributes$attribute, 'aria-current', 'page'),
								A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Warlock home')
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$img,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$src('./assets/brand/identity/warlock-mark.svg'),
										$elm$html$Html$Attributes$alt(''),
										$elm$html$Html$Attributes$width(32),
										$elm$html$Html$Attributes$height(32)
									]),
								_List_Nil),
								A2(
								$elm$html$Html$span,
								_List_Nil,
								_List_fromArray(
									[
										$elm$html$Html$text('WARLOCK')
									]))
							])),
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-mobile-actions')
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$a,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-doc-button wl-doc-button-primary wl-home-mobile-cta'),
										$elm$html$Html$Attributes$href('./test-drive/index.html')
									]),
								_List_fromArray(
									[
										$elm$html$Html$text('Test drive')
									])),
								A2(
								$elm$html$Html$button,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$type_('button'),
										$elm$html$Html$Attributes$class('wl-doc-button wl-home-nav-toggle'),
										A2(
										$elm$html$Html$Attributes$attribute,
										'aria-expanded',
										$author$project$SiteMain$boolToken(currentModel.mobileNavOpen)),
										A2($elm$html$Html$Attributes$attribute, 'aria-controls', 'wl-home-nav-drawer'),
										$elm$html$Html$Events$onClick($author$project$SiteMain$ToggleMobileNav)
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(
										currentModel.mobileNavOpen ? 'Close menu' : 'Menu')
									]))
							]))
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$id('wl-home-nav-drawer'),
						$elm$html$Html$Attributes$class('wl-home-drawer')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$nav,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-nav'),
								A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Primary')
							]),
						A2(
							$elm$core$List$map,
							function (_v0) {
								var linkLabel = _v0.a;
								var linkHref = _v0.b;
								return A2(
									$elm$html$Html$a,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$href(linkHref),
											$elm$html$Html$Events$onClick($author$project$SiteMain$CloseMobileNav)
										]),
									_List_fromArray(
										[
											$elm$html$Html$text(linkLabel)
										]));
							},
							$author$project$SiteMain$primaryNavLinks)),
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-appearance'),
								A2($elm$html$Html$Attributes$attribute, 'role', 'group'),
								A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Page preview appearance')
							]),
						_List_fromArray(
							[
								A3(
								$author$project$SiteMain$viewToggleChip,
								_Utils_eq(currentModel.theme, $author$project$SiteMain$ThemeNight),
								$author$project$SiteMain$SelectTheme($author$project$SiteMain$ThemeNight),
								'Night'),
								A3(
								$author$project$SiteMain$viewToggleChip,
								_Utils_eq(currentModel.theme, $author$project$SiteMain$ThemeDawn),
								$author$project$SiteMain$SelectTheme($author$project$SiteMain$ThemeDawn),
								'Dawn'),
								A3(
								$author$project$SiteMain$viewToggleChip,
								_Utils_eq(currentModel.theme, $author$project$SiteMain$ThemeHighContrast),
								$author$project$SiteMain$SelectTheme($author$project$SiteMain$ThemeHighContrast),
								'High contrast'),
								A3(
								$author$project$SiteMain$viewToggleChip,
								_Utils_eq(currentModel.motion, $author$project$SiteMain$MotionReduced),
								$author$project$SiteMain$ToggleMotion,
								'Reduced motion')
							]))
					]))
			]));
};
var $elm$html$Html$h1 = _VirtualDom_node('h1');
var $author$project$SiteMain$viewHero = A2(
	$elm$html$Html$section,
	_List_fromArray(
		[
			$elm$html$Html$Attributes$class('wl-hero'),
			A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'hero-title')
		]),
	_List_fromArray(
		[
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-hero-copy')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-hero-eyebrow')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$img,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$src('./assets/brand/identity/warlock-mark.svg'),
									$elm$html$Html$Attributes$width(28),
									$elm$html$Html$Attributes$height(22),
									$elm$html$Html$Attributes$alt('')
								]),
							_List_Nil),
							$elm$html$Html$text('Warlock for Omarchy · Beta MVP in active integration')
						])),
					A2(
					$elm$html$Html$h1,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('hero-title')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('A Windows-style desktop for Hyprland')
						])),
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-hero-lead')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Warlock gives Omarchy a taskbar, a Start-style launcher, Alt-Tab, Task View, snap layouts, notifications, Files quick access, and Settings. Hyprland keeps its tiling, input, and speed; one Elm interface and Haskell runtime keep every desktop surface honest.')
						])),
					A2(
					$elm$html$Html$div,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-hero-actions')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$a,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-button wl-doc-button-primary'),
									$elm$html$Html$Attributes$href('./test-drive/index.html')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('Open browser test drive (simulated)')
								])),
							A2(
							$elm$html$Html$a,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-button'),
									$elm$html$Html$Attributes$href('#workbench')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('Inspect surfaces')
								])),
							A2(
							$elm$html$Html$a,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-button'),
									$elm$html$Html$Attributes$href('#scope')
								]),
							_List_fromArray(
								[
									$elm$html$Html$text('Current beta & native status')
								]))
						])),
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-hero-note')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Honest scope: the browser test drive runs Warlock\u0027s compiled Elm surfaces over a simulated desktop with fixture client interiors. Full Omarchy/Hyprland release parity across the preserved 242 requirements / 417 scenarios remains incomplete (15 whole original requirements hold source-bound historical acceptance), and private-origin security gates (ELM-ARC-024 / ELM-DEL-014) remain OPEN.')
						]))
				])),
			A2(
			$elm$html$Html$figure,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-hero-shot')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$img,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$src('./assets/site/hero-desktop.png'),
							$elm$html$Html$Attributes$width(1600),
							$elm$html$Html$Attributes$height(903),
							$elm$html$Html$Attributes$alt('The Warlock desktop: a frosted taskbar across the top and Task View open with three workspace columns, over a black and red lacquer wallpaper')
						]),
					_List_Nil)
				]))
		]));
var $author$project$SiteMain$principleCards = _List_fromArray(
	[
		_Utils_Tuple2('Show what is known', 'Keep intent, host receipt, and observed window state distinct.'),
		_Utils_Tuple2('Keep targets steady', 'Preserve control identity and geometry while asynchronous facts arrive.'),
		_Utils_Tuple2('Separate attention', 'Give window focus, active app, and switcher candidate distinct cues.'),
		_Utils_Tuple2('Use color economically', 'Let neutral lacquer surfaces carry content and purposeful color carry meaning.'),
		_Utils_Tuple2('Preserve access', 'Keep every action reachable by keyboard, 200% enlarged text, and reduced motion.')
	]);
var $author$project$SiteMain$ToggleActiveApplication = {$: 'ToggleActiveApplication'};
var $author$project$SiteMain$ToggleSwitcherCandidate = {$: 'ToggleSwitcherCandidate'};
var $author$project$SiteMain$ToggleWindowFocused = {$: 'ToggleWindowFocused'};
var $elm$html$Html$code = _VirtualDom_node('code');
var $author$project$SiteMain$viewCueLabCard = function (cueState) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$p,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-doc-eyebrow')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text('Interactive cue check · Separate attention')
					])),
				A2(
				$elm$html$Html$h3,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Window focus, active app, and switcher candidate stay distinct')
					])),
				A2(
				$elm$html$Html$p,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Toggle each independent fact below to verify how Lacquer separates compositor window focus (bright border), active taskbar group (lacquer pill), and uncommitted Alt-Tab candidate selection (corner brackets).')
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-tabs'),
						A2($elm$html$Html$Attributes$attribute, 'role', 'group'),
						A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Toggle attention cues')
					]),
				_List_fromArray(
					[
						A3($author$project$SiteMain$viewToggleChip, cueState.windowFocused, $author$project$SiteMain$ToggleWindowFocused, 'Window focused'),
						A3($author$project$SiteMain$viewToggleChip, cueState.activeApplication, $author$project$SiteMain$ToggleActiveApplication, 'Active app on bar'),
						A3($author$project$SiteMain$viewToggleChip, cueState.switcherCandidate, $author$project$SiteMain$ToggleSwitcherCandidate, 'Alt-Tab candidate')
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class(
						'wl-home-window' + ((cueState.windowFocused ? ' is-focused' : '') + (cueState.switcherCandidate ? ' is-candidate' : ''))),
						A2($elm$html$Html$Attributes$attribute, 'aria-live', 'polite')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-badges')
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$span,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class(
										cueState.activeApplication ? 'wl-home-pill is-active' : 'wl-home-pill')
									]),
								_List_fromArray(
									[
										$elm$html$Html$text(
										cueState.activeApplication ? 'Taskbar: active lacquer pill' : 'Taskbar: neutral running pill')
									])),
								A2(
								$elm$html$Html$code,
								_List_Nil,
								_List_fromArray(
									[
										$elm$html$Html$text(
										'Focus: ' + ((cueState.windowFocused ? 'focused edge' : 'unfocused edge') + (' · Candidate: ' + (cueState.switcherCandidate ? 'selected (uncommitted)' : 'none'))))
									]))
							]))
					]))
			]));
};
var $author$project$SiteMain$SamplePending = {$: 'SamplePending'};
var $author$project$SiteMain$SampleRefused = {$: 'SampleRefused'};
var $author$project$SiteMain$SampleUnknown = {$: 'SampleUnknown'};
var $author$project$SiteMain$SelectOutcomeSample = function (a) {
	return {$: 'SelectOutcomeSample', a: a};
};
var $elm$html$Html$strong = _VirtualDom_node('strong');
var $author$project$SiteMain$viewOutcomeLabCard = function (currentSample) {
	var _v0 = function () {
		switch (currentSample.$) {
			case 'SampleObserved':
				return _Utils_Tuple3('Observed result: Hyprland reported window mapped on Workspace 2', 'Only after an observed compositor snapshot arrives does Elm advance active window and workspace indicators.', './test-drive/index.html?scenario=taskbar');
			case 'SamplePending':
				return _Utils_Tuple3('Submitted receipt: launch accepted, awaiting observed window', 'Elm shows non-blocking pending feedback without fabricating a focused window or reordering taskbar groups early.', './test-drive/index.html?scenario=launcher');
			case 'SampleUnknown':
				return _Utils_Tuple3('Unknown outcome: bridge timed out without confirming failure', 'Ambiguous outcomes are never silently retried when side effects could duplicate launches or move the wrong window.', './test-drive/index.html?scenario=status-recovery');
			default:
				return _Utils_Tuple3('Refused receipt: validation or compositor check rejected request', 'Explicit refusal preserves user draft input in place and explains why the action did not run.', './components/status-recovery/index.html');
		}
	}();
	var statusTitle = _v0.a;
	var statusExplanation = _v0.b;
	var statusHref = _v0.c;
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$p,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-doc-eyebrow')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text('Interactive causality check · Show what is known')
					])),
				A2(
				$elm$html$Html$h3,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text('Intent, receipt, and observed outcome never collapse into one boolean')
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-tabs'),
						A2($elm$html$Html$Attributes$attribute, 'role', 'group'),
						A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Select host receipt state')
					]),
				_List_fromArray(
					[
						A3(
						$author$project$SiteMain$viewToggleChip,
						_Utils_eq(currentSample, $author$project$SiteMain$SampleObserved),
						$author$project$SiteMain$SelectOutcomeSample($author$project$SiteMain$SampleObserved),
						'Observed'),
						A3(
						$author$project$SiteMain$viewToggleChip,
						_Utils_eq(currentSample, $author$project$SiteMain$SamplePending),
						$author$project$SiteMain$SelectOutcomeSample($author$project$SiteMain$SamplePending),
						'Submitted'),
						A3(
						$author$project$SiteMain$viewToggleChip,
						_Utils_eq(currentSample, $author$project$SiteMain$SampleUnknown),
						$author$project$SiteMain$SelectOutcomeSample($author$project$SiteMain$SampleUnknown),
						'Unknown'),
						A3(
						$author$project$SiteMain$viewToggleChip,
						_Utils_eq(currentSample, $author$project$SiteMain$SampleRefused),
						$author$project$SiteMain$SelectOutcomeSample($author$project$SiteMain$SampleRefused),
						'Refused')
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-window is-focused'),
						A2($elm$html$Html$Attributes$attribute, 'aria-live', 'polite')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-meta-badge')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Model preview · Component checks active; native ELM-UI-007 keyboard/AT gate OPEN')
							])),
						A2(
						$elm$html$Html$p,
						_List_Nil,
						_List_fromArray(
							[
								A2(
								$elm$html$Html$strong,
								_List_Nil,
								_List_fromArray(
									[
										$elm$html$Html$text(statusTitle)
									]))
							])),
						A2(
						$elm$html$Html$p,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-detail')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(statusExplanation)
							])),
						A2(
						$elm$html$Html$a,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-feature-link'),
								$elm$html$Html$Attributes$href(statusHref)
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Inspect status & recovery behavior')
							]))
					]))
			]));
};
var $author$project$SiteMain$viewPrinciplesSection = function (currentModel) {
	return A2(
		$elm$html$Html$section,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$id('principles'),
				$elm$html$Html$Attributes$class('wl-band'),
				A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'principles-title')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-section-head')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$p,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-doc-eyebrow')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Built on Elm')
							])),
						A2(
						$elm$html$Html$h2,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$id('principles-title')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Honest about every window')
							])),
						A2(
						$elm$html$Html$p,
						_List_Nil,
						_List_fromArray(
							[
								$elm$html$Html$text('Warlock asks Hyprland to act and shows what Hyprland reports. One Elm policy authority drives every surface, so the taskbar, the launcher, and the switcher never contradict one another.')
							]))
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-doc-grid')
					]),
				A2(
					$elm$core$List$map,
					function (_v0) {
						var titleText = _v0.a;
						var bodyText = _v0.b;
						return A2(
							$elm$html$Html$div,
							_List_fromArray(
								[
									$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack')
								]),
							_List_fromArray(
								[
									A2(
									$elm$html$Html$h3,
									_List_Nil,
									_List_fromArray(
										[
											$elm$html$Html$text(titleText)
										])),
									A2(
									$elm$html$Html$p,
									_List_Nil,
									_List_fromArray(
										[
											$elm$html$Html$text(bodyText)
										]))
								]));
					},
					$author$project$SiteMain$principleCards)),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-split wl-home-specimen-grid')
					]),
				_List_fromArray(
					[
						$author$project$SiteMain$viewCueLabCard(currentModel.cues),
						$author$project$SiteMain$viewOutcomeLabCard(currentModel.outcomeSample)
					]))
			]));
};
var $author$project$SiteMain$readinessTiers = _List_fromArray(
	[
		{kicker: 'Browser simulated', modifier: 'is-simulated', summary: 'Simulated stage & fixture interiors only; never native session proof'},
		{kicker: 'Component + Quint', modifier: 'is-component', summary: 'Isolated Elm contracts & Quint models; ELM-UI-007 slice active'},
		{kicker: '15 / 242 requirements', modifier: 'is-historical', summary: '15 historical source-scoped accepted; 242 requirement register retained'},
		{kicker: 'Native MVP & release OPEN', modifier: 'is-open-gate', summary: '417 scenario obligations · ARC-024, DEL-014 & native AT gates OPEN'}
	]);
var $author$project$SiteMain$scopeCards = _List_fromArray(
	[
		{body: 'The browser test drive runs Warlock\u0027s compiled Elm surfaces (Main, Bar, and Popup) over a deterministic simulated stage. Window interiors are browser fixtures, not Linux processes, Wayland surfaces, or native acceptance proof.', detail: 'Route: ./test-drive/index.html (16 seeded scenarios)', eyebrow: 'Browser test drive · Simulated stage', title: 'Interactive Elm interface on fixture desktop state'},
		{body: 'Authored production code uses Elm and Haskell only, with every GUI element in Elm. Private UI origin, strict CSP, and WebKit engine hardening gates (ELM-ARC-024 and ELM-DEL-014) remain OPEN in active verification.', detail: 'Source: implementation/warlock/ (no Python runtime ships)', eyebrow: 'Beta MVP · Active integration', title: 'Elm GUI + Haskell runtime custody'},
		{body: 'Warlock preserves all 242 original requirements, 417 scenarios, literal latency deadlines, and frozen failure records. Fifteen whole original requirements hold source-bound historical acceptance in the canonical ledger (retaining their recorded scope), while full release and native parity obligations remain incomplete.', detail: 'Historical verdicts retain recorded source scope; browser demos never imply native acceptance', eyebrow: 'Native release gate · 242 requirements / 417 scenarios', title: 'Full release and native parity remain incomplete'},
		{body: 'This homepage is authored in Elm (Browser.element, zero new authored JavaScript) consuming shared site/assets/shared/ tokens and styles. Standalone HTML publication runs through Root\u0027s protected compiler.', detail: 'Contract: site/src/SiteMain.elm + site/elm.json', eyebrow: 'Documentation website · Outside desktop runtime', title: 'Elm homepage source with shared Lacquer tokens'}
	]);
var $author$project$SiteMain$viewReadinessTier = function (tier) {
	return A2(
		$elm$html$Html$li,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-home-readiness-item ' + tier.modifier)
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$span,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-readiness-kicker')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(tier.kicker)
					])),
				A2(
				$elm$html$Html$span,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-readiness-value')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(tier.summary)
					]))
			]));
};
var $author$project$SiteMain$viewScopeCard = function (item) {
	return A2(
		$elm$html$Html$article,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-doc-card wl-home-card-stack')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$p,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-doc-eyebrow')
					]),
				_List_fromArray(
					[
						$elm$html$Html$text(item.eyebrow)
					])),
				A2(
				$elm$html$Html$h3,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(item.title)
					])),
				A2(
				$elm$html$Html$p,
				_List_Nil,
				_List_fromArray(
					[
						$elm$html$Html$text(item.body)
					])),
				A2(
				$elm$html$Html$p,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-home-detail')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$code,
						_List_Nil,
						_List_fromArray(
							[
								$elm$html$Html$text(item.detail)
							]))
					]))
			]));
};
var $author$project$SiteMain$viewScopeSection = A2(
	$elm$html$Html$section,
	_List_fromArray(
		[
			$elm$html$Html$Attributes$id('scope'),
			$elm$html$Html$Attributes$class('wl-band'),
			A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'scope-title')
		]),
	_List_fromArray(
		[
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-section-head')
				]),
			_List_fromArray(
				[
					A2(
					$elm$html$Html$p,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-doc-eyebrow')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Honest delivery boundaries')
						])),
					A2(
					$elm$html$Html$h2,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('scope-title')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('What runs in the browser vs on the native desktop')
						])),
					A2(
					$elm$html$Html$p,
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text('Warlock keeps simulated browser demonstrations, CPU contract checks, Quint formal models, and native compositor acceptance strictly separate. Header appearance buttons above preview Lacquer tokens on this page only.')
						]))
				])),
			A2(
			$elm$html$Html$ul,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-home-readiness-strip'),
					A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Four-tier verification and readiness summary')
				]),
			A2($elm$core$List$map, $author$project$SiteMain$viewReadinessTier, $author$project$SiteMain$readinessTiers)),
			A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class('wl-doc-grid wl-home-scope-grid')
				]),
			A2($elm$core$List$map, $author$project$SiteMain$viewScopeCard, $author$project$SiteMain$scopeCards))
		]));
var $author$project$SiteMain$StepSpotlight = function (a) {
	return {$: 'StepSpotlight', a: a};
};
var $elm$html$Html$dd = _VirtualDom_node('dd');
var $elm$html$Html$dl = _VirtualDom_node('dl');
var $elm$html$Html$dt = _VirtualDom_node('dt');
var $elm$html$Html$kbd = _VirtualDom_node('kbd');
var $author$project$SiteMain$SelectSpotlight = function (a) {
	return {$: 'SelectSpotlight', a: a};
};
var $author$project$SiteMain$KeyboardJumpSpotlight = function (a) {
	return {$: 'KeyboardJumpSpotlight', a: a};
};
var $author$project$SiteMain$KeyboardStepSpotlight = function (a) {
	return {$: 'KeyboardStepSpotlight', a: a};
};
var $author$project$SiteMain$decodeWorkbenchTabKey = A2(
	$elm$json$Json$Decode$andThen,
	function (keyName) {
		switch (keyName) {
			case 'ArrowRight':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardStepSpotlight(1),
						true));
			case 'ArrowDown':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardStepSpotlight(1),
						true));
			case 'ArrowLeft':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardStepSpotlight(-1),
						true));
			case 'ArrowUp':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardStepSpotlight(-1),
						true));
			case 'Home':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardJumpSpotlight($author$project$SiteMain$SurfaceTaskbar),
						true));
			case 'End':
				return $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(
						$author$project$SiteMain$KeyboardJumpSpotlight($author$project$SiteMain$SurfaceFiles),
						true));
			default:
				return $elm$json$Json$Decode$fail('unhandled tab key');
		}
	},
	A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
var $elm$virtual_dom$VirtualDom$MayPreventDefault = function (a) {
	return {$: 'MayPreventDefault', a: a};
};
var $elm$html$Html$Events$preventDefaultOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayPreventDefault(decoder));
	});
var $author$project$SiteMain$viewWorkbenchTab = F2(
	function (activeId, spec) {
		var isSelected = _Utils_eq(activeId, spec.surfaceId);
		return A2(
			$elm$html$Html$button,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$type_('button'),
					$elm$html$Html$Attributes$id(
					$author$project$SiteMain$surfaceTabDomId(spec.surfaceId)),
					$elm$html$Html$Attributes$class(
					isSelected ? 'wl-doc-button wl-home-chip is-pressed' : 'wl-doc-button wl-home-chip'),
					A2($elm$html$Html$Attributes$attribute, 'role', 'tab'),
					A2(
					$elm$html$Html$Attributes$attribute,
					'aria-selected',
					$author$project$SiteMain$boolToken(isSelected)),
					A2($elm$html$Html$Attributes$attribute, 'aria-controls', 'wl-workbench-panel'),
					$elm$html$Html$Attributes$tabindex(
					isSelected ? 0 : (-1)),
					$elm$html$Html$Events$onClick(
					$author$project$SiteMain$SelectSpotlight(spec.surfaceId)),
					A2($elm$html$Html$Events$preventDefaultOn, 'keydown', $author$project$SiteMain$decodeWorkbenchTabKey)
				]),
			_List_fromArray(
				[
					$elm$html$Html$text(spec.label)
				]));
	});
var $author$project$SiteMain$viewWorkbenchSection = function (currentModel) {
	var activeSpec = $author$project$SiteMain$findSurfaceSpec(currentModel.spotlight);
	return A2(
		$elm$html$Html$section,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$id('workbench'),
				$elm$html$Html$Attributes$class('wl-band'),
				A2($elm$html$Html$Attributes$attribute, 'aria-labelledby', 'workbench-title')
			]),
		_List_fromArray(
			[
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-section-head')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$p,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-doc-eyebrow')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Interactive surface workbench')
							])),
						A2(
						$elm$html$Html$h2,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$id('workbench-title')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text('Inspect Elm policy authority vs observed host facts')
							])),
						A2(
						$elm$html$Html$p,
						_List_Nil,
						_List_fromArray(
							[
								$elm$html$Html$text('Select any desktop surface below (or press Left and Right arrow keys on the tab strip) to inspect what Elm decides locally, what the Haskell/Hyprland host reports back, and jump to its simulated scenario or specification.')
							]))
					])),
				A2(
				$elm$html$Html$div,
				_List_fromArray(
					[
						$elm$html$Html$Attributes$class('wl-doc-card wl-home-workbench')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$class('wl-home-workbench-bar')
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$div,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-home-tabs'),
										A2($elm$html$Html$Attributes$attribute, 'role', 'tablist'),
										A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Desktop surfaces')
									]),
								A2(
									$elm$core$List$map,
									$author$project$SiteMain$viewWorkbenchTab(currentModel.spotlight),
									$author$project$SiteMain$allSurfaces)),
								A2(
								$elm$html$Html$div,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-home-step-group')
									]),
								_List_fromArray(
									[
										A2(
										$elm$html$Html$button,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$type_('button'),
												$elm$html$Html$Attributes$class('wl-doc-button wl-home-chip'),
												$elm$html$Html$Events$onClick(
												$author$project$SiteMain$StepSpotlight(-1))
											]),
										_List_fromArray(
											[
												$elm$html$Html$text('Previous')
											])),
										A2(
										$elm$html$Html$button,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$type_('button'),
												$elm$html$Html$Attributes$class('wl-doc-button wl-home-chip'),
												$elm$html$Html$Events$onClick(
												$author$project$SiteMain$StepSpotlight(1))
											]),
										_List_fromArray(
											[
												$elm$html$Html$text('Next')
											]))
									]))
							])),
						A2(
						$elm$html$Html$div,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$id('wl-workbench-panel'),
								$elm$html$Html$Attributes$class('wl-home-split'),
								A2($elm$html$Html$Attributes$attribute, 'role', 'tabpanel'),
								A2(
								$elm$html$Html$Attributes$attribute,
								'aria-labelledby',
								$author$project$SiteMain$surfaceTabDomId(activeSpec.surfaceId)),
								$elm$html$Html$Attributes$tabindex(0)
							]),
						_List_fromArray(
							[
								A2(
								$elm$html$Html$figure,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-feature-shot')
									]),
								_List_fromArray(
									[
										A2(
										$elm$html$Html$img,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$src(activeSpec.imageSrc),
												$elm$html$Html$Attributes$width(activeSpec.imageWidth),
												$elm$html$Html$Attributes$height(activeSpec.imageHeight),
												$elm$html$Html$Attributes$alt(activeSpec.imageAlt)
											]),
										_List_Nil)
									])),
								A2(
								$elm$html$Html$div,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class('wl-home-card-stack')
									]),
								_List_fromArray(
									[
										A2(
										$elm$html$Html$div,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$class('wl-home-badges')
											]),
										_List_fromArray(
											[
												A2(
												$elm$html$Html$span,
												_List_fromArray(
													[
														$elm$html$Html$Attributes$class('wl-doc-eyebrow')
													]),
												_List_fromArray(
													[
														$elm$html$Html$text(activeSpec.label)
													])),
												A2(
												$elm$html$Html$kbd,
												_List_fromArray(
													[
														$elm$html$Html$Attributes$class('wl-home-kbd')
													]),
												_List_fromArray(
													[
														$elm$html$Html$text(activeSpec.chord)
													])),
												A2(
												$elm$html$Html$span,
												_List_fromArray(
													[
														$elm$html$Html$Attributes$class('wl-home-meta-badge')
													]),
												_List_fromArray(
													[
														$elm$html$Html$text('Browser CTA launches simulated fixture')
													]))
											])),
										A2(
										$elm$html$Html$h3,
										_List_Nil,
										_List_fromArray(
											[
												$elm$html$Html$text(activeSpec.heading)
											])),
										A2(
										$elm$html$Html$p,
										_List_Nil,
										_List_fromArray(
											[
												$elm$html$Html$text(activeSpec.summary)
											])),
										A2(
										$elm$html$Html$dl,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$class('wl-home-dl')
											]),
										_List_fromArray(
											[
												A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														A2(
														$elm$html$Html$dt,
														_List_Nil,
														_List_fromArray(
															[
																$elm$html$Html$text('Elm GUI policy authority')
															])),
														A2(
														$elm$html$Html$dd,
														_List_Nil,
														_List_fromArray(
															[
																$elm$html$Html$text(activeSpec.elmAuthority)
															]))
													])),
												A2(
												$elm$html$Html$div,
												_List_Nil,
												_List_fromArray(
													[
														A2(
														$elm$html$Html$dt,
														_List_Nil,
														_List_fromArray(
															[
																$elm$html$Html$text('Target Haskell / Hyprland contract')
															])),
														A2(
														$elm$html$Html$dd,
														_List_Nil,
														_List_fromArray(
															[
																$elm$html$Html$text(activeSpec.hostObservation)
															]))
													]))
											])),
										A2(
										$elm$html$Html$div,
										_List_fromArray(
											[
												$elm$html$Html$Attributes$class('wl-home-actions-row')
											]),
										_List_fromArray(
											[
												A2(
												$elm$html$Html$a,
												_List_fromArray(
													[
														$elm$html$Html$Attributes$class('wl-doc-button wl-doc-button-primary'),
														$elm$html$Html$Attributes$href(activeSpec.scenarioHref)
													]),
												_List_fromArray(
													[
														$elm$html$Html$text(activeSpec.scenarioCta + ' (simulated stage)')
													])),
												A2(
												$elm$html$Html$a,
												_List_fromArray(
													[
														$elm$html$Html$Attributes$class('wl-doc-button'),
														$elm$html$Html$Attributes$href(activeSpec.specHref)
													]),
												_List_fromArray(
													[
														$elm$html$Html$text('Read ' + (activeSpec.label + ' spec'))
													]))
											]))
									]))
							]))
					]))
			]));
};
var $author$project$SiteMain$view = function (currentModel) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class('wl-home-root'),
				A2(
				$elm$html$Html$Attributes$attribute,
				'data-theme',
				$author$project$SiteMain$themeSlug(currentModel.theme)),
				A2(
				$elm$html$Html$Attributes$attribute,
				'data-motion',
				$author$project$SiteMain$motionSlug(currentModel.motion)),
				A2(
				$elm$html$Html$Attributes$attribute,
				'data-nav-open',
				$author$project$SiteMain$boolToken(currentModel.mobileNavOpen))
			]),
		_Utils_ap(
			$author$project$SiteMain$sharedHeadLinks,
			_List_fromArray(
				[
					A3(
					$elm$html$Html$node,
					'style',
					_List_Nil,
					_List_fromArray(
						[
							$elm$html$Html$text($author$project$SiteMain$supplementalCss)
						])),
					A2(
					$elm$html$Html$a,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('wl-doc-skip'),
							$elm$html$Html$Attributes$href('#main')
						]),
					_List_fromArray(
						[
							$elm$html$Html$text('Skip to content')
						])),
					$author$project$SiteMain$viewHeader(currentModel),
					A2(
					$elm$html$Html$main_,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$id('main'),
							$elm$html$Html$Attributes$tabindex(-1),
							$elm$html$Html$Attributes$class('wl-landing')
						]),
					_List_fromArray(
						[
							$author$project$SiteMain$viewHero,
							$author$project$SiteMain$viewScopeSection,
							$author$project$SiteMain$viewWorkbenchSection(currentModel),
							$author$project$SiteMain$viewFeaturesSection(currentModel),
							$author$project$SiteMain$viewPrinciplesSection(currentModel),
							$author$project$SiteMain$viewArchitectureSection,
							$author$project$SiteMain$viewGuideSection
						])),
					$author$project$SiteMain$viewFooter
				])));
};
var $author$project$SiteMain$main = $elm$browser$Browser$element(
	{
		init: $author$project$SiteMain$init,
		subscriptions: function (_v0) {
			return $elm$core$Platform$Sub$none;
		},
		update: $author$project$SiteMain$update,
		view: $author$project$SiteMain$view
	});
_Platform_export({'SiteMain':{'init':$author$project$SiteMain$main(
	$elm$json$Json$Decode$succeed(_Utils_Tuple0))(0)}});}(this));