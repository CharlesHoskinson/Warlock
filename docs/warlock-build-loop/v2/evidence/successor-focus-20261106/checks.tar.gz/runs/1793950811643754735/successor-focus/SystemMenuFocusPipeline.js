(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}




var _List_Nil = { $: 0 };
var _List_Nil_UNUSED = { $: '[]' };

function _List_Cons(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons_UNUSED(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log = F2(function(tag, value)
{
	return value;
});

var _Debug_log_UNUSED = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString(value)
{
	return '<internals>';
}

function _Debug_toString_UNUSED(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash_UNUSED(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.dw.cg === region.dP.cg)
	{
		return 'on line ' + region.dw.cg;
	}
	return 'on lines ' + region.dw.cg + ' through ' + region.dP.cg;
}



// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**_UNUSED/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**_UNUSED/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**/
	if (typeof x.$ === 'undefined')
	//*/
	/**_UNUSED/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0 = 0;
var _Utils_Tuple0_UNUSED = { $: '#0' };

function _Utils_Tuple2(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2_UNUSED(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3_UNUSED(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr(c) { return c; }
function _Utils_chr_UNUSED(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**_UNUSED/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap_UNUSED(value) { return { $: 0, a: value }; }
function _Json_unwrap_UNUSED(value) { return value.a; }

function _Json_wrap(value) { return value; }
function _Json_unwrap(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.fc,
		impl.fN,
		impl.fI,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**_UNUSED/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}
var $elm$core$Basics$EQ = 1;
var $elm$core$Basics$LT = 0;
var $elm$core$List$cons = _List_cons;
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (!node.$) {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === -2) {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Basics$GT = 2;
var $elm$core$Result$Err = function (a) {
	return {$: 1, a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 0, a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 2, a: a};
};
var $elm$core$Basics$False = 1;
var $elm$core$Basics$add = _Basics_add;
var $elm$core$Maybe$Just = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Maybe$Nothing = {$: 1};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$core$Basics$append = _Utils_append;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\u000A    ',
		A2($elm$core$String$split, '\u000A', str));
};
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\u000A\u000A(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 0:
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 1) {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\u0027' + (f + '\u0027]'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 1:
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 2:
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\u000A\u000A',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\u000A\u000A';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\u000A\u000A    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\u000A\u000A' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 0, a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 1, a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$eq = _Utils_equal;
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.S) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.U),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.U);
		} else {
			var treeLen = builder.S * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.Y) : builder.Y;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.S);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.U) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.U);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{Y: nodeList, S: (len / $elm$core$Array$branchFactor) | 0, U: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Basics$True = 0;
var $elm$core$Result$isOk = function (result) {
	if (!result.$) {
		return true;
	} else {
		return false;
	}
};
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $elm$core$Platform$Sub$batch = _Platform_batch;
var $elm$core$Platform$Sub$none = $elm$core$Platform$Sub$batch(_List_Nil);
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $author$project$SystemMenuFocusPipeline$outgoing = _Platform_outgoingPort('outgoing', $elm$core$Basics$identity);
var $author$project$Desktop$CancelSystemChange = function (a) {
	return {$: 32, a: a};
};
var $author$project$SurfaceController$DesktopEffect = function (a) {
	return {$: 0, a: a};
};
var $author$project$Desktop$Focus = function (a) {
	return {$: 5, a: a};
};
var $author$project$Desktop$Incoming = function (a) {
	return {$: 11, a: a};
};
var $author$project$Desktop$OpenSystemMenu = function (a) {
	return {$: 27, a: a};
};
var $author$project$SurfaceController$Publish = function (a) {
	return {$: 1, a: a};
};
var $author$project$SystemMenu$Reboot = 4;
var $author$project$Desktop$SystemChange = F2(
	function (a, b) {
		return {$: 30, a: a, b: b};
	});
var $elm$core$List$any = F2(
	function (isOkay, list) {
		any:
		while (true) {
			if (!list.b) {
				return false;
			} else {
				var x = list.a;
				var xs = list.b;
				if (isOkay(x)) {
					return true;
				} else {
					var $temp$isOkay = isOkay,
						$temp$list = xs;
					isOkay = $temp$isOkay;
					list = $temp$list;
					continue any;
				}
			}
		}
	});
var $elm$json$Json$Encode$object = function (pairs) {
	return _Json_wrap(
		A3(
			$elm$core$List$foldl,
			F2(
				function (_v0, obj) {
					var k = _v0.a;
					var v = _v0.b;
					return A3(_Json_addField, k, v, obj);
				}),
			_Json_emptyObject(0),
			pairs));
};
var $elm$json$Json$Encode$string = _Json_wrap;
var $author$project$SystemMenuFocusPipeline$binding = $elm$json$Json$Encode$object(
	_List_fromArray(
		[
			_Utils_Tuple2(
			'lifetime',
			$elm$json$Json$Encode$string('1')),
			_Utils_Tuple2(
			'session',
			$elm$json$Json$Encode$string('1')),
			_Utils_Tuple2(
			'frontend',
			$elm$json$Json$Encode$string('1'))
		]));
var $elm$json$Json$Encode$int = _Json_wrap;
var $author$project$SystemMenuFocusPipeline$attached = $elm$json$Json$Encode$object(
	_List_fromArray(
		[
			_Utils_Tuple2(
			'protocolVersion',
			$elm$json$Json$Encode$int(3)),
			_Utils_Tuple2(
			'kind',
			$elm$json$Json$Encode$string('attached')),
			_Utils_Tuple2('binding', $author$project$SystemMenuFocusPipeline$binding)
		]));
var $elm$json$Json$Encode$bool = _Json_wrap;
var $author$project$Desktop$ViewStamp = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$core$Maybe$map = F2(
	function (f, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return $elm$core$Maybe$Just(
				f(value));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Desktop$capture = function (model) {
	return A2(
		$elm$core$Maybe$map,
		$author$project$Desktop$ViewStamp(model.a.b.c3),
		model.aF);
};
var $author$project$Desktop$Acknowledge = function (a) {
	return {$: 76, a: a};
};
var $author$project$Menu$Activate = F3(
	function (a, b, c) {
		return {$: 3, a: a, b: b, c: c};
	});
var $author$project$ShortcutPreferences$Alternate = 3;
var $author$project$Desktop$ApplicationsPage = F2(
	function (a, b) {
		return {$: 14, a: a, b: b};
	});
var $author$project$Desktop$ApplySnap = function (a) {
	return {$: 5, a: a};
};
var $author$project$Switcher$Browsing = 2;
var $author$project$GeometryProjection$CanSnap = 2;
var $author$project$Desktop$CancelOverviewTransfer = function (a) {
	return {$: 64, a: a};
};
var $author$project$TaskbarShell$Choose = F3(
	function (a, b, c) {
		return {$: 2, a: a, b: b, c: c};
	});
var $author$project$TaskbarShell$Close = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $author$project$Desktop$CloseApplications = function (a) {
	return {$: 66, a: a};
};
var $author$project$Desktop$CloseFiles = function (a) {
	return {$: 22, a: a};
};
var $author$project$Desktop$CloseJumpList = function (a) {
	return {$: 18, a: a};
};
var $author$project$Desktop$CloseNotifications = function (a) {
	return {$: 34, a: a};
};
var $author$project$Desktop$CloseOverview = function (a) {
	return {$: 57, a: a};
};
var $author$project$Desktop$CloseSettings = function (a) {
	return {$: 40, a: a};
};
var $author$project$Desktop$CloseSnap = function (a) {
	return {$: 6, a: a};
};
var $author$project$Desktop$CloseSwitcher = function (a) {
	return {$: 56, a: a};
};
var $author$project$Desktop$CloseSystemMenu = function (a) {
	return {$: 28, a: a};
};
var $author$project$Desktop$CommitSwitcher = function (a) {
	return {$: 55, a: a};
};
var $author$project$Desktop$ConfigureNotificationPolicy = F2(
	function (a, b) {
		return {$: 37, a: a, b: b};
	});
var $author$project$Desktop$ConfirmSystemChange = F2(
	function (a, b) {
		return {$: 31, a: a, b: b};
	});
var $author$project$Settings$Dawn = 1;
var $author$project$ShortcutPreferences$Default = 2;
var $author$project$Menu$Dismiss = function (a) {
	return {$: 5, a: a};
};
var $author$project$Notifications$Dismiss = 1;
var $author$project$Desktop$EditFilesPath = F2(
	function (a, b) {
		return {$: 24, a: a, b: b};
	});
var $author$project$Desktop$EditMotionPreference = F2(
	function (a, b) {
		return {$: 47, a: a, b: b};
	});
var $author$project$Desktop$EditSettings = F2(
	function (a, b) {
		return {$: 45, a: a, b: b};
	});
var $author$project$Desktop$EditShortcutChoice = F3(
	function (a, b, c) {
		return {$: 42, a: a, b: b, c: c};
	});
var $author$project$Notifications$EntryLive = 0;
var $author$project$Switcher$Forward = 0;
var $author$project$MotionPreferences$Full = 2;
var $author$project$Settings$HighContrast = 2;
var $author$project$Notifications$Invoke = 0;
var $author$project$Desktop$JumpAction = F2(
	function (a, b) {
		return {$: 20, a: a, b: b};
	});
var $author$project$ShortcutPreferences$Keep = 1;
var $author$project$SystemMenu$Lock = 6;
var $author$project$SystemMenu$Logout = 7;
var $author$project$TaskbarShell$MenuEvent = function (a) {
	return {$: 5, a: a};
};
var $author$project$Desktop$MovePin = F3(
	function (a, b, c) {
		return {$: 69, a: a, b: b, c: c};
	});
var $author$project$SystemMenu$Mute = 1;
var $author$project$SystemMenu$Network = 2;
var $author$project$SystemMenu$NetworkNo = 1;
var $author$project$Settings$Night = 0;
var $author$project$Desktop$NotificationAction = F2(
	function (a, b) {
		return {$: 38, a: a, b: b};
	});
var $author$project$Desktop$OpenFilesPath = function (a) {
	return {$: 26, a: a};
};
var $author$project$Desktop$OpenFilesTarget = F2(
	function (a, b) {
		return {$: 25, a: a, b: b};
	});
var $author$project$Desktop$OpenJumpList = F2(
	function (a, b) {
		return {$: 17, a: a, b: b};
	});
var $author$project$Desktop$OpenOverviewTransfer = F2(
	function (a, b) {
		return {$: 63, a: a, b: b};
	});
var $author$project$Desktop$OpenSnap = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $author$project$Desktop$OverviewChoose = F2(
	function (a, b) {
		return {$: 62, a: a, b: b};
	});
var $author$project$Desktop$OverviewNavigateWorkspace = F2(
	function (a, b) {
		return {$: 58, a: a, b: b};
	});
var $author$project$Desktop$OverviewTransfer = F3(
	function (a, b, c) {
		return {$: 65, a: a, b: b, c: c};
	});
var $author$project$Desktop$OverviewWorkspace = F2(
	function (a, b) {
		return {$: 61, a: a, b: b};
	});
var $author$project$SystemMenu$PowerOff = 5;
var $author$project$Menu$Ready = {$: 0};
var $author$project$JumpList$RecentAction = 1;
var $author$project$MotionPreferences$Reduce = 1;
var $author$project$Desktop$RefreshApplications = function (a) {
	return {$: 13, a: a};
};
var $author$project$Desktop$RefreshFiles = function (a) {
	return {$: 23, a: a};
};
var $author$project$Desktop$RefreshJumpList = function (a) {
	return {$: 19, a: a};
};
var $author$project$Desktop$RefreshMotionPreference = function (a) {
	return {$: 49, a: a};
};
var $author$project$Desktop$RefreshNotifications = function (a) {
	return {$: 36, a: a};
};
var $author$project$Desktop$RefreshSettings = function (a) {
	return {$: 50, a: a};
};
var $author$project$Desktop$RefreshShortcutChoices = function (a) {
	return {$: 44, a: a};
};
var $author$project$Desktop$RefreshSystemMenu = function (a) {
	return {$: 29, a: a};
};
var $author$project$Desktop$RefreshWorkspaceNavigation = function (a) {
	return {$: 59, a: a};
};
var $author$project$Switcher$Reverse = 1;
var $author$project$Desktop$SaveMotionPreference = function (a) {
	return {$: 48, a: a};
};
var $author$project$Desktop$SaveSettings = function (a) {
	return {$: 46, a: a};
};
var $author$project$Desktop$SaveShortcutChoices = function (a) {
	return {$: 43, a: a};
};
var $author$project$Desktop$SearchQuery = F2(
	function (a, b) {
		return {$: 67, a: a, b: b};
	});
var $author$project$Desktop$SelectSnap = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $author$project$Desktop$Start = function (a) {
	return {$: 72, a: a};
};
var $author$project$SystemMenu$Suspend = 3;
var $author$project$Desktop$SwitcherChoose = F2(
	function (a, b) {
		return {$: 54, a: a, b: b};
	});
var $author$project$Desktop$SwitcherStep = F2(
	function (a, b) {
		return {$: 53, a: a, b: b};
	});
var $author$project$MotionPreferences$System = 0;
var $author$project$Desktop$TogglePin = F2(
	function (a, b) {
		return {$: 68, a: a, b: b};
	});
var $author$project$Desktop$ToggleSettingsHelp = function (a) {
	return {$: 41, a: a};
};
var $author$project$SystemMenu$Volume = 0;
var $author$project$Desktop$Window = function (a) {
	return {$: 1, a: a};
};
var $elm$core$String$length = _String_length;
var $author$project$Surface$actionName = F2(
	function (action, name) {
		return ($elm$core$String$length(action) > 512) ? name : action;
	});
var $elm$core$Maybe$andThen = F2(
	function (callback, maybeValue) {
		if (!maybeValue.$) {
			var value = maybeValue.a;
			return callback(value);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Desktop$applicationPageSize = function (model) {
	return model.bA ? 1 : 8;
};
var $author$project$Shell$Ready = 2;
var $elm$core$Basics$neq = _Utils_notEqual;
var $elm$core$Basics$not = _Basics_not;
var $author$project$Effects$Pending = 0;
var $elm$core$Maybe$withDefault = F2(
	function (_default, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return value;
		} else {
			return _default;
		}
	});
var $author$project$Effects$pending = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (transaction) {
				return !transaction.O;
			},
			model.dz));
};
var $author$project$Shell$available = function (model) {
	return (!model.c1) && ((!model.cl) && ((!model.aa) && ((model.m === 2) && ((!model.ar) && ((!$author$project$Effects$pending(model.V)) && (_Utils_eq(model.dY, $elm$core$Maybe$Nothing) && ((!A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.V;
			},
			model.dc))) || (_Utils_eq(model.cE, $elm$core$Maybe$Nothing) && (!_Utils_eq(model.ac, $elm$core$Maybe$Nothing))))))))));
};
var $author$project$WorkspaceNavigation$Pending = 0;
var $author$project$WorkspaceNavigation$Unknown = 1;
var $author$project$WorkspaceNavigation$blocked = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (r) {
				return (!r.O) || (r.O === 1);
			},
			model.fz));
};
var $author$project$Shell$Stamp = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $author$project$Binding$matchesContext = F3(
	function (life, epoch, _v0) {
		var lifetime = _v0.a;
		var frontend = _v0.c;
		return _Utils_eq(life, lifetime) && _Utils_eq(epoch, frontend);
	});
var $author$project$Shell$capture = function (model) {
	var _v0 = _Utils_Tuple2(model.c3, model.V.av);
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var observed = _v0.b.a;
		return A3($author$project$Binding$matchesContext, observed.R.fe, observed.R.e4, binding) ? $elm$core$Maybe$Just(
			A3($author$project$Shell$Stamp, binding, observed.R.z, observed.R.cN)) : $elm$core$Maybe$Nothing;
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$ShortcutPreferences$choices = F2(
	function (route, values) {
		switch (route) {
			case 'applications':
				return values.aj;
			case 'system':
				return values.bI;
			default:
				return values.C;
		}
	});
var $author$project$ShortcutPreferences$row = F2(
	function (route, inventory) {
		switch (route) {
			case 'applications':
				return inventory.aj;
			case 'system':
				return inventory.bI;
			default:
				return inventory.C;
		}
	});
var $author$project$ShortcutPreferences$changed = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (current) {
				return !_Utils_eq(current.L, model.e2);
			},
			model.c)) || A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (current) {
				return A2(
					$elm$core$List$any,
					function (route) {
						return !_Utils_eq(
							A2($author$project$ShortcutPreferences$choices, route, model.e2),
							A2($author$project$ShortcutPreferences$row, route, current).dC);
					},
					_List_fromArray(
						['applications', 'system', 'notifications']));
			},
			model.cH));
};
var $elm$core$Basics$clamp = F3(
	function (low, high, number) {
		return (_Utils_cmp(number, low) < 0) ? low : ((_Utils_cmp(number, high) > 0) ? high : number);
	});
var $author$project$SystemMenu$code = function (operation) {
	switch (operation) {
		case 0:
			return 'volume-set';
		case 1:
			return 'volume-mute';
		case 2:
			return 'network-enable';
		case 3:
			return 'suspend';
		case 4:
			return 'reboot';
		case 5:
			return 'poweroff';
		case 6:
			return 'session-lock';
		default:
			return 'session-logout';
	}
};
var $author$project$Files$collections = _List_fromArray(
	[
		_Utils_Tuple2('recent', 'Recent'),
		_Utils_Tuple2('images', 'Images'),
		_Utils_Tuple2('videos', 'Videos'),
		_Utils_Tuple2('documents', 'Documents'),
		_Utils_Tuple2('downloads', 'Downloads'),
		_Utils_Tuple2('large', 'Large files'),
		_Utils_Tuple2('screenshots', 'Screenshots')
	]);
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm$core$Basics$composeR = F3(
	function (f, g, x) {
		return g(
			f(x));
	});
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$append = F2(
	function (xs, ys) {
		if (!ys.b) {
			return xs;
		} else {
			return A3($elm$core$List$foldr, $elm$core$List$cons, ys, xs);
		}
	});
var $elm$core$List$concat = function (lists) {
	return A3($elm$core$List$foldr, $elm$core$List$append, _List_Nil, lists);
};
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$core$List$concatMap = F2(
	function (f, list) {
		return $elm$core$List$concat(
			A2($elm$core$List$map, f, list));
	});
var $author$project$GeometryProjection$Maximized = 1;
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $elm$core$List$head = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(x);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$GeometryProjection$window = F2(
	function (incarnation, snapshot) {
		return $elm$core$List$head(
			A2(
				$elm$core$List$filter,
				function (row) {
					return _Utils_eq(row.au, incarnation);
				},
				snapshot.a));
	});
var $author$project$Surface$confirmedWindowState = F2(
	function (model, root) {
		var shell = model.a.b;
		return (!_Utils_eq(shell.cE, $elm$core$Maybe$Nothing)) ? '' : A2(
			$elm$core$Maybe$withDefault,
			'',
			A2(
				$elm$core$Maybe$map,
				function (window) {
					return A2(
						$elm$core$String$join,
						' • ',
						_Utils_ap(
							(window.ec === 1) ? _List_fromArray(
								['Maximized']) : _List_Nil,
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									function (pin) {
										return pin.fr ? _List_fromArray(
											['Always on top']) : _List_Nil;
									},
									window.dp))));
				},
				A2(
					$elm$core$Maybe$andThen,
					function (observed) {
						return (!_Utils_eq(
							shell.c3,
							$elm$core$Maybe$Just(observed.c3))) ? $elm$core$Maybe$Nothing : A2($author$project$GeometryProjection$window, root, observed);
					},
					shell.ac)));
	});
var $author$project$MenuBridge$currentProvider = function (_v0) {
	var state = _v0;
	return A2(
		$elm$core$Maybe$map,
		function ($) {
			return $.c;
		},
		state.bB);
};
var $elm$core$List$member = F2(
	function (x, xs) {
		return A2(
			$elm$core$List$any,
			function (a) {
				return _Utils_eq(a, x);
			},
			xs);
	});
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $elm$core$String$startsWith = _String_startsWith;
var $author$project$Transfer$ordinary = function (value) {
	return (!$elm$core$String$isEmpty(value)) && ((!A2($elm$core$String$startsWith, '0', value)) && (A2($elm$core$String$all, $elm$core$Char$isDigit, value) && (($elm$core$String$length(value) < 19) || (($elm$core$String$length(value) === 19) && (value <= '9223372036854775807')))));
};
var $author$project$Transfer$destinations = function (snapshot) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (w, ids) {
				var _v0 = w.dB;
				if (!_v0.$) {
					var id = _v0.a;
					return ($author$project$Transfer$ordinary(id) && (!A2($elm$core$List$member, id, ids))) ? _Utils_ap(
						ids,
						_List_fromArray(
							[id])) : ids;
				} else {
					return ids;
				}
			}),
		A2(
			$elm$core$List$map,
			$elm$core$String$fromInt,
			A2($elm$core$List$range, 1, 10)),
		snapshot.a);
};
var $elm$core$String$fromList = _String_fromList;
var $elm$core$String$foldr = _String_foldr;
var $elm$core$String$toList = function (string) {
	return A3($elm$core$String$foldr, $elm$core$List$cons, _List_Nil, string);
};
var $author$project$Surface$displayPrefix = F2(
	function (limit, value) {
		var step = F2(
			function (_char, _v1) {
				var kept = _v1.a;
				var units = _v1.b;
				var stopped = _v1.c;
				var size = ($elm$core$Char$toCode(_char) > 65535) ? 2 : 1;
				return (stopped || (_Utils_cmp(units + size, limit) > 0)) ? _Utils_Tuple3(kept, units, true) : _Utils_Tuple3(
					A2($elm$core$List$cons, _char, kept),
					units + size,
					false);
			});
		var _v0 = A3(
			$elm$core$List$foldl,
			step,
			_Utils_Tuple3(_List_Nil, 0, false),
			$elm$core$String$toList(value));
		var characters = _v0.a;
		return $elm$core$String$fromList(
			$elm$core$List$reverse(characters));
	});
var $author$project$Surface$displayLabel = function (value) {
	return ($elm$core$String$length(value) > 512) ? (A2($author$project$Surface$displayPrefix, 511, value) + '…') : value;
};
var $elm$core$List$drop = F2(
	function (n, list) {
		drop:
		while (true) {
			if (n <= 0) {
				return list;
			} else {
				if (!list.b) {
					return list;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs;
					n = $temp$n;
					list = $temp$list;
					continue drop;
				}
			}
		}
	});
var $author$project$Switcher$entries = function (_v0) {
	var model = _v0;
	return model.ak;
};
var $author$project$Notifications$entryStateName = function (state) {
	switch (state) {
		case 0:
			return 'live';
		case 1:
			return 'expired';
		case 2:
			return 'invoked';
		case 3:
			return 'dismissed';
		case 4:
			return 'closed';
		case 5:
			return 'disconnected';
		case 6:
			return 'unknown';
		default:
			return 'unavailable';
	}
};
var $author$project$Effects$Unknown = 4;
var $author$project$UInt64$string = function (_v0) {
	var value = _v0;
	return value;
};
var $author$project$Binding$authorityIdentity = function (_v0) {
	var lifetime = _v0.a;
	return $author$project$UInt64$string(lifetime);
};
var $author$project$Effects$blocked = F3(
	function (lifetime, incarnation, model) {
		return A2(
			$elm$core$List$any,
			function (t) {
				return _Utils_eq(t.af.R.fe, lifetime) && (_Utils_eq(t.af.au, incarnation) && A2(
					$elm$core$List$member,
					t.O,
					_List_fromArray(
						[0, 4])));
			},
			model.fM);
	});
var $author$project$Menu$Window = function (a) {
	return {$: 0, a: a};
};
var $author$project$Menu$hasOutstandingFor = F2(
	function (window, _v0) {
		var state = _v0;
		return A2(
			$elm$core$List$any,
			function (entry) {
				var _v1 = entry.c3;
				var value = _v1;
				return _Utils_eq(
					value.fK,
					$author$project$Menu$Window(window));
			},
			state.fn);
	});
var $elm$core$Basics$compare = _Utils_compare;
var $elm$core$Dict$get = F2(
	function (targetKey, dict) {
		get:
		while (true) {
			if (dict.$ === -2) {
				return $elm$core$Maybe$Nothing;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var _v1 = A2($elm$core$Basics$compare, targetKey, key);
				switch (_v1) {
					case 0:
						var $temp$targetKey = targetKey,
							$temp$dict = left;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
					case 1:
						return $elm$core$Maybe$Just(value);
					default:
						var $temp$targetKey = targetKey,
							$temp$dict = right;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
				}
			}
		}
	});
var $author$project$ActionProjection$rootOf = F2(
	function (identity, _v0) {
		var cache = _v0.d;
		return A2(
			$elm$core$Dict$get,
			$author$project$UInt64$string(identity),
			cache);
	});
var $author$project$Menu$snapshot = function (_v0) {
	var state = _v0;
	return {
		aA: state.aA,
		d2: $elm$core$List$length(state.aT),
		cf: state.cf,
		aC: state.aC,
		fn: $elm$core$List$length(state.fn),
		bE: $elm$core$List$length(state.bE),
		ew: $elm$core$List$length(state.a_)
	};
};
var $author$project$Menu$WindowId = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$Menu$windowId = $author$project$Menu$WindowId;
var $author$project$ActionProjection$windows = function (_v0) {
	var rows = _v0.c;
	return rows;
};
var $author$project$MenuBridge$blockedFor = F3(
	function (incarnation, shell, _v0) {
		var state = _v0;
		var root = A2(
			$elm$core$Maybe$andThen,
			function (observed) {
				return A2($author$project$ActionProjection$rootOf, incarnation, observed.eA);
			},
			shell.V.av);
		var nativeBlocked = function () {
			var _v2 = _Utils_Tuple3(shell.c3, shell.V.av, root);
			if (((!_v2.a.$) && (!_v2.b.$)) && (!_v2.c.$)) {
				var observed = _v2.b.a;
				var family = _v2.c.a;
				return A2(
					$elm$core$List$any,
					function (window) {
						return A3($author$project$Effects$blocked, observed.R.fe, window.au, shell.V);
					},
					A2(
						$elm$core$List$filter,
						function (window) {
							return _Utils_eq(
								A2($author$project$ActionProjection$rootOf, window.au, observed.eA),
								$elm$core$Maybe$Just(family));
						},
						$author$project$ActionProjection$windows(observed.eA)));
			} else {
				return A2(
					$elm$core$List$any,
					function (transaction) {
						return A2(
							$elm$core$List$member,
							transaction.O,
							_List_fromArray(
								[0, 4]));
					},
					shell.V.fM);
			}
		}();
		var blocked = function () {
			var _v1 = _Utils_Tuple2(shell.c3, root);
			if ((!_v1.a.$) && (!_v1.b.$)) {
				var _native = _v1.a.a;
				var family = _v1.b.a;
				return A2(
					$author$project$Menu$hasOutstandingFor,
					A2(
						$author$project$Menu$windowId,
						$author$project$Binding$authorityIdentity(_native),
						$author$project$UInt64$string(family)),
					state.aC);
			} else {
				return $author$project$Menu$snapshot(state.aC).fn > 0;
			}
		}();
		return blocked || nativeBlocked;
	});
var $author$project$Surface$familyBlocked = F2(
	function (model, incarnation) {
		return A3($author$project$MenuBridge$blockedFor, incarnation, model.a.b, model.a.i);
	});
var $elm$core$List$maybeCons = F3(
	function (f, mx, xs) {
		var _v0 = f(mx);
		if (!_v0.$) {
			var x = _v0.a;
			return A2($elm$core$List$cons, x, xs);
		} else {
			return xs;
		}
	});
var $elm$core$List$filterMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			$elm$core$List$maybeCons(f),
			_List_Nil,
			xs);
	});
var $elm$core$List$all = F2(
	function (isOkay, list) {
		return !A2(
			$elm$core$List$any,
			A2($elm$core$Basics$composeL, $elm$core$Basics$not, isOkay),
			list);
	});
var $author$project$UInt64$compare = F2(
	function (_v0, _v1) {
		var left = _v0;
		var right = _v1;
		var _v2 = A2(
			$elm$core$Basics$compare,
			$elm$core$String$length(left),
			$elm$core$String$length(right));
		if (_v2 === 1) {
			return A2($elm$core$Basics$compare, left, right);
		} else {
			var order = _v2;
			return order;
		}
	});
var $author$project$ActionProjection$focused = function (_v0) {
	var focus = _v0.b;
	return focus;
};
var $elm$core$List$sortWith = _List_sortWith;
var $author$project$Taskbar$groups = function (projection) {
	var rows = $author$project$ActionProjection$windows(projection);
	var add = F2(
		function (_v0, accumulated) {
			var key = _v0.a;
			var entry = _v0.b;
			return A2(
				$elm$core$List$any,
				function (g) {
					return _Utils_eq(g.aV, key);
				},
				accumulated) ? A2(
				$elm$core$List$map,
				function (g) {
					return _Utils_eq(g.aV, key) ? _Utils_update(
						g,
						{
							aB: _Utils_ap(
								g.aB,
								_List_fromArray(
									[entry]))
						}) : g;
				},
				accumulated) : _Utils_ap(
				accumulated,
				_List_fromArray(
					[
						{
						aB: _List_fromArray(
							[entry]),
						aV: key
					}
					]));
		});
	var activeRoot = A2(
		$elm$core$Maybe$andThen,
		function (id) {
			return A2($author$project$ActionProjection$rootOf, id, projection);
		},
		$author$project$ActionProjection$focused(projection));
	var family = function (root) {
		var members = A2(
			$elm$core$List$filter,
			function (w) {
				return _Utils_eq(
					A2($author$project$ActionProjection$rootOf, w.au, projection),
					$elm$core$Maybe$Just(root.au));
			},
			rows);
		var key = $elm$core$String$isEmpty(root.c0) ? ('window:' + $author$project$UInt64$string(root.au)) : ('application:' + root.c0);
		return _Utils_Tuple2(
			key,
			{
				dC: _Utils_eq(
					activeRoot,
					$elm$core$Maybe$Just(root.au)),
				c0: root.c0,
				dF: A2(
					$elm$core$List$any,
					function ($) {
						return $.dF;
					},
					members),
				c2: A2(
					$elm$core$List$all,
					function ($) {
						return $.c2;
					},
					members),
				d6: root.d6,
				bR: root.bR,
				n: root.au
			});
	};
	return A3(
		$elm$core$List$foldl,
		add,
		_List_Nil,
		A2(
			$elm$core$List$map,
			family,
			A2(
				$elm$core$List$sortWith,
				F2(
					function (a, b) {
						return A2($author$project$UInt64$compare, a.au, b.au);
					}),
				A2(
					$elm$core$List$filter,
					function (w) {
						return _Utils_eq(w.dm, $elm$core$Maybe$Nothing);
					},
					rows))));
};
var $author$project$TaskbarShell$groups = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				function ($) {
					return $.eA;
				},
				$author$project$Taskbar$groups),
			model.b.V.av));
};
var $author$project$Catalog$id = function (_v0) {
	var value = _v0;
	return value;
};
var $author$project$Notifications$verbName = function (verb) {
	if (!verb) {
		return 'invoke';
	} else {
		return 'dismiss';
	}
};
var $author$project$Notifications$identity = function (value) {
	return 'notification:' + ($author$project$UInt64$string(value.cS) + (':' + ($author$project$UInt64$string(value.au) + (':' + ($author$project$Notifications$verbName(value.b2) + (':' + value.eV))))));
};
var $author$project$Snap$identity = function (region) {
	switch (region) {
		case 0:
			return 'left-half';
		case 1:
			return 'right-half';
		case 2:
			return 'top-left';
		case 3:
			return 'top-right';
		case 4:
			return 'bottom-left';
		default:
			return 'bottom-right';
	}
};
var $author$project$Provider$incarnation = function (_v0) {
	var value = _v0;
	return value.au;
};
var $author$project$Files$intent = F2(
	function (snapshot, target) {
		return {cN: snapshot.cN, cS: snapshot.cS, fK: target};
	});
var $author$project$JumpList$intent = F2(
	function (snapshot, action) {
		return {eV: action, dQ: snapshot.dQ, cN: snapshot.cN, cS: snapshot.cS};
	});
var $author$project$SystemMenu$intent = F3(
	function (snapshot, operation, value) {
		return {bc: operation, cN: snapshot.cN, cS: snapshot.cS, ab: value};
	});
var $elm$core$List$isEmpty = function (xs) {
	if (!xs.b) {
		return true;
	} else {
		return false;
	}
};
var $author$project$Binding$encode = function (_v0) {
	var lifetime = _v0.a;
	var session = _v0.b;
	var frontend = _v0.c;
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(lifetime))),
				_Utils_Tuple2(
				'session',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(session))),
				_Utils_Tuple2(
				'frontend',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(frontend)))
			]));
};
var $author$project$Desktop$host = function (binding) {
	return A2(
		$elm$json$Json$Encode$encode,
		0,
		$author$project$Binding$encode(binding));
};
var $author$project$Desktop$key = F2(
	function (model, suffix) {
		return 'applications:' + (A2(
			$elm$core$Maybe$withDefault,
			'detached',
			A2($elm$core$Maybe$map, $author$project$Desktop$host, model.a.b.c3)) + (':' + (A2(
			$elm$core$Maybe$withDefault,
			'exhausted',
			A2($elm$core$Maybe$map, $author$project$UInt64$string, model.aF)) + (':' + suffix))));
	});
var $author$project$MotionPreferences$label = function (override) {
	switch (override) {
		case 0:
			return 'Follow system';
		case 1:
			return 'Reduced motion';
		default:
			return 'Full motion';
	}
};
var $author$project$ShortcutPreferences$label = function (route) {
	switch (route) {
		case 'applications':
			return 'Apps menu';
		case 'system':
			return 'System menu';
		default:
			return 'Notification history';
	}
};
var $author$project$Notifications$live = F2(
	function (choice, model) {
		var _v0 = model.c;
		if (_v0.$ === 1) {
			return false;
		} else {
			var current = _v0.a;
			return current.c2 && (_Utils_eq(current.cS, choice.cS) && ((!A2($elm$core$List$member, choice, model.b1)) && A2(
				$elm$core$List$any,
				function (row) {
					return _Utils_eq(row.cc, choice.cc) && (_Utils_eq(row.au, choice.au) && (_Utils_eq(row.ag, choice.ag) && ((!row.cX) && (((choice.b2 === 1) && (choice.eV === '')) || ((!choice.b2) && A2(
						$elm$core$List$any,
						function (action) {
							return _Utils_eq(action.aV, choice.eV);
						},
						row.cv))))));
				},
				current.ak)));
		}
	});
var $author$project$Catalog$lookup = F2(
	function (value, _v0) {
		var values = _v0.c;
		return A2($elm$core$Dict$get, value, values);
	});
var $elm$core$Dict$values = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, valueList) {
				return A2($elm$core$List$cons, value, valueList);
			}),
		_List_Nil,
		dict);
};
var $author$project$Catalog$entries = function (_v0) {
	var values = _v0.c;
	return $elm$core$Dict$values(values);
};
var $author$project$Desktop$pinGroups = F2(
	function (identity, model) {
		var _v0 = A2(
			$elm$core$Maybe$andThen,
			$author$project$Catalog$lookup(identity),
			model.aj);
		if (_v0.$ === 1) {
			return _List_Nil;
		} else {
			var entry = _v0.a;
			return A2(
				$elm$core$List$filter,
				function (group) {
					return A2(
						$elm$core$List$any,
						function (family) {
							return _Utils_eq(family.c0, identity) || ((!$elm$core$String$isEmpty(entry.fP)) && _Utils_eq(family.c0, entry.fP));
						},
						group.aB);
				},
				$author$project$TaskbarShell$groups(model.a));
		}
	});
var $author$project$Desktop$menuApplication = function (model) {
	return A2(
		$elm$core$Maybe$andThen,
		function (provider) {
			return function (matches) {
				if (matches.b && (!matches.b.b)) {
					var entry = matches.a;
					return $elm$core$Maybe$Just(entry);
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}(
				A2(
					$elm$core$List$filter,
					function (entry) {
						return A2(
							$elm$core$List$any,
							function (group) {
								return A2(
									$elm$core$List$any,
									function (family) {
										return _Utils_eq(
											family.n,
											$author$project$Provider$incarnation(provider));
									},
									group.aB);
							},
							A2(
								$author$project$Desktop$pinGroups,
								$author$project$Catalog$id(entry.cG),
								model));
					},
					A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						A2($elm$core$Maybe$map, $author$project$Catalog$entries, model.aj))));
		},
		$author$project$MenuBridge$currentProvider(model.a.i));
};
var $author$project$Surface$menuBlocked = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				$author$project$Provider$incarnation,
				$author$project$Surface$familyBlocked(model)),
			$author$project$MenuBridge$currentProvider(model.a.i)));
};
var $author$project$Menu$menuNumber = function (_v0) {
	var number = _v0;
	return number;
};
var $author$project$MenuBridge$menuSnapshot = function (_v0) {
	var state = _v0;
	return $author$project$Menu$snapshot(state.aC);
};
var $elm$core$Basics$min = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) < 0) ? x : y;
	});
var $author$project$Switcher$Waiting = 1;
var $author$project$Switcher$phase = function (_v0) {
	var model = _v0;
	return model.m;
};
var $author$project$Desktop$switcherOpen = function (model) {
	return A2(
		$elm$core$List$member,
		$author$project$Switcher$phase(model.j),
		_List_fromArray(
			[1, 2]));
};
var $author$project$Surface$mode = function (model) {
	return (!_Utils_eq(model.o, $elm$core$Maybe$Nothing)) ? 'jump' : (model.s ? 'files' : (model.x ? 'system' : (model.v ? 'notifications' : (model.p ? 'settings' : ((!_Utils_eq(model.w, $elm$core$Maybe$Nothing)) ? 'snap' : ($author$project$Desktop$switcherOpen(model) ? 'switcher' : (model.l ? 'overview' : (model.q ? 'applications' : ((!_Utils_eq(
		$author$project$MenuBridge$menuSnapshot(model.a.i).aC,
		$elm$core$Maybe$Nothing)) ? 'menu' : ((!_Utils_eq(model.a.G, $elm$core$Maybe$Nothing)) ? 'picker' : 'closed'))))))))));
};
var $author$project$ShortcutPreferences$name = function (value) {
	switch (value) {
		case 0:
			return 'undecided';
		case 1:
			return 'keep';
		case 2:
			return 'default';
		default:
			return 'alternate';
	}
};
var $author$project$Snap$name = function (region) {
	switch (region) {
		case 0:
			return 'Left half';
		case 1:
			return 'Right half';
		case 2:
			return 'Top left quarter';
		case 3:
			return 'Top right quarter';
		case 4:
			return 'Bottom left quarter';
		default:
			return 'Bottom right quarter';
	}
};
var $author$project$SystemMenu$name = function (operation) {
	switch (operation) {
		case 0:
			return 'Volume';
		case 1:
			return 'Mute';
		case 2:
			return 'Network';
		case 3:
			return 'Suspend';
		case 4:
			return 'Restart';
		case 5:
			return 'Shut down';
		case 6:
			return 'Lock session';
		default:
			return 'Log out';
	}
};
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $author$project$Desktop$NewInstance = F2(
	function (a, b) {
		return {$: 71, a: a, b: b};
	});
var $author$project$MenuBridge$preparedSnapshot = function (_v0) {
	var state = _v0;
	return A2(
		$elm$core$Maybe$map,
		function (slot) {
			return {bs: slot.bs, a8: slot.a8, bv: slot.bv, bb: slot.bb, bj: slot.bj};
		},
		state.Q);
};
var $author$project$Launch$Selection = F5(
	function (a, b, c, d, e) {
		return {$: 0, a: a, b: b, c: c, d: d, e: e};
	});
var $author$project$Launch$identityFunction = function (value) {
	return value;
};
var $elm$core$Maybe$map2 = F3(
	function (func, ma, mb) {
		if (ma.$ === 1) {
			return $elm$core$Maybe$Nothing;
		} else {
			var a = ma.a;
			if (mb.$ === 1) {
				return $elm$core$Maybe$Nothing;
			} else {
				var b = mb.a;
				return $elm$core$Maybe$Just(
					A2(func, a, b));
			}
		}
	});
var $author$project$Catalog$scope = function (_v0) {
	var lifetime = _v0.a;
	var generation = _v0.b;
	return {e7: generation, fe: lifetime};
};
var $author$project$Launch$select = F2(
	function (identity, _v0) {
		var model = _v0;
		return A2(
			$elm$core$Maybe$andThen,
			$author$project$Launch$identityFunction,
			A3(
				$elm$core$Maybe$map2,
				F2(
					function (host, snapshot) {
						return A2(
							$elm$core$Maybe$map,
							function (entry) {
								var scope = $author$project$Catalog$scope(snapshot);
								return A5($author$project$Launch$Selection, host, model.cN, scope.fe, scope.e7, entry.cG);
							},
							A2($author$project$Catalog$lookup, identity, snapshot));
					}),
				model.a9,
				model.c));
	});
var $author$project$Launch$status = function (_v0) {
	var model = _v0;
	var _v1 = model.m;
	switch (_v1.$) {
		case 0:
			return 'Idle';
		case 1:
			return 'Pending';
		default:
			switch (_v1.b) {
				case 0:
					var _v2 = _v1.b;
					return 'Submitted';
				case 1:
					var _v3 = _v1.b;
					return 'Refused';
				default:
					var _v4 = _v1.b;
					return 'Unknown';
			}
	}
};
var $author$project$Desktop$newInstanceAvailable = F2(
	function (identity, model) {
		var windowEntry = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (entry) {
					return _Utils_eq(
						$author$project$Catalog$id(entry.cG),
						identity);
				},
				$author$project$Desktop$menuApplication(model)));
		var windowBlocked = A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (provider) {
					return A3(
						$author$project$MenuBridge$blockedFor,
						$author$project$Provider$incarnation(provider),
						model.a.b,
						model.a.i);
				},
				$author$project$MenuBridge$currentProvider(model.a.i)));
		var menuReady = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (menu) {
					return _Utils_eq(menu.O, $author$project$Menu$Ready);
				},
				$author$project$MenuBridge$menuSnapshot(model.a.i).aC));
		var originReady = (!_Utils_eq(model.o, $elm$core$Maybe$Nothing)) ? (_Utils_eq(
			model.o,
			$elm$core$Maybe$Just(identity)) && _Utils_eq(model.al.dn, $elm$core$Maybe$Nothing)) : (menuReady && (windowEntry && (!windowBlocked)));
		return $author$project$Shell$available(model.a.b) && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && ((!model.bx) && (_Utils_eq(
			$author$project$MenuBridge$preparedSnapshot(model.a.i),
			$elm$core$Maybe$Nothing) && ((!_Utils_eq(
			A2(
				$elm$core$Maybe$andThen,
				$author$project$Catalog$lookup(identity),
				model.aj),
			$elm$core$Maybe$Nothing)) && ((!A2(
			$elm$core$List$member,
			$author$project$Launch$status(model.B),
			_List_fromArray(
				['Pending', 'Unknown']))) && ((!_Utils_eq(
			A2($author$project$Launch$select, identity, model.B),
			$elm$core$Maybe$Nothing)) && originReady))))));
	});
var $author$project$Surface$newInstanceControl = F3(
	function (model, domId, entry) {
		var identity = $author$project$Catalog$id(entry.cG);
		var enabled = A2($author$project$Desktop$newInstanceAvailable, identity, model);
		var detail = function () {
			var _v0 = $author$project$Launch$status(model.B);
			switch (_v0) {
				case 'Pending':
					return 'Waiting for launch confirmation';
				case 'Unknown':
					return 'Previous launch is not confirmed; recover its status first';
				default:
					return entry.dj;
			}
		}();
		return {
			f: 'Open new instance of ' + entry.dj,
			g: detail,
			h: domId,
			b9: enabled,
			cc: 'control:new-instance:' + identity,
			d6: 'New instance',
			d: enabled ? A2(
				$elm$core$Maybe$map,
				function (stamp) {
					return A2($author$project$Desktop$NewInstance, stamp, identity);
				},
				$author$project$Desktop$capture(model)) : $elm$core$Maybe$Nothing
		};
	});
var $author$project$Motion$Reduced = 0;
var $author$project$Motion$Full = 1;
var $author$project$Motion$desired = function (model) {
	var _v0 = model.aY.c;
	if (_v0.$ === 1) {
		return 0;
	} else {
		var preference = _v0.a;
		var _v1 = preference.fo;
		switch (_v1) {
			case 1:
				return 0;
			case 2:
				return 1;
			default:
				return A2(
					$elm$core$Maybe$withDefault,
					0,
					A2(
						$elm$core$Maybe$map,
						function ($) {
							return $.aG;
						},
						model.bw));
		}
	}
};
var $author$project$MotionPreferences$selected = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		0,
		A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.fo;
			},
			model.c));
};
var $author$project$Motion$notice = function (model) {
	return _Utils_eq(model.aY.c, $elm$core$Maybe$Nothing) ? model.aY.fj : ((!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? 'Applying motion preference…' : (((!$author$project$Motion$desired(model)) ? 'Reduced motion: instant transitions' : 'Full motion') + (' · ' + $author$project$MotionPreferences$label(
		$author$project$MotionPreferences$selected(model.aY)))));
};
var $author$project$Snap$LeftHalf = 0;
var $author$project$GeometryProjection$Ordinary = 0;
var $author$project$Snap$proposal = function (choice) {
	return A2(
		$elm$core$Maybe$andThen,
		function (window) {
			var _v0 = _Utils_Tuple2(
				_Utils_Tuple2(window.b4, window.bS),
				_Utils_Tuple3(window.bd, window.ct, window.b5));
			if ((((((((((!_v0.a.a.$) && _v0.a.a.a.b) && _v0.a.a.a.b.b) && _v0.a.a.a.b.b.b) && _v0.a.a.a.b.b.b.b) && (!_v0.a.a.a.b.b.b.b.b)) && (!_v0.a.b.$)) && (!_v0.b.a.$)) && (!_v0.b.b.$)) && (!_v0.b.c.$)) {
				var _v1 = _v0.a;
				var _v2 = _v1.a.a;
				var x = _v2.a;
				var _v3 = _v2.b;
				var y = _v3.a;
				var _v4 = _v3.b;
				var width = _v4.a;
				var _v5 = _v4.b;
				var height = _v5.a;
				var monitor = _v1.b.a;
				var _v6 = _v0.b;
				var output = _v6.a.a;
				var area = _v6.b.a;
				var workspace = _v6.c.a;
				var quarter = height / 2;
				var half = width / 2;
				var geometry = function () {
					var _v7 = choice.bG;
					switch (_v7) {
						case 0:
							return _List_fromArray(
								[x, y, half, height]);
						case 1:
							return _List_fromArray(
								[x + half, y, width - half, height]);
						case 2:
							return _List_fromArray(
								[x, y, half, quarter]);
						case 3:
							return _List_fromArray(
								[x + half, y, width - half, quarter]);
						case 4:
							return _List_fromArray(
								[x, y + quarter, half, height - quarter]);
						default:
							return _List_fromArray(
								[x + half, y + quarter, width - half, height - quarter]);
					}
				}();
				return $elm$core$Maybe$Just(
					{R: choice.c.R, ac: geometry, bS: monitor, bd: output, b_: choice.bG, ct: area, b5: workspace});
			} else {
				return $elm$core$Maybe$Nothing;
			}
		},
		A2($author$project$GeometryProjection$window, choice.fK, choice.c));
};
var $author$project$Snap$open = F2(
	function (snapshot, target) {
		return A2(
			$elm$core$Maybe$andThen,
			function (window) {
				var choice = {bG: 0, c: snapshot, fK: target};
				return (snapshot.eZ || ((!window.da) || (window.bR || ((!(!window.ec)) || ((!(!window.b8)) || _Utils_eq(
					$author$project$Snap$proposal(choice),
					$elm$core$Maybe$Nothing)))))) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(choice);
			},
			A2($author$project$GeometryProjection$window, target, snapshot));
	});
var $author$project$GeometryProjection$CanTransferWorkspace = 3;
var $author$project$WorkspaceInventory$coherent = F2(
	function (inventory, geometry) {
		return _Utils_eq(inventory.c3, geometry.c3) && (_Utils_eq(inventory.cM, geometry.cM) && (_Utils_eq(inventory.eC, geometry.eC) && (_Utils_eq(inventory.cN, geometry.R.cN) && (_Utils_eq(inventory.z, geometry.R.z) && A2(
			$elm$core$List$all,
			function (window) {
				var _v0 = window.dB;
				if (!_v0.$) {
					var workspace = _v0.a;
					return (A2($elm$core$String$startsWith, '-', workspace) || (workspace === '0')) ? true : A2(
						$elm$core$List$any,
						function (row) {
							return _Utils_eq(row.cG, workspace) && (_Utils_eq(
								$elm$core$Maybe$Just(row.e7),
								window.b5) && (_Utils_eq(
								$elm$core$Maybe$Just(row.bS),
								window.bS) && _Utils_eq(
								$elm$core$Maybe$Just(row.bd),
								window.bd)));
						},
						inventory.ez);
				} else {
					return true;
				}
			},
			geometry.a)))));
	});
var $author$project$TaskView$membership = F3(
	function (root, shell, geometry) {
		var pending = $elm$core$List$head(
			A2(
				$elm$core$List$filter,
				function (t) {
					return _Utils_eq(t.af.au, root) && (_Utils_eq(t.af.R.fe, geometry.R.fe) && A2(
						$elm$core$List$member,
						t.O,
						_List_fromArray(
							[0, 4])));
				},
				shell.V.fM));
		var _v0 = A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				function ($) {
					return $.af;
				},
				function ($) {
					return $.bc;
				}),
			pending);
		if ((!_v0.$) && (_v0.a.$ === 7)) {
			var p = _v0.a.a;
			return $elm$core$Maybe$Just(p.cm);
		} else {
			return A2(
				$elm$core$Maybe$andThen,
				function ($) {
					return $.dB;
				},
				A2($author$project$GeometryProjection$window, root, geometry));
		}
	});
var $author$project$TaskView$groups = function (shell) {
	var _v0 = _Utils_Tuple2(shell.V.av, shell.ac);
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var observed = _v0.a.a;
		var geometry = _v0.b.a;
		var rows = $author$project$ActionProjection$windows(observed.eA);
		var positive = function (workspace) {
			return (!$elm$core$String$isEmpty(workspace)) && ((!A2($elm$core$String$startsWith, '-', workspace)) && (workspace !== '0'));
		};
		var matching = function (row) {
			return A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (g) {
						return _Utils_eq(g.dm, row.dm) && _Utils_eq(g.bR, row.bR);
					},
					A2($author$project$GeometryProjection$window, row.au, geometry)));
		};
		var sameAuthority = _Utils_eq(
			shell.c3,
			$elm$core$Maybe$Just(geometry.c3)) && (_Utils_eq(observed.R.fe, geometry.R.fe) && (_Utils_eq(observed.R.e4, geometry.R.e4) && (_Utils_eq(observed.R.z, geometry.R.z) && (_Utils_eq(
			$author$project$ActionProjection$focused(observed.eA),
			geometry.ca) && (_Utils_eq(
			$elm$core$List$length(rows),
			$elm$core$List$length(geometry.a)) && A2($elm$core$List$all, matching, rows))))));
		var focusedWorkspace = A2(
			$elm$core$Maybe$andThen,
			function ($) {
				return $.dB;
			},
			A2(
				$elm$core$Maybe$andThen,
				function (identity) {
					return A2($author$project$GeometryProjection$window, identity, geometry);
				},
				$author$project$ActionProjection$focused(observed.eA)));
		var families = A2(
			$elm$core$List$concatMap,
			function ($) {
				return $.aB;
			},
			$author$project$Taskbar$groups(observed.eA));
		var add = F2(
			function (family, accumulated) {
				var _v1 = A3($author$project$TaskView$membership, family.n, shell, geometry);
				if (!_v1.$) {
					var workspace = _v1.a;
					return (!positive(workspace)) ? accumulated : (A2(
						$elm$core$List$any,
						function (g) {
							return _Utils_eq(g.cG, workspace);
						},
						accumulated) ? A2(
						$elm$core$List$map,
						function (g) {
							return _Utils_eq(g.cG, workspace) ? _Utils_update(
								g,
								{
									a: _Utils_ap(
										g.a,
										_List_fromArray(
											[family]))
								}) : g;
						},
						accumulated) : _Utils_ap(
						accumulated,
						_List_fromArray(
							[
								{
								dC: _Utils_eq(
									focusedWorkspace,
									$elm$core$Maybe$Just(workspace)),
								cG: workspace,
								a: _List_fromArray(
									[family])
							}
							])));
				} else {
					return accumulated;
				}
			});
		return (!sameAuthority) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
			A2(
				$elm$core$List$sortWith,
				F2(
					function (a, b) {
						return A2(
							$elm$core$Basics$compare,
							_Utils_Tuple2(
								$elm$core$String$length(a.cG),
								a.cG),
							_Utils_Tuple2(
								$elm$core$String$length(b.cG),
								b.cG));
					}),
				A3($elm$core$List$foldl, add, _List_Nil, families)));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$TaskView$groupsWith = F2(
	function (inventory, shell) {
		if (inventory.$ === 1) {
			return $author$project$TaskView$groups(shell);
		} else {
			var snapshot = inventory.a;
			var _v1 = _Utils_Tuple2(
				$author$project$TaskView$groups(shell),
				shell.ac);
			if ((!_v1.a.$) && (!_v1.b.$)) {
				var populated = _v1.a.a;
				var geometry = _v1.b.a;
				if (!A2($author$project$WorkspaceInventory$coherent, snapshot, geometry)) {
					return $elm$core$Maybe$Nothing;
				} else {
					var retained = A2(
						$elm$core$List$map,
						function (group) {
							return _Utils_update(
								group,
								{dC: false});
						},
						A2(
							$elm$core$List$filter,
							function (group) {
								return !A2(
									$elm$core$List$any,
									function (row) {
										return _Utils_eq(row.cG, group.cG);
									},
									snapshot.ez);
							},
							populated));
					var current = A2(
						$elm$core$List$map,
						function (row) {
							return {
								dC: _Utils_eq(
									snapshot.dC,
									$elm$core$Maybe$Just(row.cG)),
								cG: row.cG,
								a: A2(
									$elm$core$List$concatMap,
									function ($) {
										return $.a;
									},
									A2(
										$elm$core$List$filter,
										function (group) {
											return _Utils_eq(group.cG, row.cG);
										},
										populated))
							};
						},
						snapshot.ez);
					return $elm$core$Maybe$Just(
						A2(
							$elm$core$List$sortWith,
							F2(
								function (a, b) {
									return A2(
										$elm$core$Basics$compare,
										_Utils_Tuple2(
											$elm$core$String$length(a.cG),
											a.cG),
										_Utils_Tuple2(
											$elm$core$String$length(b.cG),
											b.cG));
								}),
							_Utils_ap(current, retained)));
				}
			} else {
				return $elm$core$Maybe$Nothing;
			}
		}
	});
var $author$project$Desktop$taskViewGroups = function (model) {
	return A2($author$project$TaskView$groupsWith, model.b6, model.a.b);
};
var $author$project$Desktop$overviewTransferAvailable = F2(
	function (model, root) {
		return model.l && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && ($author$project$Shell$available(model.a.b) && ((!$author$project$WorkspaceNavigation$blocked(model.J)) && ((!A3($author$project$MenuBridge$blockedFor, root, model.a.b, model.a.i)) && (A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (caps) {
					return A2($elm$core$List$member, 3, caps.ef);
				},
				model.a.b.dc)) && A2(
			$elm$core$List$any,
			function (family) {
				return _Utils_eq(family.n, root) && family.c2;
			},
			A2(
				$elm$core$List$concatMap,
				function ($) {
					return $.a;
				},
				A2(
					$elm$core$List$filter,
					function (group) {
						return _Utils_eq(model.T, $elm$core$Maybe$Nothing) || _Utils_eq(
							model.T,
							$elm$core$Maybe$Just(group.cG));
					},
					A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						$author$project$Desktop$taskViewGroups(model))))))))));
	});
var $author$project$Desktop$pinIdentities = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.fa;
			},
			model.H.c));
};
var $author$project$SystemMenu$powerCapabilityLabel = function (capability) {
	switch (capability) {
		case 0:
			return 'available';
		case 3:
			return 'authorization required';
		default:
			return 'unavailable';
	}
};
var $author$project$Transfer$propose = F3(
	function (snapshot, root, destination) {
		return A2(
			$elm$core$Maybe$andThen,
			function (w) {
				var _v0 = _Utils_Tuple2(w.dB, w.b5);
				if ((!_v0.a.$) && (!_v0.b.$)) {
					var source = _v0.a.a;
					var generation = _v0.b.a;
					return (snapshot.eZ || ((!_Utils_eq(w.dm, $elm$core$Maybe$Nothing)) || (w.bt || ((!($author$project$Transfer$ordinary(source) && $author$project$Transfer$ordinary(destination))) || _Utils_eq(source, destination))))) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
						{bp: destination, cm: source, cV: generation});
				} else {
					return $elm$core$Maybe$Nothing;
				}
			},
			A2($author$project$GeometryProjection$window, root, snapshot));
	});
var $author$project$ShortcutPreferences$allowed = F2(
	function (selected, observed) {
		switch (selected) {
			case 1:
				return true;
			case 2:
				return observed.c8;
			case 3:
				return observed.c$;
			default:
				return false;
		}
	});
var $author$project$ShortcutPreferences$writable = function (model) {
	return (!_Utils_eq(model.c, $elm$core$Maybe$Nothing)) && ((!_Utils_eq(model.cH, $elm$core$Maybe$Nothing)) && _Utils_eq(model.dn, $elm$core$Maybe$Nothing));
};
var $author$project$ShortcutPreferences$ready = function (model) {
	return $author$project$ShortcutPreferences$writable(model) && ($elm$core$List$isEmpty(model.ay) && A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (inventory) {
				return A2(
					$elm$core$List$all,
					function (route) {
						return A2(
							$author$project$ShortcutPreferences$allowed,
							A2($author$project$ShortcutPreferences$choices, route, model.e2),
							A2($author$project$ShortcutPreferences$row, route, inventory));
					},
					_List_fromArray(
						['applications', 'system', 'notifications']));
			},
			model.cH)));
};
var $author$project$Shell$Detached = 0;
var $author$project$Shell$Exhausted = 3;
var $author$project$TaskbarShell$Native = function (a) {
	return {$: 0, a: a};
};
var $author$project$Shell$Refresh = {$: 4};
var $author$project$Surface$recoveryControl = F2(
	function (identity, model) {
		return {
			f: 'Refresh window status; read observations without retrying actions',
			g: 'Observation only',
			h: A2($author$project$Desktop$key, model, identity),
			b9: (!(!model.a.b.m)) && ((model.a.b.m !== 3) && (!$author$project$Effects$pending(model.a.b.V))),
			cc: identity,
			d6: 'Refresh window status',
			d: $elm$core$Maybe$Just(
				$author$project$Desktop$Window(
					$author$project$TaskbarShell$Native($author$project$Shell$Refresh)))
		};
	});
var $author$project$Effects$Refused = 2;
var $author$project$Surface$recoveryNeeded = function (model) {
	return A2(
		$elm$core$List$any,
		function (transaction) {
			return A2(
				$elm$core$List$member,
				transaction.O,
				_List_fromArray(
					[0, 4]));
		},
		model.a.b.V.fM) || (A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (transaction) {
				return A2(
					$elm$core$List$member,
					transaction.O,
					_List_fromArray(
						[2, 4]));
			},
			model.a.b.V.dz)) || ($author$project$MenuBridge$menuSnapshot(model.a.i).fn > 0));
};
var $author$project$Surface$recoveryPopup = function (model) {
	return $author$project$Surface$recoveryNeeded(model) ? _List_fromArray(
		[
			A2($author$project$Surface$recoveryControl, 'control:recovery-refresh', model)
		]) : _List_Nil;
};
var $author$project$Snap$BottomLeft = 4;
var $author$project$Snap$BottomRight = 5;
var $author$project$Snap$RightHalf = 1;
var $author$project$Snap$TopLeft = 2;
var $author$project$Snap$TopRight = 3;
var $author$project$Snap$regions = _List_fromArray(
	[0, 1, 2, 3, 4, 5]);
var $elm$core$String$concat = function (strings) {
	return A2($elm$core$String$join, '', strings);
};
var $elm$core$Dict$RBEmpty_elm_builtin = {$: -2};
var $elm$core$Dict$empty = $elm$core$Dict$RBEmpty_elm_builtin;
var $elm$core$Dict$Black = 1;
var $elm$core$Dict$RBNode_elm_builtin = F5(
	function (a, b, c, d, e) {
		return {$: -1, a: a, b: b, c: c, d: d, e: e};
	});
var $elm$core$Dict$Red = 0;
var $elm$core$Dict$balance = F5(
	function (color, key, value, left, right) {
		if ((right.$ === -1) && (!right.a)) {
			var _v1 = right.a;
			var rK = right.b;
			var rV = right.c;
			var rLeft = right.d;
			var rRight = right.e;
			if ((left.$ === -1) && (!left.a)) {
				var _v3 = left.a;
				var lK = left.b;
				var lV = left.c;
				var lLeft = left.d;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					key,
					value,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					rK,
					rV,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, left, rLeft),
					rRight);
			}
		} else {
			if ((((left.$ === -1) && (!left.a)) && (left.d.$ === -1)) && (!left.d.a)) {
				var _v5 = left.a;
				var lK = left.b;
				var lV = left.c;
				var _v6 = left.d;
				var _v7 = _v6.a;
				var llK = _v6.b;
				var llV = _v6.c;
				var llLeft = _v6.d;
				var llRight = _v6.e;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					lK,
					lV,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, llK, llV, llLeft, llRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, key, value, lRight, right));
			} else {
				return A5($elm$core$Dict$RBNode_elm_builtin, color, key, value, left, right);
			}
		}
	});
var $elm$core$Dict$insertHelp = F3(
	function (key, value, dict) {
		if (dict.$ === -2) {
			return A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, $elm$core$Dict$RBEmpty_elm_builtin, $elm$core$Dict$RBEmpty_elm_builtin);
		} else {
			var nColor = dict.a;
			var nKey = dict.b;
			var nValue = dict.c;
			var nLeft = dict.d;
			var nRight = dict.e;
			var _v1 = A2($elm$core$Basics$compare, key, nKey);
			switch (_v1) {
				case 0:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						A3($elm$core$Dict$insertHelp, key, value, nLeft),
						nRight);
				case 1:
					return A5($elm$core$Dict$RBNode_elm_builtin, nColor, nKey, value, nLeft, nRight);
				default:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						nLeft,
						A3($elm$core$Dict$insertHelp, key, value, nRight));
			}
		}
	});
var $elm$core$Dict$insert = F3(
	function (key, value, dict) {
		var _v0 = A3($elm$core$Dict$insertHelp, key, value, dict);
		if ((_v0.$ === -1) && (!_v0.a)) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, 1, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Dict$fromList = function (assocs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, dict) {
				var key = _v0.a;
				var value = _v0.b;
				return A3($elm$core$Dict$insert, key, value, dict);
			}),
		$elm$core$Dict$empty,
		assocs);
};
var $author$project$SearchFold$exceptions = $elm$core$Dict$fromList(
	_List_fromArray(
		[
			_Utils_Tuple2('µ', 'μ'),
			_Utils_Tuple2('ß', 'ss'),
			_Utils_Tuple2('ŉ', 'ʼn'),
			_Utils_Tuple2('ſ', 's'),
			_Utils_Tuple2('ǰ', 'ǰ'),
			_Utils_Tuple2('ͅ', 'ι'),
			_Utils_Tuple2('ΐ', 'ΐ'),
			_Utils_Tuple2('ΰ', 'ΰ'),
			_Utils_Tuple2('ς', 'σ'),
			_Utils_Tuple2('ϐ', 'β'),
			_Utils_Tuple2('ϑ', 'θ'),
			_Utils_Tuple2('ϕ', 'φ'),
			_Utils_Tuple2('ϖ', 'π'),
			_Utils_Tuple2('ϰ', 'κ'),
			_Utils_Tuple2('ϱ', 'ρ'),
			_Utils_Tuple2('ϵ', 'ε'),
			_Utils_Tuple2('և', 'եւ'),
			_Utils_Tuple2('ᏸ', 'Ᏸ'),
			_Utils_Tuple2('ᏹ', 'Ᏹ'),
			_Utils_Tuple2('ᏺ', 'Ᏺ'),
			_Utils_Tuple2('ᏻ', 'Ᏻ'),
			_Utils_Tuple2('ᏼ', 'Ᏼ'),
			_Utils_Tuple2('ᏽ', 'Ᏽ'),
			_Utils_Tuple2('ᲀ', 'в'),
			_Utils_Tuple2('ᲁ', 'д'),
			_Utils_Tuple2('ᲂ', 'о'),
			_Utils_Tuple2('ᲃ', 'с'),
			_Utils_Tuple2('ᲄ', 'т'),
			_Utils_Tuple2('ᲅ', 'т'),
			_Utils_Tuple2('ᲆ', 'ъ'),
			_Utils_Tuple2('ᲇ', 'ѣ'),
			_Utils_Tuple2('ᲈ', 'ꙋ'),
			_Utils_Tuple2('ẖ', 'ẖ'),
			_Utils_Tuple2('ẗ', 'ẗ'),
			_Utils_Tuple2('ẘ', 'ẘ'),
			_Utils_Tuple2('ẙ', 'ẙ'),
			_Utils_Tuple2('ẚ', 'aʾ'),
			_Utils_Tuple2('ẛ', 'ṡ'),
			_Utils_Tuple2('ὐ', 'ὐ'),
			_Utils_Tuple2('ὒ', 'ὒ'),
			_Utils_Tuple2('ὔ', 'ὔ'),
			_Utils_Tuple2('ὖ', 'ὖ'),
			_Utils_Tuple2('ᾀ', 'ἀι'),
			_Utils_Tuple2('ᾁ', 'ἁι'),
			_Utils_Tuple2('ᾂ', 'ἂι'),
			_Utils_Tuple2('ᾃ', 'ἃι'),
			_Utils_Tuple2('ᾄ', 'ἄι'),
			_Utils_Tuple2('ᾅ', 'ἅι'),
			_Utils_Tuple2('ᾆ', 'ἆι'),
			_Utils_Tuple2('ᾇ', 'ἇι'),
			_Utils_Tuple2('ᾐ', 'ἠι'),
			_Utils_Tuple2('ᾑ', 'ἡι'),
			_Utils_Tuple2('ᾒ', 'ἢι'),
			_Utils_Tuple2('ᾓ', 'ἣι'),
			_Utils_Tuple2('ᾔ', 'ἤι'),
			_Utils_Tuple2('ᾕ', 'ἥι'),
			_Utils_Tuple2('ᾖ', 'ἦι'),
			_Utils_Tuple2('ᾗ', 'ἧι'),
			_Utils_Tuple2('ᾠ', 'ὠι'),
			_Utils_Tuple2('ᾡ', 'ὡι'),
			_Utils_Tuple2('ᾢ', 'ὢι'),
			_Utils_Tuple2('ᾣ', 'ὣι'),
			_Utils_Tuple2('ᾤ', 'ὤι'),
			_Utils_Tuple2('ᾥ', 'ὥι'),
			_Utils_Tuple2('ᾦ', 'ὦι'),
			_Utils_Tuple2('ᾧ', 'ὧι'),
			_Utils_Tuple2('ᾲ', 'ὰι'),
			_Utils_Tuple2('ᾳ', 'αι'),
			_Utils_Tuple2('ᾴ', 'άι'),
			_Utils_Tuple2('ᾶ', 'ᾶ'),
			_Utils_Tuple2('ᾷ', 'ᾶι'),
			_Utils_Tuple2('ι', 'ι'),
			_Utils_Tuple2('ῂ', 'ὴι'),
			_Utils_Tuple2('ῃ', 'ηι'),
			_Utils_Tuple2('ῄ', 'ήι'),
			_Utils_Tuple2('ῆ', 'ῆ'),
			_Utils_Tuple2('ῇ', 'ῆι'),
			_Utils_Tuple2('ῒ', 'ῒ'),
			_Utils_Tuple2('ΐ', 'ΐ'),
			_Utils_Tuple2('ῖ', 'ῖ'),
			_Utils_Tuple2('ῗ', 'ῗ'),
			_Utils_Tuple2('ῢ', 'ῢ'),
			_Utils_Tuple2('ΰ', 'ΰ'),
			_Utils_Tuple2('ῤ', 'ῤ'),
			_Utils_Tuple2('ῦ', 'ῦ'),
			_Utils_Tuple2('ῧ', 'ῧ'),
			_Utils_Tuple2('ῲ', 'ὼι'),
			_Utils_Tuple2('ῳ', 'ωι'),
			_Utils_Tuple2('ῴ', 'ώι'),
			_Utils_Tuple2('ῶ', 'ῶ'),
			_Utils_Tuple2('ῷ', 'ῶι'),
			_Utils_Tuple2('ꭰ', 'Ꭰ'),
			_Utils_Tuple2('ꭱ', 'Ꭱ'),
			_Utils_Tuple2('ꭲ', 'Ꭲ'),
			_Utils_Tuple2('ꭳ', 'Ꭳ'),
			_Utils_Tuple2('ꭴ', 'Ꭴ'),
			_Utils_Tuple2('ꭵ', 'Ꭵ'),
			_Utils_Tuple2('ꭶ', 'Ꭶ'),
			_Utils_Tuple2('ꭷ', 'Ꭷ'),
			_Utils_Tuple2('ꭸ', 'Ꭸ'),
			_Utils_Tuple2('ꭹ', 'Ꭹ'),
			_Utils_Tuple2('ꭺ', 'Ꭺ'),
			_Utils_Tuple2('ꭻ', 'Ꭻ'),
			_Utils_Tuple2('ꭼ', 'Ꭼ'),
			_Utils_Tuple2('ꭽ', 'Ꭽ'),
			_Utils_Tuple2('ꭾ', 'Ꭾ'),
			_Utils_Tuple2('ꭿ', 'Ꭿ'),
			_Utils_Tuple2('ꮀ', 'Ꮀ'),
			_Utils_Tuple2('ꮁ', 'Ꮁ'),
			_Utils_Tuple2('ꮂ', 'Ꮂ'),
			_Utils_Tuple2('ꮃ', 'Ꮃ'),
			_Utils_Tuple2('ꮄ', 'Ꮄ'),
			_Utils_Tuple2('ꮅ', 'Ꮅ'),
			_Utils_Tuple2('ꮆ', 'Ꮆ'),
			_Utils_Tuple2('ꮇ', 'Ꮇ'),
			_Utils_Tuple2('ꮈ', 'Ꮈ'),
			_Utils_Tuple2('ꮉ', 'Ꮉ'),
			_Utils_Tuple2('ꮊ', 'Ꮊ'),
			_Utils_Tuple2('ꮋ', 'Ꮋ'),
			_Utils_Tuple2('ꮌ', 'Ꮌ'),
			_Utils_Tuple2('ꮍ', 'Ꮍ'),
			_Utils_Tuple2('ꮎ', 'Ꮎ'),
			_Utils_Tuple2('ꮏ', 'Ꮏ'),
			_Utils_Tuple2('ꮐ', 'Ꮐ'),
			_Utils_Tuple2('ꮑ', 'Ꮑ'),
			_Utils_Tuple2('ꮒ', 'Ꮒ'),
			_Utils_Tuple2('ꮓ', 'Ꮓ'),
			_Utils_Tuple2('ꮔ', 'Ꮔ'),
			_Utils_Tuple2('ꮕ', 'Ꮕ'),
			_Utils_Tuple2('ꮖ', 'Ꮖ'),
			_Utils_Tuple2('ꮗ', 'Ꮗ'),
			_Utils_Tuple2('ꮘ', 'Ꮘ'),
			_Utils_Tuple2('ꮙ', 'Ꮙ'),
			_Utils_Tuple2('ꮚ', 'Ꮚ'),
			_Utils_Tuple2('ꮛ', 'Ꮛ'),
			_Utils_Tuple2('ꮜ', 'Ꮜ'),
			_Utils_Tuple2('ꮝ', 'Ꮝ'),
			_Utils_Tuple2('ꮞ', 'Ꮞ'),
			_Utils_Tuple2('ꮟ', 'Ꮟ'),
			_Utils_Tuple2('ꮠ', 'Ꮠ'),
			_Utils_Tuple2('ꮡ', 'Ꮡ'),
			_Utils_Tuple2('ꮢ', 'Ꮢ'),
			_Utils_Tuple2('ꮣ', 'Ꮣ'),
			_Utils_Tuple2('ꮤ', 'Ꮤ'),
			_Utils_Tuple2('ꮥ', 'Ꮥ'),
			_Utils_Tuple2('ꮦ', 'Ꮦ'),
			_Utils_Tuple2('ꮧ', 'Ꮧ'),
			_Utils_Tuple2('ꮨ', 'Ꮨ'),
			_Utils_Tuple2('ꮩ', 'Ꮩ'),
			_Utils_Tuple2('ꮪ', 'Ꮪ'),
			_Utils_Tuple2('ꮫ', 'Ꮫ'),
			_Utils_Tuple2('ꮬ', 'Ꮬ'),
			_Utils_Tuple2('ꮭ', 'Ꮭ'),
			_Utils_Tuple2('ꮮ', 'Ꮮ'),
			_Utils_Tuple2('ꮯ', 'Ꮯ'),
			_Utils_Tuple2('ꮰ', 'Ꮰ'),
			_Utils_Tuple2('ꮱ', 'Ꮱ'),
			_Utils_Tuple2('ꮲ', 'Ꮲ'),
			_Utils_Tuple2('ꮳ', 'Ꮳ'),
			_Utils_Tuple2('ꮴ', 'Ꮴ'),
			_Utils_Tuple2('ꮵ', 'Ꮵ'),
			_Utils_Tuple2('ꮶ', 'Ꮶ'),
			_Utils_Tuple2('ꮷ', 'Ꮷ'),
			_Utils_Tuple2('ꮸ', 'Ꮸ'),
			_Utils_Tuple2('ꮹ', 'Ꮹ'),
			_Utils_Tuple2('ꮺ', 'Ꮺ'),
			_Utils_Tuple2('ꮻ', 'Ꮻ'),
			_Utils_Tuple2('ꮼ', 'Ꮼ'),
			_Utils_Tuple2('ꮽ', 'Ꮽ'),
			_Utils_Tuple2('ꮾ', 'Ꮾ'),
			_Utils_Tuple2('ꮿ', 'Ꮿ'),
			_Utils_Tuple2('ﬀ', 'ff'),
			_Utils_Tuple2('ﬁ', 'fi'),
			_Utils_Tuple2('ﬂ', 'fl'),
			_Utils_Tuple2('ﬃ', 'ffi'),
			_Utils_Tuple2('ﬄ', 'ffl'),
			_Utils_Tuple2('ﬅ', 'st'),
			_Utils_Tuple2('ﬆ', 'st'),
			_Utils_Tuple2('ﬓ', 'մն'),
			_Utils_Tuple2('ﬔ', 'մե'),
			_Utils_Tuple2('ﬕ', 'մի'),
			_Utils_Tuple2('ﬖ', 'վն'),
			_Utils_Tuple2('ﬗ', 'մխ')
		]));
var $elm$core$String$cons = _String_cons;
var $elm$core$String$fromChar = function (_char) {
	return A2($elm$core$String$cons, _char, '');
};
var $elm$core$String$toLower = _String_toLower;
var $author$project$SearchFold$fold = function (value) {
	return $elm$core$String$concat(
		A2(
			$elm$core$List$map,
			function (c) {
				return A2(
					$elm$core$Maybe$withDefault,
					$elm$core$String$fromChar(c),
					A2(
						$elm$core$Dict$get,
						$elm$core$String$fromChar(c),
						$author$project$SearchFold$exceptions));
			},
			$elm$core$String$toList(
				$elm$core$String$toLower(value))));
};
var $elm$core$Tuple$second = function (_v0) {
	var y = _v0.b;
	return y;
};
var $elm$core$String$trim = _String_trim;
var $elm$core$String$words = _String_words;
var $author$project$Catalog$search = F2(
	function (raw, snapshot) {
		var query = $author$project$SearchFold$fold(
			$elm$core$String$trim(raw));
		var words = $elm$core$String$words(query);
		var rank = function (entry) {
			var tokens = A2(
				$elm$core$List$concatMap,
				A2($elm$core$Basics$composeR, $author$project$SearchFold$fold, $elm$core$String$words),
				A2(
					$elm$core$List$cons,
					entry.dj,
					A2($elm$core$List$cons, entry.dX, entry.d3)));
			var name = $author$project$SearchFold$fold(entry.dj);
			return $elm$core$String$isEmpty(query) ? $elm$core$Maybe$Just(0) : (_Utils_eq(name, query) ? $elm$core$Maybe$Just(0) : (A2($elm$core$String$startsWith, query, name) ? $elm$core$Maybe$Just(1) : (A2(
				$elm$core$List$all,
				function (word) {
					return A2(
						$elm$core$List$any,
						$elm$core$String$startsWith(word),
						tokens);
				},
				words) ? $elm$core$Maybe$Just(2) : $elm$core$Maybe$Nothing)));
		};
		var compare = F2(
			function (_v1, _v2) {
				var aRank = _v1.a;
				var a = _v1.b;
				var bRank = _v2.a;
				var b = _v2.b;
				var _v0 = A2($elm$core$Basics$compare, aRank, bRank);
				if (_v0 === 1) {
					return A2(
						$elm$core$Basics$compare,
						$author$project$Catalog$id(a.cG),
						$author$project$Catalog$id(b.cG));
				} else {
					var order = _v0;
					return order;
				}
			});
		return A2(
			$elm$core$List$map,
			$elm$core$Tuple$second,
			A2(
				$elm$core$List$sortWith,
				compare,
				A2(
					$elm$core$List$filterMap,
					function (entry) {
						return A2(
							$elm$core$Maybe$map,
							function (value) {
								return _Utils_Tuple2(value, entry);
							},
							rank(entry));
					},
					$author$project$Catalog$entries(snapshot))));
	});
var $author$project$Switcher$selected = function (_v0) {
	var model = _v0;
	return $elm$core$List$head(
		A2($elm$core$List$drop, model.bG, model.ak));
};
var $author$project$SystemMenu$sessionStateName = function (state) {
	if (!state.$) {
		return 'closing';
	} else {
		var observed = state.a;
		return observed;
	}
};
var $elm$core$List$singleton = function (value) {
	return _List_fromArray(
		[value]);
};
var $author$project$Shell$stampKey = function (_v0) {
	var binding = _v0.a;
	var output = _v0.b;
	var revision = _v0.c;
	return A2(
		$elm$json$Json$Encode$encode,
		0,
		$author$project$Binding$encode(binding)) + (':' + ($author$project$UInt64$string(output) + (':' + $author$project$UInt64$string(revision))));
};
var $elm$core$String$any = _String_any;
var $author$project$Files$textValid = function (value) {
	return ($elm$core$String$length(value) <= 512) && (!A2(
		$elm$core$String$any,
		function (c) {
			return ($elm$core$Char$toCode(c) < 32) || ($elm$core$Char$toCode(c) === 127);
		},
		value));
};
var $author$project$Files$validTarget = function (value) {
	return $author$project$Files$textValid(value) && ((value === 'home') || (A2(
		$elm$core$List$any,
		function (_v0) {
			var collection = _v0.a;
			return _Utils_eq(value, 'coll:' + collection);
		},
		$author$project$Files$collections) || (A2(
		$elm$core$String$startsWith,
		'/',
		$elm$core$String$trim(value)) || ((value === '~') || A2($elm$core$String$startsWith, '~/', value)))));
};
var $author$project$Files$supported = F2(
	function (value, model) {
		return _Utils_eq(model.dn, $elm$core$Maybe$Nothing) && ($author$project$Files$validTarget(value.fK) && ((!A2($elm$core$List$member, value, model.b1)) && A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (snapshot) {
					return snapshot.c2 && (_Utils_eq(value.cS, snapshot.cS) && _Utils_eq(value.cN, snapshot.cN));
				},
				model.c))));
	});
var $author$project$JumpList$supported = F2(
	function (value, model) {
		return _Utils_eq(model.dn, $elm$core$Maybe$Nothing) && ((!A2($elm$core$List$member, value, model.b1)) && A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (snapshot) {
					return snapshot.c2 && (_Utils_eq(snapshot.cS, value.cS) && (_Utils_eq(snapshot.cN, value.cN) && (_Utils_eq(snapshot.dQ, value.dQ) && A2(
						$elm$core$List$any,
						function (row) {
							return _Utils_eq(row.cc, value.eV);
						},
						snapshot.cv))));
				},
				model.c)));
	});
var $author$project$SystemMenu$NetworkAuth = 2;
var $author$project$SystemMenu$NetworkYes = 0;
var $author$project$SystemMenu$PowerChallenge = 3;
var $author$project$SystemMenu$PowerYes = 0;
var $elm$core$Basics$ge = _Utils_ge;
var $author$project$SystemMenu$supported = F2(
	function (value, model) {
		var _v0 = model.c;
		if (_v0.$ === 1) {
			return false;
		} else {
			var current = _v0.a;
			return _Utils_eq(value.cS, current.cS) && (_Utils_eq(value.cN, current.cN) && ((!A2($elm$core$List$member, value, model.b1)) && function () {
				var _v1 = value.bc;
				switch (_v1) {
					case 0:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return (value.ab >= 0) && ((value.ab <= 100) && (!_Utils_eq(value.ab, v.fp)));
								},
								current.fO));
					case 1:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return A2(
										$elm$core$List$member,
										value.ab,
										_List_fromArray(
											[0, 1])) && (!_Utils_eq(value.ab === 1, v.di));
								},
								current.fO));
					case 2:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return A2(
										$elm$core$List$member,
										v.fq,
										_List_fromArray(
											[0, 2])) && (A2(
										$elm$core$List$member,
										value.ab,
										_List_fromArray(
											[0, 1])) && (!_Utils_eq(value.ab === 1, v.b9)));
								},
								current.fi));
					case 3:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return A2(
										$elm$core$List$member,
										v.fJ,
										_List_fromArray(
											[0, 3])) && (!value.ab);
								},
								current.fu));
					case 4:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return A2(
										$elm$core$List$member,
										v.fx,
										_List_fromArray(
											[0, 3])) && (!value.ab);
								},
								current.fu));
					case 5:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return A2(
										$elm$core$List$member,
										v.fv,
										_List_fromArray(
											[0, 3])) && (!value.ab);
								},
								current.fu));
					case 6:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									return (!v.ff) && (!value.ab);
								},
								current.fF));
					default:
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (v) {
									var _v2 = v.cX;
									if (!_v2.$) {
										return false;
									} else {
										return !value.ab;
									}
								},
								current.fF));
				}
			}()));
		}
	});
var $elm$core$List$takeReverse = F3(
	function (n, list, kept) {
		takeReverse:
		while (true) {
			if (n <= 0) {
				return kept;
			} else {
				if (!list.b) {
					return kept;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs,
						$temp$kept = A2($elm$core$List$cons, x, kept);
					n = $temp$n;
					list = $temp$list;
					kept = $temp$kept;
					continue takeReverse;
				}
			}
		}
	});
var $elm$core$List$takeTailRec = F2(
	function (n, list) {
		return $elm$core$List$reverse(
			A3($elm$core$List$takeReverse, n, list, _List_Nil));
	});
var $elm$core$List$takeFast = F3(
	function (ctr, n, list) {
		if (n <= 0) {
			return _List_Nil;
		} else {
			var _v0 = _Utils_Tuple2(n, list);
			_v0$1:
			while (true) {
				_v0$5:
				while (true) {
					if (!_v0.b.b) {
						return list;
					} else {
						if (_v0.b.b.b) {
							switch (_v0.a) {
								case 1:
									break _v0$1;
								case 2:
									var _v2 = _v0.b;
									var x = _v2.a;
									var _v3 = _v2.b;
									var y = _v3.a;
									return _List_fromArray(
										[x, y]);
								case 3:
									if (_v0.b.b.b.b) {
										var _v4 = _v0.b;
										var x = _v4.a;
										var _v5 = _v4.b;
										var y = _v5.a;
										var _v6 = _v5.b;
										var z = _v6.a;
										return _List_fromArray(
											[x, y, z]);
									} else {
										break _v0$5;
									}
								default:
									if (_v0.b.b.b.b && _v0.b.b.b.b.b) {
										var _v7 = _v0.b;
										var x = _v7.a;
										var _v8 = _v7.b;
										var y = _v8.a;
										var _v9 = _v8.b;
										var z = _v9.a;
										var _v10 = _v9.b;
										var w = _v10.a;
										var tl = _v10.b;
										return (ctr > 1000) ? A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A2($elm$core$List$takeTailRec, n - 4, tl))))) : A2(
											$elm$core$List$cons,
											x,
											A2(
												$elm$core$List$cons,
												y,
												A2(
													$elm$core$List$cons,
													z,
													A2(
														$elm$core$List$cons,
														w,
														A3($elm$core$List$takeFast, ctr + 1, n - 4, tl)))));
									} else {
										break _v0$5;
									}
							}
						} else {
							if (_v0.a === 1) {
								break _v0$1;
							} else {
								break _v0$5;
							}
						}
					}
				}
				return list;
			}
			var _v1 = _v0.b;
			var x = _v1.a;
			return _List_fromArray(
				[x]);
		}
	});
var $elm$core$List$take = F2(
	function (n, list) {
		return A3($elm$core$List$takeFast, 0, n, list);
	});
var $author$project$Notifications$target = F4(
	function (snapshot, entry, verb, action) {
		return {eV: action, cc: entry.cc, au: entry.au, ag: entry.ag, cS: snapshot.cS, b2: verb};
	});
var $author$project$Settings$themeName = function (theme) {
	switch (theme) {
		case 0:
			return 'night';
		case 1:
			return 'dawn';
		default:
			return 'high-contrast';
	}
};
var $author$project$Launch$Acknowledgement = $elm$core$Basics$identity;
var $author$project$Launch$uncertain = function (_v0) {
	var model = _v0;
	var _v1 = model.m;
	if ((_v1.$ === 2) && (_v1.b === 2)) {
		var intent = _v1.a;
		var _v2 = _v1.b;
		return $elm$core$Maybe$Just(intent);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$UInt64$Counter = $elm$core$Basics$identity;
var $elm$core$Char$fromCode = _Char_fromCode;
var $author$project$UInt64$next = function (_v0) {
	var value = _v0;
	var add = function (digits) {
		if (!digits.b) {
			return _List_fromArray(
				['1']);
		} else {
			if ('9' === digits.a) {
				var rest = digits.b;
				return A2(
					$elm$core$List$cons,
					'0',
					add(rest));
			} else {
				var digit = digits.a;
				var rest = digits.b;
				return A2(
					$elm$core$List$cons,
					$elm$core$Char$fromCode(
						$elm$core$Char$toCode(digit) + 1),
					rest);
			}
		}
	};
	return (value === '18446744073709551615') ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
		$elm$core$String$fromList(
			$elm$core$List$reverse(
				add(
					$elm$core$List$reverse(
						$elm$core$String$toList(value))))));
};
var $author$project$WorkspaceNavigation$propose = F4(
	function (inventory, geometry, destination, model) {
		if ((!model.bY) || ($author$project$WorkspaceNavigation$blocked(model) || ((!_Utils_eq(
			model.c3,
			$elm$core$Maybe$Just(geometry.c3))) || (geometry.eZ || ((!A2($author$project$WorkspaceInventory$coherent, inventory, geometry)) || A2(
			$elm$core$List$any,
			function (w) {
				return _Utils_eq(
					w.dB,
					$elm$core$Maybe$Just(destination));
			},
			geometry.a)))))) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = _Utils_Tuple2(
				A2(
					$elm$core$Maybe$andThen,
					function (id) {
						return $elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (r) {
									return _Utils_eq(r.cG, id);
								},
								inventory.ez));
					},
					inventory.dC),
				$elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (r) {
							return _Utils_eq(r.cG, destination);
						},
						inventory.ez)));
			if ((!_v0.a.$) && (!_v0.b.$)) {
				var source = _v0.a.a;
				var target = _v0.b.a;
				return _Utils_eq(source.cG, target.cG) ? $elm$core$Maybe$Nothing : A3(
					$elm$core$Maybe$map2,
					F2(
						function (request, generation) {
							return {R: geometry.R, bp: target, e7: generation, cM: request, cm: source};
						}),
					$author$project$UInt64$next(model.cM),
					$author$project$UInt64$next(model.e7));
			} else {
				return $elm$core$Maybe$Nothing;
			}
		}
	});
var $author$project$Desktop$workspaceNavigationIntent = F2(
	function (model, destination) {
		return ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!$author$project$Shell$available(model.a.b)) || ((!_Utils_eq(model.a.b.y, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(model.a.b.cE, $elm$core$Maybe$Nothing)) || (_Utils_eq(model.aF, $elm$core$Maybe$Nothing) || (($author$project$MenuBridge$menuSnapshot(model.a.i).fn > 0) || (A2(
			$elm$core$List$any,
			function (transaction) {
				return A2(
					$elm$core$List$member,
					transaction.O,
					_List_fromArray(
						[0, 4]));
			},
			model.a.b.V.fM) || A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (transaction) {
					return A2(
						$elm$core$List$member,
						transaction.O,
						_List_fromArray(
							[0, 4]));
				},
				model.a.b.V.dz))))))))) ? $elm$core$Maybe$Nothing : A2(
			$elm$core$Maybe$andThen,
			$elm$core$Basics$identity,
			A3(
				$elm$core$Maybe$map2,
				F2(
					function (inventory, geometry) {
						return A4($author$project$WorkspaceNavigation$propose, inventory, geometry, destination, model.J);
					}),
				model.b6,
				model.a.b.ac));
	});
var $author$project$MotionPreferences$writable = function (model) {
	return (!_Utils_eq(model.c, $elm$core$Maybe$Nothing)) && _Utils_eq(model.dn, $elm$core$Maybe$Nothing);
};
var $author$project$Pins$writable = function (model) {
	return (!_Utils_eq(model.c, $elm$core$Maybe$Nothing)) && _Utils_eq(model.dn, $elm$core$Maybe$Nothing);
};
var $author$project$Settings$writable = function (model) {
	return (!_Utils_eq(model.c, $elm$core$Maybe$Nothing)) && _Utils_eq(model.dn, $elm$core$Maybe$Nothing);
};
var $author$project$Surface$controls = function (model) {
	if (model.bA && ($author$project$Surface$mode(model) !== 'applications')) {
		return ($author$project$Surface$mode(model) === 'closed') ? _List_Nil : _List_fromArray(
			[
				{
				f: 'Presentation condensed. Open Applications to browse every application and pin action.',
				g: 'Full state retained',
				h: A2($author$project$Desktop$key, model, 'capacity'),
				b9: false,
				cc: 'control:capacity',
				d6: 'Presentation condensed. Open Applications to browse every application and pin action.',
				d: $elm$core$Maybe$Nothing
			}
			]);
	} else {
		if (!_Utils_eq(model.o, $elm$core$Maybe$Nothing)) {
			var scoped = function (message) {
				return A2(
					$elm$core$Maybe$map,
					message,
					$author$project$Desktop$capture(model));
			};
			var current = A2(
				$elm$core$Maybe$andThen,
				function (snapshot) {
					return _Utils_eq(
						$elm$core$Maybe$Just(snapshot.dQ),
						model.o) ? $elm$core$Maybe$Just(snapshot) : $elm$core$Maybe$Nothing;
				},
				model.al.c);
			var title = A2(
				$elm$core$Maybe$withDefault,
				'Application actions',
				A2(
					$elm$core$Maybe$map,
					function (snapshot) {
						return 'Actions for ' + snapshot.dj;
					},
					current));
			var control = F5(
				function (identity, label, detail, enabled, message) {
					return {
						f: label,
						g: detail,
						h: A2(
							$author$project$Desktop$key,
							model,
							(identity === 'control:close') ? 'jump:close' : identity),
						b9: enabled,
						cc: identity,
						d6: label,
						d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
					};
				});
			var row = F2(
				function (snapshot, action) {
					var intent = A2($author$project$JumpList$intent, snapshot, action.cc);
					return A5(
						control,
						'jump:action:' + action.cc,
						action.d6,
						(action.d4 === 1) ? 'Recent file' : 'Application action',
						_Utils_eq(model.aU, $elm$core$Maybe$Nothing) && A2($author$project$JumpList$supported, intent, model.al),
						function (stamp) {
							return A2($author$project$Desktop$JumpAction, stamp, intent);
						});
				});
			var entries = A2(
				$elm$core$Maybe$withDefault,
				_List_Nil,
				A2(
					$elm$core$Maybe$map,
					function (snapshot) {
						return A2(
							$elm$core$List$map,
							row(snapshot),
							snapshot.cv);
					},
					current));
			return _Utils_ap(
				_List_fromArray(
					[
						A5(control, 'control:close', 'Close application actions', '', true, $author$project$Desktop$CloseJumpList),
						A5(
						control,
						'jump:refresh',
						'Refresh application actions',
						'Read actions; never repeat a request',
						_Utils_eq(model.aU, $elm$core$Maybe$Nothing),
						$author$project$Desktop$RefreshJumpList),
						A5(control, 'jump:title:state', title, '', false, $author$project$Desktop$CloseJumpList)
					]),
				_Utils_ap(
					A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						A2(
							$elm$core$Maybe$map,
							function (entry) {
								return _List_fromArray(
									[
										A3(
										$author$project$Surface$newInstanceControl,
										model,
										A2($author$project$Desktop$key, model, 'jump:new-instance'),
										entry)
									]);
							},
							A2(
								$elm$core$Maybe$andThen,
								function (identity) {
									return A2(
										$elm$core$Maybe$andThen,
										$author$project$Catalog$lookup(identity),
										model.aj);
								},
								model.o))),
					_Utils_ap(
						entries,
						($elm$core$List$isEmpty(entries) && _Utils_eq(model.aU, $elm$core$Maybe$Nothing)) ? _List_fromArray(
							[
								A5(control, 'jump:empty:state', 'No supported actions or recent files.', '', false, $author$project$Desktop$CloseJumpList)
							]) : _List_Nil)));
		} else {
			if (model.s) {
				var scoped = function (message) {
					return A2(
						$elm$core$Maybe$map,
						message,
						$author$project$Desktop$capture(model));
				};
				var ready = function (target) {
					return _Utils_eq(model.aR, $elm$core$Maybe$Nothing) && A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (snapshot) {
								return A2(
									$author$project$Files$supported,
									A2($author$project$Files$intent, snapshot, target),
									model.W);
							},
							model.W.c));
				};
				var openTarget = F2(
					function (target, stamp) {
						return A2(
							$elm$core$Maybe$withDefault,
							$author$project$Desktop$CloseFiles(stamp),
							A2(
								$elm$core$Maybe$map,
								function (snapshot) {
									return A2(
										$author$project$Desktop$OpenFilesTarget,
										stamp,
										A2($author$project$Files$intent, snapshot, target));
								},
								model.W.c));
					});
				var location = A2(
					$elm$core$Maybe$withDefault,
					'No Files window observed.',
					A2(
						$elm$core$Maybe$map,
						function (peer) {
							return 'Current location: ' + peer.fK;
						},
						A2(
							$elm$core$Maybe$andThen,
							function ($) {
								return $.bV;
							},
							model.W.c)));
				var control = F5(
					function (identity, label, detail, enabled, message) {
						return {
							f: label,
							g: detail,
							h: A2(
								$author$project$Desktop$key,
								model,
								(identity === 'control:close') ? 'files:close' : identity),
							b9: enabled,
							cc: identity,
							d6: label,
							d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
						};
					});
				var collection = function (_v0) {
					var identifier = _v0.a;
					var label = _v0.b;
					return A5(
						control,
						'files:collection:' + identifier,
						label,
						'',
						ready('coll:' + identifier),
						openTarget('coll:' + identifier));
				};
				return _Utils_ap(
					_List_fromArray(
						[
							A5(control, 'control:close', 'Close Files menu', '', true, $author$project$Desktop$CloseFiles),
							A5(
							control,
							'files:refresh',
							'Refresh Files state',
							'Read location; never repeat an opening',
							_Utils_eq(model.aR, $elm$core$Maybe$Nothing),
							$author$project$Desktop$RefreshFiles),
							A5(control, 'files:location:state', location, '', false, $author$project$Desktop$CloseFiles),
							A5(
							control,
							'files:home',
							'Home',
							'',
							ready('home'),
							openTarget('home'))
						]),
					_Utils_ap(
						A2($elm$core$List$map, collection, $author$project$Files$collections),
						_List_fromArray(
							[
								{
								f: 'Folder path',
								g: '',
								h: A2($author$project$Desktop$key, model, 'files:path'),
								b9: true,
								cc: 'control:files-path',
								d6: model.W.e2,
								d: scoped(
									function (stamp) {
										return A2($author$project$Desktop$EditFilesPath, stamp, model.W.e2);
									})
							},
								A5(
								control,
								'files:open-path',
								'Open folder',
								'Open this path in Files',
								ready(model.W.e2),
								$author$project$Desktop$OpenFilesPath)
							])));
			} else {
				if (model.x) {
					var scoped = function (action) {
						return A2(
							$elm$core$Maybe$map,
							action,
							$author$project$Desktop$capture(model));
					};
					var control = F5(
						function (identity, label, detail, enabled, message) {
							return {
								f: label,
								g: detail,
								h: A2(
									$author$project$Desktop$key,
									model,
									(identity === 'control:close') ? 'system:close' : identity),
								b9: enabled,
								cc: identity,
								d6: label,
								d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
							};
						});
					var state = F2(
						function (section, value) {
							return A5(control, 'system:' + (section + ':state'), value, '', false, $author$project$Desktop$CloseSystemMenu);
						});
					var rows = function (snapshot) {
						var change = F3(
							function (operation, value, label) {
								var intent = A3($author$project$SystemMenu$intent, snapshot, operation, value);
								var ready = _Utils_eq(model.aq.dn, $elm$core$Maybe$Nothing) && (_Utils_eq(model.aP, $elm$core$Maybe$Nothing) && (_Utils_eq(model.t, $elm$core$Maybe$Nothing) && A2($author$project$SystemMenu$supported, intent, model.aq)));
								return A5(
									control,
									'system:' + ($author$project$SystemMenu$code(operation) + (':' + $elm$core$String$fromInt(value))),
									label,
									'',
									ready,
									function (stamp) {
										return A2($author$project$Desktop$SystemChange, stamp, intent);
									});
							});
						var network = function () {
							var _v5 = snapshot.fi;
							if (_v5.$ === 1) {
								return _List_fromArray(
									[
										A2(state, 'network', 'Network unavailable')
									]);
							} else {
								var current = _v5.a;
								return _List_fromArray(
									[
										A2(
										state,
										'network',
										'Network ' + ((current.b9 ? 'enabled' : 'disabled') + (' · ' + (current.cX + ((current.fq === 1) ? '; changes unavailable' : ''))))),
										A3(
										change,
										2,
										current.b9 ? 0 : 1,
										current.b9 ? 'Disable networking' : 'Enable networking')
									]);
							}
						}();
						var session = function () {
							var _v4 = snapshot.fF;
							if (_v4.$ === 1) {
								return _List_fromArray(
									[
										A2(state, 'session', 'Session controls unavailable')
									]);
							} else {
								var current = _v4.a;
								return _List_fromArray(
									[
										A2(
										state,
										'session',
										'Session ' + (current.dj + (' · ' + ($author$project$SystemMenu$sessionStateName(current.cX) + (current.ff ? '; locked' : '; unlocked'))))),
										A3(change, 6, 0, 'Lock session'),
										A3(change, 7, 0, 'Log out')
									]);
							}
						}();
						var volume = function () {
							var _v3 = snapshot.fO;
							if (_v3.$ === 1) {
								return _List_fromArray(
									[
										A2(state, 'volume', 'Volume unavailable')
									]);
							} else {
								var current = _v3.a;
								return A2(
									$elm$core$List$cons,
									A2(
										state,
										'volume',
										'Volume ' + ($elm$core$String$fromInt(current.fp) + ('%' + ((current.di ? '; muted' : '; unmuted') + (' · ' + current.d6))))),
									_Utils_ap(
										A2(
											$elm$core$List$map,
											function (percent) {
												return A3(
													change,
													0,
													percent,
													'Set volume ' + ($elm$core$String$fromInt(percent) + '%'));
											},
											_List_fromArray(
												[0, 25, 50, 75, 100])),
										_List_fromArray(
											[
												A3(
												change,
												1,
												current.di ? 0 : 1,
												current.di ? 'Unmute' : 'Mute')
											])));
							}
						}();
						var capability = $author$project$SystemMenu$powerCapabilityLabel;
						var power = function () {
							var _v2 = snapshot.fu;
							if (_v2.$ === 1) {
								return _List_fromArray(
									[
										A2(state, 'power', 'Power controls unavailable')
									]);
							} else {
								var current = _v2.a;
								return _List_fromArray(
									[
										A2(
										state,
										'power',
										'Power · suspend ' + (capability(current.fJ) + (', restart ' + (capability(current.fx) + (', shutdown ' + capability(current.fv)))))),
										A3(change, 3, 0, 'Suspend'),
										A3(change, 4, 0, 'Restart'),
										A3(change, 5, 0, 'Shut down')
									]);
							}
						}();
						return _Utils_ap(
							volume,
							_Utils_ap(
								network,
								_Utils_ap(power, session)));
					};
					var confirmation = function () {
						var _v1 = model.t;
						if (_v1.$ === 1) {
							return _List_Nil;
						} else {
							var intent = _v1.a;
							return _List_fromArray(
								[
									A2(
									state,
									'confirmation',
									'Confirm ' + ($author$project$SystemMenu$name(intent.bc) + '? Unsaved work or active connections may be affected.')),
									A5(control, 'system:cancel', 'Cancel system change', '', true, $author$project$Desktop$CancelSystemChange),
									A5(
									control,
									'system:confirm',
									'Confirm ' + $author$project$SystemMenu$name(intent.bc),
									'',
									A2($author$project$SystemMenu$supported, intent, model.aq) && (_Utils_eq(model.aq.dn, $elm$core$Maybe$Nothing) && _Utils_eq(model.aP, $elm$core$Maybe$Nothing)),
									function (stamp) {
										return A2($author$project$Desktop$ConfirmSystemChange, stamp, intent);
									})
								]);
						}
					}();
					return _Utils_ap(
						_List_fromArray(
							[
								A5(control, 'control:close', 'Close system menu', '', true, $author$project$Desktop$CloseSystemMenu),
								A5(
								control,
								'system:refresh',
								'Refresh system state',
								'Read current state; never repeat a change',
								_Utils_eq(model.aP, $elm$core$Maybe$Nothing),
								$author$project$Desktop$RefreshSystemMenu)
							]),
						_Utils_ap(
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2($elm$core$Maybe$map, rows, model.aq.c)),
							confirmation));
				} else {
					if (model.v) {
						var scoped = function (message) {
							return A2(
								$elm$core$Maybe$map,
								message,
								$author$project$Desktop$capture(model));
						};
						var control = F5(
							function (identity, label, detail, enabled, message) {
								return {
									f: label,
									g: detail,
									h: A2(
										$author$project$Desktop$key,
										model,
										(identity === 'control:close') ? 'notifications:close' : identity),
									b9: enabled,
									cc: identity,
									d6: label,
									d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
								};
							});
						var clean = function (value) {
							return A2(
								$elm$core$String$join,
								' ',
								$elm$core$String$words(value));
						};
						var entryRows = F2(
							function (snapshot, entry) {
								var textRow = F3(
									function (identity, label, detail) {
										return {
											f: clean(label),
											g: detail,
											h: A2($author$project$Desktop$key, model, identity),
											b9: false,
											cc: identity,
											d6: clean(label),
											d: $elm$core$Maybe$Nothing
										};
									});
								var prefix = 'notification:' + ($author$project$UInt64$string(snapshot.cS) + (':' + $author$project$UInt64$string(entry.au)));
								var action = F3(
									function (verb, key, label) {
										var target = A4($author$project$Notifications$target, snapshot, entry, verb, key);
										var ready = A2($author$project$Notifications$live, target, model.C) && (_Utils_eq(model.C.dn, $elm$core$Maybe$Nothing) && _Utils_eq(model.aX, $elm$core$Maybe$Nothing));
										return A5(
											control,
											$author$project$Notifications$identity(target),
											clean(label),
											'',
											ready,
											function (stamp) {
												return A2($author$project$Desktop$NotificationAction, stamp, target);
											});
									});
								return _Utils_ap(
									_List_fromArray(
										[
											A3(
											textRow,
											prefix + ':summary',
											entry.dE + (': ' + entry.eG),
											(!entry.cX) ? 'Live' : ('History · ' + $author$project$Notifications$entryStateName(entry.cX)))
										]),
									_Utils_ap(
										$elm$core$String$isEmpty(entry.dH) ? _List_Nil : _List_fromArray(
											[
												A3(textRow, prefix + ':body', entry.dH, '')
											]),
										(!entry.cX) ? _Utils_ap(
											A2(
												$elm$core$List$map,
												function (item) {
													return A3(action, 0, item.aV, item.d6);
												},
												entry.cv),
											_List_fromArray(
												[
													A3(action, 1, '', 'Dismiss notification')
												])) : A2(
											$elm$core$Maybe$withDefault,
											_List_Nil,
											A2(
												$elm$core$Maybe$andThen,
												function (selected) {
													return (_Utils_eq(selected.fK.cS, snapshot.cS) && (_Utils_eq(selected.fK.cc, entry.cc) && (_Utils_eq(selected.fK.au, entry.au) && _Utils_eq(selected.fK.ag, entry.ag)))) ? $elm$core$Maybe$Just(
														_List_fromArray(
															[
																{
																f: selected.d6 + '; unavailable',
																g: $author$project$Notifications$entryStateName(entry.cX) + ' · Action unavailable',
																h: A2(
																	$author$project$Desktop$key,
																	model,
																	$author$project$Notifications$identity(selected.fK)),
																b9: false,
																cc: $author$project$Notifications$identity(selected.fK),
																d6: selected.d6,
																d: $elm$core$Maybe$Nothing
															}
															])) : $elm$core$Maybe$Nothing;
												},
												model.C.ca))));
							});
						var retained = A2(
							$elm$core$Maybe$withDefault,
							_List_Nil,
							A2(
								$elm$core$Maybe$andThen,
								function (selected) {
									return A2(
										$elm$core$Maybe$map,
										function (snapshot) {
											var state = A2(
												$elm$core$Maybe$withDefault,
												'unavailable',
												A2(
													$elm$core$Maybe$map,
													A2(
														$elm$core$Basics$composeR,
														function ($) {
															return $.cX;
														},
														$author$project$Notifications$entryStateName),
													$elm$core$List$head(
														A2(
															$elm$core$List$filter,
															function (entry) {
																return _Utils_eq(entry.cc, selected.fK.cc) && (_Utils_eq(entry.au, selected.fK.au) && _Utils_eq(entry.ag, selected.fK.ag));
															},
															snapshot.ak))));
											var exists = A2(
												$elm$core$List$any,
												function (row) {
													return _Utils_eq(
														row.cc,
														$author$project$Notifications$identity(selected.fK));
												},
												A2(
													$elm$core$List$concatMap,
													entryRows(snapshot),
													snapshot.ak));
											return exists ? _List_Nil : _List_fromArray(
												[
													{
													f: selected.d6 + '; unavailable',
													g: state + ' · Action unavailable',
													h: A2(
														$author$project$Desktop$key,
														model,
														$author$project$Notifications$identity(selected.fK)),
													b9: false,
													cc: $author$project$Notifications$identity(selected.fK),
													d6: selected.d6,
													d: $elm$core$Maybe$Nothing
												}
												]);
										},
										model.C.c);
								},
								model.C.ca));
						return _Utils_ap(
							_List_fromArray(
								[
									A5(control, 'control:close', 'Close notifications', '', true, $author$project$Desktop$CloseNotifications),
									A5(
									control,
									'notifications:refresh',
									'Refresh notifications',
									(!_Utils_eq(model.aX, $elm$core$Maybe$Nothing)) ? 'Reading current targets…' : 'Read current targets; no action is repeated',
									true,
									$author$project$Desktop$RefreshNotifications)
								]),
							_Utils_ap(
								_List_fromArray(
									[
										A5(
										control,
										'notifications:dnd',
										'Do not disturb for this session',
										model.C.ft.cC ? 'On · History still updates' : 'Off',
										true,
										function (stamp) {
											return A2(
												$author$project$Desktop$ConfigureNotificationPolicy,
												stamp,
												{cC: !model.C.ft.cC, d1: model.C.ft.d1});
										}),
										A5(
										control,
										'notifications:critical-interrupt',
										'Allow critical notification interruptions for this session',
										model.C.ft.d1 ? 'On · Only when Do not disturb is off' : 'Off · New notifications are polite',
										true,
										function (stamp) {
											return A2(
												$author$project$Desktop$ConfigureNotificationPolicy,
												stamp,
												{cC: model.C.ft.cC, d1: !model.C.ft.d1});
										})
									]),
								_Utils_ap(
									A2(
										$elm$core$Maybe$withDefault,
										_List_Nil,
										A2(
											$elm$core$Maybe$map,
											function (snapshot) {
												return A2(
													$elm$core$List$concatMap,
													entryRows(snapshot),
													snapshot.ak);
											},
											model.C.c)),
									retained)));
					} else {
						if (model.p) {
							var shortcutReady = $author$project$ShortcutPreferences$writable(model.ah) && _Utils_eq(model.aM, $elm$core$Maybe$Nothing);
							var scoped = function (message) {
								return A2(
									$elm$core$Maybe$map,
									message,
									$author$project$Desktop$capture(model));
							};
							var ready = $author$project$Settings$writable(model.ap) && _Utils_eq(model.bi, $elm$core$Maybe$Nothing);
							var motionReady = $author$project$MotionPreferences$writable(model.M.aY) && _Utils_eq(model.aH, $elm$core$Maybe$Nothing);
							var draft = model.ap.e2;
							var control = F5(
								function (identity, label, detail, enabled, message) {
									return {
										f: label,
										g: detail,
										h: A2(
											$author$project$Desktop$key,
											model,
											(identity === 'control:close') ? 'settings:close' : identity),
										b9: enabled,
										cc: identity,
										d6: label,
										d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
									};
								});
							var guidance = (!model.cT) ? _List_Nil : _List_fromArray(
								[
									A5(control, 'settings:help:text:keyboard', 'Keyboard navigation', 'Tab and Shift+Tab move focus. Arrows move through lists; Home/End reach endpoints. Enter chooses; Escape closes.', false, $author$project$Desktop$ToggleSettingsHelp),
									A5(control, 'settings:help:text:preferences', 'Keeping your preferences', 'Save applies appearance preferences. Motion has its own Save. Dismissing help keeps unsaved edits.', false, $author$project$Desktop$ToggleSettingsHelp),
									A5(control, 'settings:help:text:recovery', 'When an action is not confirmed', 'Pending is waiting; Refused did not proceed; Unknown is unconfirmed. Refresh reads state without repeating an action.', false, $author$project$Desktop$ToggleSettingsHelp)
								]);
							var motionOption = function (selected) {
								return A5(
									control,
									'settings:motion:' + function () {
										switch (selected) {
											case 0:
												return 'system';
											case 1:
												return 'reduced';
											default:
												return 'full';
										}
									}(),
									$author$project$MotionPreferences$label(selected),
									_Utils_eq(model.M.aY.e2, selected) ? 'Selected' : '',
									motionReady,
									function (stamp) {
										return A2($author$project$Desktop$EditMotionPreference, stamp, selected);
									});
							};
							var scale = function (percent) {
								return A5(
									control,
									'settings:scale:' + $elm$core$String$fromInt(percent),
									'Text size ' + ($elm$core$String$fromInt(percent) + '%'),
									_Utils_eq(model.ap.e2.cp, percent) ? 'Selected' : '',
									ready,
									function (stamp) {
										return A2(
											$author$project$Desktop$EditSettings,
											stamp,
											_Utils_update(
												draft,
												{cp: percent}));
									});
							};
							var shortcutRoute = function (route) {
								var option = F3(
									function (selected, suffix, enabled) {
										return A5(
											control,
											'settings:shortcuts:' + (route + (':' + $author$project$ShortcutPreferences$name(selected))),
											suffix,
											_Utils_eq(
												A2($author$project$ShortcutPreferences$choices, route, model.ah.e2),
												selected) ? 'Selected' : '',
											shortcutReady && enabled,
											function (stamp) {
												return A3($author$project$Desktop$EditShortcutChoice, stamp, route, selected);
											});
									});
								var observed = A2(
									$elm$core$Maybe$map,
									$author$project$ShortcutPreferences$row(route),
									model.ah.cH);
								var label = $author$project$ShortcutPreferences$label(route);
								var state = A2(
									$elm$core$Maybe$withDefault,
									label + ': live bindings unavailable',
									A2(
										$elm$core$Maybe$map,
										function (row) {
											return label + (': ' + ((row.dC === 1) ? 'existing shortcut preserved' : ((row.dC === 2) ? row.e0 : row.eX)));
										},
										observed));
								return _List_fromArray(
									[
										A5(control, 'settings:shortcuts:' + (route + ':state'), state, '', false, $author$project$Desktop$RefreshShortcutChoices),
										A3(option, 1, 'Keep existing shortcut for ' + label, true),
										A3(
										option,
										2,
										'Use ' + (label + ' default'),
										A2(
											$elm$core$Maybe$withDefault,
											false,
											A2(
												$elm$core$Maybe$map,
												function ($) {
													return $.c8;
												},
												observed))),
										A5(
										control,
										'settings:shortcuts:' + (route + ':default:state'),
										A2(
											$elm$core$Maybe$withDefault,
											'Default unavailable',
											A2(
												$elm$core$Maybe$map,
												function (row) {
													return _Utils_ap(
														row.e0,
														row.c8 ? ' · Available' : ' · Unavailable: existing binding');
												},
												observed)),
										'',
										false,
										$author$project$Desktop$RefreshShortcutChoices),
										A3(
										option,
										3,
										'Use ' + (label + ' alternative'),
										A2(
											$elm$core$Maybe$withDefault,
											false,
											A2(
												$elm$core$Maybe$map,
												function ($) {
													return $.c$;
												},
												observed))),
										A5(
										control,
										'settings:shortcuts:' + (route + ':alternate:state'),
										A2(
											$elm$core$Maybe$withDefault,
											'Alternative unavailable',
											A2(
												$elm$core$Maybe$map,
												function (row) {
													return _Utils_ap(
														row.eX,
														row.c$ ? ' · Available' : ' · Unavailable: existing binding');
												},
												observed)),
										'',
										false,
										$author$project$Desktop$RefreshShortcutChoices)
									]);
							};
							var shortcutControls = A2(
								$elm$core$List$cons,
								A5(control, 'settings:shortcuts:notice:state', model.ah.fj, '', false, $author$project$Desktop$RefreshShortcutChoices),
								_Utils_ap(
									A2(
										$elm$core$List$concatMap,
										shortcutRoute,
										_List_fromArray(
											['applications', 'system', 'notifications'])),
									_List_fromArray(
										[
											A5(
											control,
											'settings:shortcuts:save',
											'Save shortcut choices',
											'Apply only the free chosen chords; preserve existing bindings',
											_Utils_eq(model.aM, $elm$core$Maybe$Nothing) && ($author$project$ShortcutPreferences$ready(model.ah) && $author$project$ShortcutPreferences$changed(model.ah)),
											$author$project$Desktop$SaveShortcutChoices),
											A5(
											control,
											'settings:shortcuts:refresh',
											'Refresh shortcut choices',
											'Read stored choices and live bindings without repeating an action',
											_Utils_eq(model.aM, $elm$core$Maybe$Nothing),
											$author$project$Desktop$RefreshShortcutChoices)
										])));
							var theme = F2(
								function (selected, label) {
									return A5(
										control,
										'settings:theme:' + $author$project$Settings$themeName(selected),
										label,
										_Utils_eq(model.ap.e2.cY, selected) ? 'Selected' : '',
										ready,
										function (stamp) {
											return A2(
												$author$project$Desktop$EditSettings,
												stamp,
												_Utils_update(
													draft,
													{cY: selected}));
										});
								});
							var changed = A2(
								$elm$core$Maybe$withDefault,
								false,
								A2(
									$elm$core$Maybe$map,
									function (current) {
										return !_Utils_eq(current.bm, model.ap.e2);
									},
									model.ap.c));
							return _Utils_ap(
								_List_fromArray(
									[
										A5(control, 'control:close', 'Close settings', '', true, $author$project$Desktop$CloseSettings),
										A5(
										control,
										'settings:help',
										model.cT ? 'Dismiss help' : 'Show help',
										model.cT ? 'Expanded' : 'Collapsed',
										true,
										$author$project$Desktop$ToggleSettingsHelp)
									]),
								_Utils_ap(
									guidance,
									_Utils_ap(
										_List_fromArray(
											[
												A5(
												control,
												'settings:effects-off',
												'Disable soft effects',
												draft.cD ? 'On' : 'Off',
												ready,
												function (stamp) {
													return A2(
														$author$project$Desktop$EditSettings,
														stamp,
														_Utils_update(
															draft,
															{cD: !draft.cD}));
												}),
												A5(
												control,
												'settings:reduced-transparency',
												'Reduce transparency',
												draft.cK ? 'On' : 'Off',
												ready,
												function (stamp) {
													return A2(
														$author$project$Desktop$EditSettings,
														stamp,
														_Utils_update(
															draft,
															{cK: !draft.cK}));
												})
											]),
										_Utils_ap(
											_List_fromArray(
												[
													A5(
													control,
													'settings:motion',
													$author$project$Motion$notice(model.M),
													model.M.aY.fj,
													false,
													$author$project$Desktop$RefreshMotionPreference),
													motionOption(0),
													motionOption(1),
													motionOption(2),
													A5(
													control,
													'settings:motion:save',
													'Save motion preference',
													'Apply and keep across restart',
													motionReady && (!_Utils_eq(
														model.M.aY.e2,
														$author$project$MotionPreferences$selected(model.M.aY))),
													$author$project$Desktop$SaveMotionPreference),
													A5(
													control,
													'settings:motion:refresh',
													'Refresh motion preference',
													'Read stored preference; no write is repeated',
													_Utils_eq(model.aH, $elm$core$Maybe$Nothing),
													$author$project$Desktop$RefreshMotionPreference),
													A2(theme, 0, 'Night theme'),
													A2(theme, 1, 'Dawn theme'),
													A2(theme, 2, 'High contrast theme')
												]),
											_Utils_ap(
												A2(
													$elm$core$List$map,
													scale,
													_List_fromArray(
														[100, 125, 150, 200])),
												_Utils_ap(
													_List_fromArray(
														[
															A5(control, 'settings:save', 'Save settings', 'Apply and keep across restart', ready && changed, $author$project$Desktop$SaveSettings),
															A5(
															control,
															'settings:refresh',
															'Refresh settings',
															'Read stored values; discard unsaved changes',
															_Utils_eq(model.bi, $elm$core$Maybe$Nothing),
															$author$project$Desktop$RefreshSettings)
														]),
													shortcutControls))))));
						} else {
							if (!_Utils_eq(model.w, $elm$core$Maybe$Nothing)) {
								var _v7 = model.w;
								if (_v7.$ === 1) {
									return _List_Nil;
								} else {
									var choice = _v7.a;
									var scoped = function (message) {
										return A2(
											$elm$core$Maybe$map,
											message,
											$author$project$Desktop$capture(model));
									};
									var ready = $author$project$Shell$available(model.a.b);
									var regionControl = function (region) {
										var selected = _Utils_eq(region, choice.bG);
										var identity = 'snap:region:' + $author$project$Snap$identity(region);
										return {
											f: _Utils_ap(
												$author$project$Snap$name(region),
												selected ? '; selected preview' : ''),
											g: selected ? 'Selected' : '',
											h: A2($author$project$Desktop$key, model, identity),
											b9: ready,
											cc: identity,
											d6: $author$project$Snap$name(region),
											d: ready ? scoped(
												function (stamp) {
													return A2($author$project$Desktop$SelectSnap, stamp, region);
												}) : $elm$core$Maybe$Nothing
										};
									};
									var placement = $author$project$Snap$proposal(choice);
									var applyReady = ready && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && (A2(
										$elm$core$Maybe$withDefault,
										false,
										A2(
											$elm$core$Maybe$map,
											function (caps) {
												return A2($elm$core$List$member, 2, caps.ef);
											},
											model.a.b.dc)) && (!_Utils_eq(placement, $elm$core$Maybe$Nothing))));
									var applyLabel = applyReady ? ('Snap to ' + $elm$core$String$toLower(
										$author$project$Snap$name(choice.bG))) : 'Snapping unavailable';
									return A2(
										$elm$core$List$cons,
										{
											f: 'Close snapping',
											g: '',
											h: A2($author$project$Desktop$key, model, 'snap:close'),
											b9: true,
											cc: 'control:close',
											d6: 'Close',
											d: scoped($author$project$Desktop$CloseSnap)
										},
										_Utils_ap(
											A2($elm$core$List$map, regionControl, $author$project$Snap$regions),
											_List_fromArray(
												[
													{
													f: applyLabel,
													g: '',
													h: A2($author$project$Desktop$key, model, 'snap:apply'),
													b9: applyReady,
													cc: 'snap:apply',
													d6: applyLabel,
													d: applyReady ? scoped($author$project$Desktop$ApplySnap) : $elm$core$Maybe$Nothing
												}
												])));
								}
							} else {
								if ($author$project$Desktop$switcherOpen(model)) {
									var selected = A2(
										$elm$core$Maybe$map,
										function ($) {
											return $.n;
										},
										$author$project$Switcher$selected(model.j));
									var scoped = function (message) {
										return A2(
											$elm$core$Maybe$map,
											message,
											$author$project$Desktop$capture(model));
									};
									var control = F4(
										function (identity, label, enabled, message) {
											return {
												f: label,
												g: '',
												h: A2($author$project$Desktop$key, model, identity),
												b9: enabled,
												cc: identity,
												d6: label,
												d: enabled ? scoped(message) : $elm$core$Maybe$Nothing
											};
										});
									var browsing = $author$project$Switcher$phase(model.j) === 2;
									var row = function (family) {
										var ready = browsing && (family.c2 && (!A2($author$project$Surface$familyBlocked, model, family.n)));
										var identity = 'switcher:family:' + $author$project$UInt64$string(family.n);
										var detail = _Utils_eq(
											selected,
											$elm$core$Maybe$Just(family.n)) ? 'Selected' : (family.bR ? 'Minimized' : 'Open');
										return {
											f: _Utils_ap(
												family.bR ? 'Restore ' : 'Activate ',
												_Utils_ap(
													family.d6,
													_Utils_eq(
														selected,
														$elm$core$Maybe$Just(family.n)) ? '; selected' : '')),
											g: detail,
											h: A2($author$project$Desktop$key, model, identity),
											b9: ready,
											cc: identity,
											d6: family.d6,
											d: ready ? scoped(
												function (stamp) {
													return A2($author$project$Desktop$SwitcherChoose, stamp, family.n);
												}) : $elm$core$Maybe$Nothing
										};
									};
									return _Utils_ap(
										_List_fromArray(
											[
												A4(control, 'control:close', 'Cancel window switcher', true, $author$project$Desktop$CloseSwitcher),
												A4(
												control,
												'control:reverse',
												'Previous window',
												true,
												function (stamp) {
													return A2($author$project$Desktop$SwitcherStep, stamp, 1);
												}),
												A4(
												control,
												'control:forward',
												'Next window',
												true,
												function (stamp) {
													return A2($author$project$Desktop$SwitcherStep, stamp, 0);
												}),
												A4(
												control,
												'control:commit',
												'Activate selected window',
												browsing && A2(
													$elm$core$Maybe$withDefault,
													false,
													A2(
														$elm$core$Maybe$map,
														A2(
															$elm$core$Basics$composeR,
															$author$project$Surface$familyBlocked(model),
															$elm$core$Basics$not),
														selected)),
												$author$project$Desktop$CommitSwitcher)
											]),
										A2(
											$elm$core$List$map,
											row,
											$author$project$Switcher$entries(model.j)));
								} else {
									if (model.l) {
										var transferReady = $author$project$Shell$available(model.a.b) && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && (!$author$project$WorkspaceNavigation$blocked(model.J)));
										var scoped = function (message) {
											return A2(
												$elm$core$Maybe$map,
												message,
												$author$project$Desktop$capture(model));
										};
										var transferControl = function (family) {
											var identity = 'overview:transfer:' + $author$project$UInt64$string(family.n);
											var enabled = A2($author$project$Desktop$overviewTransferAvailable, model, family.n);
											return {
												f: 'Move ' + (family.d6 + ' to another workspace'),
												g: '',
												h: A2($author$project$Desktop$key, model, identity),
												b9: enabled,
												cc: identity,
												d6: 'Move ' + (family.d6 + '…'),
												d: enabled ? scoped(
													function (stamp) {
														return A2($author$project$Desktop$OpenOverviewTransfer, stamp, family.n);
													}) : $elm$core$Maybe$Nothing
											};
										};
										var workspaceControl = function (group) {
											return {
												f: 'Browse workspace ' + (group.cG + (group.dC ? '; active workspace' : '')),
												g: _Utils_ap(
													group.dC ? 'Active workspace' : '',
													_Utils_eq(
														model.T,
														$elm$core$Maybe$Just(group.cG)) ? ' • Selected' : ''),
												h: A2($author$project$Desktop$key, model, 'overview:workspace:' + group.cG),
												b9: true,
												cc: 'overview:workspace:' + group.cG,
												d6: 'Workspace ' + group.cG,
												d: scoped(
													function (stamp) {
														return A2(
															$author$project$Desktop$OverviewWorkspace,
															stamp,
															$elm$core$Maybe$Just(group.cG));
													})
											};
										};
										var navigateControl = function (group) {
											var proposed = A2($author$project$Desktop$workspaceNavigationIntent, model, group.cG);
											var ready = (!_Utils_eq(proposed, $elm$core$Maybe$Nothing)) && (transferReady && (_Utils_eq(model.a.b.y, $elm$core$Maybe$Nothing) && _Utils_eq(model.a.b.cE, $elm$core$Maybe$Nothing)));
											var id = 'overview:go:' + group.cG;
											return {
												f: 'Go to empty workspace ' + group.cG,
												g: 'Switch desktop',
												h: A2($author$project$Desktop$key, model, id),
												b9: ready,
												cc: id,
												d6: 'Go to workspace ' + group.cG,
												d: ready ? scoped(
													function (stamp) {
														return A2($author$project$Desktop$OverviewNavigateWorkspace, stamp, group.cG);
													}) : $elm$core$Maybe$Nothing
											};
										};
										var groups = A2(
											$elm$core$Maybe$withDefault,
											_List_Nil,
											$author$project$Desktop$taskViewGroups(model));
										var familyControl = F2(
											function (group, family) {
												var ready = (!$author$project$WorkspaceNavigation$blocked(model.J)) && ($author$project$Shell$available(model.a.b) && (family.c2 && (!A2($author$project$Surface$familyBlocked, model, family.n))));
												var identity = 'overview:family:' + $author$project$UInt64$string(family.n);
												var detail = 'Workspace ' + (group.cG + (' • ' + (A2($author$project$Surface$familyBlocked, model, family.n) ? 'Awaiting native confirmation' : ((!family.c2) ? 'Unavailable for activation' : (family.bR ? 'Minimized' : 'Open')))));
												return {
													f: (family.bR ? 'Restore ' : 'Activate ') + (family.d6 + (' on workspace ' + group.cG)),
													g: detail,
													h: A2($author$project$Desktop$key, model, identity),
													b9: ready,
													cc: identity,
													d6: family.d6,
													d: ready ? scoped(
														function (stamp) {
															return A2($author$project$Desktop$OverviewChoose, stamp, family.n);
														}) : $elm$core$Maybe$Nothing
												};
											});
										var workspaceRows = function (group) {
											return A2(
												$elm$core$List$cons,
												workspaceControl(group),
												_Utils_ap(
													($elm$core$List$isEmpty(group.a) && (!group.dC)) ? _List_fromArray(
														[
															navigateControl(group)
														]) : _List_Nil,
													(_Utils_eq(model.T, $elm$core$Maybe$Nothing) || _Utils_eq(
														model.T,
														$elm$core$Maybe$Just(group.cG))) ? A2(
														$elm$core$List$concatMap,
														function (family) {
															return _List_fromArray(
																[
																	A2(familyControl, group, family),
																	transferControl(family)
																]);
														},
														group.a) : _List_Nil));
										};
										var destinationRows = function (root) {
											return A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2(
													$elm$core$Maybe$map,
													function (geometry) {
														return A2(
															$elm$core$List$filterMap,
															function (destination) {
																return A2(
																	$elm$core$Maybe$map,
																	function (_v8) {
																		var identity = 'overview:destination:' + destination;
																		return {
																			f: 'Move selected window to workspace ' + destination,
																			g: '',
																			h: A2($author$project$Desktop$key, model, identity),
																			b9: transferReady,
																			cc: identity,
																			d6: 'Move to workspace ' + destination,
																			d: transferReady ? scoped(
																				function (stamp) {
																					return A3($author$project$Desktop$OverviewTransfer, stamp, root, destination);
																				}) : $elm$core$Maybe$Nothing
																		};
																	},
																	A3($author$project$Transfer$propose, geometry, root, destination));
															},
															$author$project$Transfer$destinations(geometry));
													},
													model.a.b.ac));
										};
										return (!_Utils_eq(model.Z, $elm$core$Maybe$Nothing)) ? _Utils_ap(
											_List_fromArray(
												[
													{
													f: 'Cancel window transfer',
													g: '',
													h: A2($author$project$Desktop$key, model, 'overview:transfer-cancel'),
													b9: true,
													cc: 'control:close',
													d6: 'Cancel transfer',
													d: scoped($author$project$Desktop$CancelOverviewTransfer)
												}
												]),
											A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2($elm$core$Maybe$map, destinationRows, model.Z))) : _Utils_ap(
											_List_fromArray(
												[
													{
													f: 'Close Task View and return to windows',
													g: '',
													h: A2($author$project$Desktop$key, model, 'overview:close'),
													b9: true,
													cc: 'control:close',
													d6: 'Close Task View',
													d: scoped($author$project$Desktop$CloseOverview)
												},
													{
													f: 'Browse all workspaces',
													g: _Utils_eq(model.T, $elm$core$Maybe$Nothing) ? 'Selected' : '',
													h: A2($author$project$Desktop$key, model, 'overview:all'),
													b9: true,
													cc: 'overview:all',
													d6: 'All windows',
													d: scoped(
														function (stamp) {
															return A2($author$project$Desktop$OverviewWorkspace, stamp, $elm$core$Maybe$Nothing);
														})
												}
												]),
											_Utils_ap(
												A2($elm$core$List$concatMap, workspaceRows, groups),
												_Utils_ap(
													_List_fromArray(
														[
															A2($author$project$Surface$recoveryControl, 'overview:refresh', model)
														]),
													$author$project$WorkspaceNavigation$blocked(model.J) ? _List_fromArray(
														[
															{
															f: 'Read workspace switch status without repeating the action',
															g: '',
															h: A2($author$project$Desktop$key, model, 'overview:workspace-refresh'),
															b9: !model.J.er,
															cc: 'overview:workspace-refresh',
															d6: 'Refresh workspace status',
															d: scoped($author$project$Desktop$RefreshWorkspaceNavigation)
														}
														]) : _List_Nil)));
									} else {
										if (model.q) {
											var size = $author$project$Desktop$applicationPageSize(model);
											var scoped = function (build) {
												return A2(
													$elm$core$Maybe$map,
													build,
													$author$project$Desktop$capture(model));
											};
											var ready = (!model.a.b.c1) && (!A2(
												$elm$core$List$member,
												$author$project$Launch$status(model.B),
												_List_fromArray(
													['Pending', 'Unknown'])));
											var pinIds = $author$project$Desktop$pinIdentities(model);
											var pinAction = F6(
												function (suffix, name, label, detail, allowed, message) {
													return {
														f: A2($author$project$Surface$actionName, label, name),
														g: detail,
														h: A2($author$project$Desktop$key, model, suffix),
														b9: $author$project$Pins$writable(model.H) && allowed,
														cc: suffix,
														d6: $author$project$Surface$displayLabel(label),
														d: ($author$project$Pins$writable(model.H) && allowed) ? scoped(message) : $elm$core$Maybe$Nothing
													};
												});
											var pinRows = F2(
												function (index, identity) {
													var label = A2(
														$elm$core$Maybe$withDefault,
														identity,
														A2(
															$elm$core$Maybe$map,
															function ($) {
																return $.dj;
															},
															A2(
																$elm$core$Maybe$andThen,
																$author$project$Catalog$lookup(identity),
																model.aj)));
													return _List_fromArray(
														[
															A6(
															pinAction,
															'unpin:' + identity,
															label,
															'Unpin ' + label,
															'Pinned application',
															true,
															function (stamp) {
																return A2($author$project$Desktop$TogglePin, stamp, identity);
															}),
															A6(
															pinAction,
															'pin-left:' + identity,
															label,
															'Move ' + (label + ' left'),
															'Pin order',
															index > 0,
															function (stamp) {
																return A3($author$project$Desktop$MovePin, stamp, identity, -1);
															}),
															A6(
															pinAction,
															'pin-right:' + identity,
															label,
															'Move ' + (label + ' right'),
															'Pin order',
															_Utils_cmp(
																index,
																$elm$core$List$length(pinIds) - 1) < 0,
															function (stamp) {
																return A3($author$project$Desktop$MovePin, stamp, identity, 1);
															})
														]);
												});
											var navigation = F4(
												function (identity, label, enabled, direction) {
													return {
														f: label,
														g: '',
														h: A2($author$project$Desktop$key, model, identity),
														b9: enabled,
														cc: identity,
														d6: label,
														d: enabled ? scoped(
															function (stamp) {
																return A2($author$project$Desktop$ApplicationsPage, stamp, direction);
															}) : $elm$core$Maybe$Nothing
													};
												});
											var entryControl = function (entry) {
												var label = 'Open ' + entry.dj;
												var detail = model.a.b.c1 ? 'Opening unavailable in this session' : '';
												var choice = ready ? A2(
													$elm$core$Maybe$map,
													$author$project$Desktop$Start,
													A2(
														$author$project$Launch$select,
														$author$project$Catalog$id(entry.cG),
														model.B)) : $elm$core$Maybe$Nothing;
												return {
													f: A2($author$project$Surface$actionName, label, entry.dj),
													g: detail,
													h: A2(
														$author$project$Desktop$key,
														model,
														'entry:' + $author$project$Catalog$id(entry.cG)),
													b9: !_Utils_eq(choice, $elm$core$Maybe$Nothing),
													cc: 'entry:' + $author$project$Catalog$id(entry.cG),
													d6: $author$project$Surface$displayLabel(label),
													d: choice
												};
											};
											var entries = A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2(
													$elm$core$Maybe$map,
													$author$project$Catalog$search(model.ck),
													model.aj));
											var jump = A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2(
													$elm$core$Maybe$map,
													$elm$core$List$singleton,
													A2(
														$elm$core$Maybe$map,
														function (entry) {
															var label = 'Actions for ' + entry.dj;
															return {
																f: A2($author$project$Surface$actionName, label, entry.dj),
																g: model.a.b.c1 ? 'Application actions unavailable in this session' : 'Application actions and recent files',
																h: A2(
																	$author$project$Desktop$key,
																	model,
																	'jump:open:' + $author$project$Catalog$id(entry.cG)),
																b9: !model.a.b.c1,
																cc: 'jump:open:' + $author$project$Catalog$id(entry.cG),
																d6: $author$project$Surface$displayLabel(label),
																d: model.a.b.c1 ? $elm$core$Maybe$Nothing : scoped(
																	function (stamp) {
																		return A2(
																			$author$project$Desktop$OpenJumpList,
																			stamp,
																			$author$project$Catalog$id(entry.cG));
																	})
															};
														},
														$elm$core$List$head(entries))));
											var pinFirst = A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2(
													$elm$core$Maybe$map,
													$elm$core$List$singleton,
													A2(
														$elm$core$Maybe$andThen,
														function (entry) {
															return A2(
																$elm$core$List$member,
																$author$project$Catalog$id(entry.cG),
																pinIds) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
																A6(
																	pinAction,
																	'pin:' + $author$project$Catalog$id(entry.cG),
																	entry.dj,
																	'Pin ' + entry.dj,
																	'Add to taskbar',
																	true,
																	function (stamp) {
																		return A2(
																			$author$project$Desktop$TogglePin,
																			stamp,
																			$author$project$Catalog$id(entry.cG));
																	}));
														},
														$elm$core$List$head(entries))));
											var prefix = _Utils_ap(
												jump,
												_Utils_ap(
													pinFirst,
													$elm$core$List$concat(
														A2($elm$core$List$indexedMap, pinRows, pinIds))));
											var prefixCount = $elm$core$List$length(prefix);
											var bodyCount = prefixCount + $elm$core$List$length(entries);
											var pages = A2($elm$core$Basics$max, 1, (((bodyCount + size) - 1) / size) | 0);
											var page = A3($elm$core$Basics$clamp, 0, pages - 1, model.ai);
											var offset = page * size;
											var entryOffset = A2($elm$core$Basics$max, 0, offset - prefixCount);
											var visiblePrefix = A2(
												$elm$core$List$take,
												size,
												A2($elm$core$List$drop, offset, prefix));
											var entrySlots = size - $elm$core$List$length(visiblePrefix);
											var visibleEntries = A2(
												$elm$core$List$map,
												entryControl,
												A2(
													$elm$core$List$take,
													entrySlots,
													A2($elm$core$List$drop, entryOffset, entries)));
											var paging = (pages <= 1) ? _List_Nil : _List_fromArray(
												[
													{
													f: 'Application and pin actions page',
													g: $elm$core$String$fromInt(
														$elm$core$List$length(entries)) + (' matching applications · ' + ($elm$core$String$fromInt(
														$elm$core$List$length(pinIds)) + ' pinned')),
													h: A2($author$project$Desktop$key, model, 'page-range'),
													b9: false,
													cc: 'control:page-range',
													d6: 'Items ' + ($elm$core$String$fromInt(offset + 1) + ('–' + ($elm$core$String$fromInt(
														A2($elm$core$Basics$min, bodyCount, offset + size)) + (' of ' + $elm$core$String$fromInt(bodyCount))))),
													d: $elm$core$Maybe$Nothing
												},
													A4(navigation, 'control:page-previous', 'Previous page', page > 0, -1),
													A4(
													navigation,
													'control:page-next',
													'Next page',
													_Utils_cmp(page, pages - 1) < 0,
													1)
												]);
											var acknowledge = A2(
												$elm$core$Maybe$withDefault,
												_List_Nil,
												A2(
													$elm$core$Maybe$map,
													$elm$core$List$singleton,
													A2(
														$elm$core$Maybe$map,
														function (token) {
															return {
																f: 'I checked; allow another launch',
																g: '',
																h: A2($author$project$Desktop$key, model, 'control:acknowledge'),
																b9: true,
																cc: 'control:acknowledge',
																d6: 'I checked; allow another launch',
																d: $elm$core$Maybe$Just(
																	$author$project$Desktop$Acknowledge(token))
															};
														},
														$author$project$Launch$uncertain(model.B))));
											return _Utils_ap(
												_List_fromArray(
													[
														{
														f: 'Search applications',
														g: '',
														h: 'launcher-search',
														b9: true,
														cc: 'control:search',
														d6: model.ck,
														d: scoped(
															function (stamp) {
																return A2($author$project$Desktop$SearchQuery, stamp, model.ck);
															})
													},
														{
														f: 'Close applications and return to windows',
														g: '',
														h: A2($author$project$Desktop$key, model, 'control:close'),
														b9: true,
														cc: 'control:close',
														d6: 'Close applications',
														d: scoped($author$project$Desktop$CloseApplications)
													},
														{
														f: 'Refresh applications',
														g: '',
														h: A2($author$project$Desktop$key, model, 'control:refresh'),
														b9: true,
														cc: 'control:refresh',
														d6: 'Refresh',
														d: scoped($author$project$Desktop$RefreshApplications)
													}
													]),
												_Utils_ap(
													acknowledge,
													_Utils_ap(
														paging,
														_Utils_ap(visiblePrefix, visibleEntries))));
										} else {
											if (!_Utils_eq(
												$author$project$MenuBridge$menuSnapshot(model.a.i).aC,
												$elm$core$Maybe$Nothing)) {
												var _v9 = $author$project$MenuBridge$menuSnapshot(model.a.i).aC;
												if (_v9.$ === 1) {
													return _List_Nil;
												} else {
													var menu = _v9.a;
													var ready = $author$project$Shell$available(model.a.b) && (_Utils_eq(menu.O, $author$project$Menu$Ready) && (!$author$project$Surface$menuBlocked(model)));
													var prefix = 'menu:' + ($elm$core$String$fromInt(
														$author$project$Menu$menuNumber(menu.cc)) + ':');
													var row = F2(
														function (index, item) {
															var committed = A2(
																$elm$core$Maybe$withDefault,
																'',
																A2(
																	$elm$core$Maybe$map,
																	A2(
																		$elm$core$Basics$composeR,
																		$author$project$Provider$incarnation,
																		$author$project$Surface$confirmedWindowState(model)),
																	$author$project$MenuBridge$currentProvider(model.a.i)));
															var detail = A2(
																$elm$core$String$join,
																' • ',
																A2(
																	$elm$core$List$filter,
																	A2($elm$core$Basics$composeL, $elm$core$Basics$not, $elm$core$String$isEmpty),
																	_List_fromArray(
																		[
																			committed,
																			$author$project$Surface$menuBlocked(model) ? 'Awaiting native confirmation' : (_Utils_eq(
																			menu.bG,
																			$elm$core$Maybe$Just(index)) ? 'Selected' : '')
																		])));
															return {
																f: _Utils_ap(
																	item.d6,
																	$author$project$Surface$menuBlocked(model) ? ('; ' + detail) : ''),
																g: detail,
																h: _Utils_ap(
																	prefix,
																	$elm$core$String$fromInt(index)),
																b9: ready && item.b9,
																cc: _Utils_ap(
																	prefix,
																	$elm$core$String$fromInt(index)),
																d6: item.d6,
																d: (ready && item.b9) ? $elm$core$Maybe$Just(
																	$author$project$Desktop$Window(
																		$author$project$TaskbarShell$MenuEvent(
																			A3($author$project$Menu$Activate, menu.cc, menu.c3, index)))) : $elm$core$Maybe$Nothing
															};
														});
													var snap = A2(
														$elm$core$Maybe$andThen,
														function (provider) {
															return A2(
																$elm$core$Maybe$map,
																function (_v10) {
																	return {
																		f: 'Open snapping',
																		g: '',
																		h: prefix + 'snap',
																		b9: ready,
																		cc: 'control:snap-open',
																		d6: 'Snap window',
																		d: ready ? A2(
																			$elm$core$Maybe$map,
																			function (stamp) {
																				return A2(
																					$author$project$Desktop$OpenSnap,
																					stamp,
																					$author$project$Provider$incarnation(provider));
																			},
																			$author$project$Desktop$capture(model)) : $elm$core$Maybe$Nothing
																	};
																},
																A2(
																	$elm$core$Maybe$andThen,
																	function (geometry) {
																		return A2(
																			$author$project$Snap$open,
																			geometry,
																			$author$project$Provider$incarnation(provider));
																	},
																	model.a.b.ac));
														},
														$author$project$MenuBridge$currentProvider(model.a.i));
													var newInstance = A2(
														$elm$core$Maybe$map,
														A2($author$project$Surface$newInstanceControl, model, prefix + 'new-instance'),
														$author$project$Desktop$menuApplication(model));
													var applicationActions = A2(
														$elm$core$Maybe$map,
														function (entry) {
															return {
																f: 'Actions for ' + entry.dj,
																g: 'Declared actions and recent files',
																h: prefix + 'application-actions',
																b9: ready,
																cc: 'jump:open:' + $author$project$Catalog$id(entry.cG),
																d6: 'Application actions',
																d: ready ? A2(
																	$elm$core$Maybe$map,
																	function (stamp) {
																		return A2(
																			$author$project$Desktop$OpenJumpList,
																			stamp,
																			$author$project$Catalog$id(entry.cG));
																	},
																	$author$project$Desktop$capture(model)) : $elm$core$Maybe$Nothing
															};
														},
														$author$project$Desktop$menuApplication(model));
													return A2(
														$elm$core$List$cons,
														{
															f: 'Close window actions',
															g: '',
															h: prefix + 'close',
															b9: true,
															cc: 'control:menu-close',
															d6: 'Close',
															d: $elm$core$Maybe$Just(
																$author$project$Desktop$Window(
																	$author$project$TaskbarShell$MenuEvent(
																		$author$project$Menu$Dismiss(menu.cc))))
														},
														_Utils_ap(
															A2($elm$core$List$indexedMap, row, menu.fd),
															_Utils_ap(
																A2(
																	$elm$core$Maybe$withDefault,
																	_List_Nil,
																	A2($elm$core$Maybe$map, $elm$core$List$singleton, snap)),
																_Utils_ap(
																	A2(
																		$elm$core$Maybe$withDefault,
																		_List_Nil,
																		A2($elm$core$Maybe$map, $elm$core$List$singleton, newInstance)),
																	_Utils_ap(
																		A2(
																			$elm$core$Maybe$withDefault,
																			_List_Nil,
																			A2($elm$core$Maybe$map, $elm$core$List$singleton, applicationActions)),
																		$author$project$Surface$recoveryPopup(model))))));
												}
											} else {
												var _v11 = model.a.G;
												if (!_v11.$) {
													var picker = _v11.a;
													var familyControl = function (family) {
														var ready = $author$project$Shell$available(model.a.b) && (family.c2 && ((!A2($author$project$Surface$familyBlocked, model, family.n)) && _Utils_eq(
															$author$project$Shell$capture(model.a.b),
															$elm$core$Maybe$Just(picker.cQ))));
														var detail = A2(
															$elm$core$String$join,
															' • ',
															A2(
																$elm$core$List$filter,
																A2($elm$core$Basics$composeL, $elm$core$Basics$not, $elm$core$String$isEmpty),
																_List_fromArray(
																	[
																		A2($author$project$Surface$confirmedWindowState, model, family.n),
																		A2($author$project$Surface$familyBlocked, model, family.n) ? 'Awaiting native confirmation' : (family.bR ? 'Minimized' : 'Open')
																	])));
														return {
															f: _Utils_ap(
																family.bR ? 'Restore ' : 'Activate ',
																_Utils_ap(
																	family.d6,
																	A2($author$project$Surface$familyBlocked, model, family.n) ? ('; ' + detail) : '')),
															g: detail,
															h: 'picker:' + ($author$project$Shell$stampKey(picker.cQ) + (':' + ($author$project$UInt64$string(picker.e7) + (':' + $author$project$UInt64$string(family.n))))),
															b9: ready,
															cc: 'family:' + $author$project$UInt64$string(family.n),
															d6: _Utils_ap(
																family.bR ? 'Restore ' : 'Activate ',
																family.d6),
															d: ready ? $elm$core$Maybe$Just(
																$author$project$Desktop$Window(
																	A3($author$project$TaskbarShell$Choose, picker.cQ, picker.e7, family.n))) : $elm$core$Maybe$Nothing
														};
													};
													var families = A2(
														$elm$core$List$concatMap,
														function ($) {
															return $.aB;
														},
														A2(
															$elm$core$List$filter,
															function (group) {
																return _Utils_eq(group.aV, picker.aV);
															},
															$author$project$TaskbarShell$groups(model.a)));
													return A2(
														$elm$core$List$cons,
														{
															f: 'Close window picker',
															g: '',
															h: 'picker-close:' + ($author$project$Shell$stampKey(picker.cQ) + (':' + $author$project$UInt64$string(picker.e7))),
															b9: true,
															cc: 'control:close',
															d6: 'Close',
															d: $elm$core$Maybe$Just(
																$author$project$Desktop$Window(
																	A2($author$project$TaskbarShell$Close, picker.cQ, picker.e7)))
														},
														_Utils_ap(
															A2($elm$core$List$map, familyControl, families),
															$author$project$Surface$recoveryPopup(model)));
												} else {
													return _List_Nil;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
};
var $elm$json$Json$Decode$decodeValue = _Json_run;
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$json$Json$Decode$fail = _Json_fail;
var $elm$json$Json$Decode$string = _Json_decodeString;
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $author$project$UInt64$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return ((!$elm$core$String$isEmpty(value)) && (A2(
			$elm$core$String$all,
			function (c) {
				return (c >= '0') && (c <= '9');
			},
			value) && (((value === '0') || (!A2($elm$core$String$startsWith, '0', value))) && (($elm$core$String$length(value) <= 20) && (($elm$core$String$length(value) < 20) || (value <= '18446744073709551615')))))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Expected canonical uint64 string');
	},
	$elm$json$Json$Decode$string);
var $elm$core$Result$withDefault = F2(
	function (def, result) {
		if (!result.$) {
			var a = result.a;
			return a;
		} else {
			return def;
		}
	});
var $author$project$UInt64$zero = '0';
var $author$project$SystemMenuFocusPipeline$counter = function (value) {
	return A2(
		$elm$core$Result$withDefault,
		$author$project$UInt64$zero,
		A2(
			$elm$json$Json$Decode$decodeValue,
			$author$project$UInt64$decoder,
			$elm$json$Json$Encode$string(value)));
};
var $author$project$SystemMenu$OtherSessionState = function (a) {
	return {$: 1, a: a};
};
var $author$project$SystemMenu$SessionClosing = {$: 0};
var $author$project$SystemMenu$Snapshot = F6(
	function (service, revision, volume, network, power, session) {
		return {fi: network, fu: power, cN: revision, cS: service, fF: session, fO: volume};
	});
var $elm$json$Json$Decode$bool = _Json_decodeBool;
var $author$project$SystemMenu$bounded = function (limit) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return ((_Utils_cmp(
				$elm$core$String$length(value),
				limit) < 1) && (!A2(
				$elm$core$String$any,
				function (c) {
					return $elm$core$Char$toCode(c) < 32;
				},
				value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('System text');
		},
		$elm$json$Json$Decode$string);
};
var $elm$json$Json$Decode$field = _Json_decodeField;
var $elm$json$Json$Decode$int = _Json_decodeInt;
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$json$Json$Decode$map3 = _Json_map3;
var $elm$json$Json$Decode$map6 = _Json_map6;
var $author$project$SystemMenu$networkPermissionDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'yes':
				return $elm$json$Json$Decode$succeed(0);
			case 'no':
				return $elm$json$Json$Decode$succeed(1);
			case 'auth':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Native network permission');
		}
	},
	$elm$json$Json$Decode$string);
var $elm$json$Json$Decode$null = _Json_decodeNull;
var $elm$json$Json$Decode$oneOf = _Json_oneOf;
var $elm$json$Json$Decode$nullable = function (decoder) {
	return $elm$json$Json$Decode$oneOf(
		_List_fromArray(
			[
				$elm$json$Json$Decode$null($elm$core$Maybe$Nothing),
				A2($elm$json$Json$Decode$map, $elm$core$Maybe$Just, decoder)
			]));
};
var $author$project$SystemMenu$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('System identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$SystemMenu$PowerNo = 1;
var $author$project$SystemMenu$PowerUnavailable = 2;
var $author$project$SystemMenu$powerCapabilityDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'yes':
				return $elm$json$Json$Decode$succeed(0);
			case 'no':
				return $elm$json$Json$Decode$succeed(1);
			case 'na':
				return $elm$json$Json$Decode$succeed(2);
			case 'challenge':
				return $elm$json$Json$Decode$succeed(3);
			default:
				return $elm$json$Json$Decode$fail('Native power capability');
		}
	},
	$elm$json$Json$Decode$string);
var $elm$json$Json$Decode$keyValuePairs = _Json_decodeKeyValuePairs;
var $elm$core$List$sortBy = _List_sortBy;
var $elm$core$List$sort = function (xs) {
	return A2($elm$core$List$sortBy, $elm$core$Basics$identity, xs);
};
var $elm$json$Json$Decode$value = _Json_decodeValue;
var $author$project$SystemMenu$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('System fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$SystemMenu$decoder = A2(
	$author$project$SystemMenu$strict,
	_List_fromArray(
		['service', 'revision', 'volume', 'network', 'power', 'session']),
	A7(
		$elm$json$Json$Decode$map6,
		$author$project$SystemMenu$Snapshot,
		A2($elm$json$Json$Decode$field, 'service', $author$project$SystemMenu$positive),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$SystemMenu$positive),
		A2(
			$elm$json$Json$Decode$field,
			'volume',
			$elm$json$Json$Decode$nullable(
				A2(
					$author$project$SystemMenu$strict,
					_List_fromArray(
						['percent', 'muted', 'label']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (percent, muted, label) {
								return {d6: label, di: muted, fp: percent};
							}),
						A2(
							$elm$json$Json$Decode$field,
							'percent',
							A2(
								$elm$json$Json$Decode$andThen,
								function (value) {
									return ((value >= 0) && (value <= 1600)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native volume');
								},
								$elm$json$Json$Decode$int)),
						A2($elm$json$Json$Decode$field, 'muted', $elm$json$Json$Decode$bool),
						A2(
							$elm$json$Json$Decode$field,
							'label',
							$author$project$SystemMenu$bounded(128)))))),
		A2(
			$elm$json$Json$Decode$field,
			'network',
			$elm$json$Json$Decode$nullable(
				A2(
					$author$project$SystemMenu$strict,
					_List_fromArray(
						['enabled', 'state', 'permission']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (enabled, state, permission) {
								return {b9: enabled, fq: permission, cX: state};
							}),
						A2($elm$json$Json$Decode$field, 'enabled', $elm$json$Json$Decode$bool),
						A2(
							$elm$json$Json$Decode$field,
							'state',
							$author$project$SystemMenu$bounded(32)),
						A2($elm$json$Json$Decode$field, 'permission', $author$project$SystemMenu$networkPermissionDecoder))))),
		A2(
			$elm$json$Json$Decode$field,
			'power',
			$elm$json$Json$Decode$nullable(
				A2(
					$author$project$SystemMenu$strict,
					_List_fromArray(
						['suspend', 'reboot', 'poweroff']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (suspend, reboot, poweroff) {
								return {fv: poweroff, fx: reboot, fJ: suspend};
							}),
						A2($elm$json$Json$Decode$field, 'suspend', $author$project$SystemMenu$powerCapabilityDecoder),
						A2($elm$json$Json$Decode$field, 'reboot', $author$project$SystemMenu$powerCapabilityDecoder),
						A2($elm$json$Json$Decode$field, 'poweroff', $author$project$SystemMenu$powerCapabilityDecoder))))),
		A2(
			$elm$json$Json$Decode$field,
			'session',
			$elm$json$Json$Decode$nullable(
				A2(
					$author$project$SystemMenu$strict,
					_List_fromArray(
						['name', 'state', 'locked']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (ownerName, state, locked) {
								return {ff: locked, dj: ownerName, cX: state};
							}),
						A2(
							$elm$json$Json$Decode$field,
							'name',
							$author$project$SystemMenu$bounded(128)),
						A2(
							$elm$json$Json$Decode$field,
							'state',
							A2(
								$elm$json$Json$Decode$map,
								function (observed) {
									return (observed === 'closing') ? $author$project$SystemMenu$SessionClosing : $author$project$SystemMenu$OtherSessionState(observed);
								},
								$author$project$SystemMenu$bounded(32))),
						A2($elm$json$Json$Decode$field, 'locked', $elm$json$Json$Decode$bool)))))));
var $author$project$SurfaceController$desktop = function (_v0) {
	var model = _v0;
	return model.e;
};
var $author$project$SurfaceController$Interaction = function (a) {
	return {$: 0, a: a};
};
var $author$project$Desktop$InvalidateSnap = {$: 7};
var $author$project$SurfaceController$Model = $elm$core$Basics$identity;
var $author$project$Shell$ReconciliationFull = {$: 0};
var $author$project$Shell$RecoveredUnknown = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $author$project$Shell$ReservationReleased = F4(
	function (a, b, c, d) {
		return {$: 2, a: a, b: b, c: c, d: d};
	});
var $author$project$Desktop$Send = function (a) {
	return {$: 1, a: a};
};
var $elm$core$Result$andThen = F2(
	function (callback, result) {
		if (!result.$) {
			var value = result.a;
			return callback(value);
		} else {
			var msg = result.a;
			return $elm$core$Result$Err(msg);
		}
	});
var $elm$core$Result$mapError = F2(
	function (f, result) {
		if (!result.$) {
			var v = result.a;
			return $elm$core$Result$Ok(v);
		} else {
			var e = result.a;
			return $elm$core$Result$Err(
				f(e));
		}
	});
var $author$project$ReconciliationFrame$BindingRetirement = 0;
var $author$project$ReconciliationFrame$Proof = F9(
	function (protocolVersion, kind, retirementProtocol, operation, binding, requestId, queriedBinding, sequence, grantState) {
		return {c3: binding, dZ: grantState, d4: kind, bc: operation, fw: protocolVersion, eo: queriedBinding, eu: requestId, fC: retirementProtocol, eC: sequence};
	});
var $author$project$ReconciliationFrame$Retired = 0;
var $author$project$Binding$Binding = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $author$project$Binding$nonzero = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return _Utils_eq(v, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero identity') : $elm$json$Json$Decode$succeed(v);
	},
	$author$project$UInt64$decoder);
var $author$project$Binding$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (fields) {
		return (!_Utils_eq(
			$elm$core$List$sort(
				A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
			_List_fromArray(
				['frontend', 'lifetime', 'session']))) ? $elm$json$Json$Decode$fail('Binding fields') : A4(
			$elm$json$Json$Decode$map3,
			$author$project$Binding$Binding,
			A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Binding$nonzero),
			A2($elm$json$Json$Decode$field, 'session', $author$project$Binding$nonzero),
			A2($elm$json$Json$Decode$field, 'frontend', $author$project$Binding$nonzero));
	},
	$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
var $author$project$ReconciliationFrame$exactInt = function (n) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (v) {
			return _Utils_eq(v, n) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Unsupported protocol/schema');
		},
		$elm$json$Json$Decode$int);
};
var $author$project$ReconciliationFrame$exactString = function (n) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (v) {
			return _Utils_eq(v, n) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Unexpected frame/status');
		},
		$elm$json$Json$Decode$string);
};
var $elm$json$Json$Decode$map8 = _Json_map8;
var $author$project$ReconciliationFrame$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero authority counter') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$ReconciliationFrame$Observe = 0;
var $author$project$ReconciliationFrame$Retire = 1;
var $author$project$ReconciliationFrame$retirementOperationDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		switch (v) {
			case 'observe':
				return $elm$json$Json$Decode$succeed(0);
			case 'retire':
				return $elm$json$Json$Decode$succeed(1);
			default:
				return $elm$json$Json$Decode$fail('Retirement operation');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$ReconciliationFrame$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Unexpected or missing reconciliation fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$ReconciliationFrame$proofDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (proof) {
		return A2(
			$elm$json$Json$Decode$map,
			function (grantState) {
				return _Utils_update(
					proof,
					{dZ: grantState});
			},
			A2(
				$elm$json$Json$Decode$field,
				'grantState',
				A2(
					$elm$json$Json$Decode$map,
					function (_v1) {
						return 0;
					},
					$author$project$ReconciliationFrame$exactString('Retired'))));
	},
	A2(
		$author$project$ReconciliationFrame$strict,
		_List_fromArray(
			['protocolVersion', 'kind', 'retirementProtocol', 'operation', 'binding', 'requestId', 'queriedBinding', 'sequence', 'grantState']),
		A9(
			$elm$json$Json$Decode$map8,
			F8(
				function (version, kind, protocol, operation, binding, request, queried, sequence) {
					return A9($author$project$ReconciliationFrame$Proof, version, kind, protocol, operation, binding, request, queried, sequence, 0);
				}),
			A2(
				$elm$json$Json$Decode$field,
				'protocolVersion',
				$author$project$ReconciliationFrame$exactInt(3)),
			A2(
				$elm$json$Json$Decode$field,
				'kind',
				A2(
					$elm$json$Json$Decode$map,
					function (_v0) {
						return 0;
					},
					$author$project$ReconciliationFrame$exactString('binding-retirement'))),
			A2(
				$elm$json$Json$Decode$field,
				'retirementProtocol',
				$author$project$ReconciliationFrame$exactInt(1)),
			A2($elm$json$Json$Decode$field, 'operation', $author$project$ReconciliationFrame$retirementOperationDecoder),
			A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
			A2($elm$json$Json$Decode$field, 'requestId', $author$project$ReconciliationFrame$positive),
			A2($elm$json$Json$Decode$field, 'queriedBinding', $author$project$Binding$decoder),
			A2($elm$json$Json$Decode$field, 'sequence', $author$project$ReconciliationFrame$positive))));
var $author$project$Binding$sameLifetime = F2(
	function (life, _v0) {
		var lifetime = _v0.a;
		return _Utils_eq(life, lifetime);
	});
var $author$project$ReconciliationTracking$announce = F3(
	function (current, raw, model) {
		return A2(
			$elm$core$Result$andThen,
			function (proof) {
				var newer = function (slot) {
					return A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							function (old) {
								return A2($author$project$UInt64$compare, proof.eC, old.eC) === 2;
							},
							slot.el));
				};
				var informationalScopeChanged = A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (active) {
							return !_Utils_eq(active.eo, proof.eo);
						},
						model.ba));
				var eligible = function (slot) {
					return _Utils_eq(slot.fz.c3, proof.eo) && A2($author$project$Binding$sameLifetime, slot.fz.af.R.fe, current);
				};
				var anotherActiveScope = A2(
					$elm$core$List$any,
					function (slot) {
						return (!slot.cL) && A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (active) {
									return !_Utils_eq(active.eo, proof.eo);
								},
								slot.el));
					},
					model.P);
				return (anotherActiveScope || (informationalScopeChanged || ((!_Utils_eq(proof.c3, current)) || (_Utils_eq(proof.eo, current) || ((!A2($elm$core$List$any, eligible, model.P)) || (!A2(
					$elm$core$List$all,
					function (slot) {
						return (!eligible(slot)) || newer(slot);
					},
					model.P))))))) ? $elm$core$Result$Err('Uncorrelated proof announcement') : $elm$core$Result$Ok(
					_Utils_update(
						model,
						{
							ba: A2(
								$elm$core$List$any,
								function (slot) {
									return eligible(slot) && (!slot.cL);
								},
								model.P) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(proof),
							P: A2(
								$elm$core$List$map,
								function (slot) {
									return eligible(slot) ? _Utils_update(
										slot,
										{
											eV: $elm$core$Maybe$Nothing,
											bK: $elm$core$Maybe$Nothing,
											ac: $elm$core$Maybe$Nothing,
											a8: $elm$core$Maybe$Nothing,
											el: $elm$core$Maybe$Just(proof)
										}) : slot;
								},
								model.P)
						}));
			},
			A2(
				$elm$core$Result$mapError,
				$elm$json$Json$Decode$errorToString,
				A2($elm$json$Json$Decode$decodeValue, $author$project$ReconciliationFrame$proofDecoder, raw)));
	});
var $author$project$Desktop$KeyboardEntry = 1;
var $author$project$Desktop$OpenApplications = function (a) {
	return {$: 12, a: a};
};
var $author$project$Desktop$OpenFiles = function (a) {
	return {$: 21, a: a};
};
var $author$project$Desktop$OpenNotifications = function (a) {
	return {$: 33, a: a};
};
var $author$project$Desktop$OpenOverview = function (a) {
	return {$: 51, a: a};
};
var $author$project$Desktop$OpenSettings = function (a) {
	return {$: 39, a: a};
};
var $author$project$Desktop$OpenSwitcher = F2(
	function (a, b) {
		return {$: 52, a: a, b: b};
	});
var $author$project$TaskbarShell$Primary = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $author$project$Shell$Reconnect = {$: 5};
var $author$project$Desktop$RetryWindows = {$: 75};
var $author$project$Taskbar$Unavailable = {$: 3};
var $author$project$Desktop$pinnedGroup = F2(
	function (identity, model) {
		var _v0 = A2($author$project$Desktop$pinGroups, identity, model);
		if (_v0.b && (!_v0.b.b)) {
			var group = _v0.a;
			return $elm$core$Maybe$Just(group);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Effects$Activate = {$: 2};
var $author$project$Taskbar$Apply = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Taskbar$Launch = {$: 0};
var $author$project$Effects$Minimize = {$: 0};
var $author$project$Taskbar$Picker = {$: 1};
var $author$project$Effects$Restore = {$: 1};
var $author$project$Taskbar$primary = F2(
	function (pinned, families) {
		if (!families.b) {
			return pinned ? $author$project$Taskbar$Launch : $author$project$Taskbar$Unavailable;
		} else {
			if (!families.b.b) {
				var entry = families.a;
				return (!entry.c2) ? $author$project$Taskbar$Unavailable : (entry.bR ? A2($author$project$Taskbar$Apply, $author$project$Effects$Restore, entry.n) : (entry.dC ? A2($author$project$Taskbar$Apply, $author$project$Effects$Minimize, entry.n) : A2($author$project$Taskbar$Apply, $author$project$Effects$Activate, entry.n)));
			} else {
				return $author$project$Taskbar$Picker;
			}
		}
	});
var $author$project$Surface$barControls = function (model) {
	var workspaceRecovery = ((!(!model.a.b.m)) && A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (record) {
				return record.O === 1;
			},
			model.J.fz))) ? _List_fromArray(
		[
			{
			f: 'Read workspace switch status without repeating the action',
			g: 'Observation only',
			h: A2($author$project$Desktop$key, model, 'workspace-refresh'),
			b9: !model.J.er,
			cc: 'bar:workspace-refresh',
			d6: 'Refresh workspace status',
			d: A2(
				$elm$core$Maybe$map,
				$author$project$Desktop$RefreshWorkspaceNavigation,
				$author$project$Desktop$capture(model))
		}
		]) : _List_Nil;
	var switcher = {
		f: 'Open window switcher',
		g: '',
		h: A2($author$project$Desktop$key, model, 'control:switcher-opener'),
		b9: $author$project$Shell$available(model.a.b) && _Utils_eq(model.k, $elm$core$Maybe$Nothing),
		cc: 'bar:switcher',
		d6: 'Switch windows',
		d: A2(
			$elm$core$Maybe$map,
			function (stamp) {
				return A2($author$project$Desktop$OpenSwitcher, stamp, 0);
			},
			$author$project$Desktop$capture(model))
	};
	var retry = {
		f: 'Refresh windows',
		g: '',
		h: A2($author$project$Desktop$key, model, 'refresh-windows'),
		b9: _Utils_eq(model.k, $elm$core$Maybe$Nothing),
		cc: 'bar:refresh-windows',
		d6: 'Refresh windows',
		d: $elm$core$Maybe$Just($author$project$Desktop$RetryWindows)
	};
	var recovery = ($author$project$Surface$recoveryNeeded(model) && (!(!model.a.b.m))) ? _List_fromArray(
		[
			A2($author$project$Surface$recoveryControl, 'bar:recovery-refresh', model)
		]) : _List_Nil;
	var reconnect = {
		f: 'Reconnect to the window system',
		g: '',
		h: 'reconnect',
		b9: !model.a.b.aK,
		cc: 'bar:reconnect',
		d6: 'Reconnect',
		d: $elm$core$Maybe$Just(
			$author$project$Desktop$Window(
				$author$project$TaskbarShell$Native($author$project$Shell$Reconnect)))
	};
	var pinIds = $author$project$Desktop$pinIdentities(model);
	var owners = function (group) {
		return A2(
			$elm$core$List$filter,
			function (identity) {
				return A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (matched) {
							return _Utils_eq(matched.aV, group.aV);
						},
						A2($author$project$Desktop$pinnedGroup, identity, model)));
			},
			pinIds);
	};
	var overview = {
		f: 'Open Task View',
		g: '',
		h: A2($author$project$Desktop$key, model, 'control:overview-opener'),
		b9: $author$project$Shell$available(model.a.b) && _Utils_eq(model.k, $elm$core$Maybe$Nothing),
		cc: 'bar:overview',
		d6: 'Task View',
		d: A2(
			$elm$core$Maybe$map,
			$author$project$Desktop$OpenOverview,
			$author$project$Desktop$capture(model))
	};
	var ordinaryGroups = A2(
		$elm$core$List$filter,
		function (group) {
			return $elm$core$List$length(
				owners(group)) !== 1;
		},
		$author$project$TaskbarShell$groups(model.a));
	var groupControl = function (group) {
		var state = function () {
			var _v6 = group.aB;
			if (_v6.b && (!_v6.b.b)) {
				var family = _v6.a;
				return family.bR ? 'Minimized' : (family.dC ? 'Active' : 'Open');
			} else {
				return (A2(
					$elm$core$List$any,
					function ($) {
						return $.dC;
					},
					group.aB) ? 'Active; ' : '') + ($elm$core$String$fromInt(
					$elm$core$List$length(group.aB)) + ' windows');
			}
		}();
		var scoped = $author$project$Shell$capture(model.a.b);
		var operation = function () {
			var _v2 = A2($author$project$Taskbar$primary, false, group.aB);
			_v2$4:
			while (true) {
				switch (_v2.$) {
					case 2:
						switch (_v2.a.$) {
							case 0:
								var _v3 = _v2.a;
								return 'Minimize ';
							case 1:
								var _v4 = _v2.a;
								return 'Restore ';
							case 2:
								var _v5 = _v2.a;
								return 'Activate ';
							default:
								break _v2$4;
						}
					case 1:
						return 'Choose a window from ';
					default:
						break _v2$4;
				}
			}
			return 'Unavailable ';
		}();
		var label = A2(
			$elm$core$Maybe$withDefault,
			'Windows',
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.d6;
				},
				$elm$core$List$head(group.aB)));
		var blocked = function () {
			var _v1 = A2($author$project$Taskbar$primary, false, group.aB);
			if (_v1.$ === 2) {
				var incarnation = _v1.b;
				return A2($author$project$Surface$familyBlocked, model, incarnation);
			} else {
				return false;
			}
		}();
		var ready = $author$project$Shell$available(model.a.b) && ((!_Utils_eq(
			A2($author$project$Taskbar$primary, false, group.aB),
			$author$project$Taskbar$Unavailable)) && (!blocked));
		var attention = A2(
			$elm$core$List$any,
			function ($) {
				return $.dF;
			},
			group.aB) && (!A2(
			$elm$core$List$any,
			function ($) {
				return $.dC;
			},
			group.aB));
		var observedState = attention ? ('Attention; ' + state) : state;
		return {
			f: operation + (label + ('; ' + (observedState + (blocked ? '; awaiting native confirmation' : '')))),
			g: blocked ? ('Awaiting native confirmation; ' + observedState) : observedState,
			h: A2(
				$elm$core$Maybe$withDefault,
				'detached-group',
				A2(
					$elm$core$Maybe$map,
					function (stamp) {
						return 'group:' + ($author$project$Shell$stampKey(stamp) + (':' + group.aV));
					},
					scoped)),
			b9: ready,
			cc: 'bar:group:' + group.aV,
			d6: label,
			d: ready ? A2(
				$elm$core$Maybe$map,
				function (stamp) {
					return $author$project$Desktop$Window(
						A2($author$project$TaskbarShell$Primary, stamp, group.aV));
				},
				scoped) : $elm$core$Maybe$Nothing
		};
	};
	var pinControl = function (identity) {
		var entry = A2(
			$elm$core$Maybe$andThen,
			$author$project$Catalog$lookup(identity),
			model.aj);
		var label = A2(
			$elm$core$Maybe$withDefault,
			identity,
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.dj;
				},
				entry));
		var disabled = function (reason) {
			return {
				f: A2(
					$author$project$Surface$actionName,
					_Utils_ap(reason, label),
					label),
				g: reason,
				h: A2($author$project$Desktop$key, model, 'pin:' + identity),
				b9: false,
				cc: 'bar:pin:' + identity,
				d6: label,
				d: $elm$core$Maybe$Nothing
			};
		};
		var choice = $author$project$Shell$available(model.a.b) ? A2(
			$elm$core$Maybe$map,
			$author$project$Desktop$Start,
			A2($author$project$Launch$select, identity, model.B)) : $elm$core$Maybe$Nothing;
		var _v0 = A2($author$project$Desktop$pinnedGroup, identity, model);
		if (!_v0.$) {
			var group = _v0.a;
			if ($elm$core$List$length(
				owners(group)) === 1) {
				var control = groupControl(group);
				return _Utils_update(
					control,
					{
						f: A2($author$project$Surface$actionName, control.f, label),
						g: 'Pinned; ' + control.g,
						cc: 'bar:pin:' + identity,
						d6: label
					});
			} else {
				return disabled('Ambiguous application identity: ');
			}
		} else {
			return _Utils_eq(entry, $elm$core$Maybe$Nothing) ? disabled('Unavailable application: ') : ((!$elm$core$List$isEmpty(
				A2($author$project$Desktop$pinGroups, identity, model))) ? disabled('Ambiguous application identity: ') : {
				f: A2($author$project$Surface$actionName, 'Open ' + label, label),
				g: model.a.b.c1 ? 'Pinned · Opening unavailable in this session' : 'Pinned launcher',
				h: A2($author$project$Desktop$key, model, 'pin:' + identity),
				b9: !_Utils_eq(choice, $elm$core$Maybe$Nothing),
				cc: 'bar:pin:' + identity,
				d6: label,
				d: choice
			});
		}
	};
	var applications = _Utils_ap(
		A2($elm$core$List$map, pinControl, pinIds),
		A2($elm$core$List$map, groupControl, ordinaryGroups));
	var application = {
		f: 'Open applications',
		g: '',
		h: A2($author$project$Desktop$key, model, 'control:opener'),
		b9: !(!model.a.b.m),
		cc: 'bar:applications',
		d6: 'Applications',
		d: A2(
			$elm$core$Maybe$map,
			$author$project$Desktop$OpenApplications,
			$author$project$Desktop$capture(model))
	};
	var compactPins = $elm$core$List$isEmpty(pinIds) ? _List_Nil : _List_fromArray(
		[
			{
			f: 'Open Applications for every pin action',
			g: 'Compact taskbar; full pin order retained',
			h: A2($author$project$Desktop$key, model, 'pins-summary'),
			b9: application.b9,
			cc: 'bar:pins-summary',
			d6: $elm$core$String$fromInt(
				$elm$core$List$length(pinIds)) + ' pinned applications',
			d: application.d
		}
		]);
	var utilities = A2(
		$elm$core$List$cons,
		(!model.a.b.m) ? reconnect : application,
		A2(
			$elm$core$List$cons,
			overview,
			A2(
				$elm$core$List$cons,
				switcher,
				A2(
					$elm$core$List$cons,
					{
						f: 'Open notifications',
						g: '',
						h: A2($author$project$Desktop$key, model, 'notifications:opener'),
						b9: !_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing),
						cc: 'bar:notifications',
						d6: 'Notifications' + A2(
							$elm$core$Maybe$withDefault,
							'',
							A2(
								$elm$core$Maybe$map,
								function (snapshot) {
									var count = $elm$core$List$length(
										A2(
											$elm$core$List$filter,
											function (entry) {
												return !entry.cX;
											},
											snapshot.ak));
									return (!count) ? '' : (' · ' + $elm$core$String$fromInt(count));
								},
								model.C.c)),
						d: A2(
							$elm$core$Maybe$map,
							$author$project$Desktop$OpenNotifications,
							$author$project$Desktop$capture(model))
					},
					A2(
						$elm$core$List$cons,
						{
							f: 'Open Files menu',
							g: '',
							h: A2($author$project$Desktop$key, model, 'files:opener'),
							b9: !_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing),
							cc: 'bar:files',
							d6: 'Files',
							d: A2(
								$elm$core$Maybe$map,
								$author$project$Desktop$OpenFiles,
								$author$project$Desktop$capture(model))
						},
						A2(
							$elm$core$List$cons,
							{
								f: 'Open system menu',
								g: '',
								h: A2($author$project$Desktop$key, model, 'system:opener'),
								b9: !_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing),
								cc: 'bar:system',
								d6: 'System',
								d: A2(
									$elm$core$Maybe$map,
									$author$project$Desktop$OpenSystemMenu,
									$author$project$Desktop$capture(model))
							},
							A2(
								$elm$core$List$cons,
								{
									f: 'Open settings',
									g: '',
									h: A2($author$project$Desktop$key, model, 'settings:opener'),
									b9: !_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing),
									cc: 'bar:settings',
									d6: 'Settings',
									d: A2(
										$elm$core$Maybe$map,
										$author$project$Desktop$OpenSettings,
										$author$project$Desktop$capture(model))
								},
								_List_Nil)))))));
	var supportedUtilities = model.a.b.c1 ? A2(
		$elm$core$List$map,
		function (control) {
			return A2(
				$elm$core$List$member,
				control.cc,
				_List_fromArray(
					['bar:notifications', 'bar:files', 'bar:system', 'bar:settings'])) ? _Utils_update(
				control,
				{b9: false, d: $elm$core$Maybe$Nothing}) : control;
		},
		utilities) : utilities;
	return model.bA ? _Utils_ap(
		workspaceRecovery,
		_Utils_ap(
			recovery,
			_Utils_ap(
				_List_fromArray(
					[application]),
				compactPins))) : _Utils_ap(
		workspaceRecovery,
		_Utils_ap(
			recovery,
			_Utils_ap(
				(!model.a.b.m) ? _Utils_ap(supportedUtilities, applications) : _Utils_ap(applications, supportedUtilities),
				((!$elm$core$String$isEmpty(model.D)) && (!(!model.a.b.m))) ? _List_fromArray(
					[retry]) : _List_Nil)));
};
var $author$project$Surface$capacityStatus = F2(
	function (model, value) {
		return (model.bA && ($elm$core$String$length(value) > 1024)) ? (A2($author$project$Surface$displayPrefix, 1023, value) + '…') : value;
	});
var $author$project$Settings$defaults = {cD: false, cK: false, cp: 100, cY: 0};
var $elm$core$String$slice = _String_slice;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $author$project$Settings$encodeValues = function (values) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'theme',
				$elm$json$Json$Encode$string(
					$author$project$Settings$themeName(values.cY))),
				_Utils_Tuple2(
				'textScale',
				$elm$json$Json$Encode$int(values.cp)),
				_Utils_Tuple2(
				'effectsOff',
				$elm$json$Json$Encode$bool(values.cD)),
				_Utils_Tuple2(
				'reducedTransparency',
				$elm$json$Json$Encode$bool(values.cK))
			]));
};
var $author$project$Notifications$focusedIdentity = function (model) {
	return A2(
		$elm$core$Maybe$map,
		A2(
			$elm$core$Basics$composeR,
			function ($) {
				return $.fK;
			},
			$author$project$Notifications$identity),
		model.ca);
};
var $author$project$Provider$geometryObservation = function (_v0) {
	var state = _v0;
	return state.ac;
};
var $elm$json$Json$Encode$list = F2(
	function (func, entries) {
		return _Json_wrap(
			A3(
				$elm$core$List$foldl,
				_Json_addEntry(func),
				_Json_emptyArray(0),
				entries));
	});
var $author$project$Provider$getBinding = function (_v0) {
	var value = _v0;
	return value.c3;
};
var $author$project$Provider$menuBinding = $author$project$Provider$getBinding;
var $author$project$Motion$name = function (profile) {
	if (!profile) {
		return 'reduced';
	} else {
		return 'full';
	}
};
var $author$project$Provider$nativeBinding = function (_v0) {
	var value = _v0;
	return value.R.eb;
};
var $author$project$Effects$Cancelled = 3;
var $author$project$WorkspaceNavigation$notice = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		'',
		A2(
			$elm$core$Maybe$map,
			function (r) {
				return 'Workspace ' + (r.af.bp.cG + (': ' + function () {
					var _v0 = r.O;
					switch (_v0) {
						case 0:
							return 'switching…';
						case 1:
							return 'switch could not be confirmed. Refresh workspace status; do not try again.';
						case 2:
							return 'now active.';
						default:
							return 'switch refused (' + (r.ep + '). Choose again after refreshing.');
					}
				}()));
			},
			model.fz));
};
var $author$project$Surface$reservationReason = 'Window action awaits native confirmation. Refresh status only reads observations; it does not retry the action.';
var $elm$core$String$left = F2(
	function (n, string) {
		return (n < 1) ? '' : A3($elm$core$String$slice, 0, n, string);
	});
var $author$project$Shell$status = function (model) {
	if (model.cl) {
		return 'Window recovery history is full. Restart the shell to continue.';
	} else {
		if (model.aa) {
			return 'Window transport is full or unavailable. Waiting for a verified output or capacity update.';
		} else {
			var _v0 = A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.O;
				},
				model.V.dz);
			_v0$3:
			while (true) {
				if (!_v0.$) {
					switch (_v0.a) {
						case 0:
							var _v1 = _v0.a;
							return 'Applying window change…';
						case 4:
							var _v2 = _v0.a;
							return model.fj + ' The last request could not be confirmed.';
						case 2:
							var _v3 = _v0.a;
							return model.fj + ' The window change was refused.';
						default:
							break _v0$3;
					}
				} else {
					break _v0$3;
				}
			}
			return model.fj;
		}
	}
};
var $author$project$Surface$windowNotice = function (model) {
	var subject = function (transaction) {
		var operation = function () {
			var _v3 = transaction.af.bc;
			switch (_v3.$) {
				case 0:
					return 'Minimize';
				case 1:
					return 'Restore';
				case 2:
					return 'Activate';
				case 3:
					return 'Maximize';
				case 4:
					return 'Restore size';
				case 5:
					return 'Exit fullscreen';
				case 8:
					return 'Always on top';
				case 9:
					return 'Unpin window';
				case 6:
					return 'Snap';
				default:
					var p = _v3.a;
					return 'Move to workspace ' + p.bp;
			}
		}();
		var label = A2(
			$elm$core$Maybe$withDefault,
			'selected window',
			A2(
				$elm$core$Maybe$map,
				A2(
					$elm$core$Basics$composeR,
					function ($) {
						return $.d6;
					},
					$elm$core$String$left(512)),
				$elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (family) {
							return _Utils_eq(family.n, transaction.af.au);
						},
						A2(
							$elm$core$List$concatMap,
							function ($) {
								return $.aB;
							},
							$author$project$TaskbarShell$groups(model.a))))));
		return _Utils_Tuple2(operation, label);
	};
	var _v0 = model.a.b.V.dz;
	if (!_v0.$) {
		var transaction = _v0.a;
		var _v1 = subject(transaction);
		var operation = _v1.a;
		var label = _v1.b;
		var _v2 = transaction.O;
		switch (_v2) {
			case 0:
				return operation + (': applying to ' + (label + '…'));
			case 4:
				return operation + (': not confirmed for ' + (label + ((!model.a.b.m) ? '. Reconnect to read window status; the action will not be repeated.' : '. Check your windows; Refresh only reads status.')));
			case 2:
				return operation + (': refused for ' + (label + '. Refresh window status, then choose again.'));
			case 3:
				return operation + (': cancelled for ' + (label + '.'));
			default:
				return $author$project$Surface$recoveryNeeded(model) ? $author$project$Surface$reservationReason : $author$project$Shell$status(model.a.b);
		}
	} else {
		return ($author$project$Surface$recoveryNeeded(model) && (!(!model.a.b.m))) ? $author$project$Surface$reservationReason : $author$project$Shell$status(model.a.b);
	}
};
var $author$project$Surface$contextNotice = function (model) {
	if ((!model.l) && (($author$project$Surface$mode(model) === 'closed') && ($author$project$WorkspaceNavigation$notice(model.J) !== ''))) {
		return $author$project$WorkspaceNavigation$notice(model.J);
	} else {
		if (!_Utils_eq(model.o, $elm$core$Maybe$Nothing)) {
			return (!_Utils_eq(model.aU, $elm$core$Maybe$Nothing)) ? 'Reading application actions…' : model.al.fj;
		} else {
			if (model.s) {
				return (!_Utils_eq(model.aR, $elm$core$Maybe$Nothing)) ? 'Reading Files state…' : model.W.fj;
			} else {
				if (model.x) {
					return (!_Utils_eq(model.aP, $elm$core$Maybe$Nothing)) ? 'Reading native system state…' : ((!_Utils_eq(model.t, $elm$core$Maybe$Nothing)) ? 'Confirm or cancel the requested system change.' : model.aq.fj);
				} else {
					if (model.v) {
						return (!_Utils_eq(model.aX, $elm$core$Maybe$Nothing)) ? 'Loading notifications…' : model.C.fj;
					} else {
						if (model.p) {
							return ((!_Utils_eq(model.bi, $elm$core$Maybe$Nothing)) ? 'Loading settings…' : model.ap.fj) + (' · ' + model.ah.fj);
						} else {
							if ($author$project$Desktop$switcherOpen(model)) {
								return ($author$project$Switcher$phase(model.j) === 1) ? 'Loading window activation history…' : ((!_Utils_eq(model.an, $elm$core$Maybe$Nothing)) ? 'Alt+Tab: next window. Alt+Shift+Tab: previous. Release Alt: activate. Escape: cancel.' : 'Tab or Right: next window. Shift+Tab or Left: previous. Enter: activate. Escape: cancel.');
							} else {
								if (model.l) {
									var workspaceFeedback = $author$project$WorkspaceNavigation$notice(model.J);
									var emptyNotice = function () {
										if ($author$project$Surface$recoveryNeeded(model)) {
											return $author$project$Surface$windowNotice(model);
										} else {
											var _v0 = $author$project$Desktop$taskViewGroups(model);
											if (_v0.$ === 1) {
												return 'Waiting for current workspace information. Refresh window status.';
											} else {
												if (!_v0.a.b) {
													return 'No windows to show. Close Task View to return.';
												} else {
													var groups = _v0.a;
													return ((!_Utils_eq(model.T, $elm$core$Maybe$Nothing)) && (!A2(
														$elm$core$List$any,
														function (group) {
															return _Utils_eq(
																model.T,
																$elm$core$Maybe$Just(group.cG)) && (!$elm$core$List$isEmpty(group.a));
														},
														groups))) ? 'This workspace has no windows. Go to its desktop, browse another workspace or close Task View.' : 'Choose a window to reveal its workspace, or browse another workspace.';
												}
											}
										}
									}();
									return _Utils_ap(
										(workspaceFeedback === '') ? '' : (workspaceFeedback + ' · '),
										emptyNotice);
								} else {
									if ($author$project$Surface$mode(model) === 'menu') {
										var _v1 = A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.O;
											},
											$author$project$MenuBridge$menuSnapshot(model.a.i).aC);
										_v1$3:
										while (true) {
											if (!_v1.$) {
												switch (_v1.a.$) {
													case 2:
														var reason = _v1.a.a;
														return reason;
													case 4:
														return 'The operation could not be confirmed.';
													case 1:
														return 'Working…';
													default:
														break _v1$3;
												}
											} else {
												break _v1$3;
											}
										}
										return $author$project$Surface$menuBlocked(model) ? $author$project$Surface$reservationReason : 'Window actions';
									} else {
										if (!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) {
											return 'Updating your window choice…';
										} else {
											if (!$elm$core$String$isEmpty(model.D)) {
												return model.D;
											} else {
												if ((!model.q) && A2(
													$elm$core$Maybe$withDefault,
													false,
													A2(
														$elm$core$Maybe$map,
														function (transaction) {
															return A2(
																$elm$core$List$member,
																transaction.O,
																_List_fromArray(
																	[0, 4, 2, 3]));
														},
														model.a.b.V.dz))) {
													return $author$project$Surface$windowNotice(model);
												} else {
													if ((!$elm$core$String$isEmpty(model.H.fj)) && (model.H.fj !== 'Pin order saved.')) {
														return model.H.fj;
													} else {
														var _v2 = $author$project$Launch$status(model.B);
														switch (_v2) {
															case 'Pending':
																return 'Opening application…';
															case 'Unknown':
																return 'The launch could not be confirmed. Check your windows before opening it again.';
															case 'Submitted':
																return 'Launch submitted.';
															case 'Refused':
																return 'Launch refused. Refresh applications and choose again.';
															default:
																return (!_Utils_eq(model.bn, $elm$core$Maybe$Nothing)) ? (($author$project$Surface$recoveryNeeded(model) && (!(!model.a.b.m))) ? $author$project$Surface$reservationReason : 'Applications were not opened. Choose Applications again.') : (model.q ? ((!_Utils_eq(model.y, $elm$core$Maybe$Nothing)) ? 'Loading applications…' : (_Utils_eq(model.aj, $elm$core$Maybe$Nothing) ? 'Application list unavailable. Refresh to try again.' : (A2(
																	$elm$core$Maybe$withDefault,
																	false,
																	A2(
																		$elm$core$Maybe$map,
																		A2(
																			$elm$core$Basics$composeR,
																			$author$project$Catalog$search(model.ck),
																			$elm$core$List$isEmpty),
																		model.aj)) ? 'No matching applications. Change your search or Refresh.' : ($elm$core$String$isEmpty(
																	$elm$core$String$trim(model.ck)) ? 'Type to search applications.' : (model.a.b.c1 ? 'Matching applications are shown, but opening is unavailable in this session.' : 'Choose a matching application.'))))) : $author$project$Surface$windowNotice(model));
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
};
var $author$project$Surface$notice = function (model) {
	var retainedWindowFeedback = A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (transaction) {
				return A2(
					$elm$core$List$member,
					transaction.O,
					_List_fromArray(
						[0, 4, 2, 3]));
			},
			model.a.b.V.dz));
	var context = _Utils_ap(
		model.bA ? 'Compact presentation; open Applications, search or use pages for every application and pin action. · ' : '',
		$author$project$Surface$contextNotice(model));
	return (($author$project$Surface$mode(model) === 'applications') && (retainedWindowFeedback || $author$project$Surface$recoveryNeeded(model))) ? ($author$project$Surface$windowNotice(model) + (' · ' + context)) : context;
};
var $elm$core$Tuple$pair = F2(
	function (a, b) {
		return _Utils_Tuple2(a, b);
	});
var $author$project$Desktop$gestureAction = function (message) {
	_v0$13:
	while (true) {
		switch (message.$) {
			case 11:
				return false;
			case 15:
				return false;
			case 16:
				return false;
			case 9:
				return false;
			case 8:
				return false;
			case 10:
				return false;
			case 7:
				return false;
			case 73:
				return false;
			case 74:
				return false;
			case 35:
				return false;
			case 70:
				return false;
			case 76:
				return false;
			case 1:
				if (!message.a.$) {
					return false;
				} else {
					break _v0$13;
				}
			default:
				break _v0$13;
		}
	}
	return true;
};
var $author$project$Desktop$workspaceMutation = function (message) {
	switch (message.$) {
		case 57:
			return false;
		case 51:
			return false;
		case 61:
			return false;
		case 59:
			return false;
		case 60:
			return false;
		case 1:
			switch (message.a.$) {
				case 0:
					if (message.a.a.$ === 9) {
						var _v1 = message.a.a;
						return true;
					} else {
						return false;
					}
				case 3:
					var _v2 = message.a;
					return false;
				default:
					return true;
			}
		default:
			return $author$project$Desktop$gestureAction(message);
	}
};
var $author$project$Surface$packet = F3(
	function (publication, lease, model) {
		var checked = function (control) {
			return (model.l && ((control.cc === 'overview:all') || A2($elm$core$String$startsWith, 'overview:workspace:', control.cc))) ? $elm$core$Maybe$Just(
				(control.cc === 'overview:all') ? _Utils_eq(model.T, $elm$core$Maybe$Nothing) : _Utils_eq(
					model.T,
					$elm$core$Maybe$Just(
						A2(
							$elm$core$String$dropLeft,
							$elm$core$String$length('overview:workspace:'),
							control.cc)))) : A2(
				$elm$core$Maybe$andThen,
				function (menu) {
					return A2(
						$elm$core$Maybe$andThen,
						function (_v1) {
							var item = _v1.b;
							var _v2 = item.eV;
							if (_v2.$ === 8) {
								return A2(
									$elm$core$Maybe$andThen,
									function (provider) {
										return ((!_Utils_eq(
											$author$project$Provider$menuBinding(provider),
											menu.c3)) || (!_Utils_eq(
											$elm$core$Maybe$Just(
												$author$project$Provider$nativeBinding(provider)),
											model.a.b.c3))) ? $elm$core$Maybe$Nothing : A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.fr;
											},
											A2(
												$elm$core$Maybe$andThen,
												function ($) {
													return $.dp;
												},
												A2(
													$elm$core$Maybe$andThen,
													$author$project$GeometryProjection$window(
														$author$project$Provider$incarnation(provider)),
													$author$project$Provider$geometryObservation(provider))));
									},
									$author$project$MenuBridge$currentProvider(model.a.i));
							} else {
								return $elm$core$Maybe$Nothing;
							}
						},
						$elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (_v0) {
									var index = _v0.a;
									var item = _v0.b;
									return _Utils_eq(
										control.cc,
										'menu:' + ($elm$core$String$fromInt(
											$author$project$Menu$menuNumber(menu.cc)) + (':' + $elm$core$String$fromInt(index))));
								},
								A2($elm$core$List$indexedMap, $elm$core$Tuple$pair, menu.fd))));
				},
				$author$project$MenuBridge$menuSnapshot(model.a.i).aC);
		};
		var encode = function (control) {
			return $elm$json$Json$Encode$object(
				_Utils_ap(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'id',
							$elm$json$Json$Encode$string(control.cc)),
							_Utils_Tuple2(
							'domId',
							$elm$json$Json$Encode$string(control.h)),
							_Utils_Tuple2(
							'label',
							$elm$json$Json$Encode$string(control.d6)),
							_Utils_Tuple2(
							'ariaLabel',
							$elm$json$Json$Encode$string(control.f)),
							_Utils_Tuple2(
							'detail',
							$elm$json$Json$Encode$string(control.g)),
							_Utils_Tuple2(
							'enabled',
							$elm$json$Json$Encode$bool(
								control.b9 && ((!_Utils_eq(control.d, $elm$core$Maybe$Nothing)) && (!($author$project$WorkspaceNavigation$blocked(model.J) && A2(
									$elm$core$Maybe$withDefault,
									false,
									A2($elm$core$Maybe$map, $author$project$Desktop$workspaceMutation, control.d))))))),
							_Utils_Tuple2(
							'focusOnly',
							$elm$json$Json$Encode$bool(
								model.v && ((!control.b9) && _Utils_eq(
									$author$project$Notifications$focusedIdentity(model.C),
									$elm$core$Maybe$Just(control.cc)))))
						]),
					A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						A2(
							$elm$core$Maybe$map,
							function (value) {
								return _List_fromArray(
									[
										_Utils_Tuple2(
										'checked',
										$elm$json$Json$Encode$bool(value))
									]);
							},
							checked(control)))));
		};
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'surfaceProtocol',
					$elm$json$Json$Encode$int(2)),
					_Utils_Tuple2(
					'keyboardParent',
					$elm$json$Json$Encode$bool(model.bh === 1)),
					_Utils_Tuple2(
					'motion',
					$elm$json$Json$Encode$string(
						$author$project$Motion$name(
							$author$project$Motion$desired(model.M)))),
					_Utils_Tuple2(
					'appearance',
					$author$project$Settings$encodeValues(
						A2(
							$elm$core$Maybe$withDefault,
							$author$project$Settings$defaults,
							A2(
								$elm$core$Maybe$map,
								function ($) {
									return $.bm;
								},
								model.ap.c)))),
					_Utils_Tuple2(
					'publication',
					$elm$json$Json$Encode$string(
						$author$project$UInt64$string(publication))),
					_Utils_Tuple2(
					'lease',
					$elm$json$Json$Encode$string(
						$author$project$UInt64$string(lease))),
					_Utils_Tuple2(
					'mode',
					$elm$json$Json$Encode$string(
						$author$project$Surface$mode(model))),
					_Utils_Tuple2(
					'status',
					$elm$json$Json$Encode$string(
						A2(
							$author$project$Surface$capacityStatus,
							model,
							_Utils_ap(
								$author$project$Surface$notice(model),
								_Utils_ap(
									((!model.s) && ((!_Utils_eq(model.W.dn, $elm$core$Maybe$Nothing)) || A2($elm$core$String$startsWith, 'Files:', model.W.fj))) ? (' · ' + model.W.fj) : '',
									(_Utils_eq(model.o, $elm$core$Maybe$Nothing) && ((!_Utils_eq(model.al.dn, $elm$core$Maybe$Nothing)) || A2($elm$core$String$startsWith, 'Application action:', model.al.fj))) ? (' · ' + model.al.fj) : ''))))),
					_Utils_Tuple2(
					'bar',
					A2(
						$elm$json$Json$Encode$list,
						encode,
						$author$project$Surface$barControls(model))),
					_Utils_Tuple2(
					'popup',
					A2(
						$elm$json$Json$Encode$list,
						encode,
						$author$project$Surface$controls(model)))
				]));
	});
var $author$project$SurfaceController$frame = function (_v0) {
	var model = _v0;
	return A3($author$project$Surface$packet, model._, model.ae, model.e);
};
var $author$project$Switcher$generation = function (_v0) {
	var model = _v0;
	return model.e7;
};
var $author$project$AdapterNotice$ApplicationActions = 3;
var $author$project$AdapterNotice$Applications = 0;
var $author$project$Desktop$Arm = function (a) {
	return {$: 2, a: a};
};
var $author$project$Desktop$ArmChoice = function (a) {
	return {$: 3, a: a};
};
var $author$project$Desktop$ArmWorkspaceNavigation = function (a) {
	return {$: 4, a: a};
};
var $author$project$Desktop$ChoiceToken = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$AdapterNotice$Files = 2;
var $author$project$Shell$Incoming = function (a) {
	return {$: 3, a: a};
};
var $author$project$Menu$Invalidate = function (a) {
	return {$: 6, a: a};
};
var $author$project$AdapterNotice$Motion = 6;
var $author$project$AdapterNotice$Notifications = 1;
var $author$project$TaskbarShell$OpenMenu = function (a) {
	return {$: 4, a: a};
};
var $author$project$Desktop$OverviewOpener = {$: 1};
var $author$project$Desktop$ScopedShortcut = F2(
	function (a, b) {
		return {$: 9, a: a, b: b};
	});
var $author$project$AdapterNotice$Settings = 5;
var $author$project$AdapterNotice$Shortcuts = 7;
var $author$project$AdapterNotice$System = 4;
var $author$project$Desktop$TaskbarGroup = function (a) {
	return {$: 0, a: a};
};
var $author$project$Launch$Idle = {$: 0};
var $author$project$Launch$Model = $elm$core$Basics$identity;
var $author$project$Launch$advance = function (_v0) {
	var model = _v0;
	var _v1 = $author$project$UInt64$next(model.cN);
	if (!_v1.$) {
		var revision = _v1.a;
		return _Utils_update(
			model,
			{cN: revision});
	} else {
		return _Utils_update(
			model,
			{a9: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing});
	}
};
var $author$project$Launch$acknowledgeUnknown = F2(
	function (_v0, current) {
		var intent = _v0;
		var model = current;
		var _v1 = model.m;
		if ((_v1.$ === 2) && (_v1.b === 2)) {
			var active = _v1.a;
			var _v2 = _v1.b;
			return _Utils_eq(active, intent) ? $author$project$Launch$advance(
				_Utils_update(
					model,
					{m: $author$project$Launch$Idle})) : current;
		} else {
			return current;
		}
	});
var $author$project$Switcher$Cancelled = 4;
var $author$project$Switcher$Model = $elm$core$Basics$identity;
var $author$project$Switcher$writable = function (model) {
	return A2(
		$elm$core$List$member,
		model.m,
		_List_fromArray(
			[1, 2]));
};
var $author$project$Switcher$cancel = F2(
	function (token, original) {
		var model = original;
		return ((!_Utils_eq(token, model.e7)) || (!$author$project$Switcher$writable(model))) ? original : _Utils_update(
			model,
			{ak: _List_Nil, m: 4});
	});
var $author$project$Desktop$retireSwitcher = function (model) {
	return _Utils_update(
		model,
		{
			j: A2(
				$author$project$Switcher$cancel,
				$author$project$Switcher$generation(model.j),
				model.j),
			aN: $elm$core$Maybe$Nothing,
			aO: $elm$core$Maybe$Nothing,
			cn: $elm$core$Maybe$Nothing
		});
};
var $author$project$Desktop$advance = function (model) {
	var _v0 = A2($elm$core$Maybe$andThen, $author$project$UInt64$next, model.aF);
	if (!_v0.$) {
		var value = _v0.a;
		return _Utils_update(
			model,
			{
				aF: $elm$core$Maybe$Just(value)
			});
	} else {
		return $author$project$Desktop$retireSwitcher(
			_Utils_update(
				model,
				{aj: $elm$core$Maybe$Nothing, y: $elm$core$Maybe$Nothing, q: false, l: false, aF: $elm$core$Maybe$Nothing}));
	}
};
var $author$project$Desktop$applicationGesture = function (message) {
	switch (message.$) {
		case 12:
			return true;
		case 13:
			return true;
		case 66:
			return true;
		case 14:
			return true;
		case 67:
			return true;
		case 68:
			return true;
		case 69:
			return true;
		default:
			return false;
	}
};
var $author$project$Desktop$applicationPageCount = function (model) {
	var size = $author$project$Desktop$applicationPageSize(model);
	var entries = A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		A2(
			$elm$core$Maybe$map,
			$author$project$Catalog$search(model.ck),
			model.aj));
	var leading = function () {
		var _v0 = $elm$core$List$head(entries);
		if (_v0.$ === 1) {
			return 0;
		} else {
			var entry = _v0.a;
			return A2(
				$elm$core$List$member,
				$author$project$Catalog$id(entry.cG),
				$author$project$Desktop$pinIdentities(model)) ? 1 : 2;
		}
	}();
	var total = (leading + (3 * $elm$core$List$length(
		$author$project$Desktop$pinIdentities(model)))) + $elm$core$List$length(entries);
	return A2($elm$core$Basics$max, 1, (((total + size) - 1) / size) | 0);
};
var $author$project$OverviewRecovery$Choosing = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $author$project$OverviewRecovery$begin = $author$project$OverviewRecovery$Choosing;
var $author$project$WorkspaceNavigation$encodeRow = function (r) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'identity',
				$elm$json$Json$Encode$string(r.cG)),
				_Utils_Tuple2(
				'generation',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(r.e7))),
				_Utils_Tuple2(
				'monitor',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(r.bS))),
				_Utils_Tuple2(
				'outputOwnershipGeneration',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(r.bd)))
			]));
};
var $author$project$WorkspaceNavigation$encodeIntent = function (i) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'request',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(i.cM))),
				_Utils_Tuple2(
				'generation',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(i.e7))),
				_Utils_Tuple2(
				'source',
				$author$project$WorkspaceNavigation$encodeRow(i.cm)),
				_Utils_Tuple2(
				'destination',
				$author$project$WorkspaceNavigation$encodeRow(i.bp)),
				_Utils_Tuple2(
				'context',
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'lifetime',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(i.R.fe))),
							_Utils_Tuple2(
							'epoch',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(i.R.e4))),
							_Utils_Tuple2(
							'output',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(i.R.z))),
							_Utils_Tuple2(
							'revision',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(i.R.cN)))
						])))
			]));
};
var $author$project$WorkspaceNavigation$wire = F3(
	function (kind, binding, extras) {
		return $elm$json$Json$Encode$object(
			_Utils_ap(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string(kind)),
						_Utils_Tuple2(
						'workspaceProtocol',
						$elm$json$Json$Encode$int(1)),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding))
					]),
				extras));
	});
var $author$project$WorkspaceNavigation$begin = F2(
	function (intent, model) {
		var _v0 = model.c3;
		if (!_v0.$) {
			var binding = _v0.a;
			return ($author$project$WorkspaceNavigation$blocked(model) || (!model.bY)) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						e7: intent.e7,
						bT: $elm$core$Maybe$Just(intent.bp.cG),
						fz: $elm$core$Maybe$Just(
							{c3: binding, af: intent, ep: 'admitted', O: 0}),
						cM: intent.cM,
						ex: false
					}),
				$elm$core$Maybe$Just(
					A3(
						$author$project$WorkspaceNavigation$wire,
						'workspace-navigation',
						binding,
						_List_fromArray(
							[
								_Utils_Tuple2(
								'intent',
								$author$project$WorkspaceNavigation$encodeIntent(intent))
							]))));
		} else {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$PointerOwnership$Idle = 0;
var $author$project$PointerOwnership$blocked = F2(
	function (expected, model) {
		if (expected.$ === 1) {
			return false;
		} else {
			var binding = expected.a;
			var _v1 = model.bw;
			if (!_v1.$) {
				var snapshot = _v1.a;
				return (!_Utils_eq(snapshot.c3, binding)) || (!(!snapshot.cX));
			} else {
				return true;
			}
		}
	});
var $author$project$Desktop$canProveCatalogUnsent = F3(
	function (binding, request, model) {
		return _Utils_eq(
			model.a.b.c3,
			$elm$core$Maybe$Just(binding)) && (_Utils_eq(
			model.y,
			$elm$core$Maybe$Just(request)) && ((!(!model.a.b.m)) && (model.a.b.m !== 3)));
	});
var $author$project$OverviewRecovery$Idle = {$: 0};
var $author$project$OverviewRecovery$cancelChoice = F2(
	function (read, model) {
		if (model.$ === 1) {
			var expected = model.b;
			return _Utils_eq(read, expected) ? $author$project$OverviewRecovery$Idle : model;
		} else {
			return model;
		}
	});
var $author$project$Catalog$Snapshot = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $author$project$Catalog$Entry = F6(
	function (identity, name, iconHint, wmclass, genericName, keywords) {
		return {dX: genericName, e9: iconHint, cG: identity, d3: keywords, dj: name, fP: wmclass};
	});
var $author$project$Catalog$EntryId = $elm$core$Basics$identity;
var $elm$json$Json$Decode$map4 = _Json_map4;
var $author$project$Catalog$strict = F2(
	function (names, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (fields) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
					$elm$core$List$sort(names)) ? decoder : $elm$json$Json$Decode$fail('Unexpected catalog fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Catalog$text = F2(
	function (limit, nonempty) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return ((_Utils_cmp(
					$elm$core$String$length(value),
					limit) < 1) && (((!nonempty) || (!$elm$core$String$isEmpty(value))) && (!A2(
					$elm$core$String$any,
					function (c) {
						return $elm$core$Char$toCode(c) < 32;
					},
					value)))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Catalog text');
			},
			$elm$json$Json$Decode$string);
	});
var $author$project$Catalog$entryDecoder = A2(
	$author$project$Catalog$strict,
	_List_fromArray(
		['id', 'name', 'iconHint', 'wmclass']),
	A5(
		$elm$json$Json$Decode$map4,
		F4(
			function (identity, name, iconHint, wmclass) {
				return A6($author$project$Catalog$Entry, identity, name, iconHint, wmclass, '', _List_Nil);
			}),
		A2(
			$elm$json$Json$Decode$field,
			'id',
			A2(
				$elm$json$Json$Decode$map,
				$elm$core$Basics$identity,
				A2($author$project$Catalog$text, 256, true))),
		A2(
			$elm$json$Json$Decode$field,
			'name',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'iconHint',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'wmclass',
			A2($author$project$Catalog$text, 512, false))));
var $elm$json$Json$Decode$list = _Json_decodeList;
var $author$project$Catalog$entryDecoder2 = A2(
	$author$project$Catalog$strict,
	_List_fromArray(
		['id', 'name', 'iconHint', 'wmclass', 'genericName', 'keywords']),
	A7(
		$elm$json$Json$Decode$map6,
		$author$project$Catalog$Entry,
		A2(
			$elm$json$Json$Decode$field,
			'id',
			A2(
				$elm$json$Json$Decode$map,
				$elm$core$Basics$identity,
				A2($author$project$Catalog$text, 256, true))),
		A2(
			$elm$json$Json$Decode$field,
			'name',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'iconHint',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'wmclass',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'genericName',
			A2($author$project$Catalog$text, 512, false)),
		A2(
			$elm$json$Json$Decode$field,
			'keywords',
			A2(
				$elm$json$Json$Decode$andThen,
				function (values) {
					return ($elm$core$List$length(values) <= 64) ? $elm$json$Json$Decode$succeed(values) : $elm$json$Json$Decode$fail('Keyword capacity');
				},
				$elm$json$Json$Decode$list(
					A2($author$project$Catalog$text, 128, false))))));
var $author$project$Catalog$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Zero catalog authority');
	},
	$author$project$UInt64$decoder);
var $elm$core$Dict$sizeHelp = F2(
	function (n, dict) {
		sizeHelp:
		while (true) {
			if (dict.$ === -2) {
				return n;
			} else {
				var left = dict.d;
				var right = dict.e;
				var $temp$n = A2($elm$core$Dict$sizeHelp, n + 1, right),
					$temp$dict = left;
				n = $temp$n;
				dict = $temp$dict;
				continue sizeHelp;
			}
		}
	});
var $elm$core$Dict$size = function (dict) {
	return A2($elm$core$Dict$sizeHelp, 0, dict);
};
var $author$project$Catalog$decode = function (raw) {
	var protocol = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return A2(
				$elm$core$List$member,
				value,
				_List_fromArray(
					[1, 2])) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Catalog version');
		},
		A2($elm$json$Json$Decode$field, 'catalogProtocol', $elm$json$Json$Decode$int));
	var entryList = function (version) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (values) {
				return ($elm$core$List$length(values) <= 2048) ? $elm$json$Json$Decode$list(
					(version === 2) ? $author$project$Catalog$entryDecoder2 : $author$project$Catalog$entryDecoder) : $elm$json$Json$Decode$fail('Catalog capacity');
			},
			$elm$json$Json$Decode$list($elm$json$Json$Decode$value));
	};
	var decoder = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return A2(
				$author$project$Catalog$strict,
				_List_fromArray(
					['catalogProtocol', 'lifetime', 'generation', 'entries']),
				A4(
					$elm$json$Json$Decode$map3,
					F3(
						function (lifetime, generation, values) {
							return _Utils_Tuple3(lifetime, generation, values);
						}),
					A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Catalog$positive),
					A2($elm$json$Json$Decode$field, 'generation', $author$project$Catalog$positive),
					A2(
						$elm$json$Json$Decode$field,
						'entries',
						entryList(value))));
		},
		protocol);
	return A2(
		$elm$core$Result$andThen,
		function (_v0) {
			var lifetime = _v0.a;
			var generation = _v0.b;
			var values = _v0.c;
			var dict = $elm$core$Dict$fromList(
				A2(
					$elm$core$List$map,
					function (entry) {
						return _Utils_Tuple2(
							$author$project$Catalog$id(entry.cG),
							entry);
					},
					values));
			return (!_Utils_eq(
				$elm$core$Dict$size(dict),
				$elm$core$List$length(values))) ? $elm$core$Result$Err('Duplicate desktop identity') : $elm$core$Result$Ok(
				A3($author$project$Catalog$Snapshot, lifetime, generation, dict));
		},
		A2(
			$elm$core$Result$mapError,
			$elm$json$Json$Decode$errorToString,
			A2($elm$json$Json$Decode$decodeValue, decoder, raw)));
};
var $elm$core$Result$toMaybe = function (result) {
	if (!result.$) {
		var v = result.a;
		return $elm$core$Maybe$Just(v);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Launch$catalog = F2(
	function (raw, _v0) {
		var model = _v0;
		var snapshot = $elm$core$Result$toMaybe(
			$author$project$Catalog$decode(raw));
		var phase = function () {
			var _v1 = _Utils_Tuple2(snapshot, model.m);
			_v1$2:
			while (true) {
				if ((!_v1.a.$) && (_v1.b.$ === 2)) {
					switch (_v1.b.b) {
						case 1:
							var _v2 = _v1.b;
							var _v3 = _v2.b;
							return $author$project$Launch$Idle;
						case 0:
							var _v4 = _v1.b;
							var _v5 = _v4.b;
							return $author$project$Launch$Idle;
						default:
							break _v1$2;
					}
				} else {
					break _v1$2;
				}
			}
			return model.m;
		}();
		return $author$project$Launch$advance(
			_Utils_update(
				model,
				{m: phase, c: snapshot}));
	});
var $author$project$Switcher$index = F2(
	function (root, rows) {
		return A2(
			$elm$core$Maybe$map,
			$elm$core$Tuple$first,
			$elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (_v0) {
						var row = _v0.b;
						return _Utils_eq(row.n, root);
					},
					A2($elm$core$List$indexedMap, $elm$core$Tuple$pair, rows))));
	});
var $elm$core$List$maximum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$max, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Switcher$lastOrdinal = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		0,
		$elm$core$List$maximum(
			$elm$core$Dict$keys(model.bH)));
};
var $author$project$Switcher$choose = F3(
	function (token, root, original) {
		var model = original;
		return ((!_Utils_eq(token, model.e7)) || ((model.m !== 2) || (!_Utils_eq(model.cL, $elm$core$Maybe$Nothing)))) ? original : A2(
			$elm$core$Maybe$withDefault,
			original,
			A2(
				$elm$core$Maybe$map,
				function (position) {
					return _Utils_update(
						model,
						{
							a5: $elm$core$Maybe$Just(
								{
									n: root,
									cZ: $author$project$Switcher$lastOrdinal(model)
								}),
							bG: position
						});
				},
				A2($author$project$Switcher$index, root, model.ak)));
	});
var $author$project$OverviewRecovery$initial = $author$project$OverviewRecovery$Idle;
var $author$project$Desktop$WindowEffect = function (a) {
	return {$: 0, a: a};
};
var $author$project$Launch$PendingToken = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$Launch$pending = function (_v0) {
	var model = _v0;
	var _v1 = model.m;
	if (_v1.$ === 1) {
		var host = _v1.a;
		var intent = _v1.b;
		return $elm$core$Maybe$Just(
			A2($author$project$Launch$PendingToken, host, intent));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Launch$Settled = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Launch$Unknown = 2;
var $author$project$Launch$timeout = F2(
	function (_v0, current) {
		var host = _v0.a;
		var intent = _v0.b;
		var model = current;
		var _v1 = model.m;
		if (_v1.$ === 1) {
			var owner = _v1.a;
			var active = _v1.b;
			return (_Utils_eq(owner, host) && _Utils_eq(active, intent)) ? $author$project$Launch$advance(
				_Utils_update(
					model,
					{
						m: A2($author$project$Launch$Settled, intent, 2)
					})) : current;
		} else {
			return current;
		}
	});
var $author$project$Launch$disconnect = function (current) {
	var _v0 = A2(
		$elm$core$Maybe$withDefault,
		current,
		A2(
			$elm$core$Maybe$map,
			function (token) {
				return A2($author$project$Launch$timeout, token, current);
			},
			$author$project$Launch$pending(current)));
	var model = _v0;
	return $author$project$Launch$advance(
		_Utils_update(
			model,
			{a9: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing}));
};
var $author$project$Launch$bind = F2(
	function (host, current) {
		var model = current;
		if ($elm$core$String$isEmpty(host) || (($elm$core$String$length(host) > 256) || A2(
			$elm$core$String$any,
			function (c) {
				return $elm$core$Char$toCode(c) < 32;
			},
			host))) {
			return $author$project$Launch$disconnect(current);
		} else {
			if (_Utils_eq(
				model.a9,
				$elm$core$Maybe$Just(host))) {
				return current;
			} else {
				var _v0 = $author$project$Launch$disconnect(current);
				var retired = _v0;
				return $author$project$Launch$advance(
					_Utils_update(
						retired,
						{
							a9: $elm$core$Maybe$Just(host)
						}));
			}
		}
	});
var $author$project$WorkspaceNavigation$bind = F2(
	function (binding, model) {
		return _Utils_eq(
			model.c3,
			$elm$core$Maybe$Just(binding)) ? model : _Utils_update(
			model,
			{
				c3: $elm$core$Maybe$Just(binding),
				bT: $elm$core$Maybe$Nothing,
				bY: false,
				fz: A2(
					$elm$core$Maybe$map,
					function (r) {
						return (!r.O) ? _Utils_update(
							r,
							{ep: 'delivery-unproven', O: 1}) : r;
					},
					model.fz),
				er: false,
				ex: false
			});
	});
var $author$project$Desktop$catalogRequest = F2(
	function (binding, request) {
		return $author$project$Desktop$Send(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('catalog-request')),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding)),
						_Utils_Tuple2(
						'requestId',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request)))
					])));
	});
var $author$project$AdapterNotice$Windows = 8;
var $author$project$AdapterNotice$connectionLost = F2(
	function (binding, request) {
		return {c3: binding, cM: request, cN: $elm$core$Maybe$Nothing, cS: $elm$core$Maybe$Nothing, cm: 8};
	});
var $author$project$WorkspaceInventory$identityDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (s) {
		return ((!$elm$core$String$isEmpty(s)) && (A2($elm$core$String$all, $elm$core$Char$isDigit, s) && ((!A2($elm$core$String$startsWith, '0', s)) && (($elm$core$String$length(s) < 19) || (($elm$core$String$length(s) === 19) && (s <= '9223372036854775807')))))) ? $elm$json$Json$Decode$succeed(s) : $elm$json$Json$Decode$fail('Ordinary workspace identity');
	},
	$elm$json$Json$Decode$string);
var $elm$json$Json$Decode$map2 = _Json_map2;
var $author$project$WorkspaceInventory$Row = F4(
	function (identity, generation, monitor, outputOwnershipGeneration) {
		return {e7: generation, cG: identity, bS: monitor, bd: outputOwnershipGeneration};
	});
var $author$project$WorkspaceInventory$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (n) {
		return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Zero workspace owner');
	},
	$author$project$UInt64$decoder);
var $author$project$WorkspaceInventory$strict = F2(
	function (fields, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? body : $elm$json$Json$Decode$fail('Workspace inventory schema');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$WorkspaceInventory$rowDecoder = A2(
	$author$project$WorkspaceInventory$strict,
	_List_fromArray(
		['identity', 'generation', 'monitor', 'outputOwnershipGeneration']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$WorkspaceInventory$Row,
		A2($elm$json$Json$Decode$field, 'identity', $author$project$WorkspaceInventory$identityDecoder),
		A2($elm$json$Json$Decode$field, 'generation', $author$project$WorkspaceInventory$positive),
		A2($elm$json$Json$Decode$field, 'monitor', $author$project$UInt64$decoder),
		A2($elm$json$Json$Decode$field, 'outputOwnershipGeneration', $author$project$WorkspaceInventory$positive)));
var $author$project$WorkspaceInventory$factsDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (_v0) {
		var active = _v0.a;
		var rows = _v0.b;
		var ids = A2(
			$elm$core$List$map,
			function ($) {
				return $.cG;
			},
			rows);
		var unique = _Utils_eq(
			$elm$core$List$length(ids),
			$elm$core$List$length(
				A3(
					$elm$core$List$foldl,
					F2(
						function (id, xs) {
							return A2($elm$core$List$member, id, xs) ? xs : A2($elm$core$List$cons, id, xs);
						}),
					_List_Nil,
					ids)));
		var consistent = function (row) {
			return A2(
				$elm$core$List$all,
				function (other) {
					return (!_Utils_eq(row.e7, other.e7)) || _Utils_eq(row.cG, other.cG);
				},
				rows) && A2(
				$elm$core$List$all,
				function (other) {
					return (!_Utils_eq(row.bS, other.bS)) || _Utils_eq(row.bd, other.bd);
				},
				rows);
		};
		return (($elm$core$List$length(rows) <= 256) && (unique && (A2($elm$core$List$all, consistent, rows) && A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (id) {
					return A2($elm$core$List$member, id, ids);
				},
				active))))) ? $elm$json$Json$Decode$succeed(
			_Utils_Tuple2(active, rows)) : $elm$json$Json$Decode$fail('Workspace inventory coherence');
	},
	A3(
		$elm$json$Json$Decode$map2,
		$elm$core$Tuple$pair,
		A2(
			$elm$json$Json$Decode$field,
			'activeWorkspace',
			$elm$json$Json$Decode$nullable($author$project$WorkspaceInventory$identityDecoder)),
		A2(
			$elm$json$Json$Decode$field,
			'workspaces',
			$elm$json$Json$Decode$list($author$project$WorkspaceInventory$rowDecoder))));
var $elm$json$Json$Decode$map7 = _Json_map7;
var $author$project$WorkspaceInventory$decode = function (raw) {
	return $elm$core$Result$toMaybe(
		A2(
			$elm$json$Json$Decode$decodeValue,
			A8(
				$elm$json$Json$Decode$map7,
				F7(
					function (binding, request, sequence, revision, output, _v0, facts) {
						return {dC: facts.a, c3: binding, z: output, cM: request, cN: revision, ez: facts.b, eC: sequence};
					}),
				A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
				A2($elm$json$Json$Decode$field, 'requestId', $author$project$WorkspaceInventory$positive),
				A2($elm$json$Json$Decode$field, 'sequence', $author$project$WorkspaceInventory$positive),
				A2($elm$json$Json$Decode$field, 'revision', $author$project$WorkspaceInventory$positive),
				A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$WorkspaceInventory$positive),
				A2(
					$elm$json$Json$Decode$andThen,
					function (n) {
						return (n === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Workspace inventory version');
					},
					A2($elm$json$Json$Decode$field, 'geometryProtocol', $elm$json$Json$Decode$int)),
				A2($elm$json$Json$Decode$field, 'facts', $author$project$WorkspaceInventory$factsDecoder)),
			raw));
};
var $author$project$Files$disconnect = function (model) {
	return _Utils_update(
		model,
		{
			fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? 'Files: opening not confirmed after connection loss. Open the menu to read current state; this request will not be repeated.' : model.fj,
			dn: $elm$core$Maybe$Nothing,
			c: $elm$core$Maybe$Nothing,
			b1: _List_Nil
		});
};
var $author$project$JumpList$disconnect = function (model) {
	return _Utils_update(
		model,
		{
			fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? 'Application action: not confirmed after connection loss. This request will not be repeated.' : model.fj,
			dn: $elm$core$Maybe$Nothing,
			c: $elm$core$Maybe$Nothing,
			b1: _List_Nil
		});
};
var $author$project$WorkspaceNavigation$disconnect = function (model) {
	return _Utils_update(
		model,
		{
			c3: $elm$core$Maybe$Nothing,
			bT: $elm$core$Maybe$Nothing,
			bY: false,
			fz: A2(
				$elm$core$Maybe$map,
				function (r) {
					return (!r.O) ? _Utils_update(
						r,
						{ep: 'delivery-unproven', O: 1}) : r;
				},
				model.fz),
			er: false,
			ex: false
		});
};
var $author$project$Notifications$initial = {
	ca: $elm$core$Maybe$Nothing,
	fj: 'Loading notifications…',
	cJ: $elm$core$Maybe$Nothing,
	dn: $elm$core$Maybe$Nothing,
	ft: {cC: false, d1: false},
	c: $elm$core$Maybe$Nothing,
	b1: _List_Nil
};
var $author$project$Pins$initial = {fj: '', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing};
var $author$project$Settings$initial = {e2: $author$project$Settings$defaults, fj: 'Loading settings…', cJ: $elm$core$Maybe$Nothing, dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing};
var $author$project$ShortcutPreferences$Undecided = 0;
var $author$project$ShortcutPreferences$defaults = {aj: 0, C: 0, bI: 0};
var $author$project$ShortcutPreferences$initial = {ay: _List_Nil, e2: $author$project$ShortcutPreferences$defaults, cH: $elm$core$Maybe$Nothing, fj: 'Loading shortcut choices…', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing};
var $author$project$Shortcuts$initial = {c3: $elm$core$Maybe$Nothing, bF: $author$project$UInt64$zero};
var $author$project$SystemMenu$initial = {fj: 'Loading system state…', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing, b1: _List_Nil};
var $author$project$Desktop$motionPreferencesRequest = F2(
	function (binding, request) {
		return $author$project$Desktop$Send(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('motion-preferences-request')),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding)),
						_Utils_Tuple2(
						'requestId',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request)))
					])));
	});
var $author$project$MotionPreferences$initial = {e2: 0, fj: 'Reading motion preference…', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing};
var $author$project$Motion$rebind = function (model) {
	return _Utils_update(
		model,
		{bL: $elm$core$Maybe$Nothing, dn: $elm$core$Maybe$Nothing, aY: $author$project$MotionPreferences$initial});
};
var $author$project$Desktop$settingsRequest = F2(
	function (binding, request) {
		return $author$project$Desktop$Send(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('shell-settings-request')),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding)),
						_Utils_Tuple2(
						'requestId',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request)))
					])));
	});
var $author$project$Desktop$shortcutPreferencesRequest = F2(
	function (binding, request) {
		return $author$project$Desktop$Send(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('shortcut-preferences-request')),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding)),
						_Utils_Tuple2(
						'requestId',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request)))
					])));
	});
var $author$project$Shell$Act = F3(
	function (a, b, c) {
		return {$: 9, a: a, b: b, c: c};
	});
var $author$project$MenuBridge$Model = $elm$core$Basics$identity;
var $author$project$Menu$ExitFullscreen = {$: 7};
var $author$project$Menu$Maximize = {$: 5};
var $author$project$Menu$RestoreGeometry = {$: 1};
var $author$project$Provider$actionProtocol = function (action) {
	return (_Utils_eq(action, $author$project$Menu$Maximize) || (_Utils_eq(action, $author$project$Menu$RestoreGeometry) || (_Utils_eq(action, $author$project$Menu$ExitFullscreen) || function () {
		if (action.$ === 8) {
			return true;
		} else {
			return false;
		}
	}()))) ? 2 : 1;
};
var $author$project$MenuBridge$answer = F4(
	function (bridge, shell, effects, error) {
		return {dI: bridge, V: effects, dR: error, b: shell};
	});
var $author$project$Menu$ReceiveFor = F3(
	function (a, b, c) {
		return {$: 4, a: a, b: b, c: c};
	});
var $author$project$Menu$Refusal = function (a) {
	return {$: 1, a: a};
};
var $author$project$Menu$Cancelled = {$: 3};
var $author$project$Menu$Dispatch = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $author$project$Menu$IntentId = $elm$core$Basics$identity;
var $author$project$Menu$MenuId = $elm$core$Basics$identity;
var $author$project$Menu$Model = $elm$core$Basics$identity;
var $author$project$Menu$Pending = function (a) {
	return {$: 1, a: a};
};
var $author$project$Menu$Refused = function (a) {
	return {$: 2, a: a};
};
var $author$project$Menu$Uncertain = {$: 3};
var $author$project$Menu$Unknown = function (a) {
	return {$: 4, a: a};
};
var $author$project$Menu$awaits = F2(
	function (id, status) {
		switch (status.$) {
			case 1:
				var pending = status.a;
				return _Utils_eq(pending, id);
			case 4:
				var unknown = status.a;
				return _Utils_eq(unknown, id);
			default:
				return false;
		}
	});
var $author$project$Menu$maxLabel = 256;
var $author$project$Menu$boundedOutcome = function (outcome) {
	if (outcome.$ === 1) {
		var reason = outcome.a;
		var take = F2(
			function (remaining, characters) {
				if (!characters.b) {
					return '';
				} else {
					var character = characters.a;
					var rest = characters.b;
					var value = $elm$core$String$fromChar(character);
					return (_Utils_cmp(
						$elm$core$String$length(value),
						remaining) > 0) ? '' : _Utils_ap(
						value,
						A2(
							take,
							remaining - $elm$core$String$length(value),
							rest));
				}
			});
		var completePrefix = A2(
			take,
			$author$project$Menu$maxLabel,
			$elm$core$String$toList(
				A2($elm$core$String$left, $author$project$Menu$maxLabel + 1, reason)));
		return $author$project$Menu$Refusal(completePrefix);
	} else {
		return outcome;
	}
};
var $author$project$Menu$enabledIndices = function (items) {
	return A2(
		$elm$core$List$filterMap,
		$elm$core$Basics$identity,
		A2(
			$elm$core$List$indexedMap,
			F2(
				function (index, item) {
					return item.b9 ? $elm$core$Maybe$Just(index) : $elm$core$Maybe$Nothing;
				}),
			items));
};
var $author$project$Menu$itemAt = F2(
	function (index, items) {
		return (index < 0) ? $elm$core$Maybe$Nothing : $elm$core$List$head(
			A2($elm$core$List$drop, index, items));
	});
var $author$project$Menu$maxOutstanding = 64;
var $author$project$Menu$maxRetired = 128;
var $author$project$Menu$orElse = F2(
	function (fallback, value) {
		if (!value.$) {
			return value;
		} else {
			return fallback;
		}
	});
var $author$project$Menu$navigate = F2(
	function (direction, menu) {
		var enabled = $author$project$Menu$enabledIndices(menu.fd);
		var first = $elm$core$List$head(enabled);
		var last = $elm$core$List$head(
			$elm$core$List$reverse(enabled));
		var selected = function () {
			switch (direction) {
				case 2:
					return first;
				case 3:
					return last;
				case 1:
					var _v1 = menu.bG;
					if (_v1.$ === 1) {
						return first;
					} else {
						var index = _v1.a;
						return A2(
							$author$project$Menu$orElse,
							first,
							$elm$core$List$head(
								A2(
									$elm$core$List$filter,
									$elm$core$Basics$lt(index),
									enabled)));
					}
				default:
					var _v2 = menu.bG;
					if (_v2.$ === 1) {
						return last;
					} else {
						var index = _v2.a;
						return A2(
							$author$project$Menu$orElse,
							last,
							$elm$core$List$head(
								$elm$core$List$reverse(
									A2(
										$elm$core$List$filter,
										$elm$core$Basics$gt(index),
										enabled))));
					}
			}
		}();
		return _Utils_update(
			menu,
			{bG: selected});
	});
var $author$project$Menu$outputTuple = function (_v0) {
	var value = _v0;
	return _Utils_Tuple2(value.z, value.fm);
};
var $author$project$Menu$sameTarget = F2(
	function (_v0, _v1) {
		var left = _v0;
		var right = _v1;
		return _Utils_eq(left.fK, right.fK);
	});
var $author$project$Menu$maxItems = 64;
var $author$project$Menu$validItems = function (items) {
	var uniqueActions = F2(
		function (remaining, seen) {
			uniqueActions:
			while (true) {
				if (!remaining.b) {
					return true;
				} else {
					var item = remaining.a;
					var rest = remaining.b;
					if (A2($elm$core$List$member, item.eV, seen)) {
						return false;
					} else {
						var $temp$remaining = rest,
							$temp$seen = A2($elm$core$List$cons, item.eV, seen);
						remaining = $temp$remaining;
						seen = $temp$seen;
						continue uniqueActions;
					}
				}
			}
		});
	return (_Utils_cmp(
		$elm$core$List$length(items),
		$author$project$Menu$maxItems) < 1) && (A2(
		$elm$core$List$all,
		function (item) {
			return (_Utils_cmp(
				$elm$core$String$length(item.d6),
				$author$project$Menu$maxLabel) < 1) && (!$elm$core$String$isEmpty(
				$elm$core$String$trim(item.d6)));
		},
		items) && A2(uniqueActions, items, _List_Nil));
};
var $author$project$Menu$update = F2(
	function (message, model) {
		var state = model;
		var valid = function (target) {
			return (!A2($elm$core$List$member, target, state.aT)) && (!A2(
				$elm$core$List$member,
				$author$project$Menu$outputTuple(target),
				state.a_));
		};
		var unchanged = _Utils_Tuple2(model, _List_Nil);
		var editMenu = F2(
			function (id, transform) {
				var _v8 = state.aC;
				if (!_v8.$) {
					var menu = _v8.a;
					return _Utils_eq(menu.cc, id) ? _Utils_Tuple2(
						_Utils_update(
							state,
							{
								aC: transform(menu)
							}),
						_List_Nil) : unchanged;
				} else {
					return unchanged;
				}
			});
		switch (message.$) {
			case 0:
				var target = message.a;
				var items = message.b;
				if (state.aA || ((!valid(target)) || ((!$author$project$Menu$validItems(items)) || (state.cj > 2147483647)))) {
					return unchanged;
				} else {
					var status = function () {
						var _v1 = $elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (entry) {
									return A2($author$project$Menu$sameTarget, entry.c3, target);
								},
								state.fn));
						if (_v1.$ === 1) {
							return $author$project$Menu$Ready;
						} else {
							var entry = _v1.a;
							return entry.bk ? $author$project$Menu$Unknown(entry.cc) : $author$project$Menu$Pending(entry.cc);
						}
					}();
					var menu = {
						c3: target,
						cc: state.cj,
						fd: items,
						bG: $elm$core$List$head(
							$author$project$Menu$enabledIndices(items)),
						O: status
					};
					return _Utils_Tuple2(
						_Utils_update(
							state,
							{
								aC: $elm$core$Maybe$Just(menu),
								cj: state.cj + 1
							}),
						_List_Nil);
				}
			case 1:
				var id = message.a;
				var target = message.b;
				var index = message.c;
				return A2(
					editMenu,
					id,
					function (menu) {
						if (_Utils_eq(menu.c3, target) && valid(target)) {
							var _v2 = A2($author$project$Menu$itemAt, index, menu.fd);
							if (!_v2.$) {
								var item = _v2.a;
								return item.b9 ? $elm$core$Maybe$Just(
									_Utils_update(
										menu,
										{
											bG: $elm$core$Maybe$Just(index)
										})) : $elm$core$Maybe$Just(menu);
							} else {
								return $elm$core$Maybe$Just(menu);
							}
						} else {
							return $elm$core$Maybe$Just(menu);
						}
					});
			case 2:
				var id = message.a;
				var direction = message.b;
				return A2(
					editMenu,
					id,
					A2(
						$elm$core$Basics$composeR,
						$author$project$Menu$navigate(direction),
						$elm$core$Maybe$Just));
			case 3:
				var id = message.a;
				var target = message.b;
				var index = message.c;
				var _v3 = state.aC;
				if (_v3.$ === 1) {
					return unchanged;
				} else {
					var menu = _v3.a;
					if (state.aA || ((!_Utils_eq(menu.cc, id)) || ((!_Utils_eq(menu.c3, target)) || ((!valid(target)) || (state.ci > 2147483647))))) {
						return unchanged;
					} else {
						if (A2(
							$elm$core$List$any,
							function (entry) {
								return A2($author$project$Menu$sameTarget, entry.c3, target);
							},
							state.fn)) {
							return unchanged;
						} else {
							var _v4 = A2($author$project$Menu$itemAt, index, menu.fd);
							if (!_v4.$) {
								var item = _v4.a;
								if (item.b9 && (_Utils_cmp(
									$elm$core$List$length(state.fn),
									$author$project$Menu$maxOutstanding) > -1)) {
									return _Utils_Tuple2(
										_Utils_update(
											state,
											{
												aC: $elm$core$Maybe$Just(
													_Utils_update(
														menu,
														{
															O: $author$project$Menu$Refused('Outstanding operation limit reached; reconcile existing requests.')
														}))
											}),
										_List_Nil);
								} else {
									if (item.b9) {
										var intent = state.ci;
										var entry = {c3: target, cc: intent, bk: false};
										return _Utils_Tuple2(
											_Utils_update(
												state,
												{
													aC: $elm$core$Maybe$Just(
														_Utils_update(
															menu,
															{
																bG: $elm$core$Maybe$Just(index),
																O: $author$project$Menu$Pending(intent)
															})),
													ci: state.ci + 1,
													fn: A2($elm$core$List$cons, entry, state.fn)
												}),
											_List_fromArray(
												[
													A3($author$project$Menu$Dispatch, intent, target, item.eV)
												]));
									} else {
										return unchanged;
									}
								}
							} else {
								return unchanged;
							}
						}
					}
				}
			case 4:
				var intent = message.a;
				var receiptBinding = message.b;
				var receivedOutcome = message.c;
				var _v5 = $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (entry) {
							return _Utils_eq(entry.cc, intent) && _Utils_eq(entry.c3, receiptBinding);
						},
						state.fn));
				if (_v5.$ === 1) {
					return unchanged;
				} else {
					var entry = _v5.a;
					var outcome = $author$project$Menu$boundedOutcome(receivedOutcome);
					var outstanding = _Utils_eq(outcome, $author$project$Menu$Uncertain) ? A2(
						$elm$core$List$map,
						function (current) {
							return _Utils_eq(current.cc, intent) ? _Utils_update(
								current,
								{bk: true}) : current;
						},
						state.fn) : A2(
						$elm$core$List$filter,
						function (current) {
							return !_Utils_eq(current.cc, intent);
						},
						state.fn);
					var menu = A2(
						$elm$core$Maybe$andThen,
						function (current) {
							if (!A2($author$project$Menu$awaits, intent, current.O)) {
								return $elm$core$Maybe$Just(current);
							} else {
								switch (outcome.$) {
									case 0:
										return $elm$core$Maybe$Nothing;
									case 1:
										var reason = outcome.a;
										return $elm$core$Maybe$Just(
											_Utils_update(
												current,
												{
													O: $author$project$Menu$Refused(reason)
												}));
									case 2:
										return $elm$core$Maybe$Just(
											_Utils_update(
												current,
												{O: $author$project$Menu$Cancelled}));
									default:
										return $elm$core$Maybe$Just(
											_Utils_update(
												current,
												{
													O: $author$project$Menu$Unknown(intent)
												}));
								}
							}
						},
						state.aC);
					return _Utils_Tuple2(
						_Utils_update(
							state,
							{
								cf: $elm$core$Maybe$Just(
									_Utils_Tuple2(intent, outcome)),
								aC: menu,
								fn: outstanding
							}),
						_List_Nil);
				}
			case 5:
				var id = message.a;
				return A2(
					editMenu,
					id,
					function (_v7) {
						return $elm$core$Maybe$Nothing;
					});
			case 6:
				var target = message.a;
				if (A2($elm$core$List$member, target, state.aT) || state.aA) {
					return unchanged;
				} else {
					if (_Utils_cmp(
						$elm$core$List$length(state.aT) + $elm$core$List$length(state.a_),
						$author$project$Menu$maxRetired) > -1) {
						return _Utils_Tuple2(
							_Utils_update(
								state,
								{aA: true, aC: $elm$core$Maybe$Nothing}),
							_List_Nil);
					} else {
						var menu = A2(
							$elm$core$Maybe$andThen,
							function (current) {
								return _Utils_eq(current.c3, target) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(current);
							},
							state.aC);
						var invalidated = A2($elm$core$List$cons, target, state.aT);
						return _Utils_Tuple2(
							_Utils_update(
								state,
								{aT: invalidated, aC: menu}),
							_List_Nil);
					}
				}
			default:
				var output = message.a;
				var generation = message.b;
				var retired = _Utils_Tuple2(output, generation);
				if (A2($elm$core$List$member, retired, state.a_) || state.aA) {
					return unchanged;
				} else {
					if (_Utils_cmp(
						$elm$core$List$length(state.aT) + $elm$core$List$length(state.a_),
						$author$project$Menu$maxRetired) > -1) {
						return _Utils_Tuple2(
							_Utils_update(
								state,
								{aA: true, aC: $elm$core$Maybe$Nothing}),
							_List_Nil);
					} else {
						var retiredOutputs = A2($elm$core$List$cons, retired, state.a_);
						var menu = A2(
							$elm$core$Maybe$andThen,
							function (current) {
								return _Utils_eq(
									$author$project$Menu$outputTuple(current.c3),
									retired) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(current);
							},
							state.aC);
						return _Utils_Tuple2(
							_Utils_update(
								state,
								{aC: menu, a_: retiredOutputs}),
							_List_Nil);
					}
				}
		}
	});
var $author$project$MenuBridge$refuse = F4(
	function (local, binding, reason, _v0) {
		var state = _v0;
		var _v1 = A2(
			$author$project$Menu$update,
			A3(
				$author$project$Menu$ReceiveFor,
				local,
				binding,
				$author$project$Menu$Refusal(reason)),
			state.aC);
		var menu = _v1.a;
		return _Utils_update(
			state,
			{aC: menu});
	});
var $author$project$Shell$Reconciling = 1;
var $author$project$Shell$Send = function (a) {
	return {$: 0, a: a};
};
var $author$project$Shell$refresh = function (model) {
	if (model.c1) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = _Utils_Tuple2(
			model.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			return ((!model.m) || model.aa) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						y: $elm$core$Maybe$Just(request),
						m: 1,
						aZ: false,
						cM: request
					}),
				_List_fromArray(
					[
						$author$project$Shell$Send(
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'protocolVersion',
									$elm$json$Json$Encode$int(3)),
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('projection-request')),
									_Utils_Tuple2(
									'binding',
									$author$project$Binding$encode(binding)),
									_Utils_Tuple2(
									'requestId',
									$elm$json$Json$Encode$string(
										$author$project$UInt64$string(request)))
								])))
					]));
		} else {
			return _Utils_Tuple2(
				_Utils_update(
					model,
					{y: $elm$core$Maybe$Nothing, fj: 'Restart the shell to continue.', m: 3, aZ: false}),
				_List_Nil);
		}
	}
};
var $author$project$Shell$geometryRequest = F2(
	function (attach, model) {
		if (model.c1 || model.aa) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var _v0 = _Utils_Tuple2(
				model.c3,
				$author$project$UInt64$next(model.cM));
			if ((!_v0.a.$) && (!_v0.b.$)) {
				var binding = _v0.a.a;
				var request = _v0.b.a;
				if ((!model.m) || ((attach && (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing))) || ((!attach) && (_Utils_eq(model.dc, $elm$core$Maybe$Nothing) || (!_Utils_eq(model.cE, $elm$core$Maybe$Nothing)))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var common = _List_fromArray(
						[
							_Utils_Tuple2(
							'protocolVersion',
							$elm$json$Json$Encode$int(3)),
							_Utils_Tuple2(
							'kind',
							$elm$json$Json$Encode$string(
								attach ? 'geometry-attach' : 'geometry-facts-request')),
							_Utils_Tuple2(
							'geometryProtocol',
							$elm$json$Json$Encode$int(3)),
							_Utils_Tuple2(
							'binding',
							$author$project$Binding$encode(binding)),
							_Utils_Tuple2(
							'requestId',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(request)))
						]);
					var payload = attach ? common : _Utils_ap(
						common,
						_List_fromArray(
							[
								_Utils_Tuple2(
								'minimumWatermark',
								$elm$json$Json$Encode$string(
									A2(
										$elm$core$Maybe$withDefault,
										'0',
										A2(
											$elm$core$Maybe$map,
											A2(
												$elm$core$Basics$composeR,
												function ($) {
													return $.eC;
												},
												$author$project$UInt64$string),
											model.ac))))
							]));
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{
								ar: attach || model.ar,
								dY: attach ? $elm$core$Maybe$Just(request) : model.dY,
								cE: attach ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(request),
								cM: request
							}),
						_List_fromArray(
							[
								$author$project$Shell$Send(
								$elm$json$Json$Encode$object(payload))
							]));
				}
			} else {
				return _Utils_Tuple2(model, _List_Nil);
			}
		}
	});
var $author$project$Shell$geometrySupported = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.V;
			},
			model.dc));
};
var $author$project$Shell$refreshObservations = function (model) {
	if (model.c1 || model.aa) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = $author$project$Shell$refresh(
			_Utils_update(
				model,
				{aD: false}));
		var legacy = _v0.a;
		var commands = _v0.b;
		if (legacy.ar) {
			var _v1 = A2($author$project$Shell$geometryRequest, true, legacy);
			var attached = _v1.a;
			var attachCommands = _v1.b;
			return _Utils_Tuple2(
				attached,
				_Utils_ap(commands, attachCommands));
		} else {
			if ($author$project$Shell$geometrySupported(legacy)) {
				var _v2 = A2($author$project$Shell$geometryRequest, false, legacy);
				var geometry = _v2.a;
				var geometryCommands = _v2.b;
				return _Utils_Tuple2(
					geometry,
					_Utils_ap(commands, geometryCommands));
			} else {
				return _Utils_Tuple2(legacy, commands);
			}
		}
	}
};
var $author$project$Shell$drainNotifications = function (model) {
	return model.aZ ? (((!model.m) || ((model.m === 3) || _Utils_eq(model.c3, $elm$core$Maybe$Nothing))) ? _Utils_Tuple2(
		_Utils_update(
			model,
			{aZ: false}),
		_List_Nil) : ((model.aa || (model.dO || ($author$project$Effects$pending(model.V) || ((!_Utils_eq(model.y, $elm$core$Maybe$Nothing)) || (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing)))))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Shell$refresh(model))) : (((!model.aa) && ((!model.dO) && (model.aD && ((model.m === 2) && ((!$author$project$Effects$pending(model.V)) && (_Utils_eq(model.y, $elm$core$Maybe$Nothing) && (_Utils_eq(model.cE, $elm$core$Maybe$Nothing) && _Utils_eq(model.dY, $elm$core$Maybe$Nothing)))))))) ? $author$project$Shell$refreshObservations(model) : _Utils_Tuple2(model, _List_Nil));
};
var $author$project$Shell$resumeNotifications = function (model) {
	return $author$project$Shell$drainNotifications(
		_Utils_update(
			model,
			{dO: false}));
};
var $author$project$MenuBridge$cancelPrepared = F3(
	function (reason, shell, model) {
		var state = model;
		var _v0 = state.Q;
		if (_v0.$ === 1) {
			return A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		} else {
			var slot = _v0.a;
			var cleared = A4(
				$author$project$MenuBridge$refuse,
				slot.ch,
				slot.bU,
				reason,
				_Utils_update(
					state,
					{Q: $elm$core$Maybe$Nothing}));
			var _v1 = $author$project$Shell$resumeNotifications(shell);
			var resumed = _v1.a;
			var effects = _v1.b;
			return A4(
				$author$project$MenuBridge$answer,
				cleared,
				resumed,
				effects,
				$elm$core$Maybe$Just(reason));
		}
	});
var $author$project$Shell$captureGeometry = function (model) {
	return A2(
		$elm$core$Maybe$map,
		function (observed) {
			return A3($author$project$Shell$Stamp, observed.c3, observed.R.z, observed.R.cN);
		},
		model.ac);
};
var $author$project$Provider$nativeContext = function (_v0) {
	var value = _v0;
	return {e4: value.R.dW, fe: value.R.fe, z: value.R.fm, cN: value.R.cN};
};
var $author$project$MenuBridge$sameWindowFacts = F2(
	function (before, after) {
		var ordered = $elm$core$List$sortWith(
			F2(
				function (a, b) {
					return A2($author$project$UInt64$compare, a.au, b.au);
				}));
		return _Utils_eq(
			ordered(before),
			ordered(after));
	});
var $author$project$MenuBridge$compatiblePrepared = F2(
	function (slot, shell) {
		var original = slot.ax.c;
		var sameGeometry = function () {
			var _v0 = _Utils_Tuple2(
				$author$project$Provider$geometryObservation(original),
				shell.ac);
			if (_v0.a.$ === 1) {
				var _v1 = _v0.a;
				return _Utils_eq(slot.a8, $elm$core$Maybe$Nothing);
			} else {
				if (!_v0.b.$) {
					var before = _v0.a.a;
					var after = _v0.b.a;
					return _Utils_eq(before.c3, after.c3) && (_Utils_eq(before.R.fe, after.R.fe) && (_Utils_eq(before.R.e4, after.R.e4) && (_Utils_eq(before.R.z, after.R.z) && ((!(!A2($author$project$UInt64$compare, after.R.cN, before.R.cN))) && ((!(!A2($author$project$UInt64$compare, after.eC, before.eC))) && ((!after.eZ) && A2($author$project$MenuBridge$sameWindowFacts, before.a, after.a)))))));
				} else {
					return false;
				}
			}
		}();
		var old = $author$project$Provider$nativeContext(original);
		var legacy = shell.V.av;
		var sameLegacy = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (observed) {
					return _Utils_eq(observed.R.fe, old.fe) && (_Utils_eq(observed.R.e4, old.e4) && (_Utils_eq(observed.R.z, old.z) && ((!(!A2($author$project$UInt64$compare, observed.R.cN, old.cN))) && (A2(
						$author$project$MenuBridge$sameWindowFacts,
						$author$project$ActionProjection$windows(observed.eA),
						slot.df) && _Utils_eq(
						A2(
							$author$project$ActionProjection$rootOf,
							$author$project$Provider$incarnation(original),
							observed.eA),
						$elm$core$Maybe$Just(
							$author$project$Provider$incarnation(original)))))));
				},
				legacy));
		return _Utils_eq(
			shell.c3,
			$elm$core$Maybe$Just(
				$author$project$Provider$nativeBinding(original))) && (_Utils_eq(shell.dc, slot.dc) && (sameLegacy && sameGeometry));
	});
var $author$project$NativeProvider$counter = A2($elm$core$Basics$composeR, $author$project$UInt64$string, $elm$json$Json$Encode$string);
var $author$project$Provider$Raw = F7(
	function (provider, capabilitiesGeneration, context, target, heading, capabilities, entries) {
		return {cx: capabilities, c5: capabilitiesGeneration, R: context, ak: entries, d$: heading, bB: provider, fK: target};
	});
var $author$project$Provider$Snapshot = $elm$core$Basics$identity;
var $author$project$Menu$Binding = $elm$core$Basics$identity;
var $author$project$Menu$binding = $elm$core$Basics$identity;
var $elm$json$Json$Decode$index = _Json_decodeIndex;
var $author$project$Provider$boundedList = F2(
	function (limit, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				var _v0 = A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$index, limit, $elm$json$Json$Decode$value),
					value);
				if (!_v0.$) {
					return $elm$json$Json$Decode$fail('Provider array bound');
				} else {
					return $elm$json$Json$Decode$list(body);
				}
			},
			$elm$json$Json$Decode$value);
	});
var $author$project$Provider$Context = F7(
	function (_native, lifetime, session, frontend, revision, outputId, outputGeneration) {
		return {dW: frontend, fe: lifetime, eb: _native, fm: outputGeneration, dl: outputId, cN: revision, fF: session};
	});
var $author$project$Provider$nonzero = A2(
	$elm$json$Json$Decode$andThen,
	function (counter) {
		return _Utils_eq(counter, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero provider identity') : $elm$json$Json$Decode$succeed(counter);
	},
	$author$project$UInt64$decoder);
var $author$project$Provider$nativeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		var _v0 = A2($elm$json$Json$Decode$decodeValue, $author$project$Binding$decoder, value);
		if (!_v0.$) {
			var _native = _v0.a;
			return $elm$json$Json$Decode$succeed(_native);
		} else {
			return $elm$json$Json$Decode$fail('Native provider binding');
		}
	},
	A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (lifetime, session, frontend) {
				return $elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'lifetime',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(lifetime))),
							_Utils_Tuple2(
							'session',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(session))),
							_Utils_Tuple2(
							'frontend',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(frontend)))
						]));
			}),
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'session', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$Provider$nonzero)));
var $author$project$Provider$strict = F2(
	function (fields, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? body : $elm$json$Json$Decode$fail('Unexpected provider fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Provider$contextDecoder = A2(
	$author$project$Provider$strict,
	_List_fromArray(
		['lifetime', 'session', 'frontend', 'revision', 'outputId', 'outputGeneration']),
	A8(
		$elm$json$Json$Decode$map7,
		$author$project$Provider$Context,
		$author$project$Provider$nativeDecoder,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'session', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'frontend', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'outputId', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$Provider$nonzero)));
var $author$project$Menu$AlwaysOnTop = function (a) {
	return {$: 8, a: a};
};
var $author$project$Menu$Close = {$: 6};
var $author$project$Menu$Minimize = {$: 4};
var $author$project$Menu$Move = {$: 2};
var $author$project$Menu$Restore = {$: 0};
var $author$project$Menu$Size = {$: 3};
var $author$project$Provider$actionKinds = _List_fromArray(
	['Restore', 'Minimize', 'Move', 'Size', 'Maximize', 'Close', 'ExitFullscreen', 'AlwaysOnTop']);
var $author$project$Provider$kindDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		return A2($elm$core$List$member, kind, $author$project$Provider$actionKinds) ? $elm$json$Json$Decode$succeed(kind) : $elm$json$Json$Decode$fail('Unsupported window action');
	},
	$elm$json$Json$Decode$string);
var $author$project$Provider$actionDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (kind) {
		var plain = function (action) {
			return A2(
				$author$project$Provider$strict,
				_List_fromArray(
					['kind']),
				$elm$json$Json$Decode$succeed(
					_Utils_Tuple2(kind, action)));
		};
		switch (kind) {
			case 'Restore':
				return plain($author$project$Menu$Restore);
			case 'Minimize':
				return plain($author$project$Menu$Minimize);
			case 'Move':
				return plain($author$project$Menu$Move);
			case 'Size':
				return plain($author$project$Menu$Size);
			case 'Maximize':
				return plain($author$project$Menu$Maximize);
			case 'Close':
				return plain($author$project$Menu$Close);
			case 'ExitFullscreen':
				return plain($author$project$Menu$ExitFullscreen);
			case 'AlwaysOnTop':
				return A2(
					$author$project$Provider$strict,
					_List_fromArray(
						['kind', 'checked']),
					A2(
						$elm$json$Json$Decode$map,
						function (checked) {
							return _Utils_Tuple2(
								kind,
								$author$project$Menu$AlwaysOnTop(checked));
						},
						A2($elm$json$Json$Decode$field, 'checked', $elm$json$Json$Decode$bool)));
			default:
				return $elm$json$Json$Decode$fail('Unsupported window action');
		}
	},
	A2($elm$json$Json$Decode$field, 'kind', $author$project$Provider$kindDecoder));
var $author$project$Provider$validUnicode = function (value) {
	validUnicode:
	while (true) {
		var _v0 = $elm$core$String$uncons(value);
		if (_v0.$ === 1) {
			return true;
		} else {
			var _v1 = _v0.a;
			var character = _v1.a;
			var rest = _v1.b;
			var units = $elm$core$String$fromChar(character);
			var code = $elm$core$Char$toCode(character);
			var valid = function () {
				if ($elm$core$String$length(units) === 1) {
					return (code < 55296) || (code > 57343);
				} else {
					if ($elm$core$String$length(units) === 2) {
						var _v2 = $elm$core$String$uncons(
							A2($elm$core$String$dropLeft, 1, units));
						if (!_v2.$) {
							var _v3 = _v2.a;
							var second = _v3.a;
							var low = $elm$core$Char$toCode(second);
							return (low >= 56320) && ((low <= 57343) && ((code >= 65536) && (code <= 1114111)));
						} else {
							return false;
						}
					} else {
						return false;
					}
				}
			}();
			if (valid) {
				var $temp$value = rest;
				value = $temp$value;
				continue validUnicode;
			} else {
				return false;
			}
		}
	}
};
var $author$project$Provider$textDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		var forbidden = function (character) {
			var code = $elm$core$Char$toCode(character);
			return (code < 32) || (((code >= 127) && (code <= 159)) || ((code >= 55296) && (code <= 57343)));
		};
		return (($elm$core$String$length(value) > 256) || ((!$author$project$Provider$validUnicode(value)) || ($elm$core$String$isEmpty(
			$elm$core$String$trim(value)) || A2($elm$core$String$any, forbidden, value)))) ? $elm$json$Json$Decode$fail('Invalid provider label/title') : $elm$json$Json$Decode$succeed(value);
	},
	$elm$json$Json$Decode$string);
var $author$project$Provider$entryDecoder = A2(
	$author$project$Provider$strict,
	_List_fromArray(
		['id', 'label', 'enabled', 'action']),
	A5(
		$elm$json$Json$Decode$map4,
		F4(
			function (identity, label, enabled, _v0) {
				var kind = _v0.a;
				var action = _v0.b;
				return {
					cc: $author$project$UInt64$string(identity),
					cd: {eV: action, b9: enabled, d6: label},
					d4: kind
				};
			}),
		A2($elm$json$Json$Decode$field, 'id', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'label', $author$project$Provider$textDecoder),
		A2($elm$json$Json$Decode$field, 'enabled', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'action', $author$project$Provider$actionDecoder)));
var $elm$core$Set$Set_elm_builtin = $elm$core$Basics$identity;
var $elm$core$Set$empty = $elm$core$Dict$empty;
var $elm$core$Set$insert = F2(
	function (key, _v0) {
		var dict = _v0;
		return A3($elm$core$Dict$insert, key, 0, dict);
	});
var $elm$core$Set$fromList = function (list) {
	return A3($elm$core$List$foldl, $elm$core$Set$insert, $elm$core$Set$empty, list);
};
var $author$project$Menu$OutputId = $elm$core$Basics$identity;
var $author$project$Menu$outputId = $elm$core$Basics$identity;
var $elm$core$Set$size = function (_v0) {
	var dict = _v0;
	return $elm$core$Dict$size(dict);
};
var $author$project$Provider$Target = F3(
	function (lifetime, session, incarnation) {
		return {au: incarnation, fe: lifetime, fF: session};
	});
var $author$project$Provider$targetDecoder = A2(
	$author$project$Provider$strict,
	_List_fromArray(
		['lifetime', 'session', 'incarnation']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$Provider$Target,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'session', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Provider$nonzero)));
var $author$project$Provider$envelopeDecoder = function () {
	var version = A2(
		$elm$json$Json$Decode$andThen,
		function (number) {
			return (number === 1) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Provider protocol version');
		},
		A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int));
	var body = A8(
		$elm$json$Json$Decode$map7,
		$author$project$Provider$Raw,
		A2($elm$json$Json$Decode$field, 'providerId', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'capabilityGeneration', $author$project$Provider$nonzero),
		A2($elm$json$Json$Decode$field, 'binding', $author$project$Provider$contextDecoder),
		A2($elm$json$Json$Decode$field, 'target', $author$project$Provider$targetDecoder),
		A2($elm$json$Json$Decode$field, 'title', $author$project$Provider$textDecoder),
		A2(
			$elm$json$Json$Decode$field,
			'capabilities',
			A2($author$project$Provider$boundedList, 8, $author$project$Provider$kindDecoder)),
		A2(
			$elm$json$Json$Decode$field,
			'items',
			A2($author$project$Provider$boundedList, 64, $author$project$Provider$entryDecoder)));
	return A2(
		$elm$json$Json$Decode$andThen,
		function (raw) {
			var unsupportedEnabled = A2(
				$elm$core$List$any,
				function (entry) {
					return entry.cd.b9 && (!A2($elm$core$List$member, entry.d4, raw.cx));
				},
				raw.ak);
			var identities = A2(
				$elm$core$List$map,
				function ($) {
					return $.cc;
				},
				raw.ak);
			var duplicateIds = !_Utils_eq(
				$elm$core$List$length(identities),
				$elm$core$Set$size(
					$elm$core$Set$fromList(identities)));
			var duplicateCapabilities = !_Utils_eq(
				$elm$core$List$length(raw.cx),
				$elm$core$Set$size(
					$elm$core$Set$fromList(raw.cx)));
			var coherent = _Utils_eq(raw.fK.fe, raw.R.fe) && _Utils_eq(raw.fK.fF, raw.R.fF);
			var authority = A2(
				$elm$json$Json$Encode$encode,
				0,
				A2(
					$elm$json$Json$Encode$list,
					$elm$core$Basics$identity,
					_List_fromArray(
						[
							$author$project$Binding$encode(raw.R.eb),
							$elm$json$Json$Encode$string(
							$author$project$UInt64$string(raw.bB)),
							$elm$json$Json$Encode$string(
							$author$project$UInt64$string(raw.c5))
						])));
			var actions = A2(
				$elm$core$List$map,
				A2(
					$elm$core$Basics$composeR,
					function ($) {
						return $.cd;
					},
					function ($) {
						return $.eV;
					}),
				raw.ak);
			var uniqueActions = A3(
				$elm$core$List$foldl,
				F2(
					function (action, seen) {
						return A2($elm$core$List$member, action, seen) ? seen : A2($elm$core$List$cons, action, seen);
					}),
				_List_Nil,
				actions);
			var duplicateActions = !_Utils_eq(
				$elm$core$List$length(actions),
				$elm$core$List$length(uniqueActions));
			return ((!coherent) || (duplicateIds || (duplicateActions || (duplicateCapabilities || unsupportedEnabled)))) ? $elm$json$Json$Decode$fail('Incoherent provider identity/capabilities') : $elm$json$Json$Decode$succeed(
				{
					c3: $author$project$Menu$binding(
						{
							dG: authority,
							z: $author$project$Menu$outputId(
								$author$project$UInt64$string(raw.R.dl)),
							fm: $author$project$UInt64$string(raw.R.fm),
							cN: $author$project$UInt64$string(raw.R.cN),
							fK: $author$project$Menu$Window(
								A2(
									$author$project$Menu$windowId,
									$author$project$Binding$authorityIdentity(raw.R.eb),
									$author$project$UInt64$string(raw.fK.au)))
						}),
					e_: raw.c5,
					R: raw.R,
					ac: $elm$core$Maybe$Nothing,
					au: raw.fK.au,
					fd: A2(
						$elm$core$List$map,
						function ($) {
							return $.cd;
						},
						raw.ak),
					ds: raw.bB,
					eI: raw.d$
				});
		},
		A2(
			$author$project$Provider$strict,
			_List_fromArray(
				['protocolVersion', 'providerId', 'capabilityGeneration', 'binding', 'target', 'title', 'capabilities', 'items']),
			A3(
				$elm$json$Json$Decode$map2,
				F2(
					function (_v0, raw) {
						return raw;
					}),
				version,
				body)));
}();
var $author$project$Provider$maximumBytes = 16384;
var $elm$core$String$foldl = _String_foldl;
var $author$project$Provider$utf8Bytes = function (value) {
	return A3(
		$elm$core$String$foldl,
		F2(
			function (character, total) {
				var code = $elm$core$Char$toCode(character);
				return total + ((code <= 127) ? 1 : ((code <= 2047) ? 2 : ((code <= 65535) ? 3 : 4)));
			}),
		0,
		value);
};
var $author$project$Provider$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (validated) {
				return (_Utils_cmp(
					$author$project$Provider$utf8Bytes(
						A2($elm$json$Json$Encode$encode, 0, value)),
					$author$project$Provider$maximumBytes) > 0) ? $elm$json$Json$Decode$fail('Provider encoded byte bound') : $elm$json$Json$Decode$succeed(validated);
			},
			$author$project$Provider$envelopeDecoder);
	},
	$elm$json$Json$Decode$value);
var $author$project$Provider$errorSummary = function (error) {
	switch (error.$) {
		case 0:
			var field = error.a;
			var nested = error.b;
			return 'Provider field ' + (field + (': ' + $author$project$Provider$errorSummary(nested)));
		case 1:
			var index = error.a;
			var nested = error.b;
			return 'Provider index ' + ($elm$core$String$fromInt(index) + (': ' + $author$project$Provider$errorSummary(nested)));
		case 2:
			return 'Provider alternatives rejected';
		default:
			var reason = error.a;
			return A2($elm$core$String$left, 256, reason);
	}
};
var $author$project$Provider$decode = function (value) {
	return A2(
		$elm$core$Result$mapError,
		$author$project$Provider$errorSummary,
		A2($elm$json$Json$Decode$decodeValue, $author$project$Provider$decoder, value));
};
var $author$project$NativeProvider$legacyFromShell = F3(
	function (scope, incarnation, shell) {
		if (_Utils_eq(scope.dl, $author$project$UInt64$zero) || (_Utils_eq(scope.ds, $author$project$UInt64$zero) || _Utils_eq(scope.e_, $author$project$UInt64$zero))) {
			return $elm$core$Result$Err('Missing registered provider/output identity');
		} else {
			if (shell.m !== 2) {
				return $elm$core$Result$Err('Native window facts are not ready');
			} else {
				var _v0 = _Utils_Tuple2(shell.c3, shell.V.av);
				if ((!_v0.a.$) && (!_v0.b.$)) {
					var binding = _v0.a.a;
					var observed = _v0.b.a;
					if (!A3($author$project$Binding$matchesContext, observed.R.fe, observed.R.e4, binding)) {
						return $elm$core$Result$Err('Native observation binding mismatch');
					} else {
						var _v1 = A2(
							$elm$core$Maybe$andThen,
							function (root) {
								return $elm$core$List$head(
									A2(
										$elm$core$List$filter,
										function (window) {
											return _Utils_eq(window.au, root);
										},
										$author$project$ActionProjection$windows(observed.eA)));
							},
							A2($author$project$ActionProjection$rootOf, incarnation, observed.eA));
						if (_v1.$ === 1) {
							return $elm$core$Result$Err('Native window no longer exists');
						} else {
							var window = _v1.a;
							var positive = function (name) {
								return A2($elm$json$Json$Decode$field, name, $author$project$UInt64$decoder);
							};
							var item = F4(
								function (id, label, enabled, kind) {
									return $elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'id',
												$elm$json$Json$Encode$string(id)),
												_Utils_Tuple2(
												'label',
												$elm$json$Json$Encode$string(label)),
												_Utils_Tuple2(
												'enabled',
												$elm$json$Json$Encode$bool(enabled)),
												_Utils_Tuple2(
												'action',
												$elm$json$Json$Encode$object(
													_List_fromArray(
														[
															_Utils_Tuple2(
															'kind',
															$elm$json$Json$Encode$string(kind))
														])))
											]));
								});
							var identities = A2(
								$elm$json$Json$Decode$decodeValue,
								A4(
									$elm$json$Json$Decode$map3,
									F3(
										function (life, session, frontend) {
											return _Utils_Tuple3(life, session, frontend);
										}),
									positive('lifetime'),
									positive('session'),
									positive('frontend')),
								$author$project$Binding$encode(binding));
							if (identities.$ === 1) {
								return $elm$core$Result$Err('Invalid native identity');
							} else {
								var _v3 = identities.a;
								var lifetime = _v3.a;
								var session = _v3.b;
								var frontend = _v3.c;
								return $author$project$Provider$decode(
									$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'protocolVersion',
												$elm$json$Json$Encode$int(1)),
												_Utils_Tuple2(
												'providerId',
												$author$project$NativeProvider$counter(scope.ds)),
												_Utils_Tuple2(
												'capabilityGeneration',
												$author$project$NativeProvider$counter(scope.e_)),
												_Utils_Tuple2(
												'binding',
												$elm$json$Json$Encode$object(
													_List_fromArray(
														[
															_Utils_Tuple2(
															'lifetime',
															$author$project$NativeProvider$counter(lifetime)),
															_Utils_Tuple2(
															'session',
															$author$project$NativeProvider$counter(session)),
															_Utils_Tuple2(
															'frontend',
															$author$project$NativeProvider$counter(frontend)),
															_Utils_Tuple2(
															'revision',
															$author$project$NativeProvider$counter(observed.R.cN)),
															_Utils_Tuple2(
															'outputId',
															$author$project$NativeProvider$counter(scope.dl)),
															_Utils_Tuple2(
															'outputGeneration',
															$author$project$NativeProvider$counter(observed.R.z))
														]))),
												_Utils_Tuple2(
												'target',
												$elm$json$Json$Encode$object(
													_List_fromArray(
														[
															_Utils_Tuple2(
															'lifetime',
															$author$project$NativeProvider$counter(lifetime)),
															_Utils_Tuple2(
															'session',
															$author$project$NativeProvider$counter(session)),
															_Utils_Tuple2(
															'incarnation',
															$author$project$NativeProvider$counter(window.au))
														]))),
												_Utils_Tuple2(
												'title',
												$elm$json$Json$Encode$string(
													($elm$core$String$trim(window.d6) === '') ? 'Window actions' : window.d6)),
												_Utils_Tuple2(
												'capabilities',
												A2(
													$elm$json$Json$Encode$list,
													$elm$json$Json$Encode$string,
													_List_fromArray(
														['Restore', 'Minimize']))),
												_Utils_Tuple2(
												'items',
												A2(
													$elm$json$Json$Encode$list,
													$elm$core$Basics$identity,
													_List_fromArray(
														[
															A4(item, '1', 'Restore', window.c2 && window.bR, 'Restore'),
															A4(item, '2', 'Minimize', window.c2 && (!window.bR), 'Minimize')
														])))
											])));
							}
						}
					}
				} else {
					return $elm$core$Result$Err('No admitted native window observation');
				}
			}
		}
	});
var $author$project$ActionProjection$find = F2(
	function (identity, rows) {
		return $elm$core$List$head(
			A2(
				$elm$core$List$filter,
				function (w) {
					return _Utils_eq(w.au, identity);
				},
				rows));
	});
var $author$project$ActionProjection$minimized = F2(
	function (identity, projection) {
		return A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.bR;
			},
			A2(
				$author$project$ActionProjection$find,
				identity,
				$author$project$ActionProjection$windows(projection)));
	});
var $author$project$GeometryProjection$CanExitFullscreen = 6;
var $author$project$GeometryProjection$CanMaximize = 0;
var $author$project$GeometryProjection$CanPin = 4;
var $author$project$GeometryProjection$CanRestoreGeometry = 1;
var $author$project$GeometryProjection$CanUnpin = 5;
var $author$project$GeometryProjection$Fullscreen = 2;
var $author$project$GeometryProjection$canExitFullscreen = function (row) {
	return (row.ec === 2) && ((row.b8 === 2) && (_Utils_eq(row.dm, $elm$core$Maybe$Nothing) && ((!row.bt) && ((!row.bR) && ((!_Utils_eq(row.dB, $elm$core$Maybe$Nothing)) && ((!_Utils_eq(row.bS, $elm$core$Maybe$Nothing)) && A2(
		$elm$core$Maybe$withDefault,
		false,
		A2(
			$elm$core$Maybe$map,
			function (pin) {
				return !pin.fr;
			},
			row.dp))))))));
};
var $author$project$GeometryProjection$capabilityName = function (capability) {
	switch (capability) {
		case 0:
			return 'maximize';
		case 1:
			return 'restore-geometry';
		case 2:
			return 'snap';
		case 3:
			return 'transfer-workspace';
		case 4:
			return 'pin';
		case 5:
			return 'unpin';
		default:
			return 'exit-fullscreen';
	}
};
var $author$project$Provider$withGeometry = F3(
	function (caps, observed, snapshot) {
		var state = snapshot;
		if ((!_Utils_eq(observed.c3, state.R.eb)) || (!_Utils_eq(observed.R.z, state.R.fm))) {
			return $elm$core$Result$Err('Geometry/legacy authority mismatch');
		} else {
			var _v0 = A2($author$project$GeometryProjection$window, state.au, observed);
			if (_v0.$ === 1) {
				return $elm$core$Result$Err('Geometry target missing');
			} else {
				var window = _v0.a;
				var supported = function (op) {
					return caps.V && A2($elm$core$List$member, op, caps.ef);
				};
				var restoreGeometry = supported(1) && (!window.bR);
				var ready = A2(
					$elm$core$List$any,
					function ($) {
						return $.b9;
					},
					state.fd) && ((!observed.eZ) && (window.da && (!window.e6)));
				var pinItems = A2(
					$elm$core$Maybe$withDefault,
					_List_Nil,
					A2(
						$elm$core$Maybe$map,
						function (pin) {
							return (supported(4) && supported(5)) ? _List_fromArray(
								[
									{
									eV: $author$project$Menu$AlwaysOnTop(!pin.fr),
									b9: (!observed.eZ) && pin.da,
									d6: 'Always on top'
								}
								]) : _List_Nil;
						},
						window.dp));
				var legacyRestore = $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (item) {
							return _Utils_eq(item.eV, $author$project$Menu$Restore);
						},
						state.fd));
				var restore = restoreGeometry ? {eV: $author$project$Menu$RestoreGeometry, b9: ready && (window.fA && ((window.ec === 1) && window.fs)), d6: 'Restore'} : A2(
					$elm$core$Maybe$withDefault,
					{eV: $author$project$Menu$Restore, b9: false, d6: 'Restore'},
					legacyRestore);
				var legacyMinimize = $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (item) {
							return _Utils_eq(item.eV, $author$project$Menu$Minimize);
						},
						state.fd));
				var minimize = A2(
					$elm$core$Maybe$withDefault,
					{eV: $author$project$Menu$Minimize, b9: false, d6: 'Minimize'},
					legacyMinimize);
				var exitItems = (supported(6) && (window.ec === 2)) ? _List_fromArray(
					[
						{
						eV: $author$project$Menu$ExitFullscreen,
						b9: A2(
							$elm$core$List$any,
							function ($) {
								return $.b9;
							},
							state.fd) && ((!observed.eZ) && $author$project$GeometryProjection$canExitFullscreen(window)),
						d6: 'Exit fullscreen'
					}
					]) : _List_Nil;
				var items = _Utils_ap(
					_List_fromArray(
						[restore, minimize]),
					_Utils_ap(
						exitItems,
						_Utils_ap(
							pinItems,
							supported(0) ? _List_fromArray(
								[
									{eV: $author$project$Menu$Maximize, b9: ready && (window.fg && ((!window.bR) && (!window.ec))), d6: 'Maximize'}
								]) : _List_Nil)));
				var authority = A2(
					$elm$json$Json$Encode$encode,
					0,
					A2(
						$elm$json$Json$Encode$list,
						$elm$core$Basics$identity,
						_List_fromArray(
							[
								$elm$json$Json$Encode$string(
								A2(
									$elm$json$Json$Encode$encode,
									0,
									$author$project$Binding$encode(state.R.eb)) + (':' + ($author$project$UInt64$string(state.ds) + (':' + ($author$project$UInt64$string(state.e_) + (':' + $author$project$UInt64$string(state.R.cN))))))),
								$elm$json$Json$Encode$string(
								$author$project$UInt64$string(observed.R.cN)),
								$elm$json$Json$Encode$string(
								$author$project$UInt64$string(observed.R.z)),
								A2(
								$elm$json$Json$Encode$list,
								A2($elm$core$Basics$composeL, $elm$json$Json$Encode$string, $author$project$GeometryProjection$capabilityName),
								caps.ef)
							])));
				return $elm$core$Result$Ok(
					_Utils_update(
						state,
						{
							c3: $author$project$Menu$binding(
								{
									dG: authority,
									z: $author$project$Menu$outputId(
										$author$project$UInt64$string(state.R.dl)),
									fm: $author$project$UInt64$string(observed.R.z),
									cN: $author$project$UInt64$string(observed.R.cN),
									fK: $author$project$Menu$Window(
										A2(
											$author$project$Menu$windowId,
											$author$project$Binding$authorityIdentity(state.R.eb),
											$author$project$UInt64$string(state.au)))
								}),
							ac: $elm$core$Maybe$Just(observed),
							fd: items
						}));
			}
		}
	});
var $author$project$NativeProvider$fromShell = F3(
	function (scope, incarnation, shell) {
		return A2(
			$elm$core$Result$andThen,
			function (legacy) {
				var _v0 = shell.dc;
				if (_v0.$ === 1) {
					return $elm$core$Result$Ok(legacy);
				} else {
					var caps = _v0.a;
					if (!caps.V) {
						return $elm$core$Result$Ok(legacy);
					} else {
						var _v1 = _Utils_Tuple3(shell.ac, shell.cE, shell.V.av);
						if (((!_v1.a.$) && (_v1.b.$ === 1)) && (!_v1.c.$)) {
							var observed = _v1.a.a;
							var _v2 = _v1.b;
							var legacyObserved = _v1.c.a;
							var root = $author$project$Provider$incarnation(legacy);
							var legacyMinimized = A2($author$project$ActionProjection$minimized, root, legacyObserved.eA);
							var geometryMinimized = A2(
								$elm$core$Maybe$map,
								function ($) {
									return $.bR;
								},
								A2($author$project$GeometryProjection$window, root, observed));
							return (!_Utils_eq(legacyMinimized, geometryMinimized)) ? $elm$core$Result$Err('Independent geometry/legacy facts disagree') : A3($author$project$Provider$withGeometry, caps, observed, legacy);
						} else {
							return $elm$core$Result$Err('Geometry facts are awaiting fresh observation');
						}
					}
				}
			},
			A3($author$project$NativeProvider$legacyFromShell, scope, incarnation, shell));
	});
var $author$project$Effects$ExitFullscreen = {$: 5};
var $author$project$Effects$Maximize = {$: 3};
var $author$project$Effects$Pin = {$: 8};
var $author$project$Effects$RestoreGeometry = {$: 4};
var $author$project$Effects$Unpin = {$: 9};
var $author$project$MenuBridge$operation = function (action) {
	switch (action.$) {
		case 4:
			return $elm$core$Maybe$Just($author$project$Effects$Minimize);
		case 0:
			return $elm$core$Maybe$Just($author$project$Effects$Restore);
		case 5:
			return $elm$core$Maybe$Just($author$project$Effects$Maximize);
		case 1:
			return $elm$core$Maybe$Just($author$project$Effects$RestoreGeometry);
		case 7:
			return $elm$core$Maybe$Just($author$project$Effects$ExitFullscreen);
		case 8:
			var desired = action.a;
			return $elm$core$Maybe$Just(
				desired ? $author$project$Effects$Pin : $author$project$Effects$Unpin);
		default:
			return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Provider$presentationScope = function (_v0) {
	var value = _v0;
	return {dl: value.R.dl, ds: value.ds};
};
var $author$project$ReceiptRouter$Model = $elm$core$Basics$identity;
var $author$project$Provider$getItems = function (_v0) {
	var value = _v0;
	return value.fd;
};
var $elm$core$Result$map = F2(
	function (func, ra) {
		if (!ra.$) {
			var a = ra.a;
			return $elm$core$Result$Ok(
				func(a));
		} else {
			var e = ra.a;
			return $elm$core$Result$Err(e);
		}
	});
var $author$project$ReceiptRouter$ExitFullscreen = 4;
var $author$project$ReceiptRouter$Maximize = 2;
var $author$project$ReceiptRouter$Minimize = 0;
var $author$project$ReceiptRouter$Pin = 5;
var $author$project$ReceiptRouter$Restore = 1;
var $author$project$ReceiptRouter$RestoreGeometry = 3;
var $author$project$ReceiptRouter$Unpin = 6;
var $author$project$Provider$actionContext = F2(
	function (action, snapshot) {
		var state = snapshot;
		return ($author$project$Provider$actionProtocol(action) === 2) ? A2(
			$elm$core$Maybe$withDefault,
			$author$project$Provider$nativeContext(snapshot),
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.R;
				},
				state.ac)) : $author$project$Provider$nativeContext(snapshot);
	});
var $author$project$ReceiptRouter$effectVersion = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return A2(
			$elm$core$List$member,
			value,
			_List_fromArray(
				[1, 2])) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Effect protocol');
	},
	A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int));
var $author$project$ReceiptRouter$Key = F3(
	function (_native, intent, protocol) {
		return {af: intent, eb: _native, en: protocol};
	});
var $author$project$ReceiptRouter$Intent = F5(
	function (request, generation, incarnation, operation, context) {
		return {R: context, e7: generation, au: incarnation, bc: operation, cM: request};
	});
var $author$project$ReceiptRouter$Context = F4(
	function (lifetime, epoch, output, revision) {
		return {e4: epoch, fe: lifetime, z: output, cN: revision};
	});
var $author$project$ReceiptRouter$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero native identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$ReceiptRouter$strict = F2(
	function (fields, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? body : $elm$json$Json$Decode$fail('Receipt fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$ReceiptRouter$context = A2(
	$author$project$ReceiptRouter$strict,
	_List_fromArray(
		['lifetime', 'epoch', 'output', 'revision']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$ReceiptRouter$Context,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'epoch', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'output', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$ReceiptRouter$positive)));
var $elm$json$Json$Decode$map5 = _Json_map5;
var $author$project$ReceiptRouter$operation = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'minimize':
				return $elm$json$Json$Decode$succeed(0);
			case 'restore':
				return $elm$json$Json$Decode$succeed(1);
			case 'maximize':
				return $elm$json$Json$Decode$succeed(2);
			case 'restore-geometry':
				return $elm$json$Json$Decode$succeed(3);
			case 'exit-fullscreen':
				return $elm$json$Json$Decode$succeed(4);
			case 'pin':
				return $elm$json$Json$Decode$succeed(5);
			case 'unpin':
				return $elm$json$Json$Decode$succeed(6);
			default:
				return $elm$json$Json$Decode$fail('Unsupported native menu operation');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$ReceiptRouter$intent = A2(
	$author$project$ReceiptRouter$strict,
	_List_fromArray(
		['request', 'generation', 'incarnation', 'operation', 'context']),
	A6(
		$elm$json$Json$Decode$map5,
		$author$project$ReceiptRouter$Intent,
		A2($elm$json$Json$Decode$field, 'request', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'generation', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'operation', $author$project$ReceiptRouter$operation),
		A2($elm$json$Json$Decode$field, 'context', $author$project$ReceiptRouter$context)));
var $author$project$ReceiptRouter$key = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(
			value.en,
			A2(
				$elm$core$List$member,
				value.af.bc,
				_List_fromArray(
					[2, 3, 4, 5, 6])) ? 2 : 1) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Operation protocol mismatch');
	},
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$ReceiptRouter$Key,
		A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
		A2($elm$json$Json$Decode$field, 'intent', $author$project$ReceiptRouter$intent),
		A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int)));
var $author$project$ReceiptRouter$kind = function (expected) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return _Utils_eq(value, expected) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Native message kind');
		},
		A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
};
var $author$project$ReceiptRouter$version = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (value === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Native protocol');
	},
	A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int));
var $author$project$ReceiptRouter$command = A2(
	$author$project$ReceiptRouter$strict,
	_List_fromArray(
		['protocolVersion', 'kind', 'effectProtocol', 'binding', 'intent']),
	A5(
		$elm$json$Json$Decode$map4,
		F4(
			function (_v0, _v1, _v2, value) {
				return value;
			}),
		$author$project$ReceiptRouter$version,
		$author$project$ReceiptRouter$kind('window-effect'),
		$author$project$ReceiptRouter$effectVersion,
		$author$project$ReceiptRouter$key));
var $author$project$ReceiptRouter$safeError = function (error) {
	safeError:
	while (true) {
		switch (error.$) {
			case 3:
				var reason = error.a;
				return A2($elm$core$String$left, 256, reason);
			case 0:
				var nested = error.b;
				var $temp$error = nested;
				error = $temp$error;
				continue safeError;
			case 1:
				var nested = error.b;
				var $temp$error = nested;
				error = $temp$error;
				continue safeError;
			default:
				var alternatives = error.a;
				return A2(
					$elm$core$Maybe$withDefault,
					'Invalid native frame',
					A2(
						$elm$core$Maybe$map,
						$author$project$ReceiptRouter$safeError,
						$elm$core$List$head(alternatives)));
		}
	}
};
var $author$project$ReceiptRouter$register = F4(
	function (_v0, provider, value, model) {
		var local = _v0.a;
		var binding = _v0.b;
		var action = _v0.c;
		var entries = model;
		var _v1 = A2($elm$json$Json$Decode$decodeValue, $author$project$ReceiptRouter$command, value);
		if (_v1.$ === 1) {
			var error = _v1.a;
			return $elm$core$Result$Err(
				$author$project$ReceiptRouter$safeError(error));
		} else {
			var _native = _v1.a;
			var expectedOperation = function () {
				switch (action.$) {
					case 4:
						return $elm$core$Maybe$Just(0);
					case 0:
						return $elm$core$Maybe$Just(1);
					case 5:
						return $elm$core$Maybe$Just(2);
					case 1:
						return $elm$core$Maybe$Just(3);
					case 7:
						return $elm$core$Maybe$Just(4);
					case 8:
						var desired = action.a;
						return $elm$core$Maybe$Just(
							desired ? 5 : 6);
					default:
						return $elm$core$Maybe$Nothing;
				}
			}();
			var eligible = A2(
				$elm$core$List$any,
				function (item) {
					return item.b9 && _Utils_eq(item.eV, action);
				},
				$author$project$Provider$getItems(provider));
			return ((!_Utils_eq(
				binding,
				$author$project$Provider$getBinding(provider))) || ((!eligible) || ((!_Utils_eq(
				$elm$core$Maybe$Just(_native.af.bc),
				expectedOperation)) || ((!_Utils_eq(
				_native.eb,
				$author$project$Provider$nativeBinding(provider))) || ((!_Utils_eq(
				_native.af.R,
				A2($author$project$Provider$actionContext, action, provider))) || ((!_Utils_eq(
				_native.en,
				$author$project$Provider$actionProtocol(action))) || (!_Utils_eq(
				_native.af.au,
				$author$project$Provider$incarnation(provider))))))))) ? $elm$core$Result$Err('Native command does not match frozen menu action') : (A2(
				$elm$core$List$any,
				function (entry) {
					return _Utils_eq(entry.ch, local) || (_Utils_eq(entry.aV, _native) || (_Utils_eq(entry.aV.eb, _native.eb) && _Utils_eq(entry.aV.af.cM, _native.af.cM)));
				},
				entries) ? $elm$core$Result$Err('Native/local operation already registered') : ((_Utils_cmp(
				$elm$core$List$length(entries),
				$author$project$Menu$maxOutstanding) > -1) ? $elm$core$Result$Err('Receipt registry capacity') : $elm$core$Result$Ok(
				A2(
					$elm$core$List$cons,
					{c3: binding, aV: _native, ch: local},
					entries))));
		}
	});
var $author$project$ReceiptRouter$registerPrepared = F5(
	function (_v0, original, fresh, value, model) {
		var local = _v0.a;
		var originalBinding = _v0.b;
		var action = _v0.c;
		var ordered = $elm$core$List$sortWith(
			F2(
				function (a, b) {
					return A2($author$project$UInt64$compare, a.au, b.au);
				}));
		var old = $author$project$Provider$nativeContext(original);
		var _new = $author$project$Provider$nativeContext(fresh);
		var geometrySame = function () {
			var _v2 = _Utils_Tuple2(
				$author$project$Provider$geometryObservation(original),
				$author$project$Provider$geometryObservation(fresh));
			_v2$2:
			while (true) {
				if (_v2.a.$ === 1) {
					if (_v2.b.$ === 1) {
						var _v3 = _v2.a;
						var _v4 = _v2.b;
						return true;
					} else {
						break _v2$2;
					}
				} else {
					if (!_v2.b.$) {
						var before = _v2.a.a;
						var after = _v2.b.a;
						return _Utils_eq(
							ordered(before.a),
							ordered(after.a)) && ((!after.eZ) && (_Utils_eq(before.R.z, after.R.z) && (_Utils_eq(before.c3, after.c3) && ((!(!A2($author$project$UInt64$compare, after.R.cN, before.R.cN))) && (!(!A2($author$project$UInt64$compare, after.eC, before.eC)))))));
					} else {
						break _v2$2;
					}
				}
			}
			return false;
		}();
		return ((!_Utils_eq(
			originalBinding,
			$author$project$Provider$getBinding(original))) || ((!_Utils_eq(
			$author$project$Provider$nativeBinding(original),
			$author$project$Provider$nativeBinding(fresh))) || ((!_Utils_eq(
			$author$project$Provider$incarnation(original),
			$author$project$Provider$incarnation(fresh))) || ((!_Utils_eq(
			$author$project$Provider$presentationScope(original),
			$author$project$Provider$presentationScope(fresh))) || ((!_Utils_eq(old.fe, _new.fe)) || ((!_Utils_eq(old.e4, _new.e4)) || ((!_Utils_eq(old.z, _new.z)) || ((!A2($author$project$UInt64$compare, _new.cN, old.cN)) || ((!geometrySame) || (!_Utils_eq(
			$author$project$Provider$getItems(original),
			$author$project$Provider$getItems(fresh)))))))))))) ? $elm$core$Result$Err('Prepared action authority changed') : A2(
			$elm$core$Result$map,
			function (_v1) {
				var entries = _v1;
				return A2(
					$elm$core$List$map,
					function (entry) {
						return _Utils_eq(entry.ch, local) ? _Utils_update(
							entry,
							{c3: originalBinding}) : entry;
					},
					entries);
			},
			A4(
				$author$project$ReceiptRouter$register,
				A3(
					$author$project$Menu$Dispatch,
					local,
					$author$project$Provider$getBinding(fresh),
					action),
				fresh,
				value,
				model));
	});
var $author$project$Shell$RestartBackend = {$: 1};
var $author$project$ActionProjection$actionable = F2(
	function (identity, projection) {
		return A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.c2;
				},
				A2(
					$author$project$ActionProjection$find,
					identity,
					$author$project$ActionProjection$windows(projection))));
	});
var $author$project$Effects$Context = F4(
	function (lifetime, epoch, output, revision) {
		return {e4: epoch, fe: lifetime, z: output, cN: revision};
	});
var $author$project$Effects$identity = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$Effects$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Unexpected/missing field');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Effects$contextDecoder = A2(
	$author$project$Effects$strict,
	_List_fromArray(
		['lifetime', 'epoch', 'output', 'revision']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$Effects$Context,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Effects$identity),
		A2($elm$json$Json$Decode$field, 'epoch', $author$project$Effects$identity),
		A2($elm$json$Json$Decode$field, 'output', $author$project$Effects$identity),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$Effects$identity)));
var $author$project$ActionProjection$Admitted = F4(
	function (a, b, c, d) {
		return {$: 0, a: a, b: b, c: c, d: d};
	});
var $author$project$ActionProjection$Window = F7(
	function (incarnation, label, minimized, owner, application, available, attention) {
		return {c0: application, dF: attention, c2: available, au: incarnation, d6: label, bR: minimized, dm: owner};
	});
var $author$project$ActionProjection$nonzero = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return _Utils_eq(v, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero identity') : $elm$json$Json$Decode$succeed(v);
	},
	$author$project$UInt64$decoder);
var $author$project$ActionProjection$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Unexpected projection fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$ActionProjection$windowDecoder = $elm$json$Json$Decode$oneOf(
	_List_fromArray(
		[
			A2(
			$author$project$ActionProjection$strict,
			_List_fromArray(
				['incarnation', 'label', 'minimized', 'owner', 'application', 'available', 'attention']),
			A8(
				$elm$json$Json$Decode$map7,
				$author$project$ActionProjection$Window,
				A2($elm$json$Json$Decode$field, 'incarnation', $author$project$ActionProjection$nonzero),
				A2($elm$json$Json$Decode$field, 'label', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'minimized', $elm$json$Json$Decode$bool),
				A2(
					$elm$json$Json$Decode$field,
					'owner',
					$elm$json$Json$Decode$nullable($author$project$ActionProjection$nonzero)),
				A2($elm$json$Json$Decode$field, 'application', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'available', $elm$json$Json$Decode$bool),
				A2($elm$json$Json$Decode$field, 'attention', $elm$json$Json$Decode$bool))),
			A2(
			$author$project$ActionProjection$strict,
			_List_fromArray(
				['incarnation', 'label', 'minimized', 'owner', 'application', 'available']),
			A8(
				$elm$json$Json$Decode$map7,
				$author$project$ActionProjection$Window,
				A2($elm$json$Json$Decode$field, 'incarnation', $author$project$ActionProjection$nonzero),
				A2($elm$json$Json$Decode$field, 'label', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'minimized', $elm$json$Json$Decode$bool),
				A2(
					$elm$json$Json$Decode$field,
					'owner',
					$elm$json$Json$Decode$nullable($author$project$ActionProjection$nonzero)),
				A2($elm$json$Json$Decode$field, 'application', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'available', $elm$json$Json$Decode$bool),
				$elm$json$Json$Decode$succeed(false)))
		]));
var $author$project$ActionProjection$bounded = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$index, 256, $elm$json$Json$Decode$value),
			v);
		if (!_v0.$) {
			return $elm$json$Json$Decode$fail('Window bound');
		} else {
			return $elm$json$Json$Decode$list($author$project$ActionProjection$windowDecoder);
		}
	},
	$elm$json$Json$Decode$value);
var $author$project$ActionProjection$rootIn = F3(
	function (fuel, identity, rows) {
		return (fuel <= 0) ? $elm$core$Maybe$Nothing : A2(
			$elm$core$Maybe$andThen,
			function (w) {
				var _v0 = w.dm;
				if (_v0.$ === 1) {
					return $elm$core$Maybe$Just(w.au);
				} else {
					var parent = _v0.a;
					return A3($author$project$ActionProjection$rootIn, fuel - 1, parent, rows);
				}
			},
			A2(
				$elm$core$Dict$get,
				$author$project$UInt64$string(identity),
				rows));
	});
var $author$project$ActionProjection$validText = function (value) {
	return ($elm$core$String$length(value) <= 256) && (!A2(
		$elm$core$String$any,
		function (c) {
			return $elm$core$Char$toCode(c) < 32;
		},
		value));
};
var $author$project$ActionProjection$decode = function (value) {
	return A2(
		$elm$core$Result$andThen,
		function (projection) {
			var revision_ = projection.a;
			var focus = projection.b;
			var rows = projection.c;
			var validFocus = A2(
				$elm$core$Maybe$withDefault,
				true,
				A2(
					$elm$core$Maybe$map,
					function (identity) {
						return A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (w) {
									return !w.bR;
								},
								A2($author$project$ActionProjection$find, identity, rows)));
					},
					focus));
			var unique = A3(
				$elm$core$List$foldl,
				F2(
					function (w, seen) {
						return A2($elm$core$List$member, w.au, seen) ? seen : A2($elm$core$List$cons, w.au, seen);
					}),
				_List_Nil,
				rows);
			var table = $elm$core$Dict$fromList(
				A2(
					$elm$core$List$map,
					function (w) {
						return _Utils_Tuple2(
							$author$project$UInt64$string(w.au),
							w);
					},
					rows));
			var roots = A3(
				$elm$core$List$foldl,
				F2(
					function (w, accumulated) {
						return A3(
							$elm$core$Maybe$map2,
							F2(
								function (cache, root) {
									return A3(
										$elm$core$Dict$insert,
										$author$project$UInt64$string(w.au),
										root,
										cache);
								}),
							accumulated,
							A3($author$project$ActionProjection$rootIn, 256, w.au, table));
					}),
				$elm$core$Maybe$Just($elm$core$Dict$empty),
				rows);
			var validFamily = function (w) {
				return A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (root) {
							return _Utils_eq(root.bR, w.bR);
						},
						A2(
							$elm$core$Maybe$andThen,
							function (root) {
								return A2(
									$elm$core$Dict$get,
									$author$project$UInt64$string(root),
									table);
							},
							A2(
								$elm$core$Maybe$andThen,
								$elm$core$Dict$get(
									$author$project$UInt64$string(w.au)),
								roots))));
			};
			if ((!_Utils_eq(
				$elm$core$List$length(unique),
				$elm$core$List$length(rows))) || ((!validFocus) || A2(
				$elm$core$List$any,
				function (w) {
					return !($author$project$ActionProjection$validText(w.d6) && ($author$project$ActionProjection$validText(w.c0) && validFamily(w)));
				},
				rows))) {
				return $elm$core$Result$Err('Incoherent ownership/focus projection');
			} else {
				if (!roots.$) {
					var cache = roots.a;
					return $elm$core$Result$Ok(
						A4($author$project$ActionProjection$Admitted, revision_, focus, rows, cache));
				} else {
					return $elm$core$Result$Err('Invalid ownership graph');
				}
			}
		},
		A2(
			$elm$core$Result$mapError,
			$elm$json$Json$Decode$errorToString,
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2(
					$author$project$ActionProjection$strict,
					_List_fromArray(
						['revision', 'focused', 'windows']),
					A4(
						$elm$json$Json$Decode$map3,
						F3(
							function (revision_, focus_, rows_) {
								return A4($author$project$ActionProjection$Admitted, revision_, focus_, rows_, $elm$core$Dict$empty);
							}),
						A2($elm$json$Json$Decode$field, 'revision', $author$project$ActionProjection$nonzero),
						A2(
							$elm$json$Json$Decode$field,
							'focused',
							$elm$json$Json$Decode$nullable($author$project$ActionProjection$nonzero)),
						A2($elm$json$Json$Decode$field, 'windows', $author$project$ActionProjection$bounded))),
				value)));
};
var $author$project$Effects$counter = A2($elm$core$Basics$composeR, $author$project$UInt64$string, $elm$json$Json$Encode$string);
var $author$project$Transfer$encode = function (p) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'source',
				$elm$json$Json$Encode$string(p.cm)),
				_Utils_Tuple2(
				'sourceGeneration',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(p.cV))),
				_Utils_Tuple2(
				'destination',
				$elm$json$Json$Encode$string(p.bp))
			]));
};
var $author$project$Effects$encodeContext = function (context) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'lifetime',
				$author$project$Effects$counter(context.fe)),
				_Utils_Tuple2(
				'epoch',
				$author$project$Effects$counter(context.e4)),
				_Utils_Tuple2(
				'output',
				$author$project$Effects$counter(context.z)),
				_Utils_Tuple2(
				'revision',
				$author$project$Effects$counter(context.cN))
			]));
};
var $elm$json$Json$Encode$float = _Json_wrap;
var $author$project$Snap$encodeProposal = function (proposed) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'region',
				$elm$json$Json$Encode$string(
					$author$project$Snap$identity(proposed.b_))),
				_Utils_Tuple2(
				'geometry',
				A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$float, proposed.ac)),
				_Utils_Tuple2(
				'monitor',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(proposed.bS))),
				_Utils_Tuple2(
				'outputOwnershipGeneration',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(proposed.bd))),
				_Utils_Tuple2(
				'workAreaRevision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(proposed.ct))),
				_Utils_Tuple2(
				'workspaceGeneration',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(proposed.b5)))
			]));
};
var $author$project$Effects$operationName = function (operation) {
	switch (operation.$) {
		case 0:
			return 'minimize';
		case 1:
			return 'restore';
		case 2:
			return 'activate';
		case 3:
			return 'maximize';
		case 4:
			return 'restore-geometry';
		case 5:
			return 'exit-fullscreen';
		case 8:
			return 'pin';
		case 9:
			return 'unpin';
		case 6:
			return 'snap';
		default:
			return 'transfer-workspace';
	}
};
var $author$project$Effects$encodeIntent = function (intent) {
	return $elm$json$Json$Encode$object(
		_Utils_ap(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'request',
					$author$project$Effects$counter(intent.cM)),
					_Utils_Tuple2(
					'generation',
					$author$project$Effects$counter(intent.e7)),
					_Utils_Tuple2(
					'incarnation',
					$author$project$Effects$counter(intent.au)),
					_Utils_Tuple2(
					'operation',
					$elm$json$Json$Encode$string(
						$author$project$Effects$operationName(intent.bc))),
					_Utils_Tuple2(
					'context',
					$author$project$Effects$encodeContext(intent.R))
				]),
			function () {
				var _v0 = intent.bc;
				switch (_v0.$) {
					case 6:
						var proposed = _v0.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'placement',
								$author$project$Snap$encodeProposal(proposed))
							]);
					case 7:
						var proposed = _v0.a;
						return _List_fromArray(
							[
								_Utils_Tuple2(
								'transfer',
								$author$project$Transfer$encode(proposed))
							]);
					default:
						return _List_Nil;
				}
			}()));
};
var $author$project$Effects$Intent = F5(
	function (request, generation, incarnation, operation, context) {
		return {R: context, e7: generation, au: incarnation, bc: operation, cM: request};
	});
var $author$project$Effects$SnapPlacement = function (a) {
	return {$: 6, a: a};
};
var $author$project$Effects$TransferWorkspace = function (a) {
	return {$: 7, a: a};
};
var $author$project$Transfer$Proposal = F3(
	function (source, sourceGeneration, destination) {
		return {bp: destination, cm: source, cV: sourceGeneration};
	});
var $author$project$Transfer$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (pairs) {
		return (!_Utils_eq(
			$elm$core$List$sort(
				A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
			_List_fromArray(
				['destination', 'source', 'sourceGeneration']))) ? $elm$json$Json$Decode$fail('Transfer fields') : A2(
			$elm$json$Json$Decode$andThen,
			function (p) {
				return ($author$project$Transfer$ordinary(p.cm) && ($author$project$Transfer$ordinary(p.bp) && ((!_Utils_eq(p.cm, p.bp)) && (!_Utils_eq(p.cV, $author$project$UInt64$zero))))) ? $elm$json$Json$Decode$succeed(p) : $elm$json$Json$Decode$fail('Transfer workspace identity');
			},
			A4(
				$elm$json$Json$Decode$map3,
				$author$project$Transfer$Proposal,
				A2($elm$json$Json$Decode$field, 'source', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'sourceGeneration', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'destination', $elm$json$Json$Decode$string)));
	},
	$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
var $author$project$Effects$operationDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (name) {
		switch (name) {
			case 'minimize':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Minimize);
			case 'restore':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Restore);
			case 'activate':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Activate);
			case 'maximize':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Maximize);
			case 'restore-geometry':
				return $elm$json$Json$Decode$succeed($author$project$Effects$RestoreGeometry);
			case 'exit-fullscreen':
				return $elm$json$Json$Decode$succeed($author$project$Effects$ExitFullscreen);
			case 'pin':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Pin);
			case 'unpin':
				return $elm$json$Json$Decode$succeed($author$project$Effects$Unpin);
			default:
				return $elm$json$Json$Decode$fail('Unsupported operation');
		}
	},
	$elm$json$Json$Decode$string);
var $elm$core$Basics$abs = function (n) {
	return (n < 0) ? (-n) : n;
};
var $elm$json$Json$Decode$float = _Json_decodeFloat;
var $elm$core$Basics$isInfinite = _Basics_isInfinite;
var $elm$core$Basics$isNaN = _Basics_isNaN;
var $author$project$Snap$proposalDecoder = function (context) {
	var regionDecoder = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			var _v4 = $elm$core$List$head(
				A2(
					$elm$core$List$filter,
					A2(
						$elm$core$Basics$composeR,
						$author$project$Snap$identity,
						$elm$core$Basics$eq(value)),
					$author$project$Snap$regions));
			if (!_v4.$) {
				var regionValue = _v4.a;
				return $elm$json$Json$Decode$succeed(regionValue);
			} else {
				return $elm$json$Json$Decode$fail('Unsupported snap region');
			}
		},
		$elm$json$Json$Decode$string);
	var rectangle = A2(
		$elm$json$Json$Decode$andThen,
		function (values) {
			if ((((values.b && values.b.b) && values.b.b.b) && values.b.b.b.b) && (!values.b.b.b.b.b)) {
				var x = values.a;
				var _v1 = values.b;
				var y = _v1.a;
				var _v2 = _v1.b;
				var w = _v2.a;
				var _v3 = _v2.b;
				var h = _v3.a;
				return (A2(
					$elm$core$List$all,
					function (n) {
						return (!($elm$core$Basics$isNaN(n) || $elm$core$Basics$isInfinite(n))) && ($elm$core$Basics$abs(n) <= 2147483647);
					},
					values) && ((w > 0) && (h > 0))) ? $elm$json$Json$Decode$succeed(values) : $elm$json$Json$Decode$fail('Invalid snap rectangle');
			} else {
				return $elm$json$Json$Decode$fail('Invalid snap rectangle shape');
			}
		},
		$elm$json$Json$Decode$list($elm$json$Json$Decode$float));
	var positive = A2(
		$elm$json$Json$Decode$andThen,
		function (n) {
			return _Utils_eq(n, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero placement generation') : $elm$json$Json$Decode$succeed(n);
		},
		$author$project$UInt64$decoder);
	var fields = _List_fromArray(
		['region', 'geometry', 'monitor', 'outputOwnershipGeneration', 'workAreaRevision', 'workspaceGeneration']);
	return A2(
		$elm$json$Json$Decode$andThen,
		function (pairs) {
			return (!_Utils_eq(
				$elm$core$List$sort(
					A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
				$elm$core$List$sort(fields))) ? $elm$json$Json$Decode$fail('Snap placement fields') : A7(
				$elm$json$Json$Decode$map6,
				F6(
					function (regionName, geometry, monitor, output, area, workspace) {
						return {R: context, ac: geometry, bS: monitor, bd: output, b_: regionName, ct: area, b5: workspace};
					}),
				A2($elm$json$Json$Decode$field, 'region', regionDecoder),
				A2($elm$json$Json$Decode$field, 'geometry', rectangle),
				A2($elm$json$Json$Decode$field, 'monitor', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'outputOwnershipGeneration', positive),
				A2($elm$json$Json$Decode$field, 'workAreaRevision', positive),
				A2($elm$json$Json$Decode$field, 'workspaceGeneration', positive));
		},
		$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
};
var $author$project$Effects$intentDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (name) {
		return (name === 'snap') ? A2(
			$author$project$Effects$strict,
			_List_fromArray(
				['request', 'generation', 'incarnation', 'operation', 'context', 'placement']),
			A2(
				$elm$json$Json$Decode$andThen,
				function (context) {
					return A6(
						$elm$json$Json$Decode$map5,
						$author$project$Effects$Intent,
						A2($elm$json$Json$Decode$field, 'request', $author$project$Effects$identity),
						A2($elm$json$Json$Decode$field, 'generation', $author$project$Effects$identity),
						A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Effects$identity),
						A2(
							$elm$json$Json$Decode$map,
							$author$project$Effects$SnapPlacement,
							A2(
								$elm$json$Json$Decode$field,
								'placement',
								$author$project$Snap$proposalDecoder(context))),
						$elm$json$Json$Decode$succeed(context));
				},
				A2($elm$json$Json$Decode$field, 'context', $author$project$Effects$contextDecoder))) : ((name === 'transfer-workspace') ? A2(
			$author$project$Effects$strict,
			_List_fromArray(
				['request', 'generation', 'incarnation', 'operation', 'context', 'transfer']),
			A6(
				$elm$json$Json$Decode$map5,
				$author$project$Effects$Intent,
				A2($elm$json$Json$Decode$field, 'request', $author$project$Effects$identity),
				A2($elm$json$Json$Decode$field, 'generation', $author$project$Effects$identity),
				A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Effects$identity),
				A2(
					$elm$json$Json$Decode$map,
					$author$project$Effects$TransferWorkspace,
					A2($elm$json$Json$Decode$field, 'transfer', $author$project$Transfer$decoder)),
				A2($elm$json$Json$Decode$field, 'context', $author$project$Effects$contextDecoder))) : A2(
			$author$project$Effects$strict,
			_List_fromArray(
				['request', 'generation', 'incarnation', 'operation', 'context']),
			A6(
				$elm$json$Json$Decode$map5,
				$author$project$Effects$Intent,
				A2($elm$json$Json$Decode$field, 'request', $author$project$Effects$identity),
				A2($elm$json$Json$Decode$field, 'generation', $author$project$Effects$identity),
				A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Effects$identity),
				A2($elm$json$Json$Decode$field, 'operation', $author$project$Effects$operationDecoder),
				A2($elm$json$Json$Decode$field, 'context', $author$project$Effects$contextDecoder))));
	},
	A2($elm$json$Json$Decode$field, 'operation', $elm$json$Json$Decode$string));
var $author$project$Effects$protocol = function (operation) {
	switch (operation.$) {
		case 3:
			return 2;
		case 4:
			return 2;
		case 5:
			return 2;
		case 8:
			return 2;
		case 9:
			return 2;
		case 6:
			return 2;
		case 7:
			return 2;
		default:
			return 1;
	}
};
var $author$project$ActionProjection$revision = function (_v0) {
	var value = _v0.a;
	return value;
};
var $author$project$Effects$sameAuthority = F2(
	function (a, b) {
		return _Utils_eq(a.fe, b.fe) && (_Utils_eq(a.e4, b.e4) && _Utils_eq(a.z, b.z));
	});
var $author$project$ActionProjection$sameState = F2(
	function (left, right) {
		var state = function (projection) {
			return A2(
				$elm$core$List$map,
				function (w) {
					return _Utils_Tuple3(
						w.au,
						_Utils_Tuple2(w.bR, w.dm),
						_Utils_Tuple2(
							w.c0,
							_Utils_Tuple2(w.c2, w.dF)));
				},
				A2(
					$elm$core$List$sortWith,
					F2(
						function (a, b) {
							return A2($author$project$UInt64$compare, a.au, b.au);
						}),
					$author$project$ActionProjection$windows(projection)));
		};
		return _Utils_eq(
			$author$project$ActionProjection$focused(left),
			$author$project$ActionProjection$focused(right)) && _Utils_eq(
			state(left),
			state(right));
	});
var $author$project$Effects$Committed = 1;
var $author$project$Effects$statusDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (name) {
		switch (name) {
			case 'Committed':
				return $elm$json$Json$Decode$succeed(1);
			case 'Refused':
				return $elm$json$Json$Decode$succeed(2);
			case 'Cancelled':
				return $elm$json$Json$Decode$succeed(3);
			case 'Unknown':
				return $elm$json$Json$Decode$succeed(4);
			default:
				return $elm$json$Json$Decode$fail('Not an authoritative terminal outcome');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Effects$unknown = $elm$core$Maybe$map(
	function (transaction) {
		return (!transaction.O) ? _Utils_update(
			transaction,
			{O: 4}) : transaction;
	});
var $author$project$Effects$apply = F2(
	function (value, model) {
		var refuse = function (reason) {
			return _Utils_Tuple3(
				model,
				$elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just(reason));
		};
		var decoded = F2(
			function (decoder, action) {
				var _v11 = A2($elm$json$Json$Decode$decodeValue, decoder, value);
				if (_v11.$ === 1) {
					var error = _v11.a;
					return refuse(
						$elm$json$Json$Decode$errorToString(error));
				} else {
					var result = _v11.a;
					return action(result);
				}
			});
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			value);
		if (_v0.$ === 1) {
			var error = _v0.a;
			return refuse(
				$elm$json$Json$Decode$errorToString(error));
		} else {
			switch (_v0.a) {
				case 'snapshot':
					return A2(
						decoded,
						A2(
							$author$project$Effects$strict,
							_List_fromArray(
								['kind', 'context', 'scene']),
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'context', $author$project$Effects$contextDecoder),
								A2($elm$json$Json$Decode$field, 'scene', $elm$json$Json$Decode$value))),
						function (_v1) {
							var context = _v1.a;
							var sceneValue = _v1.b;
							var _v2 = $author$project$ActionProjection$decode(sceneValue);
							if (_v2.$ === 1) {
								var error = _v2.a;
								return refuse(error);
							} else {
								var scene = _v2.a;
								if (!_Utils_eq(
									$author$project$ActionProjection$revision(scene),
									context.cN)) {
									return refuse('Scene/context revision mismatch');
								} else {
									var _v3 = model.av;
									if (!_v3.$) {
										var old = _v3.a;
										return (A2($author$project$Effects$sameAuthority, old.R, context) && ((!A2($author$project$UInt64$compare, context.cN, old.R.cN)) || (_Utils_eq(context.cN, old.R.cN) && (!A2($author$project$ActionProjection$sameState, old.eA, scene))))) ? refuse('Nonincreasing snapshot') : _Utils_Tuple3(
											_Utils_update(
												model,
												{
													a6: true,
													av: $elm$core$Maybe$Just(
														{R: context, eA: scene}),
													dz: A2($author$project$Effects$sameAuthority, old.R, context) ? model.dz : $author$project$Effects$unknown(model.dz)
												}),
											$elm$core$Maybe$Nothing,
											$elm$core$Maybe$Nothing);
									} else {
										return _Utils_Tuple3(
											_Utils_update(
												model,
												{
													a6: true,
													av: $elm$core$Maybe$Just(
														{R: context, eA: scene})
												}),
											$elm$core$Maybe$Nothing,
											$elm$core$Maybe$Nothing);
									}
								}
							}
						});
				case 'begin':
					return A2(
						decoded,
						A2(
							$author$project$Effects$strict,
							_List_fromArray(
								['kind', 'operation', 'incarnation']),
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'operation', $author$project$Effects$operationDecoder),
								A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Effects$identity))),
						function (_v4) {
							var operation = _v4.a;
							var incarnation = _v4.b;
							var _v5 = _Utils_Tuple3(
								model.av,
								$author$project$UInt64$next(model.cM),
								$author$project$UInt64$next(model.e7));
							if (((!_v5.a.$) && (!_v5.b.$)) && (!_v5.c.$)) {
								var observed = _v5.a.a;
								var request = _v5.b.a;
								var generation = _v5.c.a;
								if (!model.a6) {
									return refuse('Disconnected');
								} else {
									if ($author$project$Effects$pending(model)) {
										return refuse('Operation already pending');
									} else {
										if ($elm$core$List$length(model.fM) >= 64) {
											return refuse('Unresolved operation capacity');
										} else {
											if ($author$project$Effects$protocol(operation) === 2) {
												return refuse('Geometry observation required');
											} else {
												if (A3($author$project$Effects$blocked, observed.R.fe, incarnation, model)) {
													return refuse('Unresolved native operation');
												} else {
													if (!A2($author$project$ActionProjection$actionable, incarnation, observed.eA)) {
														return refuse('Locked or unmapped target');
													} else {
														var _v6 = A2($author$project$ActionProjection$minimized, incarnation, observed.eA);
														if (_v6.$ === 1) {
															return refuse('Unknown incarnation');
														} else {
															var minimized = _v6.a;
															if ((_Utils_eq(operation, $author$project$Effects$Minimize) && minimized) || ((_Utils_eq(operation, $author$project$Effects$Restore) && (!minimized)) || (_Utils_eq(operation, $author$project$Effects$Activate) && minimized))) {
																return refuse('Already in requested native state');
															} else {
																var intent = {R: observed.R, e7: generation, au: incarnation, bc: operation, cM: request};
																return _Utils_Tuple3(
																	_Utils_update(
																		model,
																		{
																			e7: generation,
																			cM: request,
																			dz: $elm$core$Maybe$Just(
																				{az: 1, af: intent, O: 0}),
																			fM: A2(
																				$elm$core$List$cons,
																				{az: 1, af: intent, O: 0},
																				model.fM)
																		}),
																	$elm$core$Maybe$Just(
																		$elm$json$Json$Encode$object(
																			_List_fromArray(
																				[
																					_Utils_Tuple2(
																					'kind',
																					$elm$json$Json$Encode$string('window-effect')),
																					_Utils_Tuple2(
																					'protocol',
																					$elm$json$Json$Encode$int(1)),
																					_Utils_Tuple2(
																					'intent',
																					$author$project$Effects$encodeIntent(intent))
																				]))),
																	$elm$core$Maybe$Nothing);
															}
														}
													}
												}
											}
										}
									}
								}
							} else {
								return refuse('Disconnected or exhausted identity');
							}
						});
				case 'receipt':
					var receiptDecoder = $elm$json$Json$Decode$oneOf(
						_List_fromArray(
							[
								A2(
								$author$project$Effects$strict,
								_List_fromArray(
									['kind', 'intent', 'status']),
								A3(
									$elm$json$Json$Decode$map2,
									F2(
										function (intent, status) {
											return _Utils_Tuple3(1, intent, status);
										}),
									A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
									A2($elm$json$Json$Decode$field, 'status', $author$project$Effects$statusDecoder))),
								A2(
								$author$project$Effects$strict,
								_List_fromArray(
									['kind', 'intent', 'status', 'effectProtocol']),
								A4(
									$elm$json$Json$Decode$map3,
									F3(
										function (protocolId, intent, status) {
											return _Utils_Tuple3(protocolId, intent, status);
										}),
									A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int),
									A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
									A2($elm$json$Json$Decode$field, 'status', $author$project$Effects$statusDecoder)))
							]));
					return A2(
						decoded,
						receiptDecoder,
						function (_v7) {
							var protocolId = _v7.a;
							var intent = _v7.b;
							var status = _v7.c;
							var exact = function (t) {
								return _Utils_eq(t.az, protocolId) && _Utils_eq(t.af, intent);
							};
							var found = A2($elm$core$List$any, exact, model.fM);
							var settled = function (t) {
								return exact(t) ? _Utils_update(
									t,
									{O: status}) : t;
							};
							var unresolved = (status === 4) ? A2($elm$core$List$map, settled, model.fM) : A2(
								$elm$core$List$filter,
								A2($elm$core$Basics$composeR, exact, $elm$core$Basics$not),
								model.fM);
							return ((!found) || ((!A2(
								$elm$core$List$member,
								protocolId,
								_List_fromArray(
									[1, 2]))) || (!_Utils_eq(
								$author$project$Effects$protocol(intent.bc),
								protocolId)))) ? refuse('Stale, mismatched or terminal receipt') : _Utils_Tuple3(
								_Utils_update(
									model,
									{
										dz: A2($elm$core$Maybe$map, settled, model.dz),
										fM: unresolved
									}),
								$elm$core$Maybe$Nothing,
								$elm$core$Maybe$Nothing);
						});
				case 'recover-watermarks':
					return A2(
						decoded,
						A2(
							$author$project$Effects$strict,
							_List_fromArray(
								['kind', 'request', 'generation']),
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'request', $author$project$UInt64$decoder),
								A2($elm$json$Json$Decode$field, 'generation', $author$project$UInt64$decoder))),
						function (_v8) {
							var request = _v8.a;
							var generation = _v8.b;
							var maximum = F2(
								function (old, _new) {
									return (!A2($author$project$UInt64$compare, old, _new)) ? _new : old;
								});
							return _Utils_Tuple3(
								_Utils_update(
									model,
									{
										e7: A2(maximum, model.e7, generation),
										cM: A2(maximum, model.cM, request)
									}),
								$elm$core$Maybe$Nothing,
								$elm$core$Maybe$Nothing);
						});
				case 'recover':
					return A2(
						decoded,
						A2(
							$author$project$Effects$strict,
							_List_fromArray(
								['kind', 'intent', 'effectProtocol']),
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
								A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int))),
						function (_v9) {
							var intent = _v9.a;
							var protocolId = _v9.b;
							if ((!A2(
								$elm$core$List$member,
								protocolId,
								_List_fromArray(
									[1, 2]))) || (!_Utils_eq(
								$author$project$Effects$protocol(intent.bc),
								protocolId))) {
								return refuse('Recovery operation protocol');
							} else {
								if (A2(
									$elm$core$List$any,
									function (t) {
										return _Utils_eq(t.af, intent) && _Utils_eq(t.az, protocolId);
									},
									model.fM)) {
									return _Utils_Tuple3(model, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing);
								} else {
									if ($elm$core$List$length(model.fM) >= 64) {
										return refuse('Unresolved operation capacity');
									} else {
										var transaction = {az: protocolId, af: intent, O: 4};
										var maximum = F2(
											function (old, _new) {
												return (!A2($author$project$UInt64$compare, old, _new)) ? _new : old;
											});
										return _Utils_Tuple3(
											_Utils_update(
												model,
												{
													e7: A2(maximum, model.e7, intent.e7),
													cM: A2(maximum, model.cM, intent.cM),
													dz: $elm$core$Maybe$Just(transaction),
													fM: A2($elm$core$List$cons, transaction, model.fM)
												}),
											$elm$core$Maybe$Nothing,
											$elm$core$Maybe$Nothing);
									}
								}
							}
						});
				case 'disconnect':
					return A2(
						decoded,
						A2(
							$author$project$Effects$strict,
							_List_fromArray(
								['kind']),
							$elm$json$Json$Decode$succeed(0)),
						function (_v10) {
							return _Utils_Tuple3(
								_Utils_update(
									model,
									{
										a6: false,
										dz: $author$project$Effects$unknown(model.dz),
										fM: A2(
											$elm$core$List$map,
											function (t) {
												return (!t.O) ? _Utils_update(
													t,
													{O: 4}) : t;
											},
											model.fM)
									}),
								$elm$core$Maybe$Nothing,
								$elm$core$Maybe$Nothing);
						});
				default:
					return refuse('Unsupported message');
			}
		}
	});
var $elm$json$Json$Decode$at = F2(
	function (fields, decoder) {
		return A3($elm$core$List$foldr, $elm$json$Json$Decode$field, decoder, fields);
	});
var $author$project$Effects$geometryCapability = function (operation) {
	switch (operation.$) {
		case 3:
			return $elm$core$Maybe$Just(0);
		case 4:
			return $elm$core$Maybe$Just(1);
		case 6:
			return $elm$core$Maybe$Just(2);
		case 7:
			return $elm$core$Maybe$Just(3);
		case 8:
			return $elm$core$Maybe$Just(4);
		case 9:
			return $elm$core$Maybe$Just(5);
		case 5:
			return $elm$core$Maybe$Just(6);
		case 0:
			return $elm$core$Maybe$Nothing;
		case 1:
			return $elm$core$Maybe$Nothing;
		default:
			return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Snap$matches = F3(
	function (snapshot, target, proposed) {
		return (!A2($elm$core$List$member, proposed.b_, $author$project$Snap$regions)) ? false : A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (choice) {
					return _Utils_eq(
						$author$project$Snap$proposal(
							_Utils_update(
								choice,
								{bG: proposed.b_})),
						$elm$core$Maybe$Just(proposed));
				},
				A2($author$project$Snap$open, snapshot, target)));
	});
var $author$project$Transfer$matches = F3(
	function (snapshot, root, p) {
		return _Utils_eq(
			A3($author$project$Transfer$propose, snapshot, root, p.bp),
			$elm$core$Maybe$Just(p));
	});
var $author$project$Effects$beginGeometry = F5(
	function (caps, observed, operation, incarnation, model) {
		var refuse = function (reason) {
			return _Utils_Tuple3(
				model,
				$elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just(reason));
		};
		var legacyReady = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (legacy) {
					return A2($author$project$ActionProjection$actionable, incarnation, legacy.eA) && _Utils_eq(
						A2($author$project$ActionProjection$rootOf, incarnation, legacy.eA),
						$elm$core$Maybe$Just(incarnation));
				},
				model.av));
		var _v0 = _Utils_Tuple3(
			A2($author$project$GeometryProjection$window, incarnation, observed),
			$author$project$UInt64$next(model.cM),
			$author$project$UInt64$next(model.e7));
		if (((!_v0.a.$) && (!_v0.b.$)) && (!_v0.c.$)) {
			var window = _v0.a.a;
			var request = _v0.b.a;
			var generation = _v0.c.a;
			if ((!model.a6) || ((!legacyReady) || ($author$project$Effects$pending(model) || A3($author$project$Effects$blocked, observed.R.fe, incarnation, model)))) {
				return refuse('Unresolved or disconnected native operation');
			} else {
				if ($elm$core$List$length(model.fM) >= 64) {
					return refuse('Unresolved operation capacity');
				} else {
					if (($author$project$Effects$protocol(operation) !== 2) || ((!caps.V) || (!A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (capability) {
								return A2($elm$core$List$member, capability, caps.ef);
							},
							$author$project$Effects$geometryCapability(operation)))))) {
						return refuse('Geometry operation not negotiated');
					} else {
						if (observed.eZ || function () {
							switch (operation.$) {
								case 8:
									return !A2(
										$elm$core$Maybe$withDefault,
										false,
										A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.da;
											},
											window.dp));
								case 9:
									return !A2(
										$elm$core$Maybe$withDefault,
										false,
										A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.da;
											},
											window.dp));
								case 5:
									return !$author$project$GeometryProjection$canExitFullscreen(window);
								case 7:
									var p = operation.a;
									return !A3($author$project$Transfer$matches, observed, incarnation, p);
								default:
									return (!window.da) || (window.bR || window.e6);
							}
						}()) {
							return refuse('Geometry target ineligible');
						} else {
							if ((_Utils_eq(operation, $author$project$Effects$Pin) || _Utils_eq(operation, $author$project$Effects$Unpin)) && A2(
								$elm$core$Maybe$withDefault,
								true,
								A2(
									$elm$core$Maybe$map,
									function (pin) {
										return _Utils_eq(
											pin.fr,
											_Utils_eq(operation, $author$project$Effects$Pin));
									},
									window.dp))) {
								return refuse('Pin state already requested or unavailable');
							} else {
								if ((_Utils_eq(operation, $author$project$Effects$Maximize) && ((!window.fg) || (!(!window.ec)))) || (_Utils_eq(operation, $author$project$Effects$RestoreGeometry) && ((!window.fA) || ((window.ec !== 1) || (!window.fs))))) {
									return refuse('Geometry state/capability unavailable');
								} else {
									if (function () {
										if (operation.$ === 6) {
											var proposed = operation.a;
											return !A3($author$project$Snap$matches, observed, incarnation, proposed);
										} else {
											return false;
										}
									}()) {
										return refuse('Snap output/work-area placement changed');
									} else {
										var intent = {R: observed.R, e7: generation, au: incarnation, bc: operation, cM: request};
										var transaction = {az: 2, af: intent, O: 0};
										return _Utils_Tuple3(
											_Utils_update(
												model,
												{
													e7: generation,
													cM: request,
													dz: $elm$core$Maybe$Just(transaction),
													fM: A2($elm$core$List$cons, transaction, model.fM)
												}),
											$elm$core$Maybe$Just(
												$elm$json$Json$Encode$object(
													_List_fromArray(
														[
															_Utils_Tuple2(
															'kind',
															$elm$json$Json$Encode$string('window-effect')),
															_Utils_Tuple2(
															'protocol',
															$elm$json$Json$Encode$int(2)),
															_Utils_Tuple2(
															'intent',
															$author$project$Effects$encodeIntent(intent))
														]))),
											$elm$core$Maybe$Nothing);
									}
								}
							}
						}
					}
				}
			}
		} else {
			return refuse('Missing geometry target or exhausted identity');
		}
	});
var $author$project$Effects$canProveUnsent = F3(
	function (protocolId, intent, model) {
		var exact = function (entry) {
			return _Utils_eq(entry.az, protocolId) && _Utils_eq(entry.af, intent);
		};
		var currentSafe = function () {
			var _v0 = model.dz;
			if (!_v0.$) {
				var entry = _v0.a;
				return (!exact(entry)) || (!entry.O);
			} else {
				return true;
			}
		}();
		return _Utils_eq(
			$author$project$Effects$protocol(intent.bc),
			protocolId) && (currentSafe && A2(
			$elm$core$List$any,
			function (entry) {
				return exact(entry) && (!entry.O);
			},
			model.fM));
	});
var $author$project$Shell$canProveUnsent = F2(
	function (operations, model) {
		var unique = A3(
			$elm$core$List$foldl,
			F2(
				function (key, entries) {
					return A2($elm$core$List$member, key, entries) ? entries : A2($elm$core$List$cons, key, entries);
				}),
			_List_Nil,
			operations);
		var known = function (key) {
			return _Utils_eq(
				model.c3,
				$elm$core$Maybe$Just(key.c3)) && (A2(
				$elm$core$List$any,
				function (entry) {
					return _Utils_eq(entry.c3, key.c3) && (_Utils_eq(entry.en, key.en) && _Utils_eq(entry.af, key.af));
				},
				model.X) && A3($author$project$Effects$canProveUnsent, key.en, key.af, model.V));
		};
		return (!$elm$core$List$isEmpty(operations)) && (($elm$core$List$length(operations) <= 16) && (_Utils_eq(
			$elm$core$List$length(unique),
			$elm$core$List$length(operations)) && ((!(!model.m)) && ((model.m !== 3) && A2($elm$core$List$all, known, operations)))));
	});
var $author$project$GeometryProjection$capabilityDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'maximize':
				return $elm$json$Json$Decode$succeed(0);
			case 'restore-geometry':
				return $elm$json$Json$Decode$succeed(1);
			case 'snap':
				return $elm$json$Json$Decode$succeed(2);
			case 'transfer-workspace':
				return $elm$json$Json$Decode$succeed(3);
			case 'pin':
				return $elm$json$Json$Decode$succeed(4);
			case 'unpin':
				return $elm$json$Json$Decode$succeed(5);
			case 'exit-fullscreen':
				return $elm$json$Json$Decode$succeed(6);
			default:
				return $elm$json$Json$Decode$fail('Geometry capabilities');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$GeometryProjection$exact = F3(
	function (name, child, value) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (x) {
				return _Utils_eq(x, value) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Geometry version');
			},
			A2($elm$json$Json$Decode$field, name, child));
	});
var $author$project$GeometryProjection$strict = F2(
	function (fields, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? body : $elm$json$Json$Decode$fail('Geometry schema');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$GeometryProjection$capabilitiesDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (caps) {
		return (($elm$core$List$length(caps.ef) <= 7) && (_Utils_eq(
			$elm$core$List$length(caps.ef),
			$elm$core$List$length(
				A3(
					$elm$core$List$foldl,
					F2(
						function (x, xs) {
							return A2($elm$core$List$member, x, xs) ? xs : A2($elm$core$List$cons, x, xs);
						}),
					_List_Nil,
					caps.ef))) && _Utils_eq(
			caps.V,
			!$elm$core$List$isEmpty(caps.ef)))) ? $elm$json$Json$Decode$succeed(caps) : $elm$json$Json$Decode$fail('Geometry capabilities');
	},
	A2(
		$author$project$GeometryProjection$strict,
		_List_fromArray(
			['observe', 'effects', 'effectProtocol', 'operations', 'placementCapacity', 'canonicalScene']),
		A7(
			$elm$json$Json$Decode$map6,
			F6(
				function (_v0, effects, _v1, operations, _v2, _v3) {
					return {V: effects, ef: operations};
				}),
			A3($author$project$GeometryProjection$exact, 'observe', $elm$json$Json$Decode$bool, true),
			A2($elm$json$Json$Decode$field, 'effects', $elm$json$Json$Decode$bool),
			A3($author$project$GeometryProjection$exact, 'effectProtocol', $elm$json$Json$Decode$int, 2),
			A2(
				$elm$json$Json$Decode$field,
				'operations',
				$elm$json$Json$Decode$list($author$project$GeometryProjection$capabilityDecoder)),
			A3($author$project$GeometryProjection$exact, 'placementCapacity', $elm$json$Json$Decode$int, 256),
			A3($author$project$GeometryProjection$exact, 'canonicalScene', $elm$json$Json$Decode$bool, false))));
var $author$project$GeometryProjection$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (x) {
		return _Utils_eq(x, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero geometry identity') : $elm$json$Json$Decode$succeed(x);
	},
	$author$project$UInt64$decoder);
var $author$project$GeometrySizePolicy$Policy = F3(
	function (inputs, maximize, restoreGeometry) {
		return {dd: inputs, fg: maximize, fA: restoreGeometry};
	});
var $author$project$GeometrySizePolicy$finite = function (x) {
	return !($elm$core$Basics$isNaN(x) || $elm$core$Basics$isInfinite(x));
};
var $author$project$GeometrySizePolicy$interval = F3(
	function (raw, _v0, _v1) {
		var lx = _v0.a;
		var ly = _v0.b;
		var ux = _v1.a;
		var uy = _v1.b;
		var axis = F2(
			function (lo, hi) {
				return (raw && (!hi)) || ((hi > 0) && (_Utils_cmp(lo, hi) < 0));
			});
		return A2(axis, lx, ux) && A2(axis, ly, uy);
	});
var $author$project$GeometrySizePolicy$pair = function (nonnegative) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (values) {
			if ((values.b && values.b.b) && (!values.b.b.b)) {
				var x = values.a;
				var _v1 = values.b;
				var y = _v1.a;
				return ($author$project$GeometrySizePolicy$finite(x) && ($author$project$GeometrySizePolicy$finite(y) && ((!nonnegative) || ((x >= 0) && (y >= 0))))) ? $elm$json$Json$Decode$succeed(
					_Utils_Tuple2(x, y)) : $elm$json$Json$Decode$fail('Size vector');
			} else {
				return $elm$json$Json$Decode$fail('Size vector shape');
			}
		},
		$elm$json$Json$Decode$list($elm$json$Json$Decode$float));
};
var $author$project$GeometrySizePolicy$strict = F2(
	function (fields, body) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? body : $elm$json$Json$Decode$fail('Size policy schema');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$GeometrySizePolicy$inputsDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (inputs) {
		return ($author$project$GeometrySizePolicy$finite(inputs.cP) && ((inputs.cP > 0) && (A3($author$project$GeometrySizePolicy$interval, true, inputs.bX, inputs.bW) && A3($author$project$GeometrySizePolicy$interval, false, inputs.bQ, inputs.bP)))) ? $elm$json$Json$Decode$succeed(inputs) : $elm$json$Json$Decode$fail('Size intervals');
	},
	A2(
		$author$project$GeometrySizePolicy$strict,
		_List_fromArray(
			['profile', 'rawMinimum', 'rawMaximum', 'layoutMinimum', 'layoutMaximum', 'geometryOrigin', 'reservedTopLeft', 'reservedBottomRight', 'monitorScale']),
		A3(
			$elm$json$Json$Decode$map2,
			F2(
				function (_v0, inputs) {
					return inputs;
				}),
			A2(
				$elm$json$Json$Decode$andThen,
				function (profile) {
					return (profile === 'wayland-zero-origin-v1') ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Conversion profile');
				},
				A2($elm$json$Json$Decode$field, 'profile', $elm$json$Json$Decode$string)),
			A9(
				$elm$json$Json$Decode$map8,
				F8(
					function (rawMin, rawMax, layoutMin, layoutMax, origin, tl, br, scale) {
						return {c4: br, bP: layoutMax, bQ: layoutMin, bT: origin, bW: rawMax, bX: rawMin, cP: scale, dy: tl};
					}),
				A2(
					$elm$json$Json$Decode$field,
					'rawMinimum',
					$author$project$GeometrySizePolicy$pair(true)),
				A2(
					$elm$json$Json$Decode$field,
					'rawMaximum',
					$author$project$GeometrySizePolicy$pair(true)),
				A2(
					$elm$json$Json$Decode$field,
					'layoutMinimum',
					$author$project$GeometrySizePolicy$pair(true)),
				A2(
					$elm$json$Json$Decode$field,
					'layoutMaximum',
					$author$project$GeometrySizePolicy$pair(true)),
				A2(
					$elm$json$Json$Decode$field,
					'geometryOrigin',
					$author$project$GeometrySizePolicy$pair(false)),
				A2(
					$elm$json$Json$Decode$field,
					'reservedTopLeft',
					$author$project$GeometrySizePolicy$pair(true)),
				A2(
					$elm$json$Json$Decode$field,
					'reservedBottomRight',
					$author$project$GeometrySizePolicy$pair(true)),
				A2($elm$json$Json$Decode$field, 'monitorScale', $elm$json$Json$Decode$float)))));
var $author$project$GeometrySizePolicy$Projection = F4(
	function (logical, visual, real, configure) {
		return {c7: configure, d7: logical, bZ: real, eO: visual};
	});
var $author$project$GeometrySizePolicy$box = A2(
	$elm$json$Json$Decode$andThen,
	function (values) {
		if ((((values.b && values.b.b) && values.b.b.b) && values.b.b.b.b) && (!values.b.b.b.b.b)) {
			var x = values.a;
			var _v1 = values.b;
			var y = _v1.a;
			var _v2 = _v1.b;
			var w = _v2.a;
			var _v3 = _v2.b;
			var h = _v3.a;
			return (A2($elm$core$List$all, $author$project$GeometrySizePolicy$finite, values) && (A2(
				$elm$core$List$all,
				function (v) {
					return $elm$core$Basics$abs(v) <= 2147483647;
				},
				values) && ((w > 0) && (h > 0)))) ? $elm$json$Json$Decode$succeed(
				{aS: h, a0: w, a1: x, a2: y}) : $elm$json$Json$Decode$fail('Prospective box');
		} else {
			return $elm$json$Json$Decode$fail('Prospective box shape');
		}
	},
	$elm$json$Json$Decode$list($elm$json$Json$Decode$float));
var $author$project$GeometrySizePolicy$projectionDecoder = A2(
	$author$project$GeometrySizePolicy$strict,
	_List_fromArray(
		['logical', 'visual', 'real', 'configure']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$GeometrySizePolicy$Projection,
		A2($elm$json$Json$Decode$field, 'logical', $author$project$GeometrySizePolicy$box),
		A2(
			$elm$json$Json$Decode$field,
			'visual',
			$elm$json$Json$Decode$nullable($author$project$GeometrySizePolicy$box)),
		A2($elm$json$Json$Decode$field, 'real', $author$project$GeometrySizePolicy$box),
		A2(
			$elm$json$Json$Decode$field,
			'configure',
			$author$project$GeometrySizePolicy$pair(true))));
var $author$project$GeometrySizePolicy$decoder = A2(
	$author$project$GeometrySizePolicy$strict,
	_List_fromArray(
		['inputs', 'maximize', 'restoreGeometry']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$GeometrySizePolicy$Policy,
		A2(
			$elm$json$Json$Decode$field,
			'inputs',
			$elm$json$Json$Decode$nullable($author$project$GeometrySizePolicy$inputsDecoder)),
		A2(
			$elm$json$Json$Decode$field,
			'maximize',
			$elm$json$Json$Decode$nullable($author$project$GeometrySizePolicy$projectionDecoder)),
		A2(
			$elm$json$Json$Decode$field,
			'restoreGeometry',
			$elm$json$Json$Decode$nullable($author$project$GeometrySizePolicy$projectionDecoder))));
var $author$project$GeometryProjection$modeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (x) {
		switch (x) {
			case 'ordinary':
				return $elm$json$Json$Decode$succeed(0);
			case 'maximized':
				return $elm$json$Json$Decode$succeed(1);
			case 'fullscreen':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Geometry mode');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$GeometryProjection$rect = A2(
	$elm$json$Json$Decode$andThen,
	function (xs) {
		if ((((xs.b && xs.b.b) && xs.b.b.b) && xs.b.b.b.b) && (!xs.b.b.b.b.b)) {
			var x = xs.a;
			var _v1 = xs.b;
			var y = _v1.a;
			var _v2 = _v1.b;
			var w = _v2.a;
			var _v3 = _v2.b;
			var h = _v3.a;
			return (A2(
				$elm$core$List$all,
				function (n) {
					return !($elm$core$Basics$isNaN(n) || $elm$core$Basics$isInfinite(n));
				},
				_List_fromArray(
					[x, y, w, h, x + w, y + h])) && ((w > 0) && (h > 0))) ? $elm$json$Json$Decode$succeed(xs) : $elm$json$Json$Decode$fail('Geometry rectangle');
		} else {
			return $elm$json$Json$Decode$fail('Geometry rectangle shape');
		}
	},
	$elm$json$Json$Decode$list($elm$json$Json$Decode$float));
var $author$project$GeometryProjection$workspace = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		var negative = A2($elm$core$String$startsWith, '-', value);
		var limit = negative ? '9223372036854775808' : '9223372036854775807';
		var digits = negative ? A2($elm$core$String$dropLeft, 1, value) : value;
		var valid = (!$elm$core$String$isEmpty(digits)) && (A2($elm$core$String$all, $elm$core$Char$isDigit, digits) && (((digits === '0') || (!A2($elm$core$String$startsWith, '0', digits))) && ((!(negative && (digits === '0'))) && (($elm$core$String$length(digits) < 19) || (($elm$core$String$length(digits) === 19) && (_Utils_cmp(digits, limit) < 1))))));
		return valid ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Workspace identity');
	},
	$elm$json$Json$Decode$string);
var $author$project$GeometryProjection$windowDecoder = function (protocol) {
	var state = A9(
		$elm$json$Json$Decode$map8,
		F8(
			function (logical, visual, _native, client, minimized, floating, grouped, fixed) {
				return {dK: client, dU: fixed, bO: floating, bt: grouped, d7: logical, bR: minimized, eb: _native, eO: visual};
			}),
		A2($elm$json$Json$Decode$field, 'logicalGeometry', $author$project$GeometryProjection$rect),
		A2($elm$json$Json$Decode$field, 'visualGeometry', $author$project$GeometryProjection$rect),
		A2($elm$json$Json$Decode$field, 'nativeMode', $author$project$GeometryProjection$modeDecoder),
		A2($elm$json$Json$Decode$field, 'clientMode', $author$project$GeometryProjection$modeDecoder),
		A2($elm$json$Json$Decode$field, 'minimized', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'floating', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'grouped', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'fixedSize', $elm$json$Json$Decode$bool));
	var policy = A7(
		$elm$json$Json$Decode$map6,
		F6(
			function (constrained, eligible, known, caps, size, pin) {
				return {c6: caps, dM: constrained, da: eligible, d5: known, dp: pin, eE: size};
			}),
		A2($elm$json$Json$Decode$field, 'constrainedSize', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'geometryEligible', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'ordinaryPlacementKnown', $elm$json$Json$Decode$bool),
		A2(
			$elm$json$Json$Decode$field,
			'capabilities',
			A2(
				$author$project$GeometryProjection$strict,
				_List_fromArray(
					['maximize', 'restoreGeometry']),
				A3(
					$elm$json$Json$Decode$map2,
					$elm$core$Tuple$pair,
					A2($elm$json$Json$Decode$field, 'maximize', $elm$json$Json$Decode$bool),
					A2($elm$json$Json$Decode$field, 'restoreGeometry', $elm$json$Json$Decode$bool)))),
		(protocol >= 2) ? A2(
			$elm$json$Json$Decode$map,
			$elm$core$Maybe$Just,
			A2($elm$json$Json$Decode$field, 'sizePolicy', $author$project$GeometrySizePolicy$decoder)) : $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing),
		(protocol === 3) ? A2(
			$elm$json$Json$Decode$map,
			$elm$core$Maybe$Just,
			A2(
				$elm$json$Json$Decode$field,
				'pin',
				A2(
					$author$project$GeometryProjection$strict,
					_List_fromArray(
						['pinned', 'eligible']),
					A3(
						$elm$json$Json$Decode$map2,
						F2(
							function (pinned, eligible) {
								return {da: eligible, fr: pinned};
							}),
						A2($elm$json$Json$Decode$field, 'pinned', $elm$json$Json$Decode$bool),
						A2($elm$json$Json$Decode$field, 'eligible', $elm$json$Json$Decode$bool))))) : $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing));
	var identities = A9(
		$elm$json$Json$Decode$map8,
		F8(
			function (inc, owner, ws, wg, mon, og, wr, wa) {
				return {d0: inc, d9: mon, ee: og, dm: owner, eQ: wa, eR: wg, eS: wr, eT: ws};
			}),
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$GeometryProjection$positive),
		A2(
			$elm$json$Json$Decode$field,
			'owner',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$positive)),
		A2(
			$elm$json$Json$Decode$field,
			'workspace',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$workspace)),
		A2(
			$elm$json$Json$Decode$field,
			'workspaceGeneration',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$positive)),
		A2(
			$elm$json$Json$Decode$field,
			'monitor',
			$elm$json$Json$Decode$nullable($author$project$UInt64$decoder)),
		A2(
			$elm$json$Json$Decode$field,
			'outputOwnershipGeneration',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$positive)),
		A2(
			$elm$json$Json$Decode$field,
			'workAreaRevision',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$positive)),
		A2(
			$elm$json$Json$Decode$field,
			'workArea',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$rect)));
	return A2(
		$author$project$GeometryProjection$strict,
		_Utils_ap(
			_List_fromArray(
				['incarnation', 'owner', 'workspace', 'workspaceGeneration', 'monitor', 'outputOwnershipGeneration', 'workAreaRevision', 'workArea', 'logicalGeometry', 'visualGeometry', 'nativeMode', 'clientMode', 'minimized', 'floating', 'grouped', 'fixedSize', 'constrainedSize', 'geometryEligible', 'ordinaryPlacementKnown', 'capabilities']),
			_Utils_ap(
				(protocol >= 2) ? _List_fromArray(
					['sizePolicy']) : _List_Nil,
				(protocol === 3) ? _List_fromArray(
					['pin']) : _List_Nil)),
		A4(
			$elm$json$Json$Decode$map3,
			F3(
				function (i, s, p) {
					return {b8: s.dK, cy: p.dM, da: p.da, e6: s.dU, bO: s.bO, bt: s.bt, au: i.d0, d8: s.d7, fg: p.c6.a, bR: s.bR, bS: i.d9, ec: s.eb, bd: i.ee, dm: i.dm, dp: p.dp, fs: p.d5, fA: p.c6.b, cU: p.eE, eP: s.eO, b4: i.eQ, ct: i.eS, dB: i.eT, b5: i.eR};
				}),
			identities,
			state,
			policy));
};
var $author$project$GeometryProjection$factsBody = function (protocol) {
	return A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (focus, blocked, rows) {
				return {eZ: blocked, ca: focus, a: rows};
			}),
		A2(
			$elm$json$Json$Decode$field,
			'focused',
			$elm$json$Json$Decode$nullable($author$project$GeometryProjection$positive)),
		A2($elm$json$Json$Decode$field, 'inputBlocked', $elm$json$Json$Decode$bool),
		A2(
			$elm$json$Json$Decode$field,
			'windows',
			$elm$json$Json$Decode$list(
				$author$project$GeometryProjection$windowDecoder(protocol))));
};
var $author$project$GeometrySizePolicy$fixed = function (inputs) {
	var axis = F4(
		function (rawLo, rawHi, layoutLo, layoutHi) {
			var upper = A2(
				$elm$core$Basics$min,
				2147483647,
				A2(
					$elm$core$Basics$min,
					(!rawHi) ? 2147483647 : $elm$core$Basics$floor(rawHi),
					$elm$core$Basics$floor(layoutHi)));
			var lower = A2(
				$elm$core$Basics$max,
				1,
				A2(
					$elm$core$Basics$max,
					$elm$core$Basics$ceiling(rawLo),
					$elm$core$Basics$floor(layoutLo)));
			return _Utils_cmp(lower, upper) > -1;
		});
	var _v0 = inputs.bW;
	var ux = _v0.a;
	var uy = _v0.b;
	var _v1 = inputs.bX;
	var rx = _v1.a;
	var ry = _v1.b;
	var _v2 = inputs.bQ;
	var lx = _v2.a;
	var ly = _v2.b;
	var _v3 = inputs.bP;
	var hx = _v3.a;
	var hy = _v3.b;
	return A4(axis, rx, ux, lx, hx) || A4(axis, ry, uy, ly, hy);
};
var $author$project$GeometrySizePolicy$fromList = function (values) {
	if ((((values.b && values.b.b) && values.b.b.b) && values.b.b.b.b) && (!values.b.b.b.b.b)) {
		var x = values.a;
		var _v1 = values.b;
		var y = _v1.a;
		var _v2 = _v1.b;
		var w = _v2.a;
		var _v3 = _v2.b;
		var h = _v3.a;
		return $elm$core$Maybe$Just(
			{aS: h, a0: w, a1: x, a2: y});
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$GeometrySizePolicy$roundNative = function (x) {
	return (x >= 0) ? ($elm$core$Basics$floor(x) + (((x - $elm$core$Basics$floor(x)) >= 0.5) ? 1 : 0)) : ($elm$core$Basics$ceiling(x) - ((($elm$core$Basics$ceiling(x) - x) >= 0.5) ? 1 : 0));
};
var $author$project$GeometrySizePolicy$rounded = function (value) {
	return {
		aS: $author$project$GeometrySizePolicy$roundNative(value.a2 + value.aS) - $author$project$GeometrySizePolicy$roundNative(value.a2),
		a0: $author$project$GeometrySizePolicy$roundNative(value.a1 + value.a0) - $author$project$GeometrySizePolicy$roundNative(value.a1),
		a1: $author$project$GeometrySizePolicy$roundNative(value.a1),
		a2: $author$project$GeometrySizePolicy$roundNative(value.a2)
	};
};
var $author$project$GeometrySizePolicy$within = F2(
	function (inputs, projection) {
		var axis = F6(
			function (configured, real, rawLo, rawHi, lo, hi) {
				return (configured >= 1) && ((configured <= 2147483647) && ((_Utils_cmp(configured, rawLo) > -1) && (((!rawHi) || (_Utils_cmp(configured, rawHi) < 1)) && ((_Utils_cmp(real, lo) > -1) && (_Utils_cmp(real, hi) < 1)))));
			});
		var _v0 = inputs.bW;
		var ux = _v0.a;
		var uy = _v0.b;
		var _v1 = inputs.bX;
		var rx = _v1.a;
		var ry = _v1.b;
		var _v2 = inputs.bQ;
		var lx = _v2.a;
		var ly = _v2.b;
		var _v3 = inputs.bP;
		var hx = _v3.a;
		var hy = _v3.b;
		var _v4 = projection.c7;
		var cx = _v4.a;
		var cy = _v4.b;
		return _Utils_eq(
			projection.c7,
			_Utils_Tuple2(
				$elm$core$Basics$floor(projection.bZ.a0),
				$elm$core$Basics$floor(projection.bZ.aS))) && (A6(axis, cx, projection.bZ.a0, rx, ux, lx, hx) && A6(axis, cy, projection.bZ.aS, ry, uy, ly, hy));
	});
var $author$project$GeometrySizePolicy$projectionValid = F4(
	function (maximize, workArea, inputs, projection) {
		var real = projection.bZ;
		var logical = projection.d7;
		var source = maximize ? A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				A2(
					$elm$core$Basics$composeR,
					$author$project$GeometrySizePolicy$rounded,
					$elm$core$Basics$eq(logical)),
				A2($elm$core$Maybe$andThen, $author$project$GeometrySizePolicy$fromList, workArea))) : _Utils_eq(
			projection.eO,
			$elm$core$Maybe$Just(real));
		var _v0 = inputs.dy;
		var tx = _v0.a;
		var ty = _v0.b;
		var _v1 = inputs.c4;
		var bx = _v1.a;
		var by = _v1.b;
		var converted = maximize ? {aS: logical.aS - (ty + by), a0: logical.a0 - (tx + bx), a1: logical.a1 + tx, a2: logical.a2 + ty} : logical;
		return _Utils_eq(
			logical,
			$author$project$GeometrySizePolicy$rounded(logical)) && (A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (v) {
					return _Utils_eq(
						v,
						$author$project$GeometrySizePolicy$rounded(v));
				},
				projection.eO)) && (_Utils_eq(real, converted) && (A2($author$project$GeometrySizePolicy$within, inputs, projection) && (source && ((!maximize) || _Utils_eq(projection.eO, $elm$core$Maybe$Nothing))))));
	});
var $author$project$GeometrySizePolicy$supported = function (policy) {
	var _v0 = policy.dd;
	if (_v0.$ === 1) {
		return false;
	} else {
		var inputs = _v0.a;
		return _Utils_eq(
			inputs.bT,
			_Utils_Tuple2(0, 0)) && (!$author$project$GeometrySizePolicy$fixed(inputs));
	}
};
var $author$project$GeometrySizePolicy$coherent = F4(
	function (policy, workArea, constrained, fixedSize) {
		var _v0 = policy.dd;
		if (_v0.$ === 1) {
			return _Utils_eq(policy.fg, $elm$core$Maybe$Nothing) && _Utils_eq(policy.fA, $elm$core$Maybe$Nothing);
		} else {
			var inputs = _v0.a;
			var values = function (_v1) {
				var x = _v1.a;
				var y = _v1.b;
				return _List_fromArray(
					[x, y]);
			};
			var valid = F2(
				function (maximize, projection) {
					return A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							function (p) {
								return $author$project$GeometrySizePolicy$supported(policy) && A4($author$project$GeometrySizePolicy$projectionValid, maximize, workArea, inputs, p);
							},
							projection));
				});
			var expected = A2(
				$elm$core$List$any,
				$elm$core$Basics$lt(1),
				_Utils_ap(
					values(inputs.bX),
					values(inputs.bQ))) || (A2(
				$elm$core$List$any,
				$elm$core$Basics$lt(0),
				values(inputs.bW)) || A2(
				$elm$core$List$any,
				$elm$core$Basics$gt(1.7976931348623157e308),
				values(inputs.bP)));
			return _Utils_eq(constrained, expected) && (_Utils_eq(
				fixedSize,
				$author$project$GeometrySizePolicy$fixed(inputs)) && (A2(valid, true, policy.fg) && A2(valid, false, policy.fA)));
		}
	});
var $author$project$GeometrySizePolicy$permits = F2(
	function (maximize, policy) {
		return $author$project$GeometrySizePolicy$supported(policy) && (maximize ? (!_Utils_eq(policy.fg, $elm$core$Maybe$Nothing)) : (!_Utils_eq(policy.fA, $elm$core$Maybe$Nothing)));
	});
var $author$project$GeometryProjection$validRows = F3(
	function (caps, blocked, rows) {
		var walk = F2(
			function (visited, id) {
				walk:
				while (true) {
					if (A2($elm$core$List$member, id, visited)) {
						return false;
					} else {
						var _v0 = $elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (row) {
									return _Utils_eq(row.au, id);
								},
								rows));
						if (_v0.$ === 1) {
							return false;
						} else {
							var row = _v0.a;
							var _v1 = row.dm;
							if (_v1.$ === 1) {
								return true;
							} else {
								var parent = _v1.a;
								var $temp$visited = A2($elm$core$List$cons, id, visited),
									$temp$id = parent;
								visited = $temp$visited;
								id = $temp$id;
								continue walk;
							}
						}
					}
				}
			});
		var rowValid = function (row) {
			var sizeValid = A2(
				$elm$core$Maybe$withDefault,
				true,
				A2(
					$elm$core$Maybe$map,
					function (p) {
						return A4($author$project$GeometrySizePolicy$coherent, p, row.b4, row.cy, row.e6) && (((!row.da) || $author$project$GeometrySizePolicy$supported(p)) && (((!row.fg) || A2($author$project$GeometrySizePolicy$permits, true, p)) && ((!row.fA) || A2($author$project$GeometrySizePolicy$permits, false, p))));
					},
					row.cU));
			var pinValid = A2(
				$elm$core$Maybe$withDefault,
				true,
				A2(
					$elm$core$Maybe$map,
					function (pin) {
						return (!pin.da) || ((!blocked) && ((!_Utils_eq(row.dB, $elm$core$Maybe$Nothing)) && (row.bO && (_Utils_eq(row.dm, $elm$core$Maybe$Nothing) && ((!row.bt) && ((!row.bR) && (_Utils_eq(row.ec, row.b8) && ((row.ec !== 2) && (A2($elm$core$List$member, 4, caps.ef) && A2($elm$core$List$member, 5, caps.ef))))))))));
					},
					row.dp));
			var ownership = function () {
				var _v2 = row.dm;
				if (_v2.$ === 1) {
					return true;
				} else {
					return A2(walk, _List_Nil, row.au);
				}
			}();
			var known = A2(
				$elm$core$List$map,
				$elm$core$Basics$identity,
				_List_fromArray(
					[
						!_Utils_eq(row.dB, $elm$core$Maybe$Nothing),
						!_Utils_eq(row.b5, $elm$core$Maybe$Nothing),
						!_Utils_eq(row.bS, $elm$core$Maybe$Nothing),
						!_Utils_eq(row.bd, $elm$core$Maybe$Nothing),
						!_Utils_eq(row.ct, $elm$core$Maybe$Nothing),
						!_Utils_eq(row.b4, $elm$core$Maybe$Nothing)
					]));
			var paired = A2(
				$elm$core$List$all,
				$elm$core$Basics$eq(true),
				known) || A2(
				$elm$core$List$all,
				$elm$core$Basics$eq(false),
				known);
			var eligible = (!row.da) || ((!_Utils_eq(row.dB, $elm$core$Maybe$Nothing)) && ((!blocked) && ((!row.bR) && ((!row.bt) && ((!row.e6) && (((!_Utils_eq(row.cU, $elm$core$Maybe$Nothing)) || (!row.cy)) && (row.bO && (_Utils_eq(row.dm, $elm$core$Maybe$Nothing) && (_Utils_eq(row.ec, row.b8) && (row.ec !== 2))))))))));
			var capabilityModes = ((!row.fg) || (row.da && (!row.ec))) && ((!row.fA) || (row.da && ((row.ec === 1) && row.fs)));
			return pinValid && (paired && (eligible && (ownership && (sizeValid && (capabilityModes && (((!row.fg) || A2($elm$core$List$member, 0, caps.ef)) && ((!row.fA) || A2($elm$core$List$member, 1, caps.ef))))))));
		};
		var ids = A2(
			$elm$core$List$map,
			function ($) {
				return $.au;
			},
			rows);
		var unique = _Utils_eq(
			$elm$core$List$length(ids),
			$elm$core$List$length(
				A3(
					$elm$core$List$foldl,
					F2(
						function (x, xs) {
							return A2($elm$core$List$member, x, xs) ? xs : A2($elm$core$List$cons, x, xs);
						}),
					_List_Nil,
					ids)));
		var coherent = F2(
			function (a, b) {
				return (_Utils_eq(a.bd, $elm$core$Maybe$Nothing) || ((!_Utils_eq(a.bd, b.bd)) || _Utils_eq(a.bS, b.bS))) && (_Utils_eq(a.b5, $elm$core$Maybe$Nothing) || ((!_Utils_eq(a.b5, b.b5)) || (_Utils_eq(a.dB, b.dB) && (_Utils_eq(a.bd, b.bd) && (_Utils_eq(a.ct, b.ct) && _Utils_eq(a.b4, b.b4))))));
			});
		return ($elm$core$List$length(rows) <= 256) && (unique && (A2($elm$core$List$all, rowValid, rows) && A2(
			$elm$core$List$all,
			function (a) {
				return A2(
					$elm$core$List$all,
					coherent(a),
					rows);
			},
			rows)));
	});
var $author$project$GeometryProjection$decoder = F2(
	function (protocol, caps) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (snapshot) {
				return (A3($author$project$GeometryProjection$validRows, caps, snapshot.eZ, snapshot.a) && A2(
					$elm$core$Maybe$withDefault,
					true,
					A2(
						$elm$core$Maybe$map,
						function (id) {
							return A2(
								$elm$core$List$any,
								function (row) {
									return _Utils_eq(row.au, id);
								},
								snapshot.a);
						},
						snapshot.ca))) ? $elm$json$Json$Decode$succeed(snapshot) : $elm$json$Json$Decode$fail('Geometry facts coherence');
			},
			A2(
				$author$project$GeometryProjection$strict,
				_List_fromArray(
					['protocolVersion', 'kind', 'geometryProtocol', 'binding', 'requestId', 'sequence', 'revision', 'outputGeneration', 'facts']),
				A9(
					$elm$json$Json$Decode$map8,
					F8(
						function (_v0, _v1, _v2, binding, request, sequence, revision, rest) {
							var _v3 = rest;
							var output = _v3.a;
							var facts = _v3.b;
							var context = function () {
								var _v4 = A2(
									$elm$json$Json$Decode$decodeValue,
									A3(
										$elm$json$Json$Decode$map2,
										$elm$core$Tuple$pair,
										A2($elm$json$Json$Decode$field, 'lifetime', $author$project$GeometryProjection$positive),
										A2($elm$json$Json$Decode$field, 'frontend', $author$project$GeometryProjection$positive)),
									$author$project$Binding$encode(binding));
								if (!_v4.$) {
									var _v5 = _v4.a;
									var life = _v5.a;
									var epoch = _v5.b;
									return {e4: epoch, fe: life, z: output, cN: revision};
								} else {
									return {e4: $author$project$UInt64$zero, fe: $author$project$UInt64$zero, z: output, cN: revision};
								}
							}();
							return {c3: binding, eZ: facts.eZ, R: context, ca: facts.ca, cM: request, eC: sequence, a: facts.a};
						}),
					A3($author$project$GeometryProjection$exact, 'protocolVersion', $elm$json$Json$Decode$int, 3),
					A3($author$project$GeometryProjection$exact, 'kind', $elm$json$Json$Decode$string, 'geometry-facts'),
					A3($author$project$GeometryProjection$exact, 'geometryProtocol', $elm$json$Json$Decode$int, protocol),
					A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
					A2($elm$json$Json$Decode$field, 'requestId', $author$project$GeometryProjection$positive),
					A2($elm$json$Json$Decode$field, 'sequence', $author$project$GeometryProjection$positive),
					A2($elm$json$Json$Decode$field, 'revision', $author$project$GeometryProjection$positive),
					A3(
						$elm$json$Json$Decode$map2,
						$elm$core$Tuple$pair,
						A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$GeometryProjection$positive),
						A2(
							$elm$json$Json$Decode$field,
							'facts',
							$elm$json$Json$Decode$oneOf(
								_List_fromArray(
									[
										A2(
										$author$project$GeometryProjection$strict,
										_List_fromArray(
											['focused', 'inputBlocked', 'windows']),
										$author$project$GeometryProjection$factsBody(protocol)),
										(protocol === 3) ? A2(
										$author$project$GeometryProjection$strict,
										_List_fromArray(
											['focused', 'inputBlocked', 'windows', 'workspaces', 'activeWorkspace']),
										A3(
											$elm$json$Json$Decode$map2,
											F2(
												function (facts, _v6) {
													return facts;
												}),
											$author$project$GeometryProjection$factsBody(protocol),
											$author$project$WorkspaceInventory$factsDecoder)) : $elm$json$Json$Decode$fail('Workspace inventory version')
									])))))));
	});
var $author$project$GeometryProjection$decode = F2(
	function (caps, raw) {
		return A2(
			$elm$core$Result$mapError,
			function (_v0) {
				return 'Invalid geometry projection';
			},
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2(
					$elm$json$Json$Decode$andThen,
					function (version) {
						return A2(
							$elm$core$List$member,
							version,
							_List_fromArray(
								[2, 3])) ? A2($author$project$GeometryProjection$decoder, version, caps) : $elm$json$Json$Decode$fail('Geometry protocol');
					},
					A2($elm$json$Json$Decode$field, 'geometryProtocol', $elm$json$Json$Decode$int)),
				raw));
	});
var $author$project$Shell$recoveryNotice = function (failure) {
	switch (failure) {
		case 0:
			return 'Window recovery data is unavailable. Restore access, then reconnect.';
		case 1:
			return 'Window recovery storage is full. Free space, then reconnect.';
		case 2:
			return 'Another shell is using window recovery data. Close it, then reconnect.';
		case 3:
			return 'Window recovery data could not be verified. Repair it, then reconnect.';
		default:
			return 'Previous window recovery data has no verified owner. Complete migration, then reconnect.';
	}
};
var $author$project$Shell$disconnect = function (model) {
	var _v0 = A2(
		$author$project$Effects$apply,
		$elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'kind',
					$elm$json$Json$Encode$string('disconnect'))
				])),
		model.V);
	var effects = _v0.a;
	return _Utils_update(
		model,
		{
			c1: false,
			ar: false,
			dO: false,
			V: effects,
			y: $elm$core$Maybe$Nothing,
			ac: $elm$core$Maybe$Nothing,
			dY: $elm$core$Maybe$Nothing,
			dc: $elm$core$Maybe$Nothing,
			cE: $elm$core$Maybe$Nothing,
			fj: A2(
				$elm$core$Maybe$withDefault,
				'Connection lost. Reconnect to continue.',
				A2($elm$core$Maybe$map, $author$project$Shell$recoveryNotice, model.bD)),
			aD: false,
			m: 0,
			aZ: false,
			aK: false,
			aa: false
		});
};
var $author$project$Effects$locallyRefuseUnsent = F3(
	function (protocolId, intent, model) {
		var exact = function (entry) {
			return _Utils_eq(entry.az, protocolId) && _Utils_eq(entry.af, intent);
		};
		return (!A3($author$project$Effects$canProveUnsent, protocolId, intent, model)) ? model : _Utils_update(
			model,
			{
				dz: A2(
					$elm$core$Maybe$map,
					function (entry) {
						return exact(entry) ? _Utils_update(
							entry,
							{O: 2}) : entry;
					},
					model.dz),
				fM: A2(
					$elm$core$List$filter,
					A2($elm$core$Basics$composeR, exact, $elm$core$Basics$not),
					model.fM)
			});
	});
var $author$project$Shell$matchesUnsent = F2(
	function (observations, model) {
		var slot = function (kind) {
			switch (kind) {
				case 'projection-request':
					return model.y;
				case 'geometry-facts-request':
					return model.cE;
				case 'geometry-attach':
					return model.dY;
				default:
					return $elm$core$Maybe$Nothing;
			}
		};
		return (!$elm$core$List$isEmpty(observations)) && A2(
			$elm$core$List$all,
			function (_v0) {
				var kind = _v0.a;
				var request = _v0.b;
				return _Utils_eq(
					slot(kind),
					$elm$core$Maybe$Just(request));
			},
			observations);
	});
var $author$project$Shell$notificationRefresh = function (model) {
	return (model.c1 || ((!model.m) || ((model.m === 3) || model.aa))) ? _Utils_Tuple2(model, _List_Nil) : ((model.dO || ($author$project$Effects$pending(model.V) || ((!_Utils_eq(model.y, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(model.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing)))))) ? _Utils_Tuple2(
		_Utils_update(
			model,
			{aD: true}),
		_List_Nil) : $author$project$Shell$refreshObservations(model));
};
var $author$project$Shell$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Zero displayed scope');
	},
	$author$project$UInt64$decoder);
var $author$project$Effects$recoverUnknown = F3(
	function (protocolId, intent, model) {
		var observe = function (transaction) {
			return (_Utils_eq(transaction.af, intent) && (_Utils_eq(transaction.az, protocolId) && (!transaction.O))) ? _Utils_update(
				transaction,
				{O: 4}) : transaction;
		};
		var _v0 = A2(
			$author$project$Effects$apply,
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('recover')),
						_Utils_Tuple2(
						'intent',
						$author$project$Effects$encodeIntent(intent)),
						_Utils_Tuple2(
						'effectProtocol',
						$elm$json$Json$Encode$int(protocolId))
					])),
			model);
		var recovered = _v0.a;
		var error = _v0.c;
		if (!error.$) {
			var reason = error.a;
			return $elm$core$Result$Err(reason);
		} else {
			return $elm$core$Result$Ok(
				_Utils_update(
					recovered,
					{
						dz: A2($elm$core$Maybe$map, observe, recovered.dz),
						fM: A2($elm$core$List$map, observe, recovered.fM)
					}));
		}
	});
var $author$project$Shell$Busy = 2;
var $author$project$Shell$Full = 1;
var $author$project$Shell$LegacyOwner = 4;
var $author$project$Shell$Unavailable = 0;
var $author$project$Shell$Unverified = 3;
var $author$project$Shell$recoveryDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (reason) {
		switch (reason) {
			case 'unavailable':
				return $elm$json$Json$Decode$succeed(0);
			case 'full':
				return $elm$json$Json$Decode$succeed(1);
			case 'busy':
				return $elm$json$Json$Decode$succeed(2);
			case 'unverified':
				return $elm$json$Json$Decode$succeed(3);
			case 'legacy-owner':
				return $elm$json$Json$Decode$succeed(4);
			default:
				return $elm$json$Json$Decode$fail('Recovery reason');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Shell$rejectReason = F2(
	function (reason, model) {
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{
					cB: $elm$core$Maybe$Just(reason)
				}),
			_List_Nil);
	});
var $author$project$Shell$version = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return (v === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Protocol version');
	},
	A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int));
var $author$project$Shell$rejectEnvelope = F2(
	function (raw, model) {
		var reason = function () {
			var _v0 = A2($elm$json$Json$Decode$decodeValue, $author$project$Shell$version, raw);
			if (_v0.$ === 1) {
				return 'Native envelope rejected: missing or unsupported protocol version.';
			} else {
				return 'Native envelope rejected: malformed fields.';
			}
		}();
		return A2($author$project$Shell$rejectReason, reason, model);
	});
var $author$project$Effects$releaseUnknown = F3(
	function (protocolId, intent, model) {
		return _Utils_update(
			model,
			{
				fM: A2(
					$elm$core$List$filter,
					function (t) {
						return !((t.O === 4) && (_Utils_eq(t.az, protocolId) && _Utils_eq(t.af, intent)));
					},
					model.fM)
			});
	});
var $author$project$Binding$replaces = F2(
	function (_v0, _v1) {
		var life = _v0.a;
		var session = _v0.b;
		var frontend = _v0.c;
		var oldLife = _v1.a;
		var oldSession = _v1.b;
		var oldFrontend = _v1.c;
		return (!_Utils_eq(life, oldLife)) || ((!_Utils_eq(session, oldSession)) || (A2($author$project$UInt64$compare, frontend, oldFrontend) === 2));
	});
var $author$project$Shell$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Unexpected fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativeOutcome$exact = F3(
	function (name, child, expected) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return _Utils_eq(value, expected) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Outcome protocol');
			},
			A2($elm$json$Json$Decode$field, name, child));
	});
var $author$project$NativeOutcome$intent = function (protocolId) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (original) {
			return _Utils_eq(
				$author$project$Effects$protocol(original.bc),
				protocolId) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Outcome operation protocol');
		},
		$author$project$Effects$intentDecoder);
};
var $author$project$NativeOutcome$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero outcome identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$NativeOutcome$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Outcome schema');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$NativeOutcome$decoderBody = function (protocolId) {
	return A2(
		$author$project$NativeOutcome$strict,
		_List_fromArray(
			['protocolVersion', 'kind', 'effectProtocol', 'binding', 'intent', 'status', 'reason', 'revision', 'outputGeneration']),
		A9(
			$elm$json$Json$Decode$map8,
			F8(
				function (_v0, _v1, _v2, _v3, _v4, _v5, _v6, _v7) {
					return 0;
				}),
			A3($author$project$NativeOutcome$exact, 'protocolVersion', $elm$json$Json$Decode$int, 3),
			A3($author$project$NativeOutcome$exact, 'kind', $elm$json$Json$Decode$string, 'effect-outcome'),
			A3($author$project$NativeOutcome$exact, 'effectProtocol', $elm$json$Json$Decode$int, protocolId),
			A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
			A2(
				$elm$json$Json$Decode$field,
				'intent',
				$author$project$NativeOutcome$intent(protocolId)),
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return A2(
						$elm$core$List$member,
						value,
						_List_fromArray(
							['Committed', 'Refused', 'Cancelled', 'Unknown'])) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Outcome status');
				},
				A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string)),
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return ($elm$core$String$length(value) <= 256) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Outcome reason');
				},
				A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$string)),
			A3(
				$elm$json$Json$Decode$map2,
				F2(
					function (_v8, _v9) {
						return 0;
					}),
				A2($elm$json$Json$Decode$field, 'revision', $author$project$NativeOutcome$positive),
				A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$NativeOutcome$positive))));
};
var $author$project$NativeOutcome$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (protocolId) {
		return A2(
			$elm$core$List$member,
			protocolId,
			_List_fromArray(
				[1, 2])) ? $author$project$NativeOutcome$decoderBody(protocolId) : $elm$json$Json$Decode$fail('Effect protocol');
	},
	A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int));
var $author$project$NativeOutcome$valid = function (value) {
	var _v0 = A2($elm$json$Json$Decode$decodeValue, $author$project$NativeOutcome$decoder, value);
	if (!_v0.$) {
		return true;
	} else {
		return false;
	}
};
var $author$project$Shell$update = F2(
	function (msg, model) {
		switch (msg.$) {
			case 0:
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{cl: true, aa: true}),
					_List_Nil);
			case 1:
				var protocolId = msg.a;
				var intent = msg.b;
				var _v1 = A3($author$project$Effects$recoverUnknown, protocolId, intent, model.V);
				if (_v1.$ === 1) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var effects = _v1.a;
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{V: effects, fj: 'The previous window change could not be confirmed.'}),
						_List_Nil);
				}
			case 2:
				var preserveShared = msg.a;
				var oldBinding = msg.b;
				var protocolId = msg.c;
				var intent = msg.d;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							V: preserveShared ? model.V : A3($author$project$Effects$releaseUnknown, protocolId, intent, model.V),
							X: A2(
								$elm$core$List$filter,
								function (entry) {
									return !(_Utils_eq(entry.c3, oldBinding) && (_Utils_eq(entry.en, protocolId) && _Utils_eq(entry.af, intent)));
								},
								model.X),
							fj: 'Previous request remains unconfirmed. Choose a new window action.'
						}),
					_List_Nil);
			case 4:
				return ((!model.m) || $author$project$Effects$pending(model.V)) ? _Utils_Tuple2(model, _List_Nil) : ($author$project$Shell$geometrySupported(model) ? $author$project$Shell$notificationRefresh(model) : $author$project$Shell$refresh(model));
			case 5:
				return ((!model.m) && (!model.aK)) ? _Utils_Tuple2(
					_Utils_update(
						model,
						{fj: 'Reconnecting…', aK: true}),
					_List_fromArray(
						[$author$project$Shell$RestartBackend])) : _Utils_Tuple2(model, _List_Nil);
			case 11:
				var reissue = msg.a;
				if (model.c1 || ((!model.m) || ((model.m === 3) || _Utils_eq(model.c3, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var retired = _Utils_update(
						model,
						{dO: false, y: $elm$core$Maybe$Nothing, dY: $elm$core$Maybe$Nothing, cE: $elm$core$Maybe$Nothing, aD: true, m: 1, aZ: false});
					var attach = model.ar || (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing));
					if (!reissue) {
						return _Utils_Tuple2(retired, _List_Nil);
					} else {
						var _v2 = $author$project$Shell$refreshObservations(retired);
						var fresh = _v2.a;
						var commands = _v2.b;
						var _v3 = attach ? A2($author$project$Shell$geometryRequest, true, fresh) : _Utils_Tuple2(fresh, _List_Nil);
						var attached = _v3.a;
						var attachCommands = _v3.b;
						return _Utils_Tuple2(
							attached,
							_Utils_ap(commands, attachCommands));
					}
				}
			case 13:
				var operations = msg.a;
				var observations = msg.b;
				var matches = F2(
					function (key, entry) {
						return _Utils_eq(entry.c3, key.c3) && (_Utils_eq(entry.en, key.en) && _Utils_eq(entry.af, key.af));
					});
				var keys = A3(
					$elm$core$List$foldl,
					F2(
						function (key, unique) {
							return A2($elm$core$List$member, key, unique) ? unique : A2($elm$core$List$cons, key, unique);
						}),
					_List_Nil,
					operations);
				var proven = A2(
					$elm$core$List$filter,
					function (key) {
						return A2(
							$author$project$Shell$canProveUnsent,
							_List_fromArray(
								[key]),
							model);
					},
					keys);
				var has = F2(
					function (kind, slot) {
						return A2(
							$elm$core$List$any,
							function (_v4) {
								var name = _v4.a;
								var id = _v4.b;
								return _Utils_eq(name, kind) && _Utils_eq(
									slot,
									$elm$core$Maybe$Just(id));
							},
							observations);
					});
				var effects = A3(
					$elm$core$List$foldl,
					F2(
						function (key, state) {
							return A3($author$project$Effects$locallyRefuseUnsent, key.en, key.af, state);
						}),
					model.V,
					proven);
				var retired = _Utils_update(
					model,
					{
						ar: model.ar || A2(has, 'geometry-attach', model.dY),
						dO: false,
						V: effects,
						y: A2(has, 'projection-request', model.y) ? $elm$core$Maybe$Nothing : model.y,
						dY: A2(has, 'geometry-attach', model.dY) ? $elm$core$Maybe$Nothing : model.dY,
						cE: A2(has, 'geometry-facts-request', model.cE) ? $elm$core$Maybe$Nothing : model.cE,
						X: A2(
							$elm$core$List$filter,
							function (entry) {
								return !A2(
									$elm$core$List$any,
									function (key) {
										return A2(matches, key, entry);
									},
									proven);
							},
							model.X),
						fj: 'The request was not sent. Waiting for window transport recovery.',
						aD: true,
						m: ((!model.m) || (model.m === 3)) ? model.m : 1,
						aa: true
					});
				return _Utils_Tuple2(retired, _List_Nil);
			case 14:
				var reissue = msg.a;
				if (!model.aa) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var recovered = _Utils_update(
						model,
						{aa: false});
					return ((!reissue) || ((!recovered.m) || ((recovered.m === 3) || ($author$project$Effects$pending(recovered.V) || ((!_Utils_eq(recovered.y, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(recovered.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(recovered.dY, $elm$core$Maybe$Nothing)))))))) ? _Utils_Tuple2(recovered, _List_Nil) : $author$project$Shell$refreshObservations(recovered);
				}
			case 12:
				var operations = msg.a;
				if (!A2($author$project$Shell$canProveUnsent, operations, model)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var matches = F2(
						function (key, entry) {
							return _Utils_eq(entry.c3, key.c3) && (_Utils_eq(entry.en, key.en) && _Utils_eq(entry.af, key.af));
						});
					var effects = A3(
						$elm$core$List$foldl,
						F2(
							function (key, state) {
								return A3($author$project$Effects$locallyRefuseUnsent, key.en, key.af, state);
							}),
						model.V,
						operations);
					var updated = _Utils_update(
						model,
						{
							V: effects,
							X: A2(
								$elm$core$List$filter,
								function (entry) {
									return !A2(
										$elm$core$List$any,
										function (key) {
											return A2(matches, key, entry);
										},
										operations);
								},
								model.X),
							fj: 'The request was not sent. Choose again.'
						});
					return $author$project$Shell$resumeNotifications(updated);
				}
			case 10:
				var observations = msg.a;
				var valid = A2($author$project$Shell$matchesUnsent, observations, model);
				var contains = function (kind) {
					return A2(
						$elm$core$List$any,
						function (_v7) {
							var name = _v7.a;
							return _Utils_eq(name, kind);
						},
						observations);
				};
				var cleared = _Utils_update(
					model,
					{
						y: contains('projection-request') ? $elm$core$Maybe$Nothing : model.y,
						dY: contains('geometry-attach') ? $elm$core$Maybe$Nothing : model.dY,
						cE: contains('geometry-facts-request') ? $elm$core$Maybe$Nothing : model.cE,
						aD: true
					});
				if ((!valid) || ((!model.m) || (model.m === 3))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					if ($author$project$Effects$pending(model.V) || (model.dO || ((!_Utils_eq(cleared.y, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(cleared.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(cleared.dY, $elm$core$Maybe$Nothing)))))) {
						return _Utils_Tuple2(cleared, _List_Nil);
					} else {
						var _v5 = $author$project$Shell$refreshObservations(cleared);
						var fresh = _v5.a;
						var commands = _v5.b;
						var _v6 = contains('geometry-attach') ? A2($author$project$Shell$geometryRequest, true, fresh) : _Utils_Tuple2(fresh, _List_Nil);
						var attached = _v6.a;
						var attachCommands = _v6.b;
						return _Utils_Tuple2(
							attached,
							_Utils_ap(commands, attachCommands));
					}
				}
			case 6:
				return _Utils_Tuple2(model, _List_Nil);
			case 7:
				return A2($author$project$Shell$geometryRequest, true, model);
			case 8:
				return A2($author$project$Shell$geometryRequest, false, model);
			case 9:
				var stamp = msg.a;
				var operation = msg.b;
				var incarnation = msg.c;
				if (!$author$project$Shell$available(model)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					if (!_Utils_eq(
						($author$project$Effects$protocol(operation) === 2) ? $author$project$Shell$captureGeometry(model) : $author$project$Shell$capture(model),
						$elm$core$Maybe$Just(stamp))) {
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{fj: 'Window list changed. Choose again.'}),
							_List_Nil);
					} else {
						var _v8 = function () {
							if ($author$project$Effects$protocol(operation) === 2) {
								var _v9 = _Utils_Tuple2(model.dc, model.ac);
								if ((!_v9.a.$) && (!_v9.b.$)) {
									var caps = _v9.a.a;
									var observed = _v9.b.a;
									return ((!_Utils_eq(model.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing))) ? _Utils_Tuple3(
										model.V,
										$elm$core$Maybe$Nothing,
										$elm$core$Maybe$Just('Geometry refresh pending')) : A5($author$project$Effects$beginGeometry, caps, observed, operation, incarnation, model.V);
								} else {
									return _Utils_Tuple3(
										model.V,
										$elm$core$Maybe$Nothing,
										$elm$core$Maybe$Just('Geometry observation unavailable'));
								}
							} else {
								return A2(
									$author$project$Effects$apply,
									$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'kind',
												$elm$json$Json$Encode$string('begin')),
												_Utils_Tuple2(
												'operation',
												$elm$json$Json$Encode$string(
													$author$project$Effects$operationName(operation))),
												_Utils_Tuple2(
												'incarnation',
												$elm$json$Json$Encode$string(
													$author$project$UInt64$string(incarnation)))
											])),
									model.V);
							}
						}();
						var effects = _v8.a;
						var command = _v8.b;
						var error = _v8.c;
						var commands = function () {
							var _v11 = _Utils_Tuple2(command, model.c3);
							if ((!_v11.a.$) && (!_v11.b.$)) {
								var value = _v11.a.a;
								var binding = _v11.b.a;
								var _v12 = A2(
									$elm$json$Json$Decode$decodeValue,
									A2($elm$json$Json$Decode$field, 'intent', $elm$json$Json$Decode$value),
									value);
								if (!_v12.$) {
									var intent = _v12.a;
									return _List_fromArray(
										[
											$author$project$Shell$Send(
											$elm$json$Json$Encode$object(
												_List_fromArray(
													[
														_Utils_Tuple2(
														'protocolVersion',
														$elm$json$Json$Encode$int(3)),
														_Utils_Tuple2(
														'kind',
														$elm$json$Json$Encode$string('window-effect')),
														_Utils_Tuple2(
														'effectProtocol',
														$elm$json$Json$Encode$int(
															$author$project$Effects$protocol(operation))),
														_Utils_Tuple2(
														'binding',
														$author$project$Binding$encode(binding)),
														_Utils_Tuple2('intent', intent)
													])))
										]);
								} else {
									return _List_Nil;
								}
							} else {
								return _List_Nil;
							}
						}();
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{
									V: effects,
									X: function () {
										var _v10 = _Utils_Tuple3(command, model.c3, effects.dz);
										if (((!_v10.a.$) && (!_v10.b.$)) && (!_v10.c.$)) {
											var binding = _v10.b.a;
											var transaction = _v10.c.a;
											return A2(
												$elm$core$List$cons,
												{c3: binding, af: transaction.af, en: transaction.az},
												model.X);
										} else {
											return model.X;
										}
									}(),
									fj: A2($elm$core$Maybe$withDefault, model.fj, error)
								}),
							commands);
					}
				}
			default:
				var raw = msg.a;
				var _v13 = A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					raw);
				if (!_v13.$) {
					switch (_v13.a) {
						case 'host-recovery-failed':
							var _v14 = A2(
								$elm$json$Json$Decode$decodeValue,
								A2(
									$author$project$Shell$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'reason']),
									A3(
										$elm$json$Json$Decode$map2,
										F2(
											function (_v15, reason) {
												return reason;
											}),
										$author$project$Shell$version,
										A2($elm$json$Json$Decode$field, 'reason', $author$project$Shell$recoveryDecoder))),
								raw);
							if (!_v14.$) {
								var reason = _v14.a;
								var detached = $author$project$Shell$disconnect(model);
								return _Utils_Tuple2(
									_Utils_update(
										detached,
										{
											fj: $author$project$Shell$recoveryNotice(reason),
											bD: $elm$core$Maybe$Just(reason)
										}),
									_List_Nil);
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'host-disconnected':
							var _v16 = A2(
								$elm$json$Json$Decode$decodeValue,
								A2(
									$author$project$Shell$strict,
									_List_fromArray(
										['protocolVersion', 'kind']),
									$author$project$Shell$version),
								raw);
							if (!_v16.$) {
								return _Utils_Tuple2(
									$author$project$Shell$disconnect(model),
									_List_Nil);
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'host-refresh':
							var _v17 = A2(
								$elm$json$Json$Decode$decodeValue,
								A2(
									$author$project$Shell$strict,
									_List_fromArray(
										['protocolVersion', 'kind']),
									$author$project$Shell$version),
								raw);
							if (!_v17.$) {
								return $author$project$Shell$notificationRefresh(model);
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'application-attached':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'binding', 'nativeOperations']),
								A4(
									$elm$json$Json$Decode$map3,
									F3(
										function (_v19, binding, _v20) {
											return binding;
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2(
										$elm$json$Json$Decode$field,
										'nativeOperations',
										A2(
											$elm$json$Json$Decode$andThen,
											function (operations) {
												return $elm$core$List$isEmpty(operations) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Native operations unavailable');
											},
											$elm$json$Json$Decode$list($elm$json$Json$Decode$string)))));
							var _v18 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (!_v18.$) {
								var binding = _v18.a;
								if ((!(!model.m)) || ((!model.aK) || A2(
									$elm$core$Maybe$withDefault,
									false,
									A2(
										$elm$core$Maybe$map,
										A2(
											$elm$core$Basics$composeR,
											$author$project$Binding$replaces(binding),
											$elm$core$Basics$not),
										model.c3)))) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var detached = $author$project$Shell$disconnect(model);
									return _Utils_Tuple2(
										_Utils_update(
											detached,
											{
												c1: true,
												c3: $elm$core$Maybe$Just(binding),
												fj: 'Applications connected. Window controls unavailable.',
												m: 1,
												aK: false,
												bD: $elm$core$Maybe$Nothing
											}),
										_List_Nil);
								}
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'attached':
							var _v21 = A2(
								$elm$json$Json$Decode$decodeValue,
								A3(
									$elm$json$Json$Decode$map2,
									F2(
										function (_v22, binding) {
											return binding;
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder)),
								raw);
							if (!_v21.$) {
								var binding = _v21.a;
								if ((!(!model.m)) || ((!model.aK) || A2(
									$elm$core$Maybe$withDefault,
									false,
									A2(
										$elm$core$Maybe$map,
										A2(
											$elm$core$Basics$composeR,
											$author$project$Binding$replaces(binding),
											$elm$core$Basics$not),
										model.c3)))) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var detached = $author$project$Shell$disconnect(model);
									return $author$project$Shell$refresh(
										_Utils_update(
											detached,
											{
												c3: $elm$core$Maybe$Just(binding),
												fj: 'Updating window information…',
												m: 1,
												aK: false,
												bD: $elm$core$Maybe$Nothing
											}));
								}
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'projection-unavailable':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'binding', 'requestId', 'reason']),
								A5(
									$elm$json$Json$Decode$map4,
									F4(
										function (_v25, binding, request, _v26) {
											return _Utils_Tuple2(binding, request);
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'requestId', $author$project$Shell$positive),
									A2(
										$elm$json$Json$Decode$andThen,
										function (reason) {
											return (reason === 'scene-changed') ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Projection terminal reason');
										},
										A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$string))));
							var _v23 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (_v23.$ === 1) {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							} else {
								var _v24 = _v23.a;
								var binding = _v24.a;
								var request = _v24.b;
								return ((!model.m) || ((model.m === 3) || ((!_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(binding))) || (!_Utils_eq(
									model.y,
									$elm$core$Maybe$Just(request)))))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Shell$drainNotifications(
									_Utils_update(
										model,
										{y: $elm$core$Maybe$Nothing, aD: true, m: 1, aZ: true}));
							}
						case 'action-projection':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'binding', 'requestId', 'context', 'scene']),
								A6(
									$elm$json$Json$Decode$map5,
									F5(
										function (_v32, binding, request, life, epoch) {
											return _Utils_Tuple3(
												binding,
												request,
												_Utils_Tuple2(life, epoch));
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
									A2(
										$elm$json$Json$Decode$at,
										_List_fromArray(
											['context', 'lifetime']),
										$author$project$UInt64$decoder),
									A2(
										$elm$json$Json$Decode$at,
										_List_fromArray(
											['context', 'epoch']),
										$author$project$UInt64$decoder)));
							var _v27 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (!_v27.$) {
								var _v28 = _v27.a;
								var binding = _v28.a;
								var request = _v28.b;
								var _v29 = _v28.c;
								var life = _v29.a;
								var epoch = _v29.b;
								if ((!model.m) || ((!_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(binding))) || ((!_Utils_eq(
									model.y,
									$elm$core$Maybe$Just(request))) || (!A3($author$project$Binding$matchesContext, life, epoch, binding))))) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var _v30 = A2(
										$elm$json$Json$Decode$decodeValue,
										A3(
											$elm$json$Json$Decode$map2,
											F2(
												function (context, scene) {
													return $elm$json$Json$Encode$object(
														_List_fromArray(
															[
																_Utils_Tuple2(
																'kind',
																$elm$json$Json$Encode$string('snapshot')),
																_Utils_Tuple2('context', context),
																_Utils_Tuple2('scene', scene)
															]));
												}),
											A2($elm$json$Json$Decode$field, 'context', $elm$json$Json$Decode$value),
											A2($elm$json$Json$Decode$field, 'scene', $elm$json$Json$Decode$value)),
										raw);
									if (!_v30.$) {
										var snapshot = _v30.a;
										var _v31 = A2($author$project$Effects$apply, snapshot, model.V);
										var effects = _v31.a;
										var error = _v31.c;
										return (!_Utils_eq(error, $elm$core$Maybe$Nothing)) ? A2($author$project$Shell$rejectEnvelope, raw, model) : $author$project$Shell$drainNotifications(
											_Utils_update(
												model,
												{V: effects, y: $elm$core$Maybe$Nothing, fj: 'Connected', m: 2}));
									} else {
										return A2($author$project$Shell$rejectEnvelope, raw, model);
									}
								}
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'host-geometry-negotiate':
							var _v33 = A2(
								$elm$json$Json$Decode$decodeValue,
								A2(
									$author$project$Shell$strict,
									_List_fromArray(
										['protocolVersion', 'kind']),
									$author$project$Shell$version),
								raw);
							if (_v33.$ === 1) {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							} else {
								return ((!_Utils_eq(model.dc, $elm$core$Maybe$Nothing)) || (!_Utils_eq(model.dY, $elm$core$Maybe$Nothing))) ? _Utils_Tuple2(model, _List_Nil) : A2($author$project$Shell$geometryRequest, true, model);
							}
						case 'geometry-unavailable':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'binding', 'requestId', 'reason']),
								A5(
									$elm$json$Json$Decode$map4,
									F4(
										function (_v35, binding, request, reason) {
											return {c3: binding, ep: reason, cM: request};
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'requestId', $author$project$Shell$positive),
									A2(
										$elm$json$Json$Decode$andThen,
										function (reason) {
											return ($elm$core$String$length(reason) <= 256) ? $elm$json$Json$Decode$succeed(reason) : $elm$json$Json$Decode$fail('Geometry refusal reason');
										},
										A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$string))));
							var _v34 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (_v34.$ === 1) {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							} else {
								var refusal = _v34.a;
								return ((!_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(refusal.c3))) || (!_Utils_eq(
									model.dY,
									$elm$core$Maybe$Just(refusal.cM)))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Shell$drainNotifications(
									_Utils_update(
										model,
										{
											ar: false,
											ac: $elm$core$Maybe$Nothing,
											dY: $elm$core$Maybe$Nothing,
											dc: $elm$core$Maybe$Just(
												{V: false, ef: _List_Nil}),
											cE: $elm$core$Maybe$Nothing
										}));
							}
						case 'geometry-attached':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'geometryProtocol', 'binding', 'requestId', 'capabilities']),
								A6(
									$elm$json$Json$Decode$map5,
									F5(
										function (_v37, _v38, binding, request, caps) {
											return {c3: binding, c6: caps, cM: request};
										}),
									$author$project$Shell$version,
									A2(
										$elm$json$Json$Decode$andThen,
										function (v) {
											return (v === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Geometry protocol');
										},
										A2($elm$json$Json$Decode$field, 'geometryProtocol', $elm$json$Json$Decode$int)),
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'requestId', $author$project$Shell$positive),
									A2($elm$json$Json$Decode$field, 'capabilities', $author$project$GeometryProjection$capabilitiesDecoder)));
							var _v36 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (!_v36.$) {
								var value = _v36.a;
								return ((!_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(value.c3))) || ((!_Utils_eq(
									model.dY,
									$elm$core$Maybe$Just(value.cM))) || (!model.m))) ? _Utils_Tuple2(model, _List_Nil) : A2(
									$author$project$Shell$geometryRequest,
									false,
									_Utils_update(
										model,
										{
											ar: false,
											ac: $elm$core$Maybe$Nothing,
											dY: $elm$core$Maybe$Nothing,
											dc: $elm$core$Maybe$Just(value.c6)
										}));
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'geometry-facts':
							var _v39 = model.dc;
							if (_v39.$ === 1) {
								return A2($author$project$Shell$rejectReason, 'Native geometry facts rejected: no negotiated capabilities.', model);
							} else {
								var caps = _v39.a;
								var _v40 = A2($author$project$GeometryProjection$decode, caps, raw);
								if (_v40.$ === 1) {
									return A2($author$project$Shell$rejectEnvelope, raw, model);
								} else {
									var observed = _v40.a;
									var newer = function () {
										var _v41 = model.ac;
										if (_v41.$ === 1) {
											return true;
										} else {
											var old = _v41.a;
											return (_Utils_eq(old.R.fe, observed.R.fe) && _Utils_eq(old.R.e4, observed.R.e4)) ? ((!(!A2($author$project$UInt64$compare, observed.R.z, old.R.z))) && ((!(!A2($author$project$UInt64$compare, observed.eC, old.eC))) && ((!(!A2($author$project$UInt64$compare, observed.R.cN, old.R.cN))) && ((!_Utils_eq(observed.R.cN, old.R.cN)) || _Utils_eq(
												observed,
												_Utils_update(
													old,
													{cM: observed.cM, eC: observed.eC})))))) : true;
										}
									}();
									return ((!_Utils_eq(
										model.c3,
										$elm$core$Maybe$Just(observed.c3))) || ((!_Utils_eq(
										model.cE,
										$elm$core$Maybe$Just(observed.cM))) || ((!model.m) || (!newer)))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Shell$drainNotifications(
										_Utils_update(
											model,
											{
												ac: $elm$core$Maybe$Just(observed),
												cE: $elm$core$Maybe$Nothing
											}));
								}
							}
						case 'host-recovery-watermarks':
							var decoder = A2(
								$author$project$Shell$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'binding', 'request', 'generation']),
								A5(
									$elm$json$Json$Decode$map4,
									F4(
										function (_v45, binding, request, generation) {
											return _Utils_Tuple3(binding, request, generation);
										}),
									$author$project$Shell$version,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'request', $author$project$UInt64$decoder),
									A2($elm$json$Json$Decode$field, 'generation', $author$project$UInt64$decoder)));
							var _v42 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (!_v42.$) {
								var _v43 = _v42.a;
								var binding = _v43.a;
								var request = _v43.b;
								var generation = _v43.c;
								if ((model.m !== 1) || (!_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(binding)))) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var _v44 = A2(
										$author$project$Effects$apply,
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('recover-watermarks')),
													_Utils_Tuple2(
													'request',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2(
													'generation',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(generation)))
												])),
										model.V);
									var effects = _v44.a;
									return _Utils_Tuple2(
										_Utils_update(
											model,
											{V: effects}),
										_List_Nil);
								}
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'host-uncertain':
							var decoder = $elm$json$Json$Decode$oneOf(
								_List_fromArray(
									[
										A2(
										$author$project$Shell$strict,
										_List_fromArray(
											['protocolVersion', 'kind', 'binding', 'intent']),
										A4(
											$elm$json$Json$Decode$map3,
											F3(
												function (_v50, binding, intent) {
													return _Utils_Tuple3(binding, intent, 1);
												}),
											$author$project$Shell$version,
											A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
											A2($elm$json$Json$Decode$field, 'intent', $elm$json$Json$Decode$value))),
										A2(
										$author$project$Shell$strict,
										_List_fromArray(
											['protocolVersion', 'kind', 'binding', 'intent', 'effectProtocol']),
										A5(
											$elm$json$Json$Decode$map4,
											F4(
												function (_v51, binding, intent, protocolId) {
													return _Utils_Tuple3(binding, intent, protocolId);
												}),
											$author$project$Shell$version,
											A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
											A2($elm$json$Json$Decode$field, 'intent', $elm$json$Json$Decode$value),
											A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int)))
									]));
							var _v46 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
							if (!_v46.$) {
								var _v47 = _v46.a;
								var binding = _v47.a;
								var intent = _v47.b;
								var protocolId = _v47.c;
								var _v48 = A2($elm$json$Json$Decode$decodeValue, $author$project$Effects$intentDecoder, intent);
								if (_v48.$ === 1) {
									return A2($author$project$Shell$rejectEnvelope, raw, model);
								} else {
									if ((!_Utils_eq(
										model.c3,
										$elm$core$Maybe$Just(binding))) || ((model.m !== 1) || (!_Utils_eq(
										A2(
											$elm$core$Result$map,
											function (life) {
												return A2($author$project$Binding$sameLifetime, life, binding);
											},
											A2(
												$elm$json$Json$Decode$decodeValue,
												A2(
													$elm$json$Json$Decode$at,
													_List_fromArray(
														['context', 'lifetime']),
													$author$project$Shell$positive),
												intent)),
										$elm$core$Result$Ok(true))))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var _v49 = A2(
											$author$project$Effects$apply,
											$elm$json$Json$Encode$object(
												_List_fromArray(
													[
														_Utils_Tuple2(
														'kind',
														$elm$json$Json$Encode$string('recover')),
														_Utils_Tuple2('intent', intent),
														_Utils_Tuple2(
														'effectProtocol',
														$elm$json$Json$Encode$int(protocolId))
													])),
											model.V);
										var effects = _v49.a;
										var error = _v49.c;
										return (!_Utils_eq(error, $elm$core$Maybe$Nothing)) ? A2($author$project$Shell$rejectEnvelope, raw, model) : _Utils_Tuple2(
											_Utils_update(
												model,
												{V: effects, fj: 'The previous window change could not be confirmed.'}),
											_List_Nil);
									}
								}
							} else {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							}
						case 'effect-outcome':
							if (!$author$project$NativeOutcome$valid(raw)) {
								return A2($author$project$Shell$rejectEnvelope, raw, model);
							} else {
								var _v52 = A2(
									$elm$json$Json$Decode$decodeValue,
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v53, binding, protocolId, receipt) {
												return _Utils_Tuple3(binding, protocolId, receipt);
											}),
										$author$project$Shell$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int),
										A4(
											$elm$json$Json$Decode$map3,
											F3(
												function (intent, outcome, protocolId) {
													return $elm$json$Json$Encode$object(
														_List_fromArray(
															[
																_Utils_Tuple2(
																'kind',
																$elm$json$Json$Encode$string('receipt')),
																_Utils_Tuple2('intent', intent),
																_Utils_Tuple2('status', outcome),
																_Utils_Tuple2('effectProtocol', protocolId)
															]));
												}),
											A2($elm$json$Json$Decode$field, 'intent', $elm$json$Json$Decode$value),
											A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$value),
											A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$value))),
									raw);
								if (!_v52.$) {
									var _v54 = _v52.a;
									var binding = _v54.a;
									var protocolId = _v54.b;
									var receipt = _v54.c;
									var receivedIntent = $elm$core$Result$toMaybe(
										A2(
											$elm$json$Json$Decode$decodeValue,
											A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
											raw));
									var exact = function (entry) {
										return _Utils_eq(entry.c3, binding) && (_Utils_eq(entry.en, protocolId) && _Utils_eq(
											$elm$core$Maybe$Just(entry.af),
											receivedIntent));
									};
									var known = A2($elm$core$List$any, exact, model.X);
									if (!known) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var retained = _Utils_eq(
											A2(
												$elm$json$Json$Decode$decodeValue,
												A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
												raw),
											$elm$core$Result$Ok('Unknown')) ? model.X : A2(
											$elm$core$List$filter,
											A2($elm$core$Basics$composeR, exact, $elm$core$Basics$not),
											model.X);
										var _v55 = A2($author$project$Effects$apply, receipt, model.V);
										var effects = _v55.a;
										var error = _v55.c;
										if (!_Utils_eq(error, $elm$core$Maybe$Nothing)) {
											return A2($author$project$Shell$rejectEnvelope, raw, model);
										} else {
											var current = function () {
												var _v56 = model.V.dz;
												if (_v56.$ === 1) {
													return false;
												} else {
													var transaction = _v56.a;
													return _Utils_eq(transaction.az, protocolId) && _Utils_eq(
														$elm$core$Maybe$Just(transaction.af),
														receivedIntent);
												}
											}();
											return ((!current) || ((!model.m) || (!_Utils_eq(
												model.c3,
												$elm$core$Maybe$Just(binding))))) ? _Utils_Tuple2(
												_Utils_update(
													model,
													{V: effects, X: retained}),
												_List_Nil) : $author$project$Shell$refreshObservations(
												_Utils_update(
													model,
													{V: effects, X: retained}));
										}
									}
								} else {
									return A2($author$project$Shell$rejectEnvelope, raw, model);
								}
							}
						default:
							return _Utils_Tuple2(model, _List_Nil);
					}
				} else {
					return A2($author$project$Shell$rejectEnvelope, raw, model);
				}
		}
	});
var $author$project$MenuBridge$advancePrepared = F4(
	function (message, previous, shell, model) {
		var state = model;
		var _v0 = state.Q;
		if (_v0.$ === 1) {
			return A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		} else {
			var slot = _v0.a;
			if ((!shell.m) || ((shell.m === 3) || (!_Utils_eq(
				shell.c3,
				$elm$core$Maybe$Just(
					$author$project$Provider$nativeBinding(slot.ax.c)))))) {
				return A3($author$project$MenuBridge$cancelPrepared, 'Selection disconnected or authority changed', shell, model);
			} else {
				var response = function () {
					if (message.$ === 3) {
						var raw = message.a;
						return $elm$core$Result$toMaybe(
							A2(
								$elm$json$Json$Decode$decodeValue,
								A4(
									$elm$json$Json$Decode$map3,
									F3(
										function (kind, _native, request) {
											return _Utils_Tuple3(kind, _native, request);
										}),
									A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder)),
								raw));
					} else {
						return $elm$core$Maybe$Nothing;
					}
				}();
				var legacyReady = slot.bv || (_Utils_eq(
					response,
					$elm$core$Maybe$Just(
						_Utils_Tuple3(
							'action-projection',
							$author$project$Provider$nativeBinding(slot.ax.c),
							slot.bb))) && (_Utils_eq(
					previous.y,
					$elm$core$Maybe$Just(slot.bb)) && _Utils_eq(shell.y, $elm$core$Maybe$Nothing)));
				var geometryReady = slot.bs || function () {
					var _v7 = slot.a8;
					if (_v7.$ === 1) {
						return true;
					} else {
						var request = _v7.a;
						return _Utils_eq(
							response,
							$elm$core$Maybe$Just(
								_Utils_Tuple3(
									'geometry-facts',
									$author$project$Provider$nativeBinding(slot.ax.c),
									request))) && (_Utils_eq(
							previous.cE,
							$elm$core$Maybe$Just(request)) && _Utils_eq(shell.cE, $elm$core$Maybe$Nothing));
					}
				}();
				var lostCorrelation = ((!legacyReady) && (!_Utils_eq(
					shell.y,
					$elm$core$Maybe$Just(slot.bb)))) || ((!geometryReady) && (!_Utils_eq(shell.cE, slot.a8)));
				var updatedSlot = _Utils_update(
					slot,
					{bs: geometryReady, bv: legacyReady});
				var updated = _Utils_update(
					state,
					{
						Q: $elm$core$Maybe$Just(updatedSlot)
					});
				if (lostCorrelation) {
					return A3($author$project$MenuBridge$cancelPrepared, 'Post-close observation correlation changed', shell, updated);
				} else {
					if (!(legacyReady && (geometryReady && $author$project$Shell$available(shell)))) {
						return A4($author$project$MenuBridge$answer, updated, shell, _List_Nil, $elm$core$Maybe$Nothing);
					} else {
						if (!A2($author$project$MenuBridge$compatiblePrepared, updatedSlot, shell)) {
							return A3($author$project$MenuBridge$cancelPrepared, 'Window state changed. Choose again.', shell, updated);
						} else {
							var scope = $author$project$Provider$presentationScope(slot.ax.c);
							var generation = A2(
								$elm$core$Maybe$withDefault,
								$author$project$UInt64$zero,
								A2(
									$elm$core$Maybe$map,
									A2(
										$elm$core$Basics$composeR,
										function ($) {
											return $.R;
										},
										function ($) {
											return $.cN;
										}),
									shell.V.av));
							var _v1 = A3(
								$author$project$NativeProvider$fromShell,
								{e_: generation, dl: scope.dl, ds: scope.ds},
								$author$project$Provider$incarnation(slot.ax.c),
								shell);
							if (_v1.$ === 1) {
								var reason = _v1.a;
								return A3($author$project$MenuBridge$cancelPrepared, reason, shell, updated);
							} else {
								var fresh = _v1.a;
								var _v2 = $author$project$MenuBridge$operation(slot.eV);
								if (_v2.$ === 1) {
									return A3($author$project$MenuBridge$cancelPrepared, 'Selected operation unavailable', shell, updated);
								} else {
									var nativeOperation = _v2.a;
									var stamp = ($author$project$Provider$actionProtocol(slot.eV) === 2) ? $author$project$Shell$captureGeometry(shell) : $author$project$Shell$capture(shell);
									if (stamp.$ === 1) {
										return A3($author$project$MenuBridge$cancelPrepared, 'Fresh native context unavailable', shell, updated);
									} else {
										var current = stamp.a;
										var _v4 = A2(
											$author$project$Shell$update,
											A3(
												$author$project$Shell$Act,
												current,
												nativeOperation,
												$author$project$Provider$incarnation(fresh)),
											shell);
										var issued = _v4.a;
										var commands = _v4.b;
										if ((commands.b && (!commands.a.$)) && (!commands.b.b)) {
											var command = commands.a.a;
											var _v6 = A5($author$project$ReceiptRouter$registerPrepared, slot.c9, slot.ax.c, fresh, command, state.aw);
											if (_v6.$ === 1) {
												var reason = _v6.a;
												return A3($author$project$MenuBridge$cancelPrepared, reason, shell, updated);
											} else {
												var router = _v6.a;
												return A4(
													$author$project$MenuBridge$answer,
													_Utils_update(
														state,
														{Q: $elm$core$Maybe$Nothing, aw: router}),
													_Utils_update(
														issued,
														{dO: false}),
													commands,
													$elm$core$Maybe$Nothing);
											}
										} else {
											return A3($author$project$MenuBridge$cancelPrepared, 'Native operation unavailable', shell, updated);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	});
var $author$project$Menu$markDisconnected = function (_v0) {
	var state = _v0;
	return _Utils_update(
		state,
		{
			aC: A2(
				$elm$core$Maybe$map,
				function (menu) {
					var _v1 = menu.O;
					if (_v1.$ === 1) {
						var intent = _v1.a;
						return _Utils_update(
							menu,
							{
								O: $author$project$Menu$Unknown(intent)
							});
					} else {
						return menu;
					}
				},
				state.aC),
			fn: A2(
				$elm$core$List$map,
				function (entry) {
					return _Utils_update(
						entry,
						{bk: true});
				},
				state.fn)
		});
};
var $author$project$MenuBridge$connectionLost = function (_v0) {
	var state = _v0;
	var canceled = function () {
		var _v2 = state.Q;
		if (_v2.$ === 1) {
			return state.aC;
		} else {
			var slot = _v2.a;
			return A2(
				$author$project$Menu$update,
				A3(
					$author$project$Menu$ReceiveFor,
					slot.ch,
					slot.bU,
					$author$project$Menu$Refusal('Connection lost before dispatch')),
				state.aC).a;
		}
	}();
	var uncertain = $author$project$Menu$markDisconnected(canceled);
	var closed = function () {
		var _v1 = $author$project$Menu$snapshot(uncertain).aC;
		if (_v1.$ === 1) {
			return uncertain;
		} else {
			var view = _v1.a;
			return A2(
				$author$project$Menu$update,
				$author$project$Menu$Dismiss(view.cc),
				uncertain).a;
		}
	}();
	return _Utils_update(
		state,
		{aC: closed, Q: $elm$core$Maybe$Nothing});
};
var $author$project$MenuBridge$guardedAct = F5(
	function (stamp, action, incarnation, shell, model) {
		var blocked = A3($author$project$MenuBridge$blockedFor, incarnation, shell, model);
		if (blocked || (!_Utils_eq(
			$author$project$MenuBridge$preparedSnapshot(model),
			$elm$core$Maybe$Nothing))) {
			return _Utils_Tuple3(
				shell,
				_List_Nil,
				$elm$core$Maybe$Just('A menu operation for this window family awaits reconciliation'));
		} else {
			var _v0 = A2(
				$author$project$Shell$update,
				A3($author$project$Shell$Act, stamp, action, incarnation),
				shell);
			var next = _v0.a;
			var effects = _v0.b;
			return _Utils_Tuple3(
				next,
				effects,
				$elm$core$List$isEmpty(effects) ? $elm$core$Maybe$Just('Native operation unavailable') : $elm$core$Maybe$Nothing);
		}
	});
var $author$project$UnsentOperation$encodeCommand = function (key) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'protocolVersion',
				$elm$json$Json$Encode$int(3)),
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('window-effect')),
				_Utils_Tuple2(
				'effectProtocol',
				$elm$json$Json$Encode$int(key.en)),
				_Utils_Tuple2(
				'binding',
				$author$project$Binding$encode(key.c3)),
				_Utils_Tuple2(
				'intent',
				$author$project$Effects$encodeIntent(key.af))
			]));
};
var $author$project$ReceiptRouter$locallyRefuseUnsent = F2(
	function (proved, model) {
		var entries = model;
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			$author$project$ReceiptRouter$command,
			$author$project$UnsentOperation$encodeCommand(proved));
		if (_v0.$ === 1) {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		} else {
			var _native = _v0.a;
			var _v1 = $elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (entry) {
						return _Utils_eq(entry.aV, _native);
					},
					entries));
			if (_v1.$ === 1) {
				return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
			} else {
				var entry = _v1.a;
				return _Utils_Tuple2(
					A2(
						$elm$core$List$filter,
						function (item) {
							return !_Utils_eq(item.aV, _native);
						},
						entries),
					$elm$core$Maybe$Just(
						A3(
							$author$project$Menu$ReceiveFor,
							entry.ch,
							entry.c3,
							$author$project$Menu$Refusal('The request was not sent. Choose again.'))));
			}
		}
	});
var $author$project$MenuBridge$locallyRefuseUnsent = F2(
	function (proved, model) {
		var state = model;
		var _v0 = A2($author$project$ReceiptRouter$locallyRefuseUnsent, proved, state.aw);
		var router = _v0.a;
		var message = _v0.b;
		if (message.$ === 1) {
			return model;
		} else {
			var receipt = message.a;
			var _v2 = A2($author$project$Menu$update, receipt, state.aC);
			var menu = _v2.a;
			return _Utils_update(
				state,
				{aC: menu, aw: router});
		}
	});
var $elm$json$Json$Decode$decodeString = _Json_runOnString;
var $author$project$Menu$Cancellation = {$: 2};
var $author$project$Menu$Committed = {$: 0};
var $author$project$ReceiptRouter$receipt = A2(
	$author$project$ReceiptRouter$strict,
	_List_fromArray(
		['protocolVersion', 'kind', 'effectProtocol', 'binding', 'intent', 'status', 'reason', 'revision', 'outputGeneration']),
	A9(
		$elm$json$Json$Decode$map8,
		F8(
			function (_v0, _v1, _v2, _native, status, reason, _v3, _v4) {
				return _Utils_Tuple2(
					_native,
					function () {
						switch (status) {
							case 'Committed':
								return $author$project$Menu$Committed;
							case 'Refused':
								return $author$project$Menu$Refusal(reason);
							case 'Cancelled':
								return $author$project$Menu$Cancellation;
							default:
								return $author$project$Menu$Uncertain;
						}
					}());
			}),
		$author$project$ReceiptRouter$version,
		$author$project$ReceiptRouter$kind('effect-outcome'),
		$author$project$ReceiptRouter$effectVersion,
		$author$project$ReceiptRouter$key,
		A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return A2(
					$elm$core$List$member,
					value,
					_List_fromArray(
						['Committed', 'Refused', 'Cancelled', 'Unknown'])) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native outcome');
			},
			A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string)),
		A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return ($elm$core$String$length(value) <= 256) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Native reason bound');
			},
			A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$string)),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$ReceiptRouter$positive),
		A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$ReceiptRouter$positive)));
var $author$project$ReceiptRouter$utf8Bytes = A2(
	$elm$core$String$foldl,
	F2(
		function (character, total) {
			var code = $elm$core$Char$toCode(character);
			return total + ((code <= 127) ? 1 : ((code <= 2047) ? 2 : ((code <= 65535) ? 3 : 4)));
		}),
	0);
var $author$project$ReceiptRouter$accept = F2(
	function (raw, model) {
		var entries = model;
		if (($elm$core$String$length(raw) > 16384) || ($author$project$ReceiptRouter$utf8Bytes(raw) > 16384)) {
			return _Utils_Tuple3(
				model,
				$elm$core$Maybe$Nothing,
				$elm$core$Maybe$Just('Native receipt byte bound'));
		} else {
			var _v0 = A2($elm$json$Json$Decode$decodeString, $author$project$ReceiptRouter$receipt, raw);
			if (_v0.$ === 1) {
				var error = _v0.a;
				return _Utils_Tuple3(
					model,
					$elm$core$Maybe$Nothing,
					$elm$core$Maybe$Just(
						$author$project$ReceiptRouter$safeError(error)));
			} else {
				var _v1 = _v0.a;
				var _native = _v1.a;
				var outcome = _v1.b;
				var _v2 = $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (entry) {
							return _Utils_eq(entry.aV, _native);
						},
						entries));
				if (_v2.$ === 1) {
					return _Utils_Tuple3(
						model,
						$elm$core$Maybe$Nothing,
						$elm$core$Maybe$Just('Unknown or mismatched native receipt'));
				} else {
					var entry = _v2.a;
					var next = _Utils_eq(outcome, $author$project$Menu$Uncertain) ? model : A2(
						$elm$core$List$filter,
						function (item) {
							return !_Utils_eq(item.ch, entry.ch);
						},
						entries);
					return _Utils_Tuple3(
						next,
						$elm$core$Maybe$Just(
							A3($author$project$Menu$ReceiveFor, entry.ch, entry.c3, outcome)),
						$elm$core$Maybe$Nothing);
				}
			}
		}
	});
var $author$project$MenuBridge$nativeFrame = F2(
	function (raw, model) {
		var state = model;
		var _v0 = A2(
			$elm$json$Json$Decode$decodeString,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			raw);
		if (_v0.$ === 1) {
			return _Utils_Tuple2(
				model,
				$elm$core$Maybe$Just('Invalid native frame'));
		} else {
			switch (_v0.a) {
				case 'host-disconnected':
					return _Utils_Tuple2(
						$author$project$MenuBridge$connectionLost(model),
						$elm$core$Maybe$Nothing);
				case 'effect-outcome':
					var _v1 = A2($author$project$ReceiptRouter$accept, raw, state.aw);
					var router = _v1.a;
					var receipt = _v1.b;
					var error = _v1.c;
					if (receipt.$ === 1) {
						return _Utils_Tuple2(model, error);
					} else {
						var message = receipt.a;
						var _v3 = A2($author$project$Menu$update, message, state.aC);
						var menu = _v3.a;
						return _Utils_Tuple2(
							_Utils_update(
								state,
								{aC: menu, aw: router}),
							error);
					}
				default:
					return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
			}
		}
	});
var $author$project$Shell$stampDecoder = A2(
	$author$project$Shell$strict,
	_List_fromArray(
		['binding', 'output', 'revision']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$Shell$Stamp,
		A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
		A2($elm$json$Json$Decode$field, 'output', $author$project$Shell$positive),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$Shell$positive)));
var $author$project$MenuBridge$providerStamp = function (provider) {
	var context = $author$project$Provider$nativeContext(provider);
	return A2(
		$elm$core$Result$mapError,
		function (_v0) {
			return 'Invalid native menu stamp';
		},
		A2(
			$elm$json$Json$Decode$decodeValue,
			$author$project$Shell$stampDecoder,
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(
							$author$project$Provider$nativeBinding(provider))),
						_Utils_Tuple2(
						'output',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(context.z))),
						_Utils_Tuple2(
						'revision',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(context.cN)))
					]))));
};
var $author$project$Menu$rebindReady = F5(
	function (id, previous, fresh, items, model) {
		var state = model;
		var _v0 = state.aC;
		if (!_v0.$) {
			var current = _v0.a;
			return (state.aA || ((!_Utils_eq(current.cc, id)) || ((!_Utils_eq(current.c3, previous)) || ((!_Utils_eq(current.O, $author$project$Menu$Ready)) || ((!_Utils_eq(current.fd, items)) || ((!$author$project$Menu$validItems(items)) || ((!A2($author$project$Menu$sameTarget, previous, fresh)) || ((!_Utils_eq(
				$author$project$Menu$outputTuple(previous),
				$author$project$Menu$outputTuple(fresh))) || (A2($elm$core$List$member, fresh, state.aT) || (A2(
				$elm$core$List$member,
				$author$project$Menu$outputTuple(fresh),
				state.a_) || A2(
				$elm$core$List$any,
				function (entry) {
					return A2($author$project$Menu$sameTarget, entry.c3, fresh);
				},
				state.fn))))))))))) ? model : _Utils_update(
				state,
				{
					aC: $elm$core$Maybe$Just(
						_Utils_update(
							current,
							{c3: fresh}))
				});
		} else {
			return model;
		}
	});
var $author$project$Provider$title = function (_v0) {
	var value = _v0;
	return value.eI;
};
var $author$project$MenuBridge$reconcileWithShell = F2(
	function (shell, model) {
		var state = model;
		if (!shell.m) {
			return $author$project$MenuBridge$connectionLost(model);
		} else {
			if (!_Utils_eq(state.Q, $elm$core$Maybe$Nothing)) {
				return model;
			} else {
				var _v0 = state.bB;
				if (_v0.$ === 1) {
					return model;
				} else {
					var captured = _v0.a;
					var _v1 = shell.V.av;
					if (_v1.$ === 1) {
						return model;
					} else {
						var observed = _v1.a;
						var retired = function () {
							var _v8 = A2(
								$author$project$Menu$update,
								$author$project$Menu$Invalidate(
									$author$project$Provider$getBinding(captured.c)),
								state.aC);
							var menu = _v8.a;
							return _Utils_update(
								state,
								{aC: menu});
						}();
						var previous = $author$project$Provider$nativeContext(captured.c);
						var sameAuthority = _Utils_eq(
							shell.c3,
							$elm$core$Maybe$Just(
								$author$project$Provider$nativeBinding(captured.c))) && (_Utils_eq(observed.R.fe, previous.fe) && (_Utils_eq(observed.R.e4, previous.e4) && _Utils_eq(observed.R.z, previous.z)));
						var liveRoot = _Utils_eq(
							A2(
								$author$project$ActionProjection$rootOf,
								$author$project$Provider$incarnation(captured.c),
								observed.eA),
							$elm$core$Maybe$Just(
								$author$project$Provider$incarnation(captured.c)));
						var changed = (!_Utils_eq(observed.R, previous)) || ((!sameAuthority) || ((!liveRoot) || (!_Utils_eq(
							A2(
								$elm$core$Maybe$map,
								function ($) {
									return $.R;
								},
								$author$project$Provider$geometryObservation(captured.c)),
							_Utils_eq(
								$author$project$Provider$geometryObservation(captured.c),
								$elm$core$Maybe$Nothing) ? $elm$core$Maybe$Nothing : A2(
								$elm$core$Maybe$map,
								function ($) {
									return $.R;
								},
								shell.ac)))));
						if (!changed) {
							return model;
						} else {
							var _v2 = $author$project$Menu$snapshot(state.aC).aC;
							if (!_v2.$) {
								var view = _v2.a;
								if ((!_Utils_eq(view.O, $author$project$Menu$Ready)) || ((!sameAuthority) || (!liveRoot))) {
									return retired;
								} else {
									if ((!_Utils_eq(shell.y, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(shell.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(shell.dY, $elm$core$Maybe$Nothing)))) {
										return model;
									} else {
										if (!$author$project$Shell$available(shell)) {
											return retired;
										} else {
											var scope = $author$project$Provider$presentationScope(captured.c);
											var sameGeometry = function (fresh) {
												var _v5 = _Utils_Tuple2(
													$author$project$Provider$geometryObservation(captured.c),
													$author$project$Provider$geometryObservation(fresh));
												_v5$2:
												while (true) {
													if (_v5.a.$ === 1) {
														if (_v5.b.$ === 1) {
															var _v6 = _v5.a;
															var _v7 = _v5.b;
															return true;
														} else {
															break _v5$2;
														}
													} else {
														if (!_v5.b.$) {
															var previousFacts = _v5.a.a;
															var currentFacts = _v5.b.a;
															return A2($author$project$MenuBridge$sameWindowFacts, previousFacts.a, currentFacts.a) && (_Utils_eq(previousFacts.c3, currentFacts.c3) && (_Utils_eq(previousFacts.R.fe, currentFacts.R.fe) && (_Utils_eq(previousFacts.R.e4, currentFacts.R.e4) && _Utils_eq(previousFacts.R.z, currentFacts.R.z))));
														} else {
															break _v5$2;
														}
													}
												}
												return false;
											};
											var _v3 = A3(
												$author$project$NativeProvider$fromShell,
												{e_: observed.R.cN, dl: scope.dl, ds: scope.ds},
												$author$project$Provider$incarnation(captured.c),
												shell);
											if (_v3.$ === 1) {
												return retired;
											} else {
												var fresh = _v3.a;
												if ((!_Utils_eq(
													$author$project$Provider$getItems(fresh),
													$author$project$Provider$getItems(captured.c))) || ((!_Utils_eq(
													$author$project$Provider$title(fresh),
													$author$project$Provider$title(captured.c))) || (!sameGeometry(fresh)))) {
													return retired;
												} else {
													var _v4 = $author$project$MenuBridge$providerStamp(fresh);
													if (_v4.$ === 1) {
														return retired;
													} else {
														var stamp = _v4.a;
														var refreshed = A5(
															$author$project$Menu$rebindReady,
															view.cc,
															view.c3,
															$author$project$Provider$getBinding(fresh),
															$author$project$Provider$getItems(fresh),
															state.aC);
														return (!_Utils_eq(
															A2(
																$elm$core$Maybe$map,
																function ($) {
																	return $.c3;
																},
																$author$project$Menu$snapshot(refreshed).aC),
															$elm$core$Maybe$Just(
																$author$project$Provider$getBinding(fresh)))) ? retired : _Utils_update(
															state,
															{
																aC: refreshed,
																bB: $elm$core$Maybe$Just(
																	{c: fresh, cW: stamp})
															});
													}
												}
											}
										}
									}
								}
							} else {
								return retired;
							}
						}
					}
				}
			}
		}
	});
var $author$project$TaskbarShell$native = F2(
	function (message, model) {
		var menus = function () {
			switch (message.$) {
				case 3:
					var raw = message.a;
					var _v4 = A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
						raw);
					_v4$2:
					while (true) {
						if (!_v4.$) {
							switch (_v4.a) {
								case 'effect-outcome':
									return $author$project$NativeOutcome$valid(raw) ? A2(
										$author$project$MenuBridge$nativeFrame,
										A2($elm$json$Json$Encode$encode, 0, raw),
										model.i).a : model.i;
								case 'host-disconnected':
									return $author$project$MenuBridge$connectionLost(model.i);
								default:
									break _v4$2;
							}
						} else {
							break _v4$2;
						}
					}
					return model.i;
				case 13:
					var operations = message.a;
					return A3(
						$elm$core$List$foldl,
						F2(
							function (key, menusSoFar) {
								return A2(
									$author$project$Shell$canProveUnsent,
									_List_fromArray(
										[key]),
									model.b) ? A2($author$project$MenuBridge$locallyRefuseUnsent, key, menusSoFar) : menusSoFar;
							}),
						model.i,
						operations);
				case 12:
					var operations = message.a;
					return A2($author$project$Shell$canProveUnsent, operations, model.b) ? A3($elm$core$List$foldl, $author$project$MenuBridge$locallyRefuseUnsent, model.i, operations) : model.i;
				default:
					return model.i;
			}
		}();
		var _v0 = function () {
			switch (message.$) {
				case 9:
					var scope = message.a;
					var operation = message.b;
					var target = message.c;
					var _v2 = A5($author$project$MenuBridge$guardedAct, scope, operation, target, model.b, menus);
					var next = _v2.a;
					var emitted = _v2.b;
					var error = _v2.c;
					return _Utils_Tuple2(
						_Utils_update(
							next,
							{
								fj: A2($elm$core$Maybe$withDefault, next.fj, error)
							}),
						emitted);
				case 3:
					var raw = message.a;
					return (_Utils_eq(
						A2(
							$elm$json$Json$Decode$decodeValue,
							A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
							raw),
						$elm$core$Result$Ok('effect-outcome')) && (!$author$project$NativeOutcome$valid(raw))) ? _Utils_Tuple2(model.b, _List_Nil) : A2($author$project$Shell$update, message, model.b);
				default:
					return A2($author$project$Shell$update, message, model.b);
			}
		}();
		var shell = _v0.a;
		var effects = _v0.b;
		var advanced = A4($author$project$MenuBridge$advancePrepared, message, model.b, shell, menus);
		var finalShell = advanced.b;
		var settledMenus = A2($author$project$MenuBridge$reconcileWithShell, advanced.b, advanced.dI);
		var picker = A2(
			$elm$core$Maybe$andThen,
			function (current) {
				return (_Utils_eq(
					$author$project$Shell$capture(shell),
					$elm$core$Maybe$Just(current.cQ)) && $author$project$Shell$available(shell)) ? $elm$core$Maybe$Just(current) : $elm$core$Maybe$Nothing;
			},
			model.G);
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{
					i: settledMenus,
					G: picker,
					b: _Utils_update(
						finalShell,
						{
							fj: A2($elm$core$Maybe$withDefault, finalShell.fj, advanced.dR)
						})
				}),
			_Utils_ap(effects, advanced.V));
	});
var $author$project$TaskbarShell$apply = F3(
	function (scope, decision, model) {
		if (decision.$ === 2) {
			var operation = decision.a;
			var root = decision.b;
			return A2(
				$author$project$TaskbarShell$native,
				A3($author$project$Shell$Act, scope, operation, root),
				_Utils_update(
					model,
					{G: $elm$core$Maybe$Nothing}));
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	});
var $author$project$MenuBridge$cancelSelection = F3(
	function (token, shell, model) {
		var state = model;
		var _v0 = state.Q;
		if (!_v0.$) {
			var slot = _v0.a;
			return _Utils_eq(slot.bj, token) ? A3($author$project$MenuBridge$cancelPrepared, 'Selection canceled before dispatch', shell, model) : A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		} else {
			return A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$Shell$ArmPrepared = function (a) {
	return {$: 2, a: a};
};
var $author$project$MenuBridge$providerMatches = F2(
	function (captured, shell) {
		return _Utils_eq(
			shell.c3,
			$elm$core$Maybe$Just(
				$author$project$Provider$nativeBinding(captured.c))) && (_Utils_eq(
			$author$project$Shell$capture(shell),
			$elm$core$Maybe$Just(captured.cW)) && (_Utils_eq(
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.R;
				},
				$author$project$Provider$geometryObservation(captured.c)),
			_Utils_eq(
				$author$project$Provider$geometryObservation(captured.c),
				$elm$core$Maybe$Nothing) ? $elm$core$Maybe$Nothing : A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.R;
				},
				shell.ac)) && (_Utils_eq(
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.R;
				},
				shell.V.av),
			$elm$core$Maybe$Just(
				$author$project$Provider$nativeContext(captured.c))) && _Utils_eq(
			A2(
				$elm$core$Maybe$andThen,
				function (observed) {
					return A2(
						$author$project$ActionProjection$rootOf,
						$author$project$Provider$incarnation(captured.c),
						observed.eA);
				},
				shell.V.av),
			$elm$core$Maybe$Just(
				$author$project$Provider$incarnation(captured.c))))));
	});
var $author$project$MenuBridge$menuEvent = F3(
	function (message, shell, model) {
		var state = model;
		switch (message.$) {
			case 4:
				return A4(
					$author$project$MenuBridge$answer,
					model,
					shell,
					_List_Nil,
					$elm$core$Maybe$Just('Native outcomes require an authenticated frame'));
			case 0:
				return A4(
					$author$project$MenuBridge$answer,
					model,
					shell,
					_List_Nil,
					$elm$core$Maybe$Just('Menu opening requires a validated provider'));
			case 5:
				var id = message.a;
				var _v1 = state.Q;
				if (!_v1.$) {
					var slot = _v1.a;
					return _Utils_eq(slot.dg, id) ? A3($author$project$MenuBridge$cancelPrepared, 'Selection canceled before dispatch', shell, model) : A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
				} else {
					return A4(
						$author$project$MenuBridge$answer,
						_Utils_update(
							state,
							{
								aC: A2($author$project$Menu$update, message, state.aC).a
							}),
						shell,
						_List_Nil,
						$elm$core$Maybe$Nothing);
				}
			case 6:
				var binding = message.a;
				var _v2 = state.Q;
				if (!_v2.$) {
					var slot = _v2.a;
					return _Utils_eq(slot.bU, binding) ? A3($author$project$MenuBridge$cancelPrepared, 'Selection authority retired', shell, model) : A4(
						$author$project$MenuBridge$answer,
						_Utils_update(
							state,
							{
								aC: A2($author$project$Menu$update, message, state.aC).a
							}),
						shell,
						_List_Nil,
						$elm$core$Maybe$Nothing);
				} else {
					return A4(
						$author$project$MenuBridge$answer,
						_Utils_update(
							state,
							{
								aC: A2($author$project$Menu$update, message, state.aC).a
							}),
						shell,
						_List_Nil,
						$elm$core$Maybe$Nothing);
				}
			case 7:
				var output = message.a;
				var generation = message.b;
				var _v3 = state.Q;
				if (!_v3.$) {
					var slot = _v3.a;
					return (_Utils_eq(
						$author$project$Menu$outputId(
							$author$project$UInt64$string(
								$author$project$Provider$presentationScope(slot.ax.c).dl)),
						output) && _Utils_eq(
						$author$project$UInt64$string(
							$author$project$Provider$nativeContext(slot.ax.c).z),
						generation)) ? A3($author$project$MenuBridge$cancelPrepared, 'Selection output retired', shell, model) : A4(
						$author$project$MenuBridge$answer,
						_Utils_update(
							state,
							{
								aC: A2($author$project$Menu$update, message, state.aC).a
							}),
						shell,
						_List_Nil,
						$elm$core$Maybe$Nothing);
				} else {
					return A4(
						$author$project$MenuBridge$answer,
						_Utils_update(
							state,
							{
								aC: A2($author$project$Menu$update, message, state.aC).a
							}),
						shell,
						_List_Nil,
						$elm$core$Maybe$Nothing);
				}
			default:
				var preblocked = function () {
					var _v12 = _Utils_Tuple2(message, state.bB);
					if ((_v12.a.$ === 3) && (!_v12.b.$)) {
						var _v13 = _v12.a;
						var captured = _v12.b.a;
						return A3(
							$author$project$MenuBridge$blockedFor,
							$author$project$Provider$incarnation(captured.c),
							shell,
							model);
					} else {
						return false;
					}
				}();
				var _v4 = A2($author$project$Menu$update, message, state.aC);
				var menu = _v4.a;
				var effects = _v4.b;
				var updated = _Utils_update(
					state,
					{aC: menu});
				if (preblocked) {
					return A4(
						$author$project$MenuBridge$answer,
						model,
						shell,
						_List_Nil,
						$elm$core$Maybe$Just('A menu operation for this window family awaits reconciliation'));
				} else {
					if (effects.b) {
						if (!effects.b.b) {
							var dispatch = effects.a;
							var local = dispatch.a;
							var binding = dispatch.b;
							var action = dispatch.c;
							var rejected = function (reason) {
								return A4(
									$author$project$MenuBridge$answer,
									A4($author$project$MenuBridge$refuse, local, binding, reason, updated),
									shell,
									_List_Nil,
									$elm$core$Maybe$Just(reason));
							};
							var _v6 = _Utils_Tuple2(
								state.bB,
								$author$project$MenuBridge$operation(action));
							if ((!_v6.a.$) && (!_v6.b.$)) {
								var captured = _v6.a.a;
								if ((!_Utils_eq(
									$author$project$Provider$getBinding(captured.c),
									binding)) || ((!A2($author$project$MenuBridge$providerMatches, captured, shell)) || (($author$project$Provider$actionProtocol(action) === 2) && ((!_Utils_eq(shell.cE, $elm$core$Maybe$Nothing)) || (!_Utils_eq(shell.dY, $elm$core$Maybe$Nothing)))))) {
									return rejected('Native window information changed; choose again');
								} else {
									var _v7 = _Utils_Tuple3(
										state.Q,
										$author$project$UInt64$next(state.dq),
										_Utils_Tuple2(
											$author$project$Menu$snapshot(state.aC).aC,
											shell.V.av));
									if ((((_v7.a.$ === 1) && (!_v7.b.$)) && (!_v7.c.a.$)) && (!_v7.c.b.$)) {
										var _v8 = _v7.a;
										var token = _v7.b.a;
										var _v9 = _v7.c;
										var view = _v9.a.a;
										var observed = _v9.b.a;
										var needsGeometry = !_Utils_eq(
											$author$project$Provider$geometryObservation(captured.c),
											$elm$core$Maybe$Nothing);
										var closed = A2(
											$author$project$Menu$update,
											$author$project$Menu$Dismiss(view.cc),
											menu).a;
										var _v10 = A2($author$project$Shell$update, $author$project$Shell$Refresh, shell);
										var refreshing = _v10.a;
										var requests = _v10.b;
										var _v11 = refreshing.y;
										if (_v11.$ === 1) {
											return rejected('Post-close window observation unavailable');
										} else {
											var legacyRequest = _v11.a;
											if ($elm$core$List$isEmpty(requests) || (needsGeometry && _Utils_eq(refreshing.cE, $elm$core$Maybe$Nothing))) {
												return rejected('Post-close geometry observation unavailable');
											} else {
												var slot = {
													eV: action,
													ax: captured,
													c9: dispatch,
													dc: shell.dc,
													bs: !needsGeometry,
													a8: refreshing.cE,
													bv: false,
													bb: legacyRequest,
													df: $author$project$ActionProjection$windows(observed.eA),
													ch: local,
													dg: view.cc,
													bU: binding,
													bj: token
												};
												return A4(
													$author$project$MenuBridge$answer,
													_Utils_update(
														state,
														{
															aC: closed,
															Q: $elm$core$Maybe$Just(slot),
															dq: token
														}),
													_Utils_update(
														refreshing,
														{dO: true}),
													_Utils_ap(
														requests,
														_List_fromArray(
															[
																$author$project$Shell$ArmPrepared(token)
															])),
													$elm$core$Maybe$Nothing);
											}
										}
									} else {
										return rejected('A prepared selection is already pending or exhausted');
									}
								}
							} else {
								return rejected('Menu operation unavailable');
							}
						} else {
							return A4(
								$author$project$MenuBridge$answer,
								model,
								shell,
								_List_Nil,
								$elm$core$Maybe$Just('Invalid menu dispatch count'));
						}
					} else {
						return A4($author$project$MenuBridge$answer, updated, shell, _List_Nil, $elm$core$Maybe$Nothing);
					}
				}
		}
	});
var $author$project$TaskbarShell$dismissMenus = function (model) {
	var _v0 = $author$project$MenuBridge$menuSnapshot(model.i).aC;
	if (_v0.$ === 1) {
		return model;
	} else {
		var view = _v0.a;
		var result = A3(
			$author$project$MenuBridge$menuEvent,
			$author$project$Menu$Dismiss(view.cc),
			model.b,
			model.i);
		return _Utils_update(
			model,
			{i: result.dI});
	}
};
var $author$project$MenuBridge$expirePrepared = F3(
	function (token, shell, model) {
		var state = model;
		var _v0 = state.Q;
		if (!_v0.$) {
			var slot = _v0.a;
			return _Utils_eq(slot.bj, token) ? A3($author$project$MenuBridge$cancelPrepared, 'Window information took too long. Choose again.', shell, model) : A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		} else {
			return A4($author$project$MenuBridge$answer, model, shell, _List_Nil, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$Menu$Open = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$Provider$toOpen = function (_v0) {
	var value = _v0;
	return A2($author$project$Menu$Open, value.c3, value.fd);
};
var $author$project$MenuBridge$open = F2(
	function (provider, model) {
		var state = model;
		if (!_Utils_eq(state.Q, $elm$core$Maybe$Nothing)) {
			return model;
		} else {
			var _v0 = $author$project$MenuBridge$providerStamp(provider);
			if (_v0.$ === 1) {
				return model;
			} else {
				var stamp = _v0.a;
				var before = $author$project$Menu$snapshot(state.aC);
				var _v1 = A2(
					$author$project$Menu$update,
					$author$project$Provider$toOpen(provider),
					state.aC);
				var menu = _v1.a;
				return _Utils_eq(
					$author$project$Menu$snapshot(menu).aC,
					before.aC) ? model : _Utils_update(
					state,
					{
						aC: menu,
						bB: $elm$core$Maybe$Just(
							{c: provider, cW: stamp})
					});
			}
		}
	});
var $author$project$Taskbar$selection = function (entry) {
	return (!entry.c2) ? $author$project$Taskbar$Unavailable : A2(
		$author$project$Taskbar$Apply,
		entry.bR ? $author$project$Effects$Restore : $author$project$Effects$Activate,
		entry.n);
};
var $author$project$TaskbarShell$valid = F2(
	function (scope, model) {
		return _Utils_eq(
			$author$project$MenuBridge$preparedSnapshot(model.i),
			$elm$core$Maybe$Nothing) && (_Utils_eq(
			$author$project$Shell$capture(model.b),
			$elm$core$Maybe$Just(scope)) && $author$project$Shell$available(model.b));
	});
var $author$project$TaskbarShell$update = F2(
	function (message, model) {
		switch (message.$) {
			case 4:
				var provider = message.a;
				var menus = A2($author$project$MenuBridge$open, provider, model.i);
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							i: menus,
							G: _Utils_eq(menus, model.i) ? model.G : $elm$core$Maybe$Nothing
						}),
					_List_Nil);
			case 5:
				var event = message.a;
				var result = A3($author$project$MenuBridge$menuEvent, event, model.b, model.i);
				var shell = result.b;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							i: result.dI,
							G: $elm$core$List$isEmpty(result.V) ? model.G : $elm$core$Maybe$Nothing,
							b: _Utils_update(
								shell,
								{
									fj: A2($elm$core$Maybe$withDefault, shell.fj, result.dR)
								})
						}),
					result.V);
			case 7:
				var token = message.a;
				var result = A3($author$project$MenuBridge$cancelSelection, token, model.b, model.i);
				var shell = result.b;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							i: result.dI,
							b: _Utils_update(
								shell,
								{
									fj: A2($elm$core$Maybe$withDefault, shell.fj, result.dR)
								})
						}),
					result.V);
			case 6:
				var token = message.a;
				var result = A3($author$project$MenuBridge$expirePrepared, token, model.b, model.i);
				var shell = result.b;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							i: result.dI,
							b: _Utils_update(
								shell,
								{
									fj: A2($elm$core$Maybe$withDefault, shell.fj, result.dR)
								})
						}),
					result.V);
			case 0:
				var value = message.a;
				return A2($author$project$TaskbarShell$native, value, model);
			case 1:
				var scope = message.a;
				var key = message.b;
				if (!A2($author$project$TaskbarShell$valid, scope, model)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v1 = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (group) {
								return _Utils_eq(group.aV, key);
							},
							$author$project$TaskbarShell$groups(model)));
					if (_v1.$ === 1) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var group = _v1.a;
						var base = $author$project$TaskbarShell$dismissMenus(model);
						var _v2 = A2($author$project$Taskbar$primary, false, group.aB);
						if (_v2.$ === 1) {
							var _v3 = $author$project$UInt64$next(model.e7);
							if (!_v3.$) {
								var generation = _v3.a;
								return _Utils_Tuple2(
									_Utils_update(
										base,
										{
											e7: generation,
											G: $elm$core$Maybe$Just(
												{e7: generation, aV: key, cQ: scope})
										}),
									_List_Nil);
							} else {
								return _Utils_Tuple2(
									_Utils_update(
										base,
										{G: $elm$core$Maybe$Nothing}),
									_List_Nil);
							}
						} else {
							var decision = _v2;
							return A3($author$project$TaskbarShell$apply, scope, decision, base);
						}
					}
				}
			case 2:
				var scope = message.a;
				var generation = message.b;
				var root = message.c;
				var _v4 = model.G;
				if (!_v4.$) {
					var picker = _v4.a;
					return ((!A2($author$project$TaskbarShell$valid, scope, model)) || ((!_Utils_eq(picker.cQ, scope)) || (!_Utils_eq(picker.e7, generation)))) ? _Utils_Tuple2(model, _List_Nil) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(model, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (family) {
								return A3(
									$author$project$TaskbarShell$apply,
									scope,
									$author$project$Taskbar$selection(family),
									model);
							},
							$elm$core$List$head(
								A2(
									$elm$core$List$filter,
									function (family) {
										return _Utils_eq(family.n, root);
									},
									A2(
										$elm$core$List$concatMap,
										function ($) {
											return $.aB;
										},
										A2(
											$elm$core$List$filter,
											function (group) {
												return _Utils_eq(group.aV, picker.aV);
											},
											$author$project$TaskbarShell$groups(model)))))));
				} else {
					return _Utils_Tuple2(model, _List_Nil);
				}
			default:
				var scope = message.a;
				var generation = message.b;
				var _v5 = model.G;
				if (!_v5.$) {
					var picker = _v5.a;
					return (_Utils_eq(picker.cQ, scope) && _Utils_eq(picker.e7, generation)) ? _Utils_Tuple2(
						_Utils_update(
							model,
							{G: $elm$core$Maybe$Nothing}),
						_List_Nil) : _Utils_Tuple2(model, _List_Nil);
				} else {
					return _Utils_Tuple2(model, _List_Nil);
				}
		}
	});
var $author$project$Snap$valid = F2(
	function (current, choice) {
		return _Utils_eq(current.c3, choice.c.c3) && (_Utils_eq(current.R.fe, choice.c.R.fe) && (_Utils_eq(current.R.e4, choice.c.R.e4) && (_Utils_eq(current.R.z, choice.c.R.z) && A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (window) {
					return (current.eZ || window.da) && ((!window.bR) && (window.bO && ((!window.bt) && ((!window.e6) && (_Utils_eq(window.dm, $elm$core$Maybe$Nothing) && ((!window.ec) && ((!window.b8) && (_Utils_eq(
						A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.cU;
							},
							A2($author$project$GeometryProjection$window, choice.fK, choice.c)),
						$elm$core$Maybe$Just(window.cU)) && _Utils_eq(
						$author$project$Snap$proposal(
							_Utils_update(
								choice,
								{c: current})),
						A2(
							$elm$core$Maybe$map,
							function (prior) {
								return _Utils_update(
									prior,
									{R: current.R});
							},
							$author$project$Snap$proposal(choice)))))))))));
				},
				A2($author$project$GeometryProjection$window, choice.fK, current))))));
	});
var $author$project$Desktop$windowBase = F2(
	function (message, model) {
		var _v0 = A2($author$project$TaskbarShell$update, message, model.a);
		var windows = _v0.a;
		var effects = _v0.b;
		var changed = !_Utils_eq(windows.b.c3, model.a.b.c3);
		var disconnected = !windows.b.m;
		var pins = (disconnected || changed) ? $author$project$Pins$initial : model.H;
		var inventory = function () {
			if (disconnected || changed) {
				return $elm$core$Maybe$Nothing;
			} else {
				if (_Utils_eq(windows.b.ac, model.a.b.ac)) {
					return model.b6;
				} else {
					if ((!message.$) && (message.a.$ === 3)) {
						var raw = message.a.a;
						return $author$project$WorkspaceInventory$decode(raw);
					} else {
						return $elm$core$Maybe$Nothing;
					}
				}
			}
		}();
		var launch = disconnected ? $author$project$Launch$disconnect(model.B) : (changed ? A2(
			$elm$core$Maybe$withDefault,
			$author$project$Launch$disconnect(model.B),
			A2(
				$elm$core$Maybe$map,
				function (binding) {
					return A2(
						$author$project$Launch$bind,
						$author$project$Desktop$host(binding),
						model.B);
				},
				windows.b.c3)) : model.B);
		var read = (changed && (!disconnected)) ? A2(
			$elm$core$Maybe$andThen,
			function (binding) {
				return A2(
					$elm$core$Maybe$map,
					function (request) {
						return _Utils_Tuple2(binding, request);
					},
					$author$project$UInt64$next(model.cM));
			},
			windows.b.c3) : $elm$core$Maybe$Nothing;
		var settingsRead = windows.b.c1 ? $elm$core$Maybe$Nothing : A2(
			$elm$core$Maybe$andThen,
			function (_v11) {
				var binding = _v11.a;
				var request = _v11.b;
				return A2(
					$elm$core$Maybe$map,
					function (next) {
						return _Utils_Tuple2(binding, next);
					},
					$author$project$UInt64$next(request));
			},
			read);
		var motionRead = A2(
			$elm$core$Maybe$andThen,
			function (_v10) {
				var binding = _v10.a;
				var request = _v10.b;
				return A2(
					$elm$core$Maybe$map,
					function (next) {
						return _Utils_Tuple2(binding, next);
					},
					$author$project$UInt64$next(request));
			},
			settingsRead);
		var shortcutsRead = A2(
			$elm$core$Maybe$andThen,
			function (_v9) {
				var binding = _v9.a;
				var request = _v9.b;
				return A2(
					$elm$core$Maybe$map,
					function (next) {
						return _Utils_Tuple2(binding, next);
					},
					$author$project$UInt64$next(request));
			},
			motionRead);
		return _Utils_Tuple2(
			((disconnected || changed) ? $author$project$Desktop$advance : $elm$core$Basics$identity)(
				_Utils_update(
					model,
					{
						K: (disconnected && (!(!model.a.b.m))) ? A2(
							$elm$core$Maybe$map,
							function (binding) {
								return A2($author$project$AdapterNotice$connectionLost, binding, model.a.b.cM);
							},
							model.a.b.c3) : (changed ? $elm$core$Maybe$Nothing : model.K),
						ai: (disconnected || changed) ? 0 : model.ai,
						aj: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.aj,
						bn: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.bn,
						k: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.k,
						D: (disconnected || changed) ? '' : model.D,
						y: (disconnected || changed) ? A2($elm$core$Maybe$map, $elm$core$Tuple$second, read) : model.y,
						W: (disconnected || changed) ? $author$project$Files$disconnect(model.W) : model.W,
						aR: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.aR,
						s: (disconnected || (changed || (windows.b.m === 3))) ? false : model.s,
						A: (disconnected || (changed || (windows.b.m === 3))) ? false : model.A,
						o: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.o,
						aU: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.aU,
						al: (disconnected || changed) ? $author$project$JumpList$disconnect(model.al) : model.al,
						u: (disconnected || (changed || (windows.b.m === 3))) ? false : model.u,
						B: launch,
						E: (disconnected || (changed || _Utils_eq(
							$author$project$MenuBridge$menuSnapshot(windows.i).aC,
							$elm$core$Maybe$Nothing))) ? $elm$core$Maybe$Nothing : model.E,
						M: (disconnected || changed) ? $author$project$Motion$rebind(model.M) : model.M,
						aH: (disconnected || changed) ? A2($elm$core$Maybe$map, $elm$core$Tuple$second, motionRead) : model.aH,
						an: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.an,
						C: (disconnected || changed) ? $author$project$Notifications$initial : model.C,
						aX: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.aX,
						v: (disconnected || (changed || (windows.b.m === 3))) ? false : model.v,
						F: (disconnected || (changed || (windows.b.m === 3))) ? false : model.F,
						l: (disconnected || (changed || (windows.b.m === 3))) ? false : model.l,
						Z: (disconnected || (changed || (!model.l))) ? $elm$core$Maybe$Nothing : model.Z,
						T: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.T,
						H: pins,
						bA: (disconnected || changed) ? false : model.bA,
						cM: A2(
							$elm$core$Maybe$withDefault,
							A2(
								$elm$core$Maybe$withDefault,
								A2(
									$elm$core$Maybe$withDefault,
									A2(
										$elm$core$Maybe$withDefault,
										model.cM,
										A2($elm$core$Maybe$map, $elm$core$Tuple$second, read)),
									A2($elm$core$Maybe$map, $elm$core$Tuple$second, settingsRead)),
								A2($elm$core$Maybe$map, $elm$core$Tuple$second, motionRead)),
							A2($elm$core$Maybe$map, $elm$core$Tuple$second, shortcutsRead)),
						r: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.r,
						ap: (disconnected || changed) ? $author$project$Settings$initial : model.ap,
						bi: (disconnected || changed) ? A2($elm$core$Maybe$map, $elm$core$Tuple$second, settingsRead) : model.bi,
						p: (disconnected || (changed || (windows.b.m === 3))) ? false : model.p,
						N: (disconnected || (changed || (windows.b.m === 3))) ? false : model.N,
						aM: (disconnected || changed) ? A2($elm$core$Maybe$map, $elm$core$Tuple$second, shortcutsRead) : model.aM,
						ah: (disconnected || changed) ? $author$project$ShortcutPreferences$initial : model.ah,
						b$: (disconnected || changed) ? $author$project$Shortcuts$initial : model.b$,
						w: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : A2(
							$elm$core$Maybe$andThen,
							function (choice) {
								var _v1 = windows.b.ac;
								if (_v1.$ === 1) {
									return $elm$core$Maybe$Just(choice);
								} else {
									var geometry = _v1.a;
									return A2($author$project$Snap$valid, geometry, choice) ? $elm$core$Maybe$Just(
										_Utils_update(
											choice,
											{c: geometry})) : $elm$core$Maybe$Nothing;
								}
							},
							model.w),
						j: (disconnected || (changed || (windows.b.m === 3))) ? A2(
							$author$project$Switcher$cancel,
							$author$project$Switcher$generation(model.j),
							model.j) : model.j,
						aN: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.aN,
						aO: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.aO,
						aq: (disconnected || changed) ? $author$project$SystemMenu$initial : model.aq,
						t: (disconnected || (changed || (windows.b.m === 3))) ? $elm$core$Maybe$Nothing : model.t,
						aP: (disconnected || changed) ? $elm$core$Maybe$Nothing : model.aP,
						x: (disconnected || (changed || (windows.b.m === 3))) ? false : model.x,
						I: (disconnected || (changed || (windows.b.m === 3))) ? false : model.I,
						a: windows,
						b6: inventory,
						J: disconnected ? $author$project$WorkspaceNavigation$disconnect(model.J) : (changed ? A2(
							$elm$core$Maybe$withDefault,
							$author$project$WorkspaceNavigation$disconnect(model.J),
							A2(
								$elm$core$Maybe$map,
								function (binding) {
									return A2($author$project$WorkspaceNavigation$bind, binding, model.J);
								},
								windows.b.c3)) : model.J)
					})),
			_Utils_ap(
				A2(
					$elm$core$Maybe$withDefault,
					_List_Nil,
					A2(
						$elm$core$Maybe$map,
						function (_v2) {
							var binding = _v2.a;
							var request = _v2.b;
							return _List_fromArray(
								[
									A2($author$project$Desktop$catalogRequest, binding, request)
								]);
						},
						read)),
				_Utils_ap(
					A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						A2(
							$elm$core$Maybe$map,
							function (_v3) {
								var binding = _v3.a;
								var request = _v3.b;
								return _List_fromArray(
									[
										A2($author$project$Desktop$settingsRequest, binding, request)
									]);
							},
							settingsRead)),
					_Utils_ap(
						A2(
							$elm$core$Maybe$withDefault,
							_List_Nil,
							A2(
								$elm$core$Maybe$map,
								function (_v4) {
									var binding = _v4.a;
									var request = _v4.b;
									return _List_fromArray(
										[
											A2($author$project$Desktop$motionPreferencesRequest, binding, request)
										]);
								},
								motionRead)),
						_Utils_ap(
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									function (_v5) {
										var binding = _v5.a;
										var request = _v5.b;
										return _List_fromArray(
											[
												A2($author$project$Desktop$shortcutPreferencesRequest, binding, request)
											]);
									},
									shortcutsRead)),
							_Utils_ap(
								A2($elm$core$List$map, $author$project$Desktop$WindowEffect, effects),
								function () {
									var _v6 = _Utils_Tuple3(model.a.G, windows.G, message);
									if (!_v6.b.$) {
										var prior = _v6.a;
										var picker = _v6.b.a;
										return _Utils_eq(
											A2(
												$elm$core$Maybe$map,
												function ($) {
													return $.e7;
												},
												prior),
											$elm$core$Maybe$Just(picker.e7)) ? _List_Nil : A2(
											$elm$core$Maybe$withDefault,
											_List_Nil,
											A2(
												$elm$core$Maybe$map,
												function (family) {
													return _List_fromArray(
														[
															$author$project$Desktop$Focus(
															'picker:' + ($author$project$Shell$stampKey(picker.cQ) + (':' + ($author$project$UInt64$string(picker.e7) + (':' + $author$project$UInt64$string(family.n))))))
														]);
												},
												$elm$core$List$head(
													A2(
														$elm$core$List$filter,
														function ($) {
															return $.c2;
														},
														A2(
															$elm$core$List$concatMap,
															function ($) {
																return $.aB;
															},
															A2(
																$elm$core$List$filter,
																function (group) {
																	return _Utils_eq(group.aV, picker.aV);
																},
																$author$project$TaskbarShell$groups(windows)))))));
									} else {
										if ((!_v6.a.$) && (_v6.c.$ === 3)) {
											var picker = _v6.a.a;
											var _v7 = _v6.b;
											var _v8 = _v6.c;
											var scope = _v8.a;
											var generation = _v8.b;
											return (_Utils_eq(picker.cQ, scope) && (_Utils_eq(picker.e7, generation) && _Utils_eq(
												$author$project$Shell$capture(windows.b),
												$elm$core$Maybe$Just(scope)))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													'group:' + ($author$project$Shell$stampKey(scope) + (':' + picker.aV)))
												]) : _List_Nil;
										} else {
											return _List_Nil;
										}
									}
								}()))))));
	});
var $author$project$Desktop$chooseFamily = F2(
	function (family, model) {
		var _v0 = _Utils_Tuple2(model.a.b.c3, model.a.b.V.av);
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var observed = _v0.b.a;
			if ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || A3($author$project$MenuBridge$blockedFor, family.n, model.a.b, model.a.i)) {
				return _Utils_Tuple2(
					$author$project$Desktop$retireSwitcher(model),
					_List_Nil);
			} else {
				var _v1 = A2(
					$author$project$Desktop$windowBase,
					$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
					$author$project$Desktop$retireSwitcher(
						_Utils_update(
							model,
							{D: '', l: false, aE: $author$project$OverviewRecovery$initial})));
				var next = _v1.a;
				var effects = _v1.b;
				var _v2 = next.a.b.y;
				if (!_v2.$) {
					var request = _v2.a;
					var token = A2($author$project$Desktop$ChoiceToken, binding, request);
					return _Utils_Tuple2(
						_Utils_update(
							next,
							{
								k: $elm$core$Maybe$Just(
									{
										c0: family.c0,
										c3: binding,
										aQ: A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.e7;
											},
											model.an),
										z: observed.R.z,
										bf: $elm$core$Maybe$Nothing,
										n: family.n,
										bj: token,
										a$: $elm$core$Maybe$Nothing
									})
							}),
						_Utils_ap(
							effects,
							_List_fromArray(
								[
									$author$project$Desktop$ArmChoice(token)
								])));
				} else {
					return _Utils_Tuple2(next, effects);
				}
			}
		} else {
			return _Utils_Tuple2(
				$author$project$Desktop$retireSwitcher(model),
				_List_Nil);
		}
	});
var $author$project$WorkspaceNavigation$clear = function (model) {
	return $author$project$WorkspaceNavigation$blocked(model) ? model : _Utils_update(
		model,
		{bT: $elm$core$Maybe$Nothing, fz: $elm$core$Maybe$Nothing, ex: false});
};
var $author$project$Notifications$clearFocus = function (model) {
	return _Utils_update(
		model,
		{ca: $elm$core$Maybe$Nothing});
};
var $author$project$Switcher$Idle = 0;
var $author$project$Switcher$initial = {a5: $elm$core$Maybe$Nothing, ak: _List_Nil, e7: $author$project$UInt64$zero, bT: $elm$core$Maybe$Nothing, m: 0, bY: false, cL: $elm$core$Maybe$Nothing, du: _List_Nil, bG: 0, bH: $elm$core$Dict$empty};
var $author$project$Switcher$fresh = function (token) {
	var _v0 = $author$project$Switcher$initial;
	var model = _v0;
	return _Utils_update(
		model,
		{e7: token, m: 1});
};
var $author$project$Switcher$prepare = F2(
	function (token, model) {
		var _v0 = A2($author$project$UInt64$compare, token, model.e7);
		switch (_v0) {
			case 2:
				return _Utils_eq(token, $author$project$UInt64$zero) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
					$author$project$Switcher$fresh(token));
			case 1:
				return $author$project$Switcher$writable(model) ? $elm$core$Maybe$Just(model) : $elm$core$Maybe$Nothing;
			default:
				return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Switcher$Resolved = 3;
var $elm$core$Dict$member = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$get, key, dict);
		if (!_v0.$) {
			return true;
		} else {
			return false;
		}
	});
var $author$project$Switcher$contiguous = F2(
	function (through, model) {
		return (through > 0) && A2(
			$elm$core$List$all,
			function (ordinal) {
				return A2($elm$core$Dict$member, ordinal, model.bH);
			},
			A2($elm$core$List$range, 1, through));
	});
var $author$project$Switcher$settle = function (model) {
	var complete = A2(
		$elm$core$Maybe$withDefault,
		A2(
			$author$project$Switcher$contiguous,
			$author$project$Switcher$lastOrdinal(model),
			model),
		A2(
			$elm$core$Maybe$map,
			function (ordinal) {
				return A2($author$project$Switcher$contiguous, ordinal, model);
			},
			model.cL));
	if ((!model.bY) || (!complete)) {
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{m: 1}),
			$elm$core$Maybe$Nothing);
	} else {
		if ($elm$core$List$isEmpty(model.ak)) {
			return _Utils_Tuple2(
				_Utils_update(
					model,
					{m: 3}),
				$elm$core$Maybe$Nothing);
		} else {
			if (!_Utils_eq(model.cL, $elm$core$Maybe$Nothing)) {
				var current = _Utils_update(
					model,
					{m: 3});
				return _Utils_Tuple2(
					current,
					$author$project$Switcher$selected(current));
			} else {
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{m: 2}),
					$elm$core$Maybe$Nothing);
			}
		}
	}
};
var $author$project$Switcher$release = F3(
	function (token, ordinal, original) {
		var current = original;
		if ((ordinal < 1) || (ordinal > 4096)) {
			return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
		} else {
			var _v0 = A2($author$project$Switcher$prepare, token, current);
			if (_v0.$ === 1) {
				return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
			} else {
				var model = _v0.a;
				if (_Utils_cmp(
					ordinal,
					$author$project$Switcher$lastOrdinal(model)) < 0) {
					return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
				} else {
					var _v1 = model.cL;
					if (!_v1.$) {
						return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
					} else {
						return $author$project$Switcher$settle(
							_Utils_update(
								model,
								{
									cL: $elm$core$Maybe$Just(ordinal)
								}));
					}
				}
			}
		}
	});
var $author$project$Switcher$commit = F2(
	function (token, original) {
		var model = original;
		return ((!_Utils_eq(token, model.e7)) || (model.m !== 2)) ? _Utils_Tuple2(original, $elm$core$Maybe$Nothing) : A3(
			$author$project$Switcher$release,
			token,
			$author$project$Switcher$lastOrdinal(model),
			original);
	});
var $author$project$Notifications$configure = F2(
	function (policy, model) {
		return _Utils_update(
			model,
			{ft: policy});
	});
var $author$project$SystemMenu$confirmed = function (value) {
	return A2(
		$elm$core$List$member,
		value.bc,
		_List_fromArray(
			[4, 5, 7])) || ((value.bc === 2) && (!value.ab));
};
var $author$project$Files$Peer = F5(
	function (pid, start, instance, target, visible) {
		return {de: instance, $7: pid, dw: start, fK: target, eN: visible};
	});
var $author$project$Files$Snapshot = F5(
	function (service, revision, available, reason, peer) {
		return {c2: available, bV: peer, ep: reason, cN: revision, cS: service};
	});
var $author$project$Files$bounded = function (limit) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return ((_Utils_cmp(
				$elm$core$String$length(value),
				limit) < 1) && $author$project$Files$textValid(value)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Files text');
		},
		$elm$json$Json$Decode$string);
};
var $author$project$Files$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Files identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$Files$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Files fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Files$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (snapshot) {
		return ((!snapshot.c2) && (!_Utils_eq(snapshot.bV, $elm$core$Maybe$Nothing))) ? $elm$json$Json$Decode$fail('Unavailable Files peer') : $elm$json$Json$Decode$succeed(snapshot);
	},
	A2(
		$author$project$Files$strict,
		_List_fromArray(
			['service', 'revision', 'available', 'reason', 'peer']),
		A6(
			$elm$json$Json$Decode$map5,
			$author$project$Files$Snapshot,
			A2($elm$json$Json$Decode$field, 'service', $author$project$Files$positive),
			A2($elm$json$Json$Decode$field, 'revision', $author$project$Files$positive),
			A2($elm$json$Json$Decode$field, 'available', $elm$json$Json$Decode$bool),
			A2(
				$elm$json$Json$Decode$field,
				'reason',
				$author$project$Files$bounded(128)),
			A2(
				$elm$json$Json$Decode$field,
				'peer',
				$elm$json$Json$Decode$nullable(
					A2(
						$author$project$Files$strict,
						_List_fromArray(
							['pid', 'start', 'instance', 'target', 'visible']),
						A6(
							$elm$json$Json$Decode$map5,
							$author$project$Files$Peer,
							A2($elm$json$Json$Decode$field, 'pid', $author$project$Files$positive),
							A2($elm$json$Json$Decode$field, 'start', $author$project$Files$positive),
							A2(
								$elm$json$Json$Decode$field,
								'instance',
								A2(
									$elm$json$Json$Decode$andThen,
									function (value) {
										return ((!$elm$core$String$isEmpty(value)) && A2(
											$elm$core$String$all,
											function (c) {
												return $elm$core$Char$isAlphaNum(c) || ((c === '_') || (c === '-'));
											},
											value)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Files instance');
									},
									$author$project$Files$bounded(128))),
							A2(
								$elm$json$Json$Decode$field,
								'target',
								A2(
									$elm$json$Json$Decode$andThen,
									function (value) {
										return ($author$project$Files$validTarget(value) && (!A2($elm$core$String$startsWith, '~', value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Files observed target');
									},
									$author$project$Files$bounded(512))),
							A2($elm$json$Json$Decode$field, 'visible', $elm$json$Json$Decode$bool))))))));
var $author$project$JumpList$Snapshot = F7(
	function (service, revision, entry, name, available, reason, actions) {
		return {cv: actions, c2: available, dQ: entry, dj: name, ep: reason, cN: revision, cS: service};
	});
var $author$project$JumpList$Action = F3(
	function (id, label, kind) {
		return {cc: id, d4: kind, d6: label};
	});
var $author$project$JumpList$DesktopAction = 0;
var $author$project$JumpList$actionKindDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'desktop':
				return $elm$json$Json$Decode$succeed(0);
			case 'recent':
				return $elm$json$Json$Decode$succeed(1);
			default:
				return $elm$json$Json$Decode$fail('Unsupported action kind');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$JumpList$bounded = F2(
	function (limit, nonempty) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return ((_Utils_cmp(
					$elm$core$String$length(value),
					limit) < 1) && (((!nonempty) || (!$elm$core$String$isEmpty(value))) && (!A2(
					$elm$core$String$any,
					function (c) {
						return ($elm$core$Char$toCode(c) < 32) || ($elm$core$Char$toCode(c) === 127);
					},
					value)))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Jump list text');
			},
			$elm$json$Json$Decode$string);
	});
var $author$project$JumpList$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Jump list fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$JumpList$actionDecoder = A2(
	$author$project$JumpList$strict,
	_List_fromArray(
		['id', 'label', 'kind']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$JumpList$Action,
		A2(
			$elm$json$Json$Decode$field,
			'id',
			A2($author$project$JumpList$bounded, 256, true)),
		A2(
			$elm$json$Json$Decode$field,
			'label',
			A2($author$project$JumpList$bounded, 512, true)),
		A2($elm$json$Json$Decode$field, 'kind', $author$project$JumpList$actionKindDecoder)));
var $author$project$JumpList$actionKindName = function (kind) {
	if (!kind) {
		return 'desktop';
	} else {
		return 'recent';
	}
};
var $author$project$JumpList$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Jump list identity') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$JumpList$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (snapshot) {
		var keys = A2(
			$elm$core$List$map,
			function ($) {
				return $.cc;
			},
			snapshot.cv);
		var unique = A3(
			$elm$core$List$foldl,
			F2(
				function (key, seen) {
					return A2($elm$core$List$member, key, seen) ? seen : A2($elm$core$List$cons, key, seen);
				}),
			_List_Nil,
			keys);
		return (($elm$core$List$length(keys) > 44) || ((!_Utils_eq(
			$elm$core$List$length(keys),
			$elm$core$List$length(unique))) || (((!snapshot.c2) && (!$elm$core$List$isEmpty(keys))) || A2(
			$elm$core$List$any,
			function (row) {
				return !A2(
					$elm$core$String$startsWith,
					$author$project$JumpList$actionKindName(row.d4) + ':',
					row.cc);
			},
			snapshot.cv)))) ? $elm$json$Json$Decode$fail('Jump list actions') : $elm$json$Json$Decode$succeed(snapshot);
	},
	A2(
		$author$project$JumpList$strict,
		_List_fromArray(
			['service', 'revision', 'entry', 'name', 'available', 'reason', 'actions']),
		A8(
			$elm$json$Json$Decode$map7,
			$author$project$JumpList$Snapshot,
			A2($elm$json$Json$Decode$field, 'service', $author$project$JumpList$positive),
			A2($elm$json$Json$Decode$field, 'revision', $author$project$JumpList$positive),
			A2(
				$elm$json$Json$Decode$field,
				'entry',
				A2($author$project$JumpList$bounded, 256, true)),
			A2(
				$elm$json$Json$Decode$field,
				'name',
				A2($author$project$JumpList$bounded, 512, false)),
			A2($elm$json$Json$Decode$field, 'available', $elm$json$Json$Decode$bool),
			A2(
				$elm$json$Json$Decode$field,
				'reason',
				A2($author$project$JumpList$bounded, 128, false)),
			A2(
				$elm$json$Json$Decode$field,
				'actions',
				$elm$json$Json$Decode$list($author$project$JumpList$actionDecoder)))));
var $author$project$Motion$kind = function (expected) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (v) {
			return _Utils_eq(v, expected) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Motion kind');
		},
		A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string));
};
var $author$project$Motion$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return (!_Utils_eq(v, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Motion counter');
	},
	$author$project$UInt64$decoder);
var $author$project$Motion$profileDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		switch (v) {
			case 'reduced':
				return $elm$json$Json$Decode$succeed(0);
			case 'full':
				return $elm$json$Json$Decode$succeed(1);
			default:
				return $elm$json$Json$Decode$fail('Motion profile');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Motion$Gtk = 1;
var $author$project$Motion$Portal = 0;
var $author$project$Motion$sourceDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'portal':
				return $elm$json$Json$Decode$succeed(0);
			case 'gtk':
				return $elm$json$Json$Decode$succeed(1);
			default:
				return $elm$json$Json$Decode$fail('Motion source');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Motion$strict = F2(
	function (fields, decoder_) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder_ : $elm$json$Json$Decode$fail('Motion fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Motion$version = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return (v === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Motion version');
	},
	A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int));
var $author$project$Motion$decoder = A2(
	$author$project$Motion$strict,
	_List_fromArray(
		['protocolVersion', 'kind', 'serial', 'profile', 'source']),
	A6(
		$elm$json$Json$Decode$map5,
		F5(
			function (_v0, _v1, serial, profile, source) {
				return {aG: profile, cR: serial, cm: source};
			}),
		$author$project$Motion$version,
		$author$project$Motion$kind('host-motion-preference'),
		A2($elm$json$Json$Decode$field, 'serial', $author$project$Motion$positive),
		A2($elm$json$Json$Decode$field, 'profile', $author$project$Motion$profileDecoder),
		A2($elm$json$Json$Decode$field, 'source', $author$project$Motion$sourceDecoder)));
var $author$project$MotionPreferences$overrideDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		if (value.$ === 1) {
			return $elm$json$Json$Decode$succeed(0);
		} else {
			switch (value.a) {
				case 'reduced':
					return $elm$json$Json$Decode$succeed(1);
				case 'full':
					return $elm$json$Json$Decode$succeed(2);
				default:
					return $elm$json$Json$Decode$fail('Motion override');
			}
		}
	},
	$elm$json$Json$Decode$nullable($elm$json$Json$Decode$string));
var $author$project$MotionPreferences$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Motion preference fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$MotionPreferences$decoder = A2(
	$author$project$MotionPreferences$strict,
	_List_fromArray(
		['schema', 'revision', 'override']),
	A4(
		$elm$json$Json$Decode$map3,
		F3(
			function (_v0, revision, override) {
				return {fo: override, cN: revision};
			}),
		A2(
			$elm$json$Json$Decode$andThen,
			function (v) {
				return (v === 1) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Motion preference version');
			},
			A2($elm$json$Json$Decode$field, 'schema', $elm$json$Json$Decode$int)),
		A2(
			$elm$json$Json$Decode$andThen,
			function (v) {
				return (!_Utils_eq(v, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Motion preference revision');
			},
			A2($elm$json$Json$Decode$field, 'revision', $author$project$UInt64$decoder)),
		A2($elm$json$Json$Decode$field, 'override', $author$project$MotionPreferences$overrideDecoder)));
var $author$project$Notifications$Snapshot = F5(
	function (service, revision, available, reason, entries) {
		return {c2: available, ak: entries, ep: reason, cN: revision, cS: service};
	});
var $author$project$Notifications$bounded = function (limit) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return ((_Utils_cmp(
				$elm$core$String$length(value),
				limit) < 1) && (!A2(
				$elm$core$String$any,
				function (c) {
					return ($elm$core$Char$toCode(c) < 32) && ((c !== '\n') && (c !== '\t'));
				},
				value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Notification text');
		},
		$elm$json$Json$Decode$string);
};
var $author$project$Notifications$Critical = 2;
var $author$project$Notifications$Low = 0;
var $author$project$Notifications$Normal = 1;
var $author$project$Notifications$EntryClosed = 4;
var $author$project$Notifications$EntryDisconnected = 5;
var $author$project$Notifications$EntryDismissed = 3;
var $author$project$Notifications$EntryExpired = 1;
var $author$project$Notifications$EntryInvoked = 2;
var $author$project$Notifications$EntryUnavailable = 7;
var $author$project$Notifications$EntryUnknown = 6;
var $author$project$Notifications$entryStateDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'live':
				return $elm$json$Json$Decode$succeed(0);
			case 'expired':
				return $elm$json$Json$Decode$succeed(1);
			case 'invoked':
				return $elm$json$Json$Decode$succeed(2);
			case 'dismissed':
				return $elm$json$Json$Decode$succeed(3);
			case 'closed':
				return $elm$json$Json$Decode$succeed(4);
			case 'disconnected':
				return $elm$json$Json$Decode$succeed(5);
			case 'unknown':
				return $elm$json$Json$Decode$succeed(6);
			case 'unavailable':
				return $elm$json$Json$Decode$succeed(7);
			default:
				return $elm$json$Json$Decode$fail('Notification state');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Notifications$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (!_Utils_eq(value, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Notification identity');
	},
	$author$project$UInt64$decoder);
var $author$project$Notifications$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Notification fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Notifications$unique = function (values) {
	return _Utils_eq(
		$elm$core$List$length(values),
		$elm$core$Set$size(
			$elm$core$Set$fromList(values)));
};
var $author$project$Notifications$entryDecoder = function () {
	var urgency = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			switch (value) {
				case 0:
					return $elm$json$Json$Decode$succeed(0);
				case 1:
					return $elm$json$Json$Decode$succeed(1);
				case 2:
					return $elm$json$Json$Decode$succeed(2);
				default:
					return $elm$json$Json$Decode$fail('Notification urgency');
			}
		},
		$elm$json$Json$Decode$int);
	var base = A9(
		$elm$json$Json$Decode$map8,
		F8(
			function (id, incarnation, producer, app, summary, body, state, actions) {
				return {cv: actions, dE: app, dH: body, cc: id, au: incarnation, ag: producer, cX: state, eG: summary, c_: 1};
			}),
		A2($elm$json$Json$Decode$field, 'id', $author$project$Notifications$positive),
		A2($elm$json$Json$Decode$field, 'incarnation', $author$project$Notifications$positive),
		A2(
			$elm$json$Json$Decode$field,
			'producer',
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return A2($elm$core$String$startsWith, ':', value) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Notification producer');
				},
				$author$project$Notifications$bounded(128))),
		A2(
			$elm$json$Json$Decode$field,
			'app',
			$author$project$Notifications$bounded(128)),
		A2(
			$elm$json$Json$Decode$field,
			'summary',
			$author$project$Notifications$bounded(256)),
		A2(
			$elm$json$Json$Decode$field,
			'body',
			$author$project$Notifications$bounded(1024)),
		A2($elm$json$Json$Decode$field, 'state', $author$project$Notifications$entryStateDecoder),
		A2(
			$elm$json$Json$Decode$field,
			'actions',
			$elm$json$Json$Decode$list(
				A2(
					$author$project$Notifications$strict,
					_List_fromArray(
						['key', 'label']),
					A3(
						$elm$json$Json$Decode$map2,
						F2(
							function (key, label) {
								return {aV: key, d6: label};
							}),
						A2(
							$elm$json$Json$Decode$field,
							'key',
							$author$project$Notifications$bounded(64)),
						A2(
							$elm$json$Json$Decode$field,
							'label',
							$author$project$Notifications$bounded(128)))))));
	return A2(
		$elm$json$Json$Decode$andThen,
		function (entry) {
			return (($elm$core$List$length(entry.cv) <= 8) && ($author$project$Notifications$unique(
				A2(
					$elm$core$List$map,
					function ($) {
						return $.aV;
					},
					entry.cv)) && (A2(
				$elm$core$List$all,
				function (a) {
					return (!$elm$core$String$isEmpty(a.aV)) && (!$elm$core$String$isEmpty(a.d6));
				},
				entry.cv) && ((!entry.cX) || $elm$core$List$isEmpty(entry.cv))))) ? $elm$json$Json$Decode$succeed(entry) : $elm$json$Json$Decode$fail('Notification action lifecycle');
		},
		$elm$json$Json$Decode$oneOf(
			_List_fromArray(
				[
					A2(
					$author$project$Notifications$strict,
					_List_fromArray(
						['id', 'incarnation', 'producer', 'app', 'summary', 'body', 'state', 'actions', 'urgency']),
					A3(
						$elm$json$Json$Decode$map2,
						F2(
							function (entry, level) {
								return _Utils_update(
									entry,
									{c_: level});
							}),
						base,
						A2($elm$json$Json$Decode$field, 'urgency', urgency))),
					A2(
					$author$project$Notifications$strict,
					_List_fromArray(
						['id', 'incarnation', 'producer', 'app', 'summary', 'body', 'state', 'actions']),
					base)
				])));
}();
var $author$project$Notifications$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (($elm$core$List$length(value.ak) <= 32) && ($author$project$Notifications$unique(
			A2(
				$elm$core$List$map,
				A2(
					$elm$core$Basics$composeR,
					function ($) {
						return $.cc;
					},
					$author$project$UInt64$string),
				value.ak)) && $author$project$Notifications$unique(
			A2(
				$elm$core$List$map,
				A2(
					$elm$core$Basics$composeR,
					function ($) {
						return $.au;
					},
					$author$project$UInt64$string),
				value.ak)))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Notification capacity/identity');
	},
	A2(
		$author$project$Notifications$strict,
		_List_fromArray(
			['service', 'revision', 'available', 'reason', 'entries']),
		A6(
			$elm$json$Json$Decode$map5,
			$author$project$Notifications$Snapshot,
			A2($elm$json$Json$Decode$field, 'service', $author$project$Notifications$positive),
			A2($elm$json$Json$Decode$field, 'revision', $author$project$Notifications$positive),
			A2($elm$json$Json$Decode$field, 'available', $elm$json$Json$Decode$bool),
			A2(
				$elm$json$Json$Decode$field,
				'reason',
				$author$project$Notifications$bounded(256)),
			A2(
				$elm$json$Json$Decode$field,
				'entries',
				$elm$json$Json$Decode$list($author$project$Notifications$entryDecoder)))));
var $author$project$Pins$Snapshot = F2(
	function (revision, identities) {
		return {fa: identities, cN: revision};
	});
var $author$project$Pins$identityDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (s) {
		return ((!$elm$core$String$isEmpty(s)) && (($elm$core$String$length(s) <= 256) && (!A2(
			$elm$core$String$any,
			function (c) {
				return ($elm$core$Char$toCode(c) < 32) || ($elm$core$Char$toCode(c) === 127);
			},
			s)))) ? $elm$json$Json$Decode$succeed(s) : $elm$json$Json$Decode$fail('Pin identity');
	},
	$elm$json$Json$Decode$string);
var $author$project$Pins$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Pin fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Pins$bytes = A2(
	$elm$core$String$foldl,
	F2(
		function (c, total) {
			return total + (($elm$core$Char$toCode(c) <= 127) ? 1 : (($elm$core$Char$toCode(c) <= 2047) ? 2 : (($elm$core$Char$toCode(c) <= 65535) ? 3 : 4)));
		}),
	0);
var $author$project$Pins$valid = function (values) {
	return ($elm$core$List$length(values) <= 32) && (_Utils_eq(
		$elm$core$List$length(values),
		$elm$core$List$length(
			A3(
				$elm$core$List$foldl,
				F2(
					function (s, seen) {
						return A2($elm$core$List$member, s, seen) ? seen : A2($elm$core$List$cons, s, seen);
					}),
				_List_Nil,
				values))) && ($author$project$Pins$bytes(
		A2(
			$elm$json$Json$Encode$encode,
			0,
			A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, values))) <= 3000));
};
var $author$project$Pins$decoder = A2(
	$author$project$Pins$strict,
	_List_fromArray(
		['revision', 'identities']),
	A3(
		$elm$json$Json$Decode$map2,
		$author$project$Pins$Snapshot,
		A2(
			$elm$json$Json$Decode$field,
			'revision',
			A2(
				$elm$json$Json$Decode$andThen,
				function (n) {
					return (!_Utils_eq(n, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(n) : $elm$json$Json$Decode$fail('Pin revision');
				},
				$author$project$UInt64$decoder)),
		A2(
			$elm$json$Json$Decode$field,
			'identities',
			A2(
				$elm$json$Json$Decode$andThen,
				function (values) {
					return $author$project$Pins$valid(values) ? $elm$json$Json$Decode$succeed(values) : $elm$json$Json$Decode$fail('Pin bounds');
				},
				$elm$json$Json$Decode$list($author$project$Pins$identityDecoder)))));
var $author$project$PointerOwnership$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return _Utils_eq(v, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Pointer counter') : $elm$json$Json$Decode$succeed(v);
	},
	$author$project$UInt64$decoder);
var $author$project$PointerOwnership$Moving = 1;
var $author$project$PointerOwnership$Resizing = 2;
var $author$project$PointerOwnership$stateDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		switch (v) {
			case 'idle':
				return $elm$json$Json$Decode$succeed(0);
			case 'move':
				return $elm$json$Json$Decode$succeed(1);
			case 'resize':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Pointer state');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$PointerOwnership$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Pointer fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$PointerOwnership$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (r) {
		return ((r.eK !== 3) || ((r.d4 !== 'pointer-ownership') || ((r.en !== 1) || ((!r.c.cX) && (!_Utils_eq(r.c.dm, $elm$core$Maybe$Nothing)))))) ? $elm$json$Json$Decode$fail('Pointer protocol/owner') : $elm$json$Json$Decode$succeed(r.c);
	},
	A2(
		$author$project$PointerOwnership$strict,
		_List_fromArray(
			['protocolVersion', 'kind', 'ownershipProtocol', 'binding', 'requestId', 'serial', 'state', 'owner']),
		A9(
			$elm$json$Json$Decode$map8,
			F8(
				function (version, kind, protocol, binding, request, serial, state, owner) {
					return {
						d4: kind,
						en: protocol,
						c: {c3: binding, dm: owner, cR: serial, cX: state},
						eK: version
					};
				}),
			A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'ownershipProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
			A2($elm$json$Json$Decode$field, 'requestId', $author$project$PointerOwnership$positive),
			A2($elm$json$Json$Decode$field, 'serial', $author$project$PointerOwnership$positive),
			A2($elm$json$Json$Decode$field, 'state', $author$project$PointerOwnership$stateDecoder),
			A2(
				$elm$json$Json$Decode$field,
				'owner',
				$elm$json$Json$Decode$nullable($author$project$PointerOwnership$positive)))));
var $author$project$Settings$Snapshot = F3(
	function (schema, revision, values) {
		return {cN: revision, fD: schema, bm: values};
	});
var $author$project$Settings$Values = F4(
	function (theme, textScale, effectsOff, reducedTransparency) {
		return {cD: effectsOff, cK: reducedTransparency, cp: textScale, cY: theme};
	});
var $author$project$Settings$scaleDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (scale) {
		return A2(
			$elm$core$List$member,
			scale,
			_List_fromArray(
				[100, 125, 150, 200])) ? $elm$json$Json$Decode$succeed(scale) : $elm$json$Json$Decode$fail('Text scale unavailable');
	},
	$elm$json$Json$Decode$int);
var $author$project$Settings$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Settings fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Settings$themeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'night':
				return $elm$json$Json$Decode$succeed(0);
			case 'dawn':
				return $elm$json$Json$Decode$succeed(1);
			case 'high-contrast':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Theme unavailable');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Settings$currentValues = A2(
	$author$project$Settings$strict,
	_List_fromArray(
		['theme', 'textScale', 'effectsOff', 'reducedTransparency']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$Settings$Values,
		A2($elm$json$Json$Decode$field, 'theme', $author$project$Settings$themeDecoder),
		A2($elm$json$Json$Decode$field, 'textScale', $author$project$Settings$scaleDecoder),
		A2($elm$json$Json$Decode$field, 'effectsOff', $elm$json$Json$Decode$bool),
		A2($elm$json$Json$Decode$field, 'reducedTransparency', $elm$json$Json$Decode$bool)));
var $author$project$Settings$legacyValues = A2(
	$author$project$Settings$strict,
	_List_fromArray(
		['theme', 'textScale']),
	A3(
		$elm$json$Json$Decode$map2,
		F2(
			function (theme, scale) {
				return {cD: false, cK: false, cp: scale, cY: theme};
			}),
		A2($elm$json$Json$Decode$field, 'theme', $author$project$Settings$themeDecoder),
		A2($elm$json$Json$Decode$field, 'textScale', $author$project$Settings$scaleDecoder)));
var $author$project$Settings$decoder = A2(
	$author$project$Settings$strict,
	_List_fromArray(
		['schema', 'revision', 'values']),
	A2(
		$elm$json$Json$Decode$andThen,
		function (version) {
			return (!A2(
				$elm$core$List$member,
				version,
				_List_fromArray(
					[1, 2]))) ? $elm$json$Json$Decode$fail('Settings schema unavailable') : A3(
				$elm$json$Json$Decode$map2,
				$author$project$Settings$Snapshot(2),
				A2(
					$elm$json$Json$Decode$field,
					'revision',
					A2(
						$elm$json$Json$Decode$andThen,
						function (revision) {
							return (!_Utils_eq(revision, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(revision) : $elm$json$Json$Decode$fail('Settings revision');
						},
						$author$project$UInt64$decoder)),
				A2(
					$elm$json$Json$Decode$field,
					'values',
					(version === 1) ? $author$project$Settings$legacyValues : $author$project$Settings$currentValues));
		},
		A2($elm$json$Json$Decode$field, 'schema', $elm$json$Json$Decode$int)));
var $author$project$ShortcutPreferences$Snapshot = F3(
	function (schema, revision, choices) {
		return {L: choices, cN: revision, fD: schema};
	});
var $author$project$ShortcutPreferences$Choices = F3(
	function (applications, system, notifications) {
		return {aj: applications, C: notifications, bI: system};
	});
var $author$project$ShortcutPreferences$choiceDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		switch (value) {
			case 'undecided':
				return $elm$json$Json$Decode$succeed(0);
			case 'keep':
				return $elm$json$Json$Decode$succeed(1);
			case 'default':
				return $elm$json$Json$Decode$succeed(2);
			case 'alternate':
				return $elm$json$Json$Decode$succeed(3);
			default:
				return $elm$json$Json$Decode$fail('Shortcut decision');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$ShortcutPreferences$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Shortcut fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$ShortcutPreferences$choicesDecoder = A2(
	$author$project$ShortcutPreferences$strict,
	_List_fromArray(
		['applications', 'system', 'notifications']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$ShortcutPreferences$Choices,
		A2($elm$json$Json$Decode$field, 'applications', $author$project$ShortcutPreferences$choiceDecoder),
		A2($elm$json$Json$Decode$field, 'system', $author$project$ShortcutPreferences$choiceDecoder),
		A2($elm$json$Json$Decode$field, 'notifications', $author$project$ShortcutPreferences$choiceDecoder)));
var $author$project$ShortcutPreferences$decoder = A2(
	$author$project$ShortcutPreferences$strict,
	_List_fromArray(
		['schema', 'revision', 'choices']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$ShortcutPreferences$Snapshot,
		A2(
			$elm$json$Json$Decode$field,
			'schema',
			A2(
				$elm$json$Json$Decode$andThen,
				function (v) {
					return (v === 1) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Shortcut schema');
				},
				$elm$json$Json$Decode$int)),
		A2(
			$elm$json$Json$Decode$field,
			'revision',
			A2(
				$elm$json$Json$Decode$andThen,
				function (v) {
					return (!_Utils_eq(v, $author$project$UInt64$zero)) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Shortcut revision');
				},
				$author$project$UInt64$decoder)),
		A2($elm$json$Json$Decode$field, 'choices', $author$project$ShortcutPreferences$choicesDecoder)));
var $author$project$Shortcuts$Event = F3(
	function (serial, route, outputGeneration) {
		return {fm: outputGeneration, ey: route, cR: serial};
	});
var $author$project$Shortcuts$boxDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (box) {
		if ((((box.b && box.b.b) && box.b.b.b) && box.b.b.b.b) && (!box.b.b.b.b.b)) {
			var x = box.a;
			var _v1 = box.b;
			var y = _v1.a;
			var _v2 = _v1.b;
			var width = _v2.a;
			var _v3 = _v2.b;
			var height = _v3.a;
			return ((width > 0) && ((height > 0) && A2(
				$elm$core$List$all,
				function (v) {
					return (_Utils_cmp(v, -2147483648) > -1) && (v <= 2147483647);
				},
				box))) ? $elm$json$Json$Decode$succeed(box) : $elm$json$Json$Decode$fail('Shortcut output bounds');
		} else {
			return $elm$json$Json$Decode$fail('Shortcut output shape');
		}
	},
	$elm$json$Json$Decode$list($elm$json$Json$Decode$int));
var $author$project$Shortcuts$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return _Utils_eq(v, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Shortcut serial') : $elm$json$Json$Decode$succeed(v);
	},
	$author$project$UInt64$decoder);
var $author$project$Shortcuts$Applications = 0;
var $author$project$Shortcuts$Notifications = 2;
var $author$project$Shortcuts$System = 1;
var $author$project$Shortcuts$routeDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		switch (v) {
			case 'applications':
				return $elm$json$Json$Decode$succeed(0);
			case 'system':
				return $elm$json$Json$Decode$succeed(1);
			case 'notifications':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Unsupported shell shortcut');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Shortcuts$strict = F2(
	function (fields, child) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Shortcut fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Shortcuts$eventDecoder = function (protocol) {
	return (protocol === 1) ? A2(
		$author$project$Shortcuts$strict,
		_List_fromArray(
			['serial', 'route']),
		A3(
			$elm$json$Json$Decode$map2,
			F2(
				function (serial, route) {
					return A3($author$project$Shortcuts$Event, serial, route, $elm$core$Maybe$Nothing);
				}),
			A2($elm$json$Json$Decode$field, 'serial', $author$project$Shortcuts$positive),
			A2($elm$json$Json$Decode$field, 'route', $author$project$Shortcuts$routeDecoder))) : ((protocol === 2) ? A2(
		$author$project$Shortcuts$strict,
		_List_fromArray(
			['serial', 'route', 'output']),
		A4(
			$elm$json$Json$Decode$map3,
			F3(
				function (serial, route, _v0) {
					return A3($author$project$Shortcuts$Event, serial, route, $elm$core$Maybe$Nothing);
				}),
			A2($elm$json$Json$Decode$field, 'serial', $author$project$Shortcuts$positive),
			A2($elm$json$Json$Decode$field, 'route', $author$project$Shortcuts$routeDecoder),
			A2(
				$elm$json$Json$Decode$field,
				'output',
				$elm$json$Json$Decode$nullable($author$project$Shortcuts$boxDecoder)))) : A2(
		$author$project$Shortcuts$strict,
		_List_fromArray(
			['serial', 'route', 'output', 'outputGeneration']),
		A5(
			$elm$json$Json$Decode$map4,
			F4(
				function (serial, route, _v1, generation) {
					return A3(
						$author$project$Shortcuts$Event,
						serial,
						route,
						$elm$core$Maybe$Just(generation));
				}),
			A2($elm$json$Json$Decode$field, 'serial', $author$project$Shortcuts$positive),
			A2($elm$json$Json$Decode$field, 'route', $author$project$Shortcuts$routeDecoder),
			A2(
				$elm$json$Json$Decode$field,
				'output',
				$elm$json$Json$Decode$nullable($author$project$Shortcuts$boxDecoder)),
			A2($elm$json$Json$Decode$field, 'outputGeneration', $author$project$Shortcuts$positive))));
};
var $author$project$Shortcuts$decoder = A2(
	$elm$json$Json$Decode$andThen,
	function (eventProtocol) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (receipt) {
				var snapshot = receipt.c;
				var ordered = function (rows) {
					if (!rows.b) {
						return true;
					} else {
						if (!rows.b.b) {
							return true;
						} else {
							var a = rows.a;
							var _v1 = rows.b;
							var b = _v1.a;
							var rest = _v1.b;
							return _Utils_eq(
								$author$project$UInt64$next(a.cR),
								$elm$core$Maybe$Just(b.cR)) && ordered(
								A2($elm$core$List$cons, b, rest));
						}
					}
				};
				var last = A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.cR;
					},
					$elm$core$List$head(
						$elm$core$List$reverse(snapshot.bq)));
				return ((receipt.eK !== 3) || ((receipt.d4 !== 'shell-shortcuts') || ((!A2(
					$elm$core$List$member,
					receipt.en,
					_List_fromArray(
						[1, 2, 3]))) || (($elm$core$List$length(snapshot.bq) > 64) || ((!ordered(snapshot.bq)) || ((!_Utils_eq(last, $elm$core$Maybe$Nothing)) && (!_Utils_eq(
					last,
					$elm$core$Maybe$Just(snapshot.cR))))))))) ? $elm$json$Json$Decode$fail('Shortcut protocol/order') : $elm$json$Json$Decode$succeed(snapshot);
			},
			A2(
				$author$project$Shortcuts$strict,
				_List_fromArray(
					['protocolVersion', 'kind', 'shortcutProtocol', 'binding', 'requestId', 'serial', 'blocked', 'events']),
				A9(
					$elm$json$Json$Decode$map8,
					F8(
						function (version, kind, protocol, binding, request, serial, blocked, events) {
							return {
								d4: kind,
								en: protocol,
								c: {c3: binding, eZ: blocked, bq: events, cR: serial},
								eK: version
							};
						}),
					A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					A2($elm$json$Json$Decode$field, 'shortcutProtocol', $elm$json$Json$Decode$int),
					A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
					A2($elm$json$Json$Decode$field, 'requestId', $author$project$Shortcuts$positive),
					A2($elm$json$Json$Decode$field, 'serial', $author$project$UInt64$decoder),
					A2($elm$json$Json$Decode$field, 'blocked', $elm$json$Json$Decode$bool),
					A2(
						$elm$json$Json$Decode$field,
						'events',
						$elm$json$Json$Decode$list(
							$author$project$Shortcuts$eventDecoder(eventProtocol))))));
	},
	A2($elm$json$Json$Decode$field, 'shortcutProtocol', $elm$json$Json$Decode$int));
var $author$project$Files$edit = F2(
	function (value, model) {
		return $author$project$Files$textValid(value) ? _Utils_update(
			model,
			{e2: value}) : model;
	});
var $author$project$MotionPreferences$edit = F2(
	function (override, model) {
		return $author$project$MotionPreferences$writable(model) ? _Utils_update(
			model,
			{e2: override, fj: 'Unsaved motion preference. Save to apply.'}) : model;
	});
var $author$project$Settings$edit = F2(
	function (values, model) {
		return ((!$author$project$Settings$writable(model)) || (!A2(
			$elm$core$List$member,
			values.cp,
			_List_fromArray(
				[100, 125, 150, 200])))) ? model : _Utils_update(
			model,
			{e2: values, fj: 'Unsaved changes. Save to apply.'});
	});
var $author$project$ShortcutPreferences$edit = F3(
	function (route, selected, model) {
		if ((!$author$project$ShortcutPreferences$writable(model)) || ((!A2(
			$elm$core$List$member,
			route,
			_List_fromArray(
				['applications', 'system', 'notifications']))) || (!A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				A2(
					$elm$core$Basics$composeR,
					$author$project$ShortcutPreferences$row(route),
					$author$project$ShortcutPreferences$allowed(selected)),
				model.cH))))) {
			return model;
		} else {
			var draft = model.e2;
			var next = function () {
				switch (route) {
					case 'applications':
						return _Utils_update(
							draft,
							{aj: selected});
					case 'system':
						return _Utils_update(
							draft,
							{bI: selected});
					default:
						return _Utils_update(
							draft,
							{C: selected});
				}
			}();
			var conflicts = A2(
				$elm$core$List$filter,
				$elm$core$Basics$neq(route),
				model.ay);
			return _Utils_update(
				model,
				{
					ay: conflicts,
					e2: next,
					fj: $elm$core$List$isEmpty(conflicts) ? 'Unsaved shortcut choices. Existing bindings remain unchanged until you save.' : 'Stored choices changed. Confirm each remaining affected shortcut before saving.'
				});
		}
	});
var $author$project$WorkspaceNavigation$expire = F2(
	function (intent, model) {
		var _v0 = model.fz;
		if (!_v0.$) {
			var r = _v0.a;
			return (_Utils_eq(r.af, intent) && (!r.O)) ? _Utils_update(
				model,
				{
					fz: $elm$core$Maybe$Just(
						_Utils_update(
							r,
							{ep: 'delivery-unproven', O: 1}))
				}) : model;
		} else {
			return model;
		}
	});
var $author$project$AdapterNotice$failedRead = F7(
	function (source, binding, request, service, revision, unavailable, prior) {
		return unavailable ? $elm$core$Maybe$Just(
			{c3: binding, cM: request, cN: revision, cS: service, cm: source}) : prior;
	});
var $author$project$Notifications$focus = F2(
	function (selected, model) {
		if (_Utils_eq(
			$author$project$Notifications$focusedIdentity(model),
			$elm$core$Maybe$Just(selected))) {
			return model;
		} else {
			var chosen = A2(
				$elm$core$Maybe$andThen,
				function (snapshot) {
					return $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (row) {
								return _Utils_eq(
									$author$project$Notifications$identity(row.fK),
									selected);
							},
							A2(
								$elm$core$List$concatMap,
								function (entry) {
									return _Utils_ap(
										A2(
											$elm$core$List$map,
											function (action) {
												return {
													d6: action.d6,
													fK: A4($author$project$Notifications$target, snapshot, entry, 0, action.aV)
												};
											},
											entry.cv),
										_List_fromArray(
											[
												{
												d6: 'Dismiss notification',
												fK: A4($author$project$Notifications$target, snapshot, entry, 1, '')
											}
											]));
								},
								A2(
									$elm$core$List$filter,
									function (entry) {
										return !entry.cX;
									},
									snapshot.ak))));
				},
				model.c);
			return _Utils_update(
				model,
				{ca: chosen});
		}
	});
var $author$project$ShortcutPreferences$Inventory = F4(
	function (fingerprint, applications, system, notifications) {
		return {aj: applications, dT: fingerprint, C: notifications, bI: system};
	});
var $elm$core$String$contains = _String_contains;
var $author$project$ShortcutPreferences$Row = F5(
	function (defaultChord, alternateChord, defaultAvailable, alternateAvailable, active) {
		return {dC: active, c$: alternateAvailable, eX: alternateChord, c8: defaultAvailable, e0: defaultChord};
	});
var $author$project$ShortcutPreferences$rowDecoder = F2(
	function (defaultChord, alternateChord) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return (((value.dC === 2) && (!value.c8)) || ((value.dC === 3) && (!value.c$))) ? $elm$json$Json$Decode$fail('Active shortcut conflicts') : $elm$json$Json$Decode$succeed(value);
			},
			A2(
				$author$project$ShortcutPreferences$strict,
				_List_fromArray(
					['defaultChord', 'alternateChord', 'defaultAvailable', 'alternateAvailable', 'active']),
				A6(
					$elm$json$Json$Decode$map5,
					$author$project$ShortcutPreferences$Row,
					A2(
						$elm$json$Json$Decode$field,
						'defaultChord',
						A2(
							$elm$json$Json$Decode$andThen,
							function (v) {
								return _Utils_eq(v, defaultChord) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Default chord');
							},
							$elm$json$Json$Decode$string)),
					A2(
						$elm$json$Json$Decode$field,
						'alternateChord',
						A2(
							$elm$json$Json$Decode$andThen,
							function (v) {
								return _Utils_eq(v, alternateChord) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Alternate chord');
							},
							$elm$json$Json$Decode$string)),
					A2($elm$json$Json$Decode$field, 'defaultAvailable', $elm$json$Json$Decode$bool),
					A2($elm$json$Json$Decode$field, 'alternateAvailable', $elm$json$Json$Decode$bool),
					A2(
						$elm$json$Json$Decode$field,
						'active',
						A2(
							$elm$json$Json$Decode$andThen,
							function (v) {
								return A2(
									$elm$core$List$member,
									v,
									_List_fromArray(
										[1, 2, 3])) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Observed shortcut');
							},
							$author$project$ShortcutPreferences$choiceDecoder)))));
	});
var $author$project$ShortcutPreferences$inventoryDecoder = A2(
	$author$project$ShortcutPreferences$strict,
	_List_fromArray(
		['fingerprint', 'applications', 'system', 'notifications']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$ShortcutPreferences$Inventory,
		A2(
			$elm$json$Json$Decode$field,
			'fingerprint',
			A2(
				$elm$json$Json$Decode$andThen,
				function (v) {
					return (($elm$core$String$length(v) === 64) && A2(
						$elm$core$String$all,
						function (c) {
							return A2(
								$elm$core$String$contains,
								$elm$core$String$fromChar(c),
								'0123456789abcdef');
						},
						v)) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Binding fingerprint');
				},
				$elm$json$Json$Decode$string)),
		A2(
			$elm$json$Json$Decode$field,
			'applications',
			A2($author$project$ShortcutPreferences$rowDecoder, 'SUPER + ALT + SPACE', 'SUPER + CTRL + ALT + SPACE')),
		A2(
			$elm$json$Json$Decode$field,
			'system',
			A2($author$project$ShortcutPreferences$rowDecoder, 'SUPER + ESCAPE', 'SUPER + CTRL + ESCAPE')),
		A2(
			$elm$json$Json$Decode$field,
			'notifications',
			A2($author$project$ShortcutPreferences$rowDecoder, 'SUPER + SHIFT + ALT + comma', 'SUPER + CTRL + ALT + comma'))));
var $author$project$Switcher$lastStep = function (_v0) {
	var model = _v0;
	return $author$project$Switcher$lastOrdinal(model);
};
var $author$project$Desktop$motionGesture = function (message) {
	switch (message.$) {
		case 39:
			return false;
		case 40:
			return false;
		case 45:
			return false;
		case 46:
			return false;
		case 50:
			return false;
		case 47:
			return false;
		case 48:
			return false;
		case 49:
			return false;
		default:
			return $author$project$Desktop$gestureAction(message);
	}
};
var $author$project$MotionPreferences$Refused = 1;
var $author$project$MotionPreferences$Saved = 0;
var $author$project$MotionPreferences$Unknown = 2;
var $author$project$Desktop$motionSaveReceipt = function (status) {
	switch (status) {
		case 0:
			return 0;
		case 1:
			return 1;
		default:
			return 2;
	}
};
var $author$project$Pins$move = F3(
	function (identity, direction, values) {
		var index = A2(
			$elm$core$Maybe$map,
			$elm$core$Tuple$first,
			$elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (_v2) {
						var s = _v2.b;
						return _Utils_eq(s, identity);
					},
					A2($elm$core$List$indexedMap, $elm$core$Tuple$pair, values))));
		var at = function (n) {
			return $elm$core$List$head(
				A2($elm$core$List$drop, n, values));
		};
		if (!index.$) {
			var n = index.a;
			var target = n + direction;
			if ((!A2(
				$elm$core$List$member,
				direction,
				_List_fromArray(
					[-1, 1]))) || ((target < 0) || (_Utils_cmp(
				target,
				$elm$core$List$length(values)) > -1))) {
				return values;
			} else {
				var _v1 = at(target);
				if (!_v1.$) {
					var other = _v1.a;
					return A2(
						$elm$core$List$indexedMap,
						F2(
							function (i, s) {
								return _Utils_eq(i, n) ? other : (_Utils_eq(i, target) ? identity : s);
							}),
						values);
				} else {
					return values;
				}
			}
		} else {
			return values;
		}
	});
var $author$project$Desktop$NativeChord = F8(
	function (generation, roots, history, origin, steps, released, cancelled, consumed) {
		return {cw: cancelled, cz: consumed, e7: generation, cb: history, bT: origin, cL: released, aL: roots, bH: steps};
	});
var $author$project$Desktop$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Desktop frame fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Desktop$nativeChordDecoder = function () {
	var positive = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero chord identity') : $elm$json$Json$Decode$succeed(value);
		},
		$author$project$UInt64$decoder);
	var identities = A2(
		$elm$json$Json$Decode$andThen,
		function (rows) {
			return (($elm$core$List$length(rows) <= 256) && _Utils_eq(
				$elm$core$List$length(
					A3(
						$elm$core$List$foldl,
						F2(
							function (root, unique) {
								return A2($elm$core$List$member, root, unique) ? unique : A2($elm$core$List$cons, root, unique);
							}),
						_List_Nil,
						rows)),
				$elm$core$List$length(rows))) ? $elm$json$Json$Decode$succeed(rows) : $elm$json$Json$Decode$fail('Chord membership');
		},
		$elm$json$Json$Decode$list(positive));
	var direction = A2(
		$elm$json$Json$Decode$andThen,
		function (value) {
			return (value === 1) ? $elm$json$Json$Decode$succeed(0) : (_Utils_eq(value, -1) ? $elm$json$Json$Decode$succeed(1) : $elm$json$Json$Decode$fail('Chord direction'));
		},
		$elm$json$Json$Decode$int);
	var steps = A2(
		$elm$json$Json$Decode$andThen,
		function (rows) {
			return ($elm$core$List$length(rows) <= 4096) ? $elm$json$Json$Decode$succeed(rows) : $elm$json$Json$Decode$fail('Chord ordinals');
		},
		$elm$json$Json$Decode$list(direction));
	return A2(
		$elm$json$Json$Decode$andThen,
		function (chord) {
			return (_Utils_eq(
				_Utils_eq(chord.e7, $author$project$UInt64$zero),
				$elm$core$List$isEmpty(chord.bH)) && A2(
				$elm$core$List$all,
				function (root) {
					return A2($elm$core$List$member, root, chord.aL);
				},
				chord.cb)) ? $elm$json$Json$Decode$succeed(chord) : $elm$json$Json$Decode$fail('Chord entry/history');
		},
		A2(
			$author$project$Desktop$strict,
			_List_fromArray(
				['generation', 'roots', 'history', 'origin', 'steps', 'released', 'cancelled', 'consumed']),
			A9(
				$elm$json$Json$Decode$map8,
				$author$project$Desktop$NativeChord,
				A2($elm$json$Json$Decode$field, 'generation', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'roots', identities),
				A2($elm$json$Json$Decode$field, 'history', identities),
				A2(
					$elm$json$Json$Decode$field,
					'origin',
					$elm$json$Json$Decode$nullable(positive)),
				A2($elm$json$Json$Decode$field, 'steps', steps),
				A2($elm$json$Json$Decode$field, 'released', $elm$json$Json$Decode$bool),
				A2($elm$json$Json$Decode$field, 'cancelled', $elm$json$Json$Decode$bool),
				A2($elm$json$Json$Decode$field, 'consumed', $elm$json$Json$Decode$bool))));
}();
var $author$project$Switcher$delta = function (direction) {
	return (!direction) ? 1 : (-1);
};
var $elm$core$Basics$modBy = _Basics_modBy;
var $author$project$Switcher$navigate = F2(
	function (direction, original) {
		var model = original;
		if ((model.m !== 2) || ((!_Utils_eq(model.cL, $elm$core$Maybe$Nothing)) || $elm$core$List$isEmpty(model.ak))) {
			return original;
		} else {
			var position = A2(
				$elm$core$Basics$modBy,
				$elm$core$List$length(model.ak),
				model.bG + $author$project$Switcher$delta(direction));
			var root = A2(
				$elm$core$Maybe$withDefault,
				$author$project$UInt64$zero,
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.n;
					},
					$elm$core$List$head(
						A2($elm$core$List$drop, position, model.ak))));
			return _Utils_update(
				model,
				{
					a5: $elm$core$Maybe$Just(
						{
							n: root,
							cZ: $author$project$Switcher$lastOrdinal(model)
						}),
					bG: position
				});
		}
	});
var $author$project$Motion$observe = F2(
	function (observation, model) {
		return A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (old) {
					return A2($author$project$UInt64$compare, observation.cR, old.cR) !== 2;
				},
				model.bw)) ? model : _Utils_update(
			model,
			{
				bw: $elm$core$Maybe$Just(observation)
			});
	});
var $author$project$MotionPreferences$observe = F2(
	function (snapshot, model) {
		if (snapshot.$ === 1) {
			return _Utils_update(
				model,
				{fj: 'Stored motion preference unavailable. Refresh to read it again; the stored copy is preserved.', c: $elm$core$Maybe$Nothing});
		} else {
			var current = snapshot.a;
			return A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (old) {
						return (!A2($author$project$UInt64$compare, current.cN, old.cN)) || (_Utils_eq(current.cN, old.cN) && (!_Utils_eq(current.fo, old.fo)));
					},
					model.c)) ? model : _Utils_update(
				model,
				{
					e2: current.fo,
					fj: 'Motion preference loaded.',
					dn: $elm$core$Maybe$Nothing,
					c: $elm$core$Maybe$Just(current)
				});
		}
	});
var $author$project$Notifications$same = F3(
	function (choice, service, entry) {
		return _Utils_eq(choice.cS, service) && (_Utils_eq(choice.cc, entry.cc) && (_Utils_eq(choice.au, entry.au) && _Utils_eq(choice.ag, entry.ag)));
	});
var $author$project$Notifications$observe = F2(
	function (current, model) {
		var pending = A2(
			$elm$core$Maybe$map,
			function (waiting) {
				return _Utils_update(
					waiting,
					{
						bN: waiting.bN || A2(
							$elm$core$List$any,
							function (entry) {
								return A3($author$project$Notifications$same, waiting.fK, current.cS, entry) && (entry.cX === 1);
							},
							current.ak)
					});
			},
			model.dn);
		var entries = A2(
			$elm$core$List$filter,
			function (row) {
				return !row.cX;
			},
			current.ak);
		var count = $elm$core$List$length(entries);
		var notice = (!current.c2) ? current.ep : ((!count) ? 'No live notifications. Previous notifications remain in history.' : ($elm$core$String$fromInt(count) + ' live notifications. Actions apply only to the current notification.'));
		var admitted = function () {
			var _v0 = model.c;
			if (_v0.$ === 1) {
				return true;
			} else {
				var old = _v0.a;
				return _Utils_eq(current.cS, old.cS) && ((A2($author$project$UInt64$compare, current.cN, old.cN) === 2) || _Utils_eq(current, old));
			}
		}();
		return (!admitted) ? model : _Utils_update(
			model,
			{
				fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? model.fj : notice,
				dn: pending,
				c: $elm$core$Maybe$Just(current)
			});
	});
var $author$project$Settings$observe = F2(
	function (snapshot, model) {
		if (snapshot.$ === 1) {
			return _Utils_update(
				model,
				{fj: 'Settings unavailable or from an unsupported version. Refresh to read them again; the stored copy is preserved.', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing});
		} else {
			var current = snapshot.a;
			return A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (old) {
						return !A2($author$project$UInt64$compare, current.cN, old.cN);
					},
					model.c)) ? model : _Utils_update(
				model,
				{
					e2: current.bm,
					fj: 'Settings loaded.',
					dn: $elm$core$Maybe$Nothing,
					c: $elm$core$Maybe$Just(current)
				});
		}
	});
var $author$project$ShortcutPreferences$Unconfirmed = 1;
var $author$project$ShortcutPreferences$liveMatches = F2(
	function (selected, _native) {
		return A2(
			$elm$core$List$all,
			function (route) {
				return _Utils_eq(
					A2($author$project$ShortcutPreferences$choices, route, selected),
					A2($author$project$ShortcutPreferences$row, route, _native).dC);
			},
			_List_fromArray(
				['applications', 'system', 'notifications']));
	});
var $author$project$ShortcutPreferences$observe = F3(
	function (snapshot, inventory, model) {
		var _v0 = _Utils_Tuple2(snapshot, inventory);
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var current = _v0.a.a;
			var _native = _v0.b.a;
			if (A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (old) {
						return !A2($author$project$UInt64$compare, current.cN, old.cN);
					},
					model.c))) {
				return model;
			} else {
				var settled = A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (pending) {
							return _Utils_eq(current.L, pending.L) && A2($author$project$ShortcutPreferences$liveMatches, pending.L, _native);
						},
						model.dn));
				var preserve = (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) || ((!$elm$core$List$isEmpty(model.ay)) || A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (old) {
							return !_Utils_eq(old.L, model.e2);
						},
						model.c)));
				var nextPending = settled ? $elm$core$Maybe$Nothing : A2(
					$elm$core$Maybe$map,
					function (pending) {
						return _Utils_update(
							pending,
							{dL: 1});
					},
					model.dn);
				var draft = preserve ? model.e2 : current.L;
				var conflict = function (route) {
					return preserve && ((!settled) && ((A2($elm$core$List$member, route, model.ay) && (!(_Utils_eq(
						A2($author$project$ShortcutPreferences$choices, route, draft),
						A2($author$project$ShortcutPreferences$choices, route, current.L)) && _Utils_eq(
						A2($author$project$ShortcutPreferences$choices, route, draft),
						A2($author$project$ShortcutPreferences$row, route, _native).dC)))) || A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (old) {
								return (!_Utils_eq(
									A2($author$project$ShortcutPreferences$choices, route, old.L),
									A2($author$project$ShortcutPreferences$choices, route, current.L))) && (!_Utils_eq(
									A2($author$project$ShortcutPreferences$choices, route, draft),
									A2($author$project$ShortcutPreferences$choices, route, current.L)));
							},
							model.c))));
				};
				var conflicts = A2(
					$elm$core$List$filter,
					conflict,
					_List_fromArray(
						['applications', 'system', 'notifications']));
				var notice = settled ? 'Shortcut choices confirmed saved and active. No action was repeated.' : ((!_Utils_eq(nextPending, $elm$core$Maybe$Nothing)) ? 'Shortcut application not confirmed. Your choices are preserved; refresh only reads stored choices and live bindings.' : ((!$elm$core$List$isEmpty(conflicts)) ? 'Stored choices changed. Your draft is preserved. Confirm each affected shortcut before saving.' : (preserve ? 'Your unsaved shortcut choices are preserved. Check availability before saving.' : 'Shortcut choices loaded. Conflicting bindings are preserved; choose a free chord or keep the existing shortcut.')));
				return _Utils_update(
					model,
					{
						ay: conflicts,
						e2: draft,
						cH: $elm$core$Maybe$Just(_native),
						fj: notice,
						dn: nextPending,
						c: $elm$core$Maybe$Just(current)
					});
			}
		} else {
			return _Utils_update(
				model,
				{cH: $elm$core$Maybe$Nothing, fj: 'Shortcut choices unavailable. Your draft and any pending save are preserved. Refresh to read again.'});
		}
	});
var $author$project$Pins$observeSnapshot = F2(
	function (snapshot, model) {
		if (snapshot.$ === 1) {
			return _Utils_update(
				model,
				{fj: 'Pin storage unavailable. Refresh applications to try again.', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing});
		} else {
			var value = snapshot.a;
			return A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (old) {
						return !A2($author$project$UInt64$compare, value.cN, old.cN);
					},
					model.c)) ? model : _Utils_update(
				model,
				{
					fj: '',
					dn: $elm$core$Maybe$Nothing,
					c: $elm$core$Maybe$Just(value)
				});
		}
	});
var $author$project$Pins$observeRead = F3(
	function (request, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return A2($author$project$Pins$observeSnapshot, snapshot, model);
		} else {
			var pending = _v0.a;
			var _v1 = pending.dL;
			if (!_v1.$) {
				return model;
			} else {
				var recovery = _v1.a;
				return _Utils_eq(
					recovery,
					$elm$core$Maybe$Just(request)) ? A2($author$project$Pins$observeSnapshot, snapshot, model) : model;
			}
		}
	});
var $author$project$JumpList$Awaiting = 0;
var $author$project$JumpList$propose = F3(
	function (request, value, model) {
		return (_Utils_eq(request, $author$project$UInt64$zero) || (!A2($author$project$JumpList$supported, value, model))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
			_Utils_update(
				model,
				{
					fj: 'Application action: waiting for native submission…',
					dn: $elm$core$Maybe$Just(
						{dL: 0, af: value, cM: request}),
					b1: A2(
						$elm$core$List$take,
						128,
						A2($elm$core$List$cons, value, model.b1))
				}),
			$elm$core$Maybe$Just(
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'service',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(value.cS))),
							_Utils_Tuple2(
							'revision',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(value.cN))),
							_Utils_Tuple2(
							'entry',
							$elm$json$Json$Encode$string(value.dQ)),
							_Utils_Tuple2(
							'action',
							$elm$json$Json$Encode$string(value.eV))
						]))));
	});
var $author$project$MotionPreferences$Awaiting = 0;
var $elm$json$Json$Encode$null = _Json_encodeNull;
var $author$project$MotionPreferences$encode = function (snapshot) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'schema',
				$elm$json$Json$Encode$int(1)),
				_Utils_Tuple2(
				'revision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(snapshot.cN))),
				_Utils_Tuple2(
				'override',
				function () {
					var _v0 = snapshot.fo;
					switch (_v0) {
						case 0:
							return $elm$json$Json$Encode$null;
						case 1:
							return $elm$json$Json$Encode$string('reduced');
						default:
							return $elm$json$Json$Encode$string('full');
					}
				}())
			]));
};
var $author$project$MotionPreferences$propose = F2(
	function (request, model) {
		var _v0 = model.c;
		if (_v0.$ === 1) {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		} else {
			var current = _v0.a;
			return (_Utils_eq(request, $author$project$UInt64$zero) || ((!$author$project$MotionPreferences$writable(model)) || _Utils_eq(current.fo, model.e2))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						fj: 'Saving motion preference…',
						dn: $elm$core$Maybe$Just(
							{fo: model.e2, cM: request, cN: current.cN, cX: 0})
					}),
				$elm$core$Maybe$Just(
					$author$project$MotionPreferences$encode(
						_Utils_update(
							current,
							{fo: model.e2}))));
		}
	});
var $author$project$Notifications$encodeIntent = function (value) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'service',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.cS))),
				_Utils_Tuple2(
				'id',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.cc))),
				_Utils_Tuple2(
				'incarnation',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.au))),
				_Utils_Tuple2(
				'producer',
				$elm$json$Json$Encode$string(value.ag)),
				_Utils_Tuple2(
				'action',
				$elm$json$Json$Encode$string(value.eV)),
				_Utils_Tuple2(
				'verb',
				$elm$json$Json$Encode$string(
					$author$project$Notifications$verbName(value.b2)))
			]));
};
var $author$project$Notifications$propose = F3(
	function (request, choice, model) {
		return ((!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) || (!A2($author$project$Notifications$live, choice, model))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
			_Utils_update(
				model,
				{
					fj: 'Sending notification action…',
					dn: $elm$core$Maybe$Just(
						{bN: false, cM: request, fK: choice}),
					b1: A2(
						$elm$core$List$take,
						64,
						A2($elm$core$List$cons, choice, model.b1))
				}),
			$elm$core$Maybe$Just(
				$author$project$Notifications$encodeIntent(choice)));
	});
var $author$project$Settings$encode = function (snapshot) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'schema',
				$elm$json$Json$Encode$int(snapshot.fD)),
				_Utils_Tuple2(
				'revision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(snapshot.cN))),
				_Utils_Tuple2(
				'values',
				$author$project$Settings$encodeValues(snapshot.bm))
			]));
};
var $author$project$Settings$propose = F2(
	function (request, model) {
		var _v0 = model.c;
		if (!_v0.$) {
			var current = _v0.a;
			return ((!$author$project$Settings$writable(model)) || _Utils_eq(current.bm, model.e2)) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						fj: 'Saving settings…',
						cJ: $elm$core$Maybe$Nothing,
						dn: $elm$core$Maybe$Just(
							{cM: request, bm: model.e2})
					}),
				$elm$core$Maybe$Just(
					$author$project$Settings$encode(
						_Utils_update(
							current,
							{bm: model.e2}))));
		} else {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$ShortcutPreferences$Awaiting = 0;
var $author$project$ShortcutPreferences$encode = function (snapshot) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'schema',
				$elm$json$Json$Encode$int(1)),
				_Utils_Tuple2(
				'revision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(snapshot.cN))),
				_Utils_Tuple2(
				'choices',
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'applications',
							$elm$json$Json$Encode$string(
								$author$project$ShortcutPreferences$name(snapshot.L.aj))),
							_Utils_Tuple2(
							'system',
							$elm$json$Json$Encode$string(
								$author$project$ShortcutPreferences$name(snapshot.L.bI))),
							_Utils_Tuple2(
							'notifications',
							$elm$json$Json$Encode$string(
								$author$project$ShortcutPreferences$name(snapshot.L.C)))
						])))
			]));
};
var $author$project$ShortcutPreferences$propose = F2(
	function (request, model) {
		var _v0 = _Utils_Tuple2(model.c, model.cH);
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var current = _v0.a.a;
			var _native = _v0.b.a;
			return (!($author$project$ShortcutPreferences$ready(model) && $author$project$ShortcutPreferences$changed(model))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						fj: 'Saving and applying shortcut choices…',
						dn: $elm$core$Maybe$Just(
							{L: model.e2, dL: 0, cM: request})
					}),
				$elm$core$Maybe$Just(
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'preferences',
								$author$project$ShortcutPreferences$encode(
									_Utils_update(
										current,
										{L: model.e2}))),
								_Utils_Tuple2(
								'fingerprint',
								$elm$json$Json$Encode$string(_native.dT))
							]))));
		} else {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$Desktop$readFiles = function (model) {
	if (!_Utils_eq(model.aR, $elm$core$Maybe$Nothing)) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = _Utils_Tuple2(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			return _Utils_Tuple2(
				$author$project$Desktop$advance(
					_Utils_update(
						model,
						{
							aR: $elm$core$Maybe$Just(request),
							cM: request
						})),
				_List_fromArray(
					[
						$author$project$Desktop$Send(
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'protocolVersion',
									$elm$json$Json$Encode$int(3)),
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('files-request')),
									_Utils_Tuple2(
									'binding',
									$author$project$Binding$encode(binding)),
									_Utils_Tuple2(
									'requestId',
									$elm$json$Json$Encode$string(
										$author$project$UInt64$string(request)))
								])))
					]));
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	}
};
var $author$project$Desktop$readJumpList = function (model) {
	if (!_Utils_eq(model.aU, $elm$core$Maybe$Nothing)) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = _Utils_Tuple3(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM),
			model.o);
		if (((!_v0.a.$) && (!_v0.b.$)) && (!_v0.c.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			var entry = _v0.c.a;
			return _Utils_Tuple2(
				$author$project$Desktop$advance(
					_Utils_update(
						model,
						{
							aU: $elm$core$Maybe$Just(request),
							cM: request
						})),
				_List_fromArray(
					[
						$author$project$Desktop$Send(
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'protocolVersion',
									$elm$json$Json$Encode$int(3)),
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('jump-list-request')),
									_Utils_Tuple2(
									'binding',
									$author$project$Binding$encode(binding)),
									_Utils_Tuple2(
									'requestId',
									$elm$json$Json$Encode$string(
										$author$project$UInt64$string(request))),
									_Utils_Tuple2(
									'entry',
									$elm$json$Json$Encode$string(entry))
								])))
					]));
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	}
};
var $author$project$Desktop$readMotionPreferences = function (model) {
	var _v0 = _Utils_Tuple2(
		model.a.b.c3,
		$author$project$UInt64$next(model.cM));
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var request = _v0.b.a;
		return _Utils_Tuple2(
			$author$project$Desktop$advance(
				_Utils_update(
					model,
					{
						aH: $elm$core$Maybe$Just(request),
						cM: request
					})),
			_List_fromArray(
				[
					A2($author$project$Desktop$motionPreferencesRequest, binding, request)
				]));
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Desktop$readNotifications = function (model) {
	if (!_Utils_eq(model.aX, $elm$core$Maybe$Nothing)) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = _Utils_Tuple2(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			return _Utils_Tuple2(
				$author$project$Desktop$advance(
					_Utils_update(
						model,
						{
							aX: $elm$core$Maybe$Just(request),
							cM: request
						})),
				_List_fromArray(
					[
						$author$project$Desktop$Send(
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'protocolVersion',
									$elm$json$Json$Encode$int(3)),
									_Utils_Tuple2(
									'kind',
									$elm$json$Json$Encode$string('notification-request')),
									_Utils_Tuple2(
									'binding',
									$author$project$Binding$encode(binding)),
									_Utils_Tuple2(
									'requestId',
									$elm$json$Json$Encode$string(
										$author$project$UInt64$string(request)))
								])))
					]));
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	}
};
var $author$project$Desktop$readSettings = function (model) {
	var _v0 = _Utils_Tuple2(
		model.a.b.c3,
		$author$project$UInt64$next(model.cM));
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var request = _v0.b.a;
		return _Utils_Tuple2(
			$author$project$Desktop$advance(
				_Utils_update(
					model,
					{
						cM: request,
						bi: $elm$core$Maybe$Just(request)
					})),
			_List_fromArray(
				[
					A2($author$project$Desktop$settingsRequest, binding, request)
				]));
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Desktop$readShortcutPreferences = function (model) {
	var _v0 = _Utils_Tuple2(
		model.a.b.c3,
		$author$project$UInt64$next(model.cM));
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var request = _v0.b.a;
		return _Utils_Tuple2(
			$author$project$Desktop$advance(
				_Utils_update(
					model,
					{
						cM: request,
						aM: $elm$core$Maybe$Just(request)
					})),
			_List_fromArray(
				[
					A2($author$project$Desktop$shortcutPreferencesRequest, binding, request)
				]));
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Desktop$historyRequest = F2(
	function (binding, request) {
		return $author$project$Desktop$Send(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'protocolVersion',
						$elm$json$Json$Encode$int(3)),
						_Utils_Tuple2(
						'kind',
						$elm$json$Json$Encode$string('activation-history-request')),
						_Utils_Tuple2(
						'binding',
						$author$project$Binding$encode(binding)),
						_Utils_Tuple2(
						'requestId',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request)))
					])));
	});
var $author$project$Desktop$readSwitcherHistory = function (model) {
	var _v0 = _Utils_Tuple2(
		model.a.b.c3,
		$author$project$UInt64$next(model.cM));
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var request = _v0.b.a;
		return _Utils_Tuple2(
			_Utils_update(
				model,
				{
					cM: request,
					aN: $elm$core$Maybe$Just(request),
					aO: $elm$core$Maybe$Nothing
				}),
			_List_fromArray(
				[
					A2($author$project$Desktop$historyRequest, binding, request)
				]));
	} else {
		return _Utils_Tuple2(
			$author$project$Desktop$retireSwitcher(model),
			_List_Nil);
	}
};
var $author$project$Desktop$readSystemMenu = function (model) {
	var _v0 = _Utils_Tuple2(
		model.a.b.c3,
		$author$project$UInt64$next(model.cM));
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var request = _v0.b.a;
		return _Utils_Tuple2(
			$author$project$Desktop$advance(
				_Utils_update(
					model,
					{
						cM: request,
						aP: $elm$core$Maybe$Just(request)
					})),
			_List_fromArray(
				[
					$author$project$Desktop$Send(
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'protocolVersion',
								$elm$json$Json$Encode$int(3)),
								_Utils_Tuple2(
								'kind',
								$elm$json$Json$Encode$string('system-menu-request')),
								_Utils_Tuple2(
								'binding',
								$author$project$Binding$encode(binding)),
								_Utils_Tuple2(
								'requestId',
								$elm$json$Json$Encode$string(
									$author$project$UInt64$string(request)))
							])))
				]));
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Motion$ready = F2(
	function (binding, model) {
		return (_Utils_eq(model.bw, $elm$core$Maybe$Nothing) && ((!$author$project$MotionPreferences$selected(model.aY)) && _Utils_eq(model.dn, $elm$core$Maybe$Nothing))) || ((!_Utils_eq(model.aY.c, $elm$core$Maybe$Nothing)) && (_Utils_eq(model.dn, $elm$core$Maybe$Nothing) && A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (a) {
					return _Utils_eq(
						binding,
						$elm$core$Maybe$Just(a.c3)) && _Utils_eq(
						a.aG,
						$author$project$Motion$desired(model));
				},
				model.bL))));
	});
var $author$project$Motion$receiptDecoder = A2(
	$author$project$Motion$strict,
	_List_fromArray(
		['protocolVersion', 'kind', 'binding', 'requestId', 'profile']),
	A6(
		$elm$json$Json$Decode$map5,
		F5(
			function (_v0, _v1, binding, request_, profile) {
				return {c3: binding, aG: profile, cM: request_};
			}),
		$author$project$Motion$version,
		$author$project$Motion$kind('motion-profile'),
		A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
		A2($elm$json$Json$Decode$field, 'requestId', $author$project$Motion$positive),
		A2($elm$json$Json$Decode$field, 'profile', $author$project$Motion$profileDecoder)));
var $author$project$Files$Unconfirmed = 1;
var $author$project$Files$normalize = function (value) {
	return (!A2(
		$elm$core$String$startsWith,
		'/',
		$elm$core$String$trim(value))) ? value : ('/' + A2(
		$elm$core$String$join,
		'/',
		$elm$core$List$reverse(
			A3(
				$elm$core$List$foldl,
				F2(
					function (part, parts) {
						return ((part === '') || (part === '.')) ? parts : ((part === '..') ? A2($elm$core$List$drop, 1, parts) : A2($elm$core$List$cons, part, parts));
					}),
				_List_Nil,
				A2(
					$elm$core$String$split,
					'/',
					$elm$core$String$trim(value))))));
};
var $author$project$Files$observe = F2(
	function (snapshot, model) {
		var admitted = A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (old) {
					return _Utils_eq(snapshot.cS, old.cS) && ((A2($author$project$UInt64$compare, snapshot.cN, old.cN) === 2) || _Utils_eq(snapshot, old));
				},
				model.c));
		return (!admitted) ? model : _Utils_update(
			model,
			{
				fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? model.fj : (snapshot.c2 ? 'Choose a collection or folder.' : snapshot.ep),
				c: $elm$core$Maybe$Just(snapshot)
			});
	});
var $author$project$Files$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			if ((!_Utils_eq(request, pending.cM)) || ((!_Utils_eq(snapshot.cS, pending.af.cS)) || (!A2(
				$elm$core$List$member,
				status,
				_List_fromArray(
					['Opened', 'Refused', 'Unknown']))))) {
				return model;
			} else {
				var samePeer = function () {
					var _v1 = _Utils_Tuple2(
						A2(
							$elm$core$Maybe$andThen,
							function ($) {
								return $.bV;
							},
							model.c),
						snapshot.bV);
					_v1$2:
					while (true) {
						if (!_v1.a.$) {
							if (!_v1.b.$) {
								var old = _v1.a.a;
								var current = _v1.b.a;
								return _Utils_eq(old.$7, current.$7) && (_Utils_eq(old.dw, current.dw) && _Utils_eq(old.de, current.de));
							} else {
								break _v1$2;
							}
						} else {
							if (!_v1.b.$) {
								var _v2 = _v1.a;
								return true;
							} else {
								break _v1$2;
							}
						}
					}
					return false;
				}();
				var next = A2($author$project$Files$observe, snapshot, model);
				var locationMatches = A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (peer) {
							return A2(
								$elm$core$String$startsWith,
								'~',
								$elm$core$String$trim(pending.af.fK)) ? A2($elm$core$String$startsWith, '/', peer.fK) : _Utils_eq(
								peer.fK,
								$author$project$Files$normalize(pending.af.fK));
						},
						snapshot.bV));
				var opened = snapshot.c2 && (samePeer && (locationMatches && ((A2($author$project$UInt64$compare, snapshot.cN, pending.af.cN) === 2) && A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function ($) {
							return $.eN;
						},
						snapshot.bV)))));
				var notice = ((status === 'Opened') && opened) ? 'Files: requested location opened.' : ((status === 'Refused') ? 'Files: request refused. Refresh before choosing again.' : 'Files: opening not confirmed. Refresh only reads state; this request will not be repeated.');
				return (!_Utils_eq(
					next.c,
					$elm$core$Maybe$Just(snapshot))) ? model : _Utils_update(
					next,
					{
						fj: notice,
						dn: ((status === 'Refused') || ((status === 'Opened') && opened)) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
							_Utils_update(
								pending,
								{dL: 1}))
					});
			}
		}
	});
var $author$project$JumpList$Unconfirmed = 1;
var $author$project$JumpList$observe = F2(
	function (snapshot, model) {
		var admitted = A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (old) {
					return _Utils_eq(snapshot.cS, old.cS) && ((A2($author$project$UInt64$compare, snapshot.cN, old.cN) === 2) || _Utils_eq(snapshot, old));
				},
				model.c));
		return (!admitted) ? model : _Utils_update(
			model,
			{
				fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? model.fj : (snapshot.c2 ? ($elm$core$String$isEmpty(snapshot.ep) ? 'Choose an application action or recent file.' : snapshot.ep) : snapshot.ep),
				c: $elm$core$Maybe$Just(snapshot)
			});
	});
var $author$project$JumpList$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			if ((!_Utils_eq(request, pending.cM)) || ((!_Utils_eq(snapshot.cS, pending.af.cS)) || ((!_Utils_eq(snapshot.dQ, pending.af.dQ)) || (!A2(
				$elm$core$List$member,
				status,
				_List_fromArray(
					['Submitted', 'Refused', 'Unknown'])))))) {
				return model;
			} else {
				var next = A2($author$project$JumpList$observe, snapshot, model);
				return (!_Utils_eq(
					next.c,
					$elm$core$Maybe$Just(snapshot))) ? model : _Utils_update(
					next,
					{
						fj: (status === 'Submitted') ? 'Application action: submitted to the native launcher.' : ((status === 'Refused') ? 'Application action: refused or no longer available. Refresh before choosing again.' : 'Application action: not confirmed. Refresh only reads actions; this request will not be repeated.'),
						dn: (status === 'Unknown') ? $elm$core$Maybe$Just(
							_Utils_update(
								pending,
								{dL: 1})) : $elm$core$Maybe$Nothing
					});
			}
		}
	});
var $author$project$Launch$Refused = 1;
var $author$project$Launch$Submitted = 0;
var $author$project$Launch$Intent = F4(
	function (request, lifetime, generation, entry) {
		return {dQ: entry, e7: generation, fe: lifetime, cM: request};
	});
var $author$project$Launch$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero launch counter') : $elm$json$Json$Decode$succeed(value);
	},
	$author$project$UInt64$decoder);
var $author$project$Launch$strict = F2(
	function (names, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (fields) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, fields)),
					$elm$core$List$sort(names)) ? decoder : $elm$json$Json$Decode$fail('Unexpected launch receipt fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$Launch$intentDecoder = A2(
	$author$project$Launch$strict,
	_List_fromArray(
		['request', 'lifetime', 'generation', 'entry']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$Launch$Intent,
		A2($elm$json$Json$Decode$field, 'request', $author$project$Launch$positive),
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$Launch$positive),
		A2($elm$json$Json$Decode$field, 'generation', $author$project$Launch$positive),
		A2(
			$elm$json$Json$Decode$andThen,
			function (value) {
				return ($elm$core$String$isEmpty(value) || (($elm$core$String$length(value) > 256) || A2(
					$elm$core$String$any,
					function (c) {
						return $elm$core$Char$toCode(c) < 32;
					},
					value))) ? $elm$json$Json$Decode$fail('Launch identity') : $elm$json$Json$Decode$succeed(value);
			},
			A2($elm$json$Json$Decode$field, 'entry', $elm$json$Json$Decode$string))));
var $author$project$Launch$receiptDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (receipt) {
		return ((receipt.eK !== 1) || (receipt.d4 !== 'launch-outcome')) ? $elm$json$Json$Decode$fail('Launch receipt version/kind') : (((receipt.cX === 'Submitted') && (receipt.ep === 'native-submission-accepted')) ? $elm$json$Json$Decode$succeed(
			_Utils_Tuple2(receipt.af, 0)) : (((receipt.cX === 'Unknown') && (receipt.ep === 'submission-not-confirmed')) ? $elm$json$Json$Decode$succeed(
			_Utils_Tuple2(receipt.af, 2)) : (((receipt.cX === 'Refused') && A2(
			$elm$core$List$member,
			receipt.ep,
			_List_fromArray(
				['retired-authority', 'request-reuse', 'retired-request', 'catalog-unavailable', 'stale-catalog', 'removed-entry', 'native-entry-unavailable', 'desktop-entry-raced']))) ? $elm$json$Json$Decode$succeed(
			_Utils_Tuple2(receipt.af, 1)) : $elm$json$Json$Decode$fail('Launch receipt outcome'))));
	},
	A2(
		$author$project$Launch$strict,
		_List_fromArray(
			['catalogProtocol', 'kind', 'intent', 'status', 'reason']),
		A6(
			$elm$json$Json$Decode$map5,
			F5(
				function (version, kind, intent, state, reason) {
					return {af: intent, d4: kind, ep: reason, cX: state, eK: version};
				}),
			A2($elm$json$Json$Decode$field, 'catalogProtocol', $elm$json$Json$Decode$int),
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'intent', $author$project$Launch$intentDecoder),
			A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
			A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$string))));
var $author$project$Launch$receive = F3(
	function (host, raw, current) {
		var model = current;
		var _v0 = _Utils_Tuple2(
			model.m,
			A2($elm$json$Json$Decode$decodeValue, $author$project$Launch$receiptDecoder, raw));
		if ((_v0.a.$ === 1) && (!_v0.b.$)) {
			var _v1 = _v0.a;
			var owner = _v1.a;
			var intent = _v1.b;
			var _v2 = _v0.b.a;
			var received = _v2.a;
			var result = _v2.b;
			return (_Utils_eq(host, owner) && (_Utils_eq(
				model.a9,
				$elm$core$Maybe$Just(owner)) && _Utils_eq(received, intent))) ? $author$project$Launch$advance(
				_Utils_update(
					model,
					{
						m: A2($author$project$Launch$Settled, intent, result)
					})) : current;
		} else {
			return current;
		}
	});
var $author$project$Motion$receive = F3(
	function (binding, receipt, model) {
		return ((!_Utils_eq(
			binding,
			$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
			model.dn,
			$elm$core$Maybe$Just(receipt)))) ? model : _Utils_update(
			model,
			{
				bL: $elm$core$Maybe$Just(
					{c3: receipt.c3, aG: receipt.aG}),
				dn: $elm$core$Maybe$Nothing
			});
	});
var $author$project$MotionPreferences$Unconfirmed = 1;
var $author$project$MotionPreferences$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			return (!_Utils_eq(request, pending.cM)) ? model : (((!status) && A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (s) {
						return _Utils_eq(s.fo, pending.fo) && (A2($author$project$UInt64$compare, s.cN, pending.cN) === 2);
					},
					snapshot))) ? _Utils_update(
				model,
				{fj: 'Motion preference saved.', dn: $elm$core$Maybe$Nothing, c: snapshot}) : ((status === 1) ? _Utils_update(
				model,
				{fj: 'Motion preference refused. Refresh, then choose again.', dn: $elm$core$Maybe$Nothing}) : _Utils_update(
				model,
				{
					fj: 'Motion preference save not confirmed. Refresh to read stored values; this write will not be repeated.',
					dn: $elm$core$Maybe$Just(
						_Utils_update(
							pending,
							{cX: 1}))
				})));
		}
	});
var $author$project$Pins$Unconfirmed = function (a) {
	return {$: 1, a: a};
};
var $author$project$Pins$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (!_v0.$) {
			var pending = _v0.a;
			if (!_Utils_eq(pending.cM, request)) {
				return model;
			} else {
				if ((status === 'Saved') && A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (s) {
							return _Utils_eq(s.fa, pending.fa) && A2(
								$elm$core$Maybe$withDefault,
								false,
								A2(
									$elm$core$Maybe$map,
									function (old) {
										return A2($author$project$UInt64$compare, s.cN, old.cN) === 2;
									},
									model.c));
						},
						snapshot))) {
					return _Utils_update(
						model,
						{fj: 'Pin order saved.', dn: $elm$core$Maybe$Nothing, c: snapshot});
				} else {
					if (status === 'Refused') {
						return _Utils_update(
							model,
							{fj: 'Pin change refused. Refresh applications and choose again.', dn: $elm$core$Maybe$Nothing});
					} else {
						var confirmation = function () {
							var _v1 = pending.dL;
							if (!_v1.$) {
								return $author$project$Pins$Unconfirmed($elm$core$Maybe$Nothing);
							} else {
								var recovery = _v1.a;
								return $author$project$Pins$Unconfirmed(recovery);
							}
						}();
						return _Utils_update(
							model,
							{
								fj: 'Pin save not confirmed. Refresh applications to read the order; the change will not be repeated.',
								dn: $elm$core$Maybe$Just(
									_Utils_update(
										pending,
										{dL: confirmation}))
							});
					}
				}
			}
		} else {
			return model;
		}
	});
var $author$project$PointerOwnership$receive = F3(
	function (expected, snapshot, model) {
		if (!_Utils_eq(
			expected,
			$elm$core$Maybe$Just(snapshot.c3))) {
			return model;
		} else {
			var _v0 = model.bw;
			if (!_v0.$) {
				var prior = _v0.a;
				return (_Utils_eq(prior.c3, snapshot.c3) && (A2($author$project$UInt64$compare, snapshot.cR, prior.cR) !== 2)) ? model : {
					bw: $elm$core$Maybe$Just(snapshot)
				};
			} else {
				return {
					bw: $elm$core$Maybe$Just(snapshot)
				};
			}
		}
	});
var $author$project$Settings$Refused = 1;
var $author$project$Settings$Saved = 0;
var $author$project$Settings$Unconfirmed = 2;
var $author$project$Settings$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			return (!_Utils_eq(request, pending.cM)) ? model : (((status === 'Saved') && A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (current) {
						return _Utils_eq(current.bm, pending.bm) && A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (old) {
									return A2($author$project$UInt64$compare, current.cN, old.cN) === 2;
								},
								model.c));
					},
					snapshot))) ? _Utils_update(
				model,
				{
					fj: 'Settings saved.',
					cJ: $elm$core$Maybe$Just(
						{cM: request, dt: 0}),
					dn: $elm$core$Maybe$Nothing,
					c: snapshot
				}) : ((status === 'Refused') ? _Utils_update(
				model,
				{
					fj: 'Settings change refused. Refresh, then choose again.',
					cJ: $elm$core$Maybe$Just(
						{cM: request, dt: 1}),
					dn: $elm$core$Maybe$Nothing
				}) : _Utils_update(
				model,
				{
					fj: 'Settings save not confirmed. Refresh to read the stored values; this write will not be repeated.',
					cJ: $elm$core$Maybe$Just(
						{cM: request, dt: 2})
				})));
		}
	});
var $author$project$ShortcutPreferences$receive = F5(
	function (request, status, snapshot, inventory, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			return (!_Utils_eq(pending.cM, request)) ? model : (((status === 'Saved') && (A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (current) {
						return _Utils_eq(current.L, pending.L) && A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (old) {
									return !(!A2($author$project$UInt64$compare, current.cN, old.cN));
								},
								model.c));
					},
					snapshot)) && A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (_native) {
						return A2(
							$elm$core$List$all,
							function (route) {
								return _Utils_eq(
									A2($author$project$ShortcutPreferences$choices, route, pending.L),
									A2($author$project$ShortcutPreferences$row, route, _native).dC);
							},
							_List_fromArray(
								['applications', 'system', 'notifications']));
					},
					inventory)))) ? _Utils_update(
				model,
				{ay: _List_Nil, cH: inventory, fj: 'Shortcut choices saved and active. Existing bindings were preserved.', dn: $elm$core$Maybe$Nothing, c: snapshot}) : (((status === 'Stored') && A2(
				$elm$core$Maybe$withDefault,
				false,
				A2(
					$elm$core$Maybe$map,
					function (current) {
						return _Utils_eq(current.L, pending.L) && A2(
							$elm$core$Maybe$withDefault,
							false,
							A2(
								$elm$core$Maybe$map,
								function (old) {
									return !(!A2($author$project$UInt64$compare, current.cN, old.cN));
								},
								model.c));
					},
					snapshot))) ? _Utils_update(
				model,
				{
					ay: A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							$author$project$ShortcutPreferences$liveMatches(pending.L),
							inventory)) ? _List_Nil : model.ay,
					cH: inventory,
					fj: 'Choices saved, but live bindings changed. Refresh and choose a free shortcut before applying.',
					dn: $elm$core$Maybe$Nothing,
					c: snapshot
				}) : ((status === 'Refused') ? _Utils_update(
				model,
				{fj: 'Shortcut choices refused. Bindings or stored choices changed; refresh and choose again.', dn: $elm$core$Maybe$Nothing}) : _Utils_update(
				model,
				{
					fj: 'Shortcut application not confirmed. Refresh reads stored choices and live bindings; this action will not be repeated.',
					dn: $elm$core$Maybe$Just(
						_Utils_update(
							pending,
							{dL: 1}))
				}))));
		}
	});
var $author$project$Shortcuts$receive = F3(
	function (expected, snapshot, model) {
		if (!_Utils_eq(
			expected,
			$elm$core$Maybe$Just(snapshot.c3))) {
			return _Utils_Tuple3(model, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing);
		} else {
			if (!_Utils_eq(model.c3, expected)) {
				return _Utils_Tuple3(
					{c3: expected, bF: snapshot.cR},
					$elm$core$Maybe$Nothing,
					$elm$core$Maybe$Nothing);
			} else {
				if (A2($author$project$UInt64$compare, snapshot.cR, model.bF) !== 2) {
					return _Utils_Tuple3(model, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing);
				} else {
					var next = _Utils_update(
						model,
						{bF: snapshot.cR});
					var fresh = A2(
						$elm$core$List$filter,
						function (event) {
							return A2($author$project$UInt64$compare, event.cR, model.bF) === 2;
						},
						snapshot.bq);
					var contiguous = A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function (event) {
								return _Utils_eq(
									$author$project$UInt64$next(model.bF),
									$elm$core$Maybe$Just(event.cR));
							},
							$elm$core$List$head(fresh)));
					return snapshot.eZ ? _Utils_Tuple3(
						next,
						$elm$core$Maybe$Nothing,
						$elm$core$Maybe$Just('Shell shortcut unavailable while input is blocked.')) : ((!contiguous) ? _Utils_Tuple3(
						next,
						$elm$core$Maybe$Nothing,
						$elm$core$Maybe$Just('Shortcut history expired. Press the shortcut again.')) : _Utils_Tuple3(
						next,
						A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.ey;
							},
							$elm$core$List$head(
								$elm$core$List$reverse(fresh))),
						$elm$core$Maybe$Nothing));
				}
			}
		}
	});
var $author$project$SystemMenu$UnconfirmedReceipt = 1;
var $author$project$SystemMenu$observe = F2(
	function (current, model) {
		var admitted = function () {
			var _v0 = model.c;
			if (_v0.$ === 1) {
				return true;
			} else {
				var old = _v0.a;
				return _Utils_eq(current.cS, old.cS) && ((A2($author$project$UInt64$compare, current.cN, old.cN) === 2) || _Utils_eq(current, old));
			}
		}();
		return (!admitted) ? model : _Utils_update(
			model,
			{
				fj: (!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) ? model.fj : 'Current system state. Unavailable controls cannot be changed.',
				c: $elm$core$Maybe$Just(current)
			});
	});
var $author$project$SystemMenu$receive = F4(
	function (request, status, snapshot, model) {
		var _v0 = model.dn;
		if (_v0.$ === 1) {
			return model;
		} else {
			var pending = _v0.a;
			if ((!_Utils_eq(request, pending.cM)) || ((!A2(
				$elm$core$List$member,
				status,
				_List_fromArray(
					['Committed', 'Submitted', 'Refused', 'Unknown']))) || (!_Utils_eq(snapshot.cS, pending.af.cS)))) {
				return model;
			} else {
				var notice = _Utils_ap(
					$author$project$SystemMenu$name(pending.af.bc),
					(status === 'Committed') ? ': change observed.' : ((status === 'Submitted') ? ': request accepted by the native service.' : ((status === 'Refused') ? ': refused or no longer available. Refresh before choosing again.' : ': not confirmed. Refresh only reads state; the request will not be repeated.')));
				var next = A2($author$project$SystemMenu$observe, snapshot, model);
				return (!_Utils_eq(
					next.c,
					$elm$core$Maybe$Just(snapshot))) ? model : _Utils_update(
					next,
					{
						fj: notice,
						dn: (status === 'Unknown') ? $elm$core$Maybe$Just(
							_Utils_update(
								pending,
								{eq: 1})) : $elm$core$Maybe$Nothing
					});
			}
		}
	});
var $author$project$Desktop$PointerEntry = 0;
var $author$project$Menu$abandonPrepared = F3(
	function (local, bound, _v0) {
		var state = _v0;
		return _Utils_update(
			state,
			{
				aC: $elm$core$Maybe$Nothing,
				fn: A2(
					$elm$core$List$filter,
					function (entry) {
						return !(_Utils_eq(entry.cc, local) && (_Utils_eq(entry.c3, bound) && (!entry.bk)));
					},
					state.fn)
			});
	});
var $author$project$MenuBridge$retireChoices = function (_v0) {
	var state = _v0;
	var menu = function () {
		var _v2 = state.Q;
		if (!_v2.$) {
			var slot = _v2.a;
			return A3($author$project$Menu$abandonPrepared, slot.ch, slot.bU, state.aC);
		} else {
			return state.aC;
		}
	}();
	var closed = function () {
		var _v1 = $author$project$Menu$snapshot(menu).aC;
		if (!_v1.$) {
			var view = _v1.a;
			return A2(
				$author$project$Menu$update,
				$author$project$Menu$Dismiss(view.cc),
				menu).a;
		} else {
			return menu;
		}
	}();
	return _Utils_update(
		state,
		{aC: closed, Q: $elm$core$Maybe$Nothing});
};
var $elm$core$List$sum = function (numbers) {
	return A3($elm$core$List$foldl, $elm$core$Basics$add, 0, numbers);
};
var $author$project$Switcher$advanceSelection = function (model) {
	var through = A2(
		$elm$core$Maybe$withDefault,
		0,
		A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.cZ;
			},
			model.a5));
	var total = $elm$core$List$sum(
		A2(
			$elm$core$List$map,
			A2($elm$core$Basics$composeR, $elm$core$Tuple$second, $author$project$Switcher$delta),
			A2(
				$elm$core$List$filter,
				function (_v1) {
					var number = _v1.a;
					return _Utils_cmp(number, through) > 0;
				},
				$elm$core$Dict$toList(model.bH))));
	var ring = _Utils_eq(model.a5, $elm$core$Maybe$Nothing) ? model.du : A2(
		$elm$core$List$map,
		function ($) {
			return $.n;
		},
		model.ak);
	var size = $elm$core$List$length(ring);
	var anchor = A2(
		$elm$core$Maybe$withDefault,
		_Utils_eq(
			A2($elm$core$Dict$get, 1, model.bH),
			$elm$core$Maybe$Just(0)) ? (-1) : 0,
		function (root) {
			return A2(
				$elm$core$Maybe$map,
				$elm$core$Tuple$first,
				$elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (_v0) {
							var identity = _v0.b;
							return _Utils_eq(identity, root);
						},
						A2($elm$core$List$indexedMap, $elm$core$Tuple$pair, ring))));
		}(
			A2(
				$elm$core$Maybe$withDefault,
				A2($elm$core$Maybe$withDefault, $author$project$UInt64$zero, model.bT),
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.n;
					},
					model.a5))));
	var position = (!size) ? 0 : A2($elm$core$Basics$modBy, size, anchor + total);
	var survivor = $elm$core$List$head(
		A2(
			$elm$core$List$filter,
			function (identity) {
				return A2(
					$elm$core$List$any,
					function (row) {
						return _Utils_eq(row.n, identity);
					},
					model.ak);
			},
			_Utils_ap(
				A2($elm$core$List$drop, position, ring),
				A2($elm$core$List$take, position, ring))));
	return _Utils_update(
		model,
		{
			bG: A2(
				$elm$core$Maybe$withDefault,
				0,
				A2(
					$elm$core$Maybe$andThen,
					function (identity) {
						return A2($author$project$Switcher$index, identity, model.ak);
					},
					survivor))
		});
};
var $author$project$Switcher$step = F4(
	function (token, ordinal, direction, original) {
		var current = original;
		if ((ordinal < 1) || (ordinal > 4096)) {
			return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
		} else {
			var _v0 = A2($author$project$Switcher$prepare, token, current);
			if (_v0.$ === 1) {
				return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
			} else {
				var model = _v0.a;
				if (A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (_final) {
							return _Utils_cmp(ordinal, _final) > 0;
						},
						model.cL))) {
					return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
				} else {
					var _v1 = A2($elm$core$Dict$get, ordinal, model.bH);
					if (!_v1.$) {
						var previous = _v1.a;
						return _Utils_eq(previous, direction) ? _Utils_Tuple2(original, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
							_Utils_update(
								model,
								{ak: _List_Nil, m: 4}),
							$elm$core$Maybe$Nothing);
					} else {
						var next = _Utils_update(
							model,
							{
								bH: A3($elm$core$Dict$insert, ordinal, direction, model.bH)
							});
						return $author$project$Switcher$settle(
							next.bY ? $author$project$Switcher$advanceSelection(next) : next);
					}
				}
			}
		}
	});
var $author$project$Desktop$switcherFocus = function (model) {
	return A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		A2(
			$elm$core$Maybe$map,
			function (family) {
				return _List_fromArray(
					[
						$author$project$Desktop$Focus(
						A2(
							$author$project$Desktop$key,
							model,
							'switcher:family:' + $author$project$UInt64$string(family.n)))
					]);
			},
			$author$project$Switcher$selected(model.j)));
};
var $author$project$Switcher$readyWith = F6(
	function (frozenRoots, token, history, candidates, origin, original) {
		var model = original;
		if ((!_Utils_eq(token, model.e7)) || ((!$author$project$Switcher$writable(model)) || model.bY)) {
			return _Utils_Tuple2(original, $elm$core$Maybe$Nothing);
		} else {
			var unique = function (rows) {
				return A3(
					$elm$core$List$foldl,
					F2(
						function (row, accumulated) {
							return A2(
								$elm$core$List$any,
								function (old) {
									return _Utils_eq(old.n, row.n);
								},
								accumulated) ? accumulated : _Utils_ap(
								accumulated,
								_List_fromArray(
									[row]));
						}),
					_List_Nil,
					rows);
			};
			var eligible = A2(
				$elm$core$List$filter,
				function (row) {
					return row.c2 && A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							$elm$core$List$member(row.n),
							frozenRoots));
				},
				candidates);
			var known = unique(
				A2(
					$elm$core$List$filterMap,
					function (root) {
						return $elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (row) {
									return _Utils_eq(row.n, root);
								},
								eligible));
					},
					history));
			var unranked = A2(
				$elm$core$List$sortWith,
				F2(
					function (a, b) {
						return A2($author$project$UInt64$compare, a.n, b.n);
					}),
				unique(
					A2(
						$elm$core$List$filter,
						function (row) {
							return !A2(
								$elm$core$List$any,
								function (old) {
									return _Utils_eq(old.n, row.n);
								},
								known);
						},
						eligible)));
			var frozen = _Utils_ap(known, unranked);
			var ring = A2(
				$elm$core$Maybe$withDefault,
				A2(
					$elm$core$List$map,
					function ($) {
						return $.n;
					},
					frozen),
				A2(
					$elm$core$Maybe$map,
					function (roots) {
						return _Utils_ap(
							A2(
								$elm$core$List$filter,
								function (identity) {
									return A2($elm$core$List$member, identity, roots);
								},
								history),
							A2(
								$elm$core$List$sortWith,
								$author$project$UInt64$compare,
								A2(
									$elm$core$List$filter,
									function (identity) {
										return !A2($elm$core$List$member, identity, history);
									},
									roots)));
					},
					frozenRoots));
			return (($elm$core$List$length(candidates) > 256) || ($elm$core$List$length(ring) > 256)) ? _Utils_Tuple2(
				_Utils_update(
					model,
					{m: 4}),
				$elm$core$Maybe$Nothing) : $author$project$Switcher$settle(
				$author$project$Switcher$advanceSelection(
					_Utils_update(
						model,
						{ak: frozen, bT: origin, bY: true, du: ring})));
		}
	});
var $author$project$Switcher$readyFrozen = F2(
	function (token, roots) {
		return A2(
			$author$project$Switcher$readyWith,
			$elm$core$Maybe$Just(roots),
			token);
	});
var $author$project$Switcher$reconcile = F2(
	function (candidates, original) {
		var model = original;
		if ((!$author$project$Switcher$writable(model)) || (!model.bY)) {
			return original;
		} else {
			var prior = A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.n;
				},
				$author$project$Switcher$selected(original));
			var current = function (old) {
				return $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (row) {
							return row.c2 && (_Utils_eq(row.n, old.n) && _Utils_eq(row.c0, old.c0));
						},
						candidates));
			};
			var surviving = A2($elm$core$List$filterMap, current, model.ak);
			var after = _Utils_ap(
				A2($elm$core$List$drop, model.bG, model.ak),
				A2($elm$core$List$take, model.bG, model.ak));
			var fallback = $elm$core$List$head(
				A2(
					$elm$core$List$filterMap,
					function (old) {
						return A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.n;
							},
							current(old));
					},
					after));
			var root = A2(
				$elm$core$Maybe$withDefault,
				A2($elm$core$Maybe$withDefault, $author$project$UInt64$zero, fallback),
				A2(
					$elm$core$Maybe$andThen,
					function (identity) {
						return A2(
							$elm$core$List$any,
							function (row) {
								return _Utils_eq(row.n, identity);
							},
							surviving) ? $elm$core$Maybe$Just(identity) : $elm$core$Maybe$Nothing;
					},
					prior));
			var baseline = (model.m === 2) ? $elm$core$Maybe$Just(
				{
					n: root,
					cZ: $author$project$Switcher$lastOrdinal(model)
				}) : model.a5;
			var position = A2(
				$elm$core$Maybe$withDefault,
				0,
				A2($author$project$Switcher$index, root, surviving));
			return _Utils_update(
				model,
				{
					a5: baseline,
					ak: surviving,
					m: $elm$core$List$isEmpty(surviving) ? 4 : model.m,
					bG: position
				});
		}
	});
var $author$project$Desktop$reconcileSwitcher = F2(
	function (candidates, model) {
		var switcher = A2($author$project$Switcher$reconcile, candidates, model.j);
		var previous = A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.n;
			},
			$author$project$Switcher$selected(model.j));
		var next = _Utils_eq(switcher, model.j) ? model : $author$project$Desktop$advance(
			_Utils_update(
				model,
				{j: switcher}));
		var current = A2(
			$elm$core$Maybe$map,
			function ($) {
				return $.n;
			},
			$author$project$Switcher$selected(switcher));
		return _Utils_Tuple2(
			next,
			(!_Utils_eq(current, previous)) ? $author$project$Desktop$switcherFocus(next) : _List_Nil);
	});
var $author$project$Switcher$ready = $author$project$Switcher$readyWith($elm$core$Maybe$Nothing);
var $author$project$Desktop$syncLocalSwitcher = function (model) {
	var _v0 = _Utils_Tuple3(
		model.aO,
		model.a.b.V.av,
		$author$project$TaskView$groups(model.a.b));
	if (((!_v0.a.$) && (!_v0.b.$)) && (!_v0.c.$)) {
		var history = _v0.a.a;
		var observed = _v0.b.a;
		var groups = _v0.c.a;
		if ($author$project$Switcher$phase(model.j) === 2) {
			return A2(
				$author$project$Desktop$reconcileSwitcher,
				A2(
					$elm$core$List$concatMap,
					function ($) {
						return $.a;
					},
					groups),
				model);
		} else {
			if (!_Utils_eq(history.R, observed.R)) {
				return _Utils_eq(model.aN, $elm$core$Maybe$Nothing) ? $author$project$Desktop$readSwitcherHistory(model) : _Utils_Tuple2(model, _List_Nil);
			} else {
				var _v1 = A5(
					$author$project$Switcher$ready,
					$author$project$Switcher$generation(model.j),
					history.aL,
					A2(
						$elm$core$List$concatMap,
						function ($) {
							return $.a;
						},
						groups),
					model.cn,
					model.j);
				var switcher = _v1.a;
				var selected = _v1.b;
				var next = $author$project$Desktop$advance(
					_Utils_update(
						model,
						{j: switcher}));
				if (!selected.$) {
					var family = selected.a;
					return A2($author$project$Desktop$chooseFamily, family, next);
				} else {
					return _Utils_Tuple2(
						next,
						$author$project$Desktop$switcherFocus(next));
				}
			}
		}
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Desktop$syncSwitcher = function (model) {
	if (!$author$project$Desktop$switcherOpen(model)) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = model.an;
		if (!_v0.$) {
			var chord = _v0.a;
			var _v1 = $author$project$TaskView$groups(model.a.b);
			if (!_v1.$) {
				var groups = _v1.a;
				var candidates = A2(
					$elm$core$List$filter,
					function (row) {
						return A2($elm$core$List$member, row.n, chord.aL);
					},
					A2(
						$elm$core$List$concatMap,
						function ($) {
							return $.a;
						},
						groups));
				if ($author$project$Switcher$phase(model.j) === 2) {
					return A2($author$project$Desktop$reconcileSwitcher, candidates, model);
				} else {
					var _v2 = A6(
						$author$project$Switcher$readyFrozen,
						$author$project$Switcher$generation(model.j),
						chord.aL,
						chord.cb,
						candidates,
						chord.bT,
						model.j);
					var switcher = _v2.a;
					var selected = _v2.b;
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{j: switcher}));
					if (!selected.$) {
						var family = selected.a;
						return A2($author$project$Desktop$chooseFamily, family, next);
					} else {
						return _Utils_Tuple2(
							next,
							$author$project$Desktop$switcherFocus(next));
					}
				}
			} else {
				return _Utils_Tuple2(model, _List_Nil);
			}
		} else {
			return $author$project$Desktop$syncLocalSwitcher(model);
		}
	}
};
var $author$project$Desktop$receiveChord = F2(
	function (chord, model) {
		var old = model.an;
		var order = A2(
			$elm$core$Maybe$withDefault,
			2,
			A2(
				$elm$core$Maybe$map,
				function (previous) {
					return A2($author$project$UInt64$compare, chord.e7, previous.e7);
				},
				old));
		var inconsistent = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (previous) {
					return (order === 1) && ((!_Utils_eq(previous.aL, chord.aL)) || ((!_Utils_eq(previous.cb, chord.cb)) || ((!_Utils_eq(previous.bT, chord.bT)) || ((!_Utils_eq(
						A2(
							$elm$core$List$take,
							$elm$core$List$length(previous.bH),
							chord.bH),
						previous.bH)) || ((previous.cL && (!chord.cL)) || ((previous.cw && (!chord.cw)) || (previous.cz && (!chord.cz))))))));
				},
				old));
		var closed = function () {
			var retired = $author$project$Desktop$advance(
				$author$project$Desktop$retireSwitcher(
					_Utils_update(
						model,
						{
							s: false,
							A: false,
							o: $elm$core$Maybe$Nothing,
							u: false,
							an: $elm$core$Maybe$Just(chord),
							v: false,
							F: false,
							p: false,
							N: false,
							t: $elm$core$Maybe$Nothing,
							x: false,
							I: false
						})));
			var choice = A2(
				$elm$core$Maybe$andThen,
				function (pending) {
					return _Utils_eq(
						pending.aQ,
						$elm$core$Maybe$Just(chord.e7)) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(pending);
				},
				retired.k);
			return _Utils_Tuple2(
				_Utils_update(
					retired,
					{k: choice}),
				_List_Nil);
		}();
		if (_Utils_eq(chord.e7, $author$project$UInt64$zero) || (!order)) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			if (inconsistent || (chord.cw || chord.cz)) {
				return closed;
			} else {
				var localGeneration = (order === 2) ? $author$project$UInt64$next(
					$author$project$Switcher$generation(model.j)) : $elm$core$Maybe$Just(
					$author$project$Switcher$generation(model.j));
				if (localGeneration.$ === 1) {
					return _Utils_Tuple2(
						$author$project$Desktop$retireSwitcher(model),
						_List_Nil);
				} else {
					var generation = localGeneration.a;
					var windows = model.a;
					var base = (order === 2) ? _Utils_update(
						model,
						{
							k: $elm$core$Maybe$Nothing,
							D: '',
							y: $elm$core$Maybe$Nothing,
							s: false,
							A: false,
							o: $elm$core$Maybe$Nothing,
							u: false,
							E: $elm$core$Maybe$Nothing,
							an: $elm$core$Maybe$Just(chord),
							v: false,
							F: false,
							q: false,
							l: false,
							bh: 0,
							r: $elm$core$Maybe$Nothing,
							p: false,
							N: false,
							aN: $elm$core$Maybe$Nothing,
							aO: $elm$core$Maybe$Nothing,
							t: $elm$core$Maybe$Nothing,
							x: false,
							I: false,
							a: _Utils_update(
								windows,
								{
									i: $author$project$MenuBridge$retireChoices(windows.i),
									G: $elm$core$Maybe$Nothing
								})
						}) : _Utils_update(
						model,
						{
							s: false,
							A: false,
							o: $elm$core$Maybe$Nothing,
							u: false,
							an: $elm$core$Maybe$Just(chord),
							v: false,
							F: false,
							p: false,
							N: false,
							t: $elm$core$Maybe$Nothing,
							x: false,
							I: false
						});
					var _v1 = A3(
						$elm$core$List$foldl,
						F2(
							function (_v2, _v3) {
								var ordinal = _v2.a;
								var direction = _v2.b;
								var state = _v3.a;
								return A4($author$project$Switcher$step, generation, ordinal + 1, direction, state);
							}),
						_Utils_Tuple2(base.j, $elm$core$Maybe$Nothing),
						A2($elm$core$List$indexedMap, $elm$core$Tuple$pair, chord.bH));
					var stepped = _v1.a;
					var _v4 = chord.cL ? A3(
						$author$project$Switcher$release,
						generation,
						$elm$core$List$length(chord.bH),
						stepped) : _Utils_Tuple2(stepped, $elm$core$Maybe$Nothing);
					var released = _v4.a;
					var selected = _v4.b;
					var next = $author$project$Desktop$advance(
						_Utils_update(
							base,
							{j: released}));
					if (!selected.$) {
						var family = selected.a;
						return A2($author$project$Desktop$chooseFamily, family, next);
					} else {
						var previous = A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.n;
							},
							$author$project$Switcher$selected(model.j));
						var _v6 = $author$project$Desktop$syncSwitcher(next);
						var synced = _v6.a;
						var effects = _v6.b;
						var alreadyFocused = A2(
							$elm$core$List$any,
							function (effect) {
								if (effect.$ === 5) {
									return true;
								} else {
									return false;
								}
							},
							effects);
						var current = A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.n;
							},
							$author$project$Switcher$selected(synced.j));
						var focused = (($author$project$Switcher$phase(synced.j) === 2) && (((order === 2) || (!_Utils_eq(current, previous))) && (!alreadyFocused))) ? _Utils_ap(
							effects,
							$author$project$Desktop$switcherFocus(synced)) : effects;
						if ((order === 2) && (!$author$project$Shell$available(next.a.b))) {
							var _v7 = A2(
								$author$project$Desktop$windowBase,
								$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
								synced);
							var refreshing = _v7.a;
							var reads = _v7.b;
							return _Utils_Tuple2(
								refreshing,
								_Utils_ap(focused, reads));
						} else {
							return _Utils_Tuple2(synced, focused);
						}
					}
				}
			}
		}
	});
var $author$project$Notifications$OutcomeDispatched = 0;
var $author$project$Notifications$OutcomeUnknown = 2;
var $author$project$Notifications$OutcomeRefused = 1;
var $author$project$Notifications$outcomeStatus = function (status) {
	switch (status) {
		case 'Dispatched':
			return $elm$core$Maybe$Just(0);
		case 'Refused':
			return $elm$core$Maybe$Just(1);
		case 'Unknown':
			return $elm$core$Maybe$Just(2);
		default:
			return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Notifications$receiveReason = F5(
	function (request, status, reason, current, model) {
		var _v0 = _Utils_Tuple2(
			model.dn,
			$author$project$Notifications$outcomeStatus(status));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var pending = _v0.a.a;
			var outcomeStatusValue = _v0.b.a;
			if ((!_Utils_eq(request, pending.cM)) || (!_Utils_eq(current.cS, pending.fK.cS))) {
				return model;
			} else {
				var observed = A2($author$project$Notifications$observe, current, model);
				var expired = (reason === 'expired') || A2(
					$elm$core$Maybe$withDefault,
					pending.bN,
					A2(
						$elm$core$Maybe$map,
						function ($) {
							return $.bN;
						},
						observed.dn));
				var outcome = $elm$core$Maybe$Just(
					{bN: expired, cM: request, O: outcomeStatusValue, fK: pending.fK});
				return (!_Utils_eq(
					observed.c,
					$elm$core$Maybe$Just(current))) ? model : ((outcomeStatusValue === 2) ? _Utils_update(
					observed,
					{fj: 'Notification action not confirmed. It will not be repeated.', cJ: outcome}) : _Utils_update(
					observed,
					{
						fj: (!outcomeStatusValue) ? 'Notification action sent.' : 'Notification action refused. The target expired or changed; choose a current notification.',
						cJ: outcome,
						dn: $elm$core$Maybe$Nothing
					}));
			}
		} else {
			return model;
		}
	});
var $author$project$Files$reconcile = F2(
	function (snapshot, model) {
		var next = A2($author$project$Files$observe, snapshot, model);
		var _v0 = next.dn;
		if (_v0.$ === 1) {
			return next;
		} else {
			var pending = _v0.a;
			return (_Utils_eq(
				next.c,
				$elm$core$Maybe$Just(snapshot)) && (A2($author$project$UInt64$compare, snapshot.cN, pending.af.cN) === 2)) ? _Utils_update(
				next,
				{fj: 'Files state refreshed. The previous request will not be repeated.', dn: $elm$core$Maybe$Nothing}) : next;
		}
	});
var $author$project$JumpList$reconcile = F2(
	function (snapshot, model) {
		var next = A2($author$project$JumpList$observe, snapshot, model);
		var _v0 = next.dn;
		if (_v0.$ === 1) {
			return next;
		} else {
			var pending = _v0.a;
			return (_Utils_eq(
				next.c,
				$elm$core$Maybe$Just(snapshot)) && (A2($author$project$UInt64$compare, snapshot.cN, pending.af.cN) === 2)) ? _Utils_update(
				next,
				{fj: 'Application actions refreshed. The previous request will not be repeated.', dn: $elm$core$Maybe$Nothing}) : next;
		}
	});
var $author$project$Notifications$reconcile = F2(
	function (snapshot, model) {
		var current = A2($author$project$Notifications$observe, snapshot, model);
		var _v0 = current.dn;
		if (_v0.$ === 1) {
			return current;
		} else {
			var pending = _v0.a;
			return (_Utils_eq(
				current.c,
				$elm$core$Maybe$Just(snapshot)) && (!A2(
				$elm$core$List$any,
				function (row) {
					return _Utils_eq(row.cc, pending.fK.cc) && (_Utils_eq(row.au, pending.fK.au) && (_Utils_eq(row.ag, pending.fK.ag) && (!row.cX)));
				},
				snapshot.ak))) ? _Utils_update(
				current,
				{fj: 'Notification target is no longer live. Its action will not be repeated.', dn: $elm$core$Maybe$Nothing}) : current;
		}
	});
var $author$project$SystemMenu$reconcile = F2(
	function (snapshot, model) {
		var next = A2($author$project$SystemMenu$observe, snapshot, model);
		var _v0 = next.dn;
		if (_v0.$ === 1) {
			return next;
		} else {
			var pending = _v0.a;
			return (_Utils_eq(
				next.c,
				$elm$core$Maybe$Just(snapshot)) && (A2($author$project$UInt64$compare, snapshot.cN, pending.af.cN) === 2)) ? _Utils_update(
				next,
				{fj: 'System state refreshed. The previous request will not be repeated.', dn: $elm$core$Maybe$Nothing}) : next;
		}
	});
var $author$project$WorkspaceNavigation$recover = function (model) {
	var _v0 = _Utils_Tuple2(model.c3, model.fz);
	if ((!_v0.a.$) && (!_v0.b.$)) {
		var binding = _v0.a.a;
		var r = _v0.b.a;
		return ((r.O === 1) && ((!model.er) && model.bY)) ? _Utils_Tuple2(
			_Utils_update(
				model,
				{er: true}),
			$elm$core$Maybe$Just(
				A3($author$project$WorkspaceNavigation$wire, 'workspace-navigation-recover', binding, _List_Nil))) : _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
	} else {
		return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
	}
};
var $author$project$Pins$Saving = {$: 0};
var $author$project$Pins$rejectUnsent = F2(
	function (request, model) {
		var _v0 = model.dn;
		if (!_v0.$) {
			var pending = _v0.a;
			return (_Utils_eq(pending.cM, request) && _Utils_eq(pending.dL, $author$project$Pins$Saving)) ? _Utils_update(
				model,
				{fj: 'Pin change was not sent. Refine the view or refresh applications and choose again.', dn: $elm$core$Maybe$Nothing}) : model;
		} else {
			return model;
		}
	});
var $author$project$Pins$readStarted = F2(
	function (request, model) {
		var _v0 = model.dn;
		if (!_v0.$) {
			var pending = _v0.a;
			var _v1 = pending.dL;
			if (!_v1.$) {
				return model;
			} else {
				return (A2($author$project$UInt64$compare, request, pending.cM) !== 2) ? model : _Utils_update(
					model,
					{
						dn: $elm$core$Maybe$Just(
							_Utils_update(
								pending,
								{
									dL: $author$project$Pins$Unconfirmed(
										$elm$core$Maybe$Just(request))
								}))
					});
			}
		} else {
			return model;
		}
	});
var $author$project$Desktop$requestApplications = F3(
	function (opening, stamp, model) {
		if ((!_Utils_eq(
			$author$project$Desktop$capture(model),
			$elm$core$Maybe$Just(stamp))) || (!_Utils_eq(
			$author$project$MenuBridge$preparedSnapshot(model.a.i),
			$elm$core$Maybe$Nothing))) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var base = function () {
				var _v1 = $author$project$MenuBridge$menuSnapshot(model.a.i).aC;
				if (_v1.$ === 1) {
					return model;
				} else {
					var menu = _v1.a;
					return A2(
						$author$project$Desktop$windowBase,
						$author$project$TaskbarShell$MenuEvent(
							$author$project$Menu$Dismiss(menu.cc)),
						model).a;
				}
			}();
			var windows = base.a;
			var retired = $author$project$Desktop$advance(
				$author$project$Desktop$retireSwitcher(
					_Utils_update(
						base,
						{
							ai: 0,
							aj: $elm$core$Maybe$Nothing,
							bn: $elm$core$Maybe$Nothing,
							bo: opening,
							y: $elm$core$Maybe$Nothing,
							s: false,
							A: false,
							o: $elm$core$Maybe$Nothing,
							u: false,
							B: A2($author$project$Launch$catalog, $elm$json$Json$Encode$null, model.B),
							E: $elm$core$Maybe$Nothing,
							v: false,
							F: false,
							q: true,
							l: false,
							r: $elm$core$Maybe$Nothing,
							p: false,
							N: false,
							w: $elm$core$Maybe$Nothing,
							t: $elm$core$Maybe$Nothing,
							x: false,
							I: false,
							a: _Utils_update(
								windows,
								{G: $elm$core$Maybe$Nothing})
						})));
			var _v0 = _Utils_Tuple2(
				model.a.b.c3,
				$author$project$UInt64$next(model.cM));
			if ((!_v0.a.$) && (!_v0.b.$)) {
				var binding = _v0.a.a;
				var request = _v0.b.a;
				return ((!model.a.b.m) || _Utils_eq(retired.aF, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(retired, _List_Nil) : _Utils_Tuple2(
					_Utils_update(
						retired,
						{
							y: $elm$core$Maybe$Just(request),
							H: A2($author$project$Pins$readStarted, request, retired.H),
							cM: request
						}),
					_Utils_ap(
						_List_fromArray(
							[
								A2($author$project$Desktop$catalogRequest, binding, request)
							]),
						opening ? _List_fromArray(
							[
								$author$project$Desktop$Focus('launcher-search')
							]) : _List_Nil));
			} else {
				return _Utils_Tuple2(retired, _List_Nil);
			}
		}
	});
var $author$project$OverviewRecovery$Returning = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $author$project$OverviewRecovery$observe = F5(
	function (authority, transaction, occupied, ready, model) {
		var origin = function () {
			switch (model.$) {
				case 0:
					return $elm$core$Maybe$Nothing;
				case 1:
					var owner = model.a;
					return $elm$core$Maybe$Just(owner);
				case 2:
					var owner = model.a;
					return $elm$core$Maybe$Just(owner);
				default:
					var owner = model.a;
					return $elm$core$Maybe$Just(owner);
			}
		}();
		var matched = function () {
			var _v2 = _Utils_Tuple2(model, transaction);
			if ((_v2.a.$ === 2) && (!_v2.b.$)) {
				var _v3 = _v2.a;
				var owner = _v3.a;
				var intent = _v3.b;
				var outcome = _v2.b.a;
				if (!_Utils_eq(outcome.af, intent)) {
					return model;
				} else {
					var _v4 = outcome.O;
					switch (_v4) {
						case 2:
							return A2($author$project$OverviewRecovery$Returning, owner, intent);
						case 1:
							return $author$project$OverviewRecovery$Idle;
						case 3:
							return $author$project$OverviewRecovery$Idle;
						default:
							return model;
					}
				}
			} else {
				return model;
			}
		}();
		if (occupied || A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (owner) {
					return !_Utils_eq(
						authority,
						$elm$core$Maybe$Just(owner.c3));
				},
				origin))) {
			return _Utils_Tuple2($author$project$OverviewRecovery$Idle, $elm$core$Maybe$Nothing);
		} else {
			if (matched.$ === 3) {
				var owner = matched.a;
				var intent = matched.b;
				if (!transaction.$) {
					var current = transaction.a;
					return ((!_Utils_eq(current.af, intent)) || (current.O !== 2)) ? _Utils_Tuple2($author$project$OverviewRecovery$Idle, $elm$core$Maybe$Nothing) : (ready ? _Utils_Tuple2(
						$author$project$OverviewRecovery$Idle,
						$elm$core$Maybe$Just(owner)) : _Utils_Tuple2(matched, $elm$core$Maybe$Nothing));
				} else {
					return _Utils_Tuple2($author$project$OverviewRecovery$Idle, $elm$core$Maybe$Nothing);
				}
			} else {
				return _Utils_Tuple2(matched, $elm$core$Maybe$Nothing);
			}
		}
	});
var $author$project$Desktop$resumeOverview = function (model) {
	var occupied = model.l || (model.q || ((!_Utils_eq(model.w, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(model.o, $elm$core$Maybe$Nothing)) || (model.s || (model.x || (model.v || (model.p || ($author$project$Desktop$switcherOpen(model) || ((!_Utils_eq(model.a.G, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(
		$author$project$MenuBridge$menuSnapshot(model.a.i).aC,
		$elm$core$Maybe$Nothing)) || (!_Utils_eq(
		$author$project$MenuBridge$preparedSnapshot(model.a.i),
		$elm$core$Maybe$Nothing))))))))))));
	var groups = $author$project$Desktop$taskViewGroups(model);
	var ready = $author$project$Shell$available(model.a.b) && (_Utils_eq(model.a.b.y, $elm$core$Maybe$Nothing) && (_Utils_eq(model.a.b.cE, $elm$core$Maybe$Nothing) && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && ((!_Utils_eq(model.aF, $elm$core$Maybe$Nothing)) && ((!_Utils_eq(groups, $elm$core$Maybe$Nothing)) && (!A2($author$project$PointerOwnership$blocked, model.a.b.c3, model.bz)))))));
	var authority = A2(
		$elm$core$List$member,
		model.a.b.m,
		_List_fromArray(
			[0, 3])) ? $elm$core$Maybe$Nothing : model.a.b.c3;
	var _v0 = A5($author$project$OverviewRecovery$observe, authority, model.a.b.V.dz, occupied, ready, model.aE);
	var recovery = _v0.a;
	var origin = _v0.b;
	var next = _Utils_update(
		model,
		{aE: recovery});
	if (origin.$ === 1) {
		return _Utils_Tuple2(next, _List_Nil);
	} else {
		var owner = origin.a;
		var current = A2($elm$core$Maybe$withDefault, _List_Nil, groups);
		var workspace = A2(
			$elm$core$Maybe$andThen,
			function (selected) {
				return A2(
					$elm$core$List$any,
					function (group) {
						return _Utils_eq(group.cG, selected);
					},
					current) ? $elm$core$Maybe$Just(selected) : $elm$core$Maybe$Nothing;
			},
			owner.dB);
		var family = A2(
			$elm$core$List$any,
			function (row) {
				return _Utils_eq(row.n, owner.n) && (row.c2 && (!A3($author$project$MenuBridge$blockedFor, row.n, model.a.b, model.a.i)));
			},
			A2(
				$elm$core$List$concatMap,
				function ($) {
					return $.a;
				},
				A2(
					$elm$core$List$filter,
					function (group) {
						return _Utils_eq(workspace, $elm$core$Maybe$Nothing) || _Utils_eq(
							workspace,
							$elm$core$Maybe$Just(group.cG));
					},
					current)));
		var reopened = $author$project$Desktop$advance(
			_Utils_update(
				next,
				{l: true, Z: $elm$core$Maybe$Nothing, T: workspace, r: $elm$core$Maybe$Nothing}));
		var target = family ? ('overview:family:' + $author$project$UInt64$string(owner.n)) : A2(
			$elm$core$Maybe$withDefault,
			'overview:all',
			A2(
				$elm$core$Maybe$map,
				$elm$core$Basics$append('overview:workspace:'),
				workspace));
		return (reopened.l && (!_Utils_eq(reopened.aF, $elm$core$Maybe$Nothing))) ? _Utils_Tuple2(
			reopened,
			_List_fromArray(
				[
					$author$project$Desktop$Focus(
					A2($author$project$Desktop$key, reopened, target))
				])) : _Utils_Tuple2(reopened, _List_Nil);
	}
};
var $author$project$Desktop$resumeWorkspaceOverview = function (model) {
	var ready = $author$project$Shell$available(model.a.b) && (_Utils_eq(model.a.b.y, $elm$core$Maybe$Nothing) && (_Utils_eq(model.a.b.cE, $elm$core$Maybe$Nothing) && (_Utils_eq(model.k, $elm$core$Maybe$Nothing) && (!_Utils_eq(
		$author$project$Desktop$taskViewGroups(model),
		$elm$core$Maybe$Nothing)))));
	var navigation = model.J;
	if ((!navigation.ex) || (!ready)) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var selected = A2(
			$elm$core$Maybe$andThen,
			function (id) {
				return A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						$elm$core$List$any(
							function (g) {
								return _Utils_eq(g.cG, id);
							}),
						$author$project$Desktop$taskViewGroups(model))) ? $elm$core$Maybe$Just(id) : $elm$core$Maybe$Nothing;
			},
			navigation.bT);
		var next = $author$project$Desktop$advance(
			_Utils_update(
				model,
				{
					l: true,
					T: selected,
					r: $elm$core$Maybe$Nothing,
					J: _Utils_update(
						navigation,
						{bT: $elm$core$Maybe$Nothing, ex: false})
				}));
		return _Utils_Tuple2(
			next,
			_List_fromArray(
				[
					$author$project$Desktop$Focus(
					A2(
						$author$project$Desktop$key,
						next,
						A2(
							$elm$core$Maybe$withDefault,
							'overview:all',
							A2(
								$elm$core$Maybe$map,
								$elm$core$Basics$append('overview:workspace:'),
								selected))))
				]));
	}
};
var $author$project$OverviewRecovery$retainedOrigin = F3(
	function (authority, transaction, model) {
		var _v0 = _Utils_Tuple2(model, transaction);
		_v0$2:
		while (true) {
			if (!_v0.b.$) {
				switch (_v0.a.$) {
					case 2:
						var _v1 = _v0.a;
						var origin = _v1.a;
						var intent = _v1.b;
						var current = _v0.b.a;
						return (_Utils_eq(
							authority,
							$elm$core$Maybe$Just(origin.c3)) && (_Utils_eq(current.af, intent) && A2(
							$elm$core$List$member,
							current.O,
							_List_fromArray(
								[0, 4])))) ? $elm$core$Maybe$Just(origin) : $elm$core$Maybe$Nothing;
					case 3:
						var _v2 = _v0.a;
						var origin = _v2.a;
						var intent = _v2.b;
						var current = _v0.b.a;
						return (_Utils_eq(
							authority,
							$elm$core$Maybe$Just(origin.c3)) && (_Utils_eq(current.af, intent) && (current.O === 2))) ? $elm$core$Maybe$Just(origin) : $elm$core$Maybe$Nothing;
					default:
						break _v0$2;
				}
			} else {
				break _v0$2;
			}
		}
		return $elm$core$Maybe$Nothing;
	});
var $author$project$Pins$encode = function (snapshot) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'revision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(snapshot.cN))),
				_Utils_Tuple2(
				'identities',
				A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, snapshot.fa))
			]));
};
var $author$project$Pins$propose = F3(
	function (request, values, model) {
		var _v0 = model.c;
		if (!_v0.$) {
			var snapshot = _v0.a;
			return ((!$author$project$Pins$writable(model)) || ((!$author$project$Pins$valid(values)) || _Utils_eq(values, snapshot.fa))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
				_Utils_update(
					model,
					{
						fj: 'Saving pin order…',
						dn: $elm$core$Maybe$Just(
							{dL: $author$project$Pins$Saving, fa: values, cM: request})
					}),
				$elm$core$Maybe$Just(
					$author$project$Pins$encode(
						_Utils_update(
							snapshot,
							{fa: values}))));
		} else {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$Desktop$savePins = F2(
	function (values, model) {
		var _v0 = _Utils_Tuple2(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			var wire = function (p) {
				return $elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'protocolVersion',
							$elm$json$Json$Encode$int(3)),
							_Utils_Tuple2(
							'kind',
							$elm$json$Json$Encode$string('taskbar-pins-write')),
							_Utils_Tuple2(
							'binding',
							$author$project$Binding$encode(binding)),
							_Utils_Tuple2(
							'requestId',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(request))),
							_Utils_Tuple2('proposal', p)
						]));
			};
			var _v1 = A3($author$project$Pins$propose, request, values, model.H);
			var pins = _v1.a;
			var proposal = _v1.b;
			if (!proposal.$) {
				var p = proposal.a;
				return ($author$project$Pins$bytes(
					A2(
						$elm$json$Json$Encode$encode,
						0,
						wire(p))) > 4095) ? _Utils_Tuple2(
					_Utils_update(
						model,
						{
							H: _Utils_update(
								pins,
								{fj: 'Pin order is too large to save.', dn: $elm$core$Maybe$Nothing})
						}),
					_List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{H: pins, cM: request})),
					_List_fromArray(
						[
							$author$project$Desktop$Send(
							wire(p))
						]));
			} else {
				return _Utils_Tuple2(model, _List_Nil);
			}
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	});
var $author$project$Desktop$ReceiptRefused = 1;
var $author$project$Desktop$ReceiptSaved = 0;
var $author$project$Desktop$ReceiptUnknown = 2;
var $author$project$Desktop$saveReceiptDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (raw) {
		switch (raw) {
			case 'Saved':
				return $elm$json$Json$Decode$succeed(0);
			case 'Refused':
				return $elm$json$Json$Decode$succeed(1);
			case 'Unknown':
				return $elm$json$Json$Decode$succeed(2);
			default:
				return $elm$json$Json$Decode$fail('Save receipt status');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Desktop$saveReceiptName = function (status) {
	switch (status) {
		case 0:
			return 'Saved';
		case 1:
			return 'Refused';
		default:
			return 'Unknown';
	}
};
var $author$project$Snap$select = F3(
	function (current, region, choice) {
		return A2($author$project$Snap$valid, current, choice) ? $elm$core$Maybe$Just(
			_Utils_update(
				choice,
				{bG: region})) : $elm$core$Maybe$Nothing;
	});
var $author$project$Files$Awaiting = 0;
var $author$project$Files$propose = F3(
	function (request, value, model) {
		return (_Utils_eq(request, $author$project$UInt64$zero) || (!A2($author$project$Files$supported, value, model))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
			_Utils_update(
				model,
				{
					fj: 'Files: waiting for the requested location…',
					dn: $elm$core$Maybe$Just(
						{dL: 0, af: value, cM: request}),
					b1: A2(
						$elm$core$List$take,
						128,
						A2($elm$core$List$cons, value, model.b1))
				}),
			$elm$core$Maybe$Just(
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'service',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(value.cS))),
							_Utils_Tuple2(
							'revision',
							$elm$json$Json$Encode$string(
								$author$project$UInt64$string(value.cN))),
							_Utils_Tuple2(
							'target',
							$elm$json$Json$Encode$string(value.fK))
						]))));
	});
var $author$project$Desktop$sendFiles = F2(
	function (target, model) {
		if (!_Utils_eq(model.aR, $elm$core$Maybe$Nothing)) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var _v0 = _Utils_Tuple2(
				model.a.b.c3,
				$author$project$UInt64$next(model.cM));
			if ((!_v0.a.$) && (!_v0.b.$)) {
				var binding = _v0.a.a;
				var request = _v0.b.a;
				var _v1 = A3($author$project$Files$propose, request, target, model.W);
				var files = _v1.a;
				var proposal = _v1.b;
				if (proposal.$ === 1) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var value = proposal.a;
					return _Utils_Tuple2(
						$author$project$Desktop$advance(
							_Utils_update(
								model,
								{W: files, s: false, A: false, o: $elm$core$Maybe$Nothing, u: false, cM: request})),
						_List_fromArray(
							[
								$author$project$Desktop$Send(
								$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'protocolVersion',
											$elm$json$Json$Encode$int(3)),
											_Utils_Tuple2(
											'kind',
											$elm$json$Json$Encode$string('files-open')),
											_Utils_Tuple2(
											'binding',
											$author$project$Binding$encode(binding)),
											_Utils_Tuple2(
											'requestId',
											$elm$json$Json$Encode$string(
												$author$project$UInt64$string(request))),
											_Utils_Tuple2('intent', value)
										])))
							]));
				}
			} else {
				return _Utils_Tuple2(model, _List_Nil);
			}
		}
	});
var $author$project$SystemMenu$AwaitingReceipt = 0;
var $author$project$SystemMenu$encode = function (value) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'service',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.cS))),
				_Utils_Tuple2(
				'revision',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(value.cN))),
				_Utils_Tuple2(
				'operation',
				$elm$json$Json$Encode$string(
					$author$project$SystemMenu$code(value.bc))),
				_Utils_Tuple2(
				'value',
				$elm$json$Json$Encode$int(value.ab))
			]));
};
var $author$project$SystemMenu$propose = F3(
	function (request, value, model) {
		return ((!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) || (!A2($author$project$SystemMenu$supported, value, model))) ? _Utils_Tuple2(model, $elm$core$Maybe$Nothing) : _Utils_Tuple2(
			_Utils_update(
				model,
				{
					fj: $author$project$SystemMenu$name(value.bc) + ': waiting for native result…',
					dn: $elm$core$Maybe$Just(
						{af: value, eq: 0, cM: request}),
					b1: A2(
						$elm$core$List$take,
						128,
						A2($elm$core$List$cons, value, model.b1))
				}),
			$elm$core$Maybe$Just(
				$author$project$SystemMenu$encode(value)));
	});
var $author$project$Desktop$sendSystemChange = F2(
	function (intent, model) {
		var _v0 = _Utils_Tuple2(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			var _v1 = A3($author$project$SystemMenu$propose, request, intent, model.aq);
			var menu = _v1.a;
			var proposal = _v1.b;
			if (proposal.$ === 1) {
				return _Utils_Tuple2(model, _List_Nil);
			} else {
				var value = proposal.a;
				return _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{cM: request, aq: menu, t: $elm$core$Maybe$Nothing})),
					_List_fromArray(
						[
							$author$project$Desktop$Send(
							$elm$json$Json$Encode$object(
								_List_fromArray(
									[
										_Utils_Tuple2(
										'protocolVersion',
										$elm$json$Json$Encode$int(3)),
										_Utils_Tuple2(
										'kind',
										$elm$json$Json$Encode$string('system-menu-effect')),
										_Utils_Tuple2(
										'binding',
										$author$project$Binding$encode(binding)),
										_Utils_Tuple2(
										'requestId',
										$elm$json$Json$Encode$string(
											$author$project$UInt64$string(request))),
										_Utils_Tuple2('intent', value)
									])))
						]));
			}
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	});
var $author$project$Desktop$ShortcutRefused = 2;
var $author$project$Desktop$ShortcutSaved = 0;
var $author$project$Desktop$ShortcutStored = 1;
var $author$project$Desktop$ShortcutUnknown = 3;
var $author$project$Desktop$shortcutSaveReceiptDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (raw) {
		switch (raw) {
			case 'Saved':
				return $elm$json$Json$Decode$succeed(0);
			case 'Stored':
				return $elm$json$Json$Decode$succeed(1);
			case 'Refused':
				return $elm$json$Json$Decode$succeed(2);
			case 'Unknown':
				return $elm$json$Json$Decode$succeed(3);
			default:
				return $elm$json$Json$Decode$fail('Shortcut receipt status');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$Desktop$shortcutSaveReceiptName = function (status) {
	switch (status) {
		case 0:
			return 'Saved';
		case 1:
			return 'Stored';
		case 2:
			return 'Refused';
		default:
			return 'Unknown';
	}
};
var $author$project$Launch$Pending = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $author$project$Catalog$intent = F3(
	function (request, entry, _v0) {
		var lifetime = _v0.a;
		var generation = _v0.b;
		var values = _v0.c;
		return (_Utils_eq(request, $author$project$UInt64$zero) || (!A2(
			$elm$core$Dict$member,
			$author$project$Catalog$id(entry),
			values))) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'request',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(request))),
						_Utils_Tuple2(
						'lifetime',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(lifetime))),
						_Utils_Tuple2(
						'generation',
						$elm$json$Json$Encode$string(
							$author$project$UInt64$string(generation))),
						_Utils_Tuple2(
						'entry',
						$elm$json$Json$Encode$string(
							$author$project$Catalog$id(entry)))
					])));
	});
var $author$project$Launch$start = F2(
	function (_v0, current) {
		var host = _v0.a;
		var revision = _v0.b;
		var lifetime = _v0.c;
		var generation = _v0.d;
		var entry = _v0.e;
		var model = current;
		var ready = function () {
			var _v3 = model.m;
			switch (_v3.$) {
				case 0:
					return true;
				case 2:
					if (_v3.b === 2) {
						var _v4 = _v3.b;
						return false;
					} else {
						return true;
					}
				default:
					return false;
			}
		}();
		var _v1 = _Utils_Tuple2(
			model.c,
			$author$project$UInt64$next(model.cM));
		if ((!_v1.a.$) && (!_v1.b.$)) {
			var snapshot = _v1.a.a;
			var request = _v1.b.a;
			var scope = $author$project$Catalog$scope(snapshot);
			if (ready && (_Utils_eq(
				model.a9,
				$elm$core$Maybe$Just(host)) && (_Utils_eq(model.cN, revision) && (_Utils_eq(lifetime, scope.fe) && _Utils_eq(generation, scope.e7))))) {
				var _v2 = A3($author$project$Catalog$intent, request, entry, snapshot);
				if (!_v2.$) {
					var wire = _v2.a;
					return _Utils_Tuple2(
						$author$project$Launch$advance(
							_Utils_update(
								model,
								{
									m: A2(
										$author$project$Launch$Pending,
										host,
										{
											dQ: $author$project$Catalog$id(entry),
											e7: generation,
											fe: lifetime,
											cM: request
										}),
									cM: request
								})),
						$elm$core$Maybe$Just(wire));
				} else {
					return _Utils_Tuple2(current, $elm$core$Maybe$Nothing);
				}
			} else {
				return _Utils_Tuple2(current, $elm$core$Maybe$Nothing);
			}
		} else {
			return _Utils_Tuple2(current, $elm$core$Maybe$Nothing);
		}
	});
var $author$project$Motion$request = function (pending) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'protocolVersion',
				$elm$json$Json$Encode$int(3)),
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('motion-profile-set')),
				_Utils_Tuple2(
				'binding',
				$author$project$Binding$encode(pending.c3)),
				_Utils_Tuple2(
				'requestId',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(pending.cM))),
				_Utils_Tuple2(
				'profile',
				$elm$json$Json$Encode$string(
					$author$project$Motion$name(pending.aG)))
			]));
};
var $author$project$Motion$propose = F3(
	function (binding, request_, model) {
		if ((!_Utils_eq(model.dn, $elm$core$Maybe$Nothing)) || (_Utils_eq(request_, $author$project$UInt64$zero) || (_Utils_eq(model.aY.c, $elm$core$Maybe$Nothing) || ((_Utils_eq(model.bw, $elm$core$Maybe$Nothing) && (!$author$project$MotionPreferences$selected(model.aY))) || A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (a) {
					return _Utils_eq(a.c3, binding) && _Utils_eq(
						a.aG,
						$author$project$Motion$desired(model));
				},
				model.bL)))))) {
			return _Utils_Tuple2(model, $elm$core$Maybe$Nothing);
		} else {
			var pending = {
				c3: binding,
				aG: $author$project$Motion$desired(model),
				cM: request_
			};
			return _Utils_Tuple2(
				_Utils_update(
					model,
					{
						dn: $elm$core$Maybe$Just(pending)
					}),
				$elm$core$Maybe$Just(
					$author$project$Motion$request(pending)));
		}
	});
var $author$project$Desktop$syncMotion = function (model) {
	if (model.a.b.c1 || ((!model.a.b.m) || (model.a.b.m === 3))) {
		return _Utils_Tuple2(model, _List_Nil);
	} else {
		var _v0 = _Utils_Tuple2(
			model.a.b.c3,
			$author$project$UInt64$next(model.cM));
		if ((!_v0.a.$) && (!_v0.b.$)) {
			var binding = _v0.a.a;
			var request = _v0.b.a;
			var _v1 = A3($author$project$Motion$propose, binding, request, model.M);
			var motion = _v1.a;
			var command = _v1.b;
			if (command.$ === 1) {
				return _Utils_Tuple2(model, _List_Nil);
			} else {
				var wire = command.a;
				return _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{M: motion, cM: request})),
					_List_fromArray(
						[
							$author$project$Desktop$Send(wire)
						]));
			}
		} else {
			return _Utils_Tuple2(model, _List_Nil);
		}
	}
};
var $author$project$Desktop$syncOverviewWorkspace = function (model) {
	var _v0 = _Utils_Tuple3(
		model.l,
		model.T,
		$author$project$Desktop$taskViewGroups(model));
	if (_v0.a && (!_v0.c.$)) {
		var selected = _v0.b;
		var groups = _v0.c.a;
		var workspacePresent = A2(
			$elm$core$Maybe$withDefault,
			true,
			A2(
				$elm$core$Maybe$map,
				function (identity) {
					return A2(
						$elm$core$List$any,
						function (group) {
							return _Utils_eq(group.cG, identity);
						},
						groups);
				},
				selected));
		var transferRetired = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (root) {
					return !A2(
						$elm$core$List$any,
						function (family) {
							return _Utils_eq(family.n, root);
						},
						A2(
							$elm$core$List$concatMap,
							function ($) {
								return $.a;
							},
							groups));
				},
				model.Z));
		if (workspacePresent && (!transferRetired)) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var workspace = workspacePresent ? selected : $elm$core$Maybe$Nothing;
			var target = A2(
				$elm$core$Maybe$withDefault,
				'overview:all',
				A2(
					$elm$core$Maybe$map,
					$elm$core$Basics$append('overview:workspace:'),
					workspace));
			var next = $author$project$Desktop$advance(
				_Utils_update(
					model,
					{Z: $elm$core$Maybe$Nothing, T: workspace}));
			return _Utils_Tuple2(
				next,
				_List_fromArray(
					[
						$author$project$Desktop$Focus(
						A2($author$project$Desktop$key, next, target))
					]));
		}
	} else {
		return _Utils_Tuple2(model, _List_Nil);
	}
};
var $author$project$Pins$toggle = F2(
	function (identity, values) {
		return A2($elm$core$List$member, identity, values) ? A2(
			$elm$core$List$filter,
			$elm$core$Basics$neq(identity),
			values) : _Utils_ap(
			values,
			_List_fromArray(
				[identity]));
	});
var $author$project$Desktop$version = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (value === 3) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Desktop version');
	},
	A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int));
var $author$project$Desktop$fenceSwitcherSelection = F3(
	function (chord, binding, effects) {
		return A2(
			$elm$core$List$concatMap,
			function (effect) {
				var _v0 = _Utils_Tuple2(chord, effect);
				if (((!_v0.a.$) && (!_v0.b.$)) && (!_v0.b.a.$)) {
					var generation = _v0.a.a;
					var raw = _v0.b.a.a;
					var _v1 = A2(
						$elm$json$Json$Decode$decodeValue,
						A4(
							$elm$json$Json$Decode$map3,
							F3(
								function (kind, request, root) {
									return _Utils_Tuple3(kind, request, root);
								}),
							A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
							A2(
								$elm$json$Json$Decode$at,
								_List_fromArray(
									['intent', 'request']),
								$author$project$UInt64$decoder),
							A2(
								$elm$json$Json$Decode$at,
								_List_fromArray(
									['intent', 'incarnation']),
								$author$project$UInt64$decoder)),
						raw);
					if ((!_v1.$) && (_v1.a.a === 'window-effect')) {
						var _v2 = _v1.a;
						var request = _v2.b;
						var root = _v2.c;
						return _List_fromArray(
							[
								$author$project$Desktop$Send(
								$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'protocolVersion',
											$elm$json$Json$Encode$int(3)),
											_Utils_Tuple2(
											'kind',
											$elm$json$Json$Encode$string('switcher-selection-request')),
											_Utils_Tuple2(
											'binding',
											$author$project$Binding$encode(binding)),
											_Utils_Tuple2(
											'requestId',
											$elm$json$Json$Encode$string(
												$author$project$UInt64$string(request))),
											_Utils_Tuple2(
											'chord',
											$elm$json$Json$Encode$string(
												$author$project$UInt64$string(generation))),
											_Utils_Tuple2(
											'root',
											$elm$json$Json$Encode$string(
												$author$project$UInt64$string(root)))
										]))),
								effect
							]);
					} else {
						return _List_fromArray(
							[effect]);
					}
				} else {
					return _List_fromArray(
						[effect]);
				}
			},
			effects);
	});
var $author$project$OverviewRecovery$Issued = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$OverviewRecovery$issue = F3(
	function (read, sent, model) {
		if (model.$ === 1) {
			var origin = model.a;
			var expected = model.b;
			if (!_Utils_eq(read, expected)) {
				return model;
			} else {
				if (!sent.$) {
					var _v2 = sent.a;
					var binding = _v2.a;
					var intent = _v2.b;
					return (_Utils_eq(binding, origin.c3) && (_Utils_eq(intent.au, origin.n) && A2(
						$elm$core$List$member,
						intent.bc,
						_List_fromArray(
							[$author$project$Effects$Activate, $author$project$Effects$Restore])))) ? A2($author$project$OverviewRecovery$Issued, origin, intent) : $author$project$OverviewRecovery$Idle;
				} else {
					return $author$project$OverviewRecovery$Idle;
				}
			}
		} else {
			return model;
		}
	});
var $author$project$Desktop$trackOverviewChoice = F3(
	function (_v0, effects, model) {
		var read = _v0.b;
		var sent = $elm$core$List$head(
			A2(
				$elm$core$List$filterMap,
				function (effect) {
					if ((!effect.$) && (!effect.a.$)) {
						var wire = effect.a.a;
						return (!_Utils_eq(
							A2(
								$elm$json$Json$Decode$decodeValue,
								A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
								wire),
							$elm$core$Result$Ok('window-effect'))) ? $elm$core$Maybe$Nothing : $elm$core$Result$toMaybe(
							A2(
								$elm$json$Json$Decode$decodeValue,
								A3(
									$elm$json$Json$Decode$map2,
									$elm$core$Tuple$pair,
									A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
									A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder)),
								wire));
					} else {
						return $elm$core$Maybe$Nothing;
					}
				},
				effects));
		return _Utils_update(
			model,
			{
				aE: A3($author$project$OverviewRecovery$issue, read, sent, model.aE)
			});
	});
var $author$project$Desktop$window = F2(
	function (message, model) {
		_v0$4:
		while (true) {
			switch (message.$) {
				case 5:
					switch (message.a.$) {
						case 3:
							var _v1 = message.a;
							var menuId = _v1.a;
							var binding = _v1.b;
							var index = _v1.c;
							var inactiveMinimize = function () {
								var _v3 = _Utils_Tuple2(
									$author$project$MenuBridge$menuSnapshot(model.a.i).aC,
									$author$project$MenuBridge$currentProvider(model.a.i));
								if ((!_v3.a.$) && (!_v3.b.$)) {
									var menu = _v3.a.a;
									var provider = _v3.b.a;
									return _Utils_eq(menu.cc, menuId) && (_Utils_eq(menu.c3, binding) && (_Utils_eq(
										A2(
											$elm$core$Maybe$map,
											function ($) {
												return $.eV;
											},
											$elm$core$List$head(
												A2($elm$core$List$drop, index, menu.fd))),
										$elm$core$Maybe$Just($author$project$Menu$Minimize)) && A2(
										$elm$core$List$any,
										function (family) {
											return _Utils_eq(
												family.n,
												$author$project$Provider$incarnation(provider)) && (!family.dC);
										},
										A2(
											$elm$core$List$concatMap,
											function ($) {
												return $.aB;
											},
											$author$project$TaskbarShell$groups(model.a)))));
								} else {
									return false;
								}
							}();
							var _v2 = A2(
								$author$project$Desktop$windowBase,
								message,
								_Utils_update(
									model,
									{r: $elm$core$Maybe$Nothing}));
							var next = _v2.a;
							var effects = _v2.b;
							var admitted = _Utils_eq(
								$author$project$MenuBridge$preparedSnapshot(model.a.i),
								$elm$core$Maybe$Nothing) && (!_Utils_eq(
								$author$project$MenuBridge$preparedSnapshot(next.a.i),
								$elm$core$Maybe$Nothing));
							return (inactiveMinimize && admitted) ? _Utils_Tuple2(
								_Utils_update(
									next,
									{
										r: (model.bh === 1) ? model.E : $elm$core$Maybe$Nothing
									}),
								effects) : _Utils_Tuple2(next, effects);
						case 5:
							var menuId = message.a.a;
							var _v4 = _Utils_Tuple2(
								$author$project$MenuBridge$menuSnapshot(model.a.i).aC,
								model.E);
							if ((!_v4.a.$) && (!_v4.b.$)) {
								var menu = _v4.a.a;
								var origin = _v4.b.a;
								if (!_Utils_eq(menu.cc, menuId)) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var _v5 = A2($author$project$Desktop$windowBase, message, model);
									var closed = _v5.a;
									var effects = _v5.b;
									var _v6 = A2(
										$author$project$Desktop$windowBase,
										$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
										closed);
									var refreshing = _v6.a;
									var commands = _v6.b;
									return _Utils_Tuple2(
										_Utils_update(
											refreshing,
											{
												E: $elm$core$Maybe$Nothing,
												r: (model.bh === 1) ? $elm$core$Maybe$Just(origin) : $elm$core$Maybe$Nothing
											}),
										_Utils_ap(effects, commands));
								}
							} else {
								return A2($author$project$Desktop$windowBase, message, model);
							}
						default:
							break _v0$4;
					}
				case 3:
					var scope = message.a;
					var generation = message.b;
					var _v7 = _Utils_Tuple2(model.a.G, model.a.b.c3);
					if ((!_v7.a.$) && (!_v7.b.$)) {
						var picker = _v7.a.a;
						var binding = _v7.b.a;
						var _v8 = A2($author$project$Desktop$windowBase, message, model);
						var closed = _v8.a;
						var effects = _v8.b;
						if ((!_Utils_eq(closed.a.G, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(picker.cQ, scope)) || (!_Utils_eq(picker.e7, generation)))) {
							return _Utils_Tuple2(closed, effects);
						} else {
							var _v9 = A2(
								$author$project$Desktop$windowBase,
								$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
								closed);
							var refreshing = _v9.a;
							var commands = _v9.b;
							return _Utils_Tuple2(
								_Utils_update(
									refreshing,
									{
										r: (model.bh === 1) ? $elm$core$Maybe$Just(
											{
												c3: binding,
												bp: $author$project$Desktop$TaskbarGroup(picker.aV),
												z: A2(
													$elm$core$Maybe$map,
													A2(
														$elm$core$Basics$composeR,
														function ($) {
															return $.R;
														},
														function ($) {
															return $.z;
														}),
													model.a.b.V.av)
											}) : $elm$core$Maybe$Nothing
									}),
								_Utils_ap(
									A2(
										$elm$core$List$filter,
										function (effect) {
											if (effect.$ === 5) {
												return false;
											} else {
												return true;
											}
										},
										effects),
									commands));
						}
					} else {
						return A2($author$project$Desktop$windowBase, message, model);
					}
				case 2:
					var scope = message.a;
					var generation = message.b;
					var root = message.c;
					var _v11 = _Utils_Tuple3(model.a.G, model.a.b.c3, model.a.b.V.av);
					if (((!_v11.a.$) && (!_v11.b.$)) && (!_v11.c.$)) {
						var picker = _v11.a.a;
						var binding = _v11.b.a;
						var observed = _v11.c.a;
						if ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(picker.cQ, scope)) || ((!_Utils_eq(picker.e7, generation)) || ((!_Utils_eq(
							$author$project$Shell$capture(model.a.b),
							$elm$core$Maybe$Just(scope))) || (!$author$project$Shell$available(model.a.b)))))) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var _v12 = $elm$core$List$head(
								A2(
									$elm$core$List$filter,
									function (family) {
										return _Utils_eq(family.n, root) && family.c2;
									},
									A2(
										$elm$core$List$concatMap,
										function ($) {
											return $.aB;
										},
										A2(
											$elm$core$List$filter,
											function (group) {
												return _Utils_eq(group.aV, picker.aV);
											},
											$author$project$TaskbarShell$groups(model.a)))));
							if (_v12.$ === 1) {
								return _Utils_Tuple2(model, _List_Nil);
							} else {
								var family = _v12.a;
								var windows = model.a;
								var _v13 = A2(
									$author$project$Desktop$windowBase,
									$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
									_Utils_update(
										model,
										{
											D: '',
											a: _Utils_update(
												windows,
												{G: $elm$core$Maybe$Nothing})
										}));
								var next = _v13.a;
								var effects = _v13.b;
								var _v14 = next.a.b.y;
								if (!_v14.$) {
									var request = _v14.a;
									var token = A2($author$project$Desktop$ChoiceToken, binding, request);
									return _Utils_Tuple2(
										_Utils_update(
											next,
											{
												k: $elm$core$Maybe$Just(
													{c0: family.c0, c3: binding, aQ: $elm$core$Maybe$Nothing, z: observed.R.z, bf: $elm$core$Maybe$Nothing, n: root, bj: token, a$: $elm$core$Maybe$Nothing})
											}),
										_Utils_ap(
											effects,
											_List_fromArray(
												[
													$author$project$Desktop$ArmChoice(token)
												])));
								} else {
									return _Utils_Tuple2(next, effects);
								}
							}
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				default:
					break _v0$4;
			}
		}
		var matchingProjection = function () {
			if ((!message.$) && (message.a.$ === 3)) {
				var raw = message.a.a;
				return A2(
					$elm$core$Result$withDefault,
					false,
					A2(
						$elm$core$Result$map,
						function (_v34) {
							var kind = _v34.a;
							var request = _v34.b;
							return (kind === 'action-projection') && _Utils_eq(
								model.a.b.y,
								$elm$core$Maybe$Just(request));
						},
						A2(
							$elm$json$Json$Decode$decodeValue,
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
								A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder)),
							raw)));
			} else {
				return false;
			}
		}();
		var base = function () {
			if ((!message.$) && (message.a.$ === 3)) {
				return model;
			} else {
				return _Utils_update(
					model,
					{r: $elm$core$Maybe$Nothing});
			}
		}();
		var _v15 = A2($author$project$Desktop$windowBase, message, base);
		var updated = _v15.a;
		var ordinaryEffects = _v15.b;
		var geometryOutput = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.V;
				},
				updated.a.b.dc)) ? A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				function ($) {
					return $.R;
				},
				function ($) {
					return $.z;
				}),
			updated.a.b.ac) : A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				function ($) {
					return $.R;
				},
				function ($) {
					return $.z;
				}),
			updated.a.b.V.av);
		var matchingGeometry = function () {
			if ((!message.$) && (message.a.$ === 3)) {
				var raw = message.a.a;
				return A2(
					$elm$core$Result$withDefault,
					false,
					A2(
						$elm$core$Result$map,
						function (_v31) {
							var kind = _v31.a;
							var request = _v31.b;
							return (kind === 'geometry-facts') && (_Utils_eq(
								model.a.b.cE,
								$elm$core$Maybe$Just(request)) && (_Utils_eq(
								A2(
									$elm$core$Maybe$map,
									function ($) {
										return $.cM;
									},
									updated.a.b.ac),
								$elm$core$Maybe$Just(request)) && (!_Utils_eq(updated.a.b.ac, model.a.b.ac))));
						},
						A2(
							$elm$json$Json$Decode$decodeValue,
							A3(
								$elm$json$Json$Decode$map2,
								$elm$core$Tuple$pair,
								A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
								A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder)),
							raw)));
			} else {
				return false;
			}
		}();
		var matchingObservation = matchingProjection || matchingGeometry;
		var _v16 = function () {
			var _v17 = updated.r;
			if (!_v17.$) {
				var target = _v17.a;
				var blocked = function () {
					var _v20 = target.bp;
					if (!_v20.$) {
						var groupKey = _v20.a;
						return A2(
							$elm$core$List$any,
							function (family) {
								return A3($author$project$MenuBridge$blockedFor, family.n, updated.a.b, updated.a.i);
							},
							A2(
								$elm$core$List$concatMap,
								function ($) {
									return $.aB;
								},
								A2(
									$elm$core$List$filter,
									function (group) {
										return _Utils_eq(group.aV, groupKey);
									},
									$author$project$TaskbarShell$groups(updated.a))));
					} else {
						return false;
					}
				}();
				if ((!matchingObservation) || ((!$author$project$Shell$available(updated.a.b)) || blocked)) {
					return _Utils_Tuple2(updated, ordinaryEffects);
				} else {
					var retired = _Utils_update(
						updated,
						{r: $elm$core$Maybe$Nothing});
					var focus = function () {
						var _v19 = target.bp;
						if (!_v19.$) {
							var groupKey = _v19.a;
							return A2(
								$elm$core$Maybe$map,
								function (scope) {
									return 'group:' + ($author$project$Shell$stampKey(scope) + (':' + groupKey));
								},
								$author$project$Shell$capture(retired.a.b));
						} else {
							return $elm$core$Maybe$Just(
								A2($author$project$Desktop$key, retired, 'control:overview-opener'));
						}
					}();
					var exists = function () {
						var _v18 = target.bp;
						if (!_v18.$) {
							var groupKey = _v18.a;
							return A2(
								$elm$core$List$any,
								function (group) {
									return _Utils_eq(group.aV, groupKey) && A2(
										$elm$core$List$any,
										function ($) {
											return $.c2;
										},
										group.aB);
								},
								$author$project$TaskbarShell$groups(retired.a));
						} else {
							return _Utils_eq(retired.k, $elm$core$Maybe$Nothing);
						}
					}();
					return (retired.q || (retired.l || ((!_Utils_eq(retired.a.G, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(
						$author$project$MenuBridge$menuSnapshot(retired.a.i).aC,
						$elm$core$Maybe$Nothing)) || ((!_Utils_eq(
						retired.a.b.c3,
						$elm$core$Maybe$Just(target.c3))) || (_Utils_eq(target.z, $elm$core$Maybe$Nothing) || ((!_Utils_eq(
						A2(
							$elm$core$Maybe$map,
							A2(
								$elm$core$Basics$composeR,
								function ($) {
									return $.R;
								},
								function ($) {
									return $.z;
								}),
							retired.a.b.V.av),
						target.z)) || ((!_Utils_eq(geometryOutput, target.z)) || (!exists))))))))) ? _Utils_Tuple2(retired, ordinaryEffects) : _Utils_Tuple2(
						retired,
						_Utils_ap(
							ordinaryEffects,
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									A2($elm$core$Basics$composeR, $author$project$Desktop$Focus, $elm$core$List$singleton),
									focus))));
				}
			} else {
				return _Utils_Tuple2(updated, ordinaryEffects);
			}
		}();
		var next = _v16.a;
		var effects = _v16.b;
		var _v21 = next.k;
		if (!_v21.$) {
			var pending = _v21.a;
			if ((!matchingObservation) || ((!$author$project$Shell$available(next.a.b)) || (((!_Utils_eq(pending.a$, $elm$core$Maybe$Nothing)) && (!matchingGeometry)) || (((!_Utils_eq(pending.bf, $elm$core$Maybe$Nothing)) || (!_Utils_eq(pending.a$, $elm$core$Maybe$Nothing))) && A2(
				$elm$core$Maybe$withDefault,
				true,
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.eZ;
					},
					next.a.b.ac)))))) {
				return _Utils_Tuple2(next, effects);
			} else {
				var retired = _Utils_update(
					next,
					{k: $elm$core$Maybe$Nothing, D: 'The window changed. Choose again.'});
				var output = A2(
					$elm$core$Maybe$map,
					A2(
						$elm$core$Basics$composeR,
						function ($) {
							return $.R;
						},
						function ($) {
							return $.z;
						}),
					next.a.b.V.av);
				var family = $elm$core$List$head(
					A2(
						$elm$core$List$filter,
						function (item) {
							return _Utils_eq(item.n, pending.n) && (_Utils_eq(item.c0, pending.c0) && item.c2);
						},
						A2(
							$elm$core$List$concatMap,
							function ($) {
								return $.aB;
							},
							$author$project$TaskbarShell$groups(next.a))));
				if ((!_Utils_eq(
					next.a.b.c3,
					$elm$core$Maybe$Just(pending.c3))) || ((!_Utils_eq(
					output,
					$elm$core$Maybe$Just(pending.z))) || (!_Utils_eq(
					geometryOutput,
					$elm$core$Maybe$Just(pending.z))))) {
					return _Utils_Tuple2(retired, effects);
				} else {
					var _v22 = _Utils_Tuple2(
						$author$project$Shell$capture(next.a.b),
						family);
					if ((!_v22.a.$) && (!_v22.b.$)) {
						var scope = _v22.a.a;
						var selected = _v22.b.a;
						if (!_Utils_eq(pending.a$, $elm$core$Maybe$Nothing)) {
							var _v23 = _Utils_Tuple3(
								pending.a$,
								next.a.b.ac,
								$author$project$Shell$captureGeometry(next.a.b));
							if (((!_v23.a.$) && (!_v23.b.$)) && (!_v23.c.$)) {
								var proposed = _v23.a.a;
								var geometry = _v23.b.a;
								var stamp = _v23.c.a;
								if (!A3($author$project$Transfer$matches, geometry, pending.n, proposed)) {
									return _Utils_Tuple2(
										_Utils_update(
											retired,
											{D: 'Window workspace changed. Choose again.'}),
										effects);
								} else {
									var _v24 = A2(
										$author$project$Desktop$windowBase,
										$author$project$TaskbarShell$Native(
											A3(
												$author$project$Shell$Act,
												stamp,
												$author$project$Effects$TransferWorkspace(proposed),
												pending.n)),
										_Utils_update(
											retired,
											{D: ''}));
									var applied = _v24.a;
									var commands = _v24.b;
									return _Utils_Tuple2(
										applied,
										_Utils_ap(effects, commands));
								}
							} else {
								return _Utils_Tuple2(retired, effects);
							}
						} else {
							var _v25 = pending.bf;
							if (!_v25.$) {
								var proposed = _v25.a;
								var _v26 = _Utils_Tuple2(
									next.a.b.ac,
									$author$project$Shell$captureGeometry(next.a.b));
								if ((!_v26.a.$) && (!_v26.b.$)) {
									var geometry = _v26.a.a;
									var stamp = _v26.b.a;
									var current = _Utils_update(
										proposed,
										{R: geometry.R});
									if (!A3($author$project$Snap$matches, geometry, pending.n, current)) {
										return _Utils_Tuple2(
											_Utils_update(
												retired,
												{D: 'Output or window changed. Open snapping again.'}),
											effects);
									} else {
										var _v27 = A2(
											$author$project$Desktop$windowBase,
											$author$project$TaskbarShell$Native(
												A3(
													$author$project$Shell$Act,
													stamp,
													$author$project$Effects$SnapPlacement(current),
													pending.n)),
											_Utils_update(
												retired,
												{D: ''}));
										var applied = _v27.a;
										var commands = _v27.b;
										return _Utils_Tuple2(
											applied,
											_Utils_ap(effects, commands));
									}
								} else {
									return _Utils_Tuple2(retired, effects);
								}
							} else {
								var _v28 = $author$project$Taskbar$selection(selected);
								if (_v28.$ === 2) {
									var operation = _v28.a;
									var root = _v28.b;
									var _v29 = A2(
										$author$project$Desktop$windowBase,
										$author$project$TaskbarShell$Native(
											A3($author$project$Shell$Act, scope, operation, root)),
										_Utils_update(
											retired,
											{D: ''}));
									var applied = _v29.a;
									var commands = _v29.b;
									return _Utils_Tuple2(
										A3($author$project$Desktop$trackOverviewChoice, pending.bj, commands, applied),
										_Utils_ap(
											effects,
											A3($author$project$Desktop$fenceSwitcherSelection, pending.aQ, pending.c3, commands)));
								} else {
									return _Utils_Tuple2(retired, effects);
								}
							}
						}
					} else {
						return _Utils_Tuple2(retired, effects);
					}
				}
			}
		} else {
			return _Utils_Tuple2(next, effects);
		}
	});
var $author$project$WorkspaceNavigation$Committed = 2;
var $author$project$WorkspaceNavigation$Refused = 3;
var $author$project$WorkspaceNavigation$maxCounter = F2(
	function (a, b) {
		return (A2($author$project$UInt64$compare, a, b) === 2) ? a : b;
	});
var $author$project$WorkspaceNavigation$accept = F2(
	function (r, model) {
		return _Utils_update(
			model,
			{
				e7: A2($author$project$WorkspaceNavigation$maxCounter, model.e7, r.af.e7),
				fz: $elm$core$Maybe$Just(r),
				cM: A2($author$project$WorkspaceNavigation$maxCounter, model.cM, r.af.cM),
				ex: (r.O === 3) && (!_Utils_eq(model.bT, $elm$core$Maybe$Nothing))
			});
	});
var $author$project$WorkspaceNavigation$protocol = A2(
	$elm$json$Json$Decode$andThen,
	function (pair) {
		return _Utils_eq(
			pair,
			_Utils_Tuple2(3, 1)) ? $elm$json$Json$Decode$succeed(0) : $elm$json$Json$Decode$fail('Workspace navigation protocol');
	},
	A3(
		$elm$json$Json$Decode$map2,
		$elm$core$Tuple$pair,
		A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
		A2($elm$json$Json$Decode$field, 'workspaceProtocol', $elm$json$Json$Decode$int)));
var $author$project$WorkspaceNavigation$Record = F4(
	function (binding, intent, status, reason) {
		return {c3: binding, af: intent, ep: reason, O: status};
	});
var $author$project$WorkspaceNavigation$Intent = F5(
	function (request, generation, source, destination, context) {
		return {R: context, bp: destination, e7: generation, cM: request, cm: source};
	});
var $author$project$WorkspaceNavigation$Context = F4(
	function (lifetime, epoch, output, revision) {
		return {e4: epoch, fe: lifetime, z: output, cN: revision};
	});
var $author$project$WorkspaceNavigation$positive = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return _Utils_eq(v, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero navigation identity') : $elm$json$Json$Decode$succeed(v);
	},
	$author$project$UInt64$decoder);
var $author$project$WorkspaceNavigation$strict = F2(
	function (fields, decoder) {
		return A2(
			$elm$json$Json$Decode$andThen,
			function (pairs) {
				return _Utils_eq(
					$elm$core$List$sort(
						A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
					$elm$core$List$sort(fields)) ? decoder : $elm$json$Json$Decode$fail('Workspace navigation fields');
			},
			$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
	});
var $author$project$WorkspaceNavigation$contextDecoder = A2(
	$author$project$WorkspaceNavigation$strict,
	_List_fromArray(
		['lifetime', 'epoch', 'output', 'revision']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$WorkspaceNavigation$Context,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$WorkspaceNavigation$positive),
		A2($elm$json$Json$Decode$field, 'epoch', $author$project$WorkspaceNavigation$positive),
		A2($elm$json$Json$Decode$field, 'output', $author$project$WorkspaceNavigation$positive),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$WorkspaceNavigation$positive)));
var $author$project$WorkspaceNavigation$intentDecoder = A2(
	$author$project$WorkspaceNavigation$strict,
	_List_fromArray(
		['request', 'generation', 'source', 'destination', 'context']),
	A6(
		$elm$json$Json$Decode$map5,
		$author$project$WorkspaceNavigation$Intent,
		A2($elm$json$Json$Decode$field, 'request', $author$project$WorkspaceNavigation$positive),
		A2($elm$json$Json$Decode$field, 'generation', $author$project$WorkspaceNavigation$positive),
		A2($elm$json$Json$Decode$field, 'source', $author$project$WorkspaceInventory$rowDecoder),
		A2($elm$json$Json$Decode$field, 'destination', $author$project$WorkspaceInventory$rowDecoder),
		A2($elm$json$Json$Decode$field, 'context', $author$project$WorkspaceNavigation$contextDecoder)));
var $author$project$WorkspaceNavigation$reasonDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (s) {
		return (($elm$core$String$length(s) <= 64) && (A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (_v0) {
					var first = _v0.a;
					return (first >= 'a') && (first <= 'z');
				},
				$elm$core$String$uncons(s))) && A2(
			$elm$core$String$all,
			function (c) {
				return ((c >= 'a') && (c <= 'z')) || (((c >= '0') && (c <= '9')) || (c === '-'));
			},
			s))) ? $elm$json$Json$Decode$succeed(s) : $elm$json$Json$Decode$fail('Workspace navigation reason');
	},
	$elm$json$Json$Decode$string);
var $author$project$WorkspaceNavigation$statusDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (s) {
		switch (s) {
			case 'Pending':
				return $elm$json$Json$Decode$succeed(0);
			case 'Unknown':
				return $elm$json$Json$Decode$succeed(1);
			case 'Committed':
				return $elm$json$Json$Decode$succeed(2);
			case 'Refused':
				return $elm$json$Json$Decode$succeed(3);
			default:
				return $elm$json$Json$Decode$fail('Workspace navigation status');
		}
	},
	$elm$json$Json$Decode$string);
var $author$project$WorkspaceNavigation$recordBody = A2(
	$elm$json$Json$Decode$andThen,
	function (r) {
		return A3($author$project$Binding$matchesContext, r.af.R.fe, r.af.R.e4, r.c3) ? $elm$json$Json$Decode$succeed(r) : $elm$json$Json$Decode$fail('Workspace navigation authority');
	},
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$WorkspaceNavigation$Record,
		A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
		A2($elm$json$Json$Decode$field, 'intent', $author$project$WorkspaceNavigation$intentDecoder),
		A2($elm$json$Json$Decode$field, 'status', $author$project$WorkspaceNavigation$statusDecoder),
		A2($elm$json$Json$Decode$field, 'reason', $author$project$WorkspaceNavigation$reasonDecoder)));
var $author$project$WorkspaceNavigation$recordDecoder = A2(
	$author$project$WorkspaceNavigation$strict,
	_List_fromArray(
		['schema', 'binding', 'intent', 'status', 'reason']),
	A2(
		$elm$json$Json$Decode$andThen,
		function (n) {
			return (n === 1) ? $author$project$WorkspaceNavigation$recordBody : $elm$json$Json$Decode$fail('Workspace record schema');
		},
		A2($elm$json$Json$Decode$field, 'schema', $elm$json$Json$Decode$int)));
var $author$project$WorkspaceNavigation$receive = F2(
	function (raw, model) {
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			raw);
		_v0$2:
		while (true) {
			if (!_v0.$) {
				switch (_v0.a) {
					case 'workspace-navigation-outcome':
						var _v1 = A2(
							$elm$json$Json$Decode$decodeValue,
							A2(
								$author$project$WorkspaceNavigation$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'workspaceProtocol', 'binding', 'intent', 'status', 'reason']),
								A2(
									$elm$json$Json$Decode$andThen,
									function (_v2) {
										return $author$project$WorkspaceNavigation$recordBody;
									},
									$author$project$WorkspaceNavigation$protocol)),
							raw);
						if (!_v1.$) {
							var r = _v1.a;
							var _v3 = model.fz;
							if (!_v3.$) {
								var current = _v3.a;
								return (_Utils_eq(
									model.c3,
									$elm$core$Maybe$Just(r.c3)) && (_Utils_eq(r.c3, current.c3) && (_Utils_eq(r.af, current.af) && (((!current.O) || (current.O === 1)) && (!(!r.O)))))) ? A2($author$project$WorkspaceNavigation$accept, r, model) : model;
							} else {
								return model;
							}
						} else {
							return model;
						}
					case 'workspace-navigation-recovery':
						var _v4 = A2(
							$elm$json$Json$Decode$decodeValue,
							A2(
								$author$project$WorkspaceNavigation$strict,
								_List_fromArray(
									['protocolVersion', 'kind', 'workspaceProtocol', 'binding', 'record']),
								A2(
									$elm$json$Json$Decode$andThen,
									function (_v5) {
										return A3(
											$elm$json$Json$Decode$map2,
											$elm$core$Tuple$pair,
											A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
											A2(
												$elm$json$Json$Decode$field,
												'record',
												$elm$json$Json$Decode$nullable($author$project$WorkspaceNavigation$recordDecoder)));
									},
									$author$project$WorkspaceNavigation$protocol)),
							raw);
						if (!_v4.$) {
							var _v6 = _v4.a;
							var binding = _v6.a;
							var maybeRecord = _v6.b;
							if ((!_Utils_eq(
								model.c3,
								$elm$core$Maybe$Just(binding))) || (model.bY && (!model.er))) {
								return model;
							} else {
								var matches = function (r) {
									return A2($author$project$Binding$sameLifetime, r.af.R.fe, binding) && ((!(!r.O)) && ((!model.bY) || A2(
										$elm$core$Maybe$withDefault,
										false,
										A2(
											$elm$core$Maybe$map,
											function (current) {
												return _Utils_eq(current.c3, r.c3) && _Utils_eq(current.af, r.af);
											},
											model.fz))));
								};
								if (!maybeRecord.$) {
									var r = maybeRecord.a;
									return matches(r) ? A2(
										$author$project$WorkspaceNavigation$accept,
										r,
										_Utils_update(
											model,
											{bY: true, er: false})) : model;
								} else {
									return model.bY ? model : _Utils_update(
										model,
										{bT: $elm$core$Maybe$Nothing, bY: true, fz: $elm$core$Maybe$Nothing, er: false, ex: false});
								}
							}
						} else {
							return model;
						}
					default:
						break _v0$2;
				}
			} else {
				break _v0$2;
			}
		}
		return model;
	});
var $author$project$Desktop$workspaceNavigationFrame = F2(
	function (raw, model) {
		var navigation = A2($author$project$WorkspaceNavigation$receive, raw, model.J);
		var terminal = A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (r) {
					return (r.O === 2) || (r.O === 3);
				},
				navigation.fz));
		var changed = !_Utils_eq(navigation, model.J);
		if (!changed) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var next = $author$project$Desktop$advance(
				_Utils_update(
					model,
					{J: navigation}));
			return terminal ? A2(
				$author$project$Desktop$windowBase,
				$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
				next) : _Utils_Tuple2(next, _List_Nil);
		}
	});
var $author$project$Desktop$update = F2(
	function (message, model) {
		update:
		while (true) {
			if (!message.$) {
				var origin = message.a;
				var inner = message.b;
				var $temp$message = inner,
					$temp$model = _Utils_update(
					model,
					{bh: origin});
				message = $temp$message;
				model = $temp$model;
				continue update;
			} else {
				return A2($author$project$Desktop$updateOrdinary, message, model);
			}
		}
	});
var $author$project$Desktop$updateAvailable = F2(
	function (message, model) {
		switch (message.$) {
			case 3:
				var stamp = message.a;
				var root = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!$author$project$Shell$available(model.a.b)) || A3($author$project$MenuBridge$blockedFor, root, model.a.b, model.a.i))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v7 = A2(
						$elm$core$Maybe$andThen,
						function (geometry) {
							return A2($author$project$Snap$open, geometry, root);
						},
						model.a.b.ac);
					if (_v7.$ === 1) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var choice = _v7.a;
						var windows = model.a;
						return _Utils_Tuple2(
							$author$project$Desktop$advance(
								$author$project$Desktop$retireSwitcher(
									_Utils_update(
										model,
										{
											k: $elm$core$Maybe$Nothing,
											y: $elm$core$Maybe$Nothing,
											s: false,
											A: false,
											o: $elm$core$Maybe$Nothing,
											u: false,
											E: $elm$core$Maybe$Nothing,
											v: false,
											F: false,
											q: false,
											l: false,
											r: $elm$core$Maybe$Nothing,
											p: false,
											N: false,
											w: $elm$core$Maybe$Just(choice),
											t: $elm$core$Maybe$Nothing,
											x: false,
											I: false,
											a: _Utils_update(
												windows,
												{
													i: $author$project$MenuBridge$retireChoices(windows.i),
													G: $elm$core$Maybe$Nothing
												})
										}))),
							_List_Nil);
					}
				}
			case 4:
				var stamp = message.a;
				var region = message.b;
				if (!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v8 = _Utils_Tuple2(model.a.b.ac, model.w);
					if ((!_v8.a.$) && (!_v8.b.$)) {
						var geometry = _v8.a.a;
						var choice = _v8.b.a;
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{
									w: A3($author$project$Snap$select, geometry, region, choice)
								}),
							_List_Nil);
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 5:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!$author$project$Shell$available(model.a.b)) || (!A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						function (caps) {
							return A2($elm$core$List$member, 2, caps.ef);
						},
						model.a.b.dc)))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v9 = _Utils_Tuple2(model.w, model.a.b.ac);
					if ((!_v9.a.$) && (!_v9.b.$)) {
						var choice = _v9.a.a;
						var geometry = _v9.b.a;
						if (!A2($author$project$Snap$valid, geometry, choice)) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var _v10 = _Utils_Tuple2(
								$author$project$Snap$proposal(choice),
								$elm$core$List$head(
									A2(
										$elm$core$List$filter,
										function (family) {
											return _Utils_eq(family.n, choice.fK) && family.c2;
										},
										A2(
											$elm$core$List$concatMap,
											function ($) {
												return $.aB;
											},
											$author$project$TaskbarShell$groups(model.a)))));
							if ((!_v10.a.$) && (!_v10.b.$)) {
								var proposed = _v10.a.a;
								var family = _v10.b.a;
								var _v11 = A2(
									$author$project$Desktop$chooseFamily,
									family,
									_Utils_update(
										model,
										{w: $elm$core$Maybe$Nothing}));
								var next = _v11.a;
								var effects = _v11.b;
								return _Utils_Tuple2(
									_Utils_update(
										next,
										{
											k: A2(
												$elm$core$Maybe$map,
												function (pending) {
													return _Utils_update(
														pending,
														{
															bf: $elm$core$Maybe$Just(proposed)
														});
												},
												next.k)
										}),
									effects);
							} else {
								return _Utils_Tuple2(model, _List_Nil);
							}
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 6:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || _Utils_eq(model.w, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{w: $elm$core$Maybe$Nothing})),
					_List_Nil);
			case 7:
				return _Utils_eq(model.w, $elm$core$Maybe$Nothing) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$author$project$Desktop$windowBase,
					$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{D: 'Output changed. Open snapping again.', w: $elm$core$Maybe$Nothing})));
			case 74:
				var token = message.a;
				if (!_Utils_eq(
					A2(
						$elm$core$Maybe$map,
						function ($) {
							return $.bj;
						},
						model.k),
					$elm$core$Maybe$Just(token))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v12 = token;
					var request = _v12.b;
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{
								k: $elm$core$Maybe$Nothing,
								D: 'Window information took too long. Refresh windows, then choose again.',
								aE: A2($author$project$OverviewRecovery$cancelChoice, request, model.aE)
							}),
						_List_Nil);
				}
			case 75:
				return ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || $elm$core$String$isEmpty(model.D)) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$author$project$Desktop$windowBase,
					$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
					_Utils_update(
						model,
						{D: ''}));
			case 9:
				var snapshot = message.a;
				var allowed = message.b;
				if ((!model.a.b.m) || (model.a.b.m === 3)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v13 = A3($author$project$Shortcuts$receive, model.a.b.c3, snapshot, model.b$);
					var shortcuts = _v13.a;
					var route = _v13.b;
					var failure = _v13.c;
					var notice = ((!_Utils_eq(route, $elm$core$Maybe$Nothing)) && (!allowed)) ? $elm$core$Maybe$Just('Shell shortcut output is unavailable. Press the shortcut again.') : failure;
					var priorNotice = ((!_Utils_eq(route, $elm$core$Maybe$Nothing)) && (allowed && A2(
						$elm$core$List$member,
						model.D,
						_List_fromArray(
							['Shell shortcut output is unavailable. Press the shortcut again.', 'Shell shortcut unavailable while input is blocked.', 'Shortcut history expired. Press the shortcut again.'])))) ? '' : model.D;
					var next = _Utils_update(
						model,
						{
							D: A2($elm$core$Maybe$withDefault, priorNotice, notice),
							bh: 1,
							b$: shortcuts
						});
					var _v14 = _Utils_Tuple2(
						allowed ? route : $elm$core$Maybe$Nothing,
						$author$project$Desktop$capture(next));
					if ((!_v14.a.$) && (!_v14.b.$)) {
						switch (_v14.a.a) {
							case 0:
								var _v15 = _v14.a.a;
								var stamp = _v14.b.a;
								return A2(
									$author$project$Desktop$update,
									$author$project$Desktop$OpenApplications(stamp),
									next);
							case 1:
								var _v16 = _v14.a.a;
								var stamp = _v14.b.a;
								return A2(
									$author$project$Desktop$update,
									$author$project$Desktop$OpenSystemMenu(stamp),
									next);
							default:
								var _v17 = _v14.a.a;
								var stamp = _v14.b.a;
								return A2(
									$author$project$Desktop$update,
									$author$project$Desktop$OpenNotifications(stamp),
									next);
						}
					} else {
						return _Utils_Tuple2(next, _List_Nil);
					}
				}
			case 10:
				var scope = message.a;
				if (_Utils_eq(scope, model.be)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v18 = function () {
						var _v19 = $author$project$MenuBridge$currentProvider(model.a.i);
						if (_v19.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var provider = _v19.a;
							return A2(
								$author$project$Desktop$windowBase,
								$author$project$TaskbarShell$MenuEvent(
									$author$project$Menu$Invalidate(
										$author$project$Provider$getBinding(provider))),
								model);
						}
					}();
					var retired = _v18.a;
					var effects = _v18.b;
					return _Utils_Tuple2(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								retired,
								{E: $elm$core$Maybe$Nothing, bx: false, be: scope, r: $elm$core$Maybe$Nothing, w: $elm$core$Maybe$Nothing})),
						effects);
				}
			case 8:
				var raw = message.a;
				var positive = A2(
					$elm$json$Json$Decode$andThen,
					function (counter) {
						return _Utils_eq(counter, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero owner identity') : $elm$json$Json$Decode$succeed(counter);
					},
					$author$project$UInt64$decoder);
				var decoder = A2(
					$author$project$Desktop$strict,
					_List_fromArray(
						['surfaceProtocol', 'kind', 'outputId', 'providerId']),
					A5(
						$elm$json$Json$Decode$map4,
						F4(
							function (protocol, kind, output, provider) {
								return _Utils_Tuple3(
									protocol,
									kind,
									{dl: output, ds: provider});
							}),
						A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
						A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
						A2($elm$json$Json$Decode$field, 'outputId', positive),
						A2($elm$json$Json$Decode$field, 'providerId', positive)));
				var _v20 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
				if (((!_v20.$) && (_v20.a.a === 2)) && (_v20.a.b === 'surface-owner')) {
					var _v21 = _v20.a;
					var owner = _v21.c;
					if (model.bx) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var _v22 = model.be;
						if (_v22.$ === 1) {
							return _Utils_Tuple2(
								_Utils_update(
									model,
									{
										be: $elm$core$Maybe$Just(owner)
									}),
								_List_Nil);
						} else {
							var previous = _v22.a;
							if (_Utils_eq(previous, owner)) {
								return _Utils_Tuple2(model, _List_Nil);
							} else {
								var retired = function () {
									var _v23 = $author$project$MenuBridge$currentProvider(model.a.i);
									if (_v23.$ === 1) {
										return model;
									} else {
										var provider = _v23.a;
										return A2(
											$author$project$Desktop$windowBase,
											$author$project$TaskbarShell$MenuEvent(
												$author$project$Menu$Invalidate(
													$author$project$Provider$getBinding(provider))),
											model).a;
									}
								}();
								return _Utils_Tuple2(
									$author$project$Desktop$retireSwitcher(
										_Utils_update(
											retired,
											{E: $elm$core$Maybe$Nothing, bx: true, be: $elm$core$Maybe$Nothing, r: $elm$core$Maybe$Nothing, w: $elm$core$Maybe$Nothing})),
									_List_Nil);
							}
						}
					}
				} else {
					return _Utils_Tuple2(model, _List_Nil);
				}
			case 2:
				var stamp = message.a;
				var root = message.b;
				if (model.bx || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing)) || ((!_Utils_eq(
					$author$project$Shell$capture(model.a.b),
					$elm$core$Maybe$Just(stamp))) || (!$author$project$Shell$available(model.a.b)))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v24 = model.a.b.V.av;
					if (_v24.$ === 1) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var observed = _v24.a;
						var _v25 = model.be;
						if (_v25.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var owner = _v25.a;
							var _v26 = A3(
								$author$project$NativeProvider$fromShell,
								{e_: observed.R.cN, dl: owner.dl, ds: owner.ds},
								root,
								model.a.b);
							if (_v26.$ === 1) {
								return _Utils_Tuple2(model, _List_Nil);
							} else {
								var provider = _v26.a;
								var _v27 = A2(
									$author$project$Desktop$windowBase,
									$author$project$TaskbarShell$OpenMenu(provider),
									model);
								var next = _v27.a;
								var effects = _v27.b;
								return _Utils_eq(
									$author$project$MenuBridge$menuSnapshot(next.a.i).aC,
									$author$project$MenuBridge$menuSnapshot(model.a.i).aC) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
									$author$project$Desktop$retireSwitcher(
										_Utils_update(
											next,
											{
												y: $elm$core$Maybe$Nothing,
												s: false,
												A: false,
												o: $elm$core$Maybe$Nothing,
												u: false,
												E: A2(
													$elm$core$Maybe$andThen,
													function (binding) {
														return A2(
															$elm$core$Maybe$map,
															function (group) {
																return {
																	c3: binding,
																	bp: $author$project$Desktop$TaskbarGroup(group.aV),
																	z: $elm$core$Maybe$Just(observed.R.z)
																};
															},
															$elm$core$List$head(
																A2(
																	$elm$core$List$filter,
																	function (group) {
																		return A2(
																			$elm$core$List$any,
																			function (family) {
																				return _Utils_eq(family.n, root);
																			},
																			group.aB);
																	},
																	$author$project$TaskbarShell$groups(model.a))));
													},
													model.a.b.c3),
												v: false,
												F: false,
												q: false,
												l: false,
												r: $elm$core$Maybe$Nothing,
												p: false,
												N: false,
												w: $elm$core$Maybe$Nothing,
												t: $elm$core$Maybe$Nothing,
												x: false,
												I: false
											})),
									effects);
							}
						}
					}
				}
			case 52:
				var stamp = message.a;
				var direction = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!$author$project$Shell$available(model.a.b)) || (!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v28 = $author$project$UInt64$next(
						$author$project$Switcher$generation(model.j));
					if (_v28.$ === 1) {
						return _Utils_Tuple2(
							$author$project$Desktop$retireSwitcher(model),
							_List_Nil);
					} else {
						var generation = _v28.a;
						var base = A2(
							$elm$core$Maybe$withDefault,
							model,
							A2(
								$elm$core$Maybe$map,
								function (menu) {
									return A2(
										$author$project$Desktop$windowBase,
										$author$project$TaskbarShell$MenuEvent(
											$author$project$Menu$Dismiss(menu.cc)),
										model).a;
								},
								$author$project$MenuBridge$menuSnapshot(model.a.i).aC));
						var origin = A2(
							$elm$core$Maybe$andThen,
							function (observed) {
								return A2(
									$elm$core$Maybe$andThen,
									function (root) {
										return A2($author$project$ActionProjection$rootOf, root, observed.eA);
									},
									$author$project$ActionProjection$focused(observed.eA));
							},
							base.a.b.V.av);
						var windows = base.a;
						var _v29 = A4($author$project$Switcher$step, generation, 1, direction, base.j);
						var switcher = _v29.a;
						var opened = $author$project$Desktop$advance(
							_Utils_update(
								base,
								{
									y: $elm$core$Maybe$Nothing,
									s: false,
									A: false,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									an: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									j: switcher,
									aO: $elm$core$Maybe$Nothing,
									cn: origin,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{G: $elm$core$Maybe$Nothing})
								}));
						var _v30 = A2(
							$author$project$Desktop$windowBase,
							$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
							opened);
						var refreshing = _v30.a;
						var commands = _v30.b;
						var _v31 = $author$project$Desktop$readSwitcherHistory(refreshing);
						var next = _v31.a;
						var history = _v31.b;
						return _Utils_Tuple2(
							next,
							_Utils_ap(commands, history));
					}
				}
			case 53:
				var stamp = message.a;
				var direction = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!$author$project$Desktop$switcherOpen(model))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v32 = (!_Utils_eq(model.an, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(
						A2($author$project$Switcher$navigate, direction, model.j),
						$elm$core$Maybe$Nothing) : A4(
						$author$project$Switcher$step,
						$author$project$Switcher$generation(model.j),
						$author$project$Switcher$lastStep(model.j) + 1,
						direction,
						model.j);
					var switcher = _v32.a;
					var chosen = _v32.b;
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{j: switcher}));
					if (!chosen.$) {
						var family = chosen.a;
						return A2($author$project$Desktop$chooseFamily, family, next);
					} else {
						return _Utils_Tuple2(
							next,
							$author$project$Desktop$switcherFocus(next));
					}
				}
			case 54:
				var stamp = message.a;
				var root = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!$author$project$Desktop$switcherOpen(model))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					if (!A2(
						$elm$core$List$any,
						function (family) {
							return _Utils_eq(family.n, root);
						},
						$author$project$Switcher$entries(model.j))) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var switcher = A3(
							$author$project$Switcher$choose,
							$author$project$Switcher$generation(model.j),
							root,
							model.j);
						var _v34 = A2(
							$author$project$Switcher$commit,
							$author$project$Switcher$generation(switcher),
							switcher);
						var resolved = _v34.a;
						var selected = _v34.b;
						if (!selected.$) {
							var family = selected.a;
							return A2(
								$author$project$Desktop$chooseFamily,
								family,
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{j: resolved})));
						} else {
							return _Utils_Tuple2(model, _List_Nil);
						}
					}
				}
			case 55:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!$author$project$Desktop$switcherOpen(model))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v36 = A2(
						$author$project$Switcher$commit,
						$author$project$Switcher$generation(model.j),
						model.j);
					var switcher = _v36.a;
					var selected = _v36.b;
					if (!selected.$) {
						var family = selected.a;
						return A2(
							$author$project$Desktop$chooseFamily,
							family,
							$author$project$Desktop$advance(
								_Utils_update(
									model,
									{j: switcher})));
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 56:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!$author$project$Desktop$switcherOpen(model))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var closed = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(model));
					var _v38 = _Utils_Tuple3(
						model.an,
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if (((!_v38.a.$) && (!_v38.b.$)) && (!_v38.c.$)) {
						var chord = _v38.a.a;
						var binding = _v38.b.a;
						var request = _v38.c.a;
						var _v39 = A2(
							$author$project$Desktop$windowBase,
							$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
							_Utils_update(
								closed,
								{cM: request}));
						var next = _v39.a;
						var reads = _v39.b;
						return _Utils_Tuple2(
							next,
							A2(
								$elm$core$List$cons,
								$author$project$Desktop$Send(
									$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'protocolVersion',
												$elm$json$Json$Encode$int(3)),
												_Utils_Tuple2(
												'kind',
												$elm$json$Json$Encode$string('switcher-cancel-request')),
												_Utils_Tuple2(
												'binding',
												$author$project$Binding$encode(binding)),
												_Utils_Tuple2(
												'requestId',
												$elm$json$Json$Encode$string(
													$author$project$UInt64$string(request))),
												_Utils_Tuple2(
												'chord',
												$elm$json$Json$Encode$string(
													$author$project$UInt64$string(chord.e7)))
											]))),
								reads));
					} else {
						return A2(
							$author$project$Desktop$windowBase,
							$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
							closed);
					}
				}
			case 0:
				return _Utils_Tuple2(model, _List_Nil);
			case 1:
				var value = message.a;
				var _v40 = A2($author$project$Desktop$window, value, model);
				var next = _v40.a;
				var effects = _v40.b;
				var _v41 = $author$project$Desktop$syncSwitcher(next);
				var synced = _v41.a;
				var commands = _v41.b;
				return ((!_Utils_eq(next.a.G, $elm$core$Maybe$Nothing)) && (!_Utils_eq(next.a.G, model.a.G))) ? _Utils_Tuple2(
					$author$project$Desktop$retireSwitcher(
						_Utils_update(
							next,
							{y: $elm$core$Maybe$Nothing, s: false, A: false, o: $elm$core$Maybe$Nothing, u: false, E: $elm$core$Maybe$Nothing, v: false, F: false, q: false, l: false, r: $elm$core$Maybe$Nothing, p: false, N: false, w: $elm$core$Maybe$Nothing, t: $elm$core$Maybe$Nothing, x: false, I: false})),
					effects) : _Utils_Tuple2(
					synced,
					_Utils_ap(effects, commands));
			case 60:
				var intent = message.a;
				return _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								J: A2($author$project$WorkspaceNavigation$expire, intent, model.J)
							})),
					_List_Nil);
			case 59:
				var stamp = message.a;
				if (!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v42 = $author$project$WorkspaceNavigation$recover(model.J);
					var navigation = _v42.a;
					var wire = _v42.b;
					var _v43 = A2(
						$author$project$Desktop$windowBase,
						$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
						_Utils_update(
							model,
							{J: navigation}));
					var refreshed = _v43.a;
					var commands = _v43.b;
					return _Utils_Tuple2(
						$author$project$Desktop$advance(refreshed),
						_Utils_ap(
							commands,
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									A2($elm$core$Basics$composeR, $author$project$Desktop$Send, $elm$core$List$singleton),
									wire))));
				}
			case 11:
				var raw = message.a;
				var _v44 = A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					raw);
				_v44$26:
				while (true) {
					if (!_v44.$) {
						switch (_v44.a) {
							case 'workspace-navigation-outcome':
								return A2($author$project$Desktop$workspaceNavigationFrame, raw, model);
							case 'workspace-navigation-recovery':
								return A2($author$project$Desktop$workspaceNavigationFrame, raw, model);
							case 'motion-preferences':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v46, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$MotionPreferences$decoder))));
								var _v45 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (_v45.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var receipt = _v45.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.aH,
										$elm$core$Maybe$Just(receipt.cM)))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var motion = model.M;
										var preference = A2($author$project$MotionPreferences$observe, receipt.c, motion.aY);
										return _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{
														K: A7(
															$author$project$AdapterNotice$failedRead,
															6,
															receipt.c3,
															receipt.cM,
															$elm$core$Maybe$Nothing,
															$elm$core$Maybe$Nothing,
															_Utils_eq(receipt.c, $elm$core$Maybe$Nothing),
															model.K),
														M: _Utils_update(
															motion,
															{aY: preference}),
														aH: $elm$core$Maybe$Nothing
													})),
											_List_Nil);
									}
								}
							case 'motion-preferences-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v48, binding, request, status, snapshot) {
												return {c3: binding, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $author$project$Desktop$saveReceiptDecoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$MotionPreferences$decoder))));
								var _v47 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (_v47.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var receipt = _v47.a;
									if (!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var motion = model.M;
										var preference = A4(
											$author$project$MotionPreferences$receive,
											receipt.cM,
											$author$project$Desktop$motionSaveReceipt(receipt.O),
											receipt.c,
											motion.aY);
										return _Utils_eq(preference, motion.aY) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{
														M: _Utils_update(
															motion,
															{aY: preference})
													})),
											_List_Nil);
									}
								}
							case 'host-motion-preference':
								var _v49 = A2($elm$json$Json$Decode$decodeValue, $author$project$Motion$decoder, raw);
								if (_v49.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var observation = _v49.a;
									var motion = A2($author$project$Motion$observe, observation, model.M);
									return _Utils_eq(motion, model.M) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
										$author$project$Desktop$advance(
											_Utils_update(
												model,
												{M: motion})),
										_List_Nil);
								}
							case 'motion-profile':
								var _v50 = A2($elm$json$Json$Decode$decodeValue, $author$project$Motion$receiptDecoder, raw);
								if (_v50.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var receipt = _v50.a;
									var motion = A3($author$project$Motion$receive, model.a.b.c3, receipt, model.M);
									return _Utils_eq(motion, model.M) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
										$author$project$Desktop$advance(
											_Utils_update(
												model,
												{M: motion})),
										_List_Nil);
								}
							case 'pointer-ownership':
								var _v51 = A2($elm$json$Json$Decode$decodeValue, $author$project$PointerOwnership$decoder, raw);
								if (_v51.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var snapshot = _v51.a;
									var pointer = A3($author$project$PointerOwnership$receive, model.a.b.c3, snapshot, model.bz);
									var next = _Utils_update(
										model,
										{bz: pointer});
									if (_Utils_eq(pointer, model.bz)) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										if (!A2($author$project$PointerOwnership$blocked, model.a.b.c3, pointer)) {
											return _Utils_Tuple2(next, _List_Nil);
										} else {
											var windows = next.a;
											var retired = $author$project$Desktop$advance(
												$author$project$Desktop$retireSwitcher(
													_Utils_update(
														next,
														{
															k: $elm$core$Maybe$Nothing,
															s: false,
															A: false,
															o: $elm$core$Maybe$Nothing,
															u: false,
															E: $elm$core$Maybe$Nothing,
															v: false,
															F: false,
															q: false,
															l: false,
															r: $elm$core$Maybe$Nothing,
															p: false,
															N: false,
															w: $elm$core$Maybe$Nothing,
															t: $elm$core$Maybe$Nothing,
															x: false,
															I: false,
															a: _Utils_update(
																windows,
																{
																	i: $author$project$MenuBridge$retireChoices(windows.i),
																	G: $elm$core$Maybe$Nothing
																})
														})));
											return _Utils_Tuple2(retired, _List_Nil);
										}
									}
								}
							case 'shell-shortcuts':
								var _v52 = A2($elm$json$Json$Decode$decodeValue, $author$project$Shortcuts$decoder, raw);
								if (_v52.$ === 1) {
									return _Utils_Tuple2(model, _List_Nil);
								} else {
									var snapshot = _v52.a;
									return A2(
										$author$project$Desktop$update,
										A2($author$project$Desktop$ScopedShortcut, snapshot, true),
										model);
								}
							case 'switcher-journal':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'chord']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v54, binding, request, chord) {
												return {c3: binding, aQ: chord, cM: request};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'chord', $author$project$Desktop$nativeChordDecoder)));
								var _v53 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v53.$) {
									var receipt = _v53.a;
									return ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || ((!model.a.b.m) || (model.a.b.m === 3))) ? _Utils_Tuple2(model, _List_Nil) : A2($author$project$Desktop$receiveChord, receipt.aQ, model);
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'activation-history':
								var positive = A2(
									$elm$json$Json$Decode$andThen,
									function (value) {
										return _Utils_eq(value, $author$project$UInt64$zero) ? $elm$json$Json$Decode$fail('Zero history identity') : $elm$json$Json$Decode$succeed(value);
									},
									$author$project$UInt64$decoder);
								var roots = A2(
									$elm$json$Json$Decode$andThen,
									function (rows) {
										return (($elm$core$List$length(rows) <= 256) && _Utils_eq(
											$elm$core$List$length(
												A3(
													$elm$core$List$foldl,
													F2(
														function (root, unique) {
															return A2($elm$core$List$member, root, unique) ? unique : A2($elm$core$List$cons, root, unique);
														}),
													_List_Nil,
													rows)),
											$elm$core$List$length(rows))) ? $elm$json$Json$Decode$succeed(rows) : $elm$json$Json$Decode$fail('History bounds/duplicates');
									},
									$elm$json$Json$Decode$list(positive));
								var context = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['lifetime', 'epoch', 'output', 'revision']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (lifetime, epoch, output, revision) {
												return {e4: epoch, fe: lifetime, z: output, cN: revision};
											}),
										A2($elm$json$Json$Decode$field, 'lifetime', positive),
										A2($elm$json$Json$Decode$field, 'epoch', positive),
										A2($elm$json$Json$Decode$field, 'output', positive),
										A2($elm$json$Json$Decode$field, 'revision', positive)));
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'context', 'roots']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v56, binding, request, scope, rows) {
												return {c3: binding, R: scope, cM: request, aL: rows};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', positive),
										A2($elm$json$Json$Decode$field, 'context', context),
										A2($elm$json$Json$Decode$field, 'roots', roots)));
								var _v55 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v55.$) {
									var receipt = _v55.a;
									return ((!$author$project$Desktop$switcherOpen(model)) || ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.aN,
										$elm$core$Maybe$Just(receipt.cM))))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$syncSwitcher(
										_Utils_update(
											model,
											{
												aN: $elm$core$Maybe$Nothing,
												aO: $elm$core$Maybe$Just(
													{R: receipt.R, aL: receipt.aL})
											}));
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'jump-list-snapshot':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v58, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$JumpList$decoder)));
								var _v57 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v57.$) {
									var result = _v57.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(result.c3))) || ((!_Utils_eq(
										model.aU,
										$elm$core$Maybe$Just(result.cM))) || ((!_Utils_eq(
										model.o,
										$elm$core$Maybe$Just(result.c.dQ))) || (!model.a.b.m)))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var reconciled = A2($author$project$JumpList$reconcile, result.c, model.al);
										var failed = (!result.c.c2) && _Utils_eq(
											reconciled.c,
											$elm$core$Maybe$Just(result.c));
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														3,
														result.c3,
														result.cM,
														$elm$core$Maybe$Just(result.c.cS),
														$elm$core$Maybe$Just(result.c.cN),
														failed,
														model.K),
													aU: $elm$core$Maybe$Nothing,
													al: reconciled,
													u: false
												}));
										return _Utils_Tuple2(
											next,
											(model.u && (!failed)) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													A2($author$project$Desktop$key, next, 'jump:close'))
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'jump-list-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v60, binding, request, status, snapshot) {
												return {c3: binding, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$JumpList$decoder)));
								var _v59 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v59.$) {
									var result = _v59.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(result.c3))) || (!model.a.b.m)) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var jumpList = A4($author$project$JumpList$receive, result.cM, result.O, result.c, model.al);
										return _Utils_eq(jumpList, model.al) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{al: jumpList})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'files-snapshot':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v62, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$Files$decoder)));
								var _v61 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v61.$) {
									var result = _v61.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(result.c3))) || ((!_Utils_eq(
										model.aR,
										$elm$core$Maybe$Just(result.cM))) || (!model.a.b.m))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var reconciled = A2($author$project$Files$reconcile, result.c, model.W);
										var failed = (!result.c.c2) && _Utils_eq(
											reconciled.c,
											$elm$core$Maybe$Just(result.c));
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														2,
														result.c3,
														result.cM,
														$elm$core$Maybe$Just(result.c.cS),
														$elm$core$Maybe$Just(result.c.cN),
														failed,
														model.K),
													W: reconciled,
													aR: $elm$core$Maybe$Nothing,
													A: false
												}));
										return _Utils_Tuple2(
											next,
											(model.s && (model.A && (!failed))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													A2($author$project$Desktop$key, next, 'files:close'))
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'files-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v64, binding, request, status, snapshot) {
												return {c3: binding, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$Files$decoder)));
								var _v63 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v63.$) {
									var result = _v63.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(result.c3))) || (!model.a.b.m)) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var files = A4($author$project$Files$receive, result.cM, result.O, result.c, model.W);
										return _Utils_eq(files, model.W) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{W: files})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'system-menu-snapshot':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v66, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$SystemMenu$decoder)));
								var _v65 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v65.$) {
									var receipt = _v65.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.aP,
										$elm$core$Maybe$Just(receipt.cM)))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var reconciled = A2($author$project$SystemMenu$reconcile, receipt.c, model.aq);
										var failed = (_Utils_eq(receipt.c.fO, $elm$core$Maybe$Nothing) && (_Utils_eq(receipt.c.fi, $elm$core$Maybe$Nothing) && (_Utils_eq(receipt.c.fu, $elm$core$Maybe$Nothing) && _Utils_eq(receipt.c.fF, $elm$core$Maybe$Nothing)))) && _Utils_eq(
											reconciled.c,
											$elm$core$Maybe$Just(receipt.c));
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														4,
														receipt.c3,
														receipt.cM,
														$elm$core$Maybe$Just(receipt.c.cS),
														$elm$core$Maybe$Just(receipt.c.cN),
														failed,
														model.K),
													aq: reconciled,
													t: $elm$core$Maybe$Nothing,
													aP: $elm$core$Maybe$Nothing,
													I: false
												}));
										return _Utils_Tuple2(
											next,
											(model.x && (model.I && (!failed))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													A2($author$project$Desktop$key, next, 'system:close'))
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'system-menu-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v68, binding, request, status, snapshot) {
												return {c3: binding, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$SystemMenu$decoder)));
								var _v67 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v67.$) {
									var receipt = _v67.a;
									if (!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var menu = A4($author$project$SystemMenu$receive, receipt.cM, receipt.O, receipt.c, model.aq);
										return _Utils_eq(menu, model.aq) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{aq: menu})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'notification-snapshot':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v70, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$Notifications$decoder)));
								var _v69 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v69.$) {
									var receipt = _v69.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.aX,
										$elm$core$Maybe$Just(receipt.cM)))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var reconciled = A2($author$project$Notifications$reconcile, receipt.c, model.C);
										var failed = (!receipt.c.c2) && _Utils_eq(
											reconciled.c,
											$elm$core$Maybe$Just(receipt.c));
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														1,
														receipt.c3,
														receipt.cM,
														$elm$core$Maybe$Just(receipt.c.cS),
														$elm$core$Maybe$Just(receipt.c.cN),
														failed,
														model.K),
													C: reconciled,
													aX: $elm$core$Maybe$Nothing,
													F: false
												}));
										return _Utils_Tuple2(
											next,
											(model.v && (model.F && (!failed))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													A2($author$project$Desktop$key, next, 'notifications:close'))
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'notification-update':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'snapshot']),
									A4(
										$elm$json$Json$Decode$map3,
										F3(
											function (_v72, binding, snapshot) {
												return {c3: binding, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$Notifications$decoder)));
								var _v71 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v71.$) {
									var receipt = _v71.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!model.a.b.m)) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var notifications = A2($author$project$Notifications$observe, receipt.c, model.C);
										return _Utils_eq(notifications, model.C) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{C: notifications})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'notification-outcome':
								var hasReason = !_Utils_eq(
									$elm$core$Maybe$Nothing,
									$elm$core$Result$toMaybe(
										A2(
											$elm$json$Json$Decode$decodeValue,
											A2($elm$json$Json$Decode$field, 'reason', $elm$json$Json$Decode$value),
											raw)));
								var reasonDecoder = hasReason ? A2(
									$elm$json$Json$Decode$field,
									'reason',
									A2(
										$elm$json$Json$Decode$andThen,
										function (value) {
											return A2(
												$elm$core$List$member,
												value,
												_List_fromArray(
													['', 'expired', 'changed', 'unavailable', 'already-handled'])) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Notification refusal reason');
										},
										$elm$json$Json$Decode$string)) : $elm$json$Json$Decode$succeed('');
								var decoder = A2(
									$author$project$Desktop$strict,
									_Utils_ap(
										_List_fromArray(
											['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
										hasReason ? _List_fromArray(
											['reason']) : _List_Nil),
									A7(
										$elm$json$Json$Decode$map6,
										F6(
											function (_v74, binding, request, status, reason, snapshot) {
												return {c3: binding, ep: reason, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
										reasonDecoder,
										A2($elm$json$Json$Decode$field, 'snapshot', $author$project$Notifications$decoder)));
								var _v73 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v73.$) {
									var receipt = _v73.a;
									if (!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var notifications = A5($author$project$Notifications$receiveReason, receipt.cM, receipt.O, receipt.ep, receipt.c, model.C);
										return _Utils_eq(notifications, model.C) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{C: notifications})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'shortcut-preferences':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot', 'inventory']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v76, binding, request, snapshot, inventory) {
												return {c3: binding, cH: inventory, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$ShortcutPreferences$decoder)),
										A2($elm$json$Json$Decode$field, 'inventory', $author$project$ShortcutPreferences$inventoryDecoder)));
								var _v75 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v75.$) {
									var receipt = _v75.a;
									return ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.aM,
										$elm$core$Maybe$Just(receipt.cM)))) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
										$author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														7,
														receipt.c3,
														receipt.cM,
														$elm$core$Maybe$Nothing,
														$elm$core$Maybe$Nothing,
														_Utils_eq(receipt.c, $elm$core$Maybe$Nothing),
														model.K),
													aM: $elm$core$Maybe$Nothing,
													ah: A3(
														$author$project$ShortcutPreferences$observe,
														receipt.c,
														$elm$core$Maybe$Just(receipt.cH),
														model.ah)
												})),
										_List_Nil);
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'shortcut-preferences-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot', 'inventory']),
									A7(
										$elm$json$Json$Decode$map6,
										F6(
											function (_v78, binding, request, status, snapshot, inventory) {
												return {c3: binding, cH: inventory, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $author$project$Desktop$shortcutSaveReceiptDecoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$ShortcutPreferences$decoder)),
										A2($elm$json$Json$Decode$field, 'inventory', $author$project$ShortcutPreferences$inventoryDecoder)));
								var _v77 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v77.$) {
									var receipt = _v77.a;
									if (!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var preferences = A5(
											$author$project$ShortcutPreferences$receive,
											receipt.cM,
											$author$project$Desktop$shortcutSaveReceiptName(receipt.O),
											receipt.c,
											$elm$core$Maybe$Just(receipt.cH),
											model.ah);
										return _Utils_eq(preferences, model.ah) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{ah: preferences})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'shell-settings':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
									A5(
										$elm$json$Json$Decode$map4,
										F4(
											function (_v80, binding, request, snapshot) {
												return {c3: binding, cM: request, c: snapshot};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$Settings$decoder))));
								var _v79 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v79.$) {
									var receipt = _v79.a;
									if ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!_Utils_eq(
										model.bi,
										$elm$core$Maybe$Just(receipt.cM)))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														5,
														receipt.c3,
														receipt.cM,
														$elm$core$Maybe$Nothing,
														$elm$core$Maybe$Nothing,
														_Utils_eq(receipt.c, $elm$core$Maybe$Nothing),
														model.K),
													ap: A2($author$project$Settings$observe, receipt.c, model.ap),
													bi: $elm$core$Maybe$Nothing,
													N: false
												}));
										return _Utils_Tuple2(
											next,
											(model.p && (model.N && (!_Utils_eq(receipt.c, $elm$core$Maybe$Nothing)))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(
													A2($author$project$Desktop$key, next, 'settings:close'))
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'shell-settings-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'snapshot']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v82, binding, request, status, snapshot) {
												return {c3: binding, cM: request, c: snapshot, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $author$project$Desktop$saveReceiptDecoder),
										A2(
											$elm$json$Json$Decode$field,
											'snapshot',
											$elm$json$Json$Decode$nullable($author$project$Settings$decoder))));
								var _v81 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v81.$) {
									var receipt = _v81.a;
									if (!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var settings = A4(
											$author$project$Settings$receive,
											receipt.cM,
											$author$project$Desktop$saveReceiptName(receipt.O),
											receipt.c,
											model.ap);
										return _Utils_eq(settings, model.ap) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
											$author$project$Desktop$advance(
												_Utils_update(
													model,
													{ap: settings})),
											_List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'application-catalog':
								var decoder = A2(
									$elm$json$Json$Decode$andThen,
									function (pairs) {
										var fields = A2($elm$core$List$map, $elm$core$Tuple$first, pairs);
										var legacy = !A2($elm$core$List$member, 'preferences', fields);
										return A2(
											$author$project$Desktop$strict,
											_Utils_ap(
												_List_fromArray(
													['protocolVersion', 'kind', 'binding', 'requestId', 'snapshot']),
												legacy ? _List_Nil : _List_fromArray(
													['preferences'])),
											A6(
												$elm$json$Json$Decode$map5,
												F5(
													function (_v84, binding, request, snapshot, pins) {
														return {c3: binding, H: pins, cM: request, c: snapshot};
													}),
												$author$project$Desktop$version,
												A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
												A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
												A2($elm$json$Json$Decode$field, 'snapshot', $elm$json$Json$Decode$value),
												legacy ? $elm$json$Json$Decode$succeed($elm$core$Maybe$Nothing) : A2(
													$elm$json$Json$Decode$field,
													'preferences',
													$elm$json$Json$Decode$nullable($author$project$Pins$decoder))));
									},
									$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
								var _v83 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v83.$) {
									var receipt = _v83.a;
									if ((!(!model.a.b.m)) && (_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3)) && _Utils_eq(
										model.y,
										$elm$core$Maybe$Just(receipt.cM)))) {
										var target = 'launcher-search';
										var applications = $elm$core$Result$toMaybe(
											$author$project$Catalog$decode(receipt.c));
										var next = $author$project$Desktop$advance(
											_Utils_update(
												model,
												{
													K: A7(
														$author$project$AdapterNotice$failedRead,
														0,
														receipt.c3,
														receipt.cM,
														$elm$core$Maybe$Nothing,
														$elm$core$Maybe$Nothing,
														_Utils_eq(applications, $elm$core$Maybe$Nothing),
														model.K),
													ai: 0,
													aj: applications,
													bn: $elm$core$Maybe$Nothing,
													bo: false,
													y: $elm$core$Maybe$Nothing,
													B: A2($author$project$Launch$catalog, receipt.c, model.B),
													H: A3($author$project$Pins$observeRead, receipt.cM, receipt.H, model.H)
												}));
										return _Utils_Tuple2(
											next,
											(next.q && (model.bo && (!_Utils_eq(applications, $elm$core$Maybe$Nothing)))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus(target)
												]) : _List_Nil);
									} else {
										return _Utils_Tuple2(model, _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'taskbar-pins-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'requestId', 'status', 'preferences']),
									A6(
										$elm$json$Json$Decode$map5,
										F5(
											function (_v86, binding, request, status, pins) {
												return {c3: binding, H: pins, cM: request, O: status};
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder),
										A2($elm$json$Json$Decode$field, 'status', $elm$json$Json$Decode$string),
										A2(
											$elm$json$Json$Decode$field,
											'preferences',
											$elm$json$Json$Decode$nullable($author$project$Pins$decoder))));
								var _v85 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v85.$) {
									var receipt = _v85.a;
									if ((!model.a.b.m) || ((!_Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(receipt.c3))) || (!A2(
										$elm$core$List$member,
										receipt.O,
										_List_fromArray(
											['Saved', 'Refused', 'Unknown']))))) {
										return _Utils_Tuple2(model, _List_Nil);
									} else {
										var pins = A4($author$project$Pins$receive, receipt.cM, receipt.O, receipt.H, model.H);
										var next = _Utils_update(
											model,
											{H: pins});
										return _Utils_Tuple2(
											_Utils_update(
												next,
												{
													ai: A3(
														$elm$core$Basics$clamp,
														0,
														$author$project$Desktop$applicationPageCount(next) - 1,
														next.ai)
												}),
											(model.q && (!_Utils_eq(pins, model.H))) ? _List_fromArray(
												[
													$author$project$Desktop$Focus('launcher-search')
												]) : _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							case 'application-launch-outcome':
								var decoder = A2(
									$author$project$Desktop$strict,
									_List_fromArray(
										['protocolVersion', 'kind', 'binding', 'outcome']),
									A4(
										$elm$json$Json$Decode$map3,
										F3(
											function (_v89, binding, outcome) {
												return _Utils_Tuple2(binding, outcome);
											}),
										$author$project$Desktop$version,
										A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
										A2($elm$json$Json$Decode$field, 'outcome', $elm$json$Json$Decode$value)));
								var _v87 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
								if (!_v87.$) {
									var _v88 = _v87.a;
									var binding = _v88.a;
									var outcome = _v88.b;
									if ((!(!model.a.b.m)) && _Utils_eq(
										model.a.b.c3,
										$elm$core$Maybe$Just(binding))) {
										var launch = A3(
											$author$project$Launch$receive,
											$author$project$Desktop$host(binding),
											outcome,
											model.B);
										var refused = ($author$project$Launch$status(model.B) === 'Pending') && ($author$project$Launch$status(launch) === 'Refused');
										var next = _Utils_update(
											model,
											{
												B: launch,
												q: (refused && (!model.cI)) ? true : (model.q && ($author$project$Launch$status(launch) !== 'Submitted'))
											});
										return _Utils_Tuple2(next, _List_Nil);
									} else {
										return _Utils_Tuple2(model, _List_Nil);
									}
								} else {
									return _Utils_Tuple2(model, _List_Nil);
								}
							default:
								break _v44$26;
						}
					} else {
						break _v44$26;
					}
				}
				var _v90 = A2(
					$author$project$Desktop$window,
					$author$project$TaskbarShell$Native(
						$author$project$Shell$Incoming(raw)),
					model);
				var next = _v90.a;
				var effects = _v90.b;
				var _v91 = $author$project$Desktop$syncSwitcher(next);
				var synced = _v91.a;
				var commands = _v91.b;
				return _Utils_Tuple2(
					synced,
					_Utils_ap(effects, commands));
			case 17:
				var stamp = message.a;
				var entry = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || (_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing) || ((!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing)) || _Utils_eq(
					A2(
						$elm$core$Maybe$andThen,
						$author$project$Catalog$lookup(entry),
						model.aj),
					$elm$core$Maybe$Nothing))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var windows = model.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								model,
								{
									s: false,
									A: false,
									ce: model.q,
									o: $elm$core$Maybe$Just(entry),
									u: true,
									E: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{
											i: $author$project$MenuBridge$retireChoices(windows.i),
											G: $elm$core$Maybe$Nothing
										})
								})));
					var _v92 = $author$project$Desktop$readJumpList(next);
					var reading = _v92.a;
					var commands = _v92.b;
					return _Utils_Tuple2(
						reading,
						_Utils_ap(
							commands,
							_List_fromArray(
								[
									$author$project$Desktop$Focus(
									A2($author$project$Desktop$key, reading, 'jump:close'))
								])));
				}
			case 18:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || _Utils_eq(model.o, $elm$core$Maybe$Nothing)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{o: $elm$core$Maybe$Nothing, u: false}));
					return model.ce ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(next, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (current) {
								return A2(
									$author$project$Desktop$update,
									$author$project$Desktop$OpenApplications(current),
									next);
							},
							$author$project$Desktop$capture(next))) : _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'control:opener'))
							]));
				}
			case 19:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || _Utils_eq(model.o, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readJumpList(model);
			case 20:
				var stamp = message.a;
				var intent = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(
					model.o,
					$elm$core$Maybe$Just(intent.dQ))) || (!_Utils_eq(model.aU, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v93 = _Utils_Tuple2(
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if ((!_v93.a.$) && (!_v93.b.$)) {
						var binding = _v93.a.a;
						var request = _v93.b.a;
						var _v94 = A3($author$project$JumpList$propose, request, intent, model.al);
						var jumpList = _v94.a;
						var proposal = _v94.b;
						if (proposal.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var value = proposal.a;
							return _Utils_Tuple2(
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{o: $elm$core$Maybe$Nothing, al: jumpList, u: false, cM: request})),
								_List_fromArray(
									[
										$author$project$Desktop$Send(
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('jump-list-effect')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(binding)),
													_Utils_Tuple2(
													'requestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2('intent', value)
												])))
									]));
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 21:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || (_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing) || (!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var windows = model.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								model,
								{
									s: true,
									A: true,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{
											i: $author$project$MenuBridge$retireChoices(windows.i),
											G: $elm$core$Maybe$Nothing
										})
								})));
					var _v96 = $author$project$Desktop$readFiles(next);
					var reading = _v96.a;
					var commands = _v96.b;
					return _Utils_Tuple2(
						reading,
						_Utils_ap(
							commands,
							_List_fromArray(
								[
									$author$project$Desktop$Focus(
									A2($author$project$Desktop$key, reading, 'files:close'))
								])));
				}
			case 22:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.s)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{s: false, A: false, o: $elm$core$Maybe$Nothing, u: false}));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'files:opener'))
							]));
				}
			case 23:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.s)) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readFiles(model);
			case 24:
				var stamp = message.a;
				var value = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.s)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var files = A2($author$project$Files$edit, value, model.W);
					return _Utils_eq(files, model.W) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
						$author$project$Desktop$advance(
							_Utils_update(
								model,
								{W: files})),
						_List_Nil);
				}
			case 26:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.s)) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$elm$core$Maybe$withDefault,
					_Utils_Tuple2(model, _List_Nil),
					A2(
						$elm$core$Maybe$map,
						function (snapshot) {
							return A2(
								$author$project$Desktop$sendFiles,
								A2($author$project$Files$intent, snapshot, model.W.e2),
								model);
						},
						model.W.c));
			case 25:
				var stamp = message.a;
				var target = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.s)) ? _Utils_Tuple2(model, _List_Nil) : A2($author$project$Desktop$sendFiles, target, model);
			case 27:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || (_Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing) || (!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var windows = model.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								model,
								{
									s: false,
									A: false,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: true,
									I: true,
									a: _Utils_update(
										windows,
										{
											i: $author$project$MenuBridge$retireChoices(windows.i),
											G: $elm$core$Maybe$Nothing
										})
								})));
					var _v97 = $author$project$Desktop$readSystemMenu(next);
					var reading = _v97.a;
					var commands = _v97.b;
					return _Utils_Tuple2(
						reading,
						_Utils_ap(
							commands,
							_List_fromArray(
								[
									$author$project$Desktop$Focus(
									A2($author$project$Desktop$key, reading, 'system:close'))
								])));
				}
			case 28:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.x)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{s: false, A: false, o: $elm$core$Maybe$Nothing, u: false, t: $elm$core$Maybe$Nothing, x: false, I: false}));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'system:opener'))
							]));
				}
			case 29:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.x) || (!_Utils_eq(model.aP, $elm$core$Maybe$Nothing)))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readSystemMenu(
					_Utils_update(
						model,
						{t: $elm$core$Maybe$Nothing}));
			case 30:
				var stamp = message.a;
				var intent = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.x) || ((!_Utils_eq(model.aP, $elm$core$Maybe$Nothing)) || ((!_Utils_eq(model.aq.dn, $elm$core$Maybe$Nothing)) || (!A2($author$project$SystemMenu$supported, intent, model.aq)))))) ? _Utils_Tuple2(model, _List_Nil) : ($author$project$SystemMenu$confirmed(intent) ? _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								t: $elm$core$Maybe$Just(intent)
							})),
					_List_fromArray(
						[
							$author$project$Desktop$Focus(
							A2($author$project$Desktop$key, model, 'system:cancel'))
						])) : A2($author$project$Desktop$sendSystemChange, intent, model));
			case 31:
				var stamp = message.a;
				var intent = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.x) || ((!_Utils_eq(
					model.t,
					$elm$core$Maybe$Just(intent))) || (!_Utils_eq(model.aP, $elm$core$Maybe$Nothing))))) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$author$project$Desktop$sendSystemChange,
					intent,
					_Utils_update(
						model,
						{t: $elm$core$Maybe$Nothing}));
			case 32:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.x) || _Utils_eq(model.t, $elm$core$Maybe$Nothing))) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{t: $elm$core$Maybe$Nothing})),
					_List_fromArray(
						[
							$author$project$Desktop$Focus(
							A2($author$project$Desktop$key, model, 'system:close'))
						]));
			case 33:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || _Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var windows = model.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								model,
								{
									s: false,
									A: false,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									C: $author$project$Notifications$clearFocus(model.C),
									v: true,
									F: true,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{
											i: $author$project$MenuBridge$retireChoices(windows.i),
											G: $elm$core$Maybe$Nothing
										})
								})));
					var _v98 = $author$project$Desktop$readNotifications(next);
					var reading = _v98.a;
					var commands = _v98.b;
					return _Utils_Tuple2(
						reading,
						_Utils_ap(
							commands,
							_List_fromArray(
								[
									$author$project$Desktop$Focus(
									A2($author$project$Desktop$key, reading, 'notifications:close'))
								])));
				}
			case 34:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.v)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								C: $author$project$Notifications$clearFocus(model.C),
								v: false,
								F: false
							}));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'notifications:opener'))
							]));
				}
			case 35:
				var stamp = message.a;
				var identity = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.v)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var notifications = A2($author$project$Notifications$focus, identity, model.C);
					return _Utils_eq(notifications, model.C) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
						_Utils_update(
							model,
							{C: notifications}),
						_List_Nil);
				}
			case 36:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.v)) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readNotifications(model);
			case 37:
				var stamp = message.a;
				var policy = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.v) || _Utils_eq(model.C.ft, policy))) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								C: A2($author$project$Notifications$configure, policy, model.C)
							})),
					_List_Nil);
			case 38:
				var stamp = message.a;
				var target = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.v) || (!_Utils_eq(model.aX, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v99 = _Utils_Tuple2(
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if ((!_v99.a.$) && (!_v99.b.$)) {
						var binding = _v99.a.a;
						var request = _v99.b.a;
						var _v100 = A3($author$project$Notifications$propose, request, target, model.C);
						var notifications = _v100.a;
						var proposal = _v100.b;
						if (proposal.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var value = proposal.a;
							return _Utils_Tuple2(
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{C: notifications, cM: request})),
								_List_fromArray(
									[
										$author$project$Desktop$Send(
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('notification-effect')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(binding)),
													_Utils_Tuple2(
													'requestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2('intent', value)
												])))
									]));
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 39:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || _Utils_eq(model.a.b.c3, $elm$core$Maybe$Nothing))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var windows = model.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								model,
								{
									s: false,
									A: false,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: false,
									r: $elm$core$Maybe$Nothing,
									p: true,
									N: true,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{
											i: $author$project$MenuBridge$retireChoices(windows.i),
											G: $elm$core$Maybe$Nothing
										})
								})));
					var _v102 = $author$project$Desktop$readSettings(next);
					var reading = _v102.a;
					var commands = _v102.b;
					var _v103 = $author$project$Desktop$readShortcutPreferences(reading);
					var shortcutsReading = _v103.a;
					var shortcutCommands = _v103.b;
					return _Utils_Tuple2(
						shortcutsReading,
						_Utils_ap(
							commands,
							_Utils_ap(
								shortcutCommands,
								_List_fromArray(
									[
										$author$project$Desktop$Focus(
										A2($author$project$Desktop$key, shortcutsReading, 'settings:close'))
									]))));
				}
			case 40:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.p)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{s: false, A: false, o: $elm$core$Maybe$Nothing, u: false, v: false, F: false, p: false, N: false, t: $elm$core$Maybe$Nothing, x: false, I: false}));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'settings:opener'))
							]));
				}
			case 41:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.p)) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{cT: !model.cT})),
					_List_Nil);
			case 42:
				var stamp = message.a;
				var route = message.b;
				var choice = message.c;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aM, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var preferences = A3($author$project$ShortcutPreferences$edit, route, choice, model.ah);
					return _Utils_eq(preferences, model.ah) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
						$author$project$Desktop$advance(
							_Utils_update(
								model,
								{ah: preferences})),
						_List_Nil);
				}
			case 43:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aM, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v104 = _Utils_Tuple2(
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if ((!_v104.a.$) && (!_v104.b.$)) {
						var binding = _v104.a.a;
						var request = _v104.b.a;
						var _v105 = A2($author$project$ShortcutPreferences$propose, request, model.ah);
						var preferences = _v105.a;
						var proposal = _v105.b;
						if (proposal.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var value = proposal.a;
							return _Utils_Tuple2(
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{cM: request, ah: preferences})),
								_List_fromArray(
									[
										$author$project$Desktop$Send(
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('shortcut-preferences-write')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(binding)),
													_Utils_Tuple2(
													'requestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2('proposal', value)
												])))
									]));
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 44:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aM, $elm$core$Maybe$Nothing)))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readShortcutPreferences(model);
			case 45:
				var stamp = message.a;
				var values = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.p)) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								ap: A2($author$project$Settings$edit, values, model.ap)
							})),
					_List_Nil);
			case 46:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.bi, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v107 = _Utils_Tuple2(
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if ((!_v107.a.$) && (!_v107.b.$)) {
						var binding = _v107.a.a;
						var request = _v107.b.a;
						var _v108 = A2($author$project$Settings$propose, request, model.ap);
						var settings = _v108.a;
						var proposal = _v108.b;
						if (proposal.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var value = proposal.a;
							return _Utils_Tuple2(
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{cM: request, ap: settings})),
								_List_fromArray(
									[
										$author$project$Desktop$Send(
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('shell-settings-write')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(binding)),
													_Utils_Tuple2(
													'requestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2('proposal', value)
												])))
									]));
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 47:
				var stamp = message.a;
				var override = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aH, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var motion = model.M;
					return _Utils_Tuple2(
						$author$project$Desktop$advance(
							_Utils_update(
								model,
								{
									M: _Utils_update(
										motion,
										{
											aY: A2($author$project$MotionPreferences$edit, override, motion.aY)
										})
								})),
						_List_Nil);
				}
			case 48:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aH, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v110 = _Utils_Tuple2(
						model.a.b.c3,
						$author$project$UInt64$next(model.cM));
					if ((!_v110.a.$) && (!_v110.b.$)) {
						var binding = _v110.a.a;
						var request = _v110.b.a;
						var motion = model.M;
						var _v111 = A2($author$project$MotionPreferences$propose, request, motion.aY);
						var preference = _v111.a;
						var proposal = _v111.b;
						if (proposal.$ === 1) {
							return _Utils_Tuple2(model, _List_Nil);
						} else {
							var value = proposal.a;
							return _Utils_Tuple2(
								$author$project$Desktop$advance(
									_Utils_update(
										model,
										{
											M: _Utils_update(
												motion,
												{aY: preference}),
											cM: request
										})),
								_List_fromArray(
									[
										$author$project$Desktop$Send(
										$elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('motion-preferences-write')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(binding)),
													_Utils_Tuple2(
													'requestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(request))),
													_Utils_Tuple2('proposal', value)
												])))
									]));
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 49:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.p) || (!_Utils_eq(model.aH, $elm$core$Maybe$Nothing)))) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readMotionPreferences(model);
			case 50:
				var stamp = message.a;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.p)) ? _Utils_Tuple2(model, _List_Nil) : $author$project$Desktop$readSettings(model);
			case 12:
				var stamp = message.a;
				return A3($author$project$Desktop$requestApplications, true, stamp, model);
			case 13:
				var stamp = message.a;
				return (!model.q) ? _Utils_Tuple2(model, _List_Nil) : A3($author$project$Desktop$requestApplications, false, stamp, model);
			case 15:
				return model.bA ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{ai: model.ai * 8, bA: true})),
					_List_Nil);
			case 16:
				var binding = message.a;
				var request = message.b;
				if (!_Utils_eq(
					model.a.b.c3,
					$elm$core$Maybe$Just(binding))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var pins = A2($author$project$Pins$rejectUnsent, request, model.H);
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{H: pins}),
						_List_Nil);
				}
			case 14:
				var stamp = message.a;
				var direction = message.b;
				var current = A3(
					$elm$core$Basics$clamp,
					0,
					$author$project$Desktop$applicationPageCount(model) - 1,
					model.ai);
				var target = current + direction;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.q) || ((!A2(
					$elm$core$List$member,
					direction,
					_List_fromArray(
						[-1, 1]))) || ((target < 0) || (_Utils_cmp(
					target,
					$author$project$Desktop$applicationPageCount(model)) > -1))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{ai: target}));
					var focus = ((direction > 0) && (_Utils_cmp(
						target,
						$author$project$Desktop$applicationPageCount(next) - 1) < 0)) ? 'control:page-next' : (((direction < 0) && (target > 0)) ? 'control:page-previous' : ((direction > 0) ? 'control:page-previous' : 'control:page-next'));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, focus))
							]));
				}
			case 70:
				var binding = message.a;
				var request = message.b;
				return (!A3($author$project$Desktop$canProveCatalogUnsent, binding, request, model)) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					_Utils_update(
						model,
						{
							K: A7($author$project$AdapterNotice$failedRead, 0, binding, request, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing, true, model.K),
							bn: $elm$core$Maybe$Just(
								{c3: binding, cM: request}),
							bo: false,
							y: $elm$core$Maybe$Nothing
						}),
					_List_Nil);
			case 66:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.q)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{bo: false, y: $elm$core$Maybe$Nothing, q: false}));
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, 'control:opener'))
							]));
				}
			case 51:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (model.l || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || ((!$author$project$Shell$available(model.a.b)) || (!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing)))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var base = A2(
						$elm$core$Maybe$withDefault,
						model,
						A2(
							$elm$core$Maybe$map,
							function (menu) {
								return A2(
									$author$project$Desktop$windowBase,
									$author$project$TaskbarShell$MenuEvent(
										$author$project$Menu$Dismiss(menu.cc)),
									model).a;
							},
							$author$project$MenuBridge$menuSnapshot(model.a.i).aC));
					var currentGroups = A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						$author$project$Desktop$taskViewGroups(base));
					var recoveryOrigin = A3($author$project$OverviewRecovery$retainedOrigin, base.a.b.c3, base.a.b.V.dz, base.aE);
					var restoredWorkspace = A2(
						$elm$core$Maybe$withDefault,
						$elm$core$Maybe$Nothing,
						A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.dB;
							},
							recoveryOrigin));
					var validWorkspace = A2(
						$elm$core$Maybe$andThen,
						function (workspace) {
							return A2(
								$elm$core$Maybe$map,
								function ($) {
									return $.cG;
								},
								$elm$core$List$head(
									A2(
										$elm$core$List$filter,
										A2(
											$elm$core$Basics$composeR,
											function ($) {
												return $.cG;
											},
											$elm$core$Basics$eq(workspace)),
										currentGroups)));
						},
						restoredWorkspace);
					var windows = base.a;
					var next = $author$project$Desktop$advance(
						$author$project$Desktop$retireSwitcher(
							_Utils_update(
								base,
								{
									y: $elm$core$Maybe$Nothing,
									s: false,
									A: false,
									o: $elm$core$Maybe$Nothing,
									u: false,
									E: $elm$core$Maybe$Nothing,
									v: false,
									F: false,
									q: false,
									l: true,
									Z: $elm$core$Maybe$Nothing,
									T: validWorkspace,
									r: $elm$core$Maybe$Nothing,
									p: false,
									N: false,
									w: $elm$core$Maybe$Nothing,
									t: $elm$core$Maybe$Nothing,
									x: false,
									I: false,
									a: _Utils_update(
										windows,
										{G: $elm$core$Maybe$Nothing})
								})));
					var groups = A2(
						$elm$core$Maybe$withDefault,
						_List_Nil,
						$author$project$Desktop$taskViewGroups(next));
					var recoveryFocus = A2(
						$elm$core$Maybe$map,
						function (_v113) {
							return A2(
								$elm$core$Maybe$withDefault,
								A2($author$project$Desktop$key, next, 'overview:all'),
								A2(
									$elm$core$Maybe$map,
									function (workspace) {
										return A2($author$project$Desktop$key, next, 'overview:workspace:' + workspace);
									},
									validWorkspace));
						},
						recoveryOrigin);
					var focus = A2(
						$elm$core$Maybe$withDefault,
						A2(
							$elm$core$Maybe$withDefault,
							A2($author$project$Desktop$key, next, 'overview:all'),
							A2(
								$elm$core$Maybe$map,
								A2(
									$elm$core$Basics$composeR,
									function ($) {
										return $.cG;
									},
									function (workspace) {
										return A2($author$project$Desktop$key, next, 'overview:workspace:' + workspace);
									}),
								$elm$core$List$head(
									A2(
										$elm$core$List$filter,
										function ($) {
											return $.dC;
										},
										groups)))),
						recoveryFocus);
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(focus)
							]));
				}
			case 57:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.l)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var target = A2(
						$elm$core$Maybe$map,
						function (binding) {
							return {
								c3: binding,
								bp: $author$project$Desktop$OverviewOpener,
								z: A2(
									$elm$core$Maybe$map,
									A2(
										$elm$core$Basics$composeR,
										function ($) {
											return $.R;
										},
										function ($) {
											return $.z;
										}),
									model.a.b.V.av)
							};
						},
						model.a.b.c3);
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{l: false, Z: $elm$core$Maybe$Nothing, T: $elm$core$Maybe$Nothing}));
					var _v114 = A2(
						$author$project$Desktop$windowBase,
						$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
						next);
					var refreshing = _v114.a;
					var commands = _v114.b;
					return _Utils_Tuple2(
						_Utils_update(
							refreshing,
							{r: target}),
						commands);
				}
			case 58:
				var stamp = message.a;
				var destination = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!model.l)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v115 = A2($author$project$Desktop$workspaceNavigationIntent, model, destination);
					if (!_v115.$) {
						var intent = _v115.a;
						var _v116 = A2($author$project$WorkspaceNavigation$begin, intent, model.J);
						var navigation = _v116.a;
						var wire = _v116.b;
						var next = $author$project$Desktop$advance(
							_Utils_update(
								model,
								{D: '', l: false, Z: $elm$core$Maybe$Nothing, r: $elm$core$Maybe$Nothing, J: navigation}));
						if (!wire.$) {
							var request = wire.a;
							return _Utils_Tuple2(
								next,
								_List_fromArray(
									[
										$author$project$Desktop$Send(request),
										$author$project$Desktop$ArmWorkspaceNavigation(intent)
									]));
						} else {
							return _Utils_Tuple2(model, _List_Nil);
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 61:
				var stamp = message.a;
				var selected = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.l) || _Utils_eq(selected, model.T))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{T: selected}));
					var exists = A2(
						$elm$core$Maybe$withDefault,
						true,
						A2(
							$elm$core$Maybe$map,
							function (workspace) {
								return A2(
									$elm$core$Maybe$withDefault,
									false,
									A2(
										$elm$core$Maybe$map,
										$elm$core$List$any(
											function (g) {
												return _Utils_eq(g.cG, workspace);
											}),
										$author$project$Desktop$taskViewGroups(model)));
							},
							selected));
					return (!exists) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2(
									$author$project$Desktop$key,
									next,
									A2(
										$elm$core$Maybe$withDefault,
										'overview:all',
										A2(
											$elm$core$Maybe$map,
											$elm$core$Basics$append('overview:workspace:'),
											selected))))
							]));
				}
			case 63:
				var stamp = message.a;
				var root = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!A2($author$project$Desktop$overviewTransferAvailable, model, root))) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{
								Z: $elm$core$Maybe$Just(root)
							})),
					_List_Nil);
			case 64:
				var stamp = message.a;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.l) || _Utils_eq(model.Z, $elm$core$Maybe$Nothing))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var next = $author$project$Desktop$advance(
						_Utils_update(
							model,
							{Z: $elm$core$Maybe$Nothing}));
					var origin = A2(
						$elm$core$Maybe$andThen,
						function (root) {
							return A2($author$project$Desktop$overviewTransferAvailable, next, root) ? $elm$core$Maybe$Just(
								'overview:transfer:' + $author$project$UInt64$string(root)) : $elm$core$Maybe$Nothing;
						},
						model.Z);
					var workspace = A2(
						$elm$core$Maybe$andThen,
						function (identity) {
							return A2(
								$elm$core$Maybe$andThen,
								function (groups) {
									return A2(
										$elm$core$List$any,
										function (group) {
											return _Utils_eq(group.cG, identity);
										},
										groups) ? $elm$core$Maybe$Just('overview:workspace:' + identity) : $elm$core$Maybe$Nothing;
								},
								$author$project$Desktop$taskViewGroups(next));
						},
						model.T);
					var target = A2(
						$elm$core$Maybe$withDefault,
						A2($elm$core$Maybe$withDefault, 'overview:all', workspace),
						origin);
					return _Utils_Tuple2(
						next,
						_List_fromArray(
							[
								$author$project$Desktop$Focus(
								A2($author$project$Desktop$key, next, target))
							]));
				}
			case 65:
				var stamp = message.a;
				var root = message.b;
				var destination = message.c;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!_Utils_eq(
					model.Z,
					$elm$core$Maybe$Just(root))) || (!_Utils_eq(model.k, $elm$core$Maybe$Nothing)))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v118 = _Utils_Tuple3(
						A2(
							$elm$core$Maybe$andThen,
							function (g) {
								return A3($author$project$Transfer$propose, g, root, destination);
							},
							model.a.b.ac),
						model.a.b.c3,
						model.a.b.V.av);
					if (((!_v118.a.$) && (!_v118.b.$)) && (!_v118.c.$)) {
						var proposed = _v118.a.a;
						var binding = _v118.b.a;
						var observed = _v118.c.a;
						var _v119 = $elm$core$List$head(
							A2(
								$elm$core$List$filter,
								function (f) {
									return _Utils_eq(f.n, root) && f.c2;
								},
								A2(
									$elm$core$List$concatMap,
									function ($) {
										return $.aB;
									},
									$author$project$TaskbarShell$groups(model.a))));
						if (!_v119.$) {
							var family = _v119.a;
							var _v120 = A2(
								$author$project$Desktop$windowBase,
								$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
								_Utils_update(
									model,
									{D: '', l: false, Z: $elm$core$Maybe$Nothing}));
							var next = _v120.a;
							var effects = _v120.b;
							var _v121 = next.a.b.y;
							if (!_v121.$) {
								var request = _v121.a;
								var token = A2($author$project$Desktop$ChoiceToken, binding, request);
								return _Utils_Tuple2(
									_Utils_update(
										next,
										{
											k: $elm$core$Maybe$Just(
												{
													c0: family.c0,
													c3: binding,
													aQ: $elm$core$Maybe$Nothing,
													z: observed.R.z,
													bf: $elm$core$Maybe$Nothing,
													n: root,
													bj: token,
													a$: $elm$core$Maybe$Just(proposed)
												})
										}),
									_Utils_ap(
										effects,
										_List_fromArray(
											[
												$author$project$Desktop$ArmChoice(token)
											])));
							} else {
								return _Utils_Tuple2(next, effects);
							}
						} else {
							return _Utils_Tuple2(model, _List_Nil);
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 62:
				var stamp = message.a;
				var root = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.l) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || (!$author$project$Shell$available(model.a.b))))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var selected = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (family) {
								return _Utils_eq(family.n, root) && (family.c2 && (!A3($author$project$MenuBridge$blockedFor, root, model.a.b, model.a.i)));
							},
							A2(
								$elm$core$List$concatMap,
								function ($) {
									return $.a;
								},
								A2(
									$elm$core$List$filter,
									function (g) {
										return _Utils_eq(model.T, $elm$core$Maybe$Nothing) || _Utils_eq(
											model.T,
											$elm$core$Maybe$Just(g.cG));
									},
									A2(
										$elm$core$Maybe$withDefault,
										_List_Nil,
										$author$project$Desktop$taskViewGroups(model))))));
					var _v122 = _Utils_Tuple3(selected, model.a.b.c3, model.a.b.V.av);
					if (((!_v122.a.$) && (!_v122.b.$)) && (!_v122.c.$)) {
						var family = _v122.a.a;
						var binding = _v122.b.a;
						var observed = _v122.c.a;
						var _v123 = A2(
							$author$project$Desktop$windowBase,
							$author$project$TaskbarShell$Native($author$project$Shell$Refresh),
							_Utils_update(
								model,
								{D: '', l: false}));
						var next = _v123.a;
						var effects = _v123.b;
						var _v124 = next.a.b.y;
						if (!_v124.$) {
							var request = _v124.a;
							var token = A2($author$project$Desktop$ChoiceToken, binding, request);
							return _Utils_Tuple2(
								_Utils_update(
									next,
									{
										k: $elm$core$Maybe$Just(
											{c0: family.c0, c3: binding, aQ: $elm$core$Maybe$Nothing, z: observed.R.z, bf: $elm$core$Maybe$Nothing, n: root, bj: token, a$: $elm$core$Maybe$Nothing}),
										aE: A2(
											$author$project$OverviewRecovery$begin,
											{c3: binding, n: root, dB: model.T},
											request)
									}),
								_Utils_ap(
									effects,
									_List_fromArray(
										[
											$author$project$Desktop$ArmChoice(token)
										])));
						} else {
							return _Utils_Tuple2(next, effects);
						}
					} else {
						return _Utils_Tuple2(model, _List_Nil);
					}
				}
			case 67:
				var stamp = message.a;
				var query = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.q) || (_Utils_eq(query, model.ck) || (($elm$core$String$length(query) > 256) || A2(
					$elm$core$String$any,
					function (c) {
						return ($elm$core$Char$toCode(c) < 32) || ($elm$core$Char$toCode(c) === 127);
					},
					query))))) ? _Utils_Tuple2(model, _List_Nil) : _Utils_Tuple2(
					$author$project$Desktop$advance(
						_Utils_update(
							model,
							{ai: 0, ck: query})),
					_List_Nil);
			case 68:
				var stamp = message.a;
				var identity = message.b;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.q) || ((!$author$project$Pins$writable(model.H)) || ((!A2(
					$elm$core$List$member,
					identity,
					$author$project$Desktop$pinIdentities(model))) && _Utils_eq(
					A2(
						$elm$core$Maybe$andThen,
						$author$project$Catalog$lookup(identity),
						model.aj),
					$elm$core$Maybe$Nothing))))) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$author$project$Desktop$savePins,
					A2(
						$author$project$Pins$toggle,
						identity,
						$author$project$Desktop$pinIdentities(model)),
					model);
			case 69:
				var stamp = message.a;
				var identity = message.b;
				var direction = message.c;
				return ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || ((!model.q) || (!$author$project$Pins$writable(model.H)))) ? _Utils_Tuple2(model, _List_Nil) : A2(
					$author$project$Desktop$savePins,
					A3(
						$author$project$Pins$move,
						identity,
						direction,
						$author$project$Desktop$pinIdentities(model)),
					model);
			case 71:
				var stamp = message.a;
				var identity = message.b;
				if ((!_Utils_eq(
					$author$project$Desktop$capture(model),
					$elm$core$Maybe$Just(stamp))) || (!A2($author$project$Desktop$newInstanceAvailable, identity, model))) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v125 = A2($author$project$Launch$select, identity, model.B);
					if (_v125.$ === 1) {
						return _Utils_Tuple2(model, _List_Nil);
					} else {
						var selection = _v125.a;
						var windows = model.a;
						var closed = $author$project$Desktop$advance(
							$author$project$Desktop$retireSwitcher(
								_Utils_update(
									model,
									{
										ce: false,
										o: $elm$core$Maybe$Nothing,
										u: false,
										E: $elm$core$Maybe$Nothing,
										q: false,
										r: $elm$core$Maybe$Nothing,
										w: $elm$core$Maybe$Nothing,
										a: _Utils_update(
											windows,
											{
												i: $author$project$MenuBridge$retireChoices(windows.i),
												G: $elm$core$Maybe$Nothing
											})
									})));
						return A2(
							$author$project$Desktop$update,
							$author$project$Desktop$Start(selection),
							closed);
					}
				}
			case 72:
				var selection = message.a;
				if (!_Utils_eq(
					$author$project$MenuBridge$preparedSnapshot(model.a.i),
					$elm$core$Maybe$Nothing)) {
					return _Utils_Tuple2(model, _List_Nil);
				} else {
					var _v126 = A2($author$project$Launch$start, selection, model.B);
					var launch = _v126.a;
					var intent = _v126.b;
					var _v127 = _Utils_Tuple2(intent, model.a.b.c3);
					if ((!_v127.a.$) && (!_v127.b.$)) {
						var wire = _v127.a.a;
						var binding = _v127.b.a;
						return _Utils_Tuple2(
							$author$project$Desktop$retireSwitcher(
								_Utils_update(
									model,
									{y: $elm$core$Maybe$Nothing, B: launch, cI: model.q, l: false})),
							A2(
								$elm$core$List$cons,
								$author$project$Desktop$Send(
									$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'protocolVersion',
												$elm$json$Json$Encode$int(3)),
												_Utils_Tuple2(
												'kind',
												$elm$json$Json$Encode$string('application-launch')),
												_Utils_Tuple2(
												'binding',
												$author$project$Binding$encode(binding)),
												_Utils_Tuple2('intent', wire)
											]))),
								A2(
									$elm$core$Maybe$withDefault,
									_List_Nil,
									A2(
										$elm$core$Maybe$map,
										A2($elm$core$Basics$composeR, $author$project$Desktop$Arm, $elm$core$List$singleton),
										$author$project$Launch$pending(launch)))));
					} else {
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{B: launch}),
							_List_Nil);
					}
				}
			case 73:
				var token = message.a;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							B: A2($author$project$Launch$timeout, token, model.B)
						}),
					_List_Nil);
			default:
				var token = message.a;
				return _Utils_Tuple2(
					_Utils_update(
						model,
						{
							B: A2($author$project$Launch$acknowledgeUnknown, token, model.B)
						}),
					_List_Nil);
		}
	});
var $author$project$Desktop$updateOrdinary = F2(
	function (message, model) {
		if (($author$project$WorkspaceNavigation$blocked(model.J) && $author$project$Desktop$workspaceMutation(message)) || ((A2($author$project$PointerOwnership$blocked, model.a.b.c3, model.bz) && ($author$project$Desktop$gestureAction(message) && (!(model.a.b.c1 && $author$project$Desktop$applicationGesture(message))))) || ((!A2($author$project$Motion$ready, model.a.b.c3, model.M)) && $author$project$Desktop$motionGesture(message)))) {
			return _Utils_Tuple2(model, _List_Nil);
		} else {
			var _v0 = A2($author$project$Desktop$updateAvailable, message, model);
			var next = _v0.a;
			var effects = _v0.b;
			var windowMutation = A2(
				$elm$core$List$any,
				function (effect) {
					if ((!effect.$) && (!effect.a.$)) {
						var wire = effect.a.a;
						return _Utils_eq(
							A2(
								$elm$json$Json$Decode$decodeValue,
								A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
								wire),
							$elm$core$Result$Ok('window-effect'));
					} else {
						return false;
					}
				},
				effects);
			var feedback = windowMutation ? _Utils_update(
				next,
				{
					J: $author$project$WorkspaceNavigation$clear(next.J)
				}) : next;
			var _v1 = $author$project$Desktop$resumeOverview(feedback);
			var recovered = _v1.a;
			var recoveryEffects = _v1.b;
			var _v2 = $author$project$Desktop$resumeWorkspaceOverview(recovered);
			var workspace = _v2.a;
			var workspaceEffects = _v2.b;
			var _v3 = $author$project$Desktop$syncOverviewWorkspace(workspace);
			var overview = _v3.a;
			var overviewEffects = _v3.b;
			var _v4 = $author$project$Desktop$syncMotion(overview);
			var synced = _v4.a;
			var commands = _v4.b;
			return _Utils_Tuple2(
				synced,
				_Utils_ap(
					effects,
					_Utils_ap(
						recoveryEffects,
						_Utils_ap(
							workspaceEffects,
							_Utils_ap(overviewEffects, commands)))));
		}
	});
var $author$project$SurfaceController$applyOrdinary = F2(
	function (message, current) {
		var model = current;
		if (model.aA) {
			return _Utils_Tuple2(current, _List_Nil);
		} else {
			var oldMode = $author$project$Surface$mode(model.e);
			var _v0 = A2($author$project$Desktop$update, message, model.e);
			var next = _v0.a;
			var effects = _v0.b;
			var changed = !_Utils_eq(next, model.e);
			var nextMode = $author$project$Surface$mode(next);
			var newLease = (nextMode !== 'closed') && ((!_Utils_eq(nextMode, oldMode)) || ((!_Utils_eq(
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.cc;
					},
					$author$project$MenuBridge$menuSnapshot(model.e.a.i).aC),
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.cc;
					},
					$author$project$MenuBridge$menuSnapshot(next.a.i).aC))) || (((nextMode === 'picker') && (!_Utils_eq(
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.e7;
					},
					model.e.a.G),
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.e7;
					},
					next.a.G)))) || ((nextMode === 'switcher') && (!_Utils_eq(
				$author$project$Switcher$generation(model.e.j),
				$author$project$Switcher$generation(next.j)))))));
			var lease = newLease ? $author$project$UInt64$next(model.ae) : $elm$core$Maybe$Just(model.ae);
			if ((!changed) && $elm$core$List$isEmpty(effects)) {
				return _Utils_Tuple2(current, _List_Nil);
			} else {
				var stableSurface = (!_Utils_eq(model._, $author$project$UInt64$zero)) && ((!newLease) && ($elm$core$List$isEmpty(effects) && _Utils_eq(
					A2(
						$elm$json$Json$Encode$encode,
						0,
						A3($author$project$Surface$packet, model._, model.ae, next)),
					A2(
						$elm$json$Json$Encode$encode,
						0,
						$author$project$SurfaceController$frame(current)))));
				var stableApplications = function () {
					if (((message.$ === 1) && (!message.a.$)) && (message.a.a.$ === 11)) {
						return (oldMode === 'applications') && ((nextMode === 'applications') && ((!newLease) && _Utils_eq(
							A2(
								$elm$json$Json$Encode$encode,
								0,
								A3($author$project$Surface$packet, model._, model.ae, next)),
							A2(
								$elm$json$Json$Encode$encode,
								0,
								$author$project$SurfaceController$frame(current)))));
					} else {
						return false;
					}
				}();
				if (stableSurface || stableApplications) {
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{e: next}),
						A2($elm$core$List$map, $author$project$SurfaceController$DesktopEffect, effects));
				} else {
					var _v1 = _Utils_Tuple2(
						$author$project$UInt64$next(model._),
						lease);
					if ((!_v1.a.$) && (!_v1.b.$)) {
						var publication = _v1.a.a;
						var token = _v1.b.a;
						var result = _Utils_update(
							model,
							{e: next, ae: token, _: publication});
						return _Utils_Tuple2(
							result,
							A2(
								$elm$core$List$cons,
								$author$project$SurfaceController$Publish(
									$author$project$SurfaceController$frame(result)),
								A2($elm$core$List$map, $author$project$SurfaceController$DesktopEffect, effects)));
					} else {
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{aA: true}),
							_List_Nil);
					}
				}
			}
		}
	});
var $author$project$ReconciliationTracking$legacy = F3(
	function (raw, shell, model) {
		if ((!_Utils_eq(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				raw),
			$elm$core$Result$Ok('host-uncertain'))) || ((shell.m !== 1) || ((!_Utils_eq(
			$elm$core$Result$toMaybe(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
					raw)),
			shell.c3)) || (!_Utils_eq(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'protocolVersion', $elm$json$Json$Decode$int),
				raw),
			$elm$core$Result$Ok(3)))))) {
			return model;
		} else {
			var _v0 = A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
				raw);
			if (_v0.$ === 1) {
				return model;
			} else {
				var intent = _v0.a;
				var protocol = A2(
					$elm$core$Result$withDefault,
					1,
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$field, 'effectProtocol', $elm$json$Json$Decode$int),
						raw));
				var entry = {af: intent, en: protocol};
				return (A2($elm$core$List$member, entry, model.bu) || (($elm$core$List$length(model.bu) >= 64) || (!A2(
					$elm$core$List$any,
					function (t) {
						return _Utils_eq(t.af, intent) && (_Utils_eq(t.az, protocol) && (t.O === 4));
					},
					shell.V.fM)))) ? model : _Utils_update(
					model,
					{
						bu: A2($elm$core$List$cons, entry, model.bu)
					});
			}
		}
	});
var $author$project$ReceiptRouter$reservationKey = F3(
	function (bound, protocolId, original) {
		var operationValue = function () {
			var _v0 = original.bc;
			switch (_v0.$) {
				case 0:
					return $elm$core$Maybe$Just(0);
				case 1:
					return $elm$core$Maybe$Just(1);
				case 3:
					return $elm$core$Maybe$Just(2);
				case 4:
					return $elm$core$Maybe$Just(3);
				case 5:
					return $elm$core$Maybe$Just(4);
				case 8:
					return $elm$core$Maybe$Just(5);
				case 9:
					return $elm$core$Maybe$Just(6);
				default:
					return $elm$core$Maybe$Nothing;
			}
		}();
		return A2(
			$elm$core$Maybe$map,
			function (op) {
				return {
					af: {R: original.R, e7: original.e7, au: original.au, bc: op, cM: original.cM},
					eb: bound,
					en: protocolId
				};
			},
			operationValue);
	});
var $author$project$ReceiptRouter$findReservation = F4(
	function (bound, protocolId, original, _v0) {
		var entries = _v0;
		return A2(
			$elm$core$Maybe$andThen,
			function (_native) {
				return A2(
					$elm$core$Maybe$map,
					function (entry) {
						return _Utils_Tuple2(entry.ch, entry.c3);
					},
					$elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (entry) {
								return _Utils_eq(entry.aV, _native);
							},
							entries)));
			},
			A3($author$project$ReceiptRouter$reservationKey, bound, protocolId, original));
	});
var $author$project$Menu$observeUnknown = F3(
	function (local, bound, _v0) {
		var state = _v0;
		return _Utils_update(
			state,
			{
				aC: A2(
					$elm$core$Maybe$map,
					function (menu) {
						return (_Utils_eq(menu.c3, bound) && _Utils_eq(
							menu.O,
							$author$project$Menu$Pending(local))) ? _Utils_update(
							menu,
							{
								O: $author$project$Menu$Unknown(local)
							}) : menu;
					},
					state.aC),
				fn: A2(
					$elm$core$List$map,
					function (entry) {
						return (_Utils_eq(entry.cc, local) && _Utils_eq(entry.c3, bound)) ? _Utils_update(
							entry,
							{bk: true}) : entry;
					},
					state.fn)
			});
	});
var $author$project$MenuBridge$observeReservationUnknown = F4(
	function (bound, protocolId, intent, model) {
		var state = model;
		return A2(
			$elm$core$Maybe$withDefault,
			model,
			A2(
				$elm$core$Maybe$map,
				function (_v0) {
					var local = _v0.a;
					var original = _v0.b;
					return _Utils_update(
						state,
						{
							aC: A3($author$project$Menu$observeUnknown, local, original, state.aC)
						});
				},
				A4($author$project$ReceiptRouter$findReservation, bound, protocolId, intent, state.aw)));
	});
var $author$project$ReconciliationFrame$Context = F4(
	function (lifetime, epoch, output, revision) {
		return {e4: epoch, fe: lifetime, z: output, cN: revision};
	});
var $author$project$ReconciliationFrame$contextDecoder = A2(
	$author$project$ReconciliationFrame$strict,
	_List_fromArray(
		['lifetime', 'epoch', 'output', 'revision']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$ReconciliationFrame$Context,
		A2($elm$json$Json$Decode$field, 'lifetime', $author$project$ReconciliationFrame$positive),
		A2($elm$json$Json$Decode$field, 'epoch', $author$project$ReconciliationFrame$positive),
		A2($elm$json$Json$Decode$field, 'output', $author$project$ReconciliationFrame$positive),
		A2($elm$json$Json$Decode$field, 'revision', $author$project$ReconciliationFrame$positive)));
var $author$project$ReconciliationTracking$observed = F4(
	function (raw, before, after, model) {
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A3(
				$elm$json$Json$Decode$map2,
				$elm$core$Tuple$pair,
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder)),
			raw);
		if (_v0.$ === 1) {
			return model;
		} else {
			var _v1 = _v0.a;
			var kind = _v1.a;
			var request = _v1.b;
			var geometryContext = A2(
				$elm$core$Maybe$map,
				function ($) {
					return $.R;
				},
				after.ac);
			var geometryAccepted = (kind === 'geometry-facts') && (_Utils_eq(
				before.cE,
				$elm$core$Maybe$Just(request)) && ((!_Utils_eq(
				after.cE,
				$elm$core$Maybe$Just(request))) && _Utils_eq(
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.cM;
					},
					after.ac),
				$elm$core$Maybe$Just(request))));
			var actionContext = $elm$core$Result$toMaybe(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'context', $author$project$ReconciliationFrame$contextDecoder),
					raw));
			var actionAccepted = (kind === 'action-projection') && (_Utils_eq(
				before.y,
				$elm$core$Maybe$Just(request)) && ((!_Utils_eq(
				after.y,
				$elm$core$Maybe$Just(request))) && ((!_Utils_eq(actionContext, $elm$core$Maybe$Nothing)) && _Utils_eq(
				A2(
					$elm$core$Maybe$map,
					function ($) {
						return $.R;
					},
					after.V.av),
				actionContext))));
			return _Utils_update(
				model,
				{
					P: A2(
						$elm$core$List$map,
						function (slot) {
							return _Utils_eq(slot.el, $elm$core$Maybe$Nothing) ? slot : ((actionAccepted && _Utils_eq(
								slot.bK,
								$elm$core$Maybe$Just(request))) ? _Utils_update(
								slot,
								{
									eV: A2(
										$elm$core$Maybe$map,
										function (context) {
											return {R: context, cM: request};
										},
										actionContext)
								}) : ((geometryAccepted && _Utils_eq(
								slot.a8,
								$elm$core$Maybe$Just(request))) ? _Utils_update(
								slot,
								{
									ac: A2(
										$elm$core$Maybe$map,
										function (context) {
											return {R: context, cM: request};
										},
										geometryContext)
								}) : slot));
						},
						model.P)
				});
		}
	});
var $author$project$ReconciliationFrame$ReservationReleased = F3(
	function (a, b, c) {
		return {$: 1, a: a, b: b, c: c};
	});
var $author$project$ReconciliationFrame$contextMatches = F2(
	function (binding, context) {
		return A3($author$project$Binding$matchesContext, context.fe, context.e4, binding);
	});
var $author$project$ReconciliationFrame$Record = F5(
	function (schema, effectProtocol, binding, intent, status) {
		return {c3: binding, az: effectProtocol, af: intent, fD: schema, O: status};
	});
var $author$project$ReconciliationFrame$protocolDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (v) {
		return ((v === 1) || (v === 2)) ? $elm$json$Json$Decode$succeed(v) : $elm$json$Json$Decode$fail('Unsupported effect protocol');
	},
	$elm$json$Json$Decode$int);
var $author$project$ReconciliationFrame$recordDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (record) {
		var operationMatches = (record.az === 1) ? A2(
			$elm$core$List$member,
			record.af.bc,
			_List_fromArray(
				[$author$project$Effects$Minimize, $author$project$Effects$Restore, $author$project$Effects$Activate])) : ($author$project$Effects$protocol(record.af.bc) === 2);
		return (A3($author$project$Binding$matchesContext, record.af.R.fe, record.af.R.e4, record.c3) && operationMatches) ? $elm$json$Json$Decode$succeed(record) : $elm$json$Json$Decode$fail('Record authority or operation/protocol mismatch');
	},
	A2(
		$author$project$ReconciliationFrame$strict,
		_List_fromArray(
			['schema', 'effectProtocol', 'binding', 'intent', 'status']),
		A6(
			$elm$json$Json$Decode$map5,
			$author$project$ReconciliationFrame$Record,
			A2(
				$elm$json$Json$Decode$field,
				'schema',
				$author$project$ReconciliationFrame$exactInt(2)),
			A2($elm$json$Json$Decode$field, 'effectProtocol', $author$project$ReconciliationFrame$protocolDecoder),
			A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
			A2($elm$json$Json$Decode$field, 'intent', $author$project$Effects$intentDecoder),
			A2(
				$elm$json$Json$Decode$field,
				'status',
				A2(
					$elm$json$Json$Decode$map,
					function (_v0) {
						return 4;
					},
					$author$project$ReconciliationFrame$exactString('Unknown'))))));
var $author$project$ReconciliationFrame$Release = F3(
	function (id, proof, observation) {
		return {cc: id, bw: observation, el: proof};
	});
var $author$project$ReconciliationFrame$Observation = F4(
	function (actionRequestId, geometryRequestId, actionContext, geometryContext) {
		return {a3: actionContext, cu: actionRequestId, a7: geometryContext, cF: geometryRequestId};
	});
var $author$project$ReconciliationFrame$observationDecoder = A2(
	$author$project$ReconciliationFrame$strict,
	_List_fromArray(
		['actionRequestId', 'geometryRequestId', 'actionContext', 'geometryContext']),
	A5(
		$elm$json$Json$Decode$map4,
		$author$project$ReconciliationFrame$Observation,
		A2($elm$json$Json$Decode$field, 'actionRequestId', $author$project$ReconciliationFrame$positive),
		A2($elm$json$Json$Decode$field, 'geometryRequestId', $author$project$ReconciliationFrame$positive),
		A2($elm$json$Json$Decode$field, 'actionContext', $author$project$ReconciliationFrame$contextDecoder),
		A2($elm$json$Json$Decode$field, 'geometryContext', $author$project$ReconciliationFrame$contextDecoder)));
var $author$project$ReconciliationFrame$releaseIdDecoder = A2(
	$elm$json$Json$Decode$andThen,
	function (value) {
		return (($elm$core$String$length(value) === 64) && A2(
			$elm$core$List$all,
			function (c) {
				return ((c >= '0') && (c <= '9')) || ((c >= 'a') && (c <= 'f'));
			},
			$elm$core$String$toList(value))) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Release ID must be64lowerhex');
	},
	$elm$json$Json$Decode$string);
var $author$project$ReconciliationFrame$releaseDecoder = A2(
	$author$project$ReconciliationFrame$strict,
	_List_fromArray(
		['id', 'proof', 'observation']),
	A4(
		$elm$json$Json$Decode$map3,
		$author$project$ReconciliationFrame$Release,
		A2($elm$json$Json$Decode$field, 'id', $author$project$ReconciliationFrame$releaseIdDecoder),
		A2($elm$json$Json$Decode$field, 'proof', $author$project$ReconciliationFrame$proofDecoder),
		A2($elm$json$Json$Decode$field, 'observation', $author$project$ReconciliationFrame$observationDecoder)));
var $author$project$ReconciliationFrame$decodeReleased = F2(
	function (expected, raw) {
		var decoder = A2(
			$author$project$ReconciliationFrame$strict,
			_List_fromArray(
				['protocolVersion', 'kind', 'binding', 'record', 'release']),
			A6(
				$elm$json$Json$Decode$map5,
				F5(
					function (_v1, _v2, binding, record, release) {
						return _Utils_Tuple3(binding, record, release);
					}),
				A2(
					$elm$json$Json$Decode$field,
					'protocolVersion',
					$author$project$ReconciliationFrame$exactInt(3)),
				A2(
					$elm$json$Json$Decode$field,
					'kind',
					$author$project$ReconciliationFrame$exactString('host-reservation-released')),
				A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
				A2($elm$json$Json$Decode$field, 'record', $author$project$ReconciliationFrame$recordDecoder),
				A2($elm$json$Json$Decode$field, 'release', $author$project$ReconciliationFrame$releaseDecoder)));
		return A2(
			$elm$core$Result$andThen,
			function (_v0) {
				var binding = _v0.a;
				var record = _v0.b;
				var release = _v0.c;
				var proof = release.el;
				var observation = release.bw;
				var expectedValid = A2($author$project$ReconciliationFrame$contextMatches, expected.cA, expected.a3) && (A2($author$project$ReconciliationFrame$contextMatches, expected.cA, expected.a7) && _Utils_eq(expected.a3.z, expected.a7.z));
				var correlated = _Utils_eq(binding, expected.cA) && (_Utils_eq(record, expected.fz) && (_Utils_eq(proof.c3, binding) && (_Utils_eq(proof.eo, record.c3) && (_Utils_eq(proof.eu, expected.em) && ((!_Utils_eq(record.c3, binding)) && (A2($author$project$Binding$sameLifetime, record.af.R.fe, binding) && (_Utils_eq(observation.cu, expected.cu) && (_Utils_eq(observation.cF, expected.cF) && (_Utils_eq(observation.a3, expected.a3) && (_Utils_eq(observation.a7, expected.a7) && (A2($author$project$ReconciliationFrame$contextMatches, binding, observation.a3) && (A2($author$project$ReconciliationFrame$contextMatches, binding, observation.a7) && _Utils_eq(observation.a3.z, observation.a7.z)))))))))))));
				return (expectedValid && correlated) ? $elm$core$Result$Ok(
					A3($author$project$ReconciliationFrame$ReservationReleased, binding, record, release)) : $elm$core$Result$Err('Uncorrelated retirement or current observation');
			},
			A2(
				$elm$core$Result$mapError,
				$elm$json$Json$Decode$errorToString,
				A2($elm$json$Json$Decode$decodeValue, decoder, raw)));
	});
var $author$project$ReconciliationTracking$same = F2(
	function (a, b) {
		return _Utils_eq(a.c3, b.c3) && (_Utils_eq(a.af, b.af) && _Utils_eq(a.az, b.az));
	});
var $author$project$ReconciliationTracking$release = F3(
	function (current, raw, model) {
		return A2(
			$elm$core$Result$andThen,
			function (record) {
				if (A2(
					$elm$core$List$any,
					function (entry) {
						return _Utils_eq(entry.af, record.af) && _Utils_eq(entry.en, record.az);
					},
					model.bu)) {
					return $elm$core$Result$Err('Legacy origin remains unsupported');
				} else {
					var _v0 = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (slot) {
								return A2($author$project$ReconciliationTracking$same, slot.fz, record);
							},
							model.P));
					if (_v0.$ === 1) {
						return $elm$core$Result$Err('No stored Unknown reservation');
					} else {
						var slot = _v0.a;
						var _v1 = _Utils_Tuple3(slot.el, slot.eV, slot.ac);
						if (((!_v1.a.$) && (!_v1.b.$)) && (!_v1.c.$)) {
							var proof = _v1.a.a;
							var action = _v1.b.a;
							var geometry = _v1.c.a;
							return A2(
								$elm$core$Result$andThen,
								function (frame) {
									if (frame.$ === 1) {
										var accepted = frame.c;
										return (!_Utils_eq(accepted.el, proof)) ? $elm$core$Result$Err('Announced proof changed') : $elm$core$Result$Ok(
											_Utils_Tuple2(
												_Utils_update(
													model,
													{
														ba: _Utils_eq(
															model.ba,
															$elm$core$Maybe$Just(proof)) ? $elm$core$Maybe$Nothing : model.ba,
														P: A2(
															$elm$core$List$map,
															function (entry) {
																return A2($author$project$ReconciliationTracking$same, entry.fz, record) ? _Utils_update(
																	entry,
																	{cL: true}) : entry;
															},
															model.P)
													}),
												record));
									} else {
										return $elm$core$Result$Err('Expected released frame');
									}
								},
								A2(
									$author$project$ReconciliationFrame$decodeReleased,
									{a3: action.R, cu: action.cM, cA: current, a7: geometry.R, cF: geometry.cM, em: proof.eu, fz: slot.fz},
									raw));
						} else {
							return $elm$core$Result$Err('Proof and both accepted observations required');
						}
					}
				}
			},
			A2(
				$elm$core$Result$mapError,
				$elm$json$Json$Decode$errorToString,
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'record', $author$project$ReconciliationFrame$recordDecoder),
					raw)));
	});
var $author$project$ReceiptRouter$forgetReservation = F2(
	function (local, _v0) {
		var entries = _v0;
		return A2(
			$elm$core$List$filter,
			function (entry) {
				return !_Utils_eq(entry.ch, local);
			},
			entries);
	});
var $author$project$Menu$releaseUnknown = F3(
	function (local, bound, model) {
		var state = model;
		var _v0 = $elm$core$List$head(
			A2(
				$elm$core$List$filter,
				function (entry) {
					return _Utils_eq(entry.cc, local) && (_Utils_eq(entry.c3, bound) && entry.bk);
				},
				state.fn));
		if (_v0.$ === 1) {
			return _Utils_Tuple2(model, false);
		} else {
			var entry = _v0.a;
			return (_Utils_cmp(
				$elm$core$List$length(state.bE),
				$author$project$Menu$maxOutstanding) > -1) ? _Utils_Tuple2(model, false) : _Utils_Tuple2(
				_Utils_update(
					state,
					{
						fn: A2(
							$elm$core$List$filter,
							function (current) {
								return !_Utils_eq(current.cc, local);
							},
							state.fn),
						bE: A2($elm$core$List$cons, entry, state.bE)
					}),
				true);
		}
	});
var $author$project$MenuBridge$releaseReservationUnknown = F4(
	function (bound, protocolId, intent, model) {
		var state = model;
		var _v0 = A4($author$project$ReceiptRouter$findReservation, bound, protocolId, intent, state.aw);
		if (_v0.$ === 1) {
			return model;
		} else {
			var _v1 = _v0.a;
			var local = _v1.a;
			var original = _v1.b;
			var _v2 = A3($author$project$Menu$releaseUnknown, local, original, state.aC);
			var menu = _v2.a;
			var accepted = _v2.b;
			return accepted ? _Utils_update(
				state,
				{
					aC: menu,
					aw: A2($author$project$ReceiptRouter$forgetReservation, local, state.aw)
				}) : model;
		}
	});
var $author$project$ReconciliationTracking$requested = F3(
	function (kind, request, model) {
		return _Utils_update(
			model,
			{
				P: A2(
					$elm$core$List$map,
					function (slot) {
						return _Utils_eq(slot.el, $elm$core$Maybe$Nothing) ? slot : ((kind === 'projection-request') ? _Utils_update(
							slot,
							{
								bK: $elm$core$Maybe$Just(request)
							}) : ((kind === 'geometry-facts-request') ? _Utils_update(
							slot,
							{
								a8: $elm$core$Maybe$Just(request)
							}) : slot));
					},
					model.P)
			});
	});
var $author$project$ReconciliationTracking$reset = function (model) {
	return _Utils_update(
		model,
		{
			ba: $elm$core$Maybe$Nothing,
			P: A2(
				$elm$core$List$map,
				function (slot) {
					return _Utils_update(
						slot,
						{eV: $elm$core$Maybe$Nothing, bK: $elm$core$Maybe$Nothing, ac: $elm$core$Maybe$Nothing, a8: $elm$core$Maybe$Nothing, el: $elm$core$Maybe$Nothing});
				},
				model.P)
		});
};
var $author$project$ReconciliationFrame$ReservationUnknown = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$ReconciliationFrame$decodeUnknown = F2(
	function (current, raw) {
		var decoder = A2(
			$author$project$ReconciliationFrame$strict,
			_List_fromArray(
				['protocolVersion', 'kind', 'binding', 'record']),
			A5(
				$elm$json$Json$Decode$map4,
				F4(
					function (_v1, _v2, binding, record) {
						return _Utils_Tuple2(binding, record);
					}),
				A2(
					$elm$json$Json$Decode$field,
					'protocolVersion',
					$author$project$ReconciliationFrame$exactInt(3)),
				A2(
					$elm$json$Json$Decode$field,
					'kind',
					$author$project$ReconciliationFrame$exactString('host-reservation-unknown')),
				A2($elm$json$Json$Decode$field, 'binding', $author$project$Binding$decoder),
				A2($elm$json$Json$Decode$field, 'record', $author$project$ReconciliationFrame$recordDecoder)));
		return A2(
			$elm$core$Result$andThen,
			function (_v0) {
				var binding = _v0.a;
				var record = _v0.b;
				return _Utils_eq(binding, current) ? $elm$core$Result$Ok(
					A2($author$project$ReconciliationFrame$ReservationUnknown, binding, record)) : $elm$core$Result$Err('Foreign current binding');
			},
			A2(
				$elm$core$Result$mapError,
				$elm$json$Json$Decode$errorToString,
				A2($elm$json$Json$Decode$decodeValue, decoder, raw)));
	});
var $author$project$ReconciliationTracking$unknown = F3(
	function (current, raw, model) {
		return A2(
			$elm$core$Result$andThen,
			function (frame) {
				if (!frame.$) {
					var record = frame.b;
					var _v1 = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (slot) {
								return A2($author$project$ReconciliationTracking$same, slot.fz, record);
							},
							model.P));
					if (!_v1.$) {
						var slot = _v1.a;
						return slot.cL ? $elm$core$Result$Err('Historical reservation already released') : $elm$core$Result$Ok(
							_Utils_Tuple2(model, record));
					} else {
						return ($elm$core$List$length(model.P) >= 64) ? $elm$core$Result$Err('Historical reservation capacity') : $elm$core$Result$Ok(
							_Utils_Tuple2(
								_Utils_update(
									model,
									{
										P: A2(
											$elm$core$List$cons,
											{eV: $elm$core$Maybe$Nothing, bK: $elm$core$Maybe$Nothing, ac: $elm$core$Maybe$Nothing, a8: $elm$core$Maybe$Nothing, el: $elm$core$Maybe$Nothing, fz: record, cL: false},
											model.P)
									}),
								record));
					}
				} else {
					return $elm$core$Result$Err('Expected Unknown');
				}
			},
			A2($author$project$ReconciliationFrame$decodeUnknown, current, raw));
	});
var $author$project$SurfaceController$apply = F2(
	function (message, current) {
		var model = current;
		var register = F2(
			function (effects, recovery) {
				return A3(
					$elm$core$List$foldl,
					F2(
						function (effect, state) {
							if (((!effect.$) && (!effect.a.$)) && (!effect.a.a.$)) {
								var wire = effect.a.a.a;
								var _v21 = A2(
									$elm$json$Json$Decode$decodeValue,
									A3(
										$elm$json$Json$Decode$map2,
										$elm$core$Tuple$pair,
										A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
										A2($elm$json$Json$Decode$field, 'requestId', $author$project$UInt64$decoder)),
									wire);
								if (!_v21.$) {
									var _v22 = _v21.a;
									var kind = _v22.a;
									var request = _v22.b;
									return A3($author$project$ReconciliationTracking$requested, kind, request, state);
								} else {
									return state;
								}
							} else {
								return state;
							}
						}),
					recovery,
					effects);
			});
		var publishDesktop = F2(
			function (recovery, next) {
				if (_Utils_eq(next, model.e)) {
					return _Utils_Tuple2(
						_Utils_update(
							model,
							{ao: recovery}),
						_List_Nil);
				} else {
					var _v19 = $author$project$UInt64$next(model._);
					if (_v19.$ === 1) {
						return _Utils_Tuple2(
							_Utils_update(
								model,
								{aA: true}),
							_List_Nil);
					} else {
						var publication = _v19.a;
						var updated = _Utils_update(
							model,
							{e: next, _: publication, ao: recovery});
						return _Utils_Tuple2(
							updated,
							_List_fromArray(
								[
									$author$project$SurfaceController$Publish(
									$author$project$SurfaceController$frame(updated))
								]));
					}
				}
			});
		var incoming = function () {
			_v18$2:
			while (true) {
				switch (message.$) {
					case 11:
						var raw = message.a;
						return $elm$core$Maybe$Just(raw);
					case 1:
						if ((!message.a.$) && (message.a.a.$ === 3)) {
							var raw = message.a.a.a;
							return $elm$core$Maybe$Just(raw);
						} else {
							break _v18$2;
						}
					default:
						break _v18$2;
				}
			}
			return $elm$core$Maybe$Nothing;
		}();
		var ordinary = F2(
			function (prepared, action) {
				var _v12 = A2($author$project$SurfaceController$applyOrdinary, action, prepared);
				var next = _v12.a;
				var effects = _v12.b;
				var hasReads = A2(
					$elm$core$List$any,
					function (effect) {
						if (((!effect.$) && (!effect.a.$)) && (!effect.a.a.$)) {
							var wire = effect.a.a.a;
							return A2(
								$elm$core$Result$withDefault,
								false,
								A2(
									$elm$core$Result$map,
									function (kind) {
										return A2(
											$elm$core$List$member,
											kind,
											_List_fromArray(
												['projection-request', 'geometry-facts-request']));
									},
									A2(
										$elm$json$Json$Decode$decodeValue,
										A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
										wire)));
						} else {
							return false;
						}
					},
					effects);
				var _v13 = next;
				var result = _v13;
				var recovery = function () {
					if (!incoming.$) {
						var raw = incoming.a;
						return A3(
							$author$project$ReconciliationTracking$legacy,
							raw,
							result.e.a.b,
							A4($author$project$ReconciliationTracking$observed, raw, model.e.a.b, result.e.a.b, result.ao));
					} else {
						return result.ao;
					}
				}();
				var reset = ((!_Utils_eq(model.e.a.b.c3, result.e.a.b.c3)) || (!result.e.a.b.m)) ? $author$project$ReconciliationTracking$reset(recovery) : recovery;
				var proofs = A3(
					$elm$core$List$foldl,
					F2(
						function (proof, values) {
							return A2($elm$core$List$member, proof, values) ? values : A2($elm$core$List$cons, proof, values);
						}),
					_List_Nil,
					_Utils_ap(
						A2(
							$elm$core$List$filterMap,
							function ($) {
								return $.el;
							},
							A2(
								$elm$core$List$filter,
								function (slot) {
									return !slot.cL;
								},
								reset.P)),
						A2(
							$elm$core$Maybe$withDefault,
							_List_Nil,
							A2($elm$core$Maybe$map, $elm$core$List$singleton, reset.ba))));
				var readyEffects = hasReads ? A2(
					$elm$core$List$map,
					function (proof) {
						return $author$project$SurfaceController$DesktopEffect(
							$author$project$Desktop$Send(
								$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'protocolVersion',
											$elm$json$Json$Encode$int(3)),
											_Utils_Tuple2(
											'kind',
											$elm$json$Json$Encode$string('reconciliation-ready')),
											_Utils_Tuple2(
											'binding',
											$author$project$Binding$encode(proof.c3)),
											_Utils_Tuple2(
											'proofRequestId',
											$elm$json$Json$Encode$string(
												$author$project$UInt64$string(proof.eu))),
											_Utils_Tuple2(
											'queriedBinding',
											$author$project$Binding$encode(proof.eo))
										]))));
					},
					proofs) : _List_Nil;
				var emitted = _Utils_ap(readyEffects, effects);
				if ((!_Utils_eq(result.e, model.e)) && (!A2(
					$elm$core$List$any,
					function (effect) {
						if (effect.$ === 1) {
							return true;
						} else {
							return false;
						}
					},
					effects))) {
					var _v15 = $author$project$UInt64$next(result._);
					if (!_v15.$) {
						var publication = _v15.a;
						var updated = _Utils_update(
							result,
							{
								_: publication,
								ao: A2(register, emitted, reset)
							});
						return _Utils_Tuple2(
							updated,
							A2(
								$elm$core$List$cons,
								$author$project$SurfaceController$Publish(
									$author$project$SurfaceController$frame(updated)),
								emitted));
					} else {
						return _Utils_Tuple2(
							_Utils_update(
								result,
								{aA: true}),
							_List_Nil);
					}
				} else {
					return _Utils_Tuple2(
						_Utils_update(
							result,
							{
								ao: A2(register, emitted, reset)
							}),
						emitted);
				}
			});
		var clearChoices = function (application) {
			var windows = application.a;
			var shell = windows.b;
			return _Utils_update(
				application,
				{
					k: $elm$core$Maybe$Nothing,
					s: false,
					A: false,
					o: $elm$core$Maybe$Nothing,
					u: false,
					E: $elm$core$Maybe$Nothing,
					v: false,
					F: false,
					l: false,
					T: $elm$core$Maybe$Nothing,
					r: $elm$core$Maybe$Nothing,
					p: false,
					N: false,
					j: A2(
						$author$project$Switcher$cancel,
						$author$project$Switcher$generation(application.j),
						application.j),
					aN: $elm$core$Maybe$Nothing,
					aO: $elm$core$Maybe$Nothing,
					t: $elm$core$Maybe$Nothing,
					x: false,
					I: false,
					a: _Utils_update(
						windows,
						{
							i: $author$project$MenuBridge$retireChoices(windows.i),
							G: $elm$core$Maybe$Nothing,
							b: _Utils_update(
								shell,
								{dO: false})
						})
				});
		};
		if (incoming.$ === 1) {
			return A2(ordinary, current, message);
		} else {
			var raw = incoming.a;
			var _v1 = _Utils_Tuple2(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
					raw),
				model.e.a.b.c3);
			_v1$3:
			while (true) {
				if ((!_v1.a.$) && (!_v1.b.$)) {
					switch (_v1.a.a) {
						case 'host-reservation-unknown':
							var currentBinding = _v1.b.a;
							if ((!model.e.a.b.m) || (model.e.a.b.m === 3)) {
								return _Utils_Tuple2(current, _List_Nil);
							} else {
								var _v2 = A3($author$project$ReconciliationTracking$unknown, currentBinding, raw, model.ao);
								if (_v2.$ === 1) {
									if (_v2.a === 'Historical reservation capacity') {
										return A2(
											ordinary,
											current,
											$author$project$Desktop$Window(
												$author$project$TaskbarShell$Native($author$project$Shell$ReconciliationFull)));
									} else {
										return _Utils_Tuple2(current, _List_Nil);
									}
								} else {
									var _v3 = _v2.a;
									var recovery = _v3.a;
									var record = _v3.b;
									var _v4 = A2(
										$author$project$Desktop$update,
										$author$project$Desktop$Window(
											$author$project$TaskbarShell$Native(
												A2($author$project$Shell$RecoveredUnknown, record.az, record.af))),
										model.e);
									var admitted = _v4.a;
									var windows = admitted.a;
									var menus = A4($author$project$MenuBridge$observeReservationUnknown, record.c3, record.az, record.af, windows.i);
									var tracked = A2(
										$elm$core$List$any,
										function (entry) {
											return _Utils_eq(entry.af, record.af) && (_Utils_eq(entry.az, record.az) && (entry.O === 4));
										},
										windows.b.V.fM);
									return (!tracked) ? _Utils_Tuple2(current, _List_Nil) : A2(
										publishDesktop,
										recovery,
										_Utils_update(
											admitted,
											{
												a: _Utils_update(
													windows,
													{i: menus})
											}));
								}
							}
						case 'binding-retirement':
							var currentBinding = _v1.b.a;
							if ((!model.e.a.b.m) || (model.e.a.b.m === 3)) {
								return _Utils_Tuple2(current, _List_Nil);
							} else {
								var _v5 = A3($author$project$ReconciliationTracking$announce, currentBinding, raw, model.ao);
								if (_v5.$ === 1) {
									return _Utils_Tuple2(current, _List_Nil);
								} else {
									var recovery = _v5.a;
									var _v6 = A2($elm$json$Json$Decode$decodeValue, $author$project$ReconciliationFrame$proofDecoder, raw);
									if (_v6.$ === 1) {
										return _Utils_Tuple2(current, _List_Nil);
									} else {
										var proof = _v6.a;
										var ready = $elm$json$Json$Encode$object(
											_List_fromArray(
												[
													_Utils_Tuple2(
													'protocolVersion',
													$elm$json$Json$Encode$int(3)),
													_Utils_Tuple2(
													'kind',
													$elm$json$Json$Encode$string('reconciliation-ready')),
													_Utils_Tuple2(
													'binding',
													$author$project$Binding$encode(currentBinding)),
													_Utils_Tuple2(
													'proofRequestId',
													$elm$json$Json$Encode$string(
														$author$project$UInt64$string(proof.eu))),
													_Utils_Tuple2(
													'queriedBinding',
													$author$project$Binding$encode(proof.eo))
												]));
										var _v7 = A2(
											ordinary,
											_Utils_update(
												model,
												{
													e: clearChoices(model.e),
													ao: recovery
												}),
											$author$project$Desktop$Window(
												$author$project$TaskbarShell$Native($author$project$Shell$Refresh)));
										var next = _v7.a;
										var effects = _v7.b;
										return A2(
											$elm$core$List$any,
											function (effect) {
												if ((!effect.$) && (effect.a.$ === 1)) {
													var wire = effect.a.a;
													return _Utils_eq(
														A2(
															$elm$json$Json$Decode$decodeValue,
															A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
															wire),
														$elm$core$Result$Ok('reconciliation-ready'));
												} else {
													return false;
												}
											},
											effects) ? _Utils_Tuple2(next, effects) : _Utils_Tuple2(
											next,
											A2(
												$elm$core$List$cons,
												$author$project$SurfaceController$DesktopEffect(
													$author$project$Desktop$Send(ready)),
												effects));
									}
								}
							}
						case 'host-reservation-released':
							var currentBinding = _v1.b.a;
							if ((!model.e.a.b.m) || (model.e.a.b.m === 3)) {
								return _Utils_Tuple2(current, _List_Nil);
							} else {
								var _v9 = A3($author$project$ReconciliationTracking$release, currentBinding, raw, model.ao);
								if (_v9.$ === 1) {
									return _Utils_Tuple2(current, _List_Nil);
								} else {
									var _v10 = _v9.a;
									var recovery = _v10.a;
									var record = _v10.b;
									if (!A2(
										$elm$core$List$any,
										function (entry) {
											return (entry.O === 4) && (_Utils_eq(entry.az, record.az) && _Utils_eq(entry.af, record.af));
										},
										model.e.a.b.V.fM)) {
										return _Utils_Tuple2(
											_Utils_update(
												model,
												{ao: recovery}),
											_List_Nil);
									} else {
										var preserveShared = A2(
											$elm$core$List$any,
											function (slot) {
												return (!slot.cL) && (_Utils_eq(slot.fz.af, record.af) && _Utils_eq(slot.fz.az, record.az));
											},
											recovery.P);
										var cleared = clearChoices(model.e);
										var windows = cleared.a;
										var menus = A4($author$project$MenuBridge$releaseReservationUnknown, record.c3, record.az, record.af, windows.i);
										var _v11 = A2(
											$author$project$Desktop$update,
											$author$project$Desktop$Window(
												$author$project$TaskbarShell$Native(
													A4($author$project$Shell$ReservationReleased, preserveShared, record.c3, record.az, record.af))),
											_Utils_update(
												cleared,
												{
													a: _Utils_update(
														windows,
														{i: menus})
												}));
										var released = _v11.a;
										return A2(publishDesktop, recovery, released);
									}
								}
							}
						default:
							break _v1$3;
					}
				} else {
					break _v1$3;
				}
			}
			return A2(ordinary, current, message);
		}
	});
var $author$project$Desktop$SurfaceEntry = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $author$project$Menu$Down = 1;
var $author$project$Menu$End = 3;
var $author$project$Menu$Home = 2;
var $author$project$Menu$Navigate = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Desktop$NotificationFocus = F2(
	function (a, b) {
		return {$: 35, a: a, b: b};
	});
var $author$project$Desktop$OpenWindowMenu = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Menu$Up = 0;
var $author$project$Surface$resolveAction = F4(
	function (publication, lease, raw, model) {
		var hasTrigger = !_Utils_eq(
			$elm$core$Maybe$Nothing,
			$elm$core$Result$toMaybe(
				A2(
					$elm$json$Json$Decode$decodeValue,
					A2($elm$json$Json$Decode$field, 'trigger', $elm$json$Json$Decode$value),
					raw)));
		var strict = function (child) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (pairs) {
					return _Utils_eq(
						$elm$core$List$sort(
							A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
						_Utils_ap(
							_List_fromArray(
								['id', 'kind', 'lease', 'publication', 'surface', 'surfaceProtocol']),
							hasTrigger ? _List_fromArray(
								['trigger']) : _List_Nil)) ? child : $elm$json$Json$Decode$fail('Surface action fields');
				},
				$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
		};
		var trigger = hasTrigger ? A2(
			$elm$json$Json$Decode$field,
			'trigger',
			A2(
				$elm$json$Json$Decode$andThen,
				function (value) {
					return A2(
						$elm$core$List$member,
						value,
						_List_fromArray(
							['pointer', 'keyboard'])) ? $elm$json$Json$Decode$succeed(value) : $elm$json$Json$Decode$fail('Surface action origin');
				},
				$elm$json$Json$Decode$string)) : $elm$json$Json$Decode$succeed('keyboard');
		var decoder = strict(
			A8(
				$elm$json$Json$Decode$map7,
				F7(
					function (version, kind, shown, scoped, identity, role, origin) {
						return {cG: identity, d4: kind, bT: origin, cO: role, eB: scoped, eD: shown, eK: version};
					}),
				A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
				A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
				A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
				A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string),
				trigger));
		var _v0 = A2($elm$json$Json$Decode$decodeValue, decoder, raw);
		if (!_v0.$) {
			var event = _v0.a;
			return ((event.eK !== 2) || ((event.d4 !== 'surface-action') || ((!_Utils_eq(event.eD, publication)) || (!_Utils_eq(event.eB, lease))))) ? $elm$core$Maybe$Nothing : A2(
				$elm$core$Maybe$map,
				(event.cO === 'bar') ? $author$project$Desktop$SurfaceEntry(
					(event.bT === 'keyboard') ? 1 : 0) : $elm$core$Basics$identity,
				A2(
					$elm$core$Maybe$andThen,
					function ($) {
						return $.d;
					},
					$elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (control) {
								return _Utils_eq(control.cc, event.cG) && control.b9;
							},
							(event.cO === 'bar') ? $author$project$Surface$barControls(model) : ((event.cO === 'popup') ? $author$project$Surface$controls(model) : _List_Nil)))));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $author$project$Surface$resolveBase = F4(
	function (publication, lease, raw, model) {
		var strict = F2(
			function (fields, child) {
				return A2(
					$elm$json$Json$Decode$andThen,
					function (pairs) {
						return _Utils_eq(
							$elm$core$List$sort(
								A2($elm$core$List$map, $elm$core$Tuple$first, pairs)),
							$elm$core$List$sort(fields)) ? child : $elm$json$Json$Decode$fail('Surface event fields');
					},
					$elm$json$Json$Decode$keyValuePairs($elm$json$Json$Decode$value));
			});
		var scopes = function (child) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (_v7) {
					var valid = _v7.a;
					var role = _v7.b;
					return valid ? child(role) : $elm$json$Json$Decode$fail('Stale surface event');
				},
				A5(
					$elm$json$Json$Decode$map4,
					F4(
						function (version, shown, scoped, role) {
							return _Utils_Tuple2(
								(version === 2) && (_Utils_eq(shown, publication) && _Utils_eq(scoped, lease)),
								role);
						}),
					A2($elm$json$Json$Decode$field, 'surfaceProtocol', $elm$json$Json$Decode$int),
					A2($elm$json$Json$Decode$field, 'publication', $author$project$UInt64$decoder),
					A2($elm$json$Json$Decode$field, 'lease', $author$project$UInt64$decoder),
					A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string)));
		};
		var query = A2(
			strict,
			_List_fromArray(
				['surfaceProtocol', 'kind', 'surface', 'publication', 'lease', 'id', 'query']),
			scopes(
				function (role) {
					return ((role === 'popup') && (model.q || (model.s && (!model.bA)))) ? A3(
						$elm$json$Json$Decode$map2,
						$elm$core$Tuple$pair,
						A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
						A2($elm$json$Json$Decode$field, 'query', $elm$json$Json$Decode$string)) : $elm$json$Json$Decode$fail('No applications');
				}));
		var navigation = A2(
			strict,
			_List_fromArray(
				['surfaceProtocol', 'kind', 'surface', 'publication', 'lease', 'key']),
			scopes(
				function (role) {
					return ((role === 'popup') && (($author$project$Surface$mode(model) === 'menu') && (!model.bA))) ? A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string) : $elm$json$Json$Decode$fail('No menu');
				}));
		var menuMessage = function (key) {
			return A2(
				$elm$core$Maybe$andThen,
				function (menu) {
					var send = A2(
						$elm$core$Basics$composeL,
						A2($elm$core$Basics$composeL, $elm$core$Maybe$Just, $author$project$Desktop$Window),
						$author$project$TaskbarShell$MenuEvent);
					switch (key) {
						case 'Escape':
							return send(
								$author$project$Menu$Dismiss(menu.cc));
						case 'Close':
							return send(
								$author$project$Menu$Dismiss(menu.cc));
						case 'ArrowUp':
							return send(
								A2($author$project$Menu$Navigate, menu.cc, 0));
						case 'ArrowDown':
							return send(
								A2($author$project$Menu$Navigate, menu.cc, 1));
						case 'Home':
							return send(
								A2($author$project$Menu$Navigate, menu.cc, 2));
						case 'End':
							return send(
								A2($author$project$Menu$Navigate, menu.cc, 3));
						case 'Enter':
							return ($author$project$Shell$available(model.a.b) && (_Utils_eq(menu.O, $author$project$Menu$Ready) && (!$author$project$Surface$menuBlocked(model)))) ? A2(
								$elm$core$Maybe$map,
								function (index) {
									return $author$project$Desktop$Window(
										$author$project$TaskbarShell$MenuEvent(
											A3($author$project$Menu$Activate, menu.cc, menu.c3, index)));
								},
								menu.bG) : $elm$core$Maybe$Nothing;
						default:
							return $elm$core$Maybe$Nothing;
					}
				},
				$author$project$MenuBridge$menuSnapshot(model.a.i).aC);
		};
		var context = A2(
			strict,
			_List_fromArray(
				['surfaceProtocol', 'kind', 'surface', 'publication', 'lease', 'id', 'trigger', 'x', 'y']),
			scopes(
				function (role) {
					return A5(
						$elm$json$Json$Decode$map4,
						F4(
							function (identity, trigger, x, y) {
								return _Utils_Tuple3(role, identity, trigger);
							}),
						A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string),
						A2($elm$json$Json$Decode$field, 'trigger', $elm$json$Json$Decode$string),
						A2($elm$json$Json$Decode$field, 'x', $elm$json$Json$Decode$int),
						A2($elm$json$Json$Decode$field, 'y', $elm$json$Json$Decode$int));
				}));
		var attention = A2(
			strict,
			_List_fromArray(
				['surfaceProtocol', 'kind', 'surface', 'publication', 'lease', 'id']),
			scopes(
				function (role) {
					return ((role === 'popup') && (model.v && (!model.bA))) ? A2($elm$json$Json$Decode$field, 'id', $elm$json$Json$Decode$string) : $elm$json$Json$Decode$fail('No notification popup');
				}));
		var _v0 = A2(
			$elm$json$Json$Decode$decodeValue,
			A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
			raw);
		_v0$5:
		while (true) {
			if (!_v0.$) {
				switch (_v0.a) {
					case 'surface-notification-focus':
						return A2(
							$elm$core$Maybe$andThen,
							function (identity) {
								return ((identity === '') || A2(
									$elm$core$List$any,
									function (control) {
										return _Utils_eq(control.cc, identity);
									},
									$author$project$Surface$controls(model))) ? A2(
									$elm$core$Maybe$map,
									function (stamp) {
										return A2($author$project$Desktop$NotificationFocus, stamp, identity);
									},
									$author$project$Desktop$capture(model)) : $elm$core$Maybe$Nothing;
							},
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, attention, raw)));
					case 'surface-action':
						return A4($author$project$Surface$resolveAction, publication, lease, raw, model);
					case 'surface-query':
						return A2(
							$elm$core$Maybe$andThen,
							function (_v1) {
								var identity = _v1.a;
								var value = _v1.b;
								return ((identity === 'control:search') && model.q) ? A2(
									$elm$core$Maybe$map,
									function (stamp) {
										return A2($author$project$Desktop$SearchQuery, stamp, value);
									},
									$author$project$Desktop$capture(model)) : (((identity === 'control:files-path') && model.s) ? A2(
									$elm$core$Maybe$map,
									function (stamp) {
										return A2($author$project$Desktop$EditFilesPath, stamp, value);
									},
									$author$project$Desktop$capture(model)) : $elm$core$Maybe$Nothing);
							},
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, query, raw)));
					case 'surface-menu-navigation':
						return A2(
							$elm$core$Maybe$andThen,
							menuMessage,
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, navigation, raw)));
					case 'surface-context':
						return A2(
							$elm$core$Maybe$andThen,
							function (_v2) {
								var role = _v2.a;
								var identity = _v2.b;
								var trigger = _v2.c;
								return ((!A2(
									$elm$core$List$member,
									trigger,
									_List_fromArray(
										['pointer', 'keyboard']))) || ((!_Utils_eq(model.k, $elm$core$Maybe$Nothing)) || (model.bA && (role !== 'bar')))) ? $elm$core$Maybe$Nothing : A2(
									$elm$core$Maybe$andThen,
									function (stamp) {
										if (role === 'bar') {
											var group = function () {
												if (A2($elm$core$String$startsWith, 'bar:pin:', identity)) {
													var pin = A2($elm$core$String$dropLeft, 8, identity);
													return A2(
														$elm$core$List$member,
														pin,
														$author$project$Desktop$pinIdentities(model)) ? A2($author$project$Desktop$pinnedGroup, pin, model) : $elm$core$Maybe$Nothing;
												} else {
													return $elm$core$List$head(
														A2(
															$elm$core$List$filter,
															function (candidate) {
																return _Utils_eq('bar:group:' + candidate.aV, identity);
															},
															$author$project$TaskbarShell$groups(model.a)));
												}
											}();
											var enabled = A2(
												$elm$core$List$any,
												function (control) {
													return _Utils_eq(control.cc, identity) && control.b9;
												},
												$author$project$Surface$barControls(model));
											var emptyPin = function () {
												if (enabled && A2($elm$core$String$startsWith, 'bar:pin:', identity)) {
													var entryId = A2($elm$core$String$dropLeft, 8, identity);
													return (A2(
														$elm$core$List$member,
														entryId,
														$author$project$Desktop$pinIdentities(model)) && $elm$core$List$isEmpty(
														A2($author$project$Desktop$pinGroups, entryId, model))) ? A2(
														$elm$core$Maybe$andThen,
														function (_v4) {
															return A2(
																$elm$core$Maybe$map,
																function (current) {
																	return A2($author$project$Desktop$OpenJumpList, current, entryId);
																},
																$author$project$Desktop$capture(model));
														},
														A2(
															$elm$core$Maybe$andThen,
															$author$project$Catalog$lookup(entryId),
															model.aj)) : $elm$core$Maybe$Nothing;
												} else {
													return $elm$core$Maybe$Nothing;
												}
											}();
											return _Utils_eq(group, $elm$core$Maybe$Nothing) ? emptyPin : A2(
												$elm$core$Maybe$andThen,
												function (current) {
													var _v3 = current.aB;
													if (_v3.b && (!_v3.b.b)) {
														var family = _v3.a;
														return family.c2 ? $elm$core$Maybe$Just(
															A2($author$project$Desktop$OpenWindowMenu, stamp, family.n)) : $elm$core$Maybe$Nothing;
													} else {
														return _Utils_eq(
															A2($author$project$Taskbar$primary, false, current.aB),
															$author$project$Taskbar$Picker) ? $elm$core$Maybe$Just(
															$author$project$Desktop$Window(
																A2($author$project$TaskbarShell$Primary, stamp, current.aV))) : $elm$core$Maybe$Nothing;
													}
												},
												enabled ? group : $elm$core$Maybe$Nothing);
										} else {
											if ((role === 'popup') && (model.q && A2($elm$core$String$startsWith, 'entry:', identity))) {
												var entry = A2($elm$core$String$dropLeft, 6, identity);
												return A2(
													$elm$core$Maybe$andThen,
													function (_v5) {
														return A2(
															$elm$core$Maybe$map,
															function (current) {
																return A2($author$project$Desktop$OpenJumpList, current, entry);
															},
															$author$project$Desktop$capture(model));
													},
													A2(
														$elm$core$Maybe$andThen,
														$author$project$Catalog$lookup(entry),
														model.aj));
											} else {
												if ((role === 'popup') && ($author$project$Surface$mode(model) === 'picker')) {
													return A2(
														$elm$core$Maybe$andThen,
														function (picker) {
															return (!_Utils_eq(picker.cQ, stamp)) ? $elm$core$Maybe$Nothing : A2(
																$elm$core$Maybe$map,
																function (family) {
																	return A2($author$project$Desktop$OpenWindowMenu, stamp, family.n);
																},
																$elm$core$List$head(
																	A2(
																		$elm$core$List$filter,
																		function (family) {
																			return _Utils_eq(
																				'family:' + $author$project$UInt64$string(family.n),
																				identity) && family.c2;
																		},
																		A2(
																			$elm$core$List$concatMap,
																			function ($) {
																				return $.aB;
																			},
																			A2(
																				$elm$core$List$filter,
																				function (group) {
																					return _Utils_eq(group.aV, picker.aV);
																				},
																				$author$project$TaskbarShell$groups(model.a))))));
														},
														model.a.G);
												} else {
													return $elm$core$Maybe$Nothing;
												}
											}
										}
									},
									$author$project$Shell$capture(model.a.b));
							},
							$elm$core$Result$toMaybe(
								A2($elm$json$Json$Decode$decodeValue, context, raw)));
					default:
						break _v0$5;
				}
			} else {
				break _v0$5;
			}
		}
		return $elm$core$Maybe$Nothing;
	});
var $author$project$Surface$resolve = F4(
	function (publication, lease, raw, model) {
		return A2(
			$elm$core$Maybe$map,
			function (message) {
				return (_Utils_eq(
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$field, 'kind', $elm$json$Json$Decode$string),
						raw),
					$elm$core$Result$Ok('surface-context')) && _Utils_eq(
					A2(
						$elm$json$Json$Decode$decodeValue,
						A2($elm$json$Json$Decode$field, 'surface', $elm$json$Json$Decode$string),
						raw),
					$elm$core$Result$Ok('bar'))) ? A2(
					$author$project$Desktop$SurfaceEntry,
					_Utils_eq(
						A2(
							$elm$json$Json$Decode$decodeValue,
							A2($elm$json$Json$Decode$field, 'trigger', $elm$json$Json$Decode$string),
							raw),
						$elm$core$Result$Ok('keyboard')) ? 1 : 0,
					message) : message;
			},
			A4($author$project$Surface$resolveBase, publication, lease, raw, model));
	});
var $author$project$SurfaceController$update = F2(
	function (event, current) {
		var model = current;
		if (model.aA) {
			return _Utils_Tuple2(current, _List_Nil);
		} else {
			switch (event.$) {
				case 0:
					var message = event.a;
					return A2($author$project$SurfaceController$apply, message, current);
				case 1:
					var raw = event.a;
					return A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (message) {
								return A2($author$project$SurfaceController$apply, message, current);
							},
							A4($author$project$Surface$resolve, model._, model.ae, raw, model.e)));
				case 3:
					var token = event.a;
					return (!_Utils_eq(token, model.ae)) ? _Utils_Tuple2(current, _List_Nil) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (message) {
								return A2($author$project$SurfaceController$apply, message, current);
							},
							A2(
								$elm$core$Maybe$andThen,
								function ($) {
									return $.d;
								},
								$elm$core$List$head(
									A2(
										$elm$core$List$filter,
										function (control) {
											return (control.cc === 'control:close') && control.b9;
										},
										$author$project$Surface$controls(model.e))))));
				case 5:
					if ($author$project$Surface$mode(model.e) === 'closed') {
						return _Utils_Tuple2(current, _List_Nil);
					} else {
						var _v1 = _Utils_Tuple2(
							$author$project$UInt64$next(model.ae),
							$author$project$UInt64$next(model._));
						if ((!_v1.a.$) && (!_v1.b.$)) {
							var token = _v1.a.a;
							var shown = _v1.b.a;
							var result = _Utils_update(
								model,
								{ae: token, _: shown});
							return _Utils_Tuple2(
								result,
								_List_fromArray(
									[
										$author$project$SurfaceController$Publish(
										$author$project$SurfaceController$frame(result))
									]));
						} else {
							return _Utils_Tuple2(
								_Utils_update(
									model,
									{aA: true}),
								_List_Nil);
						}
					}
				case 4:
					var lease = event.a;
					if ((!_Utils_eq(lease, model.ae)) || ($author$project$Surface$mode(model.e) === 'closed')) {
						return _Utils_Tuple2(current, _List_Nil);
					} else {
						if (!_Utils_eq(model.e.w, $elm$core$Maybe$Nothing)) {
							return A2($author$project$SurfaceController$apply, $author$project$Desktop$InvalidateSnap, current);
						} else {
							var _v2 = _Utils_Tuple2(
								$author$project$UInt64$next(model.ae),
								$author$project$UInt64$next(model._));
							if ((!_v2.a.$) && (!_v2.b.$)) {
								var token = _v2.a.a;
								var shown = _v2.b.a;
								var result = _Utils_update(
									model,
									{ae: token, _: shown});
								return _Utils_Tuple2(
									result,
									_List_fromArray(
										[
											$author$project$SurfaceController$Publish(
											$author$project$SurfaceController$frame(result))
										]));
							} else {
								return _Utils_Tuple2(
									_Utils_update(
										model,
										{aA: true}),
									_List_Nil);
							}
						}
					}
				default:
					var lease = event.a;
					return ((!_Utils_eq(lease, model.ae)) || ($author$project$Surface$mode(model.e) === 'closed')) ? _Utils_Tuple2(current, _List_Nil) : ((!_Utils_eq(model.e.o, $elm$core$Maybe$Nothing)) ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseJumpList(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.s ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseFiles(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.x ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseSystemMenu(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.v ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseNotifications(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.p ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseSettings(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : ((!_Utils_eq(model.e.w, $elm$core$Maybe$Nothing)) ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseSnap(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (($author$project$Surface$mode(model.e) === 'menu') ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (menu) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$Window(
										$author$project$TaskbarShell$MenuEvent(
											$author$project$Menu$Dismiss(menu.cc))),
									current);
							},
							$author$project$MenuBridge$menuSnapshot(model.e.a.i).aC)) : ($author$project$Desktop$switcherOpen(model.e) ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseSwitcher(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.l ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseOverview(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : (model.e.q ? A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (stamp) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$CloseApplications(stamp),
									current);
							},
							$author$project$Desktop$capture(model.e))) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(current, _List_Nil),
						A2(
							$elm$core$Maybe$map,
							function (picker) {
								return A2(
									$author$project$SurfaceController$apply,
									$author$project$Desktop$Window(
										A2($author$project$TaskbarShell$Close, picker.cQ, picker.e7)),
									current);
							},
							model.e.a.G))))))))))));
			}
		}
	});
var $author$project$SystemMenuFocusPipeline$send = F2(
	function (message, model) {
		return A2(
			$author$project$SurfaceController$update,
			$author$project$SurfaceController$Interaction(message),
			model);
	});
var $author$project$SystemMenuFocusPipeline$dispatch = F2(
	function (make, model) {
		return A2(
			$elm$core$Maybe$withDefault,
			_Utils_Tuple2(model, _List_Nil),
			A2(
				$elm$core$Maybe$map,
				function (stamp) {
					return A2(
						$author$project$SystemMenuFocusPipeline$send,
						make(stamp),
						model);
				},
				$author$project$Desktop$capture(
					$author$project$SurfaceController$desktop(model))));
	});
var $author$project$SystemMenuFocusPipeline$focus = function (effects) {
	return A2(
		$elm$core$List$filterMap,
		function (effect) {
			if ((!effect.$) && (effect.a.$ === 5)) {
				var target = effect.a.a;
				return $elm$core$Maybe$Just(target);
			} else {
				return $elm$core$Maybe$Nothing;
			}
		},
		effects);
};
var $author$project$SystemMenuFocusPipeline$foreignBinding = $elm$json$Json$Encode$object(
	_List_fromArray(
		[
			_Utils_Tuple2(
			'lifetime',
			$elm$json$Json$Encode$string('1')),
			_Utils_Tuple2(
			'session',
			$elm$json$Json$Encode$string('1')),
			_Utils_Tuple2(
			'frontend',
			$elm$json$Json$Encode$string('2'))
		]));
var $author$project$ReconciliationTracking$empty = {ba: $elm$core$Maybe$Nothing, bu: _List_Nil, P: _List_Nil};
var $author$project$Launch$init = {a9: $elm$core$Maybe$Nothing, m: $author$project$Launch$Idle, cM: $author$project$UInt64$zero, cN: $author$project$UInt64$zero, c: $elm$core$Maybe$Nothing};
var $author$project$Files$initial = {e2: '', fj: 'Loading Files…', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing, b1: _List_Nil};
var $author$project$JumpList$initial = {fj: 'Reading application actions…', dn: $elm$core$Maybe$Nothing, c: $elm$core$Maybe$Nothing, b1: _List_Nil};
var $author$project$Motion$initial = {bL: $elm$core$Maybe$Nothing, bw: $elm$core$Maybe$Nothing, dn: $elm$core$Maybe$Nothing, aY: $author$project$MotionPreferences$initial};
var $author$project$PointerOwnership$initial = {bw: $elm$core$Maybe$Nothing};
var $author$project$ReceiptRouter$empty = _List_Nil;
var $author$project$Menu$init = {aA: false, aT: _List_Nil, cf: $elm$core$Maybe$Nothing, aC: $elm$core$Maybe$Nothing, ci: 1, cj: 1, fn: _List_Nil, bE: _List_Nil, a_: _List_Nil};
var $author$project$MenuBridge$initial = {aC: $author$project$Menu$init, Q: $elm$core$Maybe$Nothing, dq: $author$project$UInt64$zero, bB: $elm$core$Maybe$Nothing, aw: $author$project$ReceiptRouter$empty};
var $author$project$Effects$empty = {a6: false, e7: $author$project$UInt64$zero, av: $elm$core$Maybe$Nothing, cM: $author$project$UInt64$zero, dz: $elm$core$Maybe$Nothing, fM: _List_Nil};
var $author$project$Shell$initial = {c1: false, ar: false, c3: $elm$core$Maybe$Nothing, cB: $elm$core$Maybe$Nothing, dO: false, V: $author$project$Effects$empty, y: $elm$core$Maybe$Nothing, ac: $elm$core$Maybe$Nothing, dY: $elm$core$Maybe$Nothing, dc: $elm$core$Maybe$Nothing, cE: $elm$core$Maybe$Nothing, X: _List_Nil, fj: 'Connecting…', aD: false, m: 0, aZ: false, cl: false, aK: true, bD: $elm$core$Maybe$Nothing, cM: $author$project$UInt64$zero, aa: false};
var $author$project$TaskbarShell$initial = {e7: $author$project$UInt64$zero, i: $author$project$MenuBridge$initial, G: $elm$core$Maybe$Nothing, b: $author$project$Shell$initial};
var $author$project$WorkspaceNavigation$initial = {c3: $elm$core$Maybe$Nothing, e7: $author$project$UInt64$zero, bT: $elm$core$Maybe$Nothing, bY: false, fz: $elm$core$Maybe$Nothing, er: false, cM: $author$project$UInt64$zero, ex: false};
var $author$project$Desktop$initial = {
	K: $elm$core$Maybe$Nothing,
	ai: 0,
	aj: $elm$core$Maybe$Nothing,
	bn: $elm$core$Maybe$Nothing,
	bo: false,
	k: $elm$core$Maybe$Nothing,
	D: '',
	y: $elm$core$Maybe$Nothing,
	W: $author$project$Files$initial,
	aR: $elm$core$Maybe$Nothing,
	s: false,
	A: false,
	ce: false,
	o: $elm$core$Maybe$Nothing,
	aU: $elm$core$Maybe$Nothing,
	al: $author$project$JumpList$initial,
	u: false,
	B: $author$project$Launch$init,
	cI: false,
	E: $elm$core$Maybe$Nothing,
	M: $author$project$Motion$initial,
	aH: $elm$core$Maybe$Nothing,
	an: $elm$core$Maybe$Nothing,
	C: $author$project$Notifications$initial,
	aX: $elm$core$Maybe$Nothing,
	v: false,
	F: false,
	q: false,
	l: false,
	aE: $author$project$OverviewRecovery$initial,
	Z: $elm$core$Maybe$Nothing,
	T: $elm$core$Maybe$Nothing,
	bx: false,
	be: $elm$core$Maybe$Nothing,
	H: $author$project$Pins$initial,
	bz: $author$project$PointerOwnership$initial,
	bh: 1,
	aF: $elm$core$Maybe$Just($author$project$UInt64$zero),
	bA: false,
	ck: '',
	cM: $author$project$UInt64$zero,
	r: $elm$core$Maybe$Nothing,
	ap: $author$project$Settings$initial,
	bi: $elm$core$Maybe$Nothing,
	cT: true,
	p: false,
	N: false,
	aM: $elm$core$Maybe$Nothing,
	ah: $author$project$ShortcutPreferences$initial,
	b$: $author$project$Shortcuts$initial,
	w: $elm$core$Maybe$Nothing,
	j: $author$project$Switcher$initial,
	aN: $elm$core$Maybe$Nothing,
	aO: $elm$core$Maybe$Nothing,
	cn: $elm$core$Maybe$Nothing,
	aq: $author$project$SystemMenu$initial,
	t: $elm$core$Maybe$Nothing,
	aP: $elm$core$Maybe$Nothing,
	x: false,
	I: false,
	a: $author$project$TaskbarShell$initial,
	b6: $elm$core$Maybe$Nothing,
	J: $author$project$WorkspaceNavigation$initial
};
var $author$project$SurfaceController$initial = {e: $author$project$Desktop$initial, aA: false, ae: $author$project$UInt64$zero, _: $author$project$UInt64$zero, ao: $author$project$ReconciliationTracking$empty};
var $author$project$SystemMenuFocusPipeline$snapshot = $elm$json$Json$Encode$object(
	_List_fromArray(
		[
			_Utils_Tuple2(
			'service',
			$elm$json$Json$Encode$string('9')),
			_Utils_Tuple2(
			'revision',
			$elm$json$Json$Encode$string('1')),
			_Utils_Tuple2(
			'volume',
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'percent',
						$elm$json$Json$Encode$int(100)),
						_Utils_Tuple2(
						'muted',
						$elm$json$Json$Encode$bool(false)),
						_Utils_Tuple2(
						'label',
						$elm$json$Json$Encode$string('Warlock private audio'))
					]))),
			_Utils_Tuple2('network', $elm$json$Json$Encode$null),
			_Utils_Tuple2(
			'power',
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'suspend',
						$elm$json$Json$Encode$string('yes')),
						_Utils_Tuple2(
						'reboot',
						$elm$json$Json$Encode$string('yes')),
						_Utils_Tuple2(
						'poweroff',
						$elm$json$Json$Encode$string('no'))
					]))),
			_Utils_Tuple2(
			'session',
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'name',
						$elm$json$Json$Encode$string('Warlock private session')),
						_Utils_Tuple2(
						'state',
						$elm$json$Json$Encode$string('active')),
						_Utils_Tuple2(
						'locked',
						$elm$json$Json$Encode$bool(false))
					])))
		]));
var $author$project$SystemMenuFocusPipeline$loaded = function (request) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'protocolVersion',
				$elm$json$Json$Encode$int(3)),
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('system-menu-snapshot')),
				_Utils_Tuple2('binding', $author$project$SystemMenuFocusPipeline$binding),
				_Utils_Tuple2(
				'requestId',
				$elm$json$Json$Encode$string(
					$author$project$UInt64$string(request))),
				_Utils_Tuple2('snapshot', $author$project$SystemMenuFocusPipeline$snapshot)
			]));
};
var $author$project$SystemMenuFocusPipeline$matches = F3(
	function (expected, identity, model) {
		return 1 === $elm$core$List$length(
			A2(
				$elm$core$List$filter,
				function (control) {
					return _Utils_eq(control.cc, identity) && (control.b9 && _Utils_eq(control.h, expected));
				},
				$author$project$Surface$controls(
					$author$project$SurfaceController$desktop(model))));
	});
var $author$project$SystemMenuFocusPipeline$pointerIdle = function (owner) {
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'protocolVersion',
				$elm$json$Json$Encode$int(3)),
				_Utils_Tuple2(
				'kind',
				$elm$json$Json$Encode$string('pointer-ownership')),
				_Utils_Tuple2(
				'ownershipProtocol',
				$elm$json$Json$Encode$int(1)),
				_Utils_Tuple2('binding', owner),
				_Utils_Tuple2(
				'requestId',
				$elm$json$Json$Encode$string('1')),
				_Utils_Tuple2(
				'serial',
				$elm$json$Json$Encode$string('1')),
				_Utils_Tuple2(
				'state',
				$elm$json$Json$Encode$string('idle')),
				_Utils_Tuple2('owner', $elm$json$Json$Encode$null)
			]));
};
var $author$project$SystemMenuFocusPipeline$published = function (effects) {
	return A2(
		$elm$core$List$filterMap,
		function (effect) {
			if (effect.$ === 1) {
				var frame = effect.a;
				return $elm$core$Maybe$Just(frame);
			} else {
				return $elm$core$Maybe$Nothing;
			}
		},
		effects);
};
var $author$project$SystemMenuFocusPipeline$result = function () {
	var sameFrame = F2(
		function (expected, effects) {
			var _v13 = $author$project$SystemMenuFocusPipeline$published(effects);
			if (_v13.b && (!_v13.b.b)) {
				var frame = _v13.a;
				return _Utils_eq(
					A2($elm$json$Json$Encode$encode, 0, frame),
					A2(
						$elm$json$Json$Encode$encode,
						0,
						$author$project$SurfaceController$frame(expected)));
			} else {
				return false;
			}
		});
	var current = $elm$core$Result$toMaybe(
		A2($elm$json$Json$Decode$decodeValue, $author$project$SystemMenu$decoder, $author$project$SystemMenuFocusPipeline$snapshot));
	var intent = A2(
		$elm$core$Maybe$map,
		function (value) {
			return A3($author$project$SystemMenu$intent, value, 4, 0);
		},
		current);
	var confirmId = 'applications:{\u0022lifetime\u0022:\u00221\u0022,\u0022session\u0022:\u00221\u0022,\u0022frontend\u0022:\u00221\u0022}:5:system:cancel';
	var closeId = 'applications:{\u0022lifetime\u0022:\u00221\u0022,\u0022session\u0022:\u00221\u0022,\u0022frontend\u0022:\u00221\u0022}:6:system:close';
	var _v0 = A2(
		$author$project$SystemMenuFocusPipeline$send,
		$author$project$Desktop$Incoming($author$project$SystemMenuFocusPipeline$attached),
		$author$project$SurfaceController$initial);
	var attachedModel = _v0.a;
	var _v1 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$OpenSystemMenu, attachedModel);
	var blockedOpen = _v1.a;
	var blockedEffects = _v1.b;
	var _v2 = A2(
		$author$project$SystemMenuFocusPipeline$send,
		$author$project$Desktop$Incoming(
			$author$project$SystemMenuFocusPipeline$pointerIdle($author$project$SystemMenuFocusPipeline$foreignBinding)),
		attachedModel);
	var foreignIdle = _v2.a;
	var _v3 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$OpenSystemMenu, foreignIdle);
	var foreignOpen = _v3.a;
	var foreignEffects = _v3.b;
	var _v4 = A2(
		$author$project$SystemMenuFocusPipeline$send,
		$author$project$Desktop$Incoming(
			$author$project$SystemMenuFocusPipeline$pointerIdle($author$project$SystemMenuFocusPipeline$binding)),
		foreignIdle);
	var ready = _v4.a;
	var _v5 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$OpenSystemMenu, ready);
	var opened = _v5.a;
	var request = A2(
		$elm$core$Maybe$withDefault,
		$author$project$UInt64$zero,
		$author$project$SurfaceController$desktop(opened).aP);
	var _v6 = A2(
		$author$project$SystemMenuFocusPipeline$send,
		$author$project$Desktop$Incoming(
			$author$project$SystemMenuFocusPipeline$loaded(request)),
		opened);
	var read = _v6.a;
	var _v7 = A2(
		$elm$core$Maybe$withDefault,
		_Utils_Tuple2(read, _List_Nil),
		A2(
			$elm$core$Maybe$map,
			function (value) {
				return A2(
					$author$project$SystemMenuFocusPipeline$dispatch,
					function (stamp) {
						return A2($author$project$Desktop$SystemChange, stamp, value);
					},
					read);
			},
			intent));
	var confirmation = _v7.a;
	var confirmationEffects = _v7.b;
	var _v8 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$CancelSystemChange, confirmation);
	var cancelled = _v8.a;
	var cancelEffects = _v8.b;
	var _v9 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$CancelSystemChange, cancelled);
	var duplicate = _v9.a;
	var duplicateEffects = _v9.b;
	var readModel = $author$project$SurfaceController$desktop(read);
	var exactModels = function () {
		if (intent.$ === 1) {
			return false;
		} else {
			var selected = intent.a;
			var expectedConfirm = _Utils_update(
				readModel,
				{
					aF: $elm$core$Maybe$Just(
						$author$project$SystemMenuFocusPipeline$counter('5')),
					t: $elm$core$Maybe$Just(selected)
				});
			var expectedCancel = _Utils_update(
				expectedConfirm,
				{
					aF: $elm$core$Maybe$Just(
						$author$project$SystemMenuFocusPipeline$counter('6')),
					t: $elm$core$Maybe$Nothing
				});
			return _Utils_eq(
				$author$project$SurfaceController$desktop(confirmation),
				expectedConfirm) && _Utils_eq(
				$author$project$SurfaceController$desktop(cancelled),
				expectedCancel);
		}
	}();
	var stale = A2(
		$elm$core$Maybe$withDefault,
		_Utils_Tuple2(confirmation, _List_Nil),
		A2(
			$elm$core$Maybe$map,
			function (stamp) {
				return A2(
					$author$project$SystemMenuFocusPipeline$send,
					$author$project$Desktop$CancelSystemChange(stamp),
					confirmation);
			},
			$author$project$Desktop$capture(
				$author$project$SurfaceController$desktop(read))));
	var _v10 = A2($author$project$SystemMenuFocusPipeline$dispatch, $author$project$Desktop$CancelSystemChange, stale.a);
	var validAfterStale = _v10.a;
	var validEffects = _v10.b;
	var checks = _List_fromArray(
		[
			_Utils_Tuple2(
			'missingPointerObservationRefusesOpen',
			_Utils_eq(
				$author$project$SurfaceController$desktop(blockedOpen),
				$author$project$SurfaceController$desktop(attachedModel)) && $elm$core$List$isEmpty(blockedEffects)),
			_Utils_Tuple2(
			'foreignIdleRefusesThenCurrentIdleAllows',
			_Utils_eq(
				$author$project$SurfaceController$desktop(foreignOpen),
				$author$project$SurfaceController$desktop(foreignIdle)) && ($elm$core$List$isEmpty(foreignEffects) && ($author$project$SurfaceController$desktop(opened).x && (!_Utils_eq(
				$author$project$SurfaceController$desktop(opened).aP,
				$elm$core$Maybe$Nothing))))),
			_Utils_Tuple2(
			'confirmationPublishesSuccessorAndFocus',
			(!_Utils_eq(intent, $elm$core$Maybe$Nothing)) && (_Utils_eq(
				$author$project$SystemMenuFocusPipeline$focus(confirmationEffects),
				_List_fromArray(
					[confirmId])) && (A3($author$project$SystemMenuFocusPipeline$matches, confirmId, 'system:cancel', confirmation) && A2(sameFrame, confirmation, confirmationEffects)))),
			_Utils_Tuple2(
			'cancellationPublishesSuccessorAndFocus',
			_Utils_eq(
				$author$project$SystemMenuFocusPipeline$focus(cancelEffects),
				_List_fromArray(
					[closeId])) && (A3($author$project$SystemMenuFocusPipeline$matches, closeId, 'control:close', cancelled) && A2(sameFrame, cancelled, cancelEffects))),
			_Utils_Tuple2(
			'literalFullModelsAndOrderedEffects',
			exactModels && (_Utils_eq(
				confirmationEffects,
				_List_fromArray(
					[
						$author$project$SurfaceController$Publish(
						$author$project$SurfaceController$frame(confirmation)),
						$author$project$SurfaceController$DesktopEffect(
						$author$project$Desktop$Focus(confirmId))
					])) && _Utils_eq(
				cancelEffects,
				_List_fromArray(
					[
						$author$project$SurfaceController$Publish(
						$author$project$SurfaceController$frame(cancelled)),
						$author$project$SurfaceController$DesktopEffect(
						$author$project$Desktop$Focus(closeId))
					])))),
			_Utils_Tuple2(
			'staleThenValid',
			_Utils_eq(
				$author$project$SurfaceController$desktop(stale.a),
				$author$project$SurfaceController$desktop(confirmation)) && ($elm$core$List$isEmpty(stale.b) && (_Utils_eq(
				$author$project$SurfaceController$desktop(validAfterStale),
				$author$project$SurfaceController$desktop(cancelled)) && (_Utils_eq(
				$author$project$SystemMenuFocusPipeline$focus(validEffects),
				_List_fromArray(
					[closeId])) && A2(sameFrame, validAfterStale, validEffects))))),
			_Utils_Tuple2(
			'duplicateCancelRefused',
			_Utils_eq(
				$author$project$SurfaceController$desktop(duplicate),
				$author$project$SurfaceController$desktop(cancelled)) && $elm$core$List$isEmpty(duplicateEffects)),
			_Utils_Tuple2(
			'unavailableNetworkDisabled',
			A2(
				$elm$core$List$any,
				function (c) {
					return (c.cc === 'system:network:state') && ((c.d6 === 'Network unavailable') && ((!c.b9) && _Utils_eq(c.d, $elm$core$Maybe$Nothing)));
				},
				$author$project$Surface$controls(
					$author$project$SurfaceController$desktop(read)))),
			_Utils_Tuple2(
			'observedVolumeDisplayed',
			A2(
				$elm$core$List$any,
				function (c) {
					return A2($elm$core$String$startsWith, 'Volume 100%', c.d6);
				},
				$author$project$Surface$controls(
					$author$project$SurfaceController$desktop(read))))
		]);
	return $elm$json$Json$Encode$object(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'checks',
				$elm$json$Json$Encode$object(
					A2(
						$elm$core$List$map,
						function (_v11) {
							var name = _v11.a;
							var ok = _v11.b;
							return _Utils_Tuple2(
								name,
								$elm$json$Json$Encode$bool(ok));
						},
						checks))),
				_Utils_Tuple2(
				'confirmationFrame',
				$author$project$SurfaceController$frame(confirmation)),
				_Utils_Tuple2(
				'cancelFrame',
				$author$project$SurfaceController$frame(cancelled))
			]));
}();
var $elm$core$Platform$worker = _Platform_worker;
var $author$project$SystemMenuFocusPipeline$main = $elm$core$Platform$worker(
	{
		fc: function (_v0) {
			return _Utils_Tuple2(
				0,
				$author$project$SystemMenuFocusPipeline$outgoing($author$project$SystemMenuFocusPipeline$result));
		},
		fI: function (_v1) {
			return $elm$core$Platform$Sub$none;
		},
		fN: F2(
			function (_v2, model) {
				return _Utils_Tuple2(model, $elm$core$Platform$Cmd$none);
			})
	});
_Platform_export({'SystemMenuFocusPipeline':{'init':$author$project$SystemMenuFocusPipeline$main(
	$elm$json$Json$Decode$succeed(0))(0)}});}(this));