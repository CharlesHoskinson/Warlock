from pathlib import Path
import ast,difflib,hashlib,json,os,stat
root=Path('/home/hoskinson/Projects/Warlock');out=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cache=Path('/home/hoskinson/.local/share/warlock-toolchain/elm-cache')
def rows(directory):
 result={}
 for p in sorted(directory.rglob('*')):
  name=str(p.relative_to(directory))
  if p.is_symlink():result[name]={'link':os.readlink(p)}
  elif p.is_file():result[name]={'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode),'size':p.stat().st_size}
  else:assert p.is_dir()
 return result
original=rows(cache);runs={n:root/'.warlock-contributor'/('arm64-cpu-'+n)/'successor-focus/elm-home' for n in ('1793950970948210813','1793951236470509914')};observed={n:rows(p) for n,p in runs.items()}
extras={}
for n,r in observed.items():
 assert {k:r[k] for k in original}==original
 extras[n]={k:v for k,v in r.items() if k not in original}
assert len(original)==118 and len(extras[next(iter(extras))])==20
assert len({json.dumps(v,sort_keys=True) for v in extras.values()})==1
outputs=next(iter(extras.values()))
assert all(v['mode']==0o644 and v['size']>0 and Path(k).name in ('artifacts.dat','docs.json') for k,v in outputs.items())
arm=json.loads((root/'tools/arm64-toolchain.json').read_text());manifest={'schema':1,'profile':'successor-focus-fixed-elm-compiler-cache','toolchainManifestSHA256':sha(root/'tools/arm64-toolchain.json'),'compilerSHA256':arm['files'][arm['elm']],'sdkElmCache':arm['trees'][str(cache)],'generatedFiles':outputs}
manifest_path=out/'successor-focus-elm-cache-outputs.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
proof={'originalFiles':len(original),'runs':{n:{'cache':str(p),'totalFiles':len(observed[n]),'originalInputsUnchanged':True,'generated':extras[n]} for n,p in runs.items()},'identicalGeneratedOutputs':True,'sdkRows':original,'sdkManifestSHA256':sha(root/'tools/arm64-toolchain.json'),'scope':'Read-only retained compiler outputs; not new execution or acceptance'};(out/'comparison.json').write_text(json.dumps(proof,indent=2)+'\n')
p=root/'tools/check_arm64_cpu.py';old=p.read_text();start=old.index('def successor_focus_frontend');end=old.index('\ndef consumption_frontend',start);section=old[start:end]
section=section.replace("    cache_before = inventory(Path(packet['elmHome']))\n",'''    cache_before = inventory(Path(packet['elmHome']))
    output_contract = json.loads((ROOT / 'tools/successor-focus-elm-cache-outputs.json').read_text())
    if (set(output_contract) != {'schema', 'profile', 'toolchainManifestSHA256', 'compilerSHA256', 'sdkElmCache', 'generatedFiles'}
            or output_contract['schema'] != 1 or output_contract['profile'] != 'successor-focus-fixed-elm-compiler-cache'
            or output_contract['toolchainManifestSHA256'] != packet['manifestSHA256']
            or output_contract['compilerSHA256'] != packet['compilerSHA256']
            or output_contract['sdkElmCache'] != cache_before):
        raise RuntimeError('Successor compiler cache contract differs from reviewed SDK')
    def cache_rows(directory):
        rows = {}
        for path in sorted(directory.rglob('*')):
            key = str(path.relative_to(directory))
            if path.is_symlink():
                rows[key] = {'link': os.readlink(path)}
            elif path.is_file():
                rows[key] = {'sha256': digest(path), 'mode': path.stat().st_mode & 0o7777, 'size': path.stat().st_size}
            elif not path.is_dir():
                raise RuntimeError('Unexpected special compiler cache input')
        return rows
    cache_inputs = cache_rows(Path(packet['elmHome']))
    generated = output_contract['generatedFiles']
    if (len(generated) != 20 or set(generated) & set(cache_inputs)
            or any(Path(name).is_absolute() or '..' in Path(name).parts
                   or Path(name).name not in ('artifacts.dat', 'docs.json')
                   or set(row) != {'sha256', 'mode', 'size'} or row['mode'] != 0o644
                   or type(row['size']) is not int or row['size'] <= 0
                   or not re.fullmatch('[0-9a-f]{64}', row['sha256']) for name, row in generated.items())):
        raise RuntimeError('Invalid exact compiler cache output contract')
    def checked_cache(complete):
        rows = cache_rows(frontend / 'elm-home')
        if (any(rows.get(name) != row for name, row in cache_inputs.items())
                or any(name not in cache_inputs and generated.get(name) != row for name, row in rows.items())
                or (complete and set(rows) != set(cache_inputs) | set(generated))):
            raise RuntimeError('Compiler cache changed input or produced unreviewed output')
        return rows
''',1)
section=section.replace("                and inventory(frontend / 'elm-home') == cache_before\n",'')
section=section.replace("    if not stages_match():\n", "    if checked_cache(False) != cache_inputs or not stages_match():\n",1)
section=section.replace("        artifacts[name] = image(target)\n", "        artifacts[name] = image(target)\n        checked_cache(False)\n",1)
section=section.replace("    campaigns = (\n", "    compiler_cache_after = checked_cache(True)\n    cache_receipt = frontend / 'compiler-cache-after.json'\n    cache_receipt.write_text(json.dumps(compiler_cache_after, indent=2, sort_keys=True) + '\\n')\n    compiler_cache_receipt_sha = digest(cache_receipt)\n    campaigns = (\n",1)
section=section.replace("        receipt = json.loads(receipt_path.read_text())\n", "        if checked_cache(True) != compiler_cache_after:\n            raise RuntimeError('Compiler cache changed during runtime replay')\n        receipt = json.loads(receipt_path.read_text())\n",1)
section=section.replace("    if (not stages_match() or digest(frontend / 'elm.json') != config_hash\n", "    if (not stages_match() or checked_cache(True) != compiler_cache_after\n            or digest(cache_receipt) != compiler_cache_receipt_sha or digest(frontend / 'elm.json') != config_hash\n",1)
section=section.replace("            'receipts': receipts, 'artifacts': artifacts, 'runtimeELF': elf,\n", "            'receipts': receipts, 'artifacts': artifacts, 'runtimeELF': elf,\n            'compilerCache': {'path': str(cache_receipt), 'sha256': compiler_cache_receipt_sha,\n                              'inputFiles': len(cache_inputs), 'generatedFiles': len(generated),\n                              'contractSHA256': digest(ROOT / 'tools/successor-focus-elm-cache-outputs.json')},\n",1)
new=old[:start]+section+old[end:]
new=new.replace("            if child.returncode or not report['passed']:\n                raise RuntimeError('Private ARM profile failed; retained logs')", "            if child.returncode or not report['passed']:\n                report['privateError'] = report.get('error', 'Missing successful private terminal receipt')\n                raise RuntimeError('Private ARM profile failed; retained logs: ' + report['privateError'])",1)
q=root/'tools/qa_cpu.py';qo=q.read_text();qn=qo.replace("    if successor_focus:\n", "    if successor_focus:\n        names.add('tools/successor-focus-elm-cache-outputs.json')\n",1)
patch='';bindings={}
for name,before,after in [('tools/check_arm64_cpu.py',old,new),('tools/qa_cpu.py',qo,qn),('tools/successor-focus-elm-cache-outputs.json','',manifest_path.read_text())]:
 if name.endswith('.py'):ast.parse(after)
 (out/Path(name).name).write_text(after)
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name));bindings[name]={'before':hashlib.sha256(before.encode()).hexdigest() if before else None,'after':hashlib.sha256(after.encode()).hexdigest()}
(out/'cache-repair.patch').write_text(patch);(out/'review.json').write_text(json.dumps({'status':'source-only repair candidate; independent review and Root adoption required','patchSHA256':hashlib.sha256(patch.encode()).hexdigest(),'bindings':bindings,'comparisonSHA256':sha(out/'comparison.json'),'qaExecuted':False,'acceptance':False,'priorGreen':'Both harnesses0 all740checks true; overall failed postcacheguard. Not qualified GREEN.'},indent=2)+'\n');print(hashlib.sha256(patch.encode()).hexdigest())
