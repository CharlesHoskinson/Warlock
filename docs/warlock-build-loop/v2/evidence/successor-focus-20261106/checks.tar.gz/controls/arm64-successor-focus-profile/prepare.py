from pathlib import Path
import ast,difflib,hashlib,json,re
out=Path(__file__).parent;root=Path('/home/hoskinson/Projects/Warlock');qa=root/'implementation/warlock/qa';q=Path('/home/hoskinson/.local/state/warlock-team/20261105/terra-team/artifacts/quint8/rolling-source-r14-20261106T072232Z');i=Path('/home/hoskinson/.local/state/warlock-team/20261105/terra-team/artifacts/impl8/rolling-source-r15-20261106T072105Z')
sha=lambda b:hashlib.sha256(b).hexdigest()
original=(qa/'system-menu-typed-state.cjs').read_text()
def arr(n):return json.loads(re.search(r'const '+n+r' = Object.freeze\((\[.*?\])\);',original).group(1))
legacy=arr('LEGACY');modern=[f'seed-{n}/{s}' for n in range(32) for s in arr('DOMAIN_SUFFIXES')]+arr('DESKTOP')+arr('CAPABILITIES')+arr('SESSIONS')
harness=(q/'successor-focus-harness.cjs').read_text();specs=[]
for m in re.finditer(r"\{name:'([^']+)', top:\[(.*?)\], checks:\[(.*?)\]\}",harness,re.S):
 specs.append((m[1],re.findall(r"'([^']+)'",m[3])))
assert [len(v) for n,v in specs]==[9,11,42] and len(legacy)==28 and len(modern)==650
manifest={'SystemMenuReplay':legacy,'SolSystemMenuIntegratedReplay2114':modern,**dict(specs)}
fn='SUCCESSOR_FOCUS_CHECKS = '+repr(manifest)+'\n\n\n'+'''def successor_focus_frontend(output, env, packet, run):
    """Fixed synthetic successor focus checks; no native/AT or Cmd-AST proof."""
    frontend = output / 'successor-focus'
    frontend.mkdir(mode=0o700)
    source = ROOT / 'implementation/warlock'
    source_before = inventory(source / 'src')
    cache_before = inventory(Path(packet['elmHome']))
    reviewed = json.loads((output / 'report.json').read_text())['sourceHashes']
    shutil.copytree(source / 'src', frontend / 'src')
    shutil.copytree(Path(packet['elmHome']), frontend / 'elm-home')
    (frontend / 'qa').mkdir(mode=0o700)
    qa_files = [name for name in arm64_inputs(ROOT, successor_focus=True)
                if name.startswith('implementation/warlock/qa/')]
    for name in qa_files:
        shutil.copyfile(ROOT / name, frontend / 'qa' / Path(name).name)
    def stages_match():
        return (inventory(frontend / 'src') == source_before and inventory(source / 'src') == source_before
                and inventory(Path(packet['elmHome'])) == cache_before
                and inventory(frontend / 'elm-home') == cache_before
                and all(digest(frontend / 'qa' / Path(name).name) == reviewed[name] for name in qa_files))
    if not stages_match():
        raise RuntimeError('Successor focus reviewed source/cache stage differs')
    config = json.loads((source / 'elm.json').read_text())
    config['source-directories'] = ['src', 'qa']
    (frontend / 'elm.json').write_text(json.dumps(config, sort_keys=True) + '\\n')
    config_hash = digest(frontend / 'elm.json')
    build_env = dict(env, ELM_HOME=str(frontend / 'elm-home'))
    elf = {}
    for key in ('node', 'elm'):
        with Path(packet[key]).open('rb') as stream:
            header = stream.read(20)
        if header[:6] != b'\\x7fELF\\x02\\x01' or int.from_bytes(header[18:20], 'little') != 183:
            raise RuntimeError('Expected pinned ELF64 little-endian AArch64 ' + key)
        elf[key] = {'sha256': digest(Path(packet[key])), 'class': 64, 'machine': 183}
    artifacts = {}
    for name in SUCCESSOR_FOCUS_CHECKS:
        target = frontend / (name + '.js')
        run('compile-' + name, [packet['elm'], 'make', 'qa/' + name + '.elm',
            '--optimize', '--output=' + str(target)], frontend, 180, build_env)
        artifacts[name] = image(target)
    campaigns = (
        ('original-system-menu', 'system-menu-typed-state.cjs', ('SystemMenuReplay', 'SolSystemMenuIntegratedReplay2114')),
        ('successor-focus', 'successor-focus-harness.cjs', ('SystemMenuFocusPipeline', 'SuccessorFocusReplay', 'SystemMenuFocusExtended')))
    receipts = {}
    for label, driver_name, workers in campaigns:
        receipt_path = frontend / (label + '-receipt.json')
        driver = frontend / 'qa' / driver_name
        run(label, [packet['node'], driver, *[artifacts[name]['path'] for name in workers], receipt_path], frontend, 180, build_env)
        receipt = json.loads(receipt_path.read_text())
        rows = receipt.get('fixtures', [])
        if (receipt.get('schema') != 1 or receipt.get('passed') is not True
                or receipt.get('settleWindowMs') != 25 or receipt.get('originalAccepted') is not False
                or receipt.get('nativeAccepted') is not False or [row.get('name') for row in rows] != list(workers)):
            raise RuntimeError('Fixed focus campaign terminal receipt differs: ' + label)
        for row in rows:
            name = row['name']
            checks = row.get('payload', {}).get('checks', {})
            if (row.get('passed') is not True or row.get('file') != artifacts[name]['path']
                    or row.get('sha256') != artifacts[name]['sha256']
                    or set(checks) != set(SUCCESSOR_FOCUS_CHECKS[name])
                    or any(value is not True for value in checks.values())):
                raise RuntimeError('Exact complete focus check/image receipt differs: ' + name)
        if label == 'original-system-menu':
            if receipt.get('runnerPathSha256AtReport') != digest(driver):
                raise RuntimeError('Original fixed harness receipt hash differs')
            for row in rows:
                if ([check.get('name') for check in row.get('checks', [])] != SUCCESSOR_FOCUS_CHECKS[row['name']]
                        or any(check.get('passed') is not True for check in row['checks'])):
                    raise RuntimeError('Original complete ordered check receipt differs')
            modern = rows[1]['payload']
            if (modern.get('checkCount') != 650 or modern.get('requiredCheckCount') != 650
                    or modern.get('seeds') != list(range(32)) or modern.get('originalAccepted') is not False
                    or modern.get('nativeAccepted') is not False):
                raise RuntimeError('Original 650 seed/count/acceptance contract differs')
        receipts[label] = {'receipt': receipt, 'path': str(receipt_path),
                           'sha256': digest(receipt_path), 'driverSha256': digest(driver)}
    if (not stages_match() or digest(frontend / 'elm.json') != config_hash
            or any(image(Path(item['path'])) != item for item in artifacts.values())):
        raise RuntimeError('Successor focus source/cache/image changed during execution')
    return {'scope': 'Compiled synthetic successor-focus/system-menu component only',
            'receipts': receipts, 'artifacts': artifacts, 'runtimeELF': elf,
            'nativeAcceptance': False, 'originalAcceptance': False, 'releaseAccepted': False,
            'opaqueCmdASTObserved': False, 'productionRootBehaviorExecuted': False}


'''
files={};p=root/'tools/check_arm64_cpu.py';old=p.read_text();new=old.replace('def consumption_frontend(',fn+'def consumption_frontend(',1)
new=new.replace("'held-executable', 'peer-role'):","'held-executable', 'peer-role', 'successor-focus'):")
new=new.replace('    if args.inside_private is None:\n',"    if args.successor_focus:\n        mode = '--successor-focus'\n    if args.inside_private is None:\n",1)
new=new.replace('haskell_profile, args.preview_consumption))','haskell_profile, args.preview_consumption, args.successor_focus))')
new=new.replace('args.preview_consumption)) != set(sources)', 'args.preview_consumption, args.successor_focus)) != set(sources)')
new=new.replace('        if args.preview_consumption:\n',"        if args.successor_focus:\n            report['successorFocus'] = successor_focus_frontend(output, env, packet, run)\n        elif args.preview_consumption:\n",1);files['tools/check_arm64_cpu.py']=(old,new)
p=root/'tools/qa_cpu.py';old=p.read_text();new=old.replace('protocol_only=False, consumption=False):','protocol_only=False, consumption=False, successor_focus=False):',1)
new=new.replace('    if consumption:\n',"    if successor_focus:\n        names.update('implementation/warlock/qa/' + name for name in (\n            'SystemMenuReplay.elm', 'SolSystemMenuIntegratedReplay2114.elm',\n            'SystemMenuFocusPipeline.elm', 'SuccessorFocusReplay.elm', 'SystemMenuFocusExtended.elm',\n            'NativePointerFixture.elm', 'system-menu-typed-state.cjs', 'successor-focus-harness.cjs',\n            'check-search.py'))\n    elif consumption:\n",1)
new=new.replace("['--held-executable'], ['--peer-role']]","['--held-executable'], ['--peer-role'], ['--successor-focus']]")
new=new.replace("consumption=packet['arguments'] == ['--preview-consumption'])","consumption=packet['arguments'] == ['--preview-consumption'],\n                                 successor_focus=packet['arguments'] == ['--successor-focus'])",1);files['tools/qa_cpu.py']=(old,new)
patch='';bindings={}
for name,(old,new) in files.items():
 ast.parse(new);(out/Path(name).name).write_text(new)
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name));bindings[name]={'before':sha(old.encode()),'after':sha(new.encode())}
(out/'successor-focus.patch').write_text(patch)
(out/'fixed-check-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
inputs=[qa/'SystemMenuReplay.elm',qa/'SolSystemMenuIntegratedReplay2114.elm',qa/'system-menu-typed-state.cjs',qa/'check-search.py',q/'SystemMenuFocusPipeline.elm',q/'SystemMenuFocusExtended.elm',q/'SuccessorFocusReplay.elm',q/'successor-focus-harness.cjs',q/'handoff.json',i/'handoff.json']
(out/'review.json').write_text(json.dumps({'status':'source-only support proposal, pending Root tuple selection/adoption/independent review','bindings':bindings,'patchSHA256':sha(patch.encode()),'inputCandidateHashes':{str(p):sha(p.read_bytes()) for p in inputs},'fixedCounts':{n:len(v) for n,v in manifest.items()},'packetGenerated':False,'qaExecuted':False,'acceptance':False},indent=2)+'\n')
print(sha(patch.encode()))
