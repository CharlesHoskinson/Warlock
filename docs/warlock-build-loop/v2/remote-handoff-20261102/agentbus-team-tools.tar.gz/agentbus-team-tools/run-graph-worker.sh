#!/bin/bash
set -u
rd=/home/charl/.local/state/warlock-team/20261031-agentbus
. "$rd/team.env"
. "$rd/ids/.bindings/$TEAM_RUN/terra-graph/.agentbus/env"
log="$rd/logs/terra-graph-followup-$(date +%Y%m%d-%H%M%S).log"
prompt=$(cat "$rd/terra-graph-followup-20261101.txt")
"$rd/tools/capped.sh" 3G "w-$TEAM_RUN-terra-graph" timeout 1800 codex exec -m gpt-6.1-terra -c model_reasoning_effort='"high"' --skip-git-repo-check -s workspace-write -c sandbox_workspace_write.network_access=true -C /home/charl/code/Warlock --add-dir "$rd" --add-dir /home/charl/.cache/agentbus --add-dir /home/charl/.local/share/warlock-graph "$prompt" > "$log" 2>&1 < /dev/null
rc=$?
echo "exit $rc" >> "$log"
echo "$log"
exit "$rc"
