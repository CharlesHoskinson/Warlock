#!/bin/bash
# capped.sh CAP LABEL CMD...: run CMD in its own memory-capped systemd scope inside the team slice ($TEAM_SLICE).
#
# A runaway process is then killed alone at CAP instead of taking the machine down (proforma run, 2026-10-30: one
# agy grew to 29 GB, the kernel OOM killer fired and every agent and Claude session on the machine died). The scope
# is named LABEL-<time>-<pid>; memwatch.sh never picks a scope whose label starts with `lead`, unless it has no other choice.
# Without a systemd user manager (or with TEAM_MEMCAP=0) it runs CMD uncapped and says so on stderr.
set -u
. "$(dirname "$0")/../team.env"
cap=$1; label=${2//[^A-Za-z0-9_.-]/_}; shift 2
if [ "${TEAM_MEMCAP:-1}" = 1 ] && [ -n "${TEAM_SLICE:-}" ] && systemctl --user show-environment >/dev/null 2>&1; then
  exec systemd-run --user --scope --quiet --collect --slice="$TEAM_SLICE" --unit="$label-$(date +%s)-$$" \
    -p MemoryMax="$cap" -p MemorySwapMax="${TEAM_CAP_SWAP:-1G}" "$@"
fi
echo "capped.sh: no systemd user manager, TEAM_SLICE unset or TEAM_MEMCAP=0: $label runs WITHOUT a memory cap" >&2
exec "$@"
