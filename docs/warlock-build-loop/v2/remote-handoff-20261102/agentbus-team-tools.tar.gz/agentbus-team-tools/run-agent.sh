#!/bin/bash
# run-agent.sh: run one headless, sandboxed turn of a writer on the team.
#
# usage: run-agent.sh NAME PROMPT_FILE        NAME: terra1..N | sol | grok | muse | gemini | <any name added below>
#
# Writes RD/logs/NAME-<timestamp>.log (last line `exit N`), prints its path, exits with the CLI's code.
# Blocks for the whole turn (often 10-40 min; capped at TEAM_TURN_TIMEOUT, default 2700 s). A lead must launch
# it detached (setsid nohup ... &): a foreground tool call that times out kills the writer.
#
# Every writer is sandboxed: reads anywhere, writes the worktree (and RD / the bus inbox where the CLI allows).
# Never switch these to the "skip all permissions / no sandbox" flags: the network is only needed for the
# loopback bus and the model API, and the sandboxes below allow both.
set -u
. "$(dirname "$0")/../team.env"
name=$1; pf=$(realpath "$2"); prompt=$(cat "$pf")
. "$TEAM_RD/ids/.bindings/$TEAM_RUN/$name/.agentbus/env"
export PATH=$TEAM_RD/tools:$PATH MUSE_NO_AUTO_UPDATE=1
log=$(mktemp "$TEAM_RD/logs/$name-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX.log")
# Every writer turn runs in its own memory-capped scope inside the team slice (capped.sh), so a runaway CLI is killed
# alone. Measured peak (2026-10-30): agy with Gemini 4 Argon 10 to 29 GB per turn.
case $name in gemini*) CAP=${AGY_WORKER_CAP:-${TEAM_CAP_GEMINI:-34G}};; muse*) CAP=${TEAM_CAP_MUSE:-8G};; *) CAP=${TEAM_CAP_DEFAULT:-6G};; esac
T="$TEAM_RD/tools/capped.sh $CAP w-$TEAM_RUN-$name timeout ${TEAM_TURN_TIMEOUT:-2700}"
cd "$TEAM_WT"
case $name in
  # Gemini 4 via Antigravity, through run-gemini.py: a watchdog for agy's hard 5-minute stream-idle timeout
  # (kills at the first error step, resumes the same --conversation one effort tier lower) and for early
  # turn stops (resumes until a done-marker exists). --sandbox restricts its terminal; headless it can only
  # use tools named by allow-rules in ~/.gemini/antigravity-cli/settings.json (team-init.sh --gemini-allow), and
  # its sandbox PATH lacks ~/.local/bin, so prompts must call tools by absolute path.
  gemini*) $T /usr/bin/python3 "$TEAM_RD/tools/run-gemini.py" "$pf" "${AGY_DONE_MARKER:-$TEAM_WT/.team/notes/DONE-$name-$(date +%s)}" $(( ${TEAM_TURN_TIMEOUT:-2700} - 100 )) "$TEAM_RD" ;;
  # Muse Wonder. Sandbox stays on (needs muse installed outside $HOME, e.g. /opt/muse, for its bubblewrap);
  # network enabled for the bus; writes are limited to --workspace.
  muse)   $T muse exec --model muse-wonder-1.0 --workspace "$TEAM_WT" --approval-mode never --sandbox-network enabled "$prompt" ;;
  # Grok 4.7. Uses the `team` profile from $TEAM_WT/.grok/sandbox.toml. grok -p rejects --add-dir.
  # Grok 4.7. --no-auto-update is the documented flag for scripted -p runs. If Grok is out of credits, set
  # TEAM_GROK_AS_TERRA=1 and grok* identities run GPT-6.1 Terra with the terra sandbox flags (owner, 2026-10-29).
  grok*)  if [ "${TEAM_GROK_AS_TERRA:-0}" = 1 ]; then
            $T codex exec -m gpt-6.1-terra -c model_reasoning_effort='"high"' --skip-git-repo-check -s workspace-write \
              -c sandbox_workspace_write.network_access=true -C "$TEAM_WT" --add-dir "$TEAM_RD" --add-dir "$HOME/.cache/agentbus" "$prompt"
          else $T grok -m grok-4.7 --no-auto-update --sandbox team --always-approve -p "$prompt"; fi ;;
  # Muse Wonder Full (Muse Code only, higher-capability variant), reasoning effort xhigh. --trust-workspace is needed
  # headless. Muse 1.4.14 rejects --sandbox-network unrestricted (docs say enabled is deprecated): keep enabled.
  musefull) $T muse exec --model muse-wonder-full-1.0 --reasoning-effort xhigh --workspace "$TEAM_WT" --approval-mode never \
            --sandbox-network enabled --trust-workspace "$prompt" ;;
  # Claude Fable 5.1, headless, classifier-gated auto mode (never bypassPermissions).
  fable*) $T claude -p "$prompt" --model claude-fable-5-1 --permission-mode auto --add-dir "$TEAM_RD" ;;
  # Quint audits with the quint-llm-kit plugin (skills quint-modeling, quint-lang, quint-execute-spec), Claude Opus 5.5.
  quintkit*) $T claude -p "$prompt" --model claude-opus-5-5 --permission-mode auto --add-dir "$TEAM_RD" \
            --plugin-dir /home/charl/.claude/plugins/marketplaces/quint-llm-kit/quint-llm-kit-plugin ;;
  # GPT Sol via Codex. Can also generate images (GPT image generation).
  sol*)   $T codex exec -m gpt-6.1-sol --skip-git-repo-check -s workspace-write -c sandbox_workspace_write.network_access=true \
            -C "$TEAM_WT" --add-dir "$TEAM_RD" --add-dir "$HOME/.cache/agentbus" "$prompt" ;;
  # GPT-6.1 Terra (released 2026-10-26) via Codex, reasoning effort high. Strong at visual reasoning (screenshots),
  # computer use and clear writing; image input; 1.05M context. Name writers terra1..terraN.
  terra*) $T codex exec -m gpt-6.1-terra -c model_reasoning_effort='"high"' --skip-git-repo-check -s workspace-write \
            -c sandbox_workspace_write.network_access=true -C "$TEAM_WT" --add-dir "$TEAM_RD" --add-dir "$HOME/.cache/agentbus" "$prompt" ;;
  # Claude Haiku 5.5 as a worker (research, fact-checking): no OS sandbox, so a strict tool allow-list instead:
  # read anywhere, edit/write only inside the worktree, shell only for the bus, Scrapling and the team tools.
  haiku*) $T claude -p "$prompt" --model claude-haiku-5-5 --permission-mode dontAsk --add-dir "$TEAM_RD" \
            --allowedTools Read Glob Grep "Edit(/$TEAM_WT/**)" \
            "Bash(/home/charl/.local/bin/agentbus:*)" "Bash(pdftotext:*)" \
            "Bash($TEAM_RD/tools/scrape.py:*)" "Bash($TEAM_RD/tools/persona.sh:*)" "Bash($TEAM_RD/tools/shoot.sh:*)" ;;
  # (Claude permission rules: Edit(//abs/**) covers all file writes; Write(path) is not a file rule. Bash rules match
  # literal command prefixes only: prompts must call tools by absolute path with literal arguments, no $VARS.)
  # GPT-6 Astra via Codex as a coordinator (TEAM_LEAD_CLI=astra in launch-lead.sh) or a worker. It launches other
  # writers from inside its sandbox, so it also needs the nested CLIs' state dirs writable.
  astra*) $T codex exec -m gpt-6-astra -c model_reasoning_effort='"high"' --skip-git-repo-check -s workspace-write \
            -c sandbox_workspace_write.network_access=true -C "$TEAM_WT" --add-dir "$TEAM_RD" --add-dir "$HOME/.cache/agentbus" \
            --add-dir "$HOME/.codex" --add-dir "$HOME/.claude" "$prompt" ;;
  *) echo "unknown agent $name" >&2; exit 2 ;;
esac > "$log" 2>&1 < /dev/null
rc=$?; echo "exit $rc" >> "$log"; echo "$log"; exit $rc
