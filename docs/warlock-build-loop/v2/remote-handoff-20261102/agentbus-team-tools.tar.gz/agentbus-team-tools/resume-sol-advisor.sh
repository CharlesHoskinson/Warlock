#!/bin/bash
set -eu
turn_seconds=${TEAM_CODEX_TURN_SECONDS:-1800}
case "$turn_seconds" in 1800|3600) ;; *) echo "Unsupported source-worker turn budget"; exit 2;; esac
rd=/home/charl/.local/state/warlock-team/20261031-agentbus
. "$rd/team.env"
. "$rd/ids/.bindings/$TEAM_RUN/sol-docs/.agentbus/env"
log=$(mktemp "$rd/logs/sol-advisor-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX.log")
set +e
"$rd/tools/capped.sh" 4G "w-$TEAM_RUN-sol-advisor" timeout "$turn_seconds" codex exec resume 01a1947b-90dd-7ac0-9b96-477ca1e32bc2 -m gpt-6.1-sol -c model_reasoning_effort='"high"' -c approval_policy='"never"' -c sandbox_mode='"workspace-write"' -c sandbox_workspace_write.network_access=true -c 'sandbox_workspace_write.writable_roots=["/home/charl/.local/state/warlock-team/20261031-agentbus","/home/charl/.cache/agentbus"]' "$(cat "$1")" > "$log" 2>&1 < /dev/null
rc=$?
echo "exit $rc" >> "$log"
echo "$log"
exit "$rc"
