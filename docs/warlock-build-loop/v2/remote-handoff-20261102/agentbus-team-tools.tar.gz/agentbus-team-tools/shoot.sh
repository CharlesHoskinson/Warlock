#!/bin/bash
# shoot.sh: screenshot a page in a real browser (Playwright + Chromium, software WebGL so three.js renders).
#
# usage: shoot.sh PAGE[#anchor] OUT.png [WIDTH=1440] [HEIGHT=900] [--theme light|dark] [--full] [--wait MS]
#
# Scrolls #anchor into view, waits for the scene (default 2500 ms), captures; page console errors go to stderr.
# --theme sets ?theme= and the localStorage keys in SHOOT_THEME_KEYS (comma-separated, default "theme"); set it to
# the page's own key. Needs node, a Playwright Chromium under ~/.cache/ms-playwright and playwright-core in tools/node_modules
# (team-init.sh copies one it finds on disk). Plain `chrome --screenshot` cannot do this: it ignores anchors
# and captures before WebGL scenes draw.
exec /usr/bin/node "$(dirname "$0")/shoot.mjs" "$@"
