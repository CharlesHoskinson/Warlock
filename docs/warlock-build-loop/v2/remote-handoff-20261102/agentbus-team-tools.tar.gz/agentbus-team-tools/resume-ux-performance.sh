#!/bin/bash
set -eu
turn_seconds=${TEAM_CODEX_TURN_SECONDS:-1800}
case "$turn_seconds" in 1800|3600) ;; *) echo "Unsupported source-worker turn budget"; exit 2;; esac
rd=/home/charl/.local/state/warlock-team/20261031-agentbus
prior=$1
pf=$2
case "$(tail -n 1 "$prior")" in 'exit 0'|'exit 124'|'exit 137') ;; *) echo 'Prior performance turn not terminal';exit 2;;esac
sid=$(sed -n 's/^session id: //p' "$prior" | head -1)
[ -n "$sid" ] || exit 2
python3 - "$sid" <<'CHECK'
from pathlib import Path
import sys,os
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:a=(p/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 if a and Path(os.fsdecode(a[0])).name=='codex' and sys.argv[1].encode() in a:raise SystemExit('Performance session already has live CLI')
CHECK
. "$rd/team.env"
. "$rd/ids/.bindings/$TEAM_RUN/terra-browser/.agentbus/env"
cd "$TEAM_WT"
log=$(mktemp "$rd/logs/ux-performance-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX.log")
set +e
"$rd/tools/capped.sh" 4G "w-$TEAM_RUN-ux-performance" timeout "$turn_seconds" codex exec resume "$sid" -m gpt-6.1-terra -c model_reasoning_effort='"high"' -c approval_policy='"never"' -c sandbox_mode='"workspace-write"' -c sandbox_workspace_write.network_access=true -c 'sandbox_workspace_write.writable_roots=["/home/charl/.local/state/warlock-team/20261031-agentbus","/home/charl/.cache/agentbus"]' "$(cat "$pf")" > "$log" 2>&1 < /dev/null
rc=$?
echo "exit $rc" >> "$log"
echo "$log"
exit "$rc"
