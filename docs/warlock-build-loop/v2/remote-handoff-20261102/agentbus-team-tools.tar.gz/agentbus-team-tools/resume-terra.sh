#!/bin/bash
set -eu
turn_seconds=${TEAM_CODEX_TURN_SECONDS:-1800}
case "$turn_seconds" in 1800|3600) ;; *) echo "Unsupported source-worker turn budget"; exit 2;; esac
rd=/home/charl/.local/state/warlock-team/20261031-agentbus
name=$1
prior=$2
prompt_file=$3
case "$name" in terra-engine|terra-portable|terra-vm|terra-graph|terra-security|terra-q-origin|terra-q-lifetime|terra-q-network|terra-q-http|terra-q-front) ;; *) exit 2;; esac
case "$(tail -n 1 "$prior")" in 'exit 0'|'exit 124'|'exit 137') ;; *) echo 'Prior log is not an eligible terminal turn'; exit 2;; esac
session_id=$(sed -n 's/^session id: //p' "$prior" | head -1)
[ -n "$session_id" ] || exit 2
python3 - "$session_id" <<'PYLIVE'
from pathlib import Path
import sys
sid=sys.argv[1].encode()
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit(): continue
 try:
  argv=(proc/'cmdline').read_bytes().split(b'\0')
  if argv and Path(argv[0].decode()).name=='codex' and b'resume' in argv and sid in argv:
   raise SystemExit('Prior session still has a live CLI; refusing duplicate launch')
 except (OSError,UnicodeError): pass
PYLIVE
. "$rd/team.env"
. "$rd/ids/.bindings/$TEAM_RUN/$name/.agentbus/env"
cd "$TEAM_WT"
log=$(mktemp "$rd/logs/$name-resume-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX.log")
set +e
"$rd/tools/capped.sh" 3G "w-$TEAM_RUN-$name" timeout "$turn_seconds" codex exec resume "$session_id" -m gpt-6.1-terra -c model_reasoning_effort='"high"' -c approval_policy='"never"' -c sandbox_mode='"workspace-write"' -c sandbox_workspace_write.network_access=true -c 'sandbox_workspace_write.writable_roots=["/home/charl/.local/state/warlock-team/20261031-agentbus","/home/charl/.cache/agentbus"]' "$(cat "$prompt_file")" > "$log" 2>&1 < /dev/null
rc=$?
echo "exit $rc" >> "$log"
echo "$log"
exit "$rc"
