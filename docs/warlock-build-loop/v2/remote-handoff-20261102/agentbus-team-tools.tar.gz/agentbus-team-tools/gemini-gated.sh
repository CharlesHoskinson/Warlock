#!/bin/bash
# gemini-gated.sh NAME PROMPT_FILE: run one Gemini (agy) turn only when memory allows.
# agy with Gemini 4 Argon peaks at 10 to 29 GB on ordinary turns (measured 2026-10-30; flash stays under 3 GB). Waits
# until MemAvailable >= GATE_GB (default 38) and fewer than MAX_AGY (default 1) agy processes are running, then runs
# run-agent.sh, which caps the turn at TEAM_CAP_GEMINI (34G). Logs waits to logs/gemini-gate.log.
name=$1; pf=$2; GATE_GB=${GATE_GB:-38}; MAX_AGY=${MAX_AGY:-1}
RD=$(cd "$(dirname "$0")/.." && pwd)
while true; do
  avail=$(awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo); n=$(pgrep -c -f '^agy -p' || true)
  if [ "$avail" -ge "$GATE_GB" ] && [ "${n:-0}" -lt "$MAX_AGY" ]; then break; fi
  echo "$(date -u +%FT%TZ) $name waiting: ${avail}G available, ${n} agy running" >> "$RD/logs/gemini-gate.log"; sleep 60
done
echo "$(date -u +%FT%TZ) $name start (${avail}G available)" >> "$RD/logs/gemini-gate.log"
exec "$RD/tools/run-agent.sh" "$name" "$pf"
