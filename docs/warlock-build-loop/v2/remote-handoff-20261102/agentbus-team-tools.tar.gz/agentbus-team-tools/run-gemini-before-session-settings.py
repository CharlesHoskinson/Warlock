#!/usr/bin/env python3
"""Supervised Gemini 4 Argon writer turn via agy headless (sandboxed; allow-rules in settings.json).

Why: agy's model stream has a hard 5-minute *idle* timeout. Gemini 4 Argon at high effort over a large
context can think silently for longer; agy then retries up to 6 times at 5 minutes each (30+ min lost),
emitting one `error_message` step per retry, and ends with
"stream idle timeout (5m0s)". Gemini also sometimes ends a turn early while "waiting" for background work.

What this does:
  * runs `agy -p ... --output-format stream-json` and watches every event;
  * on the first `error_message` step, or no event for --stall seconds, kills agy and resumes the
    same conversation (--conversation ID) one effort tier lower (high -> medium);
  * after a turn ends without the done-marker, resumes with "continue" (Gemini stopped early);
  * stops when the done-marker exists or the budget runs out.
Prints the raw stream plus {"run_gemini": ...} supervisor lines to stdout.

usage: run-gemini.py PROMPT_FILE DONE_MARKER BUDGET_S ADD_DIR [--stall 420]
       run-gemini.py --replay STREAM.jsonl      (offline: report what the watchdog would have done)
"""
import json, os, subprocess, sys, threading, time

MODELS = ['gemini-4-argon-high', 'gemini-4-argon-medium']
RULES = """

Working rules for this turn (headless, supervised):
- Run shell commands in the foreground and wait for them; never end your turn while something you started is still running.
- Read large files in slices (start/end lines), not whole; keep your context small.
- Write each deliverable to disk as soon as it is ready, then refine; do not hold everything for the end.
- When every deliverable of this turn is written (and your bus message sent), create the empty file {done}"""
CONTINUE = ("Continue the task from where you stopped. Check which deliverables are already on disk, finish the rest "
            "(read large files in slices, write as you go). When completely done, create the empty file {done}")


def say(**kw):
    print(json.dumps({'run_gemini': kw}), flush=True)


def watch(lines, on_event=None):
    """Consume stream-json lines; return (verdict, conversation_id). verdict: done|error_step|result_error."""
    conv = None
    for line in lines:
        if on_event: on_event(line)
        try: ev = json.loads(line)
        except ValueError: continue
        if ev.get('event') == 'init': conv = ev.get('conversation_id') or conv
        if ev.get('event') == 'step_update':
            su = ev['step_update']; conv = su.get('conversation_id') or conv
            if su.get('step_type') == 'error_message':
                return 'error_step', conv
        if ev.get('event') == 'result':
            return ('done' if ev['result'].get('status') == 'SUCCESS' else 'result_error'), ev['result'].get('conversation_id') or conv
    return 'eof', conv


def replay(path):
    verdict, conv = watch(open(path))
    say(replay=path, verdict=verdict, conversation=conv,
        action={'error_step': 'kill at first error_message and resume one effort tier lower',
                'done': 'turn ended; resume with continue unless the done-marker exists',
                'result_error': 'resume one effort tier lower', 'eof': 'resume'}[verdict])


def main():
    a = sys.argv[1:]
    if a and a[0] == '--replay': return replay(a[1])
    stall = 420
    if '--stall' in a: i = a.index('--stall'); stall = int(a[i + 1]); del a[i:i + 2]
    pf, done, budget, add = a[0], a[1], int(a[2]), a[3]
    start = time.time(); conv = None; tier = 0; turn = 0
    if os.path.exists(done): os.remove(done)
    while True:
        turn += 1; left = int(budget - (time.time() - start))
        if os.path.exists(done): say(turn=turn - 1, done=True); return 0
        if left <= 90: say(turn=turn - 1, budget_exhausted=True); return 3
        msg = (open(pf).read() + RULES.format(done=done)) if conv is None else CONTINUE.format(done=done)
        cmd = ['agy', '-p', msg, '--model', MODELS[tier], '--sandbox', '--add-dir', add,
               '--output-format', 'stream-json', '--print-timeout', f'{left}s']
        if conv: cmd += ['--conversation', conv]
        say(turn=turn, model=MODELS[tier], conversation=conv, seconds_left=left)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        last = [time.time()]
        def bump(line): last[0] = time.time(); sys.stdout.write(line); sys.stdout.flush()
        stalled = [False]
        def dog():
            while p.poll() is None:
                if time.time() - last[0] > stall: stalled[0] = True; p.kill(); return
                time.sleep(5)
        threading.Thread(target=dog, daemon=True).start()
        verdict, c = watch(p.stdout, bump)
        conv = c or conv
        if p.poll() is None: p.kill()
        p.wait()
        if stalled[0]: verdict = 'stall'
        say(turn=turn, verdict=verdict, conversation=conv)
        if verdict in ('error_step', 'stall', 'result_error'):
            tier = min(tier + 1, len(MODELS) - 1)   # silent long thinking: drop effort for the resume
        if conv is None: time.sleep(30)
        else: time.sleep(5)


if __name__ == '__main__':
    sys.exit(main())
