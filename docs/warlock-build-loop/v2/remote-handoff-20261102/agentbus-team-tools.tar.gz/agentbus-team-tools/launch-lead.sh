#!/bin/bash
# launch-lead.sh: start the lead (Claude Opus 5.5, headless) on RD/LEAD-BRIEF.md, detached.
#
# usage: launch-lead.sh            (reads ../team.env; log: RD/logs/lead.jsonl, stream-json)
#        TEAM_LEAD_CLI=astra launch-lead.sh   (GPT-6 Astra coordinator via Codex instead of Claude Opus)
#        TEAM_LEAD_MODEL=claude-opus-5-5 TEAM_LEAD_DIRS="/abs/a /abs/b" launch-lead.sh
#
# The prompt goes first: --add-dir is variadic and would swallow a trailing prompt.
# Permission mode `auto` (classifier-gated); never bypassPermissions.
# The lead runs in a memory-capped scope (TEAM_LEAD_CAP, default 14G) in the team slice; writers it starts get their
# own scopes (run-agent.sh). It also starts the team's memory watchdog (memwatch.sh) if that is not running.
set -u
. "$(dirname "$0")/../team.env"
. "$TEAM_RD/ids/.bindings/$TEAM_RUN/lead/.agentbus/env"
export PATH=$TEAM_RD/tools:$PATH
cd "$TEAM_WT"
"$TEAM_RD/tools/memwatch.sh" start || echo "WARNING: no memory watchdog for this team" >&2
CAP="$TEAM_RD/tools/capped.sh ${TEAM_LEAD_CAP:-14G} lead-$TEAM_RUN"
PROMPT="$(cat "$TEAM_RD/LEAD-BRIEF.md")

Begin now with phase 1. Your shell is already the AgentBus identity 'lead' on run '$TEAM_RUN'."
if [ "${TEAM_LEAD_CLI:-claude}" = astra ]; then
  # GPT-6 Astra coordinator via Codex, unsandboxed (user decision 2026-10-27): inside Codex's workspace-write sandbox
  # every process a command starts is killed when that command returns, so a sandboxed coordinator cannot keep
  # detached writers alive. Writers themselves stay sandboxed (run-agent.sh). Effort: TEAM_LEAD_EFFORT (default high).
  setsid nohup $CAP codex exec -m gpt-6-astra -c model_reasoning_effort="\"${TEAM_LEAD_EFFORT:-high}\"" --json --skip-git-repo-check \
    -s danger-full-access -C "$TEAM_WT" "$PROMPT" > "$TEAM_RD/logs/lead.jsonl" 2>&1 < /dev/null &
else
  setsid nohup $CAP claude -p "$PROMPT" \
    --model "${TEAM_LEAD_MODEL:-claude-opus-5-5}" --permission-mode auto --output-format stream-json --verbose \
    --add-dir "$TEAM_RD" ${TEAM_LEAD_DIRS:-} \
    > "$TEAM_RD/logs/lead.jsonl" 2>&1 < /dev/null &
fi
echo "lead started (pid $!); log $TEAM_RD/logs/lead.jsonl"
