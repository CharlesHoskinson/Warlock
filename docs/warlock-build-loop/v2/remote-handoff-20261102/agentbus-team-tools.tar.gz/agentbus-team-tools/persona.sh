#!/bin/bash
# persona.sh: ask a Claude Haiku 5.5 reader persona one question about files or screenshots.
#
# usage: persona.sh PERSONA_FILE "QUESTION" [FILE_OR_SCREENSHOT ...]
#
# PERSONA_FILE says who the reader is (background, what they know, why they are reading). The persona can only
# read the files named (Read tool, nothing else) and answers in character. Works from inside every writer sandbox.
set -u
pf=$1; q=$2; shift 2
files=""; for f in "$@"; do files="$files
- $(realpath "$f")"; done
prompt="You are role-playing a reader. Stay fully in character; be honest, specific and critical. Say exactly where you got lost, what words you did not understand, and what you wish had been explained.

WHO YOU ARE:
$(cat "$pf")

Read these files (use the Read tool; images are screenshots of a web page):$files

QUESTION: $q"
cd /tmp && timeout 600 claude -p --model claude-haiku-5-5 --allowedTools Read --permission-mode dontAsk "$prompt"
