#!/bin/bash
# memwatch.sh start|stop|status: memory watchdog for one team, run as a transient systemd user service outside the
# team slice, so it survives the lead, the writers and the Claude session that started it. launch-lead.sh starts it.
#
# Every 15 s it records MemAvailable and the slice's usage in RD/logs/memwatch.log (one line a minute, the top memory
# users every 5 minutes, and a WARN line at once when available memory falls below WARN_GB, default 12).
# Below KILL_GB (default 5) available it stops the largest writer scope in $TEAM_SLICE (TERM, then stop after 10 s);
# it takes a lead scope only when no writer scope is left. It never touches anything outside the slice.
set -u
self=$(realpath "$0"); . "$(dirname "$self")/../team.env"
unit=${TEAM_SLICE%.slice}-memwatch
case ${1:-} in
  start) systemctl --user show-environment >/dev/null 2>&1 || { echo "memwatch: no systemd user manager; not started" >&2; exit 1; }
         systemctl --user is-active -q "$unit" && { echo "memwatch: $unit already running"; exit 0; }
         exec systemd-run --user --unit="$unit" --collect --quiet "$self" run ;;
  stop)  exec systemctl --user stop "$unit" ;;
  status) systemctl --user is-active "$unit"; tail -3 "$TEAM_RD/logs/memwatch.log" 2>/dev/null; exit 0 ;;
  run) ;;
  *) sed -n 2,3p "$self"; exit 2 ;;
esac
LOG=$TEAM_RD/logs/memwatch.log; WARN_GB=${WARN_GB:-12}; KILL_GB=${KILL_GB:-5}; i=0
while true; do
  # Ask systemd for the path each tick: a hyphen in a slice name nests it (agentbus-RUN.slice lives under
  # agentbus.slice), and a slice with no scopes yet has no cgroup (empty answer) until the lead starts.
  cgp=$(systemctl --user show -p ControlGroup --value "$TEAM_SLICE" 2>/dev/null); cg=/sys/fs/cgroup$cgp
  avail=$(awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo)
  team=$(( $( [ -n "$cgp" ] && cat "$cg/memory.current" 2>/dev/null || echo 0) / 1073741824 ))
  ts=$(date -u +%FT%TZ)
  [ $((i % 4)) -eq 0 ] && echo "$ts avail=${avail}G team=${team}G" >> "$LOG"
  [ "$avail" -lt "$WARN_GB" ] && echo "$ts WARN avail=${avail}G team=${team}G" >> "$LOG"
  if [ $((i % 20)) -eq 0 ] || [ "$avail" -lt "$WARN_GB" ]; then
    ps -eo pid,rss,args --sort=-rss | sed -n 2,6p | awk -v t="$ts" '{printf "%s   top pid=%s rss=%.1fG %s %s %s\n", t, $1, $2/1048576, $3, $4, $5}' >> "$LOG"
  fi
  if [ "$avail" -lt "$KILL_GB" ] && [ -n "$cgp" ]; then
    # Largest scope by memory.current; writer scopes sort before lead scopes.
    victim=$(for s in "$cg"/*.scope; do [ -d "$s" ] || continue; n=${s##*/}; l=1; case $n in lead*) l=0;; esac
               echo "$l $(cat "$s/memory.current" 2>/dev/null || echo 0) $n"; done | sort -k1,1nr -k2,2nr | head -1 | awk '{print $3}')
    if [ -n "$victim" ]; then
      echo "$ts ALERT avail=${avail}G: stopping $victim ($(( $(cat "$cg/$victim/memory.current" 2>/dev/null || echo 0) / 1073741824 ))G)" >> "$LOG"
      systemctl --user kill --signal=TERM "$victim" 2>/dev/null; sleep 10; systemctl --user stop "$victim" 2>/dev/null
    fi
  fi
  i=$((i+1)); sleep 15
done
