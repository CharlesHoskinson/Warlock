#!/home/charl/.local/share/uv/tools/scrapling/bin/python
"""Capture one web source with Scrapling (StealthyFetcher; solves Cloudflare) for the rollup-security wiki.

usage: scrape.py URL OUT_TXT [--pdf OUT_PDF]
  Writes the page's visible text to OUT_TXT (header: URL, status, UTC capture time, SHA-256 of the text) and appends a
  provenance line to SOURCES.jsonl next to OUT_TXT. With --pdf, fetches the URL as a PDF from inside the page (works on
  Cloudflare-protected PDFs such as IACR ePrint) and saves the bytes to OUT_PDF; extract text with `pdftotext OUT_PDF -`.
Never accept a bot-check page as the source: if the text is a challenge page, retry or report it.
"""
import base64, datetime, hashlib, json, sys
from pathlib import Path
from scrapling.fetchers import StealthyFetcher

a = sys.argv[1:]
pdf = None
if '--pdf' in a:
    i = a.index('--pdf'); pdf = Path(a[i + 1]); del a[i:i + 2]
url, out = a[0], Path(a[1])
out.parent.mkdir(parents=True, exist_ok=True)
now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
grab = {}

def page_action(page):
    if pdf:
        grab['b64'] = page.evaluate("""async () => { const r = await fetch(location.href, {credentials: 'include'});
          const b = new Uint8Array(await r.arrayBuffer()); let s = ''; for (const x of b) s += String.fromCharCode(x); return btoa(s); }""")
    return page

p = StealthyFetcher.fetch(url, headless=True, network_idle=True, solve_cloudflare=True, timeout=90000, page_action=page_action)
rec = {'url': url, 'status': p.status, 'utc': now}
if pdf:
    data = base64.b64decode(grab.get('b64', ''))
    pdf.parent.mkdir(parents=True, exist_ok=True); pdf.write_bytes(data)
    rec.update(pdf=str(pdf), pdf_bytes=len(data), pdf_sha256=hashlib.sha256(data).hexdigest(), is_pdf=data[:4] == b'%PDF')
text = p.get_all_text(ignore_tags=('script', 'style', 'nav', 'footer'))
sha = hashlib.sha256(text.encode()).hexdigest()
out.write_text(f"URL: {url}\nSTATUS: {p.status}\nCAPTURED_UTC: {now}\nSHA256: {sha}\n\n{text}")
rec.update(text=str(out), chars=len(text), sha256=sha)
with open(out.parent / 'SOURCES.jsonl', 'a') as f:
    f.write(json.dumps(rec) + '\n')
print(json.dumps(rec))
