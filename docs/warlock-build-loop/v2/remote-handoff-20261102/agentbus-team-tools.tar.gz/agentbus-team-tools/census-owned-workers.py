#!/usr/bin/env python3
"""Read only exact known worker sessions; never print full command lines."""
import datetime,json
from pathlib import Path
RD=Path('/home/charl/.local/state/warlock-team/20261031-agentbus')
IDS={'01a1947b-90de-77f3-a397-9f25730af6e0':'ux-performance','01a1947b-90dd-7ac0-9b96-477ca1e32bc2':'sol-advisor','01a195dd-b85b-7231-80c7-a93921f30012':'terra-engine','01a195ca-d7c3-70b0-9283-fee7913cd88c':'terra-portable','01a195ca-d7be-7cd0-99b4-125eca0496fb':'terra-vm','01a195dc-4f37-76f2-9441-a67e9190403d':'terra-graph','01a195ca-d7cc-7782-9e27-bde14d2937ee':'terra-security','01a195ca-d7cc-7703-93e5-f3a7388fc7bc':'terra-q-origin','01a195ca-d7cc-77e3-abcc-1e4dcf58e65f':'terra-q-lifetime','01a195ca-d7be-72f1-b65d-ca847b49283c':'terra-q-network','01a195ca-d7cc-7e73-a105-436e9bc489f2':'terra-q-http','01a195ca-d7cc-7f52-86a8-2eb9f961129a':'terra-q-front','64b28e71-883e-4b82-82bf-5f79b76b9193':'gemini-site','cfb3d737-e56e-4738-beec-0af3b62a847b':'gemini-gui','34602e6d-0ef7-45b6-baa5-2dc5a5ddd760':'gemini-omarchy'}
# Fresh conversations have no session ID in their initial CLI arguments. Match
# only a pinned, still-live launch wrapper's exact process ancestry in that case.
fresh={}
for launch in json.loads((RD/'live-continuity-codex-launches.json').read_text()):
 if launch.get('sessionId'):IDS[launch['sessionId']]=launch['name']
 if not launch.get('freshIndependentGuiTask') or not launch.get('wrapperStartTicks'):continue
 try:
  fields=Path('/proc/'+str(launch['pid'])+'/stat').read_text().rsplit(')',1)[1].split()
  if fields[19]==launch['wrapperStartTicks']:fresh[launch['pid']]=launch['name']
 except (OSError,IndexError):pass
rows=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  argv=(proc/'cmdline').read_bytes().decode().split('\0');cli=Path(argv[0]).name
  if cli not in ('codex','agy'):continue
  matched=False
  for sid,name in IDS.items():
   if sid not in argv:continue
   model=argv[argv.index('-m')+1] if '-m' in argv else (argv[argv.index('--model')+1] if '--model' in argv else None)
   rows.append(dict(name=name,pid=int(proc.name),cli=cli,model=model,explicitSkipPermissions='--dangerously-skip-permissions' in argv))
   matched=True
  if not matched and cli=='codex' and 'exec' in argv and '-m' in argv and argv[argv.index('-m')+1]=='gpt-6.1-terra' and '-s' in argv and argv[argv.index('-s')+1]=='workspace-write':
   parent=int(proc.name)
   for _ in range(32):
    if parent in fresh:
     rows.append(dict(name=fresh[parent],pid=int(proc.name),cli=cli,model='gpt-6.1-terra',explicitSkipPermissions='--dangerously-skip-permissions' in argv))
     break
    if parent<=1:break
    fields=Path('/proc/'+str(parent)+'/stat').read_text().rsplit(')',1)[1].split()
    parent=int(fields[1])
 except (OSError,UnicodeError,IndexError):pass
counts={name:sum(row['name']==name for row in rows) for name in IDS.values()}
packet=dict(observedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),workers=rows,count=len(rows),duplicates=[name for name,n in counts.items() if n>1],absent=[name for name,n in counts.items() if not n])
(RD/'current-worker-census.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps(packet,indent=2))
