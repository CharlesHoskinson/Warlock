{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
-- Root-only source fixture for terra-engine-lexical-ingress-integration.patch.
-- Build against patched protocol private src, not the public facade. Untested.
-- Actual AF_UNIX + SCM from this process; mock wake/credential guard is not
-- selected-child, pidfd, native, provider cleanup or acceptance evidence.
module Main (main) where

import Control.Concurrent.MVar
import Control.Exception (mask_)
import Control.Monad (unless)
import Data.IORef
import qualified Data.ByteString as B
import GHC.Conc (STM, TVar, atomically, newTVarIO, readTVar, retry, writeTVar)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Posix.Process (getProcessID)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import qualified Warlock.Protocol.CredentialIngress as Public
import Warlock.Protocol.Ingress.Internal
import qualified Warlock.Protocol.PeerCredential as Peer
import qualified Warlock.Protocol.Framing as Framing
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))

data Wake = Stop | Death deriving (Eq,Show)
data Refusal = Revoked | Foreign deriving (Eq,Show)
data Retained = Retained (IORef (Maybe CredentialIngress)) (IORef (Maybe (S.Socket,S.Socket)))
type Registry = IORef [Retained]
data Fixture = Fixture CredentialIngress S.Socket (IORef Int) (TVar (Maybe Wake)) (CredentialGuard Refusal)

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError name))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label operation = timeout 8000000 operation >>= maybe (ioError (userError label)) pure
wakeSTM :: TVar (Maybe Wake) -> STM Wake
wakeSTM v = readTVar v >>= maybe retry pure

-- Empty retention cells precede resource acquisition; exceptions do not trigger
-- a blind close. Registry is test-local, not a durable quarantine receipt.
fixture :: Registry -> IO Fixture
fixture registry = mask_ $ do
 ownerCell <- newIORef Nothing
 sockets <- newIORef Nothing
 atomicModifyIORef' registry (\xs -> (Retained ownerCell sockets:xs,()))
 owner <- must (ingressBinding "1" "2" "3")
 pid <- toInteger <$> getProcessID
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 calls <- newIORef 0
 wake <- newTVarIO Nothing
 let verify c = Peer.credentialPid c == pid && Peer.credentialUid c == uid && Peer.credentialGid c == gid
     guard = CredentialGuard
      (\credential -> do
        stopped <- atomically (readTVar wake)
        pure (if stopped /= Nothing then Left Revoked else if verify credential then Right () else Left Foreign))
      (\credential action -> do
        stopped <- atomically (readTVar wake)
        if stopped /= Nothing then pure (Left Revoked)
         else if verify credential then Right <$> action else pure (Left Foreign))
     callback _ = modifyIORef' calls (+1)
 ingress <- newDesktopCredentialIngress owner FromElm callback callback
 writeIORef ownerCell (Just ingress)
 (owned,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 writeIORef sockets (Just (owned,peer))
 offered <- transferCredentialSocket ingress owned
 check "offer" (offered == OfferAccepted)
 active <- activateCredentialIngress ingress
 check "activation" (active == ActivationLive)
 pure (Fixture ingress peer calls wake guard)

-- Literal independently authored checked desktop request; binding and ids match
-- the declared fixture, no runtime output is captured as an expected value.
frame :: B.ByteString -> IO B.ByteString
frame req = must $ Framing.desktopCommitPrefix $
 "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"QA\",\"bar\":[{\"id\":\"qa:focus-valid\",\"domId\":\"focus-valid\",\"label\":\"QA control\",\"ariaLabel\":\"QA control\",\"detail\":\"\",\"enabled\":true,\"focusOnly\":false}],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"" <> req <> "\"}],\"focus\":[]}"

cleanFixture :: Fixture -> IO ()
cleanFixture (Fixture ingress peer _ _ _) = do
 result <- retireCredentialIngress ingress
 check "confirmed normal retirement" (endpoint result == Just EndpointConfirmed)
 S.close peer

main :: IO ()
main = do
 registry <- newIORef []
 first <- frame "7"
 second <- frame "8"
 -- Real positive first and subsequent persistent routes, exact callback count.
 good@(Fixture ingress peer calls wake guard) <- fixture registry
 N.sendAll peer first
 a <- within "first frame" (receivePersistentCredentialIngress False (wakeSTM wake) ingress (const guard))
 N.sendAll peer second
 b <- within "second frame" (receivePersistentCredentialIngress True (wakeSTM wake) ingress (const guard))
 n <- readIORef calls
 check "two real checked frames" (a == PersistentOutcome CredentialDelivered && b == PersistentOutcome CredentialDelivered && n == 2)
 cleanFixture good

 -- Prelatched stop/death must win even with a valid frame already buffered.
 mapM_ (\reason -> do
  f@(Fixture incoming sender callbacks signal g) <- fixture registry
  atomically (writeTVar signal (Just reason))
  N.sendAll sender first
  observed <- within "prelatched owner wake" (receivePersistentCredentialIngress True (wakeSTM signal) incoming (const g))
  count <- readIORef callbacks
  check "wake is not delivery" (observed == PersistentOwnerWake reason && count == 0)
  -- Deliberately permissive fixture guard isolates the actual retired gate:
  -- a later legacy ingress cannot invoke the handler with the buffered frame.
  let permissive = CredentialGuard (\_ -> pure (Right ())) (\_ action -> Right <$> action) :: CredentialGuard Refusal
  stale <- within "gate remains retired" (receiveCredentialIngress incoming permissive)
  afterStale <- readIORef callbacks
  check "no post-wake legacy callback" (stale == CredentialRejected GateRetired && afterStale == 0)
  cleanFixture f) [Stop,Death]

 -- A real first header fragment passes the mock credential guard, which then
 -- latches stop/death. With the remaining bytes absent recvmsg reaches EAGAIN;
 -- the owned inner wait must wake, unregister, retire the gate and dispatch no
 -- callback. No timing sleep and no selected-child or pidfd claim.
 mapM_ (\reason -> do
  f@(Fixture incoming sender callbacks signal baseGuard) <- fixture registry
  let midGuard _ = CredentialGuard
       (\credential -> do
        accepted <- checkFragment baseGuard credential
        case accepted of Right () -> atomically (writeTVar signal (Just reason)); Left _ -> pure ()
        pure accepted)
       (withCredentialAdmission baseGuard)
  N.sendAll sender (B.take 2 first)
  observed <- within "mid-frame owner wake" (receivePersistentCredentialIngress False (wakeSTM signal) incoming midGuard)
  count <- readIORef callbacks
  check "mid-frame wake prevents callback" (observed == PersistentInterruptedFrame reason && count == 0)
  cleanFixture f) [Stop,Death]

 -- Every fragment and final admission must receive the SAME opaque frame D.
 -- This observes the production factory/guard path, not a hard wall-clock bound.
 bound@(Fixture boundIngress boundPeer boundCalls boundWake baseGuard) <- fixture registry
 tokens <- newIORef []
 let factory deadline = CredentialGuard
      (\credential -> do
       modifyIORef' tokens (Public.frameDeadlineNs deadline :)
       checkFragment baseGuard credential)
      (\credential action -> do
       modifyIORef' tokens (Public.frameDeadlineNs deadline :)
       withCredentialAdmission baseGuard credential action)
 N.sendAll boundPeer first
 observed <- within "frame D" (receivePersistentCredentialIngress True (wakeSTM boundWake) boundIngress factory)
 seen <- readIORef tokens
 boundCount <- readIORef boundCalls
 check "same frame deadline fragments and admission" (observed == PersistentOutcome CredentialDelivered && boundCount == 1 && length seen >= 3 && all (== head seen) seen)
 cleanFixture bound

 -- EOF fails the frame under the pin; the owned path must release that pin
 -- and unregister before invoking the exact shared socket closer.
 eofFixture@(Fixture eofIngress eofPeer eofCalls eofWake eofGuard) <- fixture registry
 N.sendAll eofPeer first
 seeded <- within "EOF seed" (receivePersistentCredentialIngress False (wakeSTM eofWake) eofIngress (const eofGuard))
 S.shutdown eofPeer S.ShutdownSend
 ended <- within "EOF frame" (receivePersistentCredentialIngress True (wakeSTM eofWake) eofIngress (const eofGuard))
 (status,_) <- credentialIngressStatus eofIngress
 nEof <- readIORef eofCalls
 check "EOF closes after read pin" (seeded == PersistentOutcome CredentialDelivered && nEof == 1 &&
  case ended of PersistentOutcome (CredentialFrameRejected _) -> endpoint status == Just EndpointConfirmed; _ -> False)
 cleanFixture eofFixture
 held <- readIORef registry
 check "fixtures retained" (length held == 7)
 putStrLn "persistent ingress source controls completed"
