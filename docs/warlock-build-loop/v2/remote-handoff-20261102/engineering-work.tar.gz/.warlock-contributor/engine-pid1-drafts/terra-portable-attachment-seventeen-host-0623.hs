{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, SOURCE ONLY, UNEXECUTED. One isolated owner and guardian per case.
-- Observer timeouts do not cancel actor, storage, or retirement actions.
module PortableAttachmentSeventeen0623
 (Case, newCase, runCase, retainedWorkers, actorResult) where
import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException, SomeException, fromException, mask, throwIO, try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import Data.List (nub)
import System.Directory (doesFileExist, removeFile)
import System.Exit (ExitCode(ExitSuccess))
import System.FilePath (isAbsolute, normalise)
import System.IO.Error (isDoesNotExistError)
import System.Posix.Files (getSymbolicLinkStatus, isRegularFile)
import System.Timeout (timeout)
import Warlock.Backend
 (PersistentBackendOwner, PersistentBackendRun, PersistentDelivery(..), runPersistentBackend,
  persistentBackendCounts, persistentBackendDelivery, persistentBackendLeaderExit,
  qaBackendCounts, qaRejectedFrames)
import Warlock.Backend.PinStore (PinStore, readPins)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import qualified Warlock.Capture.Process.Persistent as Persistent
import Warlock.Protocol.CredentialIngress (PersistentSendResult(WrittenLocally))
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (parseCounter)

type Result a = Either SomeException a
data Case = Case PersistentBackendOwner PinStore (IORef Bool) (IORef [ThreadId])
 (IORef [MVar (Result ())]) (IORef (Maybe (MVar (Result PersistentBackendRun))))
newCase :: PersistentBackendOwner -> PinStore -> IO Case
newCase owner pins = Case owner pins <$> newIORef False <*> newIORef [] <*> newIORef [] <*> newIORef Nothing
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ workers _ _) = readIORef workers
actorResult :: Case -> IO (Maybe (Result PersistentBackendRun))
actorResult (Case _ _ _ _ _ cell) = readIORef cell >>= maybe (pure Nothing) tryReadMVar
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("attachment-17: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
launch :: IORef [ThreadId] -> (MVar (Result a) -> IO ()) -> IO a -> IO (MVar (Result a))
launch workers retain action = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 retain done
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (readMVar start >> action))
  putMVar done result
  case result of
   Left e -> case fromException e :: Maybe SomeAsyncException of
    Just _ -> throwIO e
    Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()
 pure done
await :: AdmissionDeadline -> String -> MVar a -> IO a
await deadline label done = do
 left <- remainingMicros deadline
 check (label ++ ": original D expired; retain owner and guardian") (left > 0)
 receipt <- timeout left (readMVar done)
 case receipt of
  Nothing -> ioError (userError (label ++ ": Unknown; retain owner and guardian"))
  Just value -> do
   remainingMicros deadline >>= check (label ++ ": result after original D") . (>0)
   pure value
step :: Case -> AdmissionDeadline -> String -> IO () -> IO ()
step (Case _ _ _ workers tasks _) deadline label action = do
 done <- launch workers (\c -> atomicModifyIORef' tasks (\xs -> (c:xs,()))) $ do
  remainingMicros deadline >>= check (label ++ ": before original D") . (>0)
  action
 await deadline label done >>= either throwIO pure
waitReceipt :: AdmissionDeadline -> FilePath -> IO ()
waitReceipt deadline path = do
 left <- remainingMicros deadline
 check "original D waiting for peer receipt" (left > 0)
 exists <- doesFileExist path
 if exists then B.readFile path >>= check "literal complete peer receipt" . (== "attached-then-ids-1-through-16-observed\n")
 else threadDelay (min left 1000) >> waitReceipt deadline path

-- Root creates a fresh private directory with no aliases through parents,
-- validates exact selected peer SHA f9d33582285b1c8299dd7e4aaa13d3c0a1474d5f21c6c1233bde7eabf8fdac23,
-- a single alpha.desktop (Name=Alpha, Exec=/bin/true), empty fresh pins,
-- binding 1/2/3, attachment enabled, SCM credentials, and real startup D.
-- The configured same owner and original start/stop budgets are retained by
-- Root's external guardian. receipt/pending do not exist; exitTrigger is a
-- pre-existing regular marker. Fixture alone does not establish those facts.
runCase :: Case -> AdmissionDeadline -> FilePath -> FilePath -> IO ()
runCase c@(Case owner pins used workers _ actorCell) deadline receipt exitTrigger = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 let paths = map normalise [receipt, receipt ++ ".pending", exitTrigger]
 check "single fresh case and distinct absolute marker paths"
  (fresh && all isAbsolute paths && length (nub paths) == length paths)
 restore $ do
  step c deadline "private marker preconditions" $ do
   status <- getSymbolicLinkStatus exitTrigger
   check "exit trigger is regular and not a symlink" (isRegularFile status)
   let absent path = do
        found <- try (getSymbolicLinkStatus path)
        case found of
         Left e | isDoesNotExistError e -> pure ()
                | otherwise -> throwIO e
         Right _ -> ioError (userError "receipt path already exists")
   mapM_ absent [receipt,receipt ++ ".pending"]
  one <- need (parseCounter False "1")
  let checkPins = do
       snapshot <- readPins pins >>= need
       check "fresh exact pin snapshot" (D.pinRevision snapshot == one && D.pinIdentities snapshot == [])
  step c deadline "pre-frame pin snapshot" checkPins
  rejected <- qaRejectedFrames
  check "fresh rejection observer" (rejected == 0)
  done <- launch workers (writeIORef actorCell . Just) $ do
   remainingMicros deadline >>= check "actor entry before original D" . (>0)
   runPersistentBackend owner
  step c deadline "17 actual replies at selected child" (waitReceipt deadline receipt)
  step c deadline "actual owner counts and pin state" $ do
   counts <- qaBackendCounts owner
   n <- qaRejectedFrames
   delivery <- persistentBackendDelivery owner
   check "one frame, sixteen domain callbacks and no rejection"
    (counts == (1,16) && n == 0 && delivery == DeliveryCompleted WrittenLocally)
   checkPins
  step c deadline "allow selected child to exit" (removeFile exitTrigger)
  observed <- await deadline "actor result" done >>= either throwIO pure
  check "completed run retains exact counts" (persistentBackendCounts observed == (1,16))
  exit <- persistentBackendLeaderExit owner
  check "same selected child exited successfully" (exit == Persistent.LeaderExitObserved ExitSuccess)
  step c deadline "post-frame pin snapshot" checkPins
-- No receipt here proves no later output, native effects, provider cleanup,
-- physical input or whole-scenario acceptance. Unknown is retained, not replayed.
