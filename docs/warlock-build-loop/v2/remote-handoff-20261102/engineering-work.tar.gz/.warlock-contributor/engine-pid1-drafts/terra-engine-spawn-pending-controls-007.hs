{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Requires QA seam007 and WARLOCK_OWNER_QA.
-- The caller supplies an owned child executable, input handle, and an existing
-- external guardian, and strongly roots Probe in the same live host throughout.
-- The injected failure deliberately retains a spawned child and pipe handles;
-- it proves neither a reap nor any provider/namespace cleanup.
module SpawnPendingControls (Probe,newProbe,runRecordedFault,runRecordedPositive) where
import Control.Concurrent (ThreadId,forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException,finally,mask,mask_)
import Control.Monad (unless,void)
import Data.IORef
import System.IO (Handle)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..),SessionObservation,ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),SessionExit(..),newPersistentOwner,persistentStatus,
  persistentUnderlyingStatus,startBudgetAfter,stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (persistentFixture,withPersistentOwnerHook,qaPersistentSpawnPending)

type Result = Either SomeException (Either SessionExit ((),SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe Handle)) (IORef (Maybe ThreadId))
 (MVar Bool) (MVar Result) (IORef (Maybe Bool)) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label value = unless value (ioError (userError ("spawn pending: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
runRecordedFault,runRecordedPositive :: Probe -> FilePath -> [String] -> Handle -> IO ()
runRecordedFault = run True
runRecordedPositive = run False
run :: Bool -> Probe -> FilePath -> [String] -> Handle -> IO ()
run inject (Probe owner handleCell worker decision done observed marks used) exe args input = mask $ \restore -> do
 first <- atomicModifyIORef' used (\was -> (True,not was))
 check "single use" first
 writeIORef handleCell (Just input)
 let hook label = case label of
      "qa-spawn-handle-recorded" -> do
       value <- qaPersistentSpawnPending owner
       writeIORef observed value
       modifyIORef' marks (+1)
       if inject then ioError (userError "injected after real handle record") else pure ()
      "qa-spawn-child-published" -> modifyIORef' marks (+10)
      _ -> pure ()
     finish = do
      mtid <- readIORef worker
      case mtid of Nothing -> pure (); Just _ -> void (tryPutMVar decision False) >> void (timeout 3000000 (readMVar done))
     body = do
      start <- startBudgetAfter 4000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (do
        allowed <- readMVar decision
        if allowed then restore (withPersistentOwnerHook owner (persistentFixture exe args input) 4096 start stop
         (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)
        else ioError (userError "not admitted")) (putMVar done)
       writeIORef worker (Just tid)
       putMVar decision True
       pure tid
      result <- within "startup result" (readMVar done)
      snapshot <- readIORef observed
      count <- readIORef marks
      check "real returned process handle recorded before child metadata" (snapshot == Just True)
      if inject then do
       retained <- qaPersistentSpawnPending owner
       status <- within "owner phase" (persistentStatus owner)
       raw <- within "raw owner" (persistentUnderlyingStatus owner)
       check "failed publication retains Pending and reports unknown" $
        count == 1 && retained == Just True && (case status of PersistentQuarantined _ -> True; _ -> False) &&
        (case raw of Quarantined _ -> True; _ -> False) &&
        (case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False)
      else check "normal publication continues after the real record" $
       count == 11 && (case result of Right _ -> True; Left _ -> False)
 restore body `finally` finish
