{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. One Case per independently guarded process. The host
-- retains Case, workers, real fd owners and a guardian on EVERY exit. The
-- driver must run the actual owner lifecycle; it cannot assign phase or D.
module QHttpRootFinishGate029 (Mode(..),Case,newCase,releaseHolder,runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),StopBudget,StopReceipt(..),StopDeadlineObservation(..),
  newPersistentOwner,newPersistentRootCustody,closePersistentRootPart,persistentStatus,
  requestSessionStop,tryPersistentStopDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaRootFinishHook,qaHoldActualGate,qaActualGateActive)
import Warlock.Platform.Resolver (Identity(..),RootCustody,RootPart(..),RootStepResult(..),withRetainedRoot)
import Warlock.Platform.Resolver.Internal (QaRootSlot(..),qaRootSlots)

data Mode = HeldPublishedGate | ExpireBeforeConfirmation | NormalConfirmation deriving (Eq,Show)
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool)
 (MVar ()) (MVar ()) (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException (Either ToolError RootStepResult)))
 (MVar (Either SomeException ())) (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId))
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef Nothing
releaseHolder :: Case -> IO ()
releaseHolder (Case _ _ _ _ _ _ release _ _ _ _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
identity :: IO Identity
identity = do
 s <- getFileStatus "/"
 pure (Identity (toInteger (deviceID s)) (toInteger (fileID s)))
runCase :: Case -> Mode -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runCase c@(Case owner rootCell used closeStart published held release holderStart closeDone holderDone closeWorker holderWorker) mode startD stopBudget drive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 remainingMicros startD >>= check "original startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef rootCell (Just root)
 expected <- identity
 result <- restore $ within "actual root lifecycle" $ withRetainedRoot root "/" expected $ \_ -> do
  within "actual production owner lifecycle" (drive owner)
  phase <- within "owner phase" (persistentStatus owner)
  check "actual owner retired" (phase==PersistentRetired)
 check "actual root and proc acquired" (result==Right ())
 stopped <- within "first stop" (requestSessionStop owner stopBudget)
 first <- tryPersistentStopDeadline owner
 deadline <- case first of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "missing actual stop D")
 check "retained root makes stop uncertain" (stopped==StopUncertain CleanupUncertain)
 let waitExpired = do
      left <- remainingMicros deadline
      if left<=0 then pure () else threadDelay (min left 10000) >> waitExpired
     hook stage = case (mode,stage) of
      (HeldPublishedGate,"published-before-reacquire") -> putMVar published () >> readMVar held
      (ExpireBeforeConfirmation,"before-deadline-resample") -> waitExpired
      _ -> pure ()
 qaRootFinishHook hook
 holderTid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try (unmask (readMVar holderStart >> qaHoldActualGate owner (putMVar held ()) (readMVar release)))
  putMVar holderDone outcome
 writeIORef holderWorker (Just holderTid)
 closeTid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try (unmask (readMVar closeStart >> closePersistentRootPart owner RootAnchor))
  putMVar closeDone outcome
 writeIORef closeWorker (Just closeTid)
 putMVar closeStart ()
 restore $ do
  case mode of
   HeldPublishedGate -> do
    within "gate published" (readMVar published)
    putMVar holderStart ()
    within "actual gate held" (readMVar held)
   ExpireBeforeConfirmation -> pure ()
   NormalConfirmation -> pure ()
  receipt <- within "close returns" (readMVar closeDone) >>= either throwIO pure
  during <- qaActualGateActive owner
  slots <- qaRootSlots root
  check "physical slot and confirmation outcome match selected case" $
   slots==(QaSlotClosed,QaSlotOpen) &&
   (case mode of
    HeldPublishedGate -> receipt==Left CleanupUncertain && during==Nothing
    ExpireBeforeConfirmation -> receipt==Left CleanupUncertain && during==Just 0
    NormalConfirmation -> receipt==Right RootStepClosed && during==Just 0)
  case mode of
   HeldPublishedGate -> do
    duplicateWhileHeld <- within "no stale insertion while holder owns gate" (closePersistentRootPart owner RootAnchor)
    check "busy gate rejects duplicate" (duplicateWhileHeld==Left OwnerBusy)
    releaseHolder c
    holder <- within "holder returns original gate" (readMVar holderDone)
    either throwIO pure holder
   _ -> do
    -- The unused holder is cancelled by its own already-published start and
    -- release, without guessing fds or changing a product deadline.
    putMVar holderStart ()
    releaseHolder c
    holder <- within "unused holder exits" (readMVar holderDone)
    either throwIO pure holder
  after <- qaActualGateActive owner
  again <- within "part not replayed" (closePersistentRootPart owner RootAnchor)
  lastD <- tryPersistentStopDeadline owner
  check "same gate, same D, entered part refuses replay" $
   after==Just 0 && lastD==first &&
   (case mode of HeldPublishedGate -> again==Left OwnerBusy; ExpireBeforeConfirmation -> again==Left TimedOut; NormalConfirmation -> again==Left OwnerBusy)
