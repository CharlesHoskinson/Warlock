'use strict';

/*
 * Independent ELM-TEA-004 (tea-subscriptions) literal oracle for the 9th
 * Browser.element root (`0710` scoped pre-flush message + exact-target Html
 * focusin decoder controls, NOT a general no-focus-steal proof):
 *   site/src/SiteMain.elm + site/src/SiteBetaStatus.elm
 *
 * Exercises `SiteMain.pendingFocusInDecoder` directly via `dispatch-focusin`
 * with raw DOM-shaped JSON events:
 *   - queued tab A + plain un-ID'd `{ target: {} }` + Flush -> no focus
 *   - queued tab A (`wl-tab-snap`) + OTHER tab B (`wl-tab-files`) + Flush -> no focus
 *   - queued tab A (`wl-tab-files`) + SAME tab A (`wl-tab-files`) + Flush -> FocusSpotlightTab
 *   - queued mobile toggle + non-target (`wl-tab-launcher`) + Flush -> no focus
 *   - queued mobile toggle + exact (`wl-home-nav-toggle`) + Flush -> FocusMobileNavToggle
 */

const empty = () => ({ $: '[]' });
const list = items => {
  let out = empty();
  for (let i = items.length - 1; i >= 0; i--) {
    out = { $: '::', a: items[i], b: out };
  }
  return out;
};
const none = () => ({ $: 'Nothing' });
const just = value => ({ $: 'Just', a: value });
const tag = name => ({ $: name });

function equalLiteral(left, right) {
  if (Object.is(left, right)) return true;
  if (typeof left !== typeof right || left === null || right === null ||
      typeof left !== 'object' || Array.isArray(left) !== Array.isArray(right)) return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every((key, i) =>
    key === rightKeys[i] && equalLiteral(left[key], right[key]));
}

function cloneLiteral(value) {
  if (value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(cloneLiteral);
  const copy = {};
  for (const key of Object.keys(value).sort()) copy[key] = cloneLiteral(value[key]);
  return copy;
}

function literalPatches(given, patches) {
  const result = cloneLiteral(given);
  for (const change of patches) {
    let cursor = result;
    for (let i = 0; i < change.path.length - 1; i++) cursor = cursor[change.path[i]];
    const leaf = change.path[change.path.length - 1];
    if (!equalLiteral(cursor[leaf], change.before)) {
      throw new Error('unexpected literal before at ' + change.path.join('.'));
    }
    if (equalLiteral(change.before, change.after)) {
      throw new Error('noop literal change at ' + change.path.join('.'));
    }
    cursor[leaf] = cloneLiteral(change.after);
  }
  return result;
}

const betaState = (filter, mvpTrack, focusSeq, lastFocusMiss) => ({
  $: 'State',
  a: {
    filter: tag(filter),
    focusSeq,
    lastFocusMiss,
    mvpTrack: tag(mvpTrack),
  },
});

const pendingTab = (seq, surface) => ({ $: 'PendingSpotlightTab', a: seq, b: tag(surface) });
const pendingMobileToggle = seq => ({ $: 'PendingMobileNavToggle', a: seq });

const initialSiteState = () => ({
  model: {
    betaStatus: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
    category: tag('CategoryAll'),
    cues: {
      activeApplication: true,
      switcherCandidate: false,
      windowFocused: true,
    },
    lastTabFocusMiss: none(),
    mobileNavOpen: false,
    motion: tag('MotionStandard'),
    outcomeSample: tag('SampleObserved'),
    pendingFocus: none(),
    spotlight: tag('SurfaceTaskbar'),
    tabFocusSeq: 0,
    theme: tag('ThemeNight'),
  },
  subscriptions: empty(),
});

const siteEffects = items => ({ $: 'SiteStepEffects', a: list(items) });
const focusTabEffect = (seq, surface) => ({ $: 'FocusSpotlightTab', a: seq, b: tag(surface) });
const focusMobileToggleEffect = seq => ({ $: 'FocusMobileNavToggle', a: seq });
const betaFilterEffect = (seq, filter) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusFilterTab', a: seq, b: tag(filter) },
});
const betaMvpEffect = (seq, track) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusMvpTab', a: seq, b: tag(track) },
});

function buildPreFlushMessageAndExactFocusInDecoderCase() {
  const s0 = initialSiteState();
  // 1. ArrowRight: queues PendingSpotlightTab(1, SurfaceLauncher), activates [PendingFocusFrame]
  const s1 = literalPatches(s0, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskbar'), after: tag('SurfaceLauncher') },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(1, 'SurfaceLauncher')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  // 2. Pre-flush StepSpotlight +1 cancels pendingFocus and drops PendingFocusFrame
  const s2 = literalPatches(s1, [
    { path: ['model', 'spotlight'], before: tag('SurfaceLauncher'), after: tag('SurfaceSwitcher') },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(1, 'SurfaceLauncher')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 3. ArrowRight -> SurfaceTaskView (seq 3), then actual decoder on un-ID'd `{ target: {} }` cancels pendingFocus
  const s3 = literalPatches(s2, [
    { path: ['model', 'spotlight'], before: tag('SurfaceSwitcher'), after: tag('SurfaceTaskView') },
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(3, 'SurfaceTaskView')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s4 = literalPatches(s3, [
    { path: ['model', 'tabFocusSeq'], before: 3, after: 4 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(3, 'SurfaceTaskView')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 4. Queued A (`SurfaceSnap` / `wl-tab-snap`) + actual decoder on OTHER tab B (`wl-tab-files`) + Flush -> no focus
  const s5 = literalPatches(s4, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskView'), after: tag('SurfaceSnap') },
    { path: ['model', 'tabFocusSeq'], before: 4, after: 5 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(5, 'SurfaceSnap')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s6 = literalPatches(s5, [
    { path: ['model', 'tabFocusSeq'], before: 5, after: 6 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(5, 'SurfaceSnap')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 5. Queued A (`SurfaceFiles` / `wl-tab-files`) + actual decoder on SAME tab A (`wl-tab-files`) + Flush -> exact FocusSpotlightTab
  const s7 = literalPatches(s6, [
    { path: ['model', 'spotlight'], before: tag('SurfaceSnap'), after: tag('SurfaceNotifications') },
    { path: ['model', 'tabFocusSeq'], before: 6, after: 7 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(7, 'SurfaceNotifications')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s8 = literalPatches(s7, [
    { path: ['model', 'spotlight'], before: tag('SurfaceNotifications'), after: tag('SurfaceFiles') },
    { path: ['model', 'tabFocusSeq'], before: 7, after: 8 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(7, 'SurfaceNotifications')), after: just(pendingTab(8, 'SurfaceFiles')) },
  ]);
  const s9 = literalPatches(s8, [
    { path: ['model', 'pendingFocus'], before: just(pendingTab(8, 'SurfaceFiles')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);

  return {
    name: 'sitemain-preflush-message-and-exact-focusin-decoder-controls',
    worker: 'sitemain',
    given: s0,
    steps: [
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s1, effects: siteEffects([]) } },
      { input: { kind: 'step-spotlight', delta: 1 }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s3, effects: siteEffects([]) } },
      { input: { kind: 'dispatch-focusin', event: { target: {} } }, expected: { state: s4, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s4, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s5, effects: siteEffects([]) } },
      { input: { kind: 'dispatch-focusin', event: { target: { id: 'wl-tab-files' } } }, expected: { state: s6, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s6, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s7, effects: siteEffects([]) } },
      { input: { kind: 'select-spotlight', surface: 'files' }, expected: { state: s8, effects: siteEffects([]) } },
      { input: { kind: 'dispatch-focusin', event: { target: { id: 'wl-tab-files' } } }, expected: { state: s8, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s9, effects: siteEffects([focusTabEffect(8, 'SurfaceFiles')]) } },
    ],
  };
}

function buildMobileNavExactDecoderAndBetaStatusCancellationCase() {
  const s0 = initialSiteState();
  const s1 = literalPatches(s0, [
    { path: ['model', 'mobileNavOpen'], before: false, after: true },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
  ]);
  // 1. Escape queues PendingMobileNavToggle(2); non-target focusin (`wl-tab-launcher`) cancels before Flush
  const s2 = literalPatches(s1, [
    { path: ['model', 'mobileNavOpen'], before: true, after: false },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingMobileToggle(2)) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s3 = literalPatches(s2, [
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
    { path: ['model', 'pendingFocus'], before: just(pendingMobileToggle(2)), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 2. Re-open + Escape queues PendingMobileNavToggle(5); exact target focusin (`wl-home-nav-toggle`) preserves pendingFocus for Flush
  const s4 = literalPatches(s3, [
    { path: ['model', 'mobileNavOpen'], before: false, after: true },
    { path: ['model', 'tabFocusSeq'], before: 3, after: 4 },
  ]);
  const s5 = literalPatches(s4, [
    { path: ['model', 'mobileNavOpen'], before: true, after: false },
    { path: ['model', 'tabFocusSeq'], before: 4, after: 5 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingMobileToggle(5)) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s6 = literalPatches(s5, [
    { path: ['model', 'pendingFocus'], before: just(pendingMobileToggle(5)), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  const s7 = literalPatches(s6, [
    { path: ['model', 'lastTabFocusMiss'], before: none(), after: just('wl-home-nav-toggle') },
  ]);
  const s8 = literalPatches(s7, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskbar'), after: tag('SurfaceLauncher') },
    { path: ['model', 'tabFocusSeq'], before: 5, after: 6 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(6, 'SurfaceLauncher')) },
    { path: ['model', 'lastTabFocusMiss'], before: just('wl-home-nav-toggle'), after: none() },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s9 = literalPatches(s8, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
      after: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
    },
    { path: ['model', 'tabFocusSeq'], before: 6, after: 7 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(6, 'SurfaceLauncher')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  const s10 = literalPatches(s9, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
      after: betaState('FilterOpenNativeGates', 'TrackProtectedCpu', 2, none()),
    },
    { path: ['model', 'tabFocusSeq'], before: 7, after: 8 },
  ]);

  return {
    name: 'sitemain-mobile-exact-decoder-and-beta-status-cancels-pending-tab-focus',
    worker: 'sitemain',
    given: s0,
    steps: [
      { input: { kind: 'toggle-mobile-nav' }, expected: { state: s1, effects: siteEffects([]) } },
      { input: { kind: 'escape-mobile-nav' }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'dispatch-focusin', event: { target: { id: 'wl-tab-launcher' } } }, expected: { state: s3, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s3, effects: siteEffects([]) } },
      { input: { kind: 'toggle-mobile-nav' }, expected: { state: s4, effects: siteEffects([]) } },
      { input: { kind: 'escape-mobile-nav' }, expected: { state: s5, effects: siteEffects([]) } },
      { input: { kind: 'dispatch-focusin', event: { target: { id: 'wl-home-nav-toggle' } } }, expected: { state: s5, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s6, effects: siteEffects([focusMobileToggleEffect(5)]) } },
      { input: { kind: 'mobile-nav-focus-settled', seq: 5, missingDomId: 'wl-home-nav-toggle' }, expected: { state: s7, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s8, effects: siteEffects([]) } },
      { input: { kind: 'beta-select-filter', filter: 'native-gates' }, expected: { state: s9, effects: siteEffects([betaFilterEffect(1, 'FilterOpenNativeGates')]) } },
      { input: { kind: 'beta-keyboard-step-mvp', delta: 1 }, expected: { state: s10, effects: siteEffects([betaMvpEffect(2, 'TrackProtectedCpu')]) } },
    ],
  };
}

const SITE_MAIN_CASES = [
  buildPreFlushMessageAndExactFocusInDecoderCase(),
  buildMobileNavExactDecoderAndBetaStatusCancellationCase(),
];

module.exports = {
  SITE_MAIN_CASES,
  initialSiteState,
};
