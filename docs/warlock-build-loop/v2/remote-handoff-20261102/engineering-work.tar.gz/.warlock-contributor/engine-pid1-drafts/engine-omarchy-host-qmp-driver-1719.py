#!/usr/bin/env python3
"""Root-only host QMP physical input driver skeleton for the Omarchy PID-1 UI MVP.

PREPARATION SKELETON ONLY — DO NOT EXECUTE FROM WORKER TURNS.
Root reviews and executes on the host only after protected qualification of the
desktop inter-frame idle fix.

Design & Honesty Invariants (v2 after sol-docs & terra-vm 1719 review):
- Pairs with the UNCHANGED screenshot-only guest controller
  (`live-controller-display-01.py`), reading its live `controller-state.json`,
  `live-current.json`, `backend.json`, and `preservation-before.json` via
  read-only guest probes over `ssh.sh`.
- Zero `/proc/<pid>/environ` reads: display socket targeting uses explicit
  reviewed CLI parameters (`--wayland-display`, optional
  `--hyprland-instance-signature`) validated under `/run/user/<euid>`.
- Strict cgroup & `/proc` census: `os.walk(..., onerror=...)` plus strict
  per-PID `/proc` parsing; any `EACCES`/`EPERM`/walk error or incomplete PID
  census marks `liveCgroupKnown = False` and fails closed.
- Exact scope & baseline pinning: pins exact `warlock-mvp-app-<12hex>.scope`
  unit, `ControlGroup`, `launcherPID`, `deadlineMonotonicNs`, broker `(pid, birth)`,
  PID-1 engine `(pid, birth)`, and requires every baseline client in
  `preservation-before.json` (including `Foot`) to have a matching original AND
  current process record with identical `(pid, birth, device, inode)` and a
  live mapped window.
- Zero hardcoded click coordinates and zero DOM/WebDriver fixture metadata:
  Root captures/views a current guest screenshot and supplies the current
  visible control rectangle (`--hitbox X0 Y0 X1 Y1`).
- Zero compositor IPC mutations (`nativeOperations = []`): never calls
  `hyprctl dispatch` or `omarchy-shell notifications dismissAll`; fails closed
  on focus loss, lock (`pgrep -x hyprlock` strict 0/1 check), geometry drift,
  foreign window overlap, or upper-layer (`top`/`overlay`) surfaces.
- Bounded pre-dispatch budget & QMP JSON verification: validates finite timing
  bounds (`qmp_timeout <= 1.25s`, `hold <= 0.15s`, `min_remaining_seconds >= 8.0s`
  for `click-hitbox` / `send-keys` matching Root's `D8sreserve`), re-checks host
  monotonic remaining budget immediately before each QMP command under stated
  timeout/clock assumptions (not a hard real-time scheduler/QMP guarantee; any
  timeout or late/uncertain completion fails closed), uses two-step intra-hitbox
  QMP `abs` motion so `WebKitWebProcess` processes `wl_pointer.motion` after
  `wl_pointer.enter`, and parses QMP JSON output to reject `{"error": ...}`.
- Printable-only `send-keys` (`a-z`, `0-9`) with mandatory fresh search-click
  receipt witness, `--focus-hitbox`, and upper-layer check; never claims
  `activeWindow` proves Wayland `wl_keyboard` delivery.
- Preserves `EngineResult False False` truth (`ui/Main.hs:75`, `WebKit.hs:498`):
  keeps `providerCleanupQualified = False`, `nativeAccepted = False`, and
  `releaseAccepted = False`.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time
from typing import Any

DEFAULT_VM_BASE = Path("/home/charl/vm/omarchy")
UNIT_NAME_RE = re.compile(r"^warlock-mvp-app-[0-9a-f]{12}\.scope$")
WAYLAND_DISPLAY_RE = re.compile(r"^wayland-[0-9]+$")
HYPR_SIG_RE = re.compile(r"^[A-Za-z0-9_.:-]+$")

# Strictly lowercase ASCII alphanumeric printable QMP key names only for the
# initial safe no-match search journey (`ret`, `tab`, `esc`, `spc`, `slash`,
# `backspace`, and all modifiers/chords are excluded so `send-keys` cannot
# activate a selected app or trigger compositor bindings).
SAFE_QMP_KEYS: frozenset[str] = frozenset("abcdefghijklmnopqrstuvwxyz0123456789")

# Read-only guest probe executed via `ssh.sh 'python3 - <run_dir> <cap> <wl> <sig>'`.
# Never reads `/proc/*/environ`, credentials, or keys; never mutates guest state.
GUEST_PROBE_SCRIPT = r"""
import errno, json, os, re, stat, subprocess, sys, time
from pathlib import Path

run_dir = Path(sys.argv[1])
capture_png = sys.argv[2] == "1"
wayland_display = sys.argv[3]
hypr_sig_arg = sys.argv[4]

if not run_dir.is_absolute() or run_dir.is_symlink():
    raise SystemExit("guest run_dir must be a non-symlink absolute path")
for anc in [run_dir, *run_dir.parents]:
    if anc.is_symlink():
        raise SystemExit(f"symlink ancestor refused: {anc}")
st_run = run_dir.stat()
euid = os.geteuid()
if not stat.S_ISDIR(st_run.st_mode) or st_run.st_uid != euid or stat.S_IMODE(st_run.st_mode) != 0o700:
    raise SystemExit("guest run_dir must be 0700 owned by effective uid")

runtime_dir = Path(f"/run/user/{euid}")
if runtime_dir.is_symlink() or not runtime_dir.is_dir():
    raise SystemExit(f"invalid XDG_RUNTIME_DIR: {runtime_dir}")
st_rt = runtime_dir.stat()
if st_rt.st_uid != euid or stat.S_IMODE(st_rt.st_mode) != 0o700:
    raise SystemExit(f"XDG_RUNTIME_DIR must be 0700 owned by uid {euid}")

if not re.match(r"^wayland-[0-9]+$", wayland_display):
    raise SystemExit(f"invalid wayland_display name: {wayland_display!r}")
wl_sock = runtime_dir / wayland_display
if wl_sock.is_symlink() or not wl_sock.exists():
    raise SystemExit(f"wayland socket missing or symlink: {wl_sock}")
st_wl = wl_sock.stat()
if st_wl.st_uid != euid or not stat.S_ISSOCK(st_wl.st_mode):
    raise SystemExit(f"wayland path is not an euid-owned socket: {wl_sock}")

hypr_root = runtime_dir / "hypr"
if hypr_root.is_symlink() or not hypr_root.is_dir():
    raise SystemExit(f"hypr runtime dir missing or symlink: {hypr_root}")
if hypr_sig_arg:
    if not re.match(r"^[A-Za-z0-9_.:-]+$", hypr_sig_arg):
        raise SystemExit(f"invalid hyprland signature: {hypr_sig_arg!r}")
    sig_dir = hypr_root / hypr_sig_arg
    if sig_dir.is_symlink() or not sig_dir.is_dir() or sig_dir.stat().st_uid != euid:
        raise SystemExit(f"hyprland signature dir invalid: {sig_dir}")
    hypr_sig = hypr_sig_arg
else:
    candidates = sorted(
        d.name for d in hypr_root.iterdir()
        if not d.is_symlink() and d.is_dir() and d.stat().st_uid == euid
    )
    if len(candidates) != 1:
        raise SystemExit(
            f"expected exactly 1 Hyprland instance in {hypr_root}, found {len(candidates)}; "
            "pass --hyprland-instance-signature explicitly"
        )
    hypr_sig = candidates[0]

def read_json_bounded(path: Path, retries: int = 1) -> dict:
    last_err = None
    for attempt in range(retries):
        try:
            if path.is_symlink():
                raise RuntimeError(f"symlink refused: {path}")
            raw = path.read_text(encoding="utf-8")
            if raw.strip():
                return json.loads(raw)
            last_err = ValueError(f"empty json: {path}")
        except (OSError, ValueError) as exc:
            last_err = exc
        if attempt + 1 < retries:
            time.sleep(0.025)
    raise RuntimeError(f"failed reading {path.name}: {last_err!r}")

def proc_record_strict(pid: int) -> dict:
    p = Path("/proc", str(pid))
    st = p.stat()
    if st.st_uid != euid:
        raise PermissionError(f"foreign uid {st.st_uid} on pid {pid} in owned cgroup")
    raw_stat = (p / "stat").read_text(encoding="utf-8", errors="strict")
    rparen = raw_stat.rfind(")")
    if rparen < 0:
        raise RuntimeError(f"malformed /proc/{pid}/stat")
    fields = raw_stat[rparen + 2 :].split()
    raw_status = (p / "status").read_text(encoding="utf-8", errors="strict")
    nspids = None
    for line in raw_status.splitlines():
        if line.startswith("NSpid:"):
            nspids = [int(v) for v in line.split()[1:]]
            break
    if not nspids:
        raise RuntimeError(f"missing NSpid in /proc/{pid}/status")
    exe_link = p / "exe"
    exe_stat = exe_link.stat()
    exe_name = Path(os.readlink(exe_link)).name
    return {
        "pid": pid,
        "state": fields[0],
        "ppid": int(fields[1]),
        "pgid": int(fields[2]),
        "birth": fields[19],
        "uid": st.st_uid,
        "executable": exe_name,
        "device": exe_stat.st_dev,
        "inode": exe_stat.st_ino,
        "namespacePids": nspids,
    }

controller_state = read_json_bounded(run_dir / "controller-state.json", retries=2)
backend_cfg = read_json_bounded(run_dir / "backend.json", retries=1)
preservation_before = read_json_bounded(run_dir / "preservation-before.json", retries=1)
# `live-controller-display-01.py` rewrites `live-current.json` in place every ~0.2s;
# allow 4 short retries (<=75ms) across transient truncation without masking absence.
live_current = read_json_bounded(run_dir / "live-current.json", retries=4)

env = {
    "PATH": "/usr/local/bin:/usr/bin:/bin",
    "HOME": str(Path.home()),
    "USER": os.environ.get("USER", ""),
    "OMARCHY_PATH": "/usr/share/omarchy",
    "LANG": "C.UTF-8",
    "LC_ALL": "C.UTF-8",
    "XDG_RUNTIME_DIR": str(runtime_dir),
    "WAYLAND_DISPLAY": wayland_display,
    "HYPRLAND_INSTANCE_SIGNATURE": hypr_sig,
}

unit = str(controller_state.get("unit", ""))
sys_show = subprocess.run(
    [
        "systemctl", "--user", "show", unit,
        "--property=ControlGroup", "--property=ActiveState",
        "--property=SubState", "--property=Result",
    ],
    env=env, capture_output=True, text=True, timeout=3, check=True,
)
unit_props = dict(line.split("=", 1) for line in sys_show.stdout.splitlines() if "=" in line)
cgroup_rel = unit_props.get("ControlGroup", "").lstrip("/")

live_cgroup_pids = []
live_cgroup_procs = []
cgroup_known = False
cgroup_error = None
if cgroup_rel:
    cg_path = Path("/sys/fs/cgroup") / cgroup_rel
    for attempt in range(3):
        try:
            if not cg_path.is_dir():
                cgroup_error = f"cgroup directory missing: {cg_path}"
                break
            found = []
            def walk_err(err):
                raise err
            for root, _, files in os.walk(cg_path, onerror=walk_err):
                if "cgroup.procs" not in files:
                    raise RuntimeError(f"cgroup directory missing cgroup.procs: {root}")
                raw_pids = (Path(root) / "cgroup.procs").read_text(encoding="utf-8").split()
                found.extend(int(x) for x in raw_pids)
            pids_sorted = sorted(set(found))
            procs_snapshot = [proc_record_strict(pid) for pid in pids_sorted]
            live_cgroup_pids = pids_sorted
            live_cgroup_procs = procs_snapshot
            cgroup_known = True
            cgroup_error = None
            break
        except (FileNotFoundError, ProcessLookupError) as transient_exc:
            # A short-lived child exited between reading cgroup.procs and /proc/<pid>;
            # retry up to 3 times (<=50ms) for a self-consistent census, else fail closed.
            cgroup_error = f"transient_proc_exit:{transient_exc!r}"
            if attempt + 1 < 3:
                time.sleep(0.025)
        except (OSError, ValueError, RuntimeError) as fatal_exc:
            cgroup_error = f"fatal_cgroup_census:{fatal_exc!r}"
            cgroup_known = False
            break

baseline_proc_checks = []
for bclient in preservation_before.get("clients", []):
    bpid = int(bclient["pid"])
    try:
        cur_rec = proc_record_strict(bpid)
        cur_err = None
    except Exception as exc:
        cur_rec = None
        cur_err = repr(exc)
    baseline_proc_checks.append({"pid": bpid, "current": cur_rec, "error": cur_err})

lock_cmd = subprocess.run(
    ["omarchy-shell", "lock", "isLocked"],
    env=env, capture_output=True, text=True, timeout=2, check=True,
)
lock_text = lock_cmd.stdout.strip()
if lock_text not in ("true", "false"):
    raise RuntimeError(f"unexpected lock output: {lock_text!r}")

pgrep_cp = subprocess.run(
    ["pgrep", "-x", "hyprlock"],
    env=env, capture_output=True, text=True, timeout=2,
)
if pgrep_cp.returncode == 0:
    hyprlock_running = True
elif pgrep_cp.returncode == 1:
    hyprlock_running = False
else:
    raise RuntimeError(
        f"pgrep -x hyprlock failed with exit {pgrep_cp.returncode}: {pgrep_cp.stderr.strip()!r}"
    )

hypr_data = {}
for key, args in (
    ("clients", ["hyprctl", "clients", "-j"]),
    ("activeWindow", ["hyprctl", "activewindow", "-j"]),
    ("monitors", ["hyprctl", "monitors", "-j"]),
    ("layers", ["hyprctl", "layers", "-j"]),
):
    cp = subprocess.run(args, env=env, capture_output=True, text=True, timeout=3, check=True)
    hypr_data[key] = json.loads(cp.stdout)

png_hex = None
if capture_png:
    grim = subprocess.run(["grim", "-"], env=env, capture_output=True, timeout=3, check=True)
    if not grim.stdout.startswith(b"\x89PNG\r\n\x1a\n"):
        raise RuntimeError("grim did not return valid PNG bytes")
    png_hex = grim.stdout.hex()

before_client_pids = {c.get("pid") for c in preservation_before.get("clients", [])}
guest_now = time.monotonic()
print(json.dumps({
    "guestMonotonic": guest_now,
    "euid": euid,
    "waylandDisplay": wayland_display,
    "hyprlandInstanceSignature": hypr_sig,
    "controllerState": controller_state,
    "backendUiPin": backend_cfg.get("ui"),
    "backendDeadlineMonotonicNs": backend_cfg.get("deadlineMonotonicNs"),
    "preservationBeforeClients": preservation_before.get("clients", []),
    "preservationBeforeProcesses": {
        str(r["pid"]): r for r in preservation_before.get("processes", [])
        if r.get("pid") in before_client_pids
    },
    "baselineClientProcsNow": baseline_proc_checks,
    "liveCurrent": live_current,
    "liveUnitProps": unit_props,
    "liveCgroupKnown": cgroup_known,
    "liveCgroupError": cgroup_error,
    "liveCgroupPIDs": live_cgroup_pids,
    "liveCgroupProcs": live_cgroup_procs,
    "locked": (lock_text == "true") or hyprlock_running,
    "hypr": hypr_data,
    "pngHex": png_hex,
}))
"""

GUEST_SUMMARY_SCRIPT = r"""
import json, os, sys
from pathlib import Path

run_dir = Path(sys.argv[1])
if not run_dir.is_absolute() or run_dir.is_symlink():
    raise SystemExit("invalid guest run_dir")

def opt_json(name: str):
    p = run_dir / name
    if not p.exists() or p.is_symlink():
        return None
    raw = p.read_text(encoding="utf-8").strip()
    return json.loads(raw) if raw else None

obs = opt_json("observations.json") or []
first_map_idx = None
last_map_idx = None
for idx, row in enumerate(obs):
    if row.get("visible"):
        if first_map_idx is None:
            first_map_idx = idx
        last_map_idx = idx

continuity = None
if first_map_idx is not None and last_map_idx is not None:
    window_slice = obs[first_map_idx : last_map_idx + 1]
    addresses = {
        c.get("address")
        for r in window_slice
        for c in (r.get("visible") or [])
    }
    engine_sets = [tuple(r.get("eligibleEnginePIDs") or []) for r in window_slice]
    unmapped_gaps = sum(1 for r in window_slice if len(r.get("visible") or []) != 1)
    unknown_scope_rows = sum(
        1 for r in window_slice if not (r.get("scopeState") or {}).get("membershipKnown")
    )
    max_gap_s = 0.0
    for prev_r, next_r in zip(window_slice, window_slice[1:]):
        gap = float(next_r["monotonic"]) - float(prev_r["monotonic"])
        if gap > max_gap_s:
            max_gap_s = gap
    continuity = {
        "firstMappedIndex": first_map_idx,
        "lastMappedIndex": last_map_idx,
        "firstMappedMonotonic": float(obs[first_map_idx]["monotonic"]),
        "lastMappedMonotonic": float(obs[last_map_idx]["monotonic"]),
        "mappedSpanSeconds": float(obs[last_map_idx]["monotonic"]) - float(obs[first_map_idx]["monotonic"]),
        "sampleCountInSpan": len(window_slice),
        "unmappedRowCountInSpan": unmapped_gaps,
        "unknownScopeRowCountInSpan": unknown_scope_rows,
        "distinctWindowAddresses": sorted(a for a in addresses if a),
        "distinctEligibleEngineTuples": [list(t) for t in sorted(set(engine_sets))],
        "maxInterSampleGapSeconds": max_gap_s,
    }

print(json.dumps({
    "trialResult": opt_json("trial-result.json"),
    "backendResult": opt_json("backend.stdout"),
    "backendStderrBytes": (run_dir / "backend.stderr").stat().st_size if (run_dir / "backend.stderr").exists() else None,
    "observationCount": len(obs),
    "observationContinuity": continuity,
    "preservationAfter": opt_json("preservation-after.json"),
    "idleRestoration": opt_json("idle-restoration.json"),
}))
"""


class FenceRefusal(RuntimeError):
    """Fail-closed pre-input, post-motion, or post-release fence failure."""


def require_finite_range(name: str, value: float, lo: float, hi: float) -> float:
    if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
        raise FenceRefusal(f"{name} must be finite, got {value!r}")
    fval = float(value)
    if fval < lo or fval > hi:
        raise FenceRefusal(f"{name}={fval} outside allowed bounds [{lo}, {hi}]")
    return fval


def validate_host_output_path(path: Path) -> None:
    if not path.is_absolute():
        raise FenceRefusal(f"host output path must be absolute: {path}")
    if path.exists() or path.is_symlink():
        raise FenceRefusal(f"refusing existing or symlink output path: {path}")
    for anc in [path.parent, *path.parent.parents]:
        if anc.is_symlink():
            raise FenceRefusal(f"symlink ancestor refused on host output path: {anc}")
        if (anc / ".git").exists():
            raise FenceRefusal(f"refusing host output path inside Git repository: {path}")


def read_host_json_strict(path: Path) -> dict[str, Any]:
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        raise FenceRefusal(f"invalid or symlink host JSON input path: {path}")
    for anc in [path.parent, *path.parent.parents]:
        if anc.is_symlink():
            raise FenceRefusal(f"symlink ancestor refused on host input path: {anc}")
    return json.loads(path.read_text(encoding="utf-8"))


def write_exclusive_json(path: Path, payload: dict[str, Any]) -> None:
    validate_host_output_path(path)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def write_exclusive_bytes(path: Path, data: bytes) -> str:
    validate_host_output_path(path)
    digest = hashlib.sha256(data).hexdigest()
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as handle:
        handle.write(data)
    return digest


def rects_overlap(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def verify_zero_prior_host_inputs(evidence_dir: Path) -> int:
    if not evidence_dir.is_absolute() or evidence_dir.is_symlink() or not evidence_dir.is_dir():
        raise FenceRefusal(f"invalid host evidence_dir: {evidence_dir}")
    checked = 0
    for entry in sorted(evidence_dir.iterdir()):
        if entry.is_symlink():
            raise FenceRefusal(f"symlink inside host evidence_dir refused: {entry}")
        if entry.suffix == ".json" and entry.is_file():
            data = json.loads(entry.read_text(encoding="utf-8"))
            checked += 1
            if data.get("kind") in ("host-qmp-click-hitbox-receipt", "host-qmp-send-keys-receipt"):
                raise FenceRefusal(
                    f"prior host QMP input receipt already exists in {evidence_dir}: {entry.name}"
                )
    return checked


def run_guest_probe(
    vm_base: Path,
    guest_run_dir: str,
    *,
    wayland_display: str,
    hyprland_sig: str | None,
    capture_png: bool = False,
) -> dict[str, Any]:
    if not guest_run_dir.startswith("/") or ".." in Path(guest_run_dir).parts:
        raise FenceRefusal(f"invalid guest_run_dir: {guest_run_dir!r}")
    if not WAYLAND_DISPLAY_RE.match(wayland_display):
        raise FenceRefusal(f"invalid --wayland-display: {wayland_display!r}")
    sig_arg = hyprland_sig or ""
    if sig_arg and not HYPR_SIG_RE.match(sig_arg):
        raise FenceRefusal(f"invalid --hyprland-instance-signature: {sig_arg!r}")

    cmd = (
        f"python3 - {shlex.quote(guest_run_dir)} "
        f"{'1' if capture_png else '0'} "
        f"{shlex.quote(wayland_display)} "
        f"{shlex.quote(sig_arg)}"
    )
    probe_start_host = time.monotonic()
    cp = subprocess.run(
        [str(vm_base / "ssh.sh"), cmd],
        input=GUEST_PROBE_SCRIPT,
        text=True,
        capture_output=True,
        cwd=vm_base,
        timeout=8,
        check=True,
    )
    probe_done_host = time.monotonic()
    rtt = probe_done_host - probe_start_host
    data = json.loads(cp.stdout)
    data["hostRoundTripSeconds"] = rtt
    data["_hostProbeStartMonotonic"] = probe_start_host
    data["_hostProbeDoneMonotonic"] = probe_done_host
    return data


def parse_qmp_helper_line(stripped: str) -> dict[str, Any]:
    """Parse `qmp.py cmd ...` output, which prints Python `repr(dict)` (or JSON)."""
    try:
        obj = json.loads(stripped)
    except ValueError:
        try:
            obj = ast.literal_eval(stripped)
        except (ValueError, SyntaxError) as exc:
            raise RuntimeError(f"unparseable qmp.py output line {stripped!r}: {exc!r}") from exc
    if not isinstance(obj, dict):
        raise RuntimeError(f"non-dict qmp.py output: {stripped!r}")
    return obj


def qmp_cmd(vm_base: Path, payload: dict[str, Any], *, timeout_s: float) -> dict[str, Any]:
    bounded_timeout = require_finite_range("qmp_timeout_seconds", timeout_s, 0.4, 1.25)
    cp = subprocess.run(
        ["/usr/bin/python3", "-I", str(vm_base / "qmp.py"), "cmd", json.dumps(payload)],
        cwd=vm_base,
        capture_output=True,
        text=True,
        timeout=bounded_timeout,
        check=True,
    )
    parsed_lines: list[dict[str, Any]] = []
    for raw_line in cp.stdout.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            continue
        obj = parse_qmp_helper_line(stripped)
        if "error" in obj:
            raise RuntimeError(f"QMP command returned error: {obj['error']!r}")
        parsed_lines.append(obj)
    if not any(isinstance(obj.get("return"), dict) for obj in parsed_lines):
        raise RuntimeError(f"QMP output lacked a valid return dict: {cp.stdout!r}")
    return {"rawStdout": cp.stdout, "parsed": parsed_lines}


def qmp_send_events(vm_base: Path, events: list[dict[str, Any]], *, timeout_s: float) -> dict[str, Any]:
    return qmp_cmd(
        vm_base,
        {"execute": "input-send-event", "arguments": {"events": events}},
        timeout_s=timeout_s,
    )


def qmp_send_qcode_key(vm_base: Path, key_name: str, *, timeout_s: float) -> dict[str, Any]:
    """Use explicit `cmd send-key` (never `qmp.py keys`, which discards QMP replies)."""
    if key_name not in SAFE_QMP_KEYS:
        raise FenceRefusal(f"disallowed qcode key: {key_name!r}")
    return qmp_cmd(
        vm_base,
        {
            "execute": "send-key",
            "arguments": {"keys": [{"type": "qcode", "data": key_name}], "hold-time": 60},
        },
        timeout_s=timeout_s,
    )


def assert_pre_dispatch_budget(
    verified: dict[str, Any],
    *,
    reserve_before_local_stop_s: float,
    local_stop_lead_s: float = 1.0,
) -> float:
    """Guard pre-dispatch remaining budget before `D - 1.0s` (`localStop`).

    Caveat (`sol-docs` 01M6C38KJ81FHET3TFE2EBNGA1): Host SSH probes and host QMP
    sockets are separate non-real-time channels. This check verifies pre-dispatch
    remaining budget under the stated monotonic-clock and helper-timeout bounds;
    host OS scheduling, Python `subprocess(..., timeout=...)`, and QMP socket
    delivery are not hard real-time guarantees, nor atomic compositor locks. Any
    helper timeout or late/uncertain completion fails closed (`passed = False`).
    """
    host_since_probe = time.monotonic() - float(verified["_hostProbeDoneMonotonic"])
    if host_since_probe < 0.0:
        raise FenceRefusal("negative host monotonic delta")
    upper_guest_now = (
        float(verified["guestMonotonic"])
        + float(verified["hostRoundTripSeconds"])
        + host_since_probe
    )
    remaining_to_local_stop = (float(verified["_deadlineSeconds"]) - local_stop_lead_s) - upper_guest_now
    if remaining_to_local_stop < reserve_before_local_stop_s:
        raise FenceRefusal(
            f"pre-dispatch remaining before localStop ({remaining_to_local_stop:.3f}s) "
            f"< required reserve ({reserve_before_local_stop_s:.3f}s)"
        )
    return remaining_to_local_stop


def verify_fence(
    probe: dict[str, Any],
    *,
    min_remaining_s: float,
    max_live_age_s: float = 1.5,
    hitbox: tuple[float, float, float, float] | None = None,
    forbid_upper_layer_surfaces: bool = False,
    expected_unit: str | None = None,
    expected_launcher_pid: int | None = None,
    expected_deadline_ns: str | None = None,
    expected_broker_pid: int | None = None,
    expected_broker_birth: str | None = None,
    expected_engine_pid: int | None = None,
    expected_engine_birth: str | None = None,
    expected_window_address: str | None = None,
    allow_empty_baseline_clients: bool = False,
    allow_fullscreen: bool = False,
) -> dict[str, Any]:
    min_rem = require_finite_range("min_remaining_s", min_remaining_s, 1.25, 27.5)
    if probe.get("locked"):
        raise FenceRefusal("guest session is locked or hyprlock is active")

    cs = probe["controllerState"]
    unit = str(cs.get("unit", ""))
    if not UNIT_NAME_RE.match(unit):
        raise FenceRefusal(f"controller-state unit {unit!r} does not match expected transient scope pattern")
    if expected_unit is not None and unit != expected_unit:
        raise FenceRefusal(f"controller-state unit {unit!r} != pinned {expected_unit!r}")

    deadline_ns_str = str(cs.get("deadlineMonotonicNs", ""))
    if not deadline_ns_str.isdigit() or deadline_ns_str != str(probe.get("backendDeadlineMonotonicNs", "")):
        raise FenceRefusal("controller-state and backend.json deadlineMonotonicNs mismatch")
    if expected_deadline_ns is not None and deadline_ns_str != expected_deadline_ns:
        raise FenceRefusal(f"deadlineMonotonicNs {deadline_ns_str!r} != pinned {expected_deadline_ns!r}")

    deadline_s = int(deadline_ns_str) / 1e9
    guest_now = float(probe["guestMonotonic"])
    rtt = float(probe["hostRoundTripSeconds"])
    effective_remaining_s = deadline_s - (guest_now + rtt)
    if effective_remaining_s < min_rem:
        raise FenceRefusal(
            f"insufficient remaining budget before original D: {effective_remaining_s:.3f}s < {min_rem:.3f}s"
        )

    live_cur = probe["liveCurrent"]
    live_age = guest_now - float(live_cur["monotonic"])
    if live_age < -0.05 or live_age > max_live_age_s:
        raise FenceRefusal(f"stale live-current.json observation: age={live_age:.3f}s")
    if not live_cur.get("scopeState", {}).get("membershipKnown"):
        raise FenceRefusal("guest controller scopeState.membershipKnown is False")

    unit_props = probe["liveUnitProps"]
    cg_prop = str(unit_props.get("ControlGroup", ""))
    euid = int(probe["euid"])
    expected_cg = f"/user.slice/user-{euid}.slice/user@{euid}.service/app.slice/{unit}"
    live_cur_cg = str((live_cur.get("scopeState", {}).get("properties") or {}).get("ControlGroup", ""))
    if (
        unit_props.get("ActiveState") != "active"
        or cg_prop != expected_cg
        or cg_prop != live_cur_cg
    ):
        raise FenceRefusal(
            f"owned scope unit/ControlGroup mismatch or inactive: {unit_props!r} (expected {expected_cg!r})"
        )

    if not probe.get("liveCgroupKnown") or probe.get("liveCgroupError") is not None:
        raise FenceRefusal(
            f"owned cgroup census incomplete or unreadable: error={probe.get('liveCgroupError')!r}"
        )
    if len(probe["liveCgroupProcs"]) != len(probe["liveCgroupPIDs"]):
        raise FenceRefusal("owned cgroup process census count mismatch")

    ui_pin = probe.get("backendUiPin") or {}
    ui_dev = int(ui_pin["device"])
    ui_ino = int(ui_pin["inode"])
    launcher_pid = int(cs["launcherPID"])
    if expected_launcher_pid is not None and launcher_pid != expected_launcher_pid:
        raise FenceRefusal(f"launcherPID {launcher_pid} != pinned {expected_launcher_pid}")

    procs = {int(r["pid"]): r for r in probe["liveCgroupProcs"]}
    launcher = procs.get(launcher_pid)
    if not launcher or launcher["state"] == "Z":
        raise FenceRefusal(f"launcherPID {launcher_pid} missing or zombie in owned cgroup")

    brokers = [
        r for r in procs.values()
        if r["ppid"] == launcher_pid
        and r["device"] == ui_dev
        and r["inode"] == ui_ino
        and len(r["namespacePids"]) == 1
        and r["namespacePids"][-1] != 1
        and r["state"] != "Z"
    ]
    if len(brokers) != 1:
        raise FenceRefusal(f"expected exactly 1 live broker warlock-ui-owner, found {len(brokers)}")
    broker = brokers[0]

    engines = [
        r for r in procs.values()
        if r["ppid"] == broker["pid"]
        and r["device"] == ui_dev
        and r["inode"] == ui_ino
        and len(r["namespacePids"]) == 2
        and r["namespacePids"][-1] == 1
        and r["state"] != "Z"
    ]
    if len(engines) != 1:
        raise FenceRefusal(f"expected exactly 1 live PID-1 engine warlock-ui-owner, found {len(engines)}")
    engine = engines[0]

    if live_cur.get("eligibleEnginePIDs") != [engine["pid"]]:
        raise FenceRefusal(
            f"live-current eligibleEnginePIDs {live_cur.get('eligibleEnginePIDs')} != [{engine['pid']}]"
        )

    if expected_broker_pid is not None and broker["pid"] != expected_broker_pid:
        raise FenceRefusal(f"broker PID changed: {broker['pid']} != {expected_broker_pid}")
    if expected_broker_birth is not None and broker["birth"] != expected_broker_birth:
        raise FenceRefusal(f"broker birth changed: {broker['birth']} != {expected_broker_birth}")
    if expected_engine_pid is not None and engine["pid"] != expected_engine_pid:
        raise FenceRefusal(f"engine PID changed: {engine['pid']} != {expected_engine_pid}")
    if expected_engine_birth is not None and engine["birth"] != expected_engine_birth:
        raise FenceRefusal(f"engine birth changed: {engine['birth']} != {expected_engine_birth}")

    # Strict baseline desktop preservation: EVERY client in `preservation-before.json`
    # (including Foot) MUST have both an original process record AND a live current
    # process record with identical `(pid, birth, device, inode)` plus a still-mapped
    # Hyprland client window with identical `(address, pid, class)`.
    before_clients = probe.get("preservationBeforeClients") or []
    if not before_clients and not allow_empty_baseline_clients:
        raise FenceRefusal("preservation-before.json has zero baseline clients (expected Foot)")
    before_procs = probe.get("preservationBeforeProcesses") or {}
    cur_baseline_by_pid = {int(row["pid"]): row for row in (probe.get("baselineClientProcsNow") or [])}
    clients = probe["hypr"].get("clients") or []
    clients_by_addr = {str(c.get("address")): c for c in clients if c.get("address")}

    for bc in before_clients:
        bpid = int(bc["pid"])
        baddr = str(bc.get("address", ""))
        bclass = str(bc.get("class", ""))
        orig_p = before_procs.get(str(bpid))
        if orig_p is None:
            raise FenceRefusal(
                f"preservation-before.json missing original process record for baseline client pid={bpid} class={bclass!r}"
            )
        cur_entry = cur_baseline_by_pid.get(bpid)
        cur_p = cur_entry.get("current") if cur_entry else None
        if (
            cur_p is None
            or cur_p["state"] == "Z"
            or int(cur_p["pid"]) != int(orig_p["pid"])
            or str(cur_p["birth"]) != str(orig_p["birth"])
            or int(cur_p["device"]) != int(orig_p["device"])
            or int(cur_p["inode"]) != int(orig_p["inode"])
        ):
            raise FenceRefusal(
                f"baseline client process pid={bpid} class={bclass!r} missing or altered: {cur_entry!r}"
            )
        live_bc = clients_by_addr.get(baddr)
        if (
            live_bc is None
            or not live_bc.get("mapped")
            or int(live_bc.get("pid", -1)) != bpid
            or str(live_bc.get("class", "")) != bclass
        ):
            raise FenceRefusal(
                f"baseline client window addr={baddr!r} pid={bpid} class={bclass!r} missing or altered"
            )

    monitors = probe["hypr"].get("monitors") or []
    if len(monitors) != 1:
        raise FenceRefusal(f"expected 1 monitor, observed {len(monitors)}")
    mon = monitors[0]
    if (
        mon.get("disabled")
        or mon.get("dpmsStatus") is not True
        or mon.get("scale") != 1
        or mon.get("transform") != 0
        or int(mon.get("x", -1)) != 0
        or int(mon.get("y", -1)) != 0
        or int(mon.get("width", 0)) <= 0
        or int(mon.get("height", 0)) <= 0
    ):
        raise FenceRefusal(f"unsupported monitor state/geometry: {mon!r}")
    mw, mh = int(mon["width"]), int(mon["height"])

    owned_windows = [
        c for c in clients
        if c.get("pid") == engine["pid"]
        and c.get("mapped") is True
        and not c.get("hidden", False)
        and c.get("visible", True) is True
    ]
    if len(owned_windows) != 1:
        raise FenceRefusal(f"expected 1 mapped unhidden engine window, observed {len(owned_windows)}")
    win = owned_windows[0]
    if win.get("floating") is not False:
        raise FenceRefusal("owned window unexpectedly floating")
    win_fullscreen = int(win.get("fullscreen", 0))
    if not allow_fullscreen and win_fullscreen != 0:
        raise FenceRefusal(
            f"owned window fullscreen={win_fullscreen} (occludes tiled Foot unless --allow-fullscreen is set)"
        )
    if expected_window_address is not None and win.get("address") != expected_window_address:
        raise FenceRefusal(f"owned window address changed: {win.get('address')} != {expected_window_address}")

    active = probe["hypr"].get("activeWindow") or {}
    if active.get("pid") != engine["pid"] or active.get("address") != win.get("address"):
        raise FenceRefusal(
            f"owned window is not activeWindow (active pid={active.get('pid')}, addr={active.get('address')})"
        )

    baseline_pids = {int(c["pid"]) for c in before_clients}
    if active.get("pid") in baseline_pids:
        raise FenceRefusal("baseline desktop window (e.g. Foot) holds focus; aborting")

    wx, wy = float(win["at"][0]), float(win["at"][1])
    ww, wh = float(win["size"][0]), float(win["size"][1])
    if ww < 64 or wh < 64 or wx < 0 or wy < 0 or wx + ww > mw or wy + wh > mh:
        raise FenceRefusal(f"owned window geometry out of monitor bounds: at={win['at']} size={win['size']}")
    win_rect = (wx, wy, wx + ww, wy + wh)

    mon_name = mon.get("name")
    if not isinstance(mon_name, str) or not mon_name:
        raise FenceRefusal(f"monitor missing string name: {mon!r}")
    layers_by_mon = probe["hypr"].get("layers")
    if not isinstance(layers_by_mon, dict) or mon_name not in layers_by_mon:
        raise FenceRefusal(f"unrecognized or missing hyprctl layers schema for monitor {mon_name!r}")

    upper_surfaces: list[tuple[str, dict[str, Any], tuple[float, float, float, float]]] = []
    for m_key, mon_entry in layers_by_mon.items():
        if not isinstance(mon_entry, dict) or not isinstance(mon_entry.get("levels"), dict):
            raise FenceRefusal(f"malformed hyprctl layers entry for {m_key!r}")
        levels = mon_entry["levels"]
        for lvl in ("2", "3"):
            lvl_list = levels.get(lvl)
            if not isinstance(lvl_list, list):
                raise FenceRefusal(f"missing or non-list layer level {lvl!r} on monitor {m_key!r}")
            for surf in lvl_list:
                if not isinstance(surf, dict) or not all(k in surf for k in ("x", "y", "w", "h")):
                    raise FenceRefusal(f"malformed surface geometry in layer {lvl!r}: {surf!r}")
                sx = require_finite_range("layer.x", surf["x"], -65536.0, 65536.0)
                sy = require_finite_range("layer.y", surf["y"], -65536.0, 65536.0)
                sw = require_finite_range("layer.w", surf["w"], 0.0, 65536.0)
                sh = require_finite_range("layer.h", surf["h"], 0.0, 65536.0)
                upper_surfaces.append((lvl, surf, (sx, sy, sx + sw, sy + sh)))

    if forbid_upper_layer_surfaces:
        for lvl, surf, srect in upper_surfaces:
            if (srect[2] - srect[0]) <= 0.0 or (srect[3] - srect[1]) <= 0.0:
                continue
            if lvl == "3" or rects_overlap(win_rect, srect):
                raise FenceRefusal(
                    f"upper layer {lvl} surface namespace={surf.get('namespace')!r} "
                    f"active during keyboard step (may capture seat keyboard focus)"
                )

    if hitbox is not None:
        x0, y0, x1, y1 = hitbox
        if not all(math.isfinite(v) for v in hitbox):
            raise FenceRefusal(f"non-finite hitbox: {hitbox}")
        if (x1 - x0) < 6.0 or (y1 - y0) < 4.0:
            raise FenceRefusal(f"hitbox too small (need >= 6px width for intra-hitbox motion): {hitbox}")
        if not (wx + 2.0 <= x0 < x1 <= wx + ww - 2.0 and wy + 2.0 <= y0 < y1 <= wy + wh - 2.0):
            raise FenceRefusal(
                f"hitbox {hitbox} is not strictly inside current owned window [{wx}, {wy}, {wx + ww}, {wy + wh}]"
            )
        for other in clients:
            if other.get("address") == win.get("address") or not other.get("mapped"):
                continue
            ox, oy = float(other["at"][0]), float(other["at"][1])
            ow, oh = float(other["size"][0]), float(other["size"][1])
            if rects_overlap(hitbox, (ox, oy, ox + ow, oy + oh)):
                raise FenceRefusal(
                    f"hitbox {hitbox} overlaps foreign client pid={other.get('pid')} class={other.get('class')}"
                )
        for lvl, surf, srect in upper_surfaces:
            if (srect[2] - srect[0]) > 0.0 and (srect[3] - srect[1]) > 0.0 and rects_overlap(hitbox, srect):
                raise FenceRefusal(
                    f"hitbox {hitbox} occluded by layer {lvl} surface namespace={surf.get('namespace')!r}"
                )

    return {
        "unit": unit,
        "controlGroup": cg_prop,
        "deadlineMonotonicNs": deadline_ns_str,
        "_deadlineSeconds": deadline_s,
        "_hostProbeDoneMonotonic": probe["_hostProbeDoneMonotonic"],
        "guestMonotonic": guest_now,
        "hostRoundTripSeconds": rtt,
        "effectiveRemainingSeconds": effective_remaining_s,
        "launcherPID": launcher_pid,
        "broker": {"pid": broker["pid"], "birth": broker["birth"]},
        "engine": {"pid": engine["pid"], "birth": engine["birth"], "namespacePids": engine["namespacePids"]},
        "window": {
            "address": win["address"],
            "at": win["at"],
            "size": win["size"],
            "fullscreen": win_fullscreen,
            "workspaceId": win.get("workspace", {}).get("id"),
            "class": win.get("class"),
        },
        "monitor": {"name": mon.get("name"), "width": mw, "height": mh, "scale": mon.get("scale")},
    }


def strip_private_keys(verified: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in verified.items() if not k.startswith("_")}


def cmd_probe(args: argparse.Namespace) -> int:
    receipt_path = Path(args.receipt_json)
    validate_host_output_path(receipt_path)
    if args.host_screenshot:
        validate_host_output_path(Path(args.host_screenshot))

    started_wall = time.time()
    vm_base = Path(args.vm_base)
    try:
        min_rem = require_finite_range("min_remaining_seconds", args.min_remaining_seconds, 3.5, 27.5)
        prior_receipts_checked = None
        if args.host_evidence_dir:
            prior_receipts_checked = verify_zero_prior_host_inputs(Path(args.host_evidence_dir))

        watch_samples: list[dict[str, Any]] = []
        if args.watch_no_input_seconds is not None:
            watch_dur = require_finite_range("watch_no_input_seconds", args.watch_no_input_seconds, 1.0, 12.0)
            poll_int = require_finite_range("poll_interval_seconds", args.poll_interval_seconds, 0.25, 1.0)
            if not args.host_evidence_dir:
                raise FenceRefusal("--watch-no-input-seconds requires --host-evidence-dir to verify zero prior QMP receipts")

            first_probe = run_guest_probe(
                vm_base,
                args.guest_run_dir,
                wayland_display=args.wayland_display,
                hyprland_sig=args.hyprland_instance_signature,
                capture_png=False,
            )
            first_ver = verify_fence(
                first_probe,
                min_remaining_s=min_rem + watch_dur,
                expected_unit=args.expected_unit,
                expected_launcher_pid=args.expected_launcher_pid,
                expected_deadline_ns=args.expected_deadline_ns,
                expected_broker_pid=args.expected_broker_pid,
                expected_broker_birth=args.expected_broker_birth,
                expected_engine_pid=args.expected_engine_pid,
                expected_engine_birth=args.expected_engine_birth,
                expected_window_address=args.expected_window_address,
                allow_fullscreen=bool(args.allow_fullscreen),
            )
            watch_samples.append(strip_private_keys(first_ver))
            prev_guest_mono = float(first_ver["guestMonotonic"])
            first_guest_mono = prev_guest_mono

            while True:
                time.sleep(poll_int)
                verify_zero_prior_host_inputs(Path(args.host_evidence_dir))
                elapsed_guest = prev_guest_mono - first_guest_mono
                want_png = bool(args.host_screenshot) and (elapsed_guest + poll_int >= watch_dur)
                cur_probe = run_guest_probe(
                    vm_base,
                    args.guest_run_dir,
                    wayland_display=args.wayland_display,
                    hyprland_sig=args.hyprland_instance_signature,
                    capture_png=want_png,
                )
                cur_ver = verify_fence(
                    cur_probe,
                    min_remaining_s=min_rem,
                    expected_unit=first_ver["unit"],
                    expected_launcher_pid=first_ver["launcherPID"],
                    expected_deadline_ns=first_ver["deadlineMonotonicNs"],
                    expected_broker_pid=first_ver["broker"]["pid"],
                    expected_broker_birth=first_ver["broker"]["birth"],
                    expected_engine_pid=first_ver["engine"]["pid"],
                    expected_engine_birth=first_ver["engine"]["birth"],
                    expected_window_address=first_ver["window"]["address"],
                    allow_fullscreen=bool(args.allow_fullscreen),
                )
                gap_s = float(cur_ver["guestMonotonic"]) - prev_guest_mono
                if gap_s <= 0.0 or gap_s > 1.5:
                    raise FenceRefusal(f"non-contiguous watch sample gap: {gap_s:.3f}s")
                if cur_ver["window"]["at"] != first_ver["window"]["at"] or cur_ver["window"]["size"] != first_ver["window"]["size"]:
                    raise FenceRefusal("owned window geometry shifted during no-input watch")
                watch_samples.append(strip_private_keys(cur_ver))
                prev_guest_mono = float(cur_ver["guestMonotonic"])
                if (prev_guest_mono - first_guest_mono) >= watch_dur:
                    if args.host_screenshot and not cur_probe.get("pngHex"):
                        cur_probe = run_guest_probe(
                            vm_base,
                            args.guest_run_dir,
                            wayland_display=args.wayland_display,
                            hyprland_sig=args.hyprland_instance_signature,
                            capture_png=True,
                        )
                        cur_ver = verify_fence(
                            cur_probe,
                            min_remaining_s=min_rem,
                            expected_unit=first_ver["unit"],
                            expected_launcher_pid=first_ver["launcherPID"],
                            expected_deadline_ns=first_ver["deadlineMonotonicNs"],
                            expected_broker_pid=first_ver["broker"]["pid"],
                            expected_broker_birth=first_ver["broker"]["birth"],
                            expected_engine_pid=first_ver["engine"]["pid"],
                            expected_engine_birth=first_ver["engine"]["birth"],
                            expected_window_address=first_ver["window"]["address"],
                            allow_fullscreen=bool(args.allow_fullscreen),
                        )
                        watch_samples.append(strip_private_keys(cur_ver))
                    probe = cur_probe
                    verified = cur_ver
                    break
            sampled_span_s = float(verified["guestMonotonic"]) - first_guest_mono
        else:
            probe = run_guest_probe(
                vm_base,
                args.guest_run_dir,
                wayland_display=args.wayland_display,
                hyprland_sig=args.hyprland_instance_signature,
                capture_png=bool(args.host_screenshot),
            )
            verified = verify_fence(
                probe,
                min_remaining_s=min_rem,
                expected_unit=args.expected_unit,
                expected_launcher_pid=args.expected_launcher_pid,
                expected_deadline_ns=args.expected_deadline_ns,
                expected_broker_pid=args.expected_broker_pid,
                expected_broker_birth=args.expected_broker_birth,
                expected_engine_pid=args.expected_engine_pid,
                expected_engine_birth=args.expected_engine_birth,
                expected_window_address=args.expected_window_address,
                allow_fullscreen=bool(args.allow_fullscreen),
            )
            sampled_span_s = None

        screenshot_record = None
        if args.host_screenshot:
            png_bytes = bytes.fromhex(probe["pngHex"])
            sha = write_exclusive_bytes(Path(args.host_screenshot), png_bytes)
            screenshot_record = {"path": args.host_screenshot, "bytes": len(png_bytes), "sha256": sha}

        payload: dict[str, Any] = {
            "kind": "host-qmp-probe-receipt",
            "passed": True,
            "startedEpochSeconds": started_wall,
            "completedEpochSeconds": time.time(),
            "verified": strip_private_keys(verified),
            "priorHostReceiptsChecked": prior_receipts_checked,
            "sampledNoDriverInputWindowSeconds": sampled_span_s,
            "watchSampleCount": len(watch_samples) if watch_samples else 1,
            "noDriverInputCaveat": (
                "Proves sampled mapped-window survival without host-driver QMP receipts only; "
                "not proof of authenticated-stream inter-frame quiescence or absence of "
                "non-driver guest activity. Post-run summarize-run inspects 0.2s observations.json."
            ),
            "screenshot": screenshot_record,
            "nativeOperations": [],
            "providerCleanupQualified": False,
            "nativeAccepted": False,
            "releaseAccepted": False,
        }
    except Exception as exc:
        payload = {
            "kind": "host-qmp-probe-receipt",
            "passed": False,
            "startedEpochSeconds": started_wall,
            "completedEpochSeconds": time.time(),
            "error": repr(exc),
            "nativeOperations": [],
            "providerCleanupQualified": False,
            "nativeAccepted": False,
            "releaseAccepted": False,
        }
    write_exclusive_json(receipt_path, payload)
    print(json.dumps({"passed": payload["passed"], "receipt": str(receipt_path), "error": payload.get("error")}))
    return 0 if payload["passed"] else 1


def cmd_click_hitbox(args: argparse.Namespace) -> int:
    receipt_path = Path(args.receipt_json)
    validate_host_output_path(receipt_path)
    vm_base = Path(args.vm_base)
    started_wall = time.time()

    hitbox = (float(args.hitbox[0]), float(args.hitbox[1]), float(args.hitbox[2]), float(args.hitbox[3]))
    tx = (hitbox[0] + hitbox[2]) / 2.0
    ty = (hitbox[1] + hitbox[3]) / 2.0
    tx_settle = tx - 3.0 if (tx - 3.0) >= (hitbox[0] + 2.0) else (tx + 1.0)

    record: dict[str, Any] = {
        "kind": "host-qmp-click-hitbox-receipt",
        "label": args.label,
        "startedEpochSeconds": started_wall,
        "hitbox": list(hitbox),
        "entryPixel": [tx, ty],
        "targetPixel": [tx_settle, ty],
        "phases": {},
        "releaseSafetyPolicy": (
            "Before button release in finally, run a fresh preReleaseFence verifying "
            "unchanged owned engine/window/geometry/focus, client-disjointness from Foot, "
            "and remaining budget before D-1.0s localStop. Only if preReleaseFence passes "
            "does down=False dispatch. If preReleaseFence fails after press was dispatched, "
            "NO unfenced motion or button-up is sent on the desktop; the receipt records "
            "buttonLatchPossiblyHeldRequiresRootRecovery=True and fails closed (passed=False) "
            "for explicit Root abort/recovery."
        ),
        "nativeOperations": [],
        "providerCleanupQualified": False,
        "nativeAccepted": False,
        "releaseAccepted": False,
    }
    try:
        min_rem = require_finite_range("min_remaining_seconds", args.min_remaining_seconds, 8.0, 27.0)
        qmp_timeout_s = require_finite_range("qmp_timeout_seconds", args.qmp_timeout_seconds, 0.4, 1.25)
        hold_s = require_finite_range("hold_seconds", args.hold_seconds, 0.02, 0.15)
        motion_settle_s = require_finite_range("motion_settle_seconds", args.motion_settle_seconds, 0.05, 0.25)

        # Phase 1: Pre-motion fence.
        pre_probe = run_guest_probe(
            vm_base,
            args.guest_run_dir,
            wayland_display=args.wayland_display,
            hyprland_sig=args.hyprland_instance_signature,
            capture_png=False,
        )
        pre_verified = verify_fence(
            pre_probe,
            min_remaining_s=min_rem,
            hitbox=hitbox,
            expected_unit=args.expected_unit,
            expected_launcher_pid=args.expected_launcher_pid,
            expected_deadline_ns=args.expected_deadline_ns,
            expected_broker_pid=args.expected_broker_pid,
            expected_broker_birth=args.expected_broker_birth,
            expected_engine_pid=args.expected_engine_pid,
            expected_engine_birth=args.expected_engine_birth,
            expected_window_address=args.expected_window_address,
            allow_fullscreen=bool(args.allow_fullscreen),
        )
        record["phases"]["preMotionFence"] = strip_private_keys(pre_verified)

        mw = pre_verified["monitor"]["width"]
        mh = pre_verified["monitor"]["height"]
        motion_entry_events = [
            {"type": "abs", "data": {"axis": "x", "value": round(tx * 32767 / mw)}},
            {"type": "abs", "data": {"axis": "y", "value": round(ty * 32767 / mh)}},
        ]
        motion_settle_events = [
            {"type": "abs", "data": {"axis": "x", "value": round(tx_settle * 32767 / mw)}},
            {"type": "abs", "data": {"axis": "y", "value": round(ty * 32767 / mh)}},
        ]

        # Phase 2: Two-step intra-hitbox QMP pointer motion so WebKitWebProcess
        # processes an intra-surface wl_pointer.motion after wl_pointer.enter.
        rem_motion_entry = assert_pre_dispatch_budget(
            pre_verified,
            reserve_before_local_stop_s=(4.0 * qmp_timeout_s) + (2.0 * motion_settle_s) + hold_s + 1.5,
        )
        motion_entry_reply = qmp_send_events(vm_base, motion_entry_events, timeout_s=qmp_timeout_s)
        time.sleep(motion_settle_s)
        rem_motion_settle = assert_pre_dispatch_budget(
            pre_verified,
            reserve_before_local_stop_s=(3.0 * qmp_timeout_s) + motion_settle_s + hold_s + 1.5,
        )
        motion_settle_reply = qmp_send_events(vm_base, motion_settle_events, timeout_s=qmp_timeout_s)
        time.sleep(motion_settle_s)
        record["phases"]["motion"] = {
            "remainingBeforeLocalStopAtEntryDispatch": rem_motion_entry,
            "remainingBeforeLocalStopAtSettleDispatch": rem_motion_settle,
            "motionSettleSeconds": motion_settle_s,
            "entryQmpEvents": motion_entry_events,
            "entryReply": motion_entry_reply,
            "settleQmpEvents": motion_settle_events,
            "settleReply": motion_settle_reply,
        }

        # Phase 3: Post-motion / pre-press re-gate.
        post_motion_probe = run_guest_probe(
            vm_base,
            args.guest_run_dir,
            wayland_display=args.wayland_display,
            hyprland_sig=args.hyprland_instance_signature,
            capture_png=False,
        )
        post_motion_verified = verify_fence(
            post_motion_probe,
            min_remaining_s=max(3.5, (2.0 * qmp_timeout_s) + hold_s + 2.0),
            hitbox=hitbox,
            expected_unit=pre_verified["unit"],
            expected_launcher_pid=pre_verified["launcherPID"],
            expected_deadline_ns=pre_verified["deadlineMonotonicNs"],
            expected_broker_pid=pre_verified["broker"]["pid"],
            expected_broker_birth=pre_verified["broker"]["birth"],
            expected_engine_pid=pre_verified["engine"]["pid"],
            expected_engine_birth=pre_verified["engine"]["birth"],
            expected_window_address=pre_verified["window"]["address"],
            allow_fullscreen=bool(args.allow_fullscreen),
        )
        if (
            post_motion_verified["window"]["at"] != pre_verified["window"]["at"]
            or post_motion_verified["window"]["size"] != pre_verified["window"]["size"]
            or post_motion_verified["monitor"] != pre_verified["monitor"]
        ):
            raise FenceRefusal("owned window or monitor geometry changed between motion and press")
        record["phases"]["postMotionRegate"] = strip_private_keys(post_motion_verified)

        # Phase 4: Re-check host clock immediately before press, then press + finally release.
        press_reserve_s = (2.0 * qmp_timeout_s) + hold_s + 1.0
        rem_press = assert_pre_dispatch_budget(
            post_motion_verified,
            reserve_before_local_stop_s=press_reserve_s,
        )
        press_event = [{"type": "btn", "data": {"down": True, "button": "left"}}]
        release_event = [{"type": "btn", "data": {"down": False, "button": "left"}}]
        press_dispatched = False
        press_err: Exception | None = None
        release_err: Exception | None = None
        try:
            press_dispatched = True
            down_reply = qmp_send_events(vm_base, press_event, timeout_s=qmp_timeout_s)
            record["phases"]["press"] = {
                "remainingBeforeLocalStopAtDispatch": rem_press,
                "qmpEvents": press_event,
                "reply": down_reply,
            }
            time.sleep(hold_s)
        except Exception as exc:
            press_err = exc
        finally:
            if press_dispatched:
                pre_rel_probe: dict[str, Any] | None = None
                try:
                    pre_rel_probe = run_guest_probe(
                        vm_base,
                        args.guest_run_dir,
                        wayland_display=args.wayland_display,
                        hyprland_sig=args.hyprland_instance_signature,
                        capture_png=False,
                    )
                    pre_rel_ver = verify_fence(
                        pre_rel_probe,
                        min_remaining_s=qmp_timeout_s + 1.25,
                        hitbox=hitbox,
                        expected_unit=pre_verified["unit"],
                        expected_launcher_pid=pre_verified["launcherPID"],
                        expected_deadline_ns=pre_verified["deadlineMonotonicNs"],
                        expected_broker_pid=pre_verified["broker"]["pid"],
                        expected_broker_birth=pre_verified["broker"]["birth"],
                        expected_engine_pid=pre_verified["engine"]["pid"],
                        expected_engine_birth=pre_verified["engine"]["birth"],
                        expected_window_address=pre_verified["window"]["address"],
                        allow_fullscreen=bool(args.allow_fullscreen),
                    )
                    if (
                        pre_rel_ver["window"]["at"] != pre_verified["window"]["at"]
                        or pre_rel_ver["window"]["size"] != pre_verified["window"]["size"]
                        or pre_rel_ver["monitor"] != pre_verified["monitor"]
                    ):
                        raise FenceRefusal("owned window or monitor geometry changed before release")
                    rem_rel = assert_pre_dispatch_budget(
                        pre_rel_ver,
                        reserve_before_local_stop_s=qmp_timeout_s + 0.25,
                    )
                    record["phases"]["preReleaseFence"] = strip_private_keys(pre_rel_ver)
                    up_reply = qmp_send_events(vm_base, release_event, timeout_s=qmp_timeout_s)
                    record["phases"]["release"] = {
                        "remainingBeforeLocalStopAtDispatch": rem_rel,
                        "qmpEvents": release_event,
                        "reply": up_reply,
                    }
                except Exception as r_exc:
                    release_err = r_exc
                    record["phases"]["releaseError"] = repr(r_exc)
                    # Never emit unfenced motion or button-up when preReleaseFence fails;
                    # record explicit Root recovery requirement and fail closed.
                    record["phases"]["buttonLatchPossiblyHeldRequiresRootRecovery"] = True

        if press_err and release_err:
            raise RuntimeError(f"press failed ({press_err!r}) and release failed ({release_err!r})")
        if press_err:
            raise press_err
        if release_err:
            raise release_err

        # Phase 5: Mandatory post-release verification fence (confirms owner/window/Foot intact).
        post_rel_probe = run_guest_probe(
            vm_base,
            args.guest_run_dir,
            wayland_display=args.wayland_display,
            hyprland_sig=args.hyprland_instance_signature,
            capture_png=False,
        )
        post_rel_verified = verify_fence(
            post_rel_probe,
            min_remaining_s=1.5,
            expected_unit=pre_verified["unit"],
            expected_launcher_pid=pre_verified["launcherPID"],
            expected_deadline_ns=pre_verified["deadlineMonotonicNs"],
            expected_broker_pid=pre_verified["broker"]["pid"],
            expected_broker_birth=pre_verified["broker"]["birth"],
            expected_engine_pid=pre_verified["engine"]["pid"],
            expected_engine_birth=pre_verified["engine"]["birth"],
            expected_window_address=pre_verified["window"]["address"],
            allow_fullscreen=bool(args.allow_fullscreen),
        )
        record["phases"]["postReleaseFence"] = strip_private_keys(post_rel_verified)
        record["passed"] = True
    except Exception as exc:
        record["passed"] = False
        record["error"] = repr(exc)

    record["completedEpochSeconds"] = time.time()
    write_exclusive_json(receipt_path, record)
    print(json.dumps({"passed": record["passed"], "receipt": str(receipt_path), "error": record.get("error")}))
    return 0 if record["passed"] else 1


def validate_search_click_witness(
    receipt_path: Path,
    *,
    focus_hitbox: tuple[float, float, float, float],
    max_age_s: float,
    expected_unit: str,
    expected_launcher_pid: int,
    expected_deadline_ns: str,
    expected_engine_pid: int,
    expected_engine_birth: str,
    expected_window_address: str,
) -> dict[str, Any]:
    witness = read_host_json_strict(receipt_path)
    if (
        witness.get("kind") != "host-qmp-click-hitbox-receipt"
        or witness.get("passed") is not True
        or witness.get("label") != "focus-search-field"
    ):
        raise FenceRefusal(f"search-click-receipt is not a passed focus-search-field receipt: {receipt_path}")
    if witness.get("hitbox") != list(focus_hitbox):
        raise FenceRefusal(
            f"search-click-receipt hitbox {witness.get('hitbox')} != --focus-hitbox {list(focus_hitbox)}"
        )
    completed_epoch = float(witness.get("completedEpochSeconds", 0.0))
    age_s = time.time() - completed_epoch
    if age_s < -0.1 or age_s > max_age_s:
        raise FenceRefusal(
            f"search-click-receipt age {age_s:.3f}s outside allowed [0, {max_age_s:.3f}s]"
        )
    post_rel = (witness.get("phases") or {}).get("postReleaseFence") or {}
    if (
        post_rel.get("unit") != expected_unit
        or post_rel.get("launcherPID") != expected_launcher_pid
        or post_rel.get("deadlineMonotonicNs") != expected_deadline_ns
        or (post_rel.get("engine") or {}).get("pid") != expected_engine_pid
        or (post_rel.get("engine") or {}).get("birth") != expected_engine_birth
        or (post_rel.get("window") or {}).get("address") != expected_window_address
    ):
        raise FenceRefusal("search-click-receipt postReleaseFence does not match pinned engine/window/unit")
    return {
        "receiptPath": str(receipt_path),
        "ageSeconds": age_s,
        "windowAtClick": post_rel.get("window"),
    }


def cmd_send_keys(args: argparse.Namespace) -> int:
    receipt_path = Path(args.receipt_json)
    validate_host_output_path(receipt_path)
    vm_base = Path(args.vm_base)
    started_wall = time.time()

    for key_name in args.keys:
        if key_name not in SAFE_QMP_KEYS:
            raise SystemExit(
                f"refusing non-printable/non-allowlisted QMP key name: {key_name!r} "
                f"(allowed: lowercase a-z and 0-9 only)"
            )
    if len(args.keys) > 12:
        raise SystemExit("refusing >12 keys in a single bounded journey step")

    focus_hitbox = (
        float(args.focus_hitbox[0]),
        float(args.focus_hitbox[1]),
        float(args.focus_hitbox[2]),
        float(args.focus_hitbox[3]),
    )
    sent_steps: list[dict[str, Any]] = []
    try:
        min_rem = require_finite_range("min_remaining_seconds", args.min_remaining_seconds, 8.0, 27.0)
        qmp_timeout_s = require_finite_range("qmp_timeout_seconds", args.qmp_timeout_seconds, 0.4, 1.25)
        inter_key_s = require_finite_range("inter_key_seconds", args.inter_key_seconds, 0.05, 0.25)
        max_witness_age_s = require_finite_range(
            "max_focus_receipt_age_seconds", args.max_focus_receipt_age_seconds, 0.5, 12.0
        )

        witness_summary = validate_search_click_witness(
            Path(args.search_click_receipt),
            focus_hitbox=focus_hitbox,
            max_age_s=max_witness_age_s,
            expected_unit=args.expected_unit,
            expected_launcher_pid=args.expected_launcher_pid,
            expected_deadline_ns=args.expected_deadline_ns,
            expected_engine_pid=args.expected_engine_pid,
            expected_engine_birth=args.expected_engine_birth,
            expected_window_address=args.expected_window_address,
        )
        pinned_win_geom = witness_summary["windowAtClick"]

        for idx, key_name in enumerate(args.keys):
            probe = run_guest_probe(
                vm_base,
                args.guest_run_dir,
                wayland_display=args.wayland_display,
                hyprland_sig=args.hyprland_instance_signature,
                capture_png=False,
            )
            verified = verify_fence(
                probe,
                min_remaining_s=min_rem,
                hitbox=focus_hitbox,
                forbid_upper_layer_surfaces=True,
                expected_unit=args.expected_unit,
                expected_launcher_pid=args.expected_launcher_pid,
                expected_deadline_ns=args.expected_deadline_ns,
                expected_broker_pid=args.expected_broker_pid,
                expected_broker_birth=args.expected_broker_birth,
                expected_engine_pid=args.expected_engine_pid,
                expected_engine_birth=args.expected_engine_birth,
                expected_window_address=args.expected_window_address,
                allow_fullscreen=bool(args.allow_fullscreen),
            )
            if (
                verified["window"]["at"] != pinned_win_geom["at"]
                or verified["window"]["size"] != pinned_win_geom["size"]
            ):
                raise FenceRefusal("owned window geometry drifted since search-field click witness")

            rem_key = assert_pre_dispatch_budget(
                verified,
                reserve_before_local_stop_s=qmp_timeout_s + 1.25,
            )
            reply = qmp_send_qcode_key(vm_base, key_name, timeout_s=qmp_timeout_s)
            sent_steps.append({
                "index": idx,
                "key": key_name,
                "remainingBeforeLocalStopAtDispatch": rem_key,
                "reply": reply,
                "fence": strip_private_keys(verified),
            })
            if idx + 1 < len(args.keys):
                time.sleep(inter_key_s)

        payload: dict[str, Any] = {
            "kind": "host-qmp-send-keys-receipt",
            "passed": True,
            "startedEpochSeconds": started_wall,
            "completedEpochSeconds": time.time(),
            "keys": args.keys,
            "focusHitbox": list(focus_hitbox),
            "searchClickWitness": witness_summary,
            "keyboardFocusCaveat": (
                "activeWindow + prior search-click witness + absence of upper-layer surfaces "
                "is a fail-closed precondition, NOT proof of Wayland wl_keyboard delivery; "
                "actual character delivery must be observed in the subsequent screenshot."
            ),
            "steps": sent_steps,
            "nativeOperations": [],
            "providerCleanupQualified": False,
            "nativeAccepted": False,
            "releaseAccepted": False,
        }
    except Exception as exc:
        payload = {
            "kind": "host-qmp-send-keys-receipt",
            "passed": False,
            "startedEpochSeconds": started_wall,
            "completedEpochSeconds": time.time(),
            "keys": args.keys,
            "focusHitbox": list(focus_hitbox),
            "steps": sent_steps,
            "error": repr(exc),
            "nativeOperations": [],
            "providerCleanupQualified": False,
            "nativeAccepted": False,
            "releaseAccepted": False,
        }

    write_exclusive_json(receipt_path, payload)
    print(json.dumps({"passed": payload["passed"], "receipt": str(receipt_path), "error": payload.get("error")}))
    return 0 if payload["passed"] else 1


def cmd_summarize_run(args: argparse.Namespace) -> int:
    receipt_path = Path(args.receipt_json)
    validate_host_output_path(receipt_path)
    vm_base = Path(args.vm_base)
    if not args.guest_run_dir.startswith("/") or ".." in Path(args.guest_run_dir).parts:
        raise FenceRefusal(f"invalid guest_run_dir: {args.guest_run_dir!r}")
    cmd = f"python3 - {shlex.quote(args.guest_run_dir)}"
    cp = subprocess.run(
        [str(vm_base / "ssh.sh"), cmd],
        input=GUEST_SUMMARY_SCRIPT,
        text=True,
        capture_output=True,
        cwd=vm_base,
        timeout=10,
        check=True,
    )
    raw = json.loads(cp.stdout)
    payload = {
        "kind": "host-qmp-post-run-summary",
        "guestSummary": raw,
        "sourceTruthNote": (
            "ui/Main.hs:75 and WebKit.hs:498 deliberately return EngineResult False False "
            "(retaining filter-store directories and leaving provider callback/backing "
            "retirement unqualified). Consequently warlock-ui-owner and warlock-ui-backend "
            "exit non-zero with backend.stdout passed=false even when EngineEntrypoint.hs:323-325 "
            "requests localStop at D-1.0s. Actual exit/auth/cleanup/callbacks/operations are "
            "retained verbatim without requiring invented green."
        ),
        "nativeOperations": [],
        "providerCleanupQualified": False,
        "nativeAccepted": False,
        "releaseAccepted": False,
    }
    write_exclusive_json(receipt_path, payload)
    print(json.dumps({"receipt": str(receipt_path)}))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--vm-base", default=str(DEFAULT_VM_BASE))
    parser.add_argument("--wayland-display", default="wayland-1")
    parser.add_argument("--hyprland-instance-signature", default=None)
    sub = parser.add_subparsers(dest="subcommand", required=True)

    def add_common_expectations(p: argparse.ArgumentParser, *, require_pins: bool) -> None:
        p.add_argument("guest_run_dir", help="Absolute guest run directory (containing controller-state.json)")
        p.add_argument("receipt_json", help="Fresh outside-Git host JSON receipt path")
        p.add_argument("--min-remaining-seconds", type=float, default=8.0)
        p.add_argument(
            "--allow-fullscreen",
            action="store_true",
            help="Allow owned window fullscreen!=0 (default requires tiled fullscreen==0 so Foot stays visible)",
        )
        p.add_argument("--expected-unit", type=str, required=require_pins)
        p.add_argument("--expected-launcher-pid", type=int, required=require_pins)
        p.add_argument("--expected-deadline-ns", type=str, required=require_pins)
        p.add_argument("--expected-broker-pid", type=int, default=None)
        p.add_argument("--expected-broker-birth", type=str, default=None)
        p.add_argument("--expected-engine-pid", type=int, required=require_pins)
        p.add_argument("--expected-engine-birth", type=str, required=require_pins)
        p.add_argument("--expected-window-address", type=str, required=require_pins)

    p_probe = sub.add_parser("probe", help="Read-only fence verification, optional no-input watch, and host PNG capture")
    add_common_expectations(p_probe, require_pins=False)
    p_probe.add_argument("--host-screenshot", default=None, help="Fresh outside-Git host PNG path via `grim -`")
    p_probe.add_argument("--host-evidence-dir", default=None, help="Host receipt dir verified free of prior QMP inputs")
    p_probe.add_argument("--watch-no-input-seconds", type=float, default=None)
    p_probe.add_argument("--poll-interval-seconds", type=float, default=0.5)
    p_probe.set_defaults(func=cmd_probe)

    p_click = sub.add_parser("click-hitbox", help="Two-step motion -> re-gate -> press -> pre-release fence -> release -> post-release fence")
    add_common_expectations(p_click, require_pins=True)
    p_click.add_argument(
        "--label",
        required=True,
        choices=("open-applications", "focus-search-field"),
        help="Authorized no-match slice step label only",
    )
    p_click.add_argument("--hitbox", nargs=4, type=float, metavar=("X0", "Y0", "X1", "Y1"), required=True)
    p_click.add_argument("--motion-settle-seconds", type=float, default=0.12)
    p_click.add_argument("--hold-seconds", type=float, default=0.06)
    p_click.add_argument("--qmp-timeout-seconds", type=float, default=1.0)
    p_click.set_defaults(func=cmd_click_hitbox)

    p_keys = sub.add_parser("send-keys", help="Printable a-z0-9 QMP key sender requiring fresh search-click witness")
    add_common_expectations(p_keys, require_pins=True)
    p_keys.add_argument("--search-click-receipt", required=True, help="Host receipt from preceding search-box click")
    p_keys.add_argument("--focus-hitbox", nargs=4, type=float, metavar=("X0", "Y0", "X1", "Y1"), required=True)
    p_keys.add_argument("--max-focus-receipt-age-seconds", type=float, default=6.0)
    p_keys.add_argument("--keys", nargs="+", required=True, help="Lowercase ASCII letters/digits (a-z, 0-9) only")
    p_keys.add_argument("--inter-key-seconds", type=float, default=0.08)
    p_keys.add_argument("--qmp-timeout-seconds", type=float, default=1.0)
    p_keys.set_defaults(func=cmd_send_keys)

    p_sum = sub.add_parser("summarize-run", help="Read-only post-run collection and 0.2s continuity summary")
    p_sum.add_argument("guest_run_dir")
    p_sum.add_argument("receipt_json")
    p_sum.set_defaults(func=cmd_summarize_run)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
