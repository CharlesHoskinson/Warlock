// Proposed UNRUN component fixture for a separately built actual Elm Popup root.
// Root supplies a fresh isolated page with window.testApp and captured
// window.actions, bounded CDP evaluate/until/check, and source/artifact binding.
// Source-reviewed candidate is the atomic merged pending-view patch
// gemini-gui-pending-query-honest-controls-2119.patch SHA256
// 47e7599f62ca60ca18ecd7c20a6160aebad6b10e1348a224e22fb942937816d4.
// Root must bind the actual integrated source and compiled artifact hashes.
// Synthetic DOM/composition events do not establish native input, actual IME,
// physical focus, assistive technology, presentation latency, or release status.
export async function pendingAffordanceView({ evaluate, until, check, assertSourceIdentity }) {
  await assertSourceIdentity();
  const beforeStatus = 'Type to search applications.';
  const pendingStatus = 'Results may not match current input. Previous: ' + beforeStatus;
  const afterStatus = 'Choose a matching application.';
  const control = (id, domId, label, ariaLabel) => ({ id, domId, label, ariaLabel, detail: '', enabled: true });
  const frame = (publication, query, status) => ({
    surfaceProtocol: 2, publication, lease: '7', mode: 'applications', status, bar: [], popup: [
      control('control:search', 'launcher-search', query, 'Search applications'),
      control('control:close', 'close-applications', 'Windows', 'Close applications and return to windows'),
      control('control:refresh', 'refresh-applications', 'Refresh', 'Refresh applications'),
      control('entry:org.example.Foot', 'entry-foot', 'Foot', 'Open Foot'),
      control('pin:org.example.Foot', 'pin-foot', 'Pin Foot', 'Pin Foot'),
      control('control:page-next', 'page-next', 'Next page', 'Next page')
    ]
  });
  const queryAction = { surfaceProtocol: 2, kind: 'surface-query', surface: 'popup', publication: '1', lease: '7', id: 'control:search', query: 'foot' };
  const exact = (left, right) => JSON.stringify(left) === JSON.stringify(right);
  const sendFrame = value => evaluate(`window.testApp.ports.presentation.send(${JSON.stringify(value)})`);
  const seen = () => evaluate(`(() => {
    const root=document.querySelector('.surface-popup');
    const field=root?.querySelector('[data-surface-field="control:search"]');
    const get=id=>root?.querySelector('[data-surface-control="'+id+'"]');
    const describe=id=>{const n=get(id);return n?{disabled:n.disabled,ariaDisabled:n.getAttribute('aria-disabled'),label:n.getAttribute('aria-label')}:null;};
    return {publication:root?.dataset.publication, status:root?.querySelector('[role="status"]')?.textContent,
      live:root?.querySelector('[role="status"]')?.getAttribute('aria-live'),
      query:field?.value, selectionStart:field?.selectionStart, selectionEnd:field?.selectionEnd, sameField:field===window.heldSearch, focused:document.activeElement===field,
      composing:root?.parentElement?.getAttribute('data-input-composing'),
      entry:describe('entry:org.example.Foot'), pin:describe('pin:org.example.Foot'), nextPage:describe('control:page-next'), refresh:describe('control:refresh'), close:describe('control:close'),
      actions:window.actions};
  })()`);
  await sendFrame(frame('1', '', beforeStatus));
  await until(`document.querySelector('.surface-popup')?.dataset.publication === '1'`);
  await evaluate(`(() => {window.actions.length=0;window.heldSearch=document.querySelector('[data-surface-field="control:search"]');window.heldSearch.focus();})()`);
  let state=await seen();
  check('baseline literal controls and focus',state.query===''&&state.status===beforeStatus&&state.focused&&state.sameField&&state.entry?.disabled===false&&state.entry?.ariaDisabled==='false'&&state.pin?.disabled===false&&state.nextPage?.disabled===false&&state.refresh?.disabled===false&&state.close?.disabled===false,state);
  await evaluate(`(() => {const f=window.heldSearch;f.value='foot';f.setSelectionRange(2,2);f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'t'}));})()`);
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(pendingStatus)} && window.actions.length===1`);
  state=await seen();
  check('pending query preserves field and disables stale entry',state.query==='foot'&&state.selectionStart===2&&state.selectionEnd===2&&state.status===pendingStatus&&state.live==='off'&&state.focused&&state.sameField&&state.entry?.disabled===true&&state.entry?.ariaDisabled==='true'&&state.pin?.disabled===true&&state.pin?.ariaDisabled==='true'&&state.nextPage?.disabled===true&&state.nextPage?.ariaDisabled==='true'&&state.refresh?.disabled===false&&state.close?.disabled===false&&exact(state.actions,[queryAction]),state);
  await evaluate(`['entry:org.example.Foot','pin:org.example.Foot','control:page-next'].forEach(id=>document.querySelector('[data-surface-control="'+id+'"]').click())`);
  state=await seen();
  check('disabled entry, pin and page clicks emit no additional action',exact(state.actions,[queryAction]),state);
  await evaluate(`(() => {const f=window.heldSearch;f.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true,data:''}));f.value='foot漢';f.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'漢'}));})()`);
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing') === 'true' && document.querySelector('[data-surface-field="control:search"]')?.value === 'foot漢'`);
  state=await seen();
  check('synthetic preedit holds focus and blocks actions',state.query==='foot漢'&&state.focused&&state.sameField&&state.composing==='true'&&state.entry?.disabled===true&&state.refresh?.disabled===true&&state.close?.disabled===true&&exact(state.actions,[queryAction]),state);
  await evaluate(`(() => {const f=window.heldSearch;f.value='foot';f.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:''}));})()`);
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing') === 'false' && document.querySelector('[data-surface-field="control:search"]')?.value === 'foot'`);
  state=await seen();
  check('cancel restores pending draft and recovery affordances',state.status===pendingStatus&&state.focused&&state.sameField&&state.entry?.disabled===true&&state.refresh?.disabled===false&&state.close?.disabled===false&&exact(state.actions,[queryAction]),state);
  await evaluate(`window.heldSearch.setSelectionRange(2,2)`);
  await sendFrame(frame('2', 'foot', afterStatus));
  await until(`document.querySelector('.surface-popup')?.dataset.publication === '2' && document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(afterStatus)}`);
  state=await seen();
  check('matching publication restores current entry and focus',state.query==='foot'&&state.selectionStart===2&&state.selectionEnd===2&&state.status===afterStatus&&state.focused&&state.sameField&&state.entry?.disabled===false&&state.entry?.ariaDisabled==='false'&&state.pin?.disabled===false&&state.nextPage?.disabled===false&&exact(state.actions,[queryAction]),state);
  // Outgoing port is captured by the isolated harness; no native host is wired.
  await evaluate(`document.querySelector('[data-surface-control="entry:org.example.Foot"]').click()`);
  await until(`window.actions.length===2`);
  state=await seen();
  const currentEntryAction = { surface: 'popup', surfaceProtocol: 2, kind: 'surface-action', publication: '2', lease: '7', id: 'entry:org.example.Foot' };
  check('current enabled entry emits exact current action envelope',exact(state.actions,[queryAction,currentEntryAction]),state);
}
