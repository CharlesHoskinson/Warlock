-- QA-only source draft. Root must compile in the process-custody test component.
-- These tests exercise the private Owner implementation; they do not certify
-- caller single-writer ownership, stop linearization, native or VM behavior.
module TerraSecurityUnborrowedAbortControls (runUnborrowedAbortControls) where

import Control.Monad (unless)
import Data.IORef (modifyIORef', newIORef, readIORef)
import qualified Warlock.Capture.Process.Owner as O

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("unborrowed-abort: " ++ label)))

freshBeginning :: IO (O.Owner, O.Pending)
freshBeginning = do
 owner <- O.newOwner
 began <- O.begin owner
 pending <- O.newPending
 retained <- O.retainPending owner pending
 check "fresh beginning and exact pending installed" (began && retained)
 pure (owner, pending)

runUnborrowedAbortControls :: IO ()
runUnborrowedAbortControls = do
 -- Positive exact pending: no borrow, input, process or native evidence.
 (clean, pending) <- freshBeginning
 accepted <- O.tryAbortUnborrowed clean pending
 status <- O.status clean
 missing <- maybe True (const False) <$> O.ownerPending clean
 repeated <- O.tryAbortUnborrowed clean pending
 check "only exact clean beginning aborts once" (accepted && status == O.Available && missing && not repeated)

 -- A different Pending never authorizes clearing the real pending slot.
 (mismatch, actual) <- freshBeginning
 foreignPending <- O.newPending
 refusedMismatch <- O.tryAbortUnborrowed mismatch foreignPending
 stillStarting <- O.status mismatch
 recoveredActual <- O.tryAbortUnborrowed mismatch actual
 check "mismatch retains exact pending" (not refusedMismatch && stillStarting == O.Starting && recoveredActual)

 -- An already-started marker is evidence of an attempted operation, even if
 -- there is no PID, descriptor or visible child yet. Preserve the pending.
 (started, marked) <- freshBeginning
 firstStart <- O.pendingStart marked
 refusedStarted <- O.tryAbortUnborrowed started marked
 startedPhase <- O.status started
 stillPending <- maybe False (const True) <$> O.ownerPending started
 check "started pending cannot be cleared as unborrowed" (firstStart && not refusedStarted && startedPhase == O.Starting && stillPending)

 -- A retained release action is evidence of a borrowed capability. Refusal
 -- must neither execute nor silently drop it; the test invokes it explicitly.
 (borrowed, borrowedPending) <- freshBeginning
 calls <- newIORef (0 :: Int)
 O.retainBorrow borrowed (modifyIORef' calls (+1))
 refusedBorrow <- O.tryAbortUnborrowed borrowed borrowedPending
 before <- readIORef calls
 borrowedPhase <- O.status borrowed
 O.releaseBorrows borrowed
 after <- readIORef calls
 check "retained borrow survives refusal" (not refusedBorrow && borrowedPhase == O.Starting && before == 0 && after == 1)

 -- Existing issue history is evidence. A failed check cannot erase it.
 (issued, issuedPending) <- freshBeginning
 O.pendingRecordIssue issuedPending "fixture-uncertainty"
 refusedIssue <- O.tryAbortUnborrowed issued issuedPending
 issuePhase <- O.status issued
 issues <- O.pendingIssues issuedPending
 check "pending issue history survives refusal" (not refusedIssue && issuePhase == O.Starting && "fixture-uncertainty" `elem` issues)
