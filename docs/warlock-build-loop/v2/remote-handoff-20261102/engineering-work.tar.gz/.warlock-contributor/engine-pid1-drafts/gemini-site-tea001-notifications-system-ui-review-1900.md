# Source Review: Connecting GUI Beauty & Usable MVP to `ELM-TEA-001` Type Repair (`Notifications`, `SystemMenu`, `ReconciliationFrame.Proof`, Website & Beta Drafts)

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Wave / Cutoff**: `2026-11-01T19:00Z` -> `2026-11-01T19:35:00Z` (`warlock-20261031-setup`)
- **Scope**: Source-only UI, label, focus/IME, and single-policy-authority review of pending notifications and system states versus existing website/beta drafts, plus companion single-file patch `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/Tea001ReconciliationFrameProofAdt.patch` (`sha256:ae9b2647397460f80ff9e835132ac842fea199d1a4458abe2e8a7dd99f96cc2b`) and proportional QA worker `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/RetirementProofReplay.elm` (`sha256:eebc71f1f8c13b1baaa882c74a52cd42d5980edc0277053f7f5c9a080466c66b`; Root-copied pre-import-trim snapshot `sha256:32e713897345bb87ecce28cb9a1971bfc5db8380b75061770973a9e0974bfb9f`, identical 20 named checks).
- **Delivery Posture**: Canonical product/QA files and foreign-dirty `site/src/SiteMain.elm` (`sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`) remain untouched. Historical ledger counts (`15 / 242` whole requirements, `39 / 417` scenarios), original deadlines `D`, failed evidence, `HOSTSTOP2`, and `nativeOperations: []` are preserved. Component compiler/replay results do not close whole `ELM-TEA-001`, `ELM-TEA-002`, or `ELM-UI-005` without Root's full typed checks, independent literal fixtures, and required native acceptance.

---

## 1. Audited Canonical & Draft Inputs (SHA-256)

| File | SHA-256 / Status |
| :--- | :--- |
| `implementation/warlock/src/Notifications.elm` | `b37bff9f104d80eb1d1ea99f297c4d859b9d5744d7b0c05f6c89fa51581bc244` |
| `implementation/warlock/src/SystemMenu.elm` | `cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054` |
| `implementation/warlock/src/Surface.elm` | `c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb` |
| `implementation/warlock/src/OutcomeAnnouncements.elm` | audited lines `1-116` (untouched canonical) |
| `implementation/warlock/src/SurfaceController.elm` | `2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998` |
| `implementation/warlock/src/ReconciliationFrame.elm` | `c44fa50ac86d528b35959d50fc4d85bd9d8983c1e866fdda01ad1854f465004e` |
| `implementation/warlock/src/ReconciliationTracking.elm` | `84482d1bb84160e3bd9e026b2043635c35b76422d6e9066f703411f784b29bf9` |
| `implementation/warlock/src/Popup.elm` | `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58` |
| `implementation/warlock/src/HttpPopup.elm` | `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354` |
| `implementation/warlock/src/SurfaceSnapshot.elm` | `58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7` |
| `site/src/SiteMain.elm` | `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (foreign-dirty, untouched) |
| `.warlock-contributor/engine-pid1-drafts/SiteMainTeaContractPublished31a92.diff` | `9e4961eb6c2c1c35172fe5cadbfa13e6722adf56a277c9d06abe05df284fb2a1` |
| `.warlock-contributor/engine-pid1-drafts/AppOnlyHierarchyEmptyState.patch` | audited lines `1-324` (`gemini-gui` beta empty-state/hierarchy draft) |
| `.warlock-contributor/engine-pid1-drafts/terra-security-tea001-notifications.patch` | audited lines `1-250` (`terra-security` `Notifications` ADT draft) |
| `.warlock-contributor/engine-pid1-drafts/Tea001ReconciliationFrameProofAdt.patch` | `ae9b2647397460f80ff9e835132ac842fea199d1a4458abe2e8a7dd99f96cc2b` (`gemini-site` `Proof` ADT draft) |

---

## 2. Pending Notifications (`Notifications.elm`) — Type Repair vs Visible Labels, Focus/IME & Single Authority

### 2.1 Stored Finite Types & Exact Wire Bijections
In `Notifications.elm:10-13`, three finite protocol/lifecycle vocabularies are stored in `Model`:
1. **`Entry.state`** (`Notifications.elm:10, 27`): 8 wire values (`"live"`, `"expired"`, `"invoked"`, `"dismissed"`, `"closed"`, `"disconnected"`, `"unknown"`, `"unavailable"`) -> `EntryState` (`EntryLive | EntryExpired | EntryInvoked | EntryDismissed | EntryClosed | EntryDisconnected | EntryUnknown | EntryUnavailable`).
   - Decoder invariant (`Notifications.elm:35`): `entry.state == EntryLive || List.isEmpty entry.actions` continues to enforce at the boundary that non-live history entries never carry actionable buttons.
2. **`Target.verb`** (`Notifications.elm:12, 51-59`): 2 wire values (`"invoke"`, `"dismiss"`) -> `Verb` (`Invoke | Dismiss`).
3. **`outcome.status`** (`Notifications.elm:13, 70-76`): 3 wire values (`"Dispatched"`, `"Refused"`, `"Unknown"`) -> `OutcomeStatus` (`OutcomeDispatched | OutcomeRefused | OutcomeUnknown`).

### 2.2 Verification of `terra-security-tea001-notifications.patch` UI, Focus & ARIA Invariants
Reviewing `terra-security-tea001-notifications.patch` against `Surface.elm`, `OutcomeAnnouncements.elm`, `SurfaceSnapshot.elm`, `SurfaceRenderer.elm`, `Presentation.elm`, `Popup.elm`, and `HttpPopup.elm`:

- **Control Identity, `domId`, `focusOnly` & Wire Intent Preservation (PASS)**:
  - `Notifications.identity` (`Notifications.elm:53-54`) formats `"notification:" ++ UInt64.string value.service ++ ":" ++ UInt64.string value.incarnation ++ ":" ++ verbName value.verb ++ ":" ++ value.action`.
  - `Notifications.encodeIntent` (`Notifications.elm:55`) encodes `("verb", E.string (verbName value.verb))`.
  - Because `verbName` maps `Invoke -> "invoke"` and `Dismiss -> "dismiss"`, every `control.id`, `Desktop.key` `domId`, `Notifications.focusedIdentity` (`Surface.elm:530`), `SurfaceSnapshot.elm:48` `focusOnly` admission check (at most one disabled `focusOnly` control, permitted exclusively when `mode == "notifications"`), and `Presentation.focusTarget` `(surface, publication, lease, domId)` check (`Presentation.elm:33-35`) remain **100% byte-identical**.
- **Exact Visible Labels, `detail` Substrings & Screen-Reader Copy (PASS)**:
  - Taskbar opener badge (`Surface.elm:423`): `"Notifications"` or `"Notifications · <count>"` counting `entry.state == Notifications.EntryLive`.
  - Summary row (`Surface.elm:175, 179`): `detail` remains `"Live"` for `EntryLive` and `"History · " ++ Notifications.entryStateName entry.state` (e.g. `"History · expired"`) for non-live entries, rendered inside `<p class="notification-text" data-notification-content="...:summary">` (`SurfaceRenderer.elm:120-121`).
  - Retained focused placeholder when target retires or is pending (`Surface.elm:180, 184-185`): `ariaLabel = selected.label ++ "; unavailable"`, `detail = state ++ " · Action unavailable"`, `enabled = False`, `focusOnly = True` (`Surface.elm:530`), keeping keyboard focus anchored without fabricating action authority until the user navigates away (`NotificationRelevanceReplay.elm:66-67, 77`).
  - Session DND & Critical Interruption toggles (`Surface.elm:189-190`): `detail` prefixes `"On · ..."` vs `"Off..."` remain unchanged, preserving `SurfaceRenderer.elm:106, 113, 129` `settingsToggle` `aria-pressed` and `aria-current` derivation (`String.startsWith "On" item.detail`).
  - All 7 user-facing status notices (`Notifications.elm:16, 48, 63, 75-76, 85`) and `OutcomeAnnouncements.elm:90, 94, 100` single-root polite/assertive announcements remain byte-for-byte unchanged.
- **IME & Focus Safety (PASS)**:
  - Opening snapshot read (`Desktop.elm:1030-1031`) emits `[Focus (key next "notifications:close")]` only when `notificationsOpen && notificationsOpening && not failed`; background `notification-update` (`:1038-1039`) and `notification-outcome` (`:1048-1049`) emit `[]` focus effects. `HttpPopup.elm:54` suppresses `Browser.Dom.focus` whenever `current.popup.composition /= Popup.Idle`.

### 2.3 Real Compiler-Blocking Defect Caught in `terra-security-tea001-notifications.patch` (Plus Remaining Boundary Note)
1. **Missed QA Caller (`NotificationRelevanceReplay.elm:38`) — Compiler Blocker Caught & Reported**:
   - `implementation/warlock/qa/NotificationRelevanceReplay.elm:38` constructs a literal `Notifications.Target` record:
     ```elm
     target = {service=counter "9",id=counter "1",incarnation=counter "1",producer=":1.7",verb="invoke",action="open"}
     ```
     and passes it to `Desktop.NotificationAction stamp target` (`:39`) and `outcome.target == target` (`:70`).
   - With `Target.verb : Verb`, `verb = "invoke"` fails Elm type-checking unless updated to `verb = Notifications.Invoke`. Alerted `terra-security` immediately (`01M6C878N9SWPK4H960WE7TMR7`); `terra-security` fixed `NotificationRelevanceReplay.elm:38` in v2 `terra-security-tea001-notifications.patch` (`sha256:2fd0029a0151cab87dfed7245ebe76536f3f66c58a9fcaaaeee0ef87d3a2ba04`, `01M6C87XE2QYAC59F00B521J99`), which Root subsequently integrated (`01M6C8BZ4H0MXGRJ2KMM9FGEJT`).
   - **Slice Path Note for Root**: Integrating the `Notifications` patch into `.warlock-contributor/tea-model-effects.json` requires `contributor extend` for `implementation/warlock/src/Notifications.elm`, `implementation/warlock/src/Surface.elm`, `implementation/warlock/src/OutcomeAnnouncements.elm`, `implementation/warlock/qa/NotificationsReplay.elm`, and `implementation/warlock/qa/NotificationRelevanceReplay.elm`. (In `qa/tea-contract-cases.cjs:52`, all 32 current cases have `notifications.focused = none()`, `outcome = none()`, `snapshot = none()`, `pending = none()`, `spent = empty()`, so zero existing JS literal cases break.)
2. **Remaining Boundary Signature Note (`Desktop.elm:1042-1049` -> `Notifications.receiveReason`)**:
   - `Notifications.receive` / `receiveReason` in `terra-security-tea001-notifications.patch` still accept `status : String` and `reason : String` parameters (`outcomeStatus : String -> Maybe OutcomeStatus`), while `Desktop.elm:1043-1044` decodes `"status"` as `D.string` and `"reason"` via finite membership `["", "expired", "changed", "unavailable", "already-handled"]`.
   - Stored `Model` state is fully typed (`outcome.status : OutcomeStatus`, `expired : Bool`), and invalid `status` strings remain a pure no-op (`_ -> model`), matching how `Desktop.elm` currently calls `Pins.receive` (`:1100-1101`). If Root chooses to type reducer receipt arguments end-to-end across child modules, `Desktop.elm:1043-1044` can decode `Notifications.OutcomeStatus` and `RefusalReason` directly in the strict incoming decoder.

---

## 3. Pending System States (`SystemMenu.elm`) — Type Repair Boundaries & UI/Label Invariants

Auditing `SystemMenu.elm:1-85`, `Surface.elm:140-168, 423, 452`, `Desktop.elm:1005-1022`, `SurfaceRenderer.elm:122-123`, and `SystemMenuReplay.elm:1-75`:

1. **Already-Typed Operation Authority**:
   - `SystemMenu.Operation` (`Volume | Mute | Network | Suspend | Reboot | PowerOff | Lock | Logout`, `SystemMenu.elm:7`) is already a custom type with total wire `code` (`:37-45`) and UI `name` (`:46-54`: `Reboot -> "Restart"`, `PowerOff -> "Shut down"`, `Lock -> "Lock session"`, `Logout -> "Log out"`).
   - Desired UI confirmation (`Desktop.Model.systemMenuConfirmation : Maybe SystemMenu.Intent`) and in-flight read correlation (`systemMenuExpected : Maybe Counter`) are kept strictly separate from observed `SystemMenu.Snapshot` and pending native request `SystemMenu.Model.pending : Maybe { request : Counter, intent : Intent }`.
2. **Closed Finite Capabilities vs Open Bounded Host Strings (Critical Distinction)**:
   - **Closed Finite Capabilities (Safe ADT Candidates)**:
     - `Snapshot.network.permission` (`SystemMenu.elm:12, 28`): decoder-restricted to `["yes", "no", "auth"]` (`NetworkPermission = NetworkYes | NetworkNo | NetworkAuth`).
     - `Snapshot.power.{suspend, reboot, poweroff}` (`SystemMenu.elm:13, 29`): decoder-restricted to `["yes", "no", "na", "challenge"]` (`PowerCapability = PowerYes | PowerNo | PowerNotApplicable | PowerChallenge`).
     - `SystemMenu.receive` `status` (`Desktop.elm:1016`, `SystemMenu.elm:76`): restricted to `["Committed", "Submitted", "Refused", "Unknown"]` (`SystemReceipt = SystemCommitted | SystemSubmitted | SystemRefused | SystemUnknown`).
   - **Open Bounded Host Observation Strings (Must Remain `String`)**:
     - `volume.label` (`bounded 128`), `network.state` (`bounded 32`), `session.name` (`bounded 128`), and `session.state` (`bounded 32`, where `:68` checks `v.state /= "closing"` for `Logout` eligibility while `Surface.elm:161` renders raw `current.state` in `"Session " ++ current.name ++ " · " ++ current.state ++ (if current.locked then "; locked" else "; unlocked")`). Converting `network.state` or `session.state` into closed Elm enums without a closed native wire guarantee would break valid host state descriptions.
3. **Exact Visible Label & Non-Replay Invariants Any `SystemMenu` ADT Conversion Must Preserve**:
   - **Network state row (`Surface.elm:154`)**: `"Network " ++ (if current.enabled then "enabled" else "disabled") ++ " · " ++ current.state ++ (if current.permission=="no" then "; changes unavailable" else "")`. Note that `"auth"` does **not** append `"; changes unavailable"` and remains actionable (`List.member v.permission ["yes", "auth"]` at `SystemMenu.elm:63`).
   - **Power state row (`Surface.elm:155-158`)**: `capability value = if value=="yes" then "available" else if value=="challenge" then "authorization required" else "unavailable"` — both `"no"` (`PowerNo`) and `"na"` (`PowerNotApplicable`) **must** render `"unavailable"` in `"Power · suspend ..., restart ..., shutdown ..."`, while `SystemMenu.supported` (`:64-66`) enables `Suspend`/`Reboot`/`PowerOff` for `"yes"` and `"challenge"`.
   - **Pending & Unknown Non-Replay Notices (`SystemMenu.elm:72, 78-85`, `Surface.elm:452`)**:
     - Pending: `"<Name>: waiting for native result…"`; `pending /= Nothing` blocks duplicate proposals (`:71`) and disables change buttons (`Surface.elm:147`).
     - Receipt suffixes (`:78`): `Committed -> ": change observed."`, `Submitted -> ": request accepted by the native service."`, `Refused -> ": refused or no longer available. Refresh before choosing again."`, `Unknown -> ": not confirmed. Refresh only reads state; the request will not be repeated."` (retaining `pending` until a newer snapshot revision reconciles at `:84-85` with `"System state refreshed. The previous request will not be repeated."`).
   - **Renderer `:state` Paragraph Contract (`SurfaceRenderer.elm:122-123`)**: `system:volume:state`, `system:network:state`, `system:power:state`, `system:session:state`, and `system:confirmation:state` match `String.endsWith ":state" item.identity` in `snapshot.mode == "system"` and render as `<p class="notification-text" data-system-content="...">` rather than interactive `<button>` controls; their `:state` identity suffix must never change.
4. **Peer Review of `sol-system-menu-permissions-1909.patch` (`sol-docs`)**:
   - Verified `git apply --check` exits `0` cleanly against post-wave `Surface.elm` (even after `Notifications` and `JumpList` integration), and exhaustive `rg` across `src/` and `qa/*.elm` confirms zero missed `SystemMenu` callers (`JumpListReplay.elm:47`, `FilesReplay.elm:49`, `PointerOwnershipReplay.elm:56` only call `Desktop.OpenSystemMenu`).
   - Preserves every UI/label invariant above: `NetworkPermission` (`NetworkYes | NetworkNo | NetworkAuth`) appends `"; changes unavailable"` only for `NetworkNo` (`Surface.elm:154`), `PowerCapability` (`PowerYes | PowerNo | PowerUnavailable | PowerChallenge`) maps both `PowerNo` and `PowerUnavailable` (`"na"`) to `"unavailable"` via `powerCapabilityLabel` (`Surface.elm:155-158`), and open bounded host strings (`volume.label`, `network.state`, `session.name`, `session.state`) remain `String`.
5. **Peer Review of `terra-browser-settings-popup-literal.cjs` (`sha256:c6a0422eb534b9b8ac6e140892ebd38ef02c18c361900d49a7d176ab316a2e84`)**:
   - Verified all 43 rendered `popup` controls (`23` header/motion/theme/scale/save/shortcut-notice rows + `3 × 6` route rows + `2` trailing save/refresh rows, `control:close` through `settings:shortcuts:refresh`) byte-for-byte against `Surface.elm:193-237`, `Motion.elm:80` (`snapshot == Nothing` delegates to `MotionPreferences.initial.notice == "Reading motion preference…"`), `MotionPreferences.elm:12, 36-40`, and `ShortcutPreferences.elm:13-51` (`defaults = Undecided` yields `detail == ""` on `keep`/`default`/`alternate` rows and `"Loading shortcut choices…"` on `settings:shortcuts:notice:state`).

---

## 4. Comparison Against Website (`SiteMain.elm`) & Beta GUI Drafts (`AppOnlyHierarchyEmptyState.patch`)

### 4.1 Website Showcase & Causality Specimens (`site/src/SiteMain.elm` + `SiteMainTeaContractPublished31a92.diff`)
- **`SurfaceNotifications` (`site/src/SiteMain.elm:384-400`)**:
  - Declares `elmAuthority = "History presentation, Do Not Disturb toggle state, and single-surface accessible announcement routing."` and `hostObservation = "Desktop notification service snapshots, action invocation receipts, and dismissal settlements."`
  - Matches production `Notifications.elm` + `OutcomeAnnouncements.elm` + `Popup.elm:76` (`Announcement.receive True` in Popup only vs `False` in Bar) with zero drift under `EntryState`/`Verb`/`OutcomeStatus` ADT conversion.
- **Interactive Causality Specimen (`site/src/SiteMain.elm:70-73, 1344-1395`)**:
  - Already uses a closed custom type `type OutcomeSample = SampleObserved | SamplePending | SampleUnknown | SampleRefused` with explicit preview badge `"Model preview · Component checks active; native ELM-UI-007 keyboard/AT gate OPEN"` (`:1391`).
  - Preserves the exact 4-way semantic distinction used across product domains (`Notifications`: `OutcomeDispatched` / `OutcomeUnknown` / `OutcomeRefused` + observed `Snapshot`; `SystemMenu`: `Submitted` vs `Committed` vs `Unknown` vs `Refused` + observed `Snapshot`) without collapsing intent, receipt, and observed state into a boolean.
- **`SiteMainTeaContractPublished31a92.diff` (`sha256:9e4961eb6c2c1c35172fe5cadbfa13e6722adf56a277c9d06abe05df284fb2a1`)**:
  - Keeps `15 / 242` whole and `39 / 417` scenario counts unchanged, separates `ELM-ARC-002` current-port partial status from `ELM-UI-005` QMP-injected software-VM search snapshot (`31a92dce9`), and describes `ELM-TEA-001` / `ELM-TEA-002` as active WIP1 without claiming whole-EARS closure.

### 4.2 Beta GUI Hierarchy & Empty-State Draft (`AppOnlyHierarchyEmptyState.patch`)
- **Non-Interference with `Notifications`, `SystemMenu` & IME Composition**:
  - `AppOnlyHierarchyEmptyState.patch` (`Popup.elm:8`, `SurfaceRenderer.elm:38-100`) gates `queryConfirmed` on `model.pendingQuery == Nothing && not (isComposing model)` so IME preedit never flashes a false `"No matching applications"` card, and scopes `popupEmptyEntries` strictly to `snapshot.mode == "closed"` and `snapshot.mode == "applications"`. `Notifications` (`mode == "notifications"`) and `SystemMenu` (`mode == "system"`) controls, `:state` / `:summary` / `:body` paragraphs, `detail` strings, and `focusOnly` buttons are completely unaffected.
  - `SurfaceTheme.popupStatusStyles` (`AppOnlyHierarchyEmptyState.patch:120-133`) highlights `"refused"` / `"unavailable"` substrings in `snapshot.status`, which remain preserved by all `Notifications` and `SystemMenu` refusal/unavailable notices.
- **Single-Policy-Authority Caution for Future Integration (`SurfaceRenderer.elm:51-97` in `AppOnlyHierarchyEmptyState.patch`)**:
  - In `AppOnlyHierarchyEmptyState.patch`, `SurfaceRenderer.elm` inspects rendered prose strings in `snapshot.status` (`"Applications connected. Window controls unavailable."`, `"Connection lost. Reconnect to continue."`, `"Loading applications…"`, `"Application list unavailable. Refresh to try again."`, `"No matching applications. Change your search or Refresh."`) to synthesize `popupHeadingText = "Application workspace"` and `popupEmptyEntries`.
  - To keep **one policy authority** (`ELM-TEA-001`) when Root later considers visual empty-state cards, empty-state identity should come from explicit `Surface.elm` `:state` controls (matching `jump:empty:state`, `files:location:state`, and `system:*:state` in `Surface.elm:125, 135, 143`) or an explicit `SurfaceSnapshot` field rather than reverse-parsing `snapshot.status` prose in `SurfaceRenderer`.

---

## 5. Companion Patch Summary: `Tea001ReconciliationFrameProofAdt.patch`

- **Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/Tea001ReconciliationFrameProofAdt.patch`
- **SHA-256**: `ae9b2647397460f80ff9e835132ac842fea199d1a4458abe2e8a7dd99f96cc2b`
- **Target**: `implementation/warlock/src/ReconciliationFrame.elm` (`c44fa50ac86d528b35959d50fc4d85bd9d8983c1e866fdda01ad1854f465004e` -> `5f9480ab13609f26a3f57f37431e9eb29c658b1c009b463321e0f277d37b8ac5`, `git apply --check` exit `0` + forward/reverse round-trip verified).
- **Conversion**:
  - `Proof.kind : ProofKind` (`BindingRetirement`, wire `"binding-retirement"`)
  - `Proof.operation : RetirementOperation` (`Observe | Retire`, wire `"observe" | "retire"`)
  - `Proof.grantState : GrantState` (`Retired`, wire `"Retired"`)
  - Exposes `ProofKind(..)`, `RetirementOperation(..)`, `GrantState(..)`, `proofKindName`, `retirementOperationName`, `grantStateName`.
- **Protocol, Authority & Replay Impact**:
  - **Wire & Decoder Invariants**: Preserves exact 9-field `strict` check, `exactInt 3`, `exactString "binding-retirement"`, `exactInt 1`, `"observe" | "retire"`, `Binding.decoder`, `positive` counters, `exactString "Retired"`, and identical `D.fail` messages.
  - **Downstream Callers**: Only `ReconciliationTracking.elm` and `SurfaceController.elm` import `ReconciliationFrame` across `src/` and `qa/*.elm`. Neither reads `.kind`, `.operation`, or `.grantState` as `String`; structural `==` / `/=` (`accepted.proof /= proof` at `ReconciliationTracking.elm:76`, `informational == Just proof` at `:77`, `List.member` at `SurfaceController.elm:84`) continues to compare all 9 `Proof` fields including `Observe` vs `Retire`. Outbound `"reconciliation-ready"` frames (`SurfaceController.elm:85, 131`) are byte-identical.
  - **`TeaContractReplay` / `tea-contract-cases.cjs` Impact**: All 32 current cases in `qa/tea-contract-cases.cjs` have `recovery: { slots: empty(), legacy: empty(), informational: none() }` (`tea-contract-cases.cjs:73`), so zero current cases change. Any future `tea-contract-cases.cjs` case that populates a retained `Proof` inside `recovery.slots` or `recovery.informational` will represent those fields in unoptimized debug Elm JS as `{ $: 'BindingRetirement' }`, `{ $: 'Observe' }` / `{ $: 'Retire' }`, and `{ $: 'Retired' }`.
  - **Contributor Slice & Proportional QA Worker (`RetirementProofReplay.elm`)**:
    - Root integrated `Tea001ReconciliationFrameProofAdt.patch` into `implementation/warlock/src/ReconciliationFrame.elm` (`sha256:5f9480ab13609f26a3f57f37431e9eb29c658b1c009b463321e0f277d37b8ac5`; peer-reviewed by `terra-security` in `01M6C852BMTQTXTSJW4815RW2K`).
    - Authored proportional QA worker `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/RetirementProofReplay.elm` (`sha256:eebc71f1f8c13b1baaa882c74a52cd42d5980edc0277053f7f5c9a080466c66b`, clean import trim of Root-copied `32e713897345bb87ecce28cb9a1971bfc5db8380b75061770973a9e0974bfb9f`) with 20 exact boolean checks aligned 1:1 with `terra-q-origin-typed-state.cjs` (`lines 48-59`): `observe`/`retire` typed constructor + wire-name positives, wrong kind/grant/protocol/retirementProtocol/extra/missing/operation/zero-counter/foreign-binding/context-mismatch negatives, correlated `ReconciliationTracking` release + replay-refusal, changed `Observe` vs `Retire` proof refusal (`Err "Announced proof changed"`), legacy `host-uncertain` refusal, and `SurfaceController` owning-route `"reconciliation-ready"` + unresolved-`Unknown` release checks (explicitly scoped as synthetic Elm decoder/correlation fixtures, not authenticated native proofs).
