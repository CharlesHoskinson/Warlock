# Non-GUI Held-Exec & Kernel-Probe Failure Diagnostic Plan (Preparation Draft)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Run**: `warlock-20261031-setup`
- **Scope**: **Actual non-GUI held-exec / kernel-probe failures ONLY** (`test-suite ui-engine-exec-controls` / `implementation/warlock/haskell/runtime/test-ui-engine-exec/Main.hs` `sha256: 7a5c90aec72f862a06afee78fe9d16399c2f561efe555e05f7ef7f6ddc3998b0`, plus its separate `-threaded` `--threaded-guard` control binary).
- **Hard Guardrails**:
  - Root owns all VM, compiler, and probe execution; VM is currently locked with `Foot 2095` present and **zero app GUI / Wayland window launch** (`startUnreadyEngine deadline session []` passes empty env and `engineProbe` exits before any GTK/WebKit symbol is called, while still linking the exact dynamic `webkitgtk-6.0` / `gtk-4` / `warlock-*` DSO closure from `runtime.cabal:172-181`).
  - `execveat`/`$ORIGIN` and pre-`main` `stdio` (`fd 0..2`) are **hypotheses, NOT external blockers**; run the unmodified non-GUI probe first and invoke the targeted branch below **only if an actual failure is observed**.
  - Preserve the `4.5s` original `AdmissionDeadline` (`test-ui-engine-exec/Main.hs:81-82`) and retain all raw failure artifacts outside the repository.

---

## 1. Subcase Inventory & Expected Non-GUI Execution Shape

`EngineExecControls` (compiled **without** `-threaded` and **with** `-with-rtsopts=-V0`, `runtime.cabal:181`) runs 5 isolated forked subcases (`test-ui-engine-exec/Main.hs:433-437`), plus 1 separate `-threaded` binary invocation (`--threaded-guard`, `L430`):

| Subcase Label | Entrypoint | Kernel / Custody Path Exercised (Zero GUI) |
| :--- | :--- | :--- |
| `zero-session-refused-before-namespace` | `zeroSessionCase` (`L379-390`) | Verifies `startUnreadyEngine deadline 0 []` throws `"engine session must be positive"` **before** `unshare(CLONE_NEWPID)` mutates `/proc/thread-self/ns/pid_for_children`. |
| `held-exec-session-1-and-sole-reap` | `ownedExecCase 1` (`L228-276`) | `enterPrivateNetwork` (`CLONE_NEWUSER\|CLONE_NEWNET`, `uid_map`/`gid_map`, `lo` up) -> `startUnreadyEngine` (`CLONE_NEWPID`, `fork`, `childSetupExec`, `execveat` `AT_EMPTY_PATH`) -> child `engineProbe` (`fdAbsent [0..2]`, `prepareEngine`, `/proc/1/exe`, `checkExecFdCensus`, `probeMarker`) -> parent `readProof` (`SCM_CREDENTIALS` + `engineCredentialGuard`), `checkActualImage` (`/proc/<pid>/exe` inode+SHA256), `stopEngineProcess` (`pidfd_send_signal` + `waitid(P_PIDFD)`), unrelated child `ExitFailure 42` preserved. |
| `held-exec-session-max-and-sole-reap` | `ownedExecCase maxBound` (`L435`) | Same full held-exec + sole-reaper path at `Word64` `maxBound` (`18446744073709551615`). |
| `post-proof-parent-death` | `parentDeathCase True` (`L306-352`) | After `readProof` + `checkActualImage`, supervisor `SIGKILL`s intermediate `executor`; verifies Engine `PID 1` exits (`pidfdExited`) within `4.5s` `D` (`PR_SET_PDEATHSIG` / lifeline). |
| `early-parent-death-phase-unknown` | `parentDeathCase False` (`L437`) | Supervisor `SIGKILL`s `executor` immediately after `startUnreadyEngine` returns (child phase unknown); verifies Engine `PID 1` exits within `4.5s` `D`. |
| `--threaded-guard` (separate `-threaded` build) | `threadedGuard` (`L356-375`) | Spawns `forkOS` bound OS thread (`/proc/self/task > 1`) and verifies `startUnreadyEngine` refuses with `"custody requires a single OS thread"` prior to namespace mutation. |

---

## 2. Symptom-to-Cause Diagnostic Decision Tree (Invoke ONLY on Observed Failure)

### Case A — Immediate Loader Failure Before `EngineExecControls` `main` (`exit 127` on Launch)
- **Observed Symptom**: Process exits `127` with `error while loading shared libraries: ... cannot open shared object file` before printing any subcase line.
- **Exact Cause**: Missing or moved inplace dynamic library (`libHSwarlock-{runtime,protocol,process-custody,held-document-proposal}-...-ghc9.6.7.so`) or Cabal store DSO in guest `DT_RUNPATH`.
- **Bounded Root Read-Only Check**:
  ```bash
  readelf -d "$PROBE_BIN" | grep -E 'NEEDED|RPATH|RUNPATH'
  env -i /lib64/ld-linux-x86-64.so.2 --list "$PROBE_BIN"
  ```

### Case B — Parent-Side Refusal Printed Directly on `stderr` (`isolated` `ExitFailure 1` or `ExitFailure 119`)
`isolated` (`test-ui-engine-exec/Main.hs:417`) prints `<label>: <exception>` on `stderr` before exiting `1`:

1. **`"positive variant needs nonthreaded RTS"` (`Main.hs:432`) / `"positive executable is not single OS thread"` (`Main.hs:231`) / `"custody requires a single OS thread"` (`EngineCustody.hsc:192`)**:
   - **Cause**: Built with `-threaded`, or `-with-rtsopts=-V0` omitted/overridden (`GHCRTS` env creating POSIX ticker thread).
   - **Check**: Verify `GHCRTS` is unset and `cabal list-bin` selected the non-threaded `ui-engine-exec-controls` binary (`rtsSupportsBoundThreads == False`).
2. **`"custody SIGCHLD ownership unavailable"` (`EngineCustody.hsc:199`)**:
   - **Cause**: Guest command runner/SSH wrapper launched the probe with `SIGCHLD` ignored (`SIG_IGN`) or `SA_NOCLDWAIT`.
   - **Check**: Inspect `grep '^SigIgn:' /proc/self/status` inside the guest runner environment (bit `16`, `0x0000000000010000`, must be `0`); reset `signal.signal(signal.SIGCHLD, signal.SIG_DFL)` in the launcher before exec if non-zero.
3. **`"create private UI namespaces"` (`PrivateNetwork.hsc:111`) or `"engine unshare PID"` (`EngineCustody.hsc:821`)**:
   - **Cause**: Guest user/PID namespace sysctl or LSM restriction (`EPERM` / `ENOSPC` / `EUSERS`).
   - **Check**: Read `/proc/sys/user/max_user_namespaces`, `/proc/sys/user/max_pid_namespaces`, `/proc/sys/user/max_mnt_namespaces`, and `/proc/sys/kernel/unprivileged_userns_clone` (if present).
4. **Subcase child exits `ExitFailure 119` (`EngineCustody.hsc:801` `failOwned`)**:
   - **Cause**: `unshare(CLONE_NEWPID)` succeeded at `L821`, then `forkProcess`, `openPidfd` (`SYS_pidfd_open`), `verifyChild`, or `releaseOnce` threw before `EngineProcess` returned.
   - **Check**: Capture single-parent syscall trace (`-e trace=unshare,clone,pidfd_open,openat,close`) to read exact `errno`.

### Case C — `"EOF before probe marker"` (`Main.hs:187`) or `"engine exited before parent death stimulus"` (`Main.hs:342`)
Because child `0, 1, 2` are closed (`CLOSE_RANGE_CLOEXEC`) and then bound to `/dev/null`, **all three child-side early exits** surface in the parent as `"EOF before probe marker"` on `channel`:
- **Child exit `127`**: Post-`execveat` `ld-linux-x86-64.so.2` failure (e.g. if `DT_RUNPATH` contained `$ORIGIN` -> `"/dev/fd"` under `AT_EMPTY_PATH`, or an unmounted DSO path inside `MS_REC | MS_PRIVATE`).
- **Child exit `121`**: Pre-`execveat` C setup failure in `childSetupExec` (`EngineCustody.hsc:560-607`).
- **Child exit `120`**: Post-`execveat` Haskell `engineProbe` / `prepareEngine` failure (`test-ui-engine-exec/Main.hs:427-429`).

#### Bounded 1-Shot Diagnostic Command (ONLY When Case C Fails)
Run **only** to record the failing child's exit code and last syscall into an outside-repo evidence directory (never treat a `ptrace`-attached run as a passing acceptance receipt, because `PTRACE_SEIZE` alters `TracerPid` and `wait` stop delivery):
```bash
strace -ff -s 96 -o "$EVIDENCE_DIR/heldexec-probe" \
  -e trace=unshare,mount,prctl,capset,close_range,fcntl,execveat,fstat,newfstatat,statx,openat,dup2,read,sendmsg,sendto,exit_group \
  "$PROBE_BIN"
```
Then classify the child trace file (`heldexec-probe.<child_host_pid>`) by its final `exit_group(...)`:

1. **`exit_group(121)` -> Pre-`execveat` `childSetupExec` (`EngineCustody.hsc:560-607`)**:
   - Failing `mount("proc", "/proc", "proc", MS_NOSUID|MS_NODEV|MS_NOEXEC, NULL) = -1 EPERM` (`L586`): guest launcher unit has masked `/proc/*` submounts (`ProtectKernelTunables=`/`ReadOnlyPaths=`) triggering Linux `mnt_already_visible` `EPERM` inside the user namespace. Run from an unmasked user scope matching the real session.
   - Failing `mount(NULL, "/", NULL, MS_REC|MS_PRIVATE, NULL) = -1 EINVAL` (`L583`): `/` is not a mount point in guest environment.
   - Failing `close_range(0, ~0U, CLOSE_RANGE_CLOEXEC) = -1` (`L592`): seccomp filter blocking `SYS_close_range` (`436`).
   - Failing `execveat(image, "", ..., AT_EMPTY_PATH) = -1` (`L606`): `ENOENT` if `$PROBE_BIN` was a `#!` wrapper script instead of the real ELF binary (`FD_CLOEXEC` + `BINPRM_FLAGS_PATH_INACCESSIBLE`); `EACCES`/`ENOEXEC` if filesystem mounted `noexec`.

2. **`exit_group(127)` after `execveat(...) = 0` -> Post-`execveat` Dynamic Linker**:
   - Inspect `openat(...) = -1 ENOENT` lines between `execveat(...) = 0` and `exit_group(127)`:
     - Lookups under `"/dev/fd/..."` confirm the `$ORIGIN` + `AT_EMPTY_PATH` hypothesis -> rebuild/link with absolute `DT_RUNPATH` only.
     - Missing `libHSwarlock-*.so` path -> stage/preserve exact `build-dynamic/dist` & `store` DSO paths.

3. **`exit_group(120)` after `execveat(...) = 0` -> Post-`execveat` `engineProbe` / `prepareEngine` (`test-ui-engine-exec/Main.hs:122-156`, `EngineEntrypoint.hs:138-176`)**:
   - Match the last syscall before `exit_group(120)`:
     - **`fstat(0..2)` / `newfstatat(0..2)` returned `0` (NOT `-1 EBADF`) before `prctl(PR_SET_PDEATHSIG)` (`Main.hs:127-128`)**: confirms the pre-`main` `stdio` hypothesis (a DSO constructor or `hs_init_ghc` opened `fd 0` while `0..2` were closed). Inspect the preceding `openat`/`eventfd2`/`pipe2`/`timerfd_create` in the same trace file to identify the exact caller before choosing a post-`execveat` C shim.
     - **`read(life, ..., 1)` did not return `-1 EAGAIN` (`EngineEntrypoint.hs:126-131, 152`)**: lifeline pipe closed early or inherited blocking mode.
     - **`openat("/proc/self/status")` followed by `exit_group(120)` (`EngineEntrypoint.hs:158-166`)**: `Pid: 1`, `NoNewPrivs: 1`, or `CapInh/CapPrm/CapEff/CapBnd/CapAmb == 0` check failed — dump `/proc/sys/kernel/cap_last_cap` vs `CapBnd`.
     - **`newfstatat("/proc/1/exe")` (`Main.hs:138-139`)**: `/proc` mount did not reflect child PID namespace.
     - **`openat("/proc/self/fd")` (`Main.hs:101-111` `checkExecFdCensus`)**: an unexpected open descriptor (`notElem [0,1,2,rpc,life]`) survived `execveat` (e.g., a DSO constructor opened a persistent FD `>= 3` post-`execveat`!). The trace's `openat`/`socket`/`eventfd2` calls post-`execveat` identify the exact library and FD number!

### Case D — Post-Marker Parent Verification Failure (`Main.hs:181-202, 261-274, 347`)
1. **`"SCM PID differs from owned child"` / `"SCM UID/GID differs"` / `"engine credential refused"` (`Main.hs:181-185`)**:
   - Compare `enginePid process` and `engineExpectedIds process` against `/proc/<enginePid>/status` `NSpid`/`Uid`/`Gid`.
2. **`checkActualImage` `/proc/<enginePid>/exe` failure (`Main.hs:193-202`)**:
   - `Permission denied` (`EACCES`): check guest `sysctl fs.suid_dumpable` and LSM logs (`dmesg` / `journalctl -k -n 50` by Root).
   - `"selected executable inode mismatch"`: binary file was overwritten in place during test instead of atomic new path.
3. **`"owned PID1 did not stop and reap under D"` (`Main.hs:262`) or `"pidfd exit not observed by original deadline"` (`Main.hs:302`)**:
   - Check guest wall/monotonic load (`4.5s` `D` budget exhausted during dynamic linking of WebKit/GTK DSOs on cold page cache; `stopCustody` requires `remaining > 200_000 us` at `EngineCustody.hsc:257`).
