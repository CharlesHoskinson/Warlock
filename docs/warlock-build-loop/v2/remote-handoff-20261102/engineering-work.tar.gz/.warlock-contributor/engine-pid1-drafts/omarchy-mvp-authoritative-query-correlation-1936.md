# Root-Ready Authoritative Elm Query / Catalog Correlation Design & Minimal QA-Only Observation Patch

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **AgentBus Run**: `warlock-20261031-setup`
- **Inspected Repository Revision (`HEAD`)**: `59a2f38ab2b26f6d76cad34039b59911a36188dc`
  - **Accepted Anchor**: Whole `ELM-TEA-002` (`tea-pure-update`) is **ACCEPTED** on immutable Elm source commit `889e9458d1707c456f5bb6e9af560383b066229e` (`16 / 242` whole requirements, `40 / 417` scenarios; `nativeOperations = []`; `HOSTSTOP2` preserved). Nothing in this design reopens `ELM-TEA-002` or alters any Elm module.
  - **Active Canonical WIP1**: `ELM-TEA-001` (`tea-typed-model`) owned by Root (`lead`); all canonical files remain untouched by this draft.
- **Target Blocker**: `ELM-UI-005` (`search-no-match`) partial verdict on `run-08` (`implementation/warlock/qa/evidence/ui005-haskell-search-20261101/observation.json:142,170`; `independent-review.json:386,389-400,496`), plus review of `terra-browser`'s guest feedback oracle (`.warlock-contributor/engine-pid1-drafts/terra-browser-guest-feedback-oracle.json`, SHA-256 `d111610511434f2b6e627f43dc69879dcfb2e88f2bf3a1d434f977de8b8b5acc`).
- **Scope Boundary**: Software-VM component observation on a Root-qualified source/runtime tuple **never** establishes protected native GUI acceptance, physical hardware input/240 Hz latency, native IME/preedit, assistive-technology focus/announcement, provider cleanup, or release readiness. Original `28s` deadline `D` is preserved without extension.

---

## 1. Source-Bound Trace: Why `run-08` Left Final-Query Correlation Unresolved

### 1.1 Renderer `Popup.pendingQuery` vs Authoritative `Desktop.Model.query`
1. **Local Renderer Overlay (`Popup.elm:53-54, 79-84, 103-118`; `SurfaceSnapshot.elm:74-75`)**:
   - Each keystroke in `#launcher-search` fires `Popup.LocalAction` -> `Popup.Action` -> `sendQuery` (`Popup.elm:79-83`), immediately setting `Popup.Model.pendingQuery = Just query` and dispatching `POST /actions` (`{"surfaceProtocol":2,"kind":"surface-query","surface":"popup","publication":P,"lease":L,"id":"control:search","query":query}`).
   - While `pendingQuery == Just q`, `Popup.view` (`Popup.elm:54`) passes `SurfaceRenderer.pendingQuery q snapshot` (`SurfaceSnapshot.elm:74-75`), which overwrites `#launcher-search`'s displayed `label` (`value`) with `q` and disables `entry:*` buttons **while preserving `snapshot.status` and `snapshot.popup` rows from the last accepted `SurfaceSnapshot`**.
   - `Popup.Present` (`Popup.elm:111-113`) clears `pendingQuery` to `Nothing` **if and only if** an incoming `"presentation"` event (`Surface.packet`) carries `SurfaceRenderer.queryValue snapshot == Just q`.
   - **Resulting visual ambiguity for `qvxz9`**: Because prefix `"qv"` (or `"q"` if no `Q*` `.desktop` entry exists) already yields `0` catalog matches (`status = "No matching applications. Change your search or Refresh."`, `0` `entry:*` controls), a screenshot showing `<input value="qvxz9">` and `"No matching applications. Change your search or Refresh."` (`query.png`) cannot by itself distinguish:
     - **(a) Authoritative completion**: `HttpMain` processed `"qvxz9"`, committed `P_final`, and `HttpPopup` rendered `P_final` (`pendingQuery == Nothing`), vs.
     - **(b) Unroundtripped suffix overlay**: `HttpMain` had only committed `"q"` or `"qv"`, and `Popup.pendingQuery == Just "qvxz9"` overlaid the full text over the earlier prefix's no-match banner.

2. **Authoritative Elm Controller Wire Fact (`Surface.elm:483, 517-531, 555, 575`)**:
   - `Surface.resolveBase` (`Surface.elm:555, 575`) strictly checks `version == 2 && shown == publication && scoped == lease` before turning `"surface-query"` into `Desktop.SearchQuery stamp value`.
   - Pure `DesktopPolicy.update` (`ELM-TEA-002`) sets `Desktop.Model.query = value`, evaluates `Catalog.search model.query` against `model.applications` (`CatalogSnapshot(lifetime, generation)`), computes `Surface.notice model` (`Surface.elm:483`), increments `SurfaceController.publication`, and `POST /commit`s a `DesktopCommit`.
   - Inside `DesktopCommit.projection.frame` (`Surface.packet`, `Surface.elm:530-531`), the `popup` control with `"id": "control:search"` (`"domId": "launcher-search"`) carries `"label": model.query` — **purely `Desktop.Model.query`, never `Popup.pendingQuery`** — alongside `"publication"`, `"lease"`, `"mode"`, `"status"`, and the filtered `entry:*` controls.

### 1.2 What Haskell `Mvp` / `EngineBroker` / `Owner` / `Backend` Currently Observe vs Drop
| Component | Inspected File & Lines | Currently Observed in Memory | Written to Disk / Stdout Today | Why Insufficient in `run-08` |
| :--- | :--- | :--- | :--- | :--- |
| **`Warlock.Ui.Mvp`** | `runtime/ui/Warlock/Ui/Mvp.hsc:372-383, 991-1010` | Polls `Broker.GetLastProjection`; `parseProjectionLease` extracts `(slScope, slRevision, slPublication, slLease, slPopupOpen)` | None | Discards `frame.status`, `control:search.label`, and `entry:*` counts; no disk output. |
| **`Warlock.Ui.EngineBroker`** | `runtime/src/Warlock/Ui/EngineBroker.hs:234-243` | Serves `LastProjection` bytes from `Owner.uiLastProjection` over engine socket | None | Internal RPC between `warlock-ui-owner` broker and `EngineOnly` WebKit child only. |
| **`Warlock.Ui.Owner`** | `runtime/src/Warlock/Ui/Owner.hs:138-141, 200-231, 433-438`; `ui/Main.hs:88-91` | Validates `DesktopCommit`; enqueues `(Popup, gateway "presentation" frameValue)` (`L212`) **before** `sendCommit native` (`L214`); confirms `Events` `200` `sendResponse` (`L230`); keeps `lastProjection` and `uiTrace` (`{role, route, bytes, sha256}`) | `uiResultJson` on `warlock-ui-owner` stdout **only if** owner exits before `D` (`ui/Main.hs:88-90`) | 1) `uiTrace` hashes request bodies without projection fields or `Events` `200` deliveries; 2) when `D` expires (`CredentialTransport TimedOut`), `Process.Bootstrap` terminates the child cgroup before `ui/Main.hs:90` runs; 3) `Backend` deliberately never dumps child stdout. |
| **`Warlock.Backend`** | `runtime/src/Warlock/Backend.hs:151-200, 210-247` | **Serves every `D.CatalogRead` (`L152-165`) AND receives every `DesktopCommit` (`D.commitProjection`, `D.commitRequests`, `D.commitFocus`) (`L185-200`)**; always runs post-`D` cleanup (`L210-235`) | `backendResultJson` (`L240`): aggregate counts only (`callbacks: 10`, `operations: 2`, `auth`, `credentialRows`, `selectedPid`) | By production rule (`L237-238`), ordinary `backend.stdout` omits query text, projection identities, and catalog digests. |
| **QMP Helper (`qmp.py` + `manual-physical-08.py`)** | `/home/charl/vm/omarchy/qmp.py:8-36`; `manual-physical-08.py:68-70, 87` | `qmp.py:14-15` returns `r` on `"return"` **or `"error"`**; `qmp.py keys` (`L23-25`) **discards `key(...)`'s return value without printing or checking `"error"`** and exits `0`! `qmp.py cmd` (`L34`) prints Python `repr(dict)` and still exits `0` on `"error"`! | `physical-inputs-through-run-08.jsonl` (only `returncode == 0` checked; `trial-result.json` left `physicalInputs: []`) | Subprocess exit code `0` did **not** verify QMP protocol `{"return": {}}` on `keys` or `cmd`, and socket had no timeout bound against `D`. |

---

## 2. Two-Layer Correlation Architecture (Read-Only Analysis + Minimal QA-Only Receipt Patch)

### 2.1 What Existing Unpatched Mechanics Already Prove (and Why `qvxz9` Still Needs an Opt-In Receipt)
- **Publication-Gated Round-Trip Property (`Surface.elm:555` + `Popup.elm:80, 111-116`)**:
  - `Surface.resolveBase` drops any `"surface-query"` whose `publication` (`shown`) differs from `HttpMain`'s current `publication`. When `HttpPopup` types while an earlier query commit is in flight, `Popup.Present` (`Popup.elm:115`) automatically re-dispatches `pendingQuery` stamped with the newly arrived `publication`. Thus each increment in `Backend.callbacks` beyond open-Applications corresponds to a `publication`-matched round trip.
- **Prefix-Boundary Property (`SurfaceSnapshot.elm:74-75`)**:
  - Because `SurfaceSnapshot.pendingQuery` never fabricates `"No matching applications. Change your search or Refresh."` (it retains `snapshot.status`), for any query $Q = c_1 \dots c_{k-1} c_k$ whose every proper prefix matches $\ge 1$ entry in `/usr/share/applications` (e.g., `"foot9"` against `foot.desktop`), the no-match status **cannot appear in the DOM at all** until `HttpMain` processes the final character $c_k$ and `HttpPopup` renders `P_final`.
  - **Why an explicit QA receipt is still required for `ELM-UI-005` (`qvxz9`)**: `terra-browser`'s oracle and the `run-08` slice predeclare `qvxz9` (where prefix `"qv"` already has `0` matches) **and** require explicit identity binding across `(catalogRequestId, catalogLifetime, catalogGeneration, viewRevision, scope, publication, lease)` (`independent-review.json:391-400`; `terra-browser-guest-feedback-oracle.json:37`). Aggregate `callbacks: 10` cannot provide those identities.

### 2.2 Minimal QA-Only Opt-In Observation Design (Zero New Authority, Production Stdout Unchanged)
Add an optional startup field `"qaObservationRoot"` (`DirectoryPin`: `{"path": "<RUN_DIR>", "device": "...", "inode": "..."}`) to `backend.json` (`Warlock.Backend`) and `ui.json` (`Warlock.Ui.Config` / `Warlock.Ui.Owner`), backed by `Warlock.Backend.Store` descriptor-pinned `0600` `O_NOFOLLOW | O_CLOEXEC` file helpers:

1. **Default Off (`Nothing`)**:
   - When `"qaObservationRoot"` is omitted (all production configs and all `10` existing Haskell CPU test suites), behavior, types on the wire, Elm code, and `backendResultJson` stdout are **100% unchanged**.
2. **`<RUN_DIR>/qa-backend-observations.json` (written by `Warlock.Backend` during post-`runBootstrapWithArguments` cleanup, so it always survives `D` expiry)**:
   - **`catalogReads`** (bounded $\le 64$ rows): `{seq, monotonicNs, requestId, status, catalogLifetime, catalogGeneration, entryCount, entryIdsSha256, replyPayloadSha256}` extracted from the exact `D.DesktopReply` sent by `Backend.hs:152-165`.
   - **`commits`** (bounded $\le 256$ rows): `{callbackSeq, monotonicNs, viewRevision, views, popupOwner, publication, lease, mode, authoritativeSearchQuery, authoritativeStatus, popupEntryCount, requests, focusCount}` extracted read-only from `D.commitProjection commit` (`control:search.label` = `Desktop.Model.query`) and `D.commitRequests commit`.
3. **`<RUN_DIR>/qa-popup-deliveries.jsonl` (appended + `fsync`ed live by `Warlock.Ui.Owner` at `Owner.hs:230-231` immediately after `sendResponse ... 200 ... == True` on `Popup` `GET /events`)**:
   - Records `{seq, monotonicNs, role: "Popup", kind: "presentation", publication, lease, mode, searchQuery, status}` at the exact moment `Owner` confirms HTTP `200` delivery of `Surface.packet` to `HttpPopup` — **surviving `D` expiry because each line is flushed live before `D`**.
4. **End-to-End Deterministic Correlation Equation (`evaluate-run` in `tools/omarchy_ui_mvp.py`)**:
   Let $C_{\text{disk}}$ be the independent `.desktop` catalog manifest scanned by `prepare_catalog_roots`, $R_{\text{cat}}$ be the latest `catalogReads` entry in `qa-backend-observations.json`, $M_{\text{final}}$ be the final `commits` entry, $D_{\text{popup}}$ be the matching `qa-popup-deliveries.jsonl` line, and $[t_{\text{shot,start}}, t_{\text{shot,end}}]$ be the guest `CLOCK_MONOTONIC` bracket of `query.png`:
   - `C_disk.entryIdsSha256 == R_cat.entryIdsSha256` and `independent_search(C_disk, "qvxz9") == []` (independent zero-match witness, never reducer-copied);
   - `M_final.mode == "applications"`, `M_final.authoritativeSearchQuery == "qvxz9"`, `M_final.authoritativeStatus == "No matching applications. Change your search or Refresh."`, `M_final.popupEntryCount == 0`, and `M_final.requests == []` (no launch/pin request);
   - `D_popup.publication == M_final.publication`, `D_popup.lease == M_final.lease`, `D_popup.searchQuery == "qvxz9"`, and `M_final.monotonicNs <= D_popup.monotonicNs < t_shot_start` (proving `HttpPopup` received `P_final` and cleared `Popup.pendingQuery` to `Nothing` before `query.png` was captured).

---

## 3. Minimal QA-Only Source Patch Diffs (Against `HEAD = 59a2f38ab2b26f6d76cad34039b59911a36188dc`)

> **Zero Authority / Zero Elm Impact**: Touches **0** Elm files, **0** `warlock-protocol` modules, **0** `CredentialIngress` / `Process.Bootstrap` guards, and **0** `backendResultJson` stdout fields.

### 3.1 `implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc`
Adds `writeQaFile` (`O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC`, `0600`, `fsync` file + dir) and `appendQaLine` (`O_WRONLY | O_CREAT | O_APPEND | O_NOFOLLOW | O_CLOEXEC`, `0600`, `fsync` file) inside the existing descriptor-pinned `StoreOwner` boundary:

```diff
--- a/implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc
+++ b/implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc
@@ -4,7 +4,7 @@
 module Warlock.Backend.Store
  (DirectoryPin(..),StoreOwner,newStoreOwner,runOwned,retireStoreOwner,
   withPinnedDirectory,withChildDirectory,listNames,entryDirectory,directoryStamp,readRegular,withPinLock,
-  replacePins,readStartupFile) where
+  replacePins,readStartupFile,writeQaFile,appendQaLine) where
 #define _GNU_SOURCE 1
 #include <sys/types.h>
 #include <sys/stat.h>
@@ -264,6 +264,34 @@
    let used=fromIntegral amount
    writeAll fd (pointer `plusPtr` used) (remaining-used)
 
+writeQaBytes :: Fd -> B.ByteString -> IO ()
+writeQaBytes fd bytes = B.useAsCStringLen bytes $ \(pointer,size) -> loop (castPtr pointer) size
+ where
+  loop _ 0 = pure ()
+  loop pointer remaining = do
+   amount <- throwErrnoIfMinus1 "qa observation write" (c_write (number fd) pointer (fromIntegral remaining))
+   require (amount>0 && toInteger amount<=toInteger remaining) "qa observation write progress"
+   let used=fromIntegral amount
+   loop (pointer `plusPtr` used) (remaining-used)
+
+writeQaFile :: StoreOwner -> DirectoryPin -> B.ByteString -> B.ByteString -> IO ()
+writeQaFile owner pin leaf bytes = runOwned owner $ withPinnedDirectory owner True pin $ \directory -> do
+ require (nameValid leaf && not (B.null bytes) && B.length bytes<=524288) "qa observation file bound"
+ tracked owner (openAt directory leaf (#{const O_WRONLY} .|. #{const O_CREAT} .|. #{const O_EXCL} .|. #{const O_NOFOLLOW} .|. #{const O_CLOEXEC}) 0o600) closeFdOnce $ \fd -> do
+  privateFile =<< getFdStatus fd
+  writeQaBytes fd bytes
+  throwErrnoIfMinus1_ "qa observation fsync" (c_fsync (number fd))
+ throwErrnoIfMinus1_ "qa observation dir fsync" (c_fsync (number directory))
+
+appendQaLine :: StoreOwner -> DirectoryPin -> B.ByteString -> B.ByteString -> IO ()
+appendQaLine owner pin leaf line = runOwned owner $ withPinnedDirectory owner True pin $ \directory -> do
+ let payload = line <> C.pack "\n"
+ require (nameValid leaf && not (B.null line) && not (B.elem 10 line) && B.length payload<=16384) "qa observation line bound"
+ tracked owner (openAt directory leaf (#{const O_WRONLY} .|. #{const O_CREAT} .|. #{const O_APPEND} .|. #{const O_NOFOLLOW} .|. #{const O_CLOEXEC}) 0o600) closeFdOnce $ \fd -> do
+  privateFile =<< getFdStatus fd
+  writeQaBytes fd payload
+  throwErrnoIfMinus1_ "qa observation line fsync" (c_fsync (number fd))
+
 readStartupFile :: StoreOwner -> FilePath -> IO B.ByteString
 readStartupFile owner path = runOwned owner $ do
  let raw=TE.encodeUtf8 (T.pack path)
```

### 3.2 `implementation/warlock/haskell/runtime/src/Warlock/Backend.hs`
Opts in via `"qaObservationRoot"` (`Maybe DirectoryPin`) to record `catalogReads` + `commits` (`authoritativeSearchQuery`, `authoritativeStatus`, `publication`, `lease`, `popupEntryCount`, `requests`) to `<RUN_DIR>/qa-backend-observations.json`:

```diff
--- a/implementation/warlock/haskell/runtime/src/Warlock/Backend.hs
+++ b/implementation/warlock/haskell/runtime/src/Warlock/Backend.hs
@@ -7,14 +7,16 @@
  (DirectoryPin(..),BackendConfig,loadBackendConfig,BackendResult(..),runBackend,backendResultJson) where
 import Control.Exception (SomeException,SomeAsyncException,fromException,mask,throwIO,try)
 import Control.Monad (forM_,unless)
+import qualified Crypto.Hash.SHA256 as SHA
 import qualified Data.ByteString as B
 import qualified Data.ByteString.Char8 as C
 import Data.IORef
 import qualified Data.Set as Set
 import Data.Text (Text)
 import qualified Data.Text as T
 import qualified Data.Text.Encoding as TE
+import GHC.Clock (getMonotonicTimeNSec)
 import Numeric (showHex)
 import System.Posix.Files (deviceID,fileID,getSymbolicLinkStatus)
 import Text.Read (readMaybe)
@@ -30,7 +32,7 @@
 import Warlock.Protocol.StrictJson
 
 data UiImage = UiImage FilePath Integer Integer Integer B.ByteString [String] [DirectoryPin]
-data BackendConfig = BackendConfig Binding String UiImage [DirectoryPin] DirectoryPin Text Bool
+data BackendConfig = BackendConfig Binding String UiImage [DirectoryPin] DirectoryPin Text Bool (Maybe DirectoryPin)
 data BackendResult = BackendResult
  {backendPassed :: Bool,backendCleanup :: Bool,backendCallbackCount :: Int,backendOperationCount :: Int
  ,backendBootstrap :: Either Text BootstrapResult,backendAuthObservation :: Maybe AuthObservation
@@ -56,14 +58,19 @@
  limits <- failure (bounds 131072 16)
  raw <- failure (decodeStrict limits bytes)
  let names=["schema","binding","deadlineMonotonicNs","ui","catalogRoots","pinsRoot","locale"]
- fields <- case raw of
-  JObject pairs | any ((=="applicationAttachment") . fst) pairs -> object ("applicationAttachment":names) raw
-  _ -> object names raw
+     optionalNames=[opt | opt <- ["applicationAttachment","qaObservationRoot"], case raw of JObject pairs -> any ((==opt) . fst) pairs; _ -> False]
+ fields <- object (optionalNames++names) raw
  attachment <- case lookup "applicationAttachment" fields of
   Nothing -> Right False
   Just (JBool value) -> Right value
   _ -> Left "invalid application attachment opt-in"
+ qaPin <- case lookup "qaObservationRoot" fields of
+  Nothing -> Right Nothing
+  Just value -> Just <$> directoryConfig value
  require (lookup "schema" fields==Just (JNumber "1")) "unsupported startup schema"
  bound <- key "binding" fields >>= bindingConfig
  deadline <- key "deadlineMonotonicNs" fields >>= string
@@ -73,7 +80,7 @@
  pins <- key "pinsRoot" fields >>= directoryConfig
  locale <- key "locale" fields >>= string
  require (T.length locale<=128 && not (T.any (< ' ') locale)) "invalid trusted locale"
- pure (BackendConfig bound (T.unpack deadline) image roots pins locale attachment)
+ pure (BackendConfig bound (T.unpack deadline) image roots pins locale attachment qaPin)
  where
   bindingConfig raw = do
    fields <- object ["lifetime","session","frontend"] raw
@@ -126,12 +133,15 @@
 positive value = string value >>= failure . parseCounter False
 
 runBackend :: BackendConfig -> IO BackendResult
-runBackend (BackendConfig bound deadlineText (UiImage image dev ino size digest arguments parents) roots pinsRoot locale attachmentEnabled) = mask $ \restore -> do
+runBackend (BackendConfig bound deadlineText (UiImage image dev ino size digest arguments parents) roots pinsRoot locale attachmentEnabled qaPin) = mask $ \restore -> do
  catalog <- newCatalog roots locale (lifetime bound)
  pins <- newPinStore pinsRoot
+ qaStore <- traverse (const newStoreOwner) qaPin
  attachmentAttempted <- newIORef False
  callbacks <- newIORef 0
  operations <- newIORef 0
+ qaCatalogRows <- newIORef ([] :: [Json])
+ qaCommitRows <- newIORef ([] :: [Json])
  -- One bounded last-disposition cell plus a high-water mark prevents replay
  -- of old/uncertain pin writes without retaining an unbounded request history.
  lastWrite <- newIORef (Nothing :: Maybe (Counter,D.PinSnapshot,D.DesktopReply))
@@ -148,21 +158,31 @@
       sent <- sendCredentialIngress ingress
       unless (sent==Right ()) (ioError (userError "backend reply delivery unconfirmed"))
      construct = either (ioError . userError . T.unpack) pure
+     recordQaCatalog reply = case qaPin of
+      Nothing -> pure ()
+      Just _ -> case D.encodeDesktopReply reply of
+       Left _ -> pure ()
+       Right replyBytes -> do
+        mono <- getMonotonicTimeNSec
+        opSeq <- readIORef operations
+        modifyIORef' qaCatalogRows (\rows -> if length rows>=64 then rows else summarizeCatalogReply opSeq mono replyBytes:rows)
      handle request = case D.requestKind request of
       D.CatalogRead -> do
        modifyIORef' operations (+1)
        actual <- readCatalog catalog
        preferences <- either (const Nothing) Just <$> readPins pins
        case actual of
         Left _ -> do
-         construct (D.catalogReply bound (D.requestId request) Nothing preferences) >>= sendReply
+         reply <- construct (D.catalogReply bound (D.requestId request) Nothing preferences)
+         recordQaCatalog reply >> sendReply reply
         Right (snapshot,_) -> do
          -- Check complete envelope including preferences. Overflow exposes
          -- explicit unavailable, never a truncated subset of the catalog.
          case D.catalogReply bound (D.requestId request) (Just snapshot) preferences of
           Left _ -> do
-           construct (D.catalogReply bound (D.requestId request) Nothing preferences) >>= sendReply
-          Right reply -> sendReply reply
+           reply <- construct (D.catalogReply bound (D.requestId request) Nothing preferences)
+           recordQaCatalog reply >> sendReply reply
+          Right reply -> recordQaCatalog reply >> sendReply reply
       D.PinsWrite -> case D.pinProposal request of
        Nothing -> ioError (userError "checked pin proposal missing")
        Just proposal -> do
@@ -186,8 +206,14 @@
       Nothing -> ioError (userError "native profile reached desktop actor")
       Just commit -> do
        modifyIORef' callbacks (+1)
+       cbSeq <- readIORef callbacks
        let requests=D.commitRequests commit
        unless (all ((==bound) . D.requestBinding) requests) (ioError (userError "checked commit binding mismatch"))
+       case qaPin of
+        Nothing -> pure ()
+        Just _ -> do
+         mono <- getMonotonicTimeNSec
+         modifyIORef' qaCommitRows (\rows -> if length rows>=256 then rows else summarizeCommit cbSeq mono commit:rows)
        -- Reserve the one attempt before enqueue/delivery. Any exception ends
        -- this authenticated session; an uncertain send is never replayed.
        firstAttempt <- if attachmentEnabled
@@ -210,6 +236,16 @@
  processRetirement <- try (retireBootstrap owner) :: IO (Either SomeException Bool)
  catalogRetirement <- try (retireCatalog catalog) :: IO (Either SomeException Bool)
  pinRetirement <- try (retirePinStore pins) :: IO (Either SomeException Bool)
+ qaWriteResult <- case (qaPin,qaStore) of
+  (Just targetPin,Just store) -> do
+   catRows <- reverse <$> readIORef qaCatalogRows
+   comRows <- reverse <$> readIORef qaCommitRows
+   let doc = JObject [("schema",JNumber "1"),("kind",JString "qa-backend-observations"),("catalogReads",JArray catRows),("commits",JArray comRows)]
+   wrote <- try (writeQaFile store targetPin (C.pack "qa-backend-observations.json") (TE.encodeUtf8 (renderJson doc <> "\n"))) :: IO (Either SomeException ())
+   retired <- try (retireStoreOwner store) :: IO (Either SomeException Bool)
+   pure (Just (wrote,retired))
+  _ -> pure Nothing
  observed <- bootstrapAuthObservation owner
  trace <- bootstrapCredentialTrace owner
  selected <- bootstrapSelectedPid owner
@@ -222,12 +258,15 @@
      processClean=either (const False) id processRetirement
      catalogClean=either (const False) id catalogRetirement
      pinClean=either (const False) id pinRetirement
-     clean=processClean && catalogClean && pinClean
+     qaClean=case qaWriteResult of
+      Nothing -> True
+      Just (Right (),Right True) -> True
+      _ -> False
+     clean=processClean && catalogClean && pinClean && qaClean
      success=case outcome of
       Right (Executed result) -> selectedCustody result==Available && selectedContainment result==BeforeSignalLeaderExited && either (const False) (const True) (selectedOperation result)
       _ -> False
  let originals=case attempted of Left (problem :: SomeException) -> [problem]; _ -> []
-     cleanupProblems=[problem | Left problem <- [processRetirement,catalogRetirement,pinRetirement]]
+     qaProblems=case qaWriteResult of Just (w,r) -> [p | Left p <- [w]] ++ [p | Left p <- [r]]; Nothing -> []
+     cleanupProblems=[problem | Left problem <- [processRetirement,catalogRetirement,pinRetirement]] ++ qaProblems
      asynchronous=[problem | problem <- originals++cleanupProblems,Just _ <- [fromException problem :: Maybe SomeAsyncException]]
  -- Every independent owner was attempted before an asynchronous failure can
  -- escape. Prefer the original asynchronous exception over cleanup failures.
@@ -235,6 +274,56 @@
  pure (BackendResult (clean && success) clean count dispatched outcome observed trace selected processClean catalogClean pinClean)
 
+hexSha256 :: B.ByteString -> Text
+hexSha256 bytes = T.pack (concatMap (\w -> let h=showHex w "" in replicate (2-length h) '0'++h) (B.unpack (SHA.hash bytes)))
+
+lookupJson :: Text -> Json -> Maybe Json
+lookupJson name (JObject pairs) = lookup name pairs
+lookupJson _ _ = Nothing
+
+summarizeCatalogReply :: Int -> Word -> B.ByteString -> Json
+summarizeCatalogReply seqNum monoNs replyBytes =
+ let parsed = bounds 1048576 16 >>= (`decodeStrict` replyBytes)
+     root = either (const (JObject [])) id parsed
+     reqId = maybe JNull id (lookupJson "requestId" root)
+     statusVal = maybe JNull id (lookupJson "status" root)
+     catObj = lookupJson "catalog" root
+     catLife = maybe JNull id (catObj >>= lookupJson "lifetime")
+     catGen = maybe JNull id (catObj >>= lookupJson "generation")
+     entries = case catObj >>= lookupJson "entries" of Just (JArray xs) -> xs; _ -> []
+     entryIds = [eid | item <- entries, Just (JString eid) <- [lookupJson "id" item]]
+     idsDigest = hexSha256 (TE.encodeUtf8 (T.intercalate "\n" entryIds))
+ in JObject
+     [("seq",JNumber (T.pack (show seqNum))),("monotonicNs",JNumber (T.pack (show monoNs)))
+     ,("requestId",reqId),("status",statusVal),("catalogLifetime",catLife),("catalogGeneration",catGen)
+     ,("entryCount",JNumber (T.pack (show (length entries)))),("entryIdsSha256",JString idsDigest)
+     ,("replyPayloadSha256",JString (hexSha256 replyBytes))]
+
+summarizeCommit :: Int -> Word -> D.DesktopCommit -> Json
+summarizeCommit cbSeq monoNs commit =
+ let proj = D.commitProjection commit
+     frame = maybe (JObject []) id (lookupJson "frame" proj)
+     popupItems = case lookupJson "popup" frame of Just (JArray xs) -> xs; _ -> []
+     searchQuery = case [lbl | item <- popupItems, lookupJson "id" item==Just (JString "control:search"), Just lbl <- [lookupJson "label" item]] of
+      (q:_) -> q
+      [] -> JNull
+     entryCount = length [() | item <- popupItems, Just (JString cid) <- [lookupJson "id" item], "entry:" `T.isPrefixOf` cid]
+     reqSummaries = [JObject [("requestId",JString (renderCounter (D.requestId req))),("kind",JString (case D.requestKind req of D.CatalogRead -> "catalog-read"; D.PinsWrite -> "pins-write"))] | req <- D.commitRequests commit]
+ in JObject
+     [("callbackSeq",JNumber (T.pack (show cbSeq))),("monotonicNs",JNumber (T.pack (show monoNs)))
+     ,("viewRevision",maybe JNull id (lookupJson "revision" proj))
+     ,("views",maybe (JArray []) id (lookupJson "views" proj))
+     ,("popupOwner",maybe JNull id (lookupJson "popupOwner" proj))
+     ,("publication",maybe JNull id (lookupJson "publication" frame))
+     ,("lease",maybe JNull id (lookupJson "lease" frame))
+     ,("mode",maybe JNull id (lookupJson "mode" frame))
+     ,("authoritativeSearchQuery",searchQuery)
+     ,("authoritativeStatus",maybe JNull id (lookupJson "status" frame))
+     ,("popupEntryCount",JNumber (T.pack (show entryCount)))
+     ,("requests",JArray reqSummaries)
+     ,("focusCount",JNumber (T.pack (show (length (D.commitFocus commit)))))]
+
 -- Ordinary executable diagnostics contain statuses/counts only, never captured
 -- UI stdout, catalog content, draft text, pixels or supplied arguments.
 backendResultJson :: BackendResult -> B.ByteString
```
*(Note: use `Word64` from `Data.Word (Word64)` for `getMonotonicTimeNSec` so signatures are exact `Word64` matching `GHC.Clock.getMonotonicTimeNSec :: IO Word64`.)*

### 3.3 `Warlock/Ui/Config.hs` + `Warlock/Ui/Owner.hs` (Live `Popup` `GET /events` `200` Delivery Receipt)
- **`Warlock/Ui/Config.hs`**: Export `uiQaObservationRoot :: UiConfig -> Maybe DirectoryPin`; in `parse`, accept optional `"qaObservationRoot"` (`DirectoryPin` via `Warlock.Backend.Store`) alongside `["schema","binding","deadlineMonotonicNs","documents"]` (`Nothing` when absent).
- **`Warlock/Ui/Owner.hs`**: When `uiQaObservationRoot config == Just qaPin`, hold one `StoreOwner` (`qaStore`, retired in `Owner` cleanup) and one `qaDeliverySeq :: IORef Int`. At `Owner.hs:230-231`, immediately after `delivered <- sendResponse ...` and `require delivered "UI HTTP response unconfirmed"`, when `role == Popup && route == Events && code == 200`:
  ```haskell
  case (qaPin, role, route, code) of
   (Just pin, Popup, Events, 200) -> recordPopupDelivery qaStore pin qaDeliverySeq body
   _ -> pure ()
  ```
  where `recordPopupDelivery` decodes `{"bridgeProtocol":1,"kind":"presentation","payload":frame}` (ignoring `"announcements"`/`"focus"` or recording their `kind`) and calls `appendQaLine qaStore pin "qa-popup-deliveries.jsonl"` with `{seq, monotonicNs, role:"Popup", kind, publication, lease, mode, searchQuery, status}`. Because `appendQaLine` writes + `fsync`s immediately, `<RUN_DIR>/qa-popup-deliveries.jsonl` is **already on disk before `shot('query.png')` and before `D` expiry**.

### 3.4 QMP Reply Verification & Per-Event Guard Fix (`manual-physical` / `tools/omarchy_ui_mvp.py`)
Fixes both `independent-review.json:386,496` (`qmp.py:14-15,24-25` exiting `0` without checking `"return"` vs `"error"`) and `terra-browser-guest-feedback-oracle.json:16,32` (per-event guard before every motion, button-down, button-up, and key):

```python
def qmp_execute_checked(
    sock_path: str,
    deadline_host_mono: float,
    command_obj: dict[str, Any],
    guard_fn: Callable[[], dict[str, Any]],
) -> dict[str, Any]:
    """Run ownership/PID-birth/cgroup/window/geometry/Foot/lock/D guard BEFORE
    opening/sending a single QMP command, enforce socket timeout <= remaining D,
    and require exact JSON reply {'return': {}} (fail closed on 'error' or EOF).
    """
    guard_receipt = guard_fn()  # raises GuardRefusal before any socket write if violated
    rem = deadline_host_mono - time.monotonic()
    if rem <= 8.0:
        raise RuntimeError(f"refusing QMP input inside 8.0s D reserve (remaining={rem:.3f}s)")
    t0 = time.monotonic_ns()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(min(2.0, max(0.2, rem - 8.0)))
        sock.connect(sock_path)
        reader = sock.makefile("r", encoding="utf-8")
        greeting = json.loads(reader.readline())
        if "QMP" not in greeting:
            raise RuntimeError(f"unexpected QMP greeting: {greeting!r}")
        sock.sendall(b'{"execute":"qmp_capabilities"}\n')
        cap_reply = read_qmp_reply(reader)
        if cap_reply != {"return": {}}:
            raise RuntimeError(f"qmp_capabilities rejected: {cap_reply!r}")
        wire = (json.dumps(command_obj, separators=(",", ":")) + "\n").encode("utf-8")
        sock.sendall(wire)
        reply = read_qmp_reply(reader)
    t1 = time.monotonic_ns()
    if "error" in reply or reply.get("return") != {}:
        raise RuntimeError(f"QMP command failed closed: cmd={command_obj!r} reply={reply!r}")
    return {
        "command": command_obj,
        "reply": reply,
        "hostMonoStartNs": t0,
        "hostMonoEndNs": t1,
        "guard": guard_receipt,
    }
```
- **Safe-abort latch discipline**: For pointer click (`motion` -> `button-down` -> `button-up`), run `guard_fn()` before `motion`, before `button-down`, and before `button-up`. If `guard_fn()` refuses after `button-down` because the active window changed or `D` was reached, record `safeAbortLatchState` without issuing an unguarded click to a foreign window (matching `terra-browser-guest-feedback-oracle.json:16`).

---

## 4. Exact Artifact, Manifest & Slice Bindings for Root Integration

When Root finishes `ELM-TEA-001` (`tea-typed-model`) and selects the next `ELM-UI-005` (`search-no-match`) slice:

1. **Contributor Slice Extension (`.warlock-contributor/ui005-haskell-search.json`)**:
   - Currently declares only `Main.elm`, `Surface.elm`, `HttpPopup.elm`, and `Mvp.hsc`.
   - Before editing Haskell runtime / QA helper files for opt-in correlation receipts, extend the slice with:
     ```bash
     python3 -B plugins/warlock-contributor/scripts/warlock.py extend \
       implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc \
       implementation/warlock/haskell/runtime/src/Warlock/Backend.hs \
       implementation/warlock/haskell/runtime/src/Warlock/Ui/Config.hs \
       implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs \
       tools/omarchy_ui_mvp.py
     ```
2. **`MVP_SOURCE_PATHS` Completeness (`tools/omarchy_ui_mvp.py:121-143`)**:
   - `Backend.hs`, `Owner.hs`, and `Config.hs` are **already** listed (`lines 136-138`), as are all `74` `ELM_SIX_ROOT_CLOSURE_PATHS` (`StatusScroll.elm` included).
   - Add `"implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc"` and `"tools/omarchy_ui_mvp.py"` to `MVP_SOURCE_PATHS` so `source-manifest.json` pins every touched source file hash.
3. **Host Protected Checks & Freshness Gate Before Guest Staging**:
   - `python3 -B docs/warlock-build-loop/v2/loop.py check`
   - `python3 -B window-integration-qa/qa_run.py -- python3 -B tools/check_haskell_cpu.py --ui-origin` (verifies all `10` Haskell suites with `"qaObservationRoot"` omitted + compiles fresh 6-root Elm `HttpMain.html` / `HttpBar.html` / `HttpPopup.html`).
   - Stage updated Haskell workspace + `tools/omarchy_ui_mvp.py` + verified `FRONTEND_DIR` HTML digests to guest, rebuild `warlock-ui-owner` and `warlock-ui-backend` offline, and run single bounded `<= 28s` (`D` unchanged) trial with `--qa-observation`.

---

## 5. Source-Bound Review of `terra-browser-guest-feedback-oracle.json` (`d1116105...`)

Inspected `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/terra-browser-guest-feedback-oracle.json` (SHA-256 `d111610511434f2b6e627f43dc69879dcfb2e88f2bf3a1d434f977de8b8b5acc`, superseding `0337113e...`):

1. **Verdict — Strongly Aligned with Production Elm/Haskell Semantics**:
   - Precondition 5 (`line 16`, per-event ownership/PID-birth/cgroup/active-window/Foot/lock/geometry/original-`D` guard before every QMP motion, button-down, button-up, and key, with safe-abort handling) and Step 4 (`line 37`, allowing legitimate `publication`/`lease` advancement on query commits rather than requiring equality to pre-input `publication`) accurately match `SurfaceController.elm` (`publication` increments per commit) and `Popup.elm:107` (`sameField` preserves `lease` across query updates within one open Applications session).
   - `not_measured` (`line 49`) and `remaining` (`line 50`) preserve the exact `UX-PERFORMANCE-ACCEPTANCE.md` and `AGENTS.md` hardware/native/AT/IME non-equivalence rules.
2. **Three Concrete Source-Bound Refinements for Integration**:
   - **R1 — Explicit QMP JSON Reply Guard (`step 2` / `step 3`)**: Require parsed QMP socket reply `{"return": {}}` on `qmp_capabilities` and every `input-send-event` / `send-key` / `screendump`; never rely on `/home/charl/vm/omarchy/qmp.py` subprocess exit code `0` (`qmp.py:14-15,24-25` ignores `"error"` on `keys` and `cmd`).
   - **R2 — Two-Point Receipt Binding (`step 4`)**: Bind `(catalogReads.entryIdsSha256 == catalogManifest.entryIdsSha256)` + `qa-backend-observations.json.commits[final]` (`authoritativeSearchQuery == "qvxz9"`, `authoritativeStatus == "No matching applications. Change your search or Refresh."`, `popupEntryCount == 0`, `requests == []`) **and** `qa-popup-deliveries.jsonl` (`role == "Popup"`, `publication == commits[final].publication`, `lease == commits[final].lease`, `monotonicNs < queryShotStartMonoNs`), which closes both controller-model causation and `HttpPopup` `GET /events` delivery prior to `query.png`.
   - **R3 — Search-Field Focus Observation Honesty (`step 2`, `HttpPopup.elm:54-58`)**: Note that opening `Applications` via pointer click sets `model.popupOrigin = Desktop.PointerEntry` (`Surface.elm:543`), whereas `HttpPopup` also executes `Browser.Dom.focus "launcher-search"` when a `"focus"` gateway event arrives while `composition == Popup.Idle` (`HttpPopup.elm:54-57`), and physical QMP click on `#launcher-search` focuses the `<input>` in WebKitGTK. As `step 2` (`line 27`) rightly states, treat key delivery into `#launcher-search` (`authoritativeSearchQuery == "qvxz9"`) as functional field-input evidence in the software VM while keeping assistive-technology/native focus verification explicitly separate (`remaining`, `line 50`).
