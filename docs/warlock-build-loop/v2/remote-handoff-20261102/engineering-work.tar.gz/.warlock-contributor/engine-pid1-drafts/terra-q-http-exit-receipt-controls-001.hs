{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Host retains Case and an independent guardian for
-- actual child, owner, handles and all workers, on every outcome or timeout.
module QHttpExitReceipt001 (Mode(..),Case,newCase,runCase,retainedWorkers) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Directory (doesFileExist,removeFile)
import System.Exit (ExitCode(..))
import System.FilePath (isAbsolute)
import System.IO (Handle)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal
 (AdmissionDeadline,ToolError(..),SessionObservation(..),leaderExited,observeChild,remainingMicros)
import Warlock.Capture.Process.Persistent.Internal
 (PersistentOwner,PersistentStatus(..),SessionExit(..),StopBudget,StopDeadlineObservation(..),
  LeaderExitObservation(..),newPersistentOwner,persistentLeaderExit,persistentStatus,
  persistentFixture,startBudgetFromDeadline,observeLiveStartup,tryPersistentStopDeadline,withPersistentOwnerHook)

data Mode = NaturalZero | NaturalOne | BeforeReapFailure | LateReceipt deriving (Eq,Show)
data Case = Case PersistentOwner Handle (IORef Bool) (IORef [ThreadId]) (IORef (Maybe SessionObservation))
 (IORef [String]) (MVar ()) (MVar ()) (MVar ()) (MVar ())
newCase :: Handle -> IO Case
newCase input = Case <$> newPersistentOwner <*> pure input <*> newIORef False <*> newIORef [] <*> newIORef Nothing
 <*> newIORef [] <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ workers _ _ _ _ _ _) = readIORef workers
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("exit-receipt: " ++ label)))
waitCell :: AdmissionDeadline -> String -> MVar a -> IO a
waitCell originalD label done = do
 left <- remainingMicros originalD
 if left<=0 then ioError (userError (label ++ ": Unknown, retain guardian")) else do
  value <- timeout left (readMVar done)
  maybe (ioError (userError (label ++ ": Unknown, retain guardian"))) pure value
launch :: IORef [ThreadId] -> IO a -> IO (MVar (Either SomeException a))
launch workers action = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try (unmask (readMVar start >> action))
  putMVar done outcome
  case outcome of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()
 pure done
awaitDead :: AdmissionDeadline -> SessionObservation -> IO ()
awaitDead originalD observed = do
 left <- remainingMicros originalD
 check "original D live awaiting actual non-reaping liveness" (left>0)
 dead <- leaderExited (observedPid observed)
 unless dead (threadDelay (min left 1000) >> awaitDead originalD observed)
awaitStopD :: AdmissionDeadline -> PersistentOwner -> IO AdmissionDeadline
awaitStopD originalD owner = do
 left <- remainingMicros originalD
 check "original D live awaiting actual cleanup D" (left>0)
 selected <- tryPersistentStopDeadline owner
 case selected of
  StopDeadlineLatched d -> pure d
  StopDeadlineFailed _ -> ioError (userError "actual cleanup D failed")
  _ -> threadDelay (min left 1000) >> awaitStopD originalD owner
awaitExpiry :: AdmissionDeadline -> AdmissionDeadline -> IO ()
awaitExpiry originalD selected = do
 left <- remainingMicros selected
 if left<=0 then pure () else do
  remainingMicros originalD >>= check "original observation D still live" . (>0)
  threadDelay (min left 1000)
  awaitExpiry originalD selected

-- Root supplies an actual private precreated trigger, real selected child
-- compiled from peer001, owned input Handle and original absolute trial D.
-- The verified pid/birth/executable and same ProcessHandle stay owner-bound.
-- Failure to reach an actual source hook is a failure/Unknown, not a fake D.
runCase :: Case -> AdmissionDeadline -> StopBudget -> FilePath -> FilePath -> Mode -> IO ()
runCase (Case owner input used workers observed events liveReady liveRelease receiptReached receiptRelease)
 originalD stopBudget child marker mode = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated Case and absolute private paths" (fresh && isAbsolute child && isAbsolute marker)
 before <- persistentLeaderExit owner
 check "fresh owner has no child exit receipt" (before==LeaderExitUnobserved)
 markerPresent <- doesFileExist marker
 check "actual trigger precreated" markerPresent
 let exitArg = case mode of NaturalOne -> "1"; _ -> "0"
     verify actual = do
      same <- observeChild originalD (observedPid actual)
      let valid = same==Right actual && observedPid actual>0 &&
                  not (B.null (observedStart actual)) && observedExecutable actual==child
      if valid then writeIORef observed (Just actual) >> pure (Right ())
       else pure (Left BadArguments)
     body live = do
      expected <- readIORef observed
      found <- observeLiveStartup live
      check "live token resolves the same verified child" ((Just <$> found)==Right expected)
      putMVar liveReady ()
      readMVar liveRelease
     event stage = do
      atomicModifyIORef' events (\xs -> (stage:xs,()))
      case mode of
       BeforeReapFailure | stage=="persistent-before-leader-exit-probe" -> ioError (userError "QA pre-reap observation failure")
       LateReceipt | stage=="qa-after-owned-reap-success" -> putMVar receiptReached () >> readMVar receiptRelease
       _ -> pure ()
 done <- launch workers $ withPersistentOwnerHook owner (persistentFixture child [marker,exitArg] input)
  4096 (startBudgetFromDeadline originalD) stopBudget verify body event
 restore $ do
  waitCell originalD "actual selected live child" liveReady
  pending <- persistentLeaderExit owner
  check "live child has no exit receipt yet" (pending==LeaderExitUnobserved)
  actual <- readIORef observed >>= maybe (ioError (userError "verified actual child missing")) pure
  -- A real owned marker release, not a PID signal or fabricated process exit.
  remove <- launch workers (removeFile marker)
  waitCell originalD "release actual child trigger" remove >>= either throwIO pure
  awaitDead originalD actual
  putMVar liveRelease ()
  case mode of
   LateReceipt -> do
    waitCell originalD "actual ProcessHandle reap returned" receiptReached
    during <- persistentLeaderExit owner
    check "pre-publication receipt stays Unknown" (during==LeaderExitUnknown)
    existingD <- awaitStopD originalD owner
    awaitExpiry originalD existingD
    putMVar receiptRelease ()
   _ -> pure ()
  actualResult <- waitCell originalD "actual owner lifecycle completion" done >>= either throwIO pure
  status <- persistentLeaderExit owner
  phase <- persistentStatus owner
  stages <- reverse <$> readIORef events
  check "natural child exit reached source liveness path without kill" $
   (if mode==BeforeReapFailure then "persistent-before-leader-exit-probe" `elem` stages else "persistent-leader-already-exited" `elem` stages) &&
   "persistent-before-leader-kill" `notElem` stages
  case mode of
   NaturalZero -> check "actual zero exit retained" $
    status==LeaderExitObserved ExitSuccess && case actualResult of Right ((),LeaderReaped _) -> True; _ -> False
   NaturalOne -> check "actual nonzero exit retained" $
    status==LeaderExitObserved (ExitFailure 1) && case actualResult of Right ((),LeaderReaped _) -> True; _ -> False
   BeforeReapFailure -> check "entered failed observation remains Unknown" $
    status==LeaderExitUnknown && (case actualResult of Left (ExitUncertain CleanupUncertain _) -> True; _ -> False) &&
    (case phase of PersistentQuarantined _ -> True; _ -> False)
   LateReceipt -> check "actual late reap result not published as observed" $
    status==LeaderExitUnknown && (case actualResult of Left (ExitUncertain CleanupUncertain _) -> True; _ -> False)
-- The actual reported exit is only direct-child evidence. Neither receipt,
-- marker, nor test implies whole provider/native/AT/IME/resource cleanup.
