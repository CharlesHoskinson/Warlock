# TEA001 type matrix: integrated wave delta

Source-only, unqualified; no tests or compiler run. This corrects the three now-integrated entries in the earlier `terra-graph-tea001-type-coverage.md` (SHA256 2b7eadea972164c3db3536ced398dca7934548d5683595fccd6f1c50d4e9edd9). Its remaining review candidates are not automatically fixed, exhaustively adjudicated or accepted. Exact postwave 73-module lexical declaration inventory: `terra-graph-tea001-six-root-type-index-postwave.md` SHA256 6d9a1d9b7223891a153be8f1d30c6ead478f0283d088690b87de021580fc6b00.

- `JumpList.elm`: actual `ActionKind = DesktopAction | RecentAction`, `Action.kind : ActionKind`; source decoder and prefix conversion retain desktop/recent. `Surface.elm` pattern uses `RecentAction`. `JumpList.receive` still accepts String status; this is a separate source-audit item.
- `Notifications.elm`: actual `EntryState`, `OutcomeStatus`, `Verb` custom types retained in Entry, Model.outcome and Target. Decoder maps eight wire lifecycle values, outcomeStatus maps three statuses, verbName retains wire values. `receive` boundary still accepts String and locally resolves it; its direct caller/finite-boundary coverage and all typed cases need protected execution.
- `ReconciliationFrame.elm`: actual `ProofKind`, `RetirementOperation`, `GrantState` custom types retained in Proof. Decoders retain old allowed wire values; retirement proof correlation and native authority remain separate requirements.
- This source inspection is not evidence of successful compilation, source fixture outcome, preserved full wire bytes or original EARS acceptance. Root reports four affected replay roots and native pointer fixture added to mandatory checks; run them only through Root's protected serialization.
- Still open for audit: Snap.Proposal finite String region retained in Effects.SnapPlacement, GeometryProjection operations strings, SystemMenu finite permissions/power strings and receipt API, Motion source, other child receipt APIs, Popup preview iconKind, CapturedAction envelope, surface projection discriminators, and full observation/desired-state and single-authority verification across six actual roots. Preserve unbounded identity/text as text; do not infer finite state from names alone.

Exact reviewed source hashes:
2ef6dbc9738771b1e13c8d42feb70c0905be8651d791a43199264b32883de195  implementation/warlock/src/JumpList.elm
91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca  implementation/warlock/src/Surface.elm
e61311c370fc0367844deb21a9ba3274a64f41faabe19bec6743af71685e2201  implementation/warlock/src/Notifications.elm
5f9480ab13609f26a3f57f37431e9eb29c658b1c009b463321e0f277d37b8ac5  implementation/warlock/src/ReconciliationFrame.elm
91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4  implementation/warlock/src/Desktop.elm
80c574e8c564c28a1fb11f1f89bb5bfa7ac97a92474bbf027a737324bb2a82cd  implementation/warlock/src/Effects.elm
8ee61de4cd63557d3f2928893ed35ce93f1e3290128847e66ca388aa5d98ec8e  implementation/warlock/src/Snap.elm
f1b5708b8b4d1c7c02e46542bc041abb9e8cb0524d965ee4b03ab97f586a544c  implementation/warlock/src/GeometryProjection.elm
cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054  implementation/warlock/src/SystemMenu.elm
e101862bae874426f0cf9aaf02340c6582abdeea21dec38c32003da7f94e8a69  implementation/warlock/src/Motion.elm
10769b8d9a86e5e5b35f1f292d9837a38b20a0ba636d5baa0ee0c3b8fcdac1cc  implementation/warlock/src/PreviewPresenter.elm
5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc  implementation/warlock/src/CapturedAction.elm
