'use strict';
// Proposed UNRUN PreviewStateReplay consumer for the exact dd9a2095 source patch.
// Root must bind the complete Elm source/compiler/JS/runner tuple externally.
// Usage: node runner /absolute/preview-states.js /absolute/output.json
// This is synthetic component evidence, not native capture, pixels or AT.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const [artifact, output] = process.argv.slice(2);
if (process.argv.length !== 4 || !path.isAbsolute(artifact || '') || !path.isAbsolute(output || '') || artifact === output) {
  throw Error('Expected distinct absolute artifact and report paths');
}
const expected = Object.freeze([
  'actualPickerSnapshot','supportedNativeSource','unsupportedPickerEligibilityRejected',
  'legacyCannotBecomeEligible','oneElmAcquire','loading','liveNeedsFence','currentLive',
  'authorizedHistorical','unavailable','fullFamilyCoverageRequired',
  'foreignIncarnationCannotBorrowPixels','hostRetirementUsesElmRelease',
  'foreignBindingCannotRetire','sameLeaseRetainsCustody','newPublicationHidesOldPixels',
  'nativeRefreshAuthorizesRetainedPixels','newLeaseHidesOldFrame',
  'metadataApplicationRoundTrip','metadataGenericRoundTrip','metadataUnavailableRoundTrip',
  'metadataRejectsUnknownKind','metadataRejectsMissingIcon','metadataRejectsUnavailableWithIcon',
  'metadataRejectsInvalidOpaqueIcon','metadataRejectsStaleAndForeign',
  'metadataKeepsOwnedLiveResource','metadataRetirementControlsUnchanged',
  'metadataAfterRetirementRejected','metadataFallbackUsesOpaqueIcon'
]);
const assert = (ok, message) => { if (!ok) throw Error(message); };
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const source = fs.readFileSync(artifact);
const sandbox = { console, setTimeout, clearTimeout };
vm.createContext(sandbox);
const realm = vm.runInContext('({ object: Object.prototype, array: Array.prototype })', sandbox);
function jsonValue(value, where, ancestors = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number') { assert(Number.isFinite(value) && !Object.is(value, -0), `${where}: invalid number`); return; }
  assert(typeof value === 'object' && !ancestors.has(value), `${where}: unsupported/cyclic`);
  const array = Array.isArray(value);
  const proto = Object.getPrototypeOf(value);
  assert(proto === (array ? realm.array : realm.object) || (!array && proto === null), `${where}: prototype`);
  assert(Object.getOwnPropertySymbols(value).length === 0, `${where}: symbols`);
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const keys = Object.keys(descriptors);
  if (array) {
    assert(keys.includes('length') && keys.length === value.length + 1, `${where}: sparse/extended array`);
    for (let i = 0; i < value.length; i++) assert(Object.hasOwn(descriptors, String(i)), `${where}: sparse array`);
  }
  ancestors.add(value);
  for (const key of keys) {
    if (array && key === 'length') continue;
    const descriptor = descriptors[key];
    assert(descriptor.enumerable && Object.hasOwn(descriptor, 'value'), `${where}.${key}: hidden/accessor`);
    jsonValue(descriptor.value, `${where}.${key}`, ancestors);
  }
  ancestors.delete(value);
}
function exactKeys(value, names, where) {
  assert(value && typeof value === 'object' && !Array.isArray(value), `${where}: object required`);
  const actual = Object.keys(value).sort();
  assert(JSON.stringify(actual) === JSON.stringify([...names].sort()), `${where}: unexpected fields`);
}
let count = 0, payload, finished = false, windowTimer;
const watchdog = setTimeout(() => fail('Timed out waiting for exactly one result'), 3000);
function fail(reason) {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog); clearTimeout(windowTimer);
  process.stderr.write(String(reason) + '\n');
  process.exitCode = 1;
}
function accept(value) {
  if (finished) return;
  count += 1;
  if (count !== 1) return fail('Duplicate result within observation window');
  try {
    jsonValue(value, 'result');
    exactKeys(value, ['checks','frame','states','emitted'], 'result');
    exactKeys(value.checks, expected, 'checks');
    assert(expected.length === 30 && new Set(expected).size === expected.length, 'manifest invalid');
    for (const name of expected) assert(value.checks[name] === true, `failed: ${name}`);
    assert(Array.isArray(value.states) && value.states.length === 4, 'expected four states');
    assert(Array.isArray(value.emitted), 'emitted must be an array');
    payload = JSON.parse(JSON.stringify(value));
    windowTimer = setTimeout(() => {
      try {
        assert(count === 1, 'duplicate result');
        fs.writeFileSync(output, JSON.stringify({ schema:1, scope:'synthetic PreviewStateReplay; no native or AT acceptance',
          artifactSha256:hash(source), runnerSha256:hash(fs.readFileSync(__filename)),
          namedChecks:expected.length, duplicateWindowMs:25, result:payload }, null, 2) + '\n', { flag:'wx' });
        finished = true; clearTimeout(watchdog);
      } catch (error) { fail(error.stack || error); }
    }, 25);
  } catch (error) { fail(error.stack || error); }
}
try {
  vm.runInContext(source.toString('utf8'), sandbox, { timeout:2000 });
  const app = sandbox.Elm.PreviewStateReplay.init();
  app.ports.outgoing.subscribe(accept);
} catch (error) { fail(error.stack || error); }
