port module SiteMainHeadFixture2205 exposing (main)

{-| Pure-Elm deterministic replay & source-contract fixture for
`SiteMainHeadMvpFrozen2205.elm` (`sha256:90f3121ab50c7744be966ec5912a80f014db0fc258ea05e7e5f8f958b27fefda`).
Worker executes zero compiler/Node/browser/VM commands; Root compiles and runs
in an isolated staging directory alongside `SiteMain.elm`.
-}

import Browser.Dom as Dom
import Json.Decode as Decode
import Json.Encode as Encode
import Platform
import SiteMain
    exposing
        ( AppearanceTheme(..)
        , FocusTarget(..)
        , Model
        , MotionMode(..)
        , Msg(..)
        , OutcomeSample(..)
        , SurfaceCategory(..)
        , SurfaceId(..)
        )


port outgoing : Encode.Value -> Cmd msg


initialModel : Model
initialModel =
    Tuple.first (SiteMain.init ())


expectedScenarioSlugs : List String
expectedScenarioSlugs =
    [ "taskbar"
    , "launcher"
    , "switcher"
    , "task-view"
    , "transfer"
    , "picker"
    , "preview-states"
    , "snap"
    , "notifications"
    , "settings"
    , "files"
    , "system"
    , "window-menu"
    , "confirmation"
    , "application-actions"
    , "status-recovery"
    ]


keyEvent : List ( String, Encode.Value ) -> Encode.Value
keyEvent pairs =
    Encode.object pairs


decodesOk : Decode.Decoder a -> Encode.Value -> Bool
decodesOk decoder raw =
    case Decode.decodeValue decoder raw of
        Ok _ ->
            True

        Err _ ->
            False


decodesErr : Decode.Decoder a -> Encode.Value -> Bool
decodesErr decoder raw =
    not (decodesOk decoder raw)


checks : List ( String, Bool )
checks =
    let
        -- 1. Initial model contract
        initCheck =
            initialModel.theme
                == ThemeNight
                && initialModel.motion
                == MotionStandard
                && initialModel.mobileNavOpen
                == False
                && initialModel.spotlight
                == SurfaceTaskbar
                && initialModel.tabFocusSeq
                == 0
                && initialModel.lastTabFocusMiss
                == Nothing
                && initialModel.scenarioCategory
                == CategoryAll
                && initialModel.category
                == CategoryAll

        -- 2. MVP Availability & Acceptance-Limits Matrix invariants
        rows =
            SiteMain.mvpMatrixRows

        rowIdsOk =
            List.map .rowId rows
                == [ "wl-mvp-row-browser"
                   , "wl-mvp-row-contracts"
                   , "wl-mvp-row-omarchy-vm"
                   , "wl-mvp-row-native-release"
                   ]

        ledgerCountsOk =
            case rows of
                [ browserRow, contractsRow, vmRow, nativeRow ] ->
                    browserRow.badgeLabel
                        == "Runnable now · Simulated"
                        && contractsRow.badgeLabel
                        == "17 / 242 whole EARS · 41 / 417 scenarios"
                        && String.contains "ELM-TEA-002" contractsRow.verifiedState
                        && String.contains "ELM-TEA-005" contractsRow.verifiedState
                        && vmRow.badgeLabel
                        == "Partial 28s VM component trial"
                        && nativeRow.badgeLabel
                        == "Unaccepted · Not released"
                        && String.contains "225 of 242" nativeRow.verifiedState
                        && String.contains "376 of 417" nativeRow.verifiedState

                _ ->
                    False

        acceptanceLimitsOk =
            case rows of
                [ browserRow, contractsRow, vmRow, nativeRow ] ->
                    String.contains "never prove" browserRow.acceptanceLimit
                        && String.contains "zero native GUI" contractsRow.acceptanceLimit
                        && String.contains "HOSTSTOP2" vmRow.acceptanceLimit
                        && String.contains "nativeOperations = []" vmRow.acceptanceLimit
                        && String.contains "Full release gate" nativeRow.acceptanceLimit

                _ ->
                    False

        -- 3. All 16 canonical scenarios & independent category filter
        scenarioSlugsOk =
            List.map .slug SiteMain.allScenarioSpecs == expectedScenarioSlugs

        scenarioPartitionOk =
            let
                countCat cat =
                    List.length (List.filter (\s -> s.category == cat) SiteMain.allScenarioSpecs)
            in
            countCat CategoryWindows
                == 7
                && countCat CategoryAppsFiles
                == 3
                && countCat CategorySystem
                == 6
                && List.length SiteMain.allScenarioSpecs
                == 16

        ( afterScenarioFilter, scenarioFilterFocus ) =
            SiteMain.transition (SelectScenarioCategory CategorySystem) initialModel

        ( afterBothFilters, featureFilterFocus ) =
            SiteMain.transition (SelectCategory CategoryWindows) afterScenarioFilter

        independentFiltersOk =
            afterScenarioFilter.scenarioCategory
                == CategorySystem
                && afterScenarioFilter.category
                == CategoryAll
                && scenarioFilterFocus
                == []
                && afterBothFilters.scenarioCategory
                == CategorySystem
                && afterBothFilters.category
                == CategoryWindows
                && featureFilterFocus
                == []

        -- 4. Mobile drawer Escape focus return vs CloseMobileNav
        ( openedDrawer, openFocus ) =
            SiteMain.transition ToggleMobileNav initialModel

        ( escapedOpen, escapeOpenFocus ) =
            SiteMain.transition EscapeMobileNav openedDrawer

        ( escapedClosed, escapeClosedFocus ) =
            SiteMain.transition EscapeMobileNav initialModel

        ( linkClosed, linkCloseFocus ) =
            SiteMain.transition CloseMobileNav openedDrawer

        mobileEscapeOk =
            openedDrawer.mobileNavOpen
                == True
                && openFocus
                == []
                && escapedOpen.mobileNavOpen
                == False
                && escapedOpen.tabFocusSeq
                == 1
                && escapeOpenFocus
                == [ FocusElement SiteMain.mobileNavToggleDomId ]
                && escapedClosed
                == initialModel
                && escapeClosedFocus
                == []
                && linkClosed.mobileNavOpen
                == False
                && linkCloseFocus
                == []

        -- 5. 8-tab roving wrap, Home, End, and stale FocusSettled guards
        ( wrappedLeft, wrappedLeftFocus ) =
            SiteMain.transition (KeyboardStepSpotlight -1) initialModel

        ( wrappedBackRight, wrappedBackRightFocus ) =
            SiteMain.transition (KeyboardStepSpotlight 1) wrappedLeft

        ( jumpedEnd, jumpedEndFocus ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceFiles) initialModel

        ( jumpedHome, jumpedHomeFocus ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceTaskbar) jumpedEnd

        rovingTabsOk =
            wrappedLeft.spotlight
                == SurfaceFiles
                && wrappedLeft.tabFocusSeq
                == 1
                && wrappedLeftFocus
                == [ FocusElement "wl-tab-files" ]
                && wrappedBackRight.spotlight
                == SurfaceTaskbar
                && wrappedBackRight.tabFocusSeq
                == 2
                && wrappedBackRightFocus
                == [ FocusElement "wl-tab-taskbar" ]
                && jumpedEnd.spotlight
                == SurfaceFiles
                && jumpedEndFocus
                == [ FocusElement "wl-tab-files" ]
                && jumpedHome.spotlight
                == SurfaceTaskbar
                && jumpedHomeFocus
                == [ FocusElement "wl-tab-taskbar" ]

        ( currentMiss, _ ) =
            SiteMain.transition
                (FocusSettled 1 "wl-tab-files" (Err (Dom.NotFound "wl-tab-files")))
                wrappedLeft

        ( staleMissIgnored, _ ) =
            SiteMain.transition
                (FocusSettled 1 "wl-tab-files" (Err (Dom.NotFound "wl-tab-files")))
                wrappedBackRight

        ( wrongTargetIgnored, _ ) =
            SiteMain.transition
                (FocusSettled 2 "wl-tab-files" (Err (Dom.NotFound "wl-tab-files")))
                wrappedBackRight

        focusSettledGuardsOk =
            currentMiss.lastTabFocusMiss
                == Just "wl-tab-files"
                && staleMissIgnored.lastTabFocusMiss
                == Nothing
                && wrongTargetIgnored.lastTabFocusMiss
                == Nothing

        -- 6. Strict missing-only optional field decoding & IME composition safety
        missingOptionalDefaultsOk =
            Decode.decodeValue
                SiteMain.decodeWorkbenchTabKey
                (keyEvent [ ( "key", Encode.string "ArrowRight" ) ])
                == Ok ( KeyboardStepSpotlight 1, True )
                && Decode.decodeValue
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent [ ( "key", Encode.string "Escape" ) ])
                == Ok EscapeMobileNav

        explicitNullRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.null )
                    ]
                )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent
                        [ ( "key", Encode.string "ArrowRight" )
                        , ( "keyCode", Encode.null )
                        ]
                    )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "isComposing", Encode.null )
                        ]
                    )

        wrongTypeRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.string "false" )
                    ]
                )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "keyCode", Encode.string "27" )
                        ]
                    )

        imeRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.bool True )
                    ]
                )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent
                        [ ( "key", Encode.string "ArrowLeft" )
                        , ( "keyCode", Encode.int 229 )
                        ]
                    )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent [ ( "key", Encode.string "Process" ) ])
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "isComposing", Encode.bool True )
                        ]
                    )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "keyCode", Encode.int 229 )
                        ]
                    )

        tabNeverTrappedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent [ ( "key", Encode.string "Tab" ) ])
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent [ ( "key", Encode.string "Tab" ) ])

        -- 7. Theme, motion, cues, and outcome state transitions
        ( dawnModel, _ ) =
            SiteMain.transition (SelectTheme ThemeDawn) initialModel

        ( hcModel, _ ) =
            SiteMain.transition (SelectTheme ThemeHighContrast) dawnModel

        ( reducedModel, _ ) =
            SiteMain.transition ToggleMotion hcModel

        ( cueToggled, _ ) =
            initialModel
                |> SiteMain.transition ToggleWindowFocused
                |> Tuple.first
                |> SiteMain.transition ToggleActiveApplication
                |> Tuple.first
                |> SiteMain.transition ToggleSwitcherCandidate

        ( refusedModel, _ ) =
            SiteMain.transition (SelectOutcomeSample SampleRefused) cueToggled

        appearanceAndLabsOk =
            dawnModel.theme
                == ThemeDawn
                && hcModel.theme
                == ThemeHighContrast
                && reducedModel.motion
                == MotionReduced
                && cueToggled.cues
                == { windowFocused = False, activeApplication = False, switcherCandidate = True }
                && refusedModel.outcomeSample
                == SampleRefused
    in
    [ ( "initialModelDefaults", initCheck )
    , ( "mvpMatrixHasFourDistinctTiers", rowIdsOk )
    , ( "mvpMatrixRecordsExact17Of242And41Of417", ledgerCountsOk )
    , ( "mvpMatrixSeparatesSimulatedVmAndNativeLimits", acceptanceLimitsOk )
    , ( "allSixteenCanonicalScenarioSlugsPresent", scenarioSlugsOk )
    , ( "scenarioCategoryPartitionSumsToSixteen", scenarioPartitionOk )
    , ( "scenarioFilterIndependentOfFeatureFilter", independentFiltersOk )
    , ( "mobileNavEscapeClosesAndRestoresToggleFocus", mobileEscapeOk )
    , ( "eightSurfaceRovingTabWrapHomeAndEnd", rovingTabsOk )
    , ( "focusSettledRejectsStaleSeqAndWrongTarget", focusSettledGuardsOk )
    , ( "genuinelyMissingOptionalEventFieldsDefaultCleanly", missingOptionalDefaultsOk )
    , ( "explicitNullOptionalEventFieldsStrictlyRejected", explicitNullRejectedOk )
    , ( "wrongTypedOptionalEventFieldsStrictlyRejected", wrongTypeRejectedOk )
    , ( "imeComposing229AndProcessStrictlyIgnored", imeRejectedOk )
    , ( "tabKeyNeverTrappedByWorkbenchOrHeader", tabNeverTrappedOk )
    , ( "appearanceCuesAndOutcomeTransitionsPure", appearanceAndLabsOk )
    ]


payload : Encode.Value
payload =
    let
        allPassed =
            List.all Tuple.second checks
    in
    Encode.object
        [ ( "fixture", Encode.string "SiteMainHeadFixture2205" )
        , ( "passed", Encode.bool allPassed )
        , ( "checkCount", Encode.int (List.length checks) )
        , ( "checks"
          , Encode.object
                (List.map (\( name, ok ) -> ( name, Encode.bool ok )) checks)
          )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing payload )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
