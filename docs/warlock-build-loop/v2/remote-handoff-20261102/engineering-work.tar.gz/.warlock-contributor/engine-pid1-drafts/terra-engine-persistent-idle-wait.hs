-- Prospective internal helper, not yet connected to CredentialIngress.
-- Requires the already-owned socket and an owner-provided STM stop/death observation.
-- It creates no process, watcher thread, timer, credential or action authority.
module Warlock.Transport.PersistentIdleWait
  ( IdleWake(..), waitReadableOrStop ) where

import Control.Exception (bracket)
import GHC.Conc (STM, atomically, orElse, threadWaitReadSTM)
import qualified Network.Socket as Socket

data IdleWake reason = OwnerWake reason | Readable deriving (Eq, Show)

-- Caller must hold the channel's existing exclusive read gate and retain the
-- socket/owner through registration and deregistration.  The supplied stop
-- transaction must represent the same live owner's monotonic stop/death event;
-- this function cannot establish that provenance.  Owner wake wins when both
-- branches are ready.  Readable includes EOF; the existing credential reader
-- must decide EOF and verify SCM on every fragment.  No bytes are consumed.
--
-- The callback remains within withFdSocket for the full registration lifetime.
-- Any registration, wait or unregister exception is propagated; the owning
-- ingress must retire or quarantine its resources, never claim readiness.
waitReadableOrStop :: Socket.Socket -> STM reason -> IO (IdleWake reason)
waitReadableOrStop socket stopReady =
  Socket.withFdSocket socket $ \fd ->
    bracket (threadWaitReadSTM (fromIntegral fd)) snd $ \(readable, _) ->
      atomically ((OwnerWake <$> stopReady) `orElse` (readable >> pure Readable))
