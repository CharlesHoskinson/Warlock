{-# LANGUAGE OverloadedStrings #-}
-- Root-only pinned selected child. Real inherited socket fd0 supplies SCM.
-- No launcher, native effect, GUI surrogate, or synthetic credential sender.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless)
import qualified Data.ByteString as B
import qualified Data.Text.Encoding as TE
import System.Directory (renameFile)
import System.Environment (getArgs)
import System.Exit (exitFailure)
import System.FilePath (isAbsolute)
import System.IO (Handle, BufferMode(NoBuffering), hClose, hFlush, hSetBinaryMode, hSetBuffering)
import System.Posix.IO (OpenMode(WriteOnly), defaultFileFlags, exclusive, fdToHandle, openFd)
import System.Posix.Signals (Handler(Default), installHandler, sigTERM)
import System.Posix.Types (Fd(..))
import System.Timeout (timeout)
import qualified Warlock.Protocol.Framing as F
import qualified Warlock.Protocol.StrictJson as J

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

packet :: B.ByteString
packet = "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"\",\"bar\":[],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"7\"}],\"focus\":[]}"

readFrame :: Handle -> IO B.ByteString
readFrame input = do
  header <- B.hGet input 4
  count <- must (F.desktopGatewayHeaderLength header)
  unless (count <= 2048) (ioError (userError "fixture reply capacity"))
  bytes <- B.hGet input count
  unless (B.length bytes == count) (ioError (userError "fixture short reply"))
  pure bytes

main :: IO ()
main = do
  args <- getArgs
  receipt <- case args of
    [path] | isAbsolute path -> pure path
    _ -> ioError (userError "expected one owned absolute receipt name")
  _ <- installHandler sigTERM Default Nothing
  input <- fdToHandle (Fd 0)
  hSetBinaryMode input True
  hSetBuffering input NoBuffering
  framed <- must (F.desktopCommitPrefix packet)
  B.hPut input framed
  hFlush input
  observed <- timeout 1500000 (readFrame input)
  reply <- maybe (ioError (userError "no complete actual Backend reply")) pure observed
  text <- either (ioError . userError . show) pure (TE.decodeUtf8' reply)
  let bytes = TE.encodeUtf8 (J.renderJson (J.JObject [("received",J.JString text)]))
  fd <- openFd (receipt ++ ".writing") WriteOnly (Just 0o600) defaultFileFlags{exclusive=True}
  output <- fdToHandle fd
  B.hPut output bytes
  hClose output
  renameFile (receipt ++ ".writing") receipt
  -- Default TERM remains active. Do not exit naturally after the receipt and
  -- accidentally turn stop into an already-dead-child observation. This fixed
  -- QA self-bound is not a renewed runtime D; Root's outer D may be stricter.
  threadDelay 2500000
  exitFailure
