# Imminent Window Controller Review Against Omarchy Builtin Lock/Idle/Notification APIs & Preserved `Foot 2095`

- **Preparation status**: Source-bound review and concrete defect checklist only — **not** an executed VM/native run, **not** GUI/EARS/native/release acceptance (`15/242` whole requirements, `39/417` scenarios, `nativeOperations = []`, `HOSTSTOP2` preserved).
- **Author / Run**: `gemini-omarchy` on `warlock-20261031-setup` (`2026-11-01T16:12Z`).
- **Controllers & artifacts cross-examined**:
  - Root guest controller lineage: `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/live-controller-02.py` (`L1-72`) and `security-controller-negative-05-guard.py` (`L1-72`)
  - Draft trial harness: `.warlock-contributor/engine-pid1-drafts/engine-vm-trial.py` (`L1-385`, `sha256: ba76a624c3eefef29e42f737dd15abfa14e32f1c37bf38c4dc86d78ad4eae693`)
  - Helper script: `tools/omarchy_ui_mvp.py` (`L590-660, 885-925`)
  - Verified `155313Z` guest build (`engine-pid1-20261101T155313Z/guest-artifacts.stdout`):
    - `/home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-owner` (`sha256: 804d2f77b55f395af93b96eb0edb6d52c3d960f56b8e2725126f62b36ba4d5ed`, 186 deps)
    - `/home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-backend` (`sha256: 00e5755942c29ad53295fd0f3e2071533ecf4b851d1e0cef29e2ff341b530b7d`, 36 deps)
    - `/home/charl/warlock-mvp-20261101T1058Z/assets/HttpMain.html` (`60aa950faa9b405ea71267487e906eef11f614e1beda69a8ad09f7fb4b1f13f1`), `HttpBar.html` (`a79e3fecc5d741dbba926f780f206d3fad658c689c978718a564837db1e8be98`), `HttpPopup.html` (`4713fbf12dcc597af389b2800f9fc69b30718fafe7fd421e3446ff722b9e1f30`)
  - Retained guest session baselines: `run-02/preservation-before.json` (`L1-357`), `run-02/idle-restoration.json` (`L1-4`), and `/home/charl/vm/omarchy/CODEX-OMARCHY-TESTING.md` (`L157-167`).

---

## 1. Concrete Defects Requiring Immediate Fix Before Root's Bounded Window Trial

### Defect 1 (CRITICAL — Zero-Grace `SIGKILL` at Exact `D` in `live-controller-02.py:46, 53-55` Truncates `backendResultJson` When Window Actually Survives)
- **Where**: `live-controller-02.py:46, 53-55` (and `security-controller-negative-05-guard.py:46, 53-55`):
  ```python
  while p.poll() is None and time.monotonic()<deadline:
      ...
  if p.poll() is None:
      forced=True
      command(['systemctl','--user','kill','--kill-whom=all','--signal=KILL',UNIT])
  ```
- **Why it broke nothing in `run-02` but breaks on a real surviving window**:
  - In `run-02`, old `warlock-ui-owner` exited at `1.46s` (`StreamEOF`), never reaching `deadline` (`D`).
  - With the `155313Z` split (`EngineEntrypoint.hs:323-330`, `ui/Main.hs:59-61, 88-89`, `Backend.hs:209-240`):
    1. `warlock-ui-owner --engine-only` sets `localStop = True` at `D - 1.0s` (`left <= 1000000` us) to drain GTK/WebKit callbacks.
    2. Broker `warlock-ui-owner` closes RPC, reaps PID 1, retires sockets/threads (`Owner.hs:274-287`), checks `remainingMicros deadline > 0`, and exits right before `D`.
    3. `warlock-ui-backend` then reaps `warlock-ui-owner` inside `runBootstrapWithArguments`, runs `retireBootstrap` + `retireCatalog` + `retirePinStore`, and prints `backendResultJson` (`Backend.hs:210-240`) right across `D` (`± 100–400ms`).
  - Firing `SIGKILL` at `time.monotonic() >= deadline` with **zero** post-`D` reap/stdout drain window kills `warlock-ui-backend` mid-retirement, leaves `backend.stdout` empty (`0` bytes), and falsely sets `forcedAtOriginalDeadline = True`.
  - Conversely, `engine-vm-trial.py:280, 358-359` omits `systemctl --user kill` entirely when `launcher.poll() is None`, risking an orphaned live window next to `Foot 2095`.
- **Fix**:
  - Keep immutable `deadlineMonotonicNs` (`D`) unchanged in `ui.json` and `backend.json` (the Haskell runtime enforces `D` internally).
  - At `time.monotonic() >= deadline`, record `exitedBeforeOriginalDeadline = (p.poll() is not None)`. Allow a bounded external reap/stdout drain window (`0.75s`–`1.0s` polling `p.poll()` every `50ms`, without extending `D`), and **only if `p.poll() is None` after that drain** set `forcedControllerKill = True` and run `systemctl --user kill --kill-whom=all --signal=KILL <UNIT>`. Record both `exitedBeforeOriginalDeadline` and `forcedControllerKill` distinctly.

---

### Defect 2 (CRITICAL — `engine-vm-trial.py:104-107, 310-313, 364` Deterministically Throws `RuntimeError: scope cleanup unqualified` on Every Clean Exit)
- **Where**: `engine-vm-trial.py:104-107` (`scope_members`), `L310` (`scope_after = scope_members(unit)`), and `L364` (`need(scope_after.get('known') and not scope_after['members'], 'scope cleanup unqualified')`).
- **Mechanism**:
  - Once the last process in `systemd-run --user --scope --unit=<UNIT>` exits cleanly, `systemd --user` immediately unloads and GCs the transient `.scope`: `systemctl --user show <UNIT> --property=ControlGroup --value` returns `""` (`LoadState=not-found`, `ActiveState=inactive`, `SubState=dead`) and `/sys/fs/cgroup/.../<UNIT>` ceases to exist.
  - `scope_members` calls `need(group.startswith('/') and group != '/', 'unknown scope cgroup')` (`L105`) + `.resolve(strict=True)` (`L106`), catching the exception at `L311-312` as `{'known': False}` and failing `L364` unconditionally!
- **Fix**:
  - Query `--property=LoadState,ActiveState,SubState,ControlGroup`. When `p.poll() is not None` and `ActiveState == 'inactive'` and `SubState == 'dead'` and `(ControlGroup == '' or not cgroup_path.exists())`, treat the transient `.scope` as unloaded/empty **iff** every `(pid, birth)` recorded in `observedOwnedIdentities` during the run is now `'absent'` or `'reused-pid'` (never `'same-incarnation'`). Note: `live-controller-02.py:28-32` (`if not group: return []`) avoids the crash only if combined with `(pid, birth)` verification so a lookup failure is never confused with cleanup.

---

### Defect 3 (CRITICAL — Omarchy Builtin `omarchy-shell` Lock/Idle/Notifications Hazards & `Foot 2095` Password-Injection Trap)
- **Empirical Omarchy builtin IPC (`quickshell` PID `10875`, `/home/charl/vm/omarchy/CODEX-OMARCHY-TESTING.md:157-167`, `run-02/idle-restoration.json:3`)**:
  - Requires `OMARCHY_PATH=/usr/share/omarchy LANG=C.UTF-8 LC_ALL=C.UTF-8` (`makoctl`, `hypridle`, and `hyprlock` are **not** running processes on this guest; `pgrep hyprlock`/`hypridle` is always empty even when locked!).
  - `omarchy-shell lock isLocked` prints literal `"true"` or `"false"`.
  - `omarchy-shell idle status` prints JSON:
    `{"enabled":true,"stayAwake":false,"stayAwakeStateLoaded":true,"screensaver":150,"lock":300,"dpms":330,"suspend":1800}`
    (`idle disable` -> `enabled: false, stayAwake: true`; `idle enable` -> `enabled: true, stayAwake: false`).
- **Three concrete bugs across existing scripts**:
  1. **`./vm-unlock.sh` password-leak hazard into `Foot 2095`**: `./vm-unlock.sh` types the guest password over QMP keys. Because `Foot 2095` (`bash` child `pid 2116`, `focusHistoryID: 0`) is the focused window on Workspace `1` whenever unlocked, calling `./vm-unlock.sh` without **first** checking `omarchy-shell lock isLocked == "true"` injects the guest password directly into `Foot 2095`'s live shell prompt and screenshots!
     - **Rule for Root**: Check `omarchy-shell lock isLocked` over SSH first; invoke `./vm-unlock.sh` **iff** stdout is `"true"`, then poll `isLocked == "false"`. Inside the guest controller, fail closed before `Popen` **and** before any QMP input if `isLocked != "false"`.
  2. **`tools/omarchy_ui_mvp.py:900` broken `grep -qi "enabled"`**: `echo "$ORIG_IDLE" | grep -qi "enabled"` always exits `0` on `{"enabled":false,...}` because the JSON key itself is `"enabled"`! Always parse JSON (`json.loads(raw)["enabled"]`).
  3. **`live-controller-02.py:33, 70` vs `engine-vm-trial.py:234, 340-362` idle mismatch & missing `notifications dismissAll` / DPMS wake**:
     - `live-controller-02.py:33` hardcodes `idle_before = dict(enabled=True, ...)` instead of reading `omarchy-shell idle status`, never disables idle (risking the `150s` screensaver / `330s` DPMS blanking output `headless-1`, which causes `grim` to hang until timeout), and never calls `omarchy-shell notifications dismissAll` before screenshots.
     - `engine-vm-trial.py:234` reads `before_idle` *after* Root's external disable, so if Root disabled idle before starting `trial()`, `before_idle["enabled"]` is `False` and `finally` leaves `stayAwake: true` enabled after the run!
     - **Fix**: Have a single owner (either Root's outer wrapper passing `--restore-idle-enabled=true/false` or the guest controller itself) record `pre_unlock_idle = json.loads(omarchy-shell idle status)` **before** disabling idle, run `omarchy-shell idle disable` + `omarchy-shell notifications dismissAll` + `./vm-wake.sh` for the bounded window run, and in `finally` restore exact `pre_unlock_idle["enabled"]` and assert post-restore `status["enabled"] == pre_unlock_idle["enabled"]` and `status["stayAwake"] == pre_unlock_idle["stayAwake"]`.

---

### Defect 4 (CRITICAL — Preserved `Foot 2095` Identity Verification & Hyprland Dwindle Half-Screen Coordinate Trap)
- **Exact preserved `Foot 2095` baseline (`run-02/preservation-before.json:6-53, 301-313`)**:
  - Process: `pid = 2095`, `birth = "6930"`, `ppid = 930`, `pgid = 2095`, `executable = "foot"`; child shell: `pid = 2116`, `birth = "6937"`, `ppid = 2095`, `executable = "bash"`.
  - Hyprland client: `address = "0x55fad233fd80"`, `class = "foot"`, `workspace.id = 1`, `floating = false`, unsplit `at = [12, 38], size = [1256, 750]`.
- **Two concrete bugs**:
  1. **`live-controller-02.py:34, 69` never asserts `Foot 2095` invariants**: Must assert before and after the run that `(2095, "6930")` and `(2116, "6937")` are alive, never appear in `UNIT` `cgroup.procs`, client `"0x55fad233fd80"` remains mapped on `workspace.id == 1`, and after Warlock exits `Foot 2095` returns to unsplit `[12, 38] 1256x750`!
  2. **Hyprland dwindle split coordinate trap (`1280x800`)**:
     - Because `Foot 2095` is tiled (`floating: false`) on Workspace `1`, mapping Warlock's undecorated `GtkWindow` splits Workspace `1` horizontally:
       - Left half (`x = 12..633`): **`Foot 2095`** (`at: [12, 38], size: [621, 750]`)
       - Right half (`x = 647..1268`): **Warlock `GtkWindow`** (`at: [647, 38], size: [621, 750]`, confirmed in `security-positive-01/observations.json:63-70`).
     - Any static/centered click with `x < 647` or any key event sent without first verifying `hyprctl activewindow -j` (`address == warlock_addr != "0x55fad233fd80"` and `pid == engine_host_pid != 2095`) **clicks or types directly into `Foot 2095` (`bash 2116`)**!
     - If QMP input is exercised inside the owned window, compute coordinates strictly from live `warlock_client["at"]` + `warlock_client["size"]` (`wx >= 647`), filter `#launcher-search` to `'foot'` before keyboard pin selection (`engine-mvp-pixel-observation-plan.md`), and note that pinning prepends `.warlock-pin` at index `0` on the left of `Bar`, shifting the `Applications` button rightward!

---

### Defect 5 (HIGH — Stale Binary Paths in `live-controller-02.py:38, 44`, Weak PID-1 Window Attribution at `L47`, & Expected Exit `1`)
1. **Stale `assets/` binary paths (`live-controller-02.py:38, 44`)**:
   - `ROOT/'assets/warlock-ui-owner'` (`88c51af4...`) and `ROOT/'assets/warlock-ui-backend'` are the pre-PID1-split binaries from `1058Z`.
   - Controller must pass `--ui-owner-bin /home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-owner` and `--ui-backend-bin /home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-backend` to `omarchy_ui_mvp.py guest-config` **and** `Popen` the same `155313Z` `warlock-ui-backend` binary, asserting both SHA-256 digests (`804d2f77...`, `00e57559...`) and the 3 HTML digests (`60aa950f...`, `a79e3fec...`, `4713fbf1...`) before launch.
2. **Weak window attribution (`live-controller-02.py:47`)**:
   - `c.get('pid') in own and c.get('mapped')` does not distinguish the outer broker (`warlock-ui-owner <ui.json>`), the held-exec PID-1 engine (`warlock-ui-owner --engine-only ...`), or `WebKitWebProcess` children inside `UNIT`.
   - Require for the attributed Warlock window `c`:
     - `c['pid'] in own` and `c['pid'] != 2095` and `c['address'] != '0x55fad233fd80'`,
     - `/proc/<pid>/exe` `(st_dev, st_ino)` equals `155313Z/assets/warlock-ui-owner`,
     - `/proc/<pid>/status` `NSpid:` is `[<host_pid>, 1]` (proving the GTK surface is owned by the child-PID-namespace PID-1 engine role), and
     - `/proc/<pid>/cmdline` argv[1] == `"--engine-only"`.
3. **Expected exit code `1` (`ui/Main.hs:75, 91`, `Backend.hs:227, 240`)**:
   - `prepareSelected` returns `EngineResult False False` (`ui/Main.hs:75`), so `warlock-ui-owner` exits `1` and `warlock-ui-backend` prints `{"schema":1,"passed":false,"cleanup":true,"callbacks":...,"operations":...,"nativeAccepted":false,"releaseAccepted":false}` and exits `1`.
   - Controller must parse `backend.stdout` JSON and treat `exit == 1` + `cleanup == True` + `callbacks >= 1` as an honest bounded diagnostic observation (`nativeAccepted: false`, `releaseAccepted: false`), never fabricating `exit == 0` or acceptance.

---

## 2. Minimal Drop-In Guard Sequence for Root's Imminent Guest Controller

```python
# 1. Pre-trial Foot 2095 & builtin lock/idle check (fail closed before Popen):
assert command(['omarchy-shell', 'lock', 'isLocked']).stdout.strip() == 'false'
idle_before = json.loads(command(['omarchy-shell', 'idle', 'status']).stdout)
command(['omarchy-shell', 'idle', 'disable'])
command(['omarchy-shell', 'notifications', 'dismissAll'])

def check_foot_preserved(procs, hypr_clients, require_unsplit=False):
    by_pid = {r['pid']: r for r in procs}
    assert by_pid.get(2095, {}).get('birth') == '6930'
    assert by_pid.get(2116, {}).get('birth') == '6937'
    foot_clients = [c for c in hypr_clients if c.get('address') == '0x55fad233fd80' and c.get('pid') == 2095]
    assert len(foot_clients) == 1 and foot_clients[0].get('mapped') is True
    if require_unsplit:
        assert foot_clients[0].get('size') == [1256, 750]
```

---

## 3. Addendum (`16:20Z`): Review of Root's Actual `live-controller-engine-01.py` (`ded935f3...`) & Retained `16:12Z` `run-01` Evidence

- **Actual controller reviewed**: `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-pid1-20261101T155313Z/live-controller-engine-01.py` (`L1-93`, `sha256: ded935f300755763b90403d77510dc56ccd57becc441bbf4d07929e011773c55`).
- **Retained `16:12Z` `run-01` facts verified**:
  - `trial-preflight.json`: observed `locked: true`, `idle.enabled: true, stayAwake: false` before unlock.
  - `live-controller-engine-01.py:51-56`: read `BUILD/'idle-before.json'`, verified `omarchy-shell lock isLocked == 'false'` before GUI launch, targeted `155313Z` `warlock-ui-owner` (`804d2f77...`) & `warlock-ui-backend` (`00e57559...`), restored `idle enable` (`idle-restoration.json` & `host-idle-restoration.json`: `exit: 0`, `enabled: true, stayAwake: false`), and preserved live `Foot` (`pid: 2095`, `address: "0x55fad233fd80"`, `at: [12, 38], size: [1256, 750]`) in `preservation-after.json`.
  - **Actual runtime outcome (`trial-result.json` + `backend.stdout` + `observations.json`)**:
    - `guest-config` took ~`1.35s` (`generatedMonotonicNs = 59793179126310`), and `warlock-ui-backend` + `selectedPid: 94314` (`warlock-ui-owner`) **exited in `< 95ms`** (`first observation monotonic = 59793.274s`, `observations.json` has `1` row with `ActiveState: "inactive"`, `SubState: "dead"`, `ControlGroup: ""`, `membershipKnown: false`, `observedMappedWindow: false`, `providerCleanupQualified: false`).
    - `backend.stdout`:
      `{"schema":1,"passed":false,"cleanup":true,"callbacks":0,"operations":0,"auth":"Just (FrameObserved (CredentialFrameRejected (CredentialTransport StreamEOF)))","credentialRows":0,"selectedPid":94314,"nativeAccepted":false,"releaseAccepted":false}`

### Concrete Defects & Diagnostic Gaps in `live-controller-engine-01.py` (`L1-93`)

1. **`live-controller-engine-01.py:11` Does Not Validate `WAYLAND_DISPLAY` + `XDG_RUNTIME_DIR` Before `Popen` (Direct `<95ms` `StreamEOF` Trigger Over SSH!)**:
   - `L11` sets `ENV = dict(os.environ, OMARCHY_PATH='/usr/share/omarchy', LANG='C.UTF-8', LC_ALL='C.UTF-8', GDK_BACKEND='wayland')` without checking `ENV.get('WAYLAND_DISPLAY')` or `ENV.get('XDG_RUNTIME_DIR')`.
   -Note: `hyprctl` (`L31`) and `omarchy-shell` (`L56`) succeed over SSH using `HYPRLAND_INSTANCE_SIGNATURE` + `XDG_RUNTIME_DIR` **even when `WAYLAND_DISPLAY` is unset**, or if `Backend.hs:204` (`readDisplayEnvironment`) sees `(Nothing, Nothing)` -> `Right []` (`Display.hs:20`), `warlock-ui-backend` spawns `warlock-ui-owner` (`selectedPid = 94314`) with `displayEnvironment = []`, which immediately aborts at `ui/Main.hs:85` (`require (not (null display)) "engine Wayland transport unavailable"`) **before `adoptNative` sends a single byte on `fd 0`**, producing the exact `<95ms` `StreamEOF` + `selectedPid: 94314`!
   -Wait: if only `XDG_RUNTIME_DIR` was set and `WAYLAND_DISPLAY` was unset, `resolveDisplayEnvironment (Just ...) Nothing` returns `Left` at `Backend.hs:204` (`selectedPid: null`). Because `selectedPid` WAS `94314`, `Backend.hs:204` succeeded (`WAYLAND_DISPLAY` WAS present in `ENV`!), narrowing `<95ms` `StreamEOF` in `selectedPid = 94314` to post-spawn broker/engine startup (`ui/Main.hs:80-86` -> `EngineCustody.hsc` -> `EngineBroker.hs` -> `EngineEntrypoint.hs` -> `WebKit.hs`), where `Backend.hs:238-240` discards selected-child stderr.
   - **Controller fix**: Explicitly record `(bool(ENV.get('XDG_RUNTIME_DIR')), ENV.get('WAYLAND_DISPLAY'))` and assert `(Path(ENV['XDG_RUNTIME_DIR']) / ENV['WAYLAND_DISPLAY']).is_socket()` in preflight JSON so transport env is proven rather than inferred.

2. **Three Exact Post-Spawn `<95ms` `StreamEOF` Candidates Inside `selectedPid = 94314` (`warlock-ui-owner`) for Root's Owned FD-2 Diagnosis (Do Not Guess — Observe Actual Error)**:
   - **Candidate 2a (`PrivateNetwork.hsc:103-104` / `EngineCustody.hsc:191-192` `length tasks == 1` vs Dynamic `libjavascriptcoregtk-6.0.so.1` `.init_array`)**: Unlike static host CPU `ui-engine-exec-controls` or dynamic `warlock-ui-backend` (36 deps, no WebKit), guest `warlock-ui-owner` (`804d2f77...`, 186 deps) dynamically links `libwebkitgtk-6.0.so.4` + `libjavascriptcoregtk-6.0.so.1` (`guest-build.stdout:282, 331`). If any `.init_array` constructor (`bmalloc`/`pas_scavenger`/GIO) creates an OS thread before `Main.main`, `enterPrivateNetwork` (`PrivateNetwork.hsc:104`, before `adoptNative`!) immediately throws `"private UI namespace needs one actual OS thread"` in `<10ms`, closing `fd 0` (`StreamEOF`)!
   - **Candidate 2b (`EngineCustody.hsc:592-607` `CLOSE_RANGE_CLOEXEC` + `execveat(..., AT_EMPTY_PATH)` on `FD_CLOEXEC` `image` FD)**: On Linux `fs/exec.c`, keeping `FD_CLOEXEC` set on `image` (`L598`) across `execveat(image, "", ..., AT_EMPTY_PATH)` closes `image` during `begin_new_exec` before dynamic `PT_INTERP` (`/lib64/ld-linux-x86-64.so.2`) opens `/dev/fd/<image>`, causing `ENOENT` -> `failChild` (`_exit(121)`) -> `Broker.completeStartup` `Indeterminate` -> `Owner` exits with `0` commits (`StreamEOF`).
   - **Candidate 2c (`EngineCustody.hsc:589` `dropCapabilities` + `NoNewPrivs=1` + `MS_NOEXEC /proc` vs WebKitGTK 6 `bwrap`)**: Inside PID 1 (`--engine-only`), WebKitGTK 6 spawns `bwrap`/`WebKitWebProcess` before `loadReady` -> `stepMvpWindow` -> initial topology commit; refusal under zero caps/`NoNewPrivs=1` aborts `runWebKit` before any commit reaches `fd 0` (`StreamEOF`).

3. **Remaining Window-Controller Guards to Retain on Next Trial (`live-controller-engine-01.py:53, 65-76, 90-92`)**:
   - **Live `Foot` sampling + exclusion (`peer caveat incorporated`)**: Sample live `Foot` `(pid, birth, address, at, size)` dynamically from `preservation-before.json` (`clients` + `processes`) rather than relying on historical constants alone; exclude all pre-existing `(pid, birth)` and client addresses from `eligible`/`visible`, and assert live `Foot` identity + unsplit geometry (`[12, 38], [1256, 750]`) in `preservation-after.json`.
   - ** Tighten `eligible` (`L67`)**: Require `len(r['namespacePids']) >= 2 and r['namespacePids'][0] == r['pid'] and r['namespacePids'][-1] == 1` (plus `/proc/<pid>/cmdline` argv[1] == `'--engine-only'`).
   - **Toast dismissal before `grim` (`L56, 72`)**: Call `command(['omarchy-shell', 'notifications', 'dismissAll'])` after `isLocked == 'false'` so notification popups cannot occlude `live-*.png`.
   - **Post-`D` reap recording (`L65, 74-76` + peer caveat)**: Never extend `deadlineMonotonicNs` (`D`); record `exitedByOriginalDeadline` strictly at `D`, keep any post-`D` backend reap/stdout observation separate from on-time completion, and retain `membershipKnown: False` / `providerCleanupQualified: False` honestly when `systemd --user` unloads the transient `.scope` (`ControlGroup == ''`).
