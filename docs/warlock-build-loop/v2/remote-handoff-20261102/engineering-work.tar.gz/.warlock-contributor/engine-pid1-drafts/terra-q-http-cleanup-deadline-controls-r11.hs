{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. One Case per independent guarded host. Root strongly
-- retains Case, owner, real child/FDs and a guardian on every result/error.
-- The driver MUST use the real same-owner natural child lifecycle and return
-- its actual SessionExit. No phase, containment, child or deadline is forged.
module QHttpCleanupDeadlineR11 (Case,newCase,runCase) where
import Control.Exception (mask)
import Control.Monad (unless)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),deadlineAbsoluteNs,remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),SessionExit(..),StopBudget,StopReceipt(..),
  StopDeadlineObservation(..),CleanupDeadlineObservation(..),newPersistentOwner,
  newPersistentRootCustody,persistentStatus,requestSessionStop,tryPersistentStopDeadline,
  tryPersistentCleanupDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaWithActualCleanupGate)
import Warlock.Platform.Resolver (Identity(..),RootCustody,withRetainedRoot)

data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool)
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("cleanup-deadline: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
-- Bounds QA observation by the existing absolute scenario/observation D.
-- On expiry the host retains all roots/guardian; no worker is killed.
within :: AdmissionDeadline -> String -> IO a -> IO a
within original label action = do
 left <- remainingMicros original
 if left<=0 then ioError (userError (label ++ ": original D expired; retain guardian")) else do
  value <- timeout left action
  maybe (ioError (userError (label ++ ": original D expired; retain guardian"))) pure value
absolute :: AdmissionDeadline -> IO Integer
absolute d = maybe (ioError (userError "invalid internal deadline")) pure (readMaybe (deadlineAbsoluteNs d))
runCase :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO SessionExit) -> IO ()
runCase (Case owner rootCell used) originalD stopBudget naturalDrive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case" fresh
 remainingMicros originalD >>= check "original D live" . (>0)
 noStop <- tryPersistentStopDeadline owner
 noCleanup <- tryPersistentCleanupDeadline owner
 check "fresh owner has no invented cleanup D" (noStop==StopDeadlineNotLatched && noCleanup==CleanupDeadlineNotSelected)
 held <- qaWithActualCleanupGate owner $ do
  c <- tryPersistentCleanupDeadline owner
  s <- tryPersistentStopDeadline owner
  pure (c,s)
 check "same actual held gate yields Busy" (held==Just (CleanupDeadlineBusy,StopDeadlineBusy))
 root <- newPersistentRootCustody owner >>= need
 writeIORef rootCell (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 acquired <- restore $ within originalD "actual root and natural child" $ withRetainedRoot root "/" ident $ \_ -> do
  natural <- within originalD "real same-owner child natural exit" (naturalDrive owner)
  phase <- within originalD "real owner phase" (persistentStatus owner)
  check "actual selected child naturally reaped and owner retired" $
   (case natural of LeaderReaped _ -> True; _ -> False) && phase==PersistentRetired
  beforeStop <- tryPersistentStopDeadline owner
  selected <- tryPersistentCleanupDeadline owner
  implicitD <- case selected of
   CleanupDeadlineSelected d -> pure d
   _ -> ioError (userError "real natural exit did not select containment D")
  check "implicit D exists without first explicit stop" (beforeStop==StopDeadlineNotLatched)
  remainingMicros implicitD >>= check "selected implicit D live" . (>0)
  first <- within originalD "first actual stop with unresolved root" (requestSessionStop owner stopBudget)
  explicit <- tryPersistentStopDeadline owner
  stopD <- case explicit of
   StopDeadlineLatched d -> pure d
   _ -> ioError (userError "first explicit stop D not selected")
  both <- tryPersistentCleanupDeadline owner
  implicitNs <- absolute implicitD
  stopNs <- absolute stopD
  actualNs <- case both of
   CleanupDeadlineSelected d -> absolute d
   _ -> ioError (userError "selected cleanup D became unknown")
  check "first stop intersects existing containment D" $
   first==StopUncertain CleanupUncertain && actualNs==min implicitNs stopNs
  repeated <- within originalD "repeat stop same owner" (requestSessionStop owner stopBudget)
  afterStop <- tryPersistentStopDeadline owner
  afterCleanup <- tryPersistentCleanupDeadline owner
  check "repeat cannot renew either deadline" $
   repeated==StopAlreadyRequested && afterStop==explicit && afterCleanup==both
 check "actual retained root callback returned" (acquired==Right ())
