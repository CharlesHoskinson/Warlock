{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY SOURCE DRAFT; NOT EXECUTED. Run one fresh Case per independently
-- guarded host process. The host must retain Case and any spawned worker even
-- on error/timeout; it owns independent child and fd containment. Its retire
-- callback MUST drive the real production lifecycle to PersistentRetired and
-- must never directly modify phase, gate, deadline, or custody state.
module TerraOwnerRootClose022
 ( Case, newCase, releaseTestBarrier, runPreseal, runPositiveAndForeign, runStopBefore, runStopDuring, runStopExpired, runLongLived ) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Posix.Files (deviceID, fileID, getFileStatus)
import System.Posix.IO (closeFd)
import System.Posix.Types (Fd)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, PersistentStatus(..), StopBudget, StopReceipt(..)
 , StopDeadlineObservation(..), newPersistentOwner, persistentStatus
 , newPersistentRootCustody, requestSessionStop, tryPersistentStopDeadline )
import Warlock.Capture.Process.Persistent.Internal (qaClosePersistentRootPartWith)
import Warlock.Platform.Resolver
 ( Identity(..), RootCustody, RootCustodyObservation(..), RootPart(..)
 , RootStepResult(..), observeRootCustody, withRetainedRoot )

-- The registered root and worker remain reachable across every exceptional
-- exit. A surrounding stable host root and separate guardian are mandatory.
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Int)
                 (IORef (Maybe ThreadId)) (IORef Bool) (MVar ()) (MVar Bool)
                 (MVar (Either SomeException (Either ToolError RootStepResult)))
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef 0
               <*> newIORef Nothing <*> newIORef False <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
-- A supervising guardian can unblock a retained worker without guessing an fd.
releaseTestBarrier :: Case -> IO ()
releaseTestBarrier (Case _ _ _ _ _ release _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label yes = unless yes (ioError (userError ("owner-root-close: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
-- Test watchdog only: it neither changes D nor proves worker termination.
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain host and guardian")) ) pure
identity :: IO Identity
identity = do
 s <- getFileStatus "/"
 pure (Identity (toInteger (deviceID s)) (toInteger (fileID s)))
prepare :: Case -> AdmissionDeadline -> IO (PersistentOwner,RootCustody)
prepare (Case owner slot _ _ used _ _ _) original = mask_ $ do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "one case per host" fresh
 live <- remainingMicros original
 check "supplied original D is live" (live > 0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 pure (owner,root)
retired :: PersistentOwner -> (PersistentOwner -> IO ()) -> IO ()
retired owner drive = do
 within "actual production lifecycle" (drive owner)
 state <- within "owner phase observation" (persistentStatus owner)
 check "actual owner reports retired" (state == PersistentRetired)
counted :: IORef Int -> Fd -> IO ()
counted n fd = modifyIORef' n (+1) >> closeFd fd

-- All cases use the actual root/proc open, identity validation and lexical
-- seal. 'drive' is supplied by the existing guarded real-Backend fixture.
runPreseal :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runPreseal c@(Case _ _ calls _ _ _ _ _) original stopBudget drive = do
 (owner,root) <- prepare c original
 expected <- identity
 result <- within "root lexical callback" $ withRetainedRoot root "/" expected $ \_ -> do
  retired owner drive
  stopped <- within "select first stop D" (requestSessionStop owner stopBudget)
  check "stop is unconfirmed while root active" (stopped == StopUncertain CleanupUncertain)
  denied <- within "pre-seal close" (qaClosePersistentRootPartWith (counted calls) owner RootAnchor)
  n <- readIORef calls
  check "unsealed actual pair is not physically closed" (denied == Left OwnerBusy && n == 0)
 a <- within "post-seal root close" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 b <- within "post-seal proc close" $ qaClosePersistentRootPartWith (counted calls) owner ProcAnchor
 n <- readIORef calls
 status <- observeRootCustody root
 check "pre-seal refusal did not consume either actual close" $
  result == Right () && a == Right RootStepClosed && b == Right RootStepClosed && n == 2 && status == RootRetired

runPositiveAndForeign :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runPositiveAndForeign c@(Case _ _ calls _ _ _ _ _) original stopBudget drive = do
 (owner,root) <- prepare c original
 foreignOwner <- newPersistentOwner
 expected <- identity
 result <- within "real pair and callback" $ withRetainedRoot root "/" expected (\_ -> retired owner drive)
 foreignResult <- within "foreign owner refused" $ qaClosePersistentRootPartWith (counted calls) foreignOwner RootAnchor
 foreignCount <- readIORef calls
 stopped <- within "select first stop D" (requestSessionStop owner stopBudget)
 check "stop while pair outstanding" (stopped == StopUncertain CleanupUncertain)
 a <- within "actual root close" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 duplicate <- within "duplicate refused" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 b <- within "actual proc close" $ qaClosePersistentRootPartWith (counted calls) owner ProcAnchor
 n <- readIORef calls
 status <- observeRootCustody root
 check "same owner only, two actual closes, no duplicate" $
  result == Right () && foreignResult == Left OwnerBusy && foreignCount == 0 &&
  a == Right RootStepClosed && duplicate == Left OwnerBusy && b == Right RootStepClosed &&
  n == 2 && status == RootRetired

runStopBefore :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runStopBefore c@(Case _ _ calls _ _ _ _ _) original stopBudget drive = do
 (owner,root) <- prepare c original
 expected <- identity
 result <- within "real pair and callback" $ withRetainedRoot root "/" expected (\_ -> retired owner drive)
 stop <- within "first stop" $ requestSessionStop owner stopBudget
 first <- tryPersistentStopDeadline owner
 a <- within "close under sticky stop D" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 b <- within "second close under same D" $ qaClosePersistentRootPartWith (counted calls) owner ProcAnchor
 next <- tryPersistentStopDeadline owner
 n <- readIORef calls
 status <- observeRootCustody root
 check "stop not fabricated clean; same D permits real closes" $
  result == Right () && stop == StopUncertain CleanupUncertain &&
  (case first of StopDeadlineLatched _ -> True; _ -> False) && first == next &&
  a == Right RootStepClosed && b == Right RootStepClosed && n == 2 && status == RootRetired

-- Pause inside the admitted actual first close; stop must latch while it is
-- active, then release it. No duplicate close is ever attempted on Unknown.
runStopDuring :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> (PersistentOwner -> IO ()) -> IO ()
runStopDuring c@(Case _ _ calls worker _ release decision done) original stopBudget drive selectContainment = mask $ \restore -> do
 (owner,root) <- prepare c original
 expected <- identity
 result <- restore $ within "real pair and callback" $ withRetainedRoot root "/" expected (\_ -> retired owner drive)
 restore (within "actual owner selects containment D" (selectContainment owner))
 entered <- newEmptyMVar
 let closeOnce fd = do
      putMVar entered ()
      readMVar release
      modifyIORef' calls (+1)
      closeFd fd
 _ <- mask_ $ do
  tid <- forkFinally (restore $ do
   allowed <- readMVar decision
   if allowed then qaClosePersistentRootPartWith closeOnce owner RootAnchor
    else ioError (userError "worker not authorized")) (putMVar done)
  writeIORef worker (Just tid)
  putMVar decision True
  pure tid
 within "inside admitted close" (readMVar entered)
 stop <- within "stop while close active" (requestSessionStop owner stopBudget)
 first <- tryPersistentStopDeadline owner
 void (tryPutMVar release ())
 receipt <- within "first close settles" (readMVar done) :: IO (Either SomeException (Either ToolError RootStepResult))
 next <- tryPersistentStopDeadline owner
 n <- readIORef calls
 check "same sticky D and one actual syscall attempt" $
  result == Right () && stop == StopUncertain CleanupUncertain &&
  (case first of StopDeadlineLatched _ -> True; _ -> False) && first == next && n == 1 &&
  (case receipt of Right (Right RootStepClosed) -> True; _ -> False)
 b <- within "remaining part" $ qaClosePersistentRootPartWith (counted calls) owner ProcAnchor
 status <- observeRootCustody root
 total <- readIORef calls
 check "both receipts and closes retained" (b == Right RootStepClosed && total == 2 && status == RootRetired)

-- This waits for the already-latched stop D; it never creates a replacement.
runStopExpired :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runStopExpired c@(Case _ _ calls _ _ _ _ _) original stopBudget drive = do
 (owner,root) <- prepare c original
 expected <- identity
 result <- within "real pair and callback" $ withRetainedRoot root "/" expected (\_ -> retired owner drive)
 stop <- within "first stop" $ requestSessionStop owner stopBudget
 first <- tryPersistentStopDeadline owner
 deadline <- case first of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "no latched stop D")
 let waitExpiry = do
      left <- remainingMicros deadline
      if left <= 0 then pure () else threadDelay (min left 10000) >> waitExpiry
 within "original stop D expires" waitExpiry
 denied <- within "expired step" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 next <- tryPersistentStopDeadline owner
 n <- readIORef calls
 status <- observeRootCustody root
 check "expired stop D is unchanged and no close starts" $
  result == Right () && stop == StopUncertain CleanupUncertain && first == next &&
  denied == Left TimedOut && n == 0 && status == RootUnconfirmed

-- This exercises startup-only D vs the source's later selected StopD. It does
-- not waive any original scenario's stricter end-to-end absolute deadline.
runLongLived :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> AdmissionDeadline -> IO ()) -> IO ()
runLongLived c@(Case _ _ calls _ _ _ _ _) startupD stopBudget driveLivePastDeadline = do
 (owner,root) <- prepare c startupD
 expected <- identity
 result <- within "real live session past startup D" $ withRetainedRoot root "/" expected (\_ -> retired owner (\sameOwner -> driveLivePastDeadline sameOwner startupD))
 startupRemaining <- remainingMicros startupD
 check "actual driver returned only after startup D" (startupRemaining <= 0)
 stop <- within "first later stop" (requestSessionStop owner stopBudget)
 first <- tryPersistentStopDeadline owner
 a <- within "root under later StopD" $ qaClosePersistentRootPartWith (counted calls) owner RootAnchor
 b <- within "proc under later StopD" $ qaClosePersistentRootPartWith (counted calls) owner ProcAnchor
 after <- tryPersistentStopDeadline owner
 n <- readIORef calls
 status <- observeRootCustody root
 check "startup-only D expired; existing stop D remains sticky" $
  result == Right () && stop == StopUncertain CleanupUncertain &&
  (case first of StopDeadlineLatched _ -> True; _ -> False) && first == after &&
  a == Right RootStepClosed && b == Right RootStepClosed && n == 2 && status == RootRetired
