{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY QA SOURCE DRAFT. Not compiled or run. No raw descriptor issuer.
-- Allocate and root the FixtureGuard (e.g. in Root's outer fixture registry)
-- BEFORE calling the supplier and retain it through every failure/timeout.
-- A held capability in this guard is NOT a child/process/pipe/reap receipt.
-- Root must independently install the actual child guardian before spawning.
-- Never retire a HeldUnknown capability or retry uncertain descriptor closure.
module TerraGraphRetainedFixture0024
 ( FixtureGuard, newFixtureGuard, validatedRetainedFixture, retainedSupplier ) where

import Control.Exception (mask)
import Control.Monad (unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.IORef (IORef, atomicModifyIORef', newIORef, writeIORef)
import Numeric (showHex)
import System.FilePath ((</>))
import System.Posix.Files (deviceID, fileID, getFileStatus)
import Warlock.Capture.Process.Persistent (PersistentOwner)
import Warlock.Platform.Executable
 ( ExecutableLease, HeldExecutable, LeaseRole(..), newExecutableLease
 , acquireExecutableLease, issueReadyExecutable )
import Warlock.Platform.Resolver (Identity(..), Kind(..), Pin(..), withRoot)

-- Lease remains retained alongside the moved HeldExecutable. The cell holds
-- no raw descriptor and has no recovery/close API. An exception during
-- validation or root cleanup never clears a capability already published.
data GuardState = Fresh | Preparing | LeaseRetained ExecutableLease
                | HeldRetained ExecutableLease HeldExecutable
newtype FixtureGuard = FixtureGuard (IORef GuardState)

newFixtureGuard :: IO FixtureGuard
newFixtureGuard = FixtureGuard <$> newIORef Fresh

-- Single-use. In particular, do not reuse after any exception or Left from
-- withRoot: its root/descriptor close disposition may be uncertain.
validatedRetainedFixture :: FixtureGuard -> FilePath -> FilePath -> IO HeldExecutable
validatedRetainedFixture (FixtureGuard cell) rootDir name = mask $ \restore -> do
 admitted <- atomicModifyIORef' cell $ \s -> case s of
  Fresh -> (Preparing, True)
  _ -> (s, False)
 unless admitted (ioError (userError "fixture guard already used"))
 rootStat <- restore (getFileStatus rootDir)
 fileStat <- restore (getFileStatus (rootDir </> name))
 bytes <- restore (B.readFile (rootDir </> name))
 let ident st = Identity (toInteger (deviceID st)) (toInteger (fileID st))
     pins = [Pin (C.pack ('/':name)) (ident fileStat) Regular]
     hex n = let s = showHex n "" in if length s == 1 then '0':s else s
     digest = C.pack (concatMap hex (B.unpack (SHA.hash bytes)))
 result <- restore $ withRoot (C.pack rootDir) (ident rootStat) $ \root -> mask $ \restoreAcquire -> do
  -- There is no asynchronous exception window between creation and publication.
  lease <- newExecutableLease
  writeIORef cell (LeaseRetained lease)
  validated <- restoreAcquire $
   acquireExecutableLease lease root pins (C.pack name) [] (toInteger (B.length bytes)) digest UiImage
  case validated of
   Left e -> ioError (userError (show e))
   Right () -> do
    -- Both issue and publication run masked. withRoot's closing bracket has
    -- not run yet; if it later throws or returns Left, cell still owns held.
    issued <- issueReadyExecutable lease
    case issued of
     Nothing -> ioError (userError "validated fixture issuance failed")
     Just (held,_,_) -> do
      writeIORef cell (HeldRetained lease held)
      pure held
 case result of
  Left e -> ioError (userError (show e))
  Right held -> pure held

-- Adapter matching owner-route fixtures. The PersistentOwner is retained by
-- their separate Probe; it does not confer raw Owner or process authority here.
retainedSupplier :: FixtureGuard -> FilePath -> FilePath -> PersistentOwner -> IO HeldExecutable
retainedSupplier guard rootDir name _ = validatedRetainedFixture guard rootDir name
