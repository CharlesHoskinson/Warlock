{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Actual selected child/ProcessHandle and its guardian
-- are retained by the host. Timeouts only observe MVars; no worker is killed.
module QHttpFinalWait001 (Mode(..),Case,newCase,runCase,retainedWorker,retainedResult,retainedStop) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Directory (doesFileExist,removeFile)
import System.FilePath (isAbsolute)
import System.IO (Handle)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Internal
 (AdmissionDeadline,ToolError(..),SessionObservation(..),deadlineAbsoluteNs,leaderExited,observeChild,remainingMicros)
import Warlock.Capture.Process.Persistent.Internal
 (PersistentOwner,PersistentStatus(..),PidfdCustody(..),SessionExit(..),StopBudget,
  CleanupDeadlineObservation(..),StopDeadlineObservation(..),StopReceipt(..),newPersistentOwner,persistentStatus,persistentPidfdCustody,
  persistentFixture,startBudgetFromDeadline,observeLiveStartup,tryPersistentCleanupDeadline,tryPersistentStopDeadline,requestSessionStop,withPersistentOwnerHook)

data Mode = Timely | LateReceipt deriving (Eq,Show)
type Result = Either SomeException (Either SessionExit ((),SessionExit))
data Case = Case PersistentOwner Handle (IORef Bool) (IORef (Maybe ThreadId)) (MVar Result)
 (IORef (Maybe SessionObservation)) (IORef [String]) (MVar ()) (MVar ()) (MVar ()) (MVar ())
 (IORef (Maybe ThreadId)) (MVar (Either SomeException StopReceipt)) (IORef (Maybe AdmissionDeadline))
newCase :: Handle -> IO Case
newCase input = Case <$> newPersistentOwner <*> pure input <*> newIORef False <*> newIORef Nothing <*> newEmptyMVar
 <*> newIORef Nothing <*> newIORef [] <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newIORef Nothing <*> newEmptyMVar <*> newIORef Nothing
retainedWorker :: Case -> IO (Maybe ThreadId)
retainedWorker (Case _ _ _ worker _ _ _ _ _ _ _ _ _ _) = readIORef worker
retainedResult :: Case -> IO (Maybe Result)
retainedResult (Case _ _ _ _ done _ _ _ _ _ _ _ _ _) = tryReadMVar done
retainedStop :: Case -> IO (Maybe ThreadId,Maybe (Either SomeException StopReceipt))
retainedStop (Case _ _ _ _ _ _ _ _ _ _ _ worker done _) = (,) <$> readIORef worker <*> tryReadMVar done
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("final-wait: " ++ label)))
wait :: AdmissionDeadline -> String -> MVar a -> IO a
wait d label cell = do
 left <- remainingMicros d
 if left<=0 then ioError (userError (label ++ ": Unknown; retain guardian")) else do
  value <- timeout left (readMVar cell)
  maybe (ioError (userError (label ++ ": Unknown; retain guardian"))) pure value
absolute :: AdmissionDeadline -> IO Integer
absolute d = maybe (ioError (userError "invalid actual deadline")) pure (readMaybe (deadlineAbsoluteNs d))
waitBounds :: [AdmissionDeadline] -> String -> MVar a -> IO a
waitBounds ds label cell = do
 left <- minimum <$> mapM remainingMicros ds
 if left<=0 then ioError (userError (label ++ ": Unknown; retain guardian")) else do
  value <- timeout left (readMVar cell)
  maybe (ioError (userError (label ++ ": Unknown; retain guardian"))) pure value
awaitFirst :: AdmissionDeadline -> AdmissionDeadline -> PersistentOwner -> IO AdmissionDeadline
awaitFirst originalD implicitD owner = do
 a <- remainingMicros originalD
 b <- remainingMicros implicitD
 check "existing D live awaiting first stop" (min a b>0)
 current <- tryPersistentStopDeadline owner
 case current of
  StopDeadlineLatched d -> pure d
  StopDeadlineFailed _ -> ioError (userError "actual first StopD failed")
  _ -> threadDelay (min 1000 (min a b)) >> awaitFirst originalD implicitD owner
observeReadOnly :: AdmissionDeadline -> String -> IO a -> IO a
observeReadOnly d label action = do
 left <- remainingMicros d
 if left<=0 then ioError (userError (label ++ ": Unknown; retain guardian")) else do
  value <- timeout left action
  maybe (ioError (userError (label ++ ": Unknown; retain guardian"))) pure value
awaitDead :: AdmissionDeadline -> SessionObservation -> IO ()
awaitDead originalD observed = do
 left <- remainingMicros originalD
 check "original trial D live while observing child" (left>0)
 dead <- leaderExited (observedPid observed)
 unless dead (threadDelay (min left 1000) >> awaitDead originalD observed)
awaitExpiry :: AdmissionDeadline -> AdmissionDeadline -> IO ()
awaitExpiry originalD selected = do
 left <- remainingMicros selected
 if left<=0 then pure () else do
  remainingMicros originalD >>= check "original observation D still live" . (>0)
  threadDelay (min left 1000)
  awaitExpiry originalD selected

-- Root supplies the actual source-selected child peer001, a distinct private
-- precreated trigger, original absolute trial D, actual owned input handle,
-- valid StopBudget and external guardian. One case/child per isolated process.
-- Host must arrange original trial D longer than the selected cleanup D for
-- the late case; otherwise report the setup unobserved, never mint a new D.
runCase :: Case -> AdmissionDeadline -> StopBudget -> StopBudget -> FilePath -> FilePath -> Mode -> IO ()
runCase (Case owner input used worker done observed events liveReady liveRelease waitReturned waitRelease stopWorker stopDone retainedFirst)
 originalD stopBudget firstStopBudget child marker mode = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "one case; absolute child and owned marker" (fresh && isAbsolute child && isAbsolute marker)
 exists <- doesFileExist marker
 check "owned trigger precreated" exists
 start <- newEmptyMVar
 let verify actual = do
      same <- observeChild originalD (observedPid actual)
      let valid = same==Right actual && observedPid actual>0 &&
                  not (B.null (observedStart actual)) && observedExecutable actual==child
      if valid then writeIORef observed (Just actual) >> pure (Right ()) else pure (Left BadArguments)
     liveBody live = do
      actual <- observeLiveStartup live
      expected <- readIORef observed
      check "real live token names same verified child" ((Just <$> actual)==Right expected)
      putMVar liveReady ()
      readMVar liveRelease
     hook stage = do
      atomicModifyIORef' events (\xs -> (stage:xs,()))
      if stage=="qa-actual-wait-return-before-wrapper" && mode==LateReceipt
       then putMVar waitReturned () >> readMVar waitRelease else pure ()
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar start
   withPersistentOwnerHook owner (persistentFixture child [marker,"0"] input) 4096
    (startBudgetFromDeadline originalD) stopBudget verify liveBody hook
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  wait originalD "actual selected live child" liveReady
  actual <- readIORef observed >>= maybe (ioError (userError "verified child missing")) pure
  -- This removes only the real private QA marker, causing child natural exit.
  -- It is not a signal, exit receipt, or proof of process/provider cleanup.
  remainingMicros originalD >>= check "original D live before trigger" . (>0)
  removeFile marker
  awaitDead originalD actual
  putMVar liveRelease ()
  case mode of
   Timely -> pure ()
   LateReceipt -> do
    wait originalD "actual successful final wait returned" waitReturned
    implicit <- tryPersistentCleanupDeadline owner
    implicitD <- case implicit of
     CleanupDeadlineSelected d -> pure d
     _ -> ioError (userError "actual implicit cleanup D unavailable")
    beforeStop <- tryPersistentStopDeadline owner
    check "no explicit first stop before controlled overlap" (beforeStop==StopDeadlineNotLatched)
    implicitNs <- absolute implicitD
    stopStart <- newEmptyMVar
    stopTid <- forkIOWithUnmask $ \unmask -> do
     outcome <- try (unmask (readMVar stopStart >> requestSessionStop owner firstStopBudget))
     putMVar stopDone outcome
     case outcome of
      Left ex -> case fromException ex :: Maybe SomeAsyncException of
       Just _ -> throwIO ex
       Nothing -> pure ()
      Right _ -> pure ()
    writeIORef stopWorker (Just stopTid)
    putMVar stopStart ()
    firstD <- awaitFirst originalD implicitD owner
    writeIORef retainedFirst (Just firstD)
    firstNs <- absolute firstD
    check "actual first StopD strictly shortens implicit D" (firstNs<implicitNs)
    first <- waitBounds [originalD,implicitD,firstD] "real first stop receipt" stopDone >>= either throwIO pure
    check "real explicit stop during stopping" (first==StopNoLiveSession)
    awaitExpiry originalD firstD
    remainingMicros implicitD >>= check "implicit D still live when first StopD elapsed" . (>0)
    putMVar waitRelease ()
  result <- wait originalD "actual owner result" done >>= either throwIO pure
  phase <- observeReadOnly originalD "owner status observation" (persistentStatus owner)
  pidfd <- persistentPidfdCustody owner
  trace <- reverse <$> readIORef events
  firstAfter <- tryPersistentStopDeadline owner
  firstSaved <- readIORef retainedFirst
  let occurrences tag = length (filter (==tag) trace)
  check "one real final wait; no signal on naturally exited child" $
   occurrences "persistent-before-owned-leader-wait"==1 &&
   occurrences "qa-actual-wait-return-before-wrapper"==1 &&
   occurrences "persistent-before-leader-kill"==0
  case mode of
   Timely -> check "actual timely owned child reap and current retirement" $
    (case result of Right ((),LeaderReaped _) -> True; _ -> False) &&
    phase==PersistentRetired && pidfd==PidfdClosed
   LateReceipt -> check "late physical reap stays Unknown and pidfd is retained" $
    (case result of Left (ExitUncertain CleanupUncertain _) -> True; _ -> False) &&
    (case phase of PersistentQuarantined _ -> True; _ -> False) &&
    (case pidfd of PidfdKnownOpen _ _ -> True; _ -> False) &&
    (case firstSaved of Just first -> firstAfter==StopDeadlineLatched first; Nothing -> False)
-- The OS wait completed before the tighter firstStop, but the real surrounding
-- bounded-wait action returned after it. Its late receipt is not confirmation. No test repeats the actual wait or proves
-- namespace/provider/native/whole cleanup.
