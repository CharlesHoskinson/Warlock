port module EngineMvpJourney exposing
    ( AcceptanceLimits
    , CheckRow
    , CoupledState
    , Msg(..)
    , StepOutcome
    , acceptanceLimits
    , allChecks
    , initial
    , main
    , stepBarAction
    , stepBarRawAction
    , stepDismiss
    , stepEscape
    , stepNative
    , stepPopupAction
    , stepPopupLocalEdit
    , stepPopupRawAction
    , stepReflow
    , stepTopology
    , stepTransportLost
    , suiteReport
    , viewBar
    , viewPopup
    )

{-| Source-route three-role Elm QA driver for the standalone app-only UI engine
journey (`Controller`/`DesktopPolicy` + `Bar` + `Popup` + `StatusScroll` +
`UiHttp` gateway framing).

Honesty & acceptance limits:
- Drives actual owning Elm model/update/view exports only (`DesktopPolicy`,
  `OutputController`, `SurfaceController`, `Desktop`, `Shell`, `Pins`, `Catalog`,
  `Bar`, `Popup`, `Presentation`, `Announcement`, `SurfaceRenderer`,
  `SurfaceSnapshot`, `StatusScroll`, `UiHttp`); zero invented APIs and zero
  duplicate policy state machines.
- Preparation QA module only: `nativeAcceptance = False`, `guiAcceptance = False`,
  `releaseAccepted = False`, `protectedQaAccepted = False`.
- Cannot establish child PID-1 `exec`, `SCM_CREDENTIALS` per-fragment auth,
  GTK4/WebKit6 realization, `GtkOverlay` `1x1` `cView` untargetability, Wayland
  surface mapping on `Virtual-1`, `Foot` non-interference, physical `Escape`
  `GTK_PHASE_CAPTURE`, `200%` rendered font geometry, or `EngineResult False False`
  (`CallbackPending`, `ProviderUnqualified`) cleanup.
-}

import Announcement
import Bar
import Binding
import Catalog
import Desktop
import DesktopPolicy as Policy
import Html
import Json.Decode as D
import Json.Encode as E
import OutputController as Outputs
import Pins
import Platform
import Popup
import Presentation
import Set
import Shell
import StatusScroll as Scroll
import SurfaceController as Controller
import SurfaceRenderer as Renderer
import SurfaceSnapshot as Snapshot
import UInt64
import UiHttp


port incoming : (D.Value -> msg) -> Sub msg


port outgoing : E.Value -> Cmd msg


type alias AcceptanceLimits =
    { nativeAcceptance : Bool
    , guiAcceptance : Bool
    , releaseAccepted : Bool
    , protectedQaAccepted : Bool
    , nativeOperations : List String
    , maxMonotonicDurationMs : Int
    , minQmpStopMarginMs : Int
    , barHeightRequestPx : Int
    , popupMinWidthPx : Int
    , popupMinHeightPx : Int
    , defaultWindowWidthPx : Int
    , defaultWindowHeightPx : Int
    , liveTextScalePercent : Int
    , unprovenByElmDriver : List String
    }


acceptanceLimits : AcceptanceLimits
acceptanceLimits =
    { nativeAcceptance = False
    , guiAcceptance = False
    , releaseAccepted = False
    , protectedQaAccepted = False
    , nativeOperations = []
    , maxMonotonicDurationMs = 28000
    , minQmpStopMarginMs = 2000
    , barHeightRequestPx = 56
    , popupMinWidthPx = 480
    , popupMinHeightPx = 360
    , defaultWindowWidthPx = 980
    , defaultWindowHeightPx = 680
    , liveTextScalePercent = 100
    , unprovenByElmDriver =
        [ "exec-pid1-thread-namespace-qualification"
        , "per-fragment-scm-credentials-authentication"
        , "gtk4-webkit6-three-view-realization-and-gtkoverlay-cview"
        , "wayland-surface-mapping-and-hyprland-dwindle-allocation"
        , "pre-existing-foot-pid-starttime-non-interference"
        , "physical-qmp-escape-gtk-phase-capture"
        , "browser-200pct-computed-font-and-cumulative-linebox-scroll"
        , "engine-result-callback-pending-provider-unqualified-cleanup"
        ]
    }


encodeAcceptanceLimits : AcceptanceLimits -> E.Value
encodeAcceptanceLimits limits =
    E.object
        [ ( "nativeAcceptance", E.bool limits.nativeAcceptance )
        , ( "guiAcceptance", E.bool limits.guiAcceptance )
        , ( "releaseAccepted", E.bool limits.releaseAccepted )
        , ( "protectedQaAccepted", E.bool limits.protectedQaAccepted )
        , ( "nativeOperations", E.list E.string limits.nativeOperations )
        , ( "maxMonotonicDurationMs", E.int limits.maxMonotonicDurationMs )
        , ( "minQmpStopMarginMs", E.int limits.minQmpStopMarginMs )
        , ( "barHeightRequestPx", E.int limits.barHeightRequestPx )
        , ( "popupMinWidthPx", E.int limits.popupMinWidthPx )
        , ( "popupMinHeightPx", E.int limits.popupMinHeightPx )
        , ( "defaultWindowWidthPx", E.int limits.defaultWindowWidthPx )
        , ( "defaultWindowHeightPx", E.int limits.defaultWindowHeightPx )
        , ( "liveTextScalePercent", E.int limits.liveTextScalePercent )
        , ( "unprovenByElmDriver", E.list E.string limits.unprovenByElmDriver )
        ]


type alias CoupledState =
    { policy : Policy.Model
    , bar : Bar.Model
    , popup : Popup.Model
    , controllerHttp : UiHttp.Model
    , barHttp : UiHttp.Model
    , popupHttp : UiHttp.Model
    , selectedScope : Maybe E.Value
    , lastBarFocusDomId : Maybe String
    , lastPopupFocusDomId : Maybe String
    , barResetTargets : List ( String, String )
    , popupPreviewSafe : Bool
    }


type alias StepOutcome =
    { state : CoupledState
    , commits : List E.Value
    , domainRequests : List E.Value
    , barFocusDomId : Maybe String
    , popupFocusDomId : Maybe String
    , barResetTargets : List ( String, String )
    , barDispatched : List E.Value
    , popupDispatched : List E.Value
    , popupPreviewSafe : Bool
    }


type alias CheckRow =
    { name : String
    , category : String
    , passed : Bool
    }


type Msg
    = Input D.Value


initial : CoupledState
initial =
    let
        ( cHttp, _ ) =
            UiHttp.controller

        ( bHttp, _ ) =
            UiHttp.renderer

        ( pHttp, _ ) =
            UiHttp.renderer
    in
    { policy = Policy.initial
    , bar = Bar.initial
    , popup = Popup.initial
    , controllerHttp = cHttp
    , barHttp = bHttp
    , popupHttp = pHttp
    , selectedScope = Nothing
    , lastBarFocusDomId = Nothing
    , lastPopupFocusDomId = Nothing
    , barResetTargets = []
    , popupPreviewSafe = True
    }


viewBar : CoupledState -> Html.Html Bar.Msg
viewBar currentState =
    Bar.view currentState.bar


viewPopup : CoupledState -> Html.Html Popup.Msg
viewPopup currentState =
    Popup.view currentState.popup


gatewayEnvelope : String -> E.Value -> E.Value
gatewayEnvelope tag payload =
    E.object
        [ ( "bridgeProtocol", E.int 1 )
        , ( "kind", E.string tag )
        , ( "payload", payload )
        ]


popupEffectSupportedInHttpProfile : Popup.Effect -> Bool
popupEffectSupportedInHttpProfile eff =
    case eff of
        Popup.Dispatch _ ->
            True

        Popup.PreviewCommand raw ->
            D.decodeValue (D.list D.value) raw
                |> Result.map List.isEmpty
                |> Result.withDefault False

        Popup.PaintRequest raw ->
            D.decodeValue (D.list D.value) raw
                |> Result.map List.isEmpty
                |> Result.withDefault False


extractBarResets : List Bar.Effect -> List ( String, String )
extractBarResets effects =
    List.filterMap
        (\eff ->
            case eff of
                Bar.Dispatch _ ->
                    Nothing

                Bar.ResetStatusViewport ep targetDom ->
                    Just ( Scroll.epochString ep, targetDom )
        )
        effects


extractPopupDispatches : List Popup.Effect -> List E.Value
extractPopupDispatches effects =
    List.filterMap
        (\eff ->
            case eff of
                Popup.Dispatch wire ->
                    Just wire

                _ ->
                    Nothing
        )
        effects


resolveFocusPacket : Bool -> E.Value -> CoupledState -> Maybe String
resolveFocusPacket isPopup focusGateway currentState =
    case UiHttp.gateway focusGateway of
        Just ( "focus", focusPayload ) ->
            if isPopup then
                let
                    maybeRawTarget =
                        if currentState.popup.composition == Popup.Idle then
                            Presentation.focusTarget True focusPayload currentState.popup.presentation

                        else
                            Nothing
                in
                case ( Presentation.current currentState.popup.presentation, maybeRawTarget ) of
                    ( Just snap, Just rawDomId ) ->
                        Just (Renderer.controlDomId snap rawDomId)

                    _ ->
                        Nothing

            else
                let
                    maybeRawTarget =
                        Presentation.focusTarget False focusPayload currentState.bar.presentation
                in
                case ( Presentation.current currentState.bar.presentation, maybeRawTarget ) of
                    ( Just snap, Just rawDomId ) ->
                        Just (Renderer.controlDomId snap rawDomId)

                    _ ->
                        Nothing

        _ ->
            Nothing


routeFocusTarget : E.Value -> E.Value -> E.Value -> String -> CoupledState -> ( Maybe String, Maybe String )
routeFocusTarget frameVal pubVal leaseVal targetDom currentState =
    let
        matchesIn fieldName =
            D.decodeValue (D.field fieldName (D.list D.value)) frameVal
                |> Result.withDefault []
                |> List.any
                    (\row ->
                        let
                            sameDom =
                                D.decodeValue (D.field "domId" D.string) row == Ok targetDom

                            rowEnabled =
                                D.decodeValue (D.field "enabled" D.bool) row == Ok True

                            rowFocusOnly =
                                D.decodeValue (D.field "focusOnly" D.bool) row == Ok True
                        in
                        sameDom && (rowEnabled || rowFocusOnly)
                    )

        inBar =
            matchesIn "bar"

        inPopup =
            matchesIn "popup"

        packetFor surfaceName =
            gatewayEnvelope "focus"
                (E.object
                    [ ( "focusProtocol", E.int 1 )
                    , ( "kind", E.string "focus" )
                    , ( "surface", E.string surfaceName )
                    , ( "publication", pubVal )
                    , ( "lease", leaseVal )
                    , ( "domId", E.string targetDom )
                    ]
                )
    in
    if inBar && not inPopup then
        ( resolveFocusPacket False (packetFor "bar") currentState, Nothing )

    else if inPopup && not inBar then
        ( Nothing, resolveFocusPacket True (packetFor "popup") currentState )

    else
        ( Nothing, Nothing )


fanOutCommit : E.Value -> ( CoupledState, List E.Value, List ( String, String ) ) -> ( CoupledState, List E.Value, List ( String, String ) )
fanOutCommit commitWire ( prevState, accRequests, accResets ) =
    let
        ( nextControllerHttp, _, _ ) =
            UiHttp.enqueue commitWire prevState.controllerHttp

        reqs =
            D.decodeValue (D.field "requests" (D.list D.value)) commitWire
                |> Result.withDefault []

        focusTargets =
            D.decodeValue (D.field "focus" (D.list D.string)) commitWire
                |> Result.withDefault []

        projection =
            D.decodeValue (D.field "projection" D.value) commitWire
                |> Result.withDefault E.null

        frameVal =
            D.decodeValue (D.field "frame" D.value) projection
                |> Result.withDefault E.null

        pubVal =
            D.decodeValue (D.field "publication" D.value) frameVal
                |> Result.withDefault E.null

        leaseVal =
            D.decodeValue (D.field "lease" D.value) frameVal
                |> Result.withDefault E.null

        announcerVal =
            D.decodeValue (D.field "announcer" D.value) projection
                |> Result.withDefault E.null

        messageVal =
            D.decodeValue (D.field "announcement" D.value) projection
                |> Result.withDefault E.null

        scopeVal =
            prevState.selectedScope |> Maybe.withDefault E.null

        announcementFor surfaceName =
            let
                recipientVal =
                    E.object
                        [ ( "scope", scopeVal )
                        , ( "surface", E.string surfaceName )
                        ]

                shouldDeliver =
                    E.encode 0 announcerVal == E.encode 0 recipientVal
            in
            gatewayEnvelope "announcements"
                (E.object
                    [ ( "announcementProtocol", E.int 1 )
                    , ( "kind", E.string "announcement-projection" )
                    , ( "recipient", recipientVal )
                    , ( "announcer", announcerVal )
                    , ( "publication", pubVal )
                    , ( "lease", leaseVal )
                    , ( "message", messageVal )
                    , ( "deliver", E.bool shouldDeliver )
                    ]
                )

        presGateway =
            gatewayEnvelope "presentation" frameVal

        ( barAfterPres, barResets ) =
            case UiHttp.gateway presGateway of
                Just ( "presentation", payload ) ->
                    let
                        ( bNext, bEffs ) =
                            Bar.step (Bar.Present payload) prevState.bar
                    in
                    ( bNext, extractBarResets bEffs )

                _ ->
                    ( prevState.bar, [] )

        barAfterAnn =
            case UiHttp.gateway (announcementFor "bar") of
                Just ( "announcements", payload ) ->
                    Bar.step (Bar.Announce payload) barAfterPres |> Tuple.first

                _ ->
                    barAfterPres

        ( popupAfterPres, presPopupEffs ) =
            case UiHttp.gateway presGateway of
                Just ( "presentation", payload ) ->
                    Popup.transition (Popup.Present payload) prevState.popup

                _ ->
                    ( prevState.popup, [] )

        ( popupAfterAnn, annPopupEffs ) =
            case UiHttp.gateway (announcementFor "popup") of
                Just ( "announcements", payload ) ->
                    Popup.transition (Popup.Announce payload) popupAfterPres

                _ ->
                    ( popupAfterPres, [] )

        allPopupEffs =
            presPopupEffs ++ annPopupEffs

        previewOk =
            prevState.popupPreviewSafe && List.all popupEffectSupportedInHttpProfile allPopupEffs

        nextPopupHttp =
            if previewOk then
                prevState.popupHttp

            else
                UiHttp.stop "Native previews are unavailable in this HTTP profile. No preview command was sent." prevState.popupHttp
                    |> (\( stoppedModel, _, _ ) -> stoppedModel)

        intermediateState =
            { prevState
                | controllerHttp = nextControllerHttp
                , bar = barAfterAnn
                , popup = popupAfterAnn
                , popupHttp = nextPopupHttp
                , popupPreviewSafe = previewOk
            }

        ( resolvedBarFocus, resolvedPopupFocus ) =
            List.foldl
                (\targetDom ( bFound, pFound ) ->
                    let
                        ( bCandidate, pCandidate ) =
                            routeFocusTarget frameVal pubVal leaseVal targetDom intermediateState
                    in
                    ( case bCandidate of
                        Just _ ->
                            bCandidate

                        Nothing ->
                            bFound
                    , case pCandidate of
                        Just _ ->
                            pCandidate

                        Nothing ->
                            pFound
                    )
                )
                ( Nothing, Nothing )
                focusTargets

        rebasedPopupQueries =
            if previewOk then
                extractPopupDispatches allPopupEffs

            else
                []

        settledState =
            { intermediateState
                | lastBarFocusDomId = resolvedBarFocus
                , lastPopupFocusDomId = resolvedPopupFocus
                , barResetTargets = barResets
            }

        -- Typecheck & evaluate actual Bar.view and Popup.view trees on every commit
        _ =
            ( Bar.view settledState.bar, Popup.view settledState.popup )
    in
    case rebasedPopupQueries of
        [] ->
            ( settledState, accRequests ++ reqs, accResets ++ barResets )

        firstQuery :: _ ->
            case settledState.selectedScope of
                Nothing ->
                    ( settledState, accRequests ++ reqs, accResets ++ barResets )

                Just activeScope ->
                    let
                        rebasedActionPacket =
                            gatewayEnvelope "view-action"
                                (E.object
                                    [ ( "viewProtocol", E.int 1 )
                                    , ( "kind", E.string "view-action" )
                                    , ( "scope", activeScope )
                                    , ( "action", firstQuery )
                                    ]
                                )

                        ( nextPolicy, followEffects ) =
                            Policy.update (Policy.Incoming rebasedActionPacket) settledState.policy

                        followCommits =
                            List.filterMap
                                (\pe ->
                                    case pe of
                                        Policy.Publish raw ->
                                            Just raw

                                        Policy.Delay _ _ ->
                                            Nothing
                                )
                                followEffects
                    in
                    List.foldl fanOutCommit
                        ( { settledState | policy = nextPolicy }, accRequests ++ reqs, accResets ++ barResets )
                        followCommits


runPolicyMessage : Policy.Msg -> CoupledState -> StepOutcome
runPolicyMessage policyMsg startState =
    let
        ( updatedPolicy, policyEffects ) =
            Policy.update policyMsg startState.policy

        publishedCommits =
            List.filterMap
                (\eff ->
                    case eff of
                        Policy.Publish wire ->
                            Just wire

                        Policy.Delay _ _ ->
                            Nothing
                )
                policyEffects

        syncedScope =
            Outputs.views updatedPolicy.controller
                |> List.head
                |> Maybe.map Outputs.encodeScope

        seededState =
            { startState
                | policy = updatedPolicy
                , selectedScope = syncedScope
                , lastBarFocusDomId = Nothing
                , lastPopupFocusDomId = Nothing
                , barResetTargets = []
            }

        ( finalState, collectedRequests, collectedResets ) =
            List.foldl fanOutCommit ( seededState, [], [] ) publishedCommits
    in
    { state = finalState
    , commits = publishedCommits
    , domainRequests = collectedRequests
    , barFocusDomId = finalState.lastBarFocusDomId
    , popupFocusDomId = finalState.lastPopupFocusDomId
    , barResetTargets = collectedResets
    , barDispatched = []
    , popupDispatched = []
    , popupPreviewSafe = finalState.popupPreviewSafe
    }


emptyOutcome : CoupledState -> StepOutcome
emptyOutcome unchanged =
    { state = unchanged
    , commits = []
    , domainRequests = []
    , barFocusDomId = Nothing
    , popupFocusDomId = Nothing
    , barResetTargets = []
    , barDispatched = []
    , popupDispatched = []
    , popupPreviewSafe = unchanged.popupPreviewSafe
    }


stepTopology : String -> Maybe ( E.Value, List Int ) -> CoupledState -> StepOutcome
stepTopology revText maybeScopeAndBox currentState =
    let
        ( viewsList, locationsList ) =
            case maybeScopeAndBox of
                Nothing ->
                    ( [], [] )

                Just ( scopeObj, boxCoords ) ->
                    ( [ scopeObj ]
                    , [ E.object
                            [ ( "scope", scopeObj )
                            , ( "box", E.list E.int boxCoords )
                            ]
                      ]
                    )

        topoPayload =
            E.object
                [ ( "viewProtocol", E.int 2 )
                , ( "kind", E.string "view-topology" )
                , ( "revision", E.string revText )
                , ( "views", E.list identity viewsList )
                , ( "locations", E.list identity locationsList )
                ]
    in
    runPolicyMessage (Policy.Incoming (gatewayEnvelope "view-topology" topoPayload)) currentState


stepNative : E.Value -> CoupledState -> StepOutcome
stepNative nativePayload currentState =
    runPolicyMessage (Policy.Incoming (gatewayEnvelope "native-event" nativePayload)) currentState


stepTransportLost : CoupledState -> StepOutcome
stepTransportLost currentState =
    runPolicyMessage Policy.TransportLost currentState


stepBarRawAction : E.Value -> CoupledState -> StepOutcome
stepBarRawAction rawAction currentState =
    let
        ( nextBar, maybeWire ) =
            Bar.transition (Bar.Action rawAction) currentState.bar

        withBar =
            { currentState | bar = nextBar }
    in
    case ( maybeWire, withBar.selectedScope ) of
        ( Just wire, Just scopeObj ) ->
            let
                ( nextBarHttp, _, _ ) =
                    UiHttp.enqueue wire withBar.barHttp

                routed =
                    runPolicyMessage
                        (Policy.Incoming
                            (gatewayEnvelope "view-action"
                                (E.object
                                    [ ( "viewProtocol", E.int 1 )
                                    , ( "kind", E.string "view-action" )
                                    , ( "scope", scopeObj )
                                    , ( "action", wire )
                                    ]
                                )
                            )
                        )
                        { withBar | barHttp = nextBarHttp }
            in
            { routed | barDispatched = [ wire ] }

        _ ->
            emptyOutcome withBar


stepBarAction : String -> CoupledState -> StepOutcome
stepBarAction controlId currentState =
    case Presentation.current currentState.bar.presentation |> Maybe.andThen (Renderer.action False controlId) of
        Just actionWire ->
            stepBarRawAction actionWire currentState

        Nothing ->
            emptyOutcome currentState


applyPopupMessage : Popup.Msg -> CoupledState -> StepOutcome
applyPopupMessage popupMsg currentState =
    let
        ( nextPopup, popupEffs ) =
            Popup.transition popupMsg currentState.popup

        previewOk =
            currentState.popupPreviewSafe && List.all popupEffectSupportedInHttpProfile popupEffs

        dispatchedWires =
            if previewOk then
                extractPopupDispatches popupEffs

            else
                []

        nextPopupHttp =
            if previewOk then
                List.foldl
                    (\wire httpAcc ->
                        UiHttp.enqueue wire httpAcc |> (\( updatedHttp, _, _ ) -> updatedHttp)
                    )
                    currentState.popupHttp
                    dispatchedWires

            else
                UiHttp.stop "Native previews are unavailable in this HTTP profile. No preview command was sent." currentState.popupHttp
                    |> (\( stoppedHttp, _, _ ) -> stoppedHttp)

        withPopup =
            { currentState
                | popup = nextPopup
                , popupHttp = nextPopupHttp
                , popupPreviewSafe = previewOk
            }

        _ =
            Popup.view withPopup.popup
    in
    case ( dispatchedWires, withPopup.selectedScope ) of
        ( firstWire :: _, Just scopeObj ) ->
            let
                routed =
                    runPolicyMessage
                        (Policy.Incoming
                            (gatewayEnvelope "view-action"
                                (E.object
                                    [ ( "viewProtocol", E.int 1 )
                                    , ( "kind", E.string "view-action" )
                                    , ( "scope", scopeObj )
                                    , ( "action", firstWire )
                                    ]
                                )
                            )
                        )
                        withPopup
            in
            { routed | popupDispatched = dispatchedWires }

        _ ->
            let
                baseOut =
                    emptyOutcome withPopup
            in
            { baseOut | popupDispatched = dispatchedWires }


stepPopupRawAction : E.Value -> CoupledState -> StepOutcome
stepPopupRawAction rawAction currentState =
    applyPopupMessage (Popup.Action rawAction) currentState


stepPopupLocalEdit : E.Value -> CoupledState -> StepOutcome
stepPopupLocalEdit rawEdit currentState =
    applyPopupMessage (Popup.LocalAction rawEdit) currentState


stepPopupAction : String -> CoupledState -> StepOutcome
stepPopupAction controlId currentState =
    case Presentation.current currentState.popup.presentation |> Maybe.andThen (Renderer.action True controlId) of
        Just actionWire ->
            stepPopupRawAction actionWire currentState

        Nothing ->
            emptyOutcome currentState


stepEscape : Maybe String -> CoupledState -> StepOutcome
stepEscape maybeOverridePub currentState =
    case ( currentState.selectedScope, Presentation.current currentState.popup.presentation ) of
        ( Just scopeObj, Just snap ) ->
            let
                pubString =
                    maybeOverridePub |> Maybe.withDefault (UInt64.string (Renderer.publication snap))

                leaseString =
                    UInt64.string (Renderer.lease snap)

                escPayload =
                    E.object
                        [ ( "scope", scopeObj )
                        , ( "publication", E.string pubString )
                        , ( "lease", E.string leaseString )
                        ]
            in
            runPolicyMessage (Policy.Incoming (gatewayEnvelope "view-escape" escPayload)) currentState

        _ ->
            emptyOutcome currentState


stepReflow : CoupledState -> StepOutcome
stepReflow currentState =
    case ( currentState.selectedScope, Presentation.current currentState.popup.presentation ) of
        ( Just scopeObj, Just snap ) ->
            let
                reflowPayload =
                    E.object
                        [ ( "scope", scopeObj )
                        , ( "lease", E.string (UInt64.string (Renderer.lease snap)) )
                        ]
            in
            runPolicyMessage (Policy.Incoming (gatewayEnvelope "view-reflow" reflowPayload)) currentState

        _ ->
            emptyOutcome currentState


stepDismiss : CoupledState -> StepOutcome
stepDismiss currentState =
    case ( currentState.selectedScope, Presentation.current currentState.popup.presentation ) of
        ( Just scopeObj, Just snap ) ->
            let
                dismissPayload =
                    E.object
                        [ ( "scope", scopeObj )
                        , ( "lease", E.string (UInt64.string (Renderer.lease snap)) )
                        ]
            in
            runPolicyMessage (Policy.Incoming (gatewayEnvelope "view-dismiss" dismissPayload)) currentState

        _ ->
            emptyOutcome currentState



-- FIXTURE BUILDERS & INVARIANT HELPERS


scopeValue : String -> String -> E.Value
scopeValue viewId genId =
    E.object
        [ ( "id", E.string viewId )
        , ( "generation", E.string genId )
        ]


bindingJson : String -> String -> String -> E.Value
bindingJson lifeText sessText frontText =
    E.object
        [ ( "lifetime", E.string lifeText )
        , ( "session", E.string sessText )
        , ( "frontend", E.string frontText )
        ]


appAttachedJson : E.Value -> List String -> E.Value
appAttachedJson bindVal ops =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "application-attached" )
        , ( "binding", bindVal )
        , ( "nativeOperations", E.list E.string ops )
        ]


catalogEntryJson : String -> String -> String -> List String -> E.Value
catalogEntryJson entryId displayName genericText kws =
    E.object
        [ ( "id", E.string entryId )
        , ( "name", E.string displayName )
        , ( "iconHint", E.string "" )
        , ( "wmclass", E.string "" )
        , ( "genericName", E.string genericText )
        , ( "keywords", E.list E.string kws )
        ]


sampleCatalogSnapshot : String -> String -> E.Value
sampleCatalogSnapshot lifeText genText =
    E.object
        [ ( "catalogProtocol", E.int 2 )
        , ( "lifetime", E.string lifeText )
        , ( "generation", E.string genText )
        , ( "entries"
          , E.list identity
                [ catalogEntryJson "foot.desktop" "Foot" "Wayland terminal" [ "terminal", "shell" ]
                , catalogEntryJson "org.gnome.Nautilus.desktop" "Files" "File manager" [ "folder", "browse" ]
                , catalogEntryJson "warlock-bar-status-scroll-1" "Scroll Collision Probe" "Adversarial ID" [ "probe" ]
                ]
          )
        ]


catalogReceiptJson : E.Value -> String -> E.Value -> Maybe ( String, List String ) -> E.Value
catalogReceiptJson bindVal reqId snapJson maybePrefs =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "application-catalog" )
        , ( "binding", bindVal )
        , ( "requestId", E.string reqId )
        , ( "snapshot", snapJson )
        , ( "preferences"
          , case maybePrefs of
                Nothing ->
                    E.null

                Just ( revText, pinIds ) ->
                    E.object
                        [ ( "revision", E.string revText )
                        , ( "identities", E.list E.string pinIds )
                        ]
          )
        ]


pinsOutcomeJson : E.Value -> String -> String -> Maybe ( String, List String ) -> E.Value
pinsOutcomeJson bindVal reqId outcomeStatus maybePrefs =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "taskbar-pins-outcome" )
        , ( "binding", bindVal )
        , ( "requestId", E.string reqId )
        , ( "status", E.string outcomeStatus )
        , ( "preferences"
          , case maybePrefs of
                Nothing ->
                    E.null

                Just ( revText, pinIds ) ->
                    E.object
                        [ ( "revision", E.string revText )
                        , ( "identities", E.list E.string pinIds )
                        ]
          )
        ]


localQueryPacket : String -> String -> String -> String -> E.Value
localQueryPacket eventKind pubText leaseText queryText =
    E.object
        [ ( "surfaceProtocol", E.int 2 )
        , ( "surface", E.string "popup" )
        , ( "publication", E.string pubText )
        , ( "lease", E.string leaseText )
        , ( "id", E.string "control:search" )
        , ( "kind", E.string eventKind )
        , ( "query", E.string queryText )
        ]


forgedSurfaceAction : String -> String -> String -> String -> E.Value
forgedSurfaceAction surfaceName pubText leaseText controlId =
    E.object
        [ ( "surfaceProtocol", E.int 2 )
        , ( "kind", E.string "surface-action" )
        , ( "surface", E.string surfaceName )
        , ( "publication", E.string pubText )
        , ( "lease", E.string leaseText )
        , ( "id", E.string controlId )
        ]


policyDesktop : CoupledState -> Desktop.Model
policyDesktop currentState =
    Controller.desktop (Outputs.controller currentState.policy.controller)


requestKind : E.Value -> String
requestKind reqVal =
    D.decodeValue (D.field "kind" D.string) reqVal |> Result.withDefault ""


requestIdOf : E.Value -> String
requestIdOf reqVal =
    D.decodeValue (D.field "requestId" D.string) reqVal |> Result.withDefault "0"


hasForbiddenNativeRequest : List E.Value -> Bool
hasForbiddenNativeRequest reqs =
    List.any
        (\reqVal ->
            not (List.member (requestKind reqVal) [ "catalog-request", "taskbar-pins-write" ])
        )
        reqs


allControlDomIdsValid : Renderer.Snapshot -> Bool
allControlDomIdsValid snap =
    let
        det =
            Snapshot.details snap

        allControls =
            det.bar ++ det.popup

        renderedIds =
            List.map (\ctrl -> Renderer.controlDomId snap ctrl.domId) allControls

        allUnique =
            List.length renderedIds == Set.size (Set.fromList renderedIds)

        noneReserved =
            not (List.any Scroll.isReservedDomId renderedIds)

        searchUnescapedWhenPresent =
            allControls
                |> List.filter (\ctrl -> ctrl.identity == "control:search")
                |> List.all (\ctrl -> Renderer.controlDomId snap ctrl.domId == "launcher-search")
    in
    allUnique && noneReserved && searchUnescapedWhenPresent


currentPubAndLease : CoupledState -> ( String, String )
currentPubAndLease currentState =
    case Presentation.current currentState.popup.presentation of
        Just snap ->
            ( UInt64.string (Renderer.publication snap)
            , UInt64.string (Renderer.lease snap)
            )

        Nothing ->
            case Presentation.current currentState.bar.presentation of
                Just bSnap ->
                    ( UInt64.string (Renderer.publication bSnap)
                    , UInt64.string (Renderer.lease bSnap)
                    )

                Nothing ->
                    ( "0", "0" )


advanceCounterString : Int -> String -> String
advanceCounterString steps startText =
    let
        startCounter =
            D.decodeValue UInt64.decoder (E.string startText)
                |> Result.withDefault UInt64.zero

        stepOnce _ acc =
            UInt64.next acc |> Maybe.withDefault acc
    in
    List.foldl stepOnce startCounter (List.range 1 steps)
        |> UInt64.string



-- DETERMINISTIC POSITIVE, NEGATIVE & SEEDED JOURNEY CHECKS


journeyChecks : List CheckRow
journeyChecks =
    let
        scope1 =
            scopeValue "1" "1"

        bind1 =
            bindingJson "9007199254741001" "9007199254741103" "9007199254741207"

        bindForeign =
            bindingJson "9007199254741001" "9007199254741103" "9007199254741208"

        -- Step 1: Initial topology [0, 0, 980, 680]
        topoStep =
            stepTopology "1" (Just ( scope1, [ 0, 0, 980, 680 ] )) initial

        barSnapAfterTopo =
            Presentation.current topoStep.state.bar.presentation

        -- Step 2: Scoped application-attached (nativeOperations: [])
        attachStep =
            stepNative (appAttachedJson bind1 []) topoStep.state

        deskAfterAttach =
            policyDesktop attachStep.state

        barSnapAfterAttach =
            Presentation.current attachStep.state.bar.presentation

        disabledBarIds =
            [ "bar:overview"
            , "bar:switcher"
            , "bar:notifications"
            , "bar:files"
            , "bar:system"
            , "bar:settings"
            ]

        -- Negative attachment checks
        badAttachOps =
            stepNative (appAttachedJson bind1 [ "focus" ]) topoStep.state

        badAttachVer =
            stepNative
                (E.object
                    [ ( "protocolVersion", E.int 2 )
                    , ( "kind", E.string "application-attached" )
                    , ( "binding", bind1 )
                    , ( "nativeOperations", E.list E.string [] )
                    ]
                )
                topoStep.state

        badAttachExtra =
            stepNative
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "application-attached" )
                    , ( "binding", bind1 )
                    , ( "nativeOperations", E.list E.string [] )
                    , ( "extra", E.bool True )
                    ]
                )
                topoStep.state

        badAttachZero =
            stepNative (appAttachedJson (bindingJson "9007199254741001" "9007199254741103" "0") []) topoStep.state

        badAttachRendererGateway =
            runPolicyMessage
                (Policy.Incoming (gatewayEnvelope "view-action" (appAttachedJson bind1 [])))
                topoStep.state

        -- Negative forged clicks on disabled Bar controls
        ( pubAttach, leaseAttach ) =
            currentPubAndLease attachStep.state

        barForgedBlocked =
            List.all
                (\disabledId ->
                    let
                        forgedWire =
                            forgedSurfaceAction "bar" pubAttach leaseAttach disabledId

                        viaBar =
                            stepBarRawAction forgedWire attachStep.state

                        viaPolicy =
                            runPolicyMessage
                                (Policy.Incoming
                                    (gatewayEnvelope "view-action"
                                        (E.object
                                            [ ( "viewProtocol", E.int 1 )
                                            , ( "kind", E.string "view-action" )
                                            , ( "scope", scope1 )
                                            , ( "action", forgedWire )
                                            ]
                                        )
                                    )
                                )
                                attachStep.state
                    in
                    List.isEmpty viaBar.barDispatched
                        && List.isEmpty viaBar.domainRequests
                        && List.isEmpty viaPolicy.commits
                        && List.isEmpty viaPolicy.domainRequests
                )
                disabledBarIds

        -- Step 3: Open Applications via published bar:applications
        openStep =
            stepBarAction "bar:applications" attachStep.state

        catalogReq1 =
            List.head openStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        catSnapJson =
            sampleCatalogSnapshot "9007199254741001" "1"

        -- Negative foreign & wrong-requestId catalog receipts
        foreignCatStep =
            stepNative (catalogReceiptJson bindForeign catalogReq1 catSnapJson (Just ( "1", [] ))) openStep.state

        wrongReqCatStep =
            stepNative (catalogReceiptJson bind1 "999999" catSnapJson (Just ( "1", [] ))) openStep.state

        -- Step 4: Valid application-catalog receipt (with empty initial pins & adversarial ID entry)
        catStep =
            stepNative (catalogReceiptJson bind1 catalogReq1 catSnapJson (Just ( "1", [] ))) openStep.state

        popupSnapAfterCat =
            Presentation.current catStep.state.popup.presentation

        ( pubCat, leaseCat ) =
            currentPubAndLease catStep.state

        -- Negative forged launch & jump-list actions on Popup
        popupForgedLaunchBlocked =
            List.all
                (\forgedId ->
                    let
                        forgedWire =
                            forgedSurfaceAction "popup" pubCat leaseCat forgedId

                        viaPopup =
                            stepPopupRawAction forgedWire catStep.state

                        viaPolicy =
                            runPolicyMessage
                                (Policy.Incoming
                                    (gatewayEnvelope "view-action"
                                        (E.object
                                            [ ( "viewProtocol", E.int 1 )
                                            , ( "kind", E.string "view-action" )
                                            , ( "scope", scope1 )
                                            , ( "action", forgedWire )
                                            ]
                                        )
                                    )
                                )
                                catStep.state
                    in
                    List.isEmpty viaPopup.popupDispatched
                        && List.isEmpty viaPopup.domainRequests
                        && List.isEmpty viaPolicy.commits
                        && List.isEmpty viaPolicy.domainRequests
                )
                [ "entry:foot.desktop", "jump:open:foot.desktop", "entry:warlock-bar-status-scroll-1" ]

        -- Step 5: IME composition start + preedit + in-flight same-lease catalog refresh + composition end
        imeRefreshInit =
            stepPopupAction "control:refresh" catStep.state

        imeRefreshReq =
            List.head imeRefreshInit.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        ( pubRefreshInit, leaseRefreshInit ) =
            currentPubAndLease imeRefreshInit.state

        imeStartStep =
            stepPopupLocalEdit (localQueryPacket "surface-composition-start" pubRefreshInit leaseRefreshInit "") imeRefreshInit.state

        imePreeditStep =
            stepPopupLocalEdit (localQueryPacket "surface-preedit" pubRefreshInit leaseRefreshInit "fo") imeStartStep.state

        -- While IME composing, attempting to click an enabled Popup button (`control:close`) is blocked locally
        imeBlockedButtonStep =
            stepPopupAction "control:close" imePreeditStep.state

        -- In-flight catalog receipt arrives on the SAME lease while IME composing -> preserves preedit!
        imeSameLeaseRefreshStep =
            stepNative (catalogReceiptJson bind1 imeRefreshReq catSnapJson (Just ( "1", [] ))) imePreeditStep.state

        ( pubAfterSameLeaseRefresh, leaseAfterSameLeaseRefresh ) =
            currentPubAndLease imeSameLeaseRefreshStep.state

        -- Even if a focus packet for "launcher-search" arrives during active IME composition, Popup suppresses focus target!
        syntheticFocusDuringIme =
            resolveFocusPacket True
                (gatewayEnvelope "focus"
                    (E.object
                        [ ( "focusProtocol", E.int 1 )
                        , ( "kind", E.string "focus" )
                        , ( "surface", E.string "popup" )
                        , ( "publication", E.string pubAfterSameLeaseRefresh )
                        , ( "lease", E.string leaseAfterSameLeaseRefresh )
                        , ( "domId", E.string "launcher-search" )
                        ]
                    )
                )
                imeSameLeaseRefreshStep.state

        -- Commit IME composition -> emits single surface-query "foot", acknowledged by DesktopPolicy!
        imeEndStep =
            stepPopupLocalEdit (localQueryPacket "surface-composition-end" pubAfterSameLeaseRefresh leaseAfterSameLeaseRefresh "foot") imeSameLeaseRefreshStep.state

        popupSnapAfterFootSearch =
            Presentation.current imeEndStep.state.popup.presentation

        -- Preceding-publication local edit rebase within same lease (`pubRefreshInit` < `pubAfterFootSearch`, same `lease`)
        rebasedNautStep =
            stepPopupLocalEdit (localQueryPacket "surface-query" pubRefreshInit leaseAfterSameLeaseRefresh "Files") imeEndStep.state

        -- Reset search back to "" so all entries are visible for multi-pin journey
        ( pubAfterNaut, leaseAfterNaut ) =
            currentPubAndLease rebasedNautStep.state

        clearSearchStep =
            stepPopupLocalEdit (localQueryPacket "surface-query" pubAfterNaut leaseAfterNaut "") rebasedNautStep.state

        -- Negative local edits: wrong lease and control character
        wrongLeaseQueryStep =
            stepPopupLocalEdit (localQueryPacket "surface-query" pubAfterNaut "999" "foot") clearSearchStep.state

        ctrlCharQueryStep =
            stepPopupLocalEdit (localQueryPacket "surface-query" pubAfterNaut leaseAfterNaut "bad\u{0007}char") clearSearchStep.state

        -- Unacknowledged non-IME draft across a concurrent same-lease catalog publication replays once cleanly
        pendingDraftState =
            let
                draftRefreshInit =
                    stepPopupAction "control:refresh" clearSearchStep.state

                draftRefreshReq =
                    List.head draftRefreshInit.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

                ( pubDraftInit, leaseDraftInit ) =
                    currentPubAndLease draftRefreshInit.state

                ( pPending, _ ) =
                    Popup.transition
                        (Popup.LocalAction (localQueryPacket "surface-query" pubDraftInit leaseDraftInit "Foot"))
                        draftRefreshInit.state.popup

                coupledWithPending =
                    { draftRefreshInit.state | popup = pPending }
            in
            stepNative (catalogReceiptJson bind1 draftRefreshReq catSnapJson (Just ( "1", [] ))) coupledWithPending

        -- Step 6: Pin toggle, save receipt, cross-role Bar chip sync, second pin & reorder, Unknown pin recovery
        pinFootStep =
            stepPopupAction "pin:foot.desktop" clearSearchStep.state

        pinReq1 =
            List.head pinFootStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        deskDuringPinSave =
            policyDesktop pinFootStep.state

        pinFootSavedStep =
            stepNative (pinsOutcomeJson bind1 pinReq1 "Saved" (Just ( "2", [ "foot.desktop" ] ))) pinFootStep.state

        barSnapAfterPin1 =
            Presentation.current pinFootSavedStep.state.bar.presentation

        popupSnapAfterPin1 =
            Presentation.current pinFootSavedStep.state.popup.presentation

        pinNautStep =
            stepPopupAction "pin:org.gnome.Nautilus.desktop" pinFootSavedStep.state

        pinReq2 =
            List.head pinNautStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        pinNautSavedStep =
            stepNative
                (pinsOutcomeJson bind1 pinReq2 "Saved" (Just ( "3", [ "foot.desktop", "org.gnome.Nautilus.desktop" ] )))
                pinNautStep.state

        moveLeftStep =
            stepPopupAction "pin-left:org.gnome.Nautilus.desktop" pinNautSavedStep.state

        pinReq3 =
            List.head moveLeftStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        moveLeftSavedStep =
            stepNative
                (pinsOutcomeJson bind1 pinReq3 "Saved" (Just ( "4", [ "org.gnome.Nautilus.desktop", "foot.desktop" ] )))
                moveLeftStep.state

        boundaryMoveLeftStep =
            stepPopupAction "pin-left:org.gnome.Nautilus.desktop" moveLeftSavedStep.state

        -- Unknown pin outcome branch: unpin foot -> receives Unknown -> zero auto-retry, writable=False -> Refresh -> recovers!
        unpinForUnknownStep =
            stepPopupAction "unpin:foot.desktop" moveLeftSavedStep.state

        unknownReqId =
            List.head unpinForUnknownStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        unknownOutcomeStep =
            stepNative (pinsOutcomeJson bind1 unknownReqId "Unknown" Nothing) unpinForUnknownStep.state

        refreshAfterUnknownStep =
            stepPopupAction "control:refresh" unknownOutcomeStep.state

        refreshReqId =
            List.head refreshAfterUnknownStep.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        recoveredAfterUnknownStep =
            stepNative
                (catalogReceiptJson bind1
                    refreshReqId
                    (sampleCatalogSnapshot "9007199254741001" "2")
                    (Just ( "4", [ "org.gnome.Nautilus.desktop", "foot.desktop" ] ))
                )
                refreshAfterUnknownStep.state

        -- Step 7: Narrow dwindle split (~620px & 600px) reflow, stale vs current physical Escape, stale lease action, reconnect
        narrowTopoStep =
            stepTopology "3" (Just ( scope1, [ 640, 0, 620, 760 ] )) recoveredAfterUnknownStep.state

        narrow600Step =
            stepTopology "4" (Just ( scope1, [ 0, 0, 600, 680 ] )) narrowTopoStep.state

        narrowReflowStep =
            stepReflow narrow600Step.state

        ( pubBeforeEsc, leaseBeforeEsc ) =
            currentPubAndLease narrowReflowStep.state

        capturedPopupActionOldLease =
            Presentation.current narrowReflowStep.state.popup.presentation
                |> Maybe.andThen (Renderer.action True "control:refresh")
                |> Maybe.withDefault E.null

        staleEscStep =
            stepEscape (Just "1") narrowReflowStep.state

        -- Start IME preedit right before Escape to prove closing Popup cleanly retires local IME composition
        imeBeforeEscStep =
            stepPopupLocalEdit (localQueryPacket "surface-composition-start" pubBeforeEsc leaseBeforeEsc "dr") narrowReflowStep.state

        validEscStep =
            stepEscape Nothing imeBeforeEscStep.state

        reopenStep =
            stepBarAction "bar:applications" validEscStep.state

        oldActionAfterReopen =
            stepPopupRawAction capturedPopupActionOldLease reopenStep.state

        oldActionViaPolicyAfterReopen =
            runPolicyMessage
                (Policy.Incoming
                    (gatewayEnvelope "view-action"
                        (E.object
                            [ ( "viewProtocol", E.int 1 )
                            , ( "kind", E.string "view-action" )
                            , ( "scope", scope1 )
                            , ( "action", capturedPopupActionOldLease )
                            ]
                        )
                    )
                )
                reopenStep.state

        lostStep =
            stepTransportLost reopenStep.state

        replayOldBindAfterLost =
            stepNative (appAttachedJson bind1 []) lostStep.state

        freshBindAfterLost =
            stepNative (appAttachedJson bindForeign []) lostStep.state

        -- StatusScroll exhaustion fail-closed check (`UInt64.max` floor withdraws DOM ID without reset task)
        maxCounter =
            D.decodeValue UInt64.decoder (E.string "18446744073709551615")
                |> Result.withDefault UInt64.zero

        exhaustedBarModel =
            case barSnapAfterAttach of
                Just snap ->
                    Bar.step (Bar.Present (Renderer.encode snap)) (Bar.initialWithScroll (Scroll.fromFloor maxCounter))
                        |> Tuple.first

                Nothing ->
                    Bar.initial
    in
    [ { name = "topologyInitialCommitsClosedFrameZeroRequests"
      , category = "topology-and-attach"
      , passed =
            List.length topoStep.commits == 1
                && List.isEmpty topoStep.domainRequests
                && (barSnapAfterTopo |> Maybe.map Renderer.mode) == Just "closed"
                && (Presentation.current topoStep.state.popup.presentation |> Maybe.map Renderer.mode) == Just "closed"
                && Bar.statusDomId topoStep.state.bar == Just "warlock-bar-status-scroll-1"
                && List.isEmpty topoStep.barResetTargets
                && topoStep.popupPreviewSafe
      }
    , { name = "attachAcceptsEmptyNativeOpsAndSetsAppOnly"
      , category = "topology-and-attach"
      , passed =
            deskAfterAttach.windows.shell.applicationOnly
                && not (Shell.available deskAfterAttach.windows.shell)
                && List.isEmpty attachStep.domainRequests
                && deskAfterAttach.windows.shell.notice == "Applications connected. Window controls unavailable."
                && Bar.statusDomId attachStep.state.bar == Just "warlock-bar-status-scroll-2"
                && attachStep.barResetTargets == [ ( "2", "warlock-bar-status-scroll-2" ) ]
      }
    , { name = "closedAppOnlyBarEnablesApplicationsOnly"
      , category = "topology-and-attach"
      , passed =
            case barSnapAfterAttach of
                Nothing ->
                    False

                Just bSnap ->
                    Renderer.enabled False "bar:applications" bSnap
                        && List.all (\cid -> List.member cid (Renderer.controlIdentities False bSnap) && not (Renderer.enabled False cid bSnap)) disabledBarIds
      }
    , { name = "negAttachRejectsNonEmptyNativeOperations"
      , category = "negative-attach"
      , passed =
            not (policyDesktop badAttachOps.state).windows.shell.applicationOnly
                && (policyDesktop badAttachOps.state).windows.shell.binding == Nothing
                && List.isEmpty badAttachOps.domainRequests
      }
    , { name = "negAttachRejectsWrongProtocolExtraFieldsAndZeroCounter"
      , category = "negative-attach"
      , passed =
            List.all
                (\badOut ->
                    let
                        d =
                            policyDesktop badOut.state
                    in
                    not d.windows.shell.applicationOnly && d.windows.shell.binding == Nothing && List.isEmpty badOut.domainRequests
                )
                [ badAttachVer, badAttachExtra, badAttachZero ]
      }
    , { name = "negRendererGatewayCannotClaimAttachment"
      , category = "negative-attach"
      , passed =
            not (policyDesktop badAttachRendererGateway.state).windows.shell.applicationOnly
                && List.isEmpty badAttachRendererGateway.commits
      }
    , { name = "negBarDisabledActionsDroppedByPresentationAndPolicy"
      , category = "negative-controls"
      , passed = barForgedBlocked
      }
    , { name = "openApplicationsDispatchesCatalogRequestOnlyAndAdvancesLoadingStatus"
      , category = "launcher-and-catalog"
      , passed =
            (policyDesktop openStep.state).open
                && List.map requestKind openStep.domainRequests == [ "catalog-request" ]
                && not (hasForbiddenNativeRequest openStep.domainRequests)
                && openStep.popupFocusDomId == Just "launcher-search"
                && Bar.statusDomId openStep.state.bar == Just "warlock-bar-status-scroll-3"
                && openStep.barResetTargets == [ ( "3", "warlock-bar-status-scroll-3" ) ]
      }
    , { name = "negForeignOrWrongRequestCatalogRejected"
      , category = "negative-catalog"
      , passed =
            (policyDesktop foreignCatStep.state).applications == Nothing
                && (policyDesktop wrongReqCatStep.state).applications == Nothing
                && ((policyDesktop wrongReqCatStep.state).expected |> Maybe.map UInt64.string) == Just catalogReq1
      }
    , { name = "catalogReceiptPopulatesEntriesAndFocusesLauncherSearch"
      , category = "launcher-and-catalog"
      , passed =
            let
                _ =
                    ( Announcement.view catStep.state.bar.announcements
                    , Announcement.view catStep.state.popup.announcements
                    )

                decodedCatIds =
                    (policyDesktop catStep.state).applications
                        |> Maybe.map (Catalog.entries >> List.map (\entry -> Catalog.id entry.identity))
                        |> Maybe.withDefault []

                encodedBindMatches =
                    (policyDesktop catStep.state).windows.shell.binding
                        |> Maybe.map (\bVal -> E.encode 0 (Binding.encode bVal) == E.encode 0 bind1)
                        |> Maybe.withDefault False
            in
            (policyDesktop catStep.state).expected == Nothing
                && encodedBindMatches
                && List.length decodedCatIds == 3
                && List.member "foot.desktop" decodedCatIds
                && catStep.popupFocusDomId == Just "launcher-search"
                && catStep.barFocusDomId == Nothing
                && catStep.popupPreviewSafe
                && UiHttp.problem catStep.state.popupHttp == Nothing
      }
    , { name = "appOnlyCatalogEnablesPinRefreshCloseDisablesLaunchAndJump"
      , category = "launcher-and-catalog"
      , passed =
            case popupSnapAfterCat of
                Nothing ->
                    False

                Just pSnap ->
                    Renderer.mode pSnap == "applications"
                        && List.all (\cid -> Renderer.enabled True cid pSnap)
                            [ "control:search"
                            , "control:refresh"
                            , "control:close"
                            , "pin:foot.desktop"
                            , "pin:org.gnome.Nautilus.desktop"
                            , "pin:warlock-bar-status-scroll-1"
                            ]
                        && List.all (\cid -> List.member cid (Renderer.controlIdentities True pSnap) && not (Renderer.enabled True cid pSnap))
                            [ "entry:foot.desktop"
                            , "jump:open:foot.desktop"
                            , "entry:org.gnome.Nautilus.desktop"
                            , "jump:open:org.gnome.Nautilus.desktop"
                            , "entry:warlock-bar-status-scroll-1"
                            , "jump:open:warlock-bar-status-scroll-1"
                            ]
      }
    , { name = "negPopupDisabledLaunchAndJumpForgedWireRefused"
      , category = "negative-controls"
      , passed = popupForgedLaunchBlocked
      }
    , { name = "adversarialControlIdsNeverCollideWithStatusScrollPrefix"
      , category = "stable-dom-ids"
      , passed =
            case ( Presentation.current catStep.state.bar.presentation, popupSnapAfterCat ) of
                ( Just bSnap, Just pSnap ) ->
                    allControlDomIdsValid bSnap && allControlDomIdsValid pSnap

                _ ->
                    False
      }
    , { name = "imeStartAndPreeditHoldLocalDraftWithoutNetworkDispatch"
      , category = "keyboard-and-ime"
      , passed =
            imeStartStep.state.popup.composition /= Popup.Idle
                && imePreeditStep.state.popup.composition /= Popup.Idle
                && imePreeditStep.state.popup.pendingQuery == Just "fo"
                && imePreeditStep.state.popup.lastQuery == Nothing
                && List.isEmpty imeStartStep.popupDispatched
                && List.isEmpty imePreeditStep.popupDispatched
                && (popupSnapAfterCat |> Maybe.andThen (Renderer.pendingQuery "fo" >> Renderer.queryValue)) == Just "fo"
      }
    , { name = "negImeComposingBlocksPopupButtonActivation"
      , category = "keyboard-and-ime"
      , passed =
            List.isEmpty imeBlockedButtonStep.popupDispatched
                && List.isEmpty imeBlockedButtonStep.domainRequests
                && imeBlockedButtonStep.state.popup.pendingQuery == Just "fo"
      }
    , { name = "sameLeaseRefreshPreservesImePreeditAndSuppressesFocusSteal"
      , category = "keyboard-and-ime"
      , passed =
            imeSameLeaseRefreshStep.state.popup.composition /= Popup.Idle
                && imeSameLeaseRefreshStep.state.popup.pendingQuery == Just "fo"
                && List.isEmpty imeSameLeaseRefreshStep.domainRequests
                && syntheticFocusDuringIme == Nothing
      }
    , { name = "imeCompositionEndCommitsSingleScopedSurfaceQuery"
      , category = "keyboard-and-ime"
      , passed =
            imeEndStep.state.popup.composition == Popup.Idle
                && imeEndStep.state.popup.pendingQuery == Nothing
                && (policyDesktop imeEndStep.state).query == "foot"
                && List.isEmpty imeEndStep.domainRequests
                && (popupSnapAfterFootSearch |> Maybe.map (Renderer.enabled True "pin:foot.desktop")) == Just True
                && (popupSnapAfterFootSearch |> Maybe.map (\s -> List.member "entry:org.gnome.Nautilus.desktop" (Renderer.controlIdentities True s))) == Just False
      }
    , { name = "precedingPublicationLocalEditRebasedWithinSameLeaseAndPreservesUnchangedStatusEpoch"
      , category = "keyboard-and-ime"
      , passed =
            (policyDesktop rebasedNautStep.state).query == "Files"
                && rebasedNautStep.state.popup.pendingQuery == Nothing
                && Bar.statusDomId rebasedNautStep.state.bar == Bar.statusDomId imeEndStep.state.bar
                && List.isEmpty rebasedNautStep.barResetTargets
                && (Presentation.current rebasedNautStep.state.popup.presentation |> Maybe.map (\s -> List.member "entry:org.gnome.Nautilus.desktop" (Renderer.controlIdentities True s))) == Just True
      }
    , { name = "negWrongLeaseAndControlCharQueryRejected"
      , category = "negative-ime-query"
      , passed =
            List.isEmpty wrongLeaseQueryStep.popupDispatched
                && List.isEmpty ctrlCharQueryStep.popupDispatched
                && (policyDesktop ctrlCharQueryStep.state).query == ""
      }
    , { name = "unacknowledgedDraftReplaysOnceAcrossConcurrentSameLeaseFrame"
      , category = "keyboard-and-ime"
      , passed =
            (policyDesktop pendingDraftState.state).query == "Foot"
                && pendingDraftState.state.popup.pendingQuery == Nothing
                && List.isEmpty pendingDraftState.domainRequests
      }
    , { name = "pinToggleEmitsSingleWriteLocksConcurrentChangesAndAdvancesStatusEpoch"
      , category = "pins-persistence"
      , passed =
            let
                priorEpochText =
                    Scroll.epoch clearSearchStep.state.bar.statusScroll
                        |> Maybe.map Scroll.epochString
                        |> Maybe.withDefault "0"

                nextEpochText =
                    advanceCounterString 1 priorEpochText

                nextDomText =
                    Scroll.reservedDomPrefix ++ nextEpochText
            in
            List.map requestKind pinFootStep.domainRequests == [ "taskbar-pins-write" ]
                && not (Pins.writable deskDuringPinSave.pins)
                && Desktop.pinIdentities deskDuringPinSave == []
                && Bar.statusDomId pinFootStep.state.bar == Just nextDomText
                && pinFootStep.barResetTargets == [ ( nextEpochText, nextDomText ) ]
      }
    , { name = "pinSavedReceiptSyncsPopupUnpinAndDisabledBarPinChip"
      , category = "pins-persistence"
      , passed =
            Desktop.pinIdentities (policyDesktop pinFootSavedStep.state) == [ "foot.desktop" ]
                && Pins.writable (policyDesktop pinFootSavedStep.state).pins
                && pinFootSavedStep.popupFocusDomId == Just "launcher-search"
                && (popupSnapAfterPin1 |> Maybe.map (Renderer.enabled True "unpin:foot.desktop")) == Just True
                && (barSnapAfterPin1 |> Maybe.map (\bSnap -> List.member "bar:pin:foot.desktop" (Renderer.controlIdentities False bSnap) && not (Renderer.enabled False "bar:pin:foot.desktop" bSnap))) == Just True
      }
    , { name = "secondPinAndMoveLeftReordersPersistedPinsAndBlocksBoundary"
      , category = "pins-persistence"
      , passed =
            Desktop.pinIdentities (policyDesktop moveLeftSavedStep.state) == [ "org.gnome.Nautilus.desktop", "foot.desktop" ]
                && (Presentation.current moveLeftSavedStep.state.bar.presentation
                        |> Maybe.map (Renderer.controlIdentities False >> List.filter (String.startsWith "bar:pin:"))
                   )
                == Just [ "bar:pin:org.gnome.Nautilus.desktop", "bar:pin:foot.desktop" ]
                && List.isEmpty boundaryMoveLeftStep.domainRequests
      }
    , { name = "negUnknownPinOutcomeNeverAutoRetriesAndRecoversViaExplicitRefresh"
      , category = "pins-persistence"
      , passed =
            List.isEmpty unknownOutcomeStep.domainRequests
                && not (Pins.writable (policyDesktop unknownOutcomeStep.state).pins)
                && List.map requestKind refreshAfterUnknownStep.domainRequests == [ "catalog-request" ]
                && Pins.writable (policyDesktop recoveredAfterUnknownStep.state).pins
      }
    , { name = "narrowSplitTopologyAndOwnerReflowMintReplacementLeaseWhilePreservingOpenPopupAndPins"
      , category = "reflow-escape-lifecycle"
      , passed =
            List.isEmpty narrowTopoStep.domainRequests
                && List.isEmpty narrow600Step.domainRequests
                && List.isEmpty narrowReflowStep.domainRequests
                && (policyDesktop narrowReflowStep.state).open
                && leaseBeforeEsc /= Tuple.second (currentPubAndLease narrow600Step.state)
                && Desktop.pinIdentities (policyDesktop narrowReflowStep.state) == [ "org.gnome.Nautilus.desktop", "foot.desktop" ]
                && (Presentation.current narrowReflowStep.state.popup.presentation |> Maybe.map allControlDomIdsValid) == Just True
      }
    , { name = "negStalePublicationEscapeIgnoredCurrentEscapeClosesPopupAndRetiresIme"
      , category = "reflow-escape-lifecycle"
      , passed =
            (policyDesktop staleEscStep.state).open
                && not (policyDesktop validEscStep.state).open
                && validEscStep.state.popup.composition == Popup.Idle
                && validEscStep.state.popup.pendingQuery == Nothing
                && (Presentation.current validEscStep.state.popup.presentation |> Maybe.map Renderer.mode) == Just "closed"
                && Outputs.owner validEscStep.state.policy.controller == Nothing
      }
    , { name = "negOldCapturedPopupActionRejectedAfterCloseAndReopenLeaseAdvance"
      , category = "reflow-escape-lifecycle"
      , passed =
            (policyDesktop reopenStep.state).open
                && List.isEmpty oldActionAfterReopen.popupDispatched
                && List.isEmpty oldActionAfterReopen.domainRequests
                && List.isEmpty oldActionViaPolicyAfterReopen.commits
                && List.isEmpty oldActionViaPolicyAfterReopen.domainRequests
      }
    , { name = "disconnectAndFreshBindingReconnectRetainAppOnlyGuarantees"
      , category = "reflow-escape-lifecycle"
      , passed =
            not (policyDesktop lostStep.state).windows.shell.applicationOnly
                && (policyDesktop lostStep.state).applications == Nothing
                && not (policyDesktop replayOldBindAfterLost.state).windows.shell.applicationOnly
                && (policyDesktop freshBindAfterLost.state).windows.shell.applicationOnly
                && List.isEmpty freshBindAfterLost.domainRequests
      }
    , { name = "statusScrollCounterExhaustionFailsClosedWithoutIdReuse"
      , category = "stable-dom-ids"
      , passed =
            Scroll.exhausted exhaustedBarModel.statusScroll
                && Bar.statusDomId exhaustedBarModel == Nothing
      }
    , { name = "seededHigh64BitAppOnlyJourneysPreserveAllInvariants"
      , category = "seeded-sweep"
      , passed = List.all runSeededJourney (List.range 0 15)
      }
    ]


runSeededJourney : Int -> Bool
runSeededJourney seedIndex =
    let
        lifeStr =
            advanceCounterString (seedIndex * 3 + 1) "9007199254741001"

        sessStr =
            advanceCounterString (seedIndex * 5 + 2) "9007199254742001"

        frontStr =
            advanceCounterString (seedIndex * 7 + 3) "9007199254743001"

        scopeStr =
            String.fromInt (seedIndex + 1)

        sScope =
            scopeValue scopeStr "1"

        sBind =
            bindingJson lifeStr sessStr frontStr

        widthPx =
            480 + modBy 500 (seedIndex * 37)

        s0 =
            stepTopology "1" (Just ( sScope, [ 0, 0, widthPx, 680 ] )) initial

        s1 =
            stepNative (appAttachedJson sBind []) s0.state

        s2 =
            stepBarAction "bar:applications" s1.state

        catReq =
            List.head s2.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        s3 =
            stepNative
                (catalogReceiptJson sBind catReq (sampleCatalogSnapshot lifeStr "1") (Just ( "1", [] )))
                s2.state

        ( pub3, lease3 ) =
            currentPubAndLease s3.state

        s4 =
            stepPopupLocalEdit (localQueryPacket "surface-query" pub3 lease3 "Foot") s3.state

        s5 =
            stepPopupAction "pin:foot.desktop" s4.state

        pinReq =
            List.head s5.domainRequests |> Maybe.map requestIdOf |> Maybe.withDefault "0"

        s6 =
            stepNative (pinsOutcomeJson sBind pinReq "Saved" (Just ( "2", [ "foot.desktop" ] ))) s5.state

        s7 =
            stepEscape Nothing s6.state

        allReqs =
            s0.domainRequests
                ++ s1.domainRequests
                ++ s2.domainRequests
                ++ s3.domainRequests
                ++ s4.domainRequests
                ++ s5.domainRequests
                ++ s6.domainRequests
                ++ s7.domainRequests

        domIdsClean =
            case ( Presentation.current s6.state.bar.presentation, Presentation.current s6.state.popup.presentation ) of
                ( Just bSnap, Just pSnap ) ->
                    allControlDomIdsValid bSnap && allControlDomIdsValid pSnap

                _ ->
                    False
    in
    not (hasForbiddenNativeRequest allReqs)
        && (policyDesktop s1.state).windows.shell.applicationOnly
        && s3.popupFocusDomId == Just "launcher-search"
        && Desktop.pinIdentities (policyDesktop s6.state) == [ "foot.desktop" ]
        && not (policyDesktop s7.state).open
        && s7.popupPreviewSafe
        && domIdsClean


allChecks : List CheckRow
allChecks =
    journeyChecks


suiteReport : () -> E.Value
suiteReport () =
    let
        rows =
            allChecks

        failed =
            List.filter (\row -> not row.passed) rows

        allPassed =
            List.isEmpty failed
    in
    E.object
        [ ( "schema", E.int 1 )
        , ( "kind", E.string "suite-report" )
        , ( "module", E.string "EngineMvpJourney" )
        , ( "passed", E.bool allPassed )
        , ( "totalChecks", E.int (List.length rows) )
        , ( "failedCount", E.int (List.length failed) )
        , ( "failedNames", E.list (\row -> E.string row.name) failed )
        , ( "checks", E.object (List.map (\row -> ( row.name, E.bool row.passed )) rows) )
        , ( "rows"
          , E.list
                (\row ->
                    E.object
                        [ ( "name", E.string row.name )
                        , ( "category", E.string row.category )
                        , ( "passed", E.bool row.passed )
                        ]
                )
                rows
          )
        , ( "acceptanceLimits", encodeAcceptanceLimits acceptanceLimits )
        , ( "nativeAcceptance", E.bool False )
        , ( "guiAcceptance", E.bool False )
        , ( "releaseAccepted", E.bool False )
        , ( "protectedQaAccepted", E.bool False )
        ]


encodeStepReport : String -> StepOutcome -> E.Value
encodeStepReport stepTag outcome =
    let
        desk =
            policyDesktop outcome.state

        nullableString maybeText =
            maybeText |> Maybe.map E.string |> Maybe.withDefault E.null

        barIds =
            Presentation.current outcome.state.bar.presentation
                |> Maybe.map (Renderer.controlIdentities False)
                |> Maybe.withDefault []

        popupIds =
            Presentation.current outcome.state.popup.presentation
                |> Maybe.map (Renderer.controlIdentities True)
                |> Maybe.withDefault []
    in
    E.object
        [ ( "schema", E.int 1 )
        , ( "kind", E.string "step-report" )
        , ( "stepKind", E.string stepTag )
        , ( "applicationOnly", E.bool desk.windows.shell.applicationOnly )
        , ( "shellAvailable", E.bool (Shell.available desk.windows.shell) )
        , ( "shell", Shell.encode desk.windows.shell )
        , ( "open", E.bool desk.open )
        , ( "query", E.string desk.query )
        , ( "pinIdentities", E.list E.string (Desktop.pinIdentities desk) )
        , ( "pinsWritable", E.bool (Pins.writable desk.pins) )
        , ( "pendingBatches", E.int (Outputs.pendingBatches outcome.state.policy.controller) )
        , ( "barStatusDomId", nullableString (Bar.statusDomId outcome.state.bar) )
        , ( "barFocusDomId", nullableString outcome.barFocusDomId )
        , ( "popupFocusDomId", nullableString outcome.popupFocusDomId )
        , ( "popupComposing", E.bool (outcome.state.popup.composition /= Popup.Idle) )
        , ( "popupPendingQuery", nullableString outcome.state.popup.pendingQuery )
        , ( "popupPreviewSafe", E.bool outcome.popupPreviewSafe )
        , ( "barControlIds", E.list E.string barIds )
        , ( "popupControlIds", E.list E.string popupIds )
        , ( "domainRequests", E.list identity outcome.domainRequests )
        , ( "forbiddenNativeRequest", E.bool (hasForbiddenNativeRequest outcome.domainRequests) )
        , ( "barResetTargets"
          , E.list
                (\( ep, dom ) ->
                    E.object [ ( "epoch", E.string ep ), ( "domId", E.string dom ) ]
                )
                outcome.barResetTargets
          )
        , ( "nativeAcceptance", E.bool False )
        , ( "guiAcceptance", E.bool False )
        , ( "releaseAccepted", E.bool False )
        ]


update : Msg -> CoupledState -> ( CoupledState, Cmd Msg )
update (Input raw) currentState =
    let
        tag =
            D.decodeValue (D.field "kind" D.string) raw |> Result.withDefault ""

        payloadVal =
            D.decodeValue (D.field "value" D.value) raw |> Result.withDefault E.null
    in
    case tag of
        "suite" ->
            ( currentState, outgoing (suiteReport ()) )

        "reset" ->
            let
                fresh =
                    emptyOutcome initial
            in
            ( initial, outgoing (encodeStepReport "reset" fresh) )

        "topology" ->
            let
                revText =
                    D.decodeValue (D.field "revision" D.string) payloadVal |> Result.withDefault "1"

                boxCoords =
                    D.decodeValue (D.field "box" (D.list D.int)) payloadVal |> Result.withDefault [ 0, 0, 980, 680 ]

                scopeObj =
                    D.decodeValue (D.field "scope" D.value) payloadVal |> Result.withDefault (scopeValue "1" "1")

                out =
                    stepTopology revText (Just ( scopeObj, boxCoords )) currentState
            in
            ( out.state, outgoing (encodeStepReport "topology" out) )

        "attach" ->
            let
                out =
                    stepNative payloadVal currentState
            in
            ( out.state, outgoing (encodeStepReport "attach" out) )

        "native" ->
            let
                out =
                    stepNative payloadVal currentState
            in
            ( out.state, outgoing (encodeStepReport "native" out) )

        "bar-action" ->
            let
                cid =
                    D.decodeValue (D.field "id" D.string) payloadVal |> Result.withDefault ""

                out =
                    stepBarAction cid currentState
            in
            ( out.state, outgoing (encodeStepReport "bar-action" out) )

        "popup-action" ->
            let
                cid =
                    D.decodeValue (D.field "id" D.string) payloadVal |> Result.withDefault ""

                out =
                    stepPopupAction cid currentState
            in
            ( out.state, outgoing (encodeStepReport "popup-action" out) )

        "local-edit" ->
            let
                out =
                    stepPopupLocalEdit payloadVal currentState
            in
            ( out.state, outgoing (encodeStepReport "local-edit" out) )

        "escape" ->
            let
                overridePub =
                    D.decodeValue (D.field "publication" D.string) payloadVal |> Result.toMaybe

                out =
                    stepEscape overridePub currentState
            in
            ( out.state, outgoing (encodeStepReport "escape" out) )

        "reflow" ->
            let
                out =
                    stepReflow currentState
            in
            ( out.state, outgoing (encodeStepReport "reflow" out) )

        "dismiss" ->
            let
                out =
                    stepDismiss currentState
            in
            ( out.state, outgoing (encodeStepReport "dismiss" out) )

        "transport-lost" ->
            let
                out =
                    stepTransportLost currentState
            in
            ( out.state, outgoing (encodeStepReport "transport-lost" out) )

        _ ->
            ( currentState, outgoing (encodeStepReport "noop" (emptyOutcome currentState)) )


main : Program () CoupledState Msg
main =
    Platform.worker
        { init = \_ -> ( initial, outgoing (suiteReport ()) )
        , update = update
        , subscriptions = \_ -> incoming Input
        }
