{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY UNEXECUTED source control against projected v8 owner plus
-- terra-engine-owner-v8-final-close-seam.patch. No production timeout changes.
-- A selected direct-child owner is used; hooks simulate scheduler delay and are
-- not proof of real kernel blocking, namespace containment or provider cleanup.
module OwnerV8FinalCloseControls (runOwnerV8FinalCloseControls) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless, when)
import Data.IORef (newIORef, readIORef, writeIORef)
import System.IO (Handle)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError)
import Warlock.Capture.Process.Bootstrap (OwnerStatus(..))
import Warlock.Capture.Process.Persistent
  ( PersistentOwner, PersistentStatus(..), PidfdCustody(..), SessionExit(..)
  , newPersistentOwner, persistentStatus, persistentPidfdCustody, persistentUnderlyingStatus
  , startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal
  ( persistentFixture, withPersistentOwnerHook )

data Case = Positive | DelayBeforeClose | DelayAfterClose deriving (Eq,Show)
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("owner-v8-final-close: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- Root supplies actual fixture child, real readiness and externally retained
-- owner/input handles before returning. Never close on uncertain disposition.
runOwnerV8FinalCloseControls :: (PersistentOwner -> IO Handle) -> FilePath -> [String]
  -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runOwnerV8FinalCloseControls acquireAndRetain executable args verifyReady =
 mapM_ runOne [Positive,DelayBeforeClose,DelayAfterClose]
 where
  runOne testCase = do
   owner <- newPersistentOwner
   input <- acquireAndRetain owner
   startup <- startBudgetAfter 3000000 >>= must
   stop <- must (stopBudgetMicros 1000000)
   sampled <- newIORef False
   closeEntered <- newIORef False
   closeReturned <- newIORef False
   let observe stage = do
        when (stage == "qa-stderr-after-budget-sample") $ do
         writeIORef sampled True
         when (testCase == DelayBeforeClose) (threadDelay 1200000)
        when (stage == "qa-stderr-close-entered") (writeIORef closeEntered True)
        when (stage == "qa-stderr-after-close-return") $ do
         writeIORef closeReturned True
         when (testCase == DelayAfterClose) (threadDelay 1200000)
   outcome <- withPersistentOwnerHook owner
    (persistentFixture executable args input) 4096 startup stop verifyReady (\_ -> pure ()) observe
   state <- persistentStatus owner
   rawState <- persistentUnderlyingStatus owner
   custody <- persistentPidfdCustody owner
   reachedSample <- readIORef sampled
   enteredClose <- readIORef closeEntered
   sawClose <- readIORef closeReturned
   let failed = case outcome of Left (ExitUncertain _ _) -> True; _ -> False
       quarantined = case state of PersistentQuarantined _ -> True; _ -> False
       rawQuarantined = case rawState of Quarantined _ -> True; _ -> False
   case testCase of
    Positive -> check "positive clean owner" (reachedSample && enteredClose && sawClose && state == PersistentRetired && custody == PidfdClosed && rawState == Available && case outcome of Right ((),LeaderReaped _) -> True; _ -> False)
    DelayBeforeClose -> do
     -- This is the RED target for v8: current boundedByDl resamples only after
     -- the action, so the QA stall can cause hClose to start after D. It must
     -- refuse that entry without saying the owner finished in budget.
     check "pre-entry delay crossed original stop D" reachedSample
     check "no stderr close entered after known expired D" (not enteredClose && not sawClose && failed && quarantined && rawQuarantined && custody == PidfdClosed)
    DelayAfterClose -> do
     -- Exact hClose returned before the controlled stall; preserve that fact,
     -- while the owner result must remain untimely and quarantined after D.
     check "stderr close returned before post-result delay" (reachedSample && enteredClose && sawClose)
     check "late cleanup is not clean retirement" (failed && quarantined && rawQuarantined && custody == PidfdClosed)
