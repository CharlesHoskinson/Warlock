-- UNRUN QA-only fixture. Requires owner v6 + terra-security 5c60 correction
-- plus sticky-fault correction c324 and the test-only hook patch 4a82. Root owns build/execution,
-- selected child, budgets, process cleanup and source/artifact binding.
-- No fixture result proves native acceptance or actual unregister failure.
module TerraSecurityWakeScopeRace
  ( WakeProbe, newWakeProbe, wakeProbeHook, wakeProbeOutstanding, exerciseWakeScope
  , failBeforeUnregisterHook, exerciseInjectedCleanupFailure ) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
  ( MVar, modifyMVar, modifyMVar_, newEmptyMVar, newMVar, putMVar, readMVar, takeMVar, tryPutMVar )
import Control.Exception (SomeException, finally, mask)
import Control.Monad (unless, void)
import Data.IORef (IORef, newIORef, writeIORef)
import GHC.Conc (STM, atomically, orElse)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent
  ( LiveSession, LiveWakeReason(..), liveSessionStopRequestedSTM
  , withLiveFrameAdmission, withLiveSessionWakeSTM )

data Borrower = Borrower LiveSession (IORef (Maybe ThreadId)) (MVar (Either SomeException (Either ToolError ())))
data WakeProbe = WakeProbe (MVar ()) (MVar ()) (MVar (Maybe Borrower)) (MVar Bool)

newWakeProbe :: IO WakeProbe
newWakeProbe = WakeProbe <$> newEmptyMVar <*> newEmptyMVar <*> newMVar Nothing <*> newMVar False

-- A True result means the Root-owned fixture must retain this probe and its
-- owner; it is not proof that the borrower thread is still executing.
wakeProbeOutstanding :: WakeProbe -> IO Bool
wakeProbeOutstanding (WakeProbe _ _ borrower _) = do
  current <- readMVar borrower
  pure (case current of Nothing -> False; Just _ -> True)

-- Pass this hook to the private withPersistentOwnerHook in a Root-owned
-- isolated fixture. It pauses only after tombstone publication, while the
-- real GHC registration and the owner's wake pin are still held.
wakeProbeHook :: WakeProbe -> String -> IO ()
wakeProbeHook (WakeProbe entered release _ _) stage =
  if stage == "persistent-wake-tombstoned-before-unregister"
    then putMVar entered () >> takeMVar release
    else pure ()

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError ("wake-scope: " ++ name)))

bounded :: String -> IO a -> IO a
bounded name action = do
  result <- timeout 2000000 action
  maybe (ioError (userError ("wake-scope timeout: " ++ name))) pure result

-- Call while the actual selected child is still alive and the owner remains
-- scoped. A forked borrower returns the actual STM; the cleanup hook holds
-- unregister. At this exact point the escaped STM must return ScopeExited,
-- not stop, death or retry. Signal release and await completion before success.
-- If the completion receipt fails, the owner must treat its borrower as uncertain and
-- quarantine under the unchanged stop budget; this function cannot prove it.
exerciseWakeScope :: WakeProbe -> LiveSession -> IO ()
exerciseWakeScope (WakeProbe entered release borrower used) session = mask $ \restore -> do
  first <- modifyMVar used (\already -> pure (True, not already))
  check "probe is one-shot" first
  escaped <- newEmptyMVar :: IO (MVar (STM LiveWakeReason))
  done <- newEmptyMVar :: IO (MVar (Either SomeException (Either ToolError ())))
  workerId <- newIORef Nothing
  -- Publish owner scope and completion before forking, while masked. A
  -- contended registry cannot strand an already-started unrecorded worker.
  modifyMVar_ borrower (const (pure (Just (Borrower session workerId done))))
  tid <- forkFinally
    (withLiveSessionWakeSTM session (putMVar escaped))
    (putMVar done)
  writeIORef workerId (Just tid)
  -- Root must retain the probe and owner across any uncertain completion.
  let releaseAndAwait = do
        void (tryPutMVar release ())
        void (timeout 2000000 (readMVar done))
  restore (do
    wake <- bounded "capture wake STM" (takeMVar escaped)
    bounded "cleanup reached hook" (takeMVar entered)
    observed <- bounded "escaped wake while cleanup paused" (atomically wake)
    check "tombstone visible before unregister" (observed == LiveWakeScopeExited)
    void (tryPutMVar release ())
    finished <- bounded "wake scope returned" (readMVar done)
    check "borrow scope returned successfully" (case finished of
      Right (Right ()) -> True
      _ -> False)
    modifyMVar_ borrower (const (pure Nothing))) `finally` releaseAndAwait

-- Separate negative control. This injects failure immediately BEFORE the real
-- unregister, rather than claiming to simulate a kernel/event-manager error.
-- Root must assert that owner teardown yields uncertain/quarantined (not a
-- reaped/closed success), retains pidfd custody, and preserves original stop D.
failBeforeUnregisterHook :: String -> IO ()
failBeforeUnregisterHook stage =
  if stage == "persistent-wake-tombstoned-before-unregister"
    then ioError (userError "injected failure before unregister")
    else pure ()

exerciseInjectedCleanupFailure :: LiveSession -> IO ()
exerciseInjectedCleanupFailure session = do
  result <- bounded "injected cleanup failure" (withLiveSessionWakeSTM session (\_ -> pure ()))
  check "cleanup failure remains explicit" (result == Left SpawnOrIO)
  stopped <- atomically ((liveSessionStopRequestedSTM session >> pure True) `orElse` pure False)
  check "unsafe unregister latches stop" stopped
  refused <- bounded "post-fault frame admission" (withLiveFrameAdmission session (\_ -> pure ()))
  check "unsafe unregister refuses later frame admission" (refused == Left SessionClosed)
