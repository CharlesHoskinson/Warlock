# `gemini-gui` Wave `20261101T203935Z` — App-Only Hierarchy, Empty-State & `attempt-02/run-01` `Applications` Click-Failure Trace

- **Author**: `gemini-gui` (`run: warlock-20261031-setup`)
- **Canonical Baseline**: Source `889e9458d1707c456f5bb6e9af560383b066229e` (`HEAD` `59a2f38ab`, includes accepted original `ELM-TEA-002`; whole `ELM-TEA-001` remains incomplete; current Root slice `ui005-live-query-refresh`)
- **Scope Discipline**:
  - Production GUI code is 100% Elm (`Surface.elm` as single policy authority; `SurfaceRenderer.elm` and `SurfaceTheme.elm` as pure projection/presentation).
  - Zero worker compiler, Node, Quint, browser, native, GPU, or VM execution.
  - `Popup.elm` and `SurfaceSnapshot.elm` are **untouched** in `gemini-gui-app-only-hierarchy-empty-state-2039.patch`, keeping it 100% orthogonal to `gemini-gui-popup-pending-query-mvp-2016.patch` (`sha256:1c7393cd6b9f6574f01b69426bb65b70b84846a8a7f3aa584da450d7ad6de86f`).
  - All QA checks in `gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch` are **proposed source-route and HTTP/DOM harness assertions** for Root's protected execution; they do not establish native or GUI acceptance.

---

## 1. Deliverable Paths & SHA-256 Hashes

| Artifact | Path | SHA-256 |
|---|---|---|
| **App-Only Hierarchy & Empty-State Source Patch (`2039`)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.patch` | `4194a3e206aecf31cd2987d803167ed0d904b1a33b6369b7223c907b40347869` |
| **App-Only Hierarchy & Empty-State QA Patch (`2039`)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch` | `67a3b21fdb49ee0e789b6c710ad5fa79ba6f725fffb6c4edfa96d370542149af` |
| **Orthogonal Pending-Query Affordance Source Patch (`2016`, preserved)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-popup-pending-query-mvp-2016.patch` | `1c7393cd6b9f6574f01b69426bb65b70b84846a8a7f3aa584da450d7ad6de86f` |
| **Prior Baseline Patch (`1719`, preserved)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/AppOnlyHierarchyEmptyState.patch` | `ef1bb568ae123152b6e17d12abe5e1def81f987f236d16a80cf6837f6e2b50b8` |

Verified cleanly with:
```bash
git -C /home/charl/code/Warlock apply --check \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.patch \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-popup-pending-query-mvp-2016.patch
```

---

## 2. Forensic Trace of `attempt-02/run-01` `Applications` Click Failure (`lead` `01M6CDEM9K6XJF2HB5C7AYRE6Y`)

We inspected `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/run-01/` (`host-journey-result.json`, `001-applications-ready.png` `97f3cc6a...`, `002-search-label-ready.png` `bd210bf9...`, `006-search-label-ready.png` `8f00c98f...`) and decoded the exact RGB pixel rows across `y = 40..94` (`local y = 2..56` inside the `621×749` window at `at = [647, 38]`).

### Primary Root Cause: `applications-ready` Checked `pView` (`y = 120..148`) While `bView` (`y = 38..109`) Was Still 100% Unpainted White

1. **Dual-WebView Split in `Mvp.hsc:683-687` & `Owner.hs:250, 267`**:
   - The GTK container (`621×749` at `x = 647..1268, y = 38..787`) packs `bView` (`HttpBar`, fixed `72px` height at `y = 38..109`, `local y = 0..71`) above `pView` (`HttpPopup`, `677px` height at `y = 110..787`, `local y = 72..748`).
   - `Controller`, `Bar` (`bView`), and `Popup` (`pView`) run independent `WebKitWebView` document loads and independent `GET /events` poll loops (`UiHttp.elm:61-70`, `100ms` spacing).
2. **What Happened at `rem_s = 26.8s..25.635s` in `attempt-02/run-01`**:
   - The host driver's readiness gate `visible('run-03-before.png', (670, 120, 850, 148), 'applications-ready')` compared pixels in **`y = 120..148`**, which is `<h1>Choose a window</h1>` inside **`pView` (`HttpPopup`)**, NOT `bView` (`HttpBar`)!
   - In `001-applications-ready.png` (`97f3cc6ae08fa77ff75267a9f2ac113c1a2889598d29c462f7f126619d8f4040`), `pView` had just painted `"Choose a window"` at `y = 120..148`, triggering `applications_ready: true` (`changed: 970, ratio: 0.19246`), while **`bView` (`y = 40..94`) was still 100% unpainted solid white `(253, 252, 253)`** at every sampled column (`x = 680, 700, 711, 740, 800, 950, 1100`)!
   - The host driver immediately dispatched `motion` (`rem_s = 26.567`), `motion` (`rem_s = 26.263`), `press` (`rem_s = 25.950`), and `release` (`rem_s = 25.635`) at `(711, 73)` (`box = [660, 66, 770, 83]`) while `bView` had not yet painted `bar:applications`.
   - By `002-search-label-ready.png` (`bd210bf9...`, `rem_s ≈ 21.5s`), `bView` had finished painting its closed-mode toolbar (`y = 40..93` dark Lacquer `#191516` `(25, 21, 22)` with `Applications` text at `y = 60..71`), but the single physical click had already been spent at `rem_s = 25.950s`, so `HttpPopup` remained in `mode == "closed"` for the rest of the run.

### Secondary Root Cause: WebKitGTK Horizontal Scrollbar Overlay Inside `.surface-actions` (`y = 79..88`)

1. **Exact Pixel Measurements in `002-search-label-ready.png` & `006-search-label-ready.png`**:
   - In `Surface.elm:423-424`, `supportedUtilities` renders 7 toolbar buttons (`Applications` + 6 disabled utility buttons `Task View`, `Switch windows`, `Notifications`, `Files`, `System`, `Settings`) inside `.surface-actions` (`height: calc(3em + 8px)` = `56px`, `y = 38..94`), while `.surface-status` occupies `clamp(180px, 40vw, 360px)` = `248px` of the `621px` width, leaving `373px` for `.surface-actions`.
   - Because 7 buttons (~`680px`) overflow `373px` horizontally and `barActionsStyles` (`SurfaceTheme.elm:300-312`) has `overflow-x: auto`, WebKitGTK renders a horizontal scrollbar thumb across the bottom of `.surface-actions` at **`y = 79..88` (`local y = 41..50`)** — decoded RGB `(146, 131, 134)` in `002-search-label-ready.png` and `(103, 84, 87)` in `006-search-label-ready.png`.
   - Meanwhile, the `Applications` button text (`#f6efe8` `(246, 239, 232)`) sits at **`y = 60..71` (`local y = 22..33`)**, and the button's uncluttered upper body is **`y = 52..72` (`local y = 14..34`)**, whereas clicking at `y = 73..83` (`local y = 35..45`) lands on the bottom edge / WebKitGTK horizontal scrollbar zone.
2. **Fixes in Elm (`SurfaceTheme.elm`) and Host Readiness Guidance**:
   - **Elm (`SurfaceTheme.barActionsStyles`, included in `gemini-gui-app-only-hierarchy-empty-state-2039.patch`)**: Added `style "scrollbar-width" "none"` to `barActionsStyles` so WebKitGTK does not paint a horizontal scrollbar overlay over the bottom of `bar:applications` in `621px` tiled windows, while preserving `overflow-x: auto` programmatic scrollability and `calc(3em + 8px)` bar height.
   - **Host Driver Readiness & Hit-Target Guidance (for Root's runner inside original `D = 28s` deadline)**:
     - Gate `'applications-ready'` on `bView`'s actual `Applications` button region — reference `(660, 52, 768, 72)` (`local (13, 14, 121, 34)` relative to window `at = [647, 38]`) — rather than `pView`'s heading at `(670, 120, 850, 148)`.
     - Target the `Applications` click inside `reference (660, 56, 768, 70)` (`local (13, 18, 121, 32)`, center `local y = 24` / screen `y = 62`), centered on the button text row (`y = 60..71`) and well above `y = 79..88`.
     - Per `sol-docs` (`01M6CD2WBX37TFV701AC9ZF11J`, `01M6CD4GPJKABWTH8YSXJQ97MD`), all host readiness/drain steps must stay strictly inside the original `D = 28s` deadline cap, and pixel diffs serve only as supporting readiness checks (never text or focus proof).

---

## 3. Source Patch Summary (`gemini-gui-app-only-hierarchy-empty-state-2039.patch`)

1. **`implementation/warlock/src/Surface.elm` (`notice`, lines 436–450 — Single Policy Authority)**:
   - When `mode model == "closed" && model.windows.shell.applicationOnly && contextNotice model /= Shell.status model.windows.shell` (e.g., when `pins.notice` is non-empty or when `catalogFailure /= Nothing` produces `"Applications were not opened. Choose Applications again."` after a failed/closed `Applications` open), `Surface.notice` appends `" · " ++ Shell.status model.windows.shell` (`" · Applications connected. Window controls unavailable."`).
   - Preserves the exact initial `application-attached` status `"Applications connected. Window controls unavailable."` unchanged while ensuring closed-mode `applicationOnly` context is never lost on override notices.
2. **`implementation/warlock/src/SurfaceRenderer.elm` (`render`, lines 142–176)**:
   - Strips `compactNoticePrefix` (`"Compact presentation; open Applications, search or use pages for every application and pin action. · "`) when present to obtain `canonicalContextStatus`.
   - Defines `appOnlyNotice = "Applications connected. Window controls unavailable."` and `isCanonicalAppOnlyNotice = canonicalContextStatus == appOnlyNotice || String.endsWith (" · " ++ appOnlyNotice) canonicalContextStatus`.
   - Replaces the misleading closed-mode `<h1>Choose a window</h1>` with **`<h1>Application workspace</h1>`** when `snapshot.mode == "closed" && isCanonicalAppOnlyNotice`, while preserving `"Applications"` when `snapshot.mode == "applications"` and `"Choose a window"` for ordinary window-shell closed/picker states.
   - Emits a non-interactive keyed empty-state card inside `.surface-controls` **only when `snapshot.mode == "closed" && List.isEmpty snapshot.popup`**:
     - `isCanonicalAppOnlyNotice` -> `("empty:closed-app-only", emptyStateCard "app-only-closed" "Open Applications to browse the catalog" "Select Applications in the taskbar to search entries, manage taskbar pins, or refresh the list.")`
     - `canonicalContextStatus == "Connection lost. Reconnect to continue."` -> `("empty:closed-detached", emptyStateCard "detached-closed" "Window connection lost" "Select Reconnect in the taskbar to restore the window connection.")`
     - otherwise -> `("empty:closed-idle", emptyStateCard "window-closed" "No panel open" "Select an enabled control in the taskbar above.")`
   - Leaves `snapshot.mode == "applications"` completely free of duplicate status cards (`Popup.elm` and `SurfaceSnapshot.elm` untouched), eliminating any stale-status echo during `pendingQuery` or IME composition.
3. **`implementation/warlock/src/SurfaceTheme.elm`**:
   - Adds `style "scrollbar-width" "none"` to `barActionsStyles`.
   - Changes `barRootStyles` lower `100vh` fill shadow from `palette.canvas` to `palette.surfaceRecessed` so the `16px` space below the `56px` `.surface-bar` inside `72px` `bView` blends seamlessly into the recessed status well.
   - Extends `statusStripeColor` to give `"Type to search applications."` and `"Choose a matching application."` the `palette.brandAccent` left stripe.
   - Adds `popupHeadingForModeStyles`, `popupControlsPanelStyles`, `popupEmptyStateStyles`, `popupEmptyTitleStyles`, and `popupEmptyBodyStyles` (suppressing `box-shadow` whenever `appearance.effectsOff` or `surfaceMode == "closed"` to preserve `layer-appearance-browser.mjs` and `accessibility-browser.mjs` invariants).

---

## 4. Proposed QA Patch Summary (`gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch`)

1. **`implementation/warlock/qa/StandaloneMvpReplay.elm` & `implementation/warlock/qa/standalone-mvp.cjs`**:
   - Proposed assertions across all 32 deterministic seeds verifying:
     - On `application-attached`: `r.frame.mode === 'closed'`, `r.frame.status === 'Applications connected. Window controls unavailable.'`, `r.frame.popup.length === 0`.
     - On `open`: `r.frame.mode === 'applications'`, `r.frame.status === 'Loading applications…'`.
     - On `application-catalog`: `r.frame.mode === 'applications'`, `r.frame.status === 'Type to search applications.'`.
   - Proposed catalog-unavailable (`snapshot: null`) check verifying `!r.open && r.frame.mode === 'closed' && r.frame.status === 'Applications were not opened. Choose Applications again. · Applications connected. Window controls unavailable.'`.
2. **`implementation/warlock/qa/ui-http.cjs` (`appOnlyEmptyStateHierarchy()`)**:
   - Proposed end-to-end HTTP/DOM harness checks driving compiled `HttpMain` -> `view-commit.projection.frame` -> `HttpBar` and `HttpPopup`:
     - `HttpBar` enables `bar:applications`, disables `bar:overview`, and renders `[role="status"]` `'Applications connected. Window controls unavailable.'`.
     - `HttpPopup` in closed app-only mode renders `<h1>Application workspace</h1>` (`!== 'Choose a window'`), `<p role="status">Applications connected. Window controls unavailable.</p>`, and non-interactive `[data-empty-state="app-only-closed"]` (`'Open Applications to browse the catalog'`) with zero `<button>`/`<input>`/`[tabindex]` children and zero POSTs.
     - `HttpPopup` in closed app-only mode with catalog-failure notice (`'Applications were not opened. Choose Applications again. · Applications connected. Window controls unavailable.'`) retains `<h1>Application workspace</h1>` and `[data-empty-state="app-only-closed"]`.
     - `HttpPopup` in open `mode: 'applications'` transitions `<h1>` to `'Applications'` and removes `[data-empty-state]`.
     - Negative controls: ordinary window-shell closed (`status: 'Connected'`) -> `<h1>Choose a window</h1>` + `[data-empty-state="window-closed"]`; detached closed (`status: 'Connection lost. Reconnect to continue.'`) -> `<h1>Choose a window</h1>` + `[data-empty-state="detached-closed"]`.
