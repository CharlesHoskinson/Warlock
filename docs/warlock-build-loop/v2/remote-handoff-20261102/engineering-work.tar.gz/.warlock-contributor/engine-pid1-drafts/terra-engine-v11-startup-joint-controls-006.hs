{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- Root-only source fixture; never executed by source worker. Build an isolated
-- QA component with WARLOCK_BORROW_QA and terra-engine-held-gate-qa-seam-
-- 006.patch, v11 startup-acquire patch, and startup-joint-qa-seam-004.patch.
-- Do not ship QA seams.
-- Root must retain Probe AND each resolver-verified acquisition before return;
-- this fixture does not prove child namespace, provider, fd, thread, or native
-- cleanup. A timed-out completion must stay in Root's outer custody registry.
module StartupBorrowAcquireControls (Probe, newProbe, runPositive, runExpiry, runStop, runCancel, runStopAfterRaw, runAbortHookError) where

import Control.Concurrent (ThreadId, forkFinally, killThread, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, PersistentStatus(..), PidfdCustody(..), SessionExit(..), StopReceipt(..)
 , newPersistentOwner, persistentStatus, persistentUnderlyingStatus, persistentPidfdCustody
 , persistentHeldNoInput, requestSessionStop, startBudgetAfter, stopBudgetMicros, withPersistentOwner )
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)
import Warlock.Platform.Executable (HeldExecutable, qaHoldHeldGate)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe
 { ownerRef :: IORef (Maybe PersistentOwner), heldRef :: IORef (Maybe HeldExecutable)
 , holderRef :: IORef (Maybe ThreadId), ownerThreadRef :: IORef (Maybe ThreadId)
 , killerRef :: IORef (Maybe ThreadId), holderDone :: MVar (Either SomeException ())
 , ownerDone :: MVar Result, killerDone :: MVar (Either SomeException ())
 , used :: IORef Bool }
newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("startup-borrow: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and owners"))) pure

-- The caller allocates and roots Probe before calling and roots the exact
-- resolver-issued held capability inside acquireAndRetain before it returns.
runPositive :: Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runPositive probe acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selection <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 start <- startBudgetAfter 3000000 >>= must
 stop <- must (stopBudgetMicros 1000000)
 result <- restore (withPersistentOwner owner selection 4096 start stop ready (\_ -> pure ()))
 state <- persistentStatus owner
 raw <- persistentUnderlyingStatus owner
 pidfd <- persistentPidfdCustody owner
 check "real selected held child can start and retire" (state == PersistentRetired && raw == Available && pidfd == PidfdClosed &&
  case result of Right ((),LeaderReaped _) -> True; _ -> False)

data Mode = Expiry | ExplicitStop | AsyncCancel | StopAfterRaw | AbortHookError
runExpiry, runStop, runCancel, runStopAfterRaw, runAbortHookError :: Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runExpiry = runBlocked Expiry
runStop = runBlocked ExplicitStop
runCancel = runBlocked AsyncCancel
runStopAfterRaw = runBlocked StopAfterRaw
runAbortHookError = runBlocked AbortHookError

runBlocked :: Mode -> Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runBlocked mode probe acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selection <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 stop <- must (stopBudgetMicros 1000000)
 gateEntered <- newEmptyMVar
 gateBlocked <- newEmptyMVar
 rawAborted <- newEmptyMVar
 rawContinue <- newEmptyMVar
 unlock <- newEmptyMVar
 spawnCalls <- newIORef (0 :: Int)
 let signalGate = qaHoldHeldGate held (putMVar gateEntered ()) (readMVar unlock)
     hook stage = case stage of
      "persistent-before-spawn" -> modifyIORef' spawnCalls (+1)
      "qa-held-borrow-gate-blocked" -> void (tryPutMVar gateBlocked ())
      "persistent-unborrowed-raw-aborted" -> case mode of
       StopAfterRaw -> putMVar rawAborted () >> readMVar rawContinue
       AbortHookError -> ioError (userError "injected post-raw abort hook failure")
       _ -> pure ()
      _ -> pure ()
     waitStarting = do
      phase <- persistentStatus owner
      if phase == PersistentStarting then pure () else threadDelay 1000 >> waitStarting
     waitIfCreated ref done = do
      tid <- readIORef ref
      case tid of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     cleanup = do
      void (tryPutMVar rawContinue ())
      void (tryPutMVar unlock ())
      waitIfCreated (holderRef probe) (holderDone probe)
      waitIfCreated (ownerThreadRef probe) (ownerDone probe)
      waitIfCreated (killerRef probe) (killerDone probe)
     run = do
      _ <- mask_ $ do
       tid <- forkFinally (restore signalGate) (putMVar (holderDone probe))
       writeIORef (holderRef probe) (Just tid)
       pure tid
      within "actual held gate locked" (readMVar gateEntered)
      start <- startBudgetAfter (case mode of Expiry -> 200000; StopAfterRaw -> 200000; AbortHookError -> 200000; _ -> 3000000) >>= must
      tid <- mask_ $ do
       worker <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop ready (\_ -> pure ()) hook)) (putMVar (ownerDone probe))
       writeIORef (ownerThreadRef probe) (Just worker)
       pure worker
      within "owner entered starting" waitStarting
      within "actual borrow observed held gate busy" (readMVar gateBlocked)
      case mode of
       Expiry -> pure ()
       ExplicitStop -> do
        first <- requestSessionStop owner stop
        second <- requestSessionStop owner stop
        check "first stop latches; second cannot renew" (first == StopLatchedBeforeLive && second == StopAlreadyRequested)
       AbortHookError -> pure ()
       StopAfterRaw -> do
        within "raw abort receipt before phase decision" (readMVar rawAborted)
        first <- requestSessionStop owner stop
        second <- requestSessionStop owner stop
        check "post-raw stop latches once" (first == StopLatchedBeforeLive && second == StopAlreadyRequested)
        void (tryPutMVar rawContinue ())
       AsyncCancel -> do
        _ <- mask_ $ do
         worker <- forkFinally (killThread tid) (putMVar (killerDone probe))
         writeIORef (killerRef probe) (Just worker)
         pure worker
        pure ()
      -- Gate remains held until owner completes or watchdog fails. This controls
      -- ordering, not hard scheduling: timeout never counts as owner completion.
      result <- within "owner returns while gate held" (readMVar (ownerDone probe))
      count <- readIORef spawnCalls
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      let expectedClean expected =
           phase == PersistentRetired && raw == Available &&
           case result of Right (Left (StartupRefused problem)) -> problem == expected; _ -> False
          expectedUnknown =
           (case raw of Quarantined _ -> True; _ -> False) &&
           (case phase of PersistentQuarantined _ -> True; _ -> False) &&
           case result of Left _ -> True; Right (Left (ExitUncertain _ _)) -> True; _ -> False
          expected = case mode of
           Expiry -> expectedClean TimedOut
           ExplicitStop -> expectedClean SessionClosed
           StopAfterRaw -> expectedClean SessionClosed
           AbortHookError -> expectedClean SpawnOrIO
           AsyncCancel -> expectedUnknown
      check "no spawn and exact checked-abort or uncertain result" (count == 0 && expected)
 restore run `finally` cleanup
