# Engine PID1 / Broker / Entrypoint & Omarchy Guest Review (Corrected Against `94327` Local `1s` Callbacks)

- **Reviewer**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Run**: `warlock-20261031-setup`
- **Status**: Preparation review only — not an implementation, native window, ARC-024/DEL-014, or acceptance claim (`nativeOperations: []`, `15/242` whole requirements, `39/417` scenarios preserved; VM currently locked with `Foot 2095` present and no app GUI launched).
- **Companion Non-GUI Probe Diagnostic Plan**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/engine-heldexec-kernelprobe-diagnostics.md`
- **Reviewed Actual Workspace Preimages (`94327` 10-Suite Profile)**:
  - `implementation/warlock/haskell/runtime/ui/Main.hs` (`sha256: 5df812de63c32881bf50b5e2109e06c6259192b0f9188a0f84a22efc1d7209b0`)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc` (`sha256: 5028eed1eae2df6f066d3868777af686aa0ddb889a651159b26cb3369c4129de`)
  - `implementation/warlock/haskell/runtime/src/Warlock/Ui/EngineBroker.hs` (`sha256: 63cebd1a5ec38b7faa6b713dacec64f62b1e15e5cda8dbc1284dd757e6d29a04`)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineEntrypoint.hs` (`sha256: 941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080`)
  - `implementation/warlock/haskell/runtime/test-ui-engine-exec/Main.hs` (`sha256: 7a5c90aec72f862a06afee78fe9d16399c2f561efe555e05f7ef7f6ddc3998b0`)
  - `implementation/warlock/haskell/runtime/runtime.cabal` (`sha256: 073a742be6ca04bde4f8744860cfb23c06802374d50e7b65b7fe9a1b8306a86d`)

---

## 1. Correction of Prior `500ms` Cutoff Claim Against Actual `EngineEntrypoint.hs:319-331` Local `1s` Callbacks

### Superseded Claim Retracted
- The earlier claim that `EngineBroker.withinOriginalDeadline` (`left > 500_000`, `EngineBroker.hs:176`) makes `WebKit.hs:462` graceful loop exit (`remaining <= 500_000`) and `retireInOrder` (`> 250_000`) unreachable over RPC is **retracted for current `EngineEntrypoint.hs` (`941d7769...`)**.

### Verified Current Source Behavior (`EngineEntrypoint.hs:319-331`)
1. `runEngineOnly` wraps `remote = Adapter.clientEndpoints startup rpcCall` with local monotonic observations of the **same immutable `originalD`**:
   - `localStop` (`L323-325`): when `remainingMicros deadline <= 1_000_000` (`1.0s` before `D`), returns `pure True` locally with **zero `GetStop` RPC**.
   - `localRemaining` (`L326-329`): when `remainingMicros deadline <= 1_000_000`, returns `pure left` locally with **zero `GetRemaining` RPC** (and above `1.0s` takes `min left <$> uiRemainingMicros remote`).
2. Consequently:
   - `WebKit.hs:458-462` (`loop mvp`) observes `stopped == True` locally at `D - 1.0s` — **`500ms` ahead** of `EngineBroker.withinOriginalDeadline`'s `D - 500ms` reserve (`EngineBroker.hs:176`) — and stops calling `stepMvpWindow` (`GetLastProjection` / `OwnerEvent`).
   - `WebKit.hs:405, 480` (`retireInOrder (uiRemainingMicros endpoints) actions`) and `Mvp.hsc:1146-1156` (`retireMvpWindow`) execute purely against `localRemaining` down to `250_000` with **zero RPC traffic**.

### Remaining Accurate Source/Runtime Boundaries (Not Pre-Run Blockers)
1. **Unverified synchronous C/FFI duration**: No fixed margin (`1.0s` vs `500ms`) proves hard real-time completion of synchronous GTK/WebKit C calls (`gtk_init_check`, `storeSave`, `contextIteration`, GObject unref) if a call stalls across `D - 500ms`; actual retirement duration must be observed under `D`.
2. **Broker `EndOfStream` classification (`EngineBroker.hs:147, 163` + `ui/Main.hs:68-72`)**: When the Engine closes its socket cleanly at `EngineEntrypoint.hs:333` after `runWebKit` finishes (`D - 1.0s .. D - 0.5s`), `readFrame` (`L163`) maps `0`-byte header `Transport.EndOfStream` to `"engine frame EOF"` -> `Broker.Indeterminate`, which `ui/Main.hs:71` (`_ -> pure ()`) accepts identically to an early engine disconnect; `stopEngineProcess` (`ui/Main.hs:49-50`) still enforces owned `pidfd` reap before `D - 200ms`.
3. **Intentional `EngineResult False False` (`WebKit.hs:491-498` + `ui/Main.hs:100-102`)**: `runWebKit` retains 3 filter-store `backings` (`L424`) and passes `custody = Nothing` (`L367`), returning `EngineResult False False` so `--engine-only` exits `1` (`ui/Main.hs:102`), preserving withheld whole-engine qualification.

---

## 2. Testable Hypotheses (NOT External Blockers Until Actually Observed on Guest)

1. **Pre-`main` `stdio` (`fd 0..2`) across `execveat` (`EngineCustody.hsc:592-606` + `EngineEntrypoint.hs:111, 145` + `test-ui-engine-exec/Main.hs:127-128`)**:
   - **Status**: **Hypothesis, not an external blocker**. `childSetupExec` closes `0..2` across `execveat` via `CLOSE_RANGE_CLOEXEC`, and `test-ui-engine-exec/Main.hs:127-128` (`closed <- mapM fdAbsent [0,1,2]`) directly tests whether dynamic-library `DT_INIT_ARRAY` constructors or GHC `9.6.7` `hs_init_ghc` (`-with-rtsopts=-V0`) open any descriptor in `0..2` before `Main.main` on the guest.
   - **Invariant**: Preserve `requireClosedStdio` and never `dup2` over `fd 0` in `childSetupExec` before `execveat` (protecting Broker's managed `Native` `fd 0` and copied-heap descriptor numbering). Remediate post-`execveat` **only if** Root's actual held-exec probe observes `fdAbsent [0,1,2] == False`.
2. **`execveat(..., "", ..., AT_EMPTY_PATH)` `$ORIGIN` / `DT_RUNPATH` on dynamic guest build (`EngineCustody.hsc:606`)**:
   - **Status**: **Hypothesis, not an external blocker**. Linux sets `AT_EXECFN = "/dev/fd/<image>"` for `AT_EMPTY_PATH`, which affects `ld.so` **only if** a `DT_RUNPATH`/`DT_RPATH` entry actually uses `$ORIGIN` (standard Cabal dynamic builds embed absolute store/build paths). Verify `readelf -d` / actual guest `ui-engine-exec-controls` execution before treating as a defect.

---

## 3. Source-Confirmed Optimization & Hygiene Notes (For Future GUI Trial Readiness)

1. **Steady-state `1,000 Hz` `GetLastProjection` polling (`WebKit.hs:466, 469` + `Mvp.hsc:968`)**:
   - Above `D - 1.0s`, `stepMvpWindow` (`Mvp.hsc:968`) evaluates `mLease <- readLease` (`GetLastProjection` RPC) every `1ms` even when `closeFlag == False`, `escapeFlag == False`, and window size is unchanged (`~3,000` RPCs/sec across `GetStop`, `GetRemaining`, `GetLastProjection` on the non-threaded Broker). Deferring `readLease` to branches that inspect `mLease` (or relaxing steady-state `threadDelay 1000`) is a clean surgical optimization if Broker CPU contention appears in later GUI runs.
2. **`engineEnvironment` empty-list intentionality (`EngineCustody.hsc:740-748` vs `ui/Main.hs:85`)**:
   - Keep `engineEnvironment []` valid in `EngineCustody.hsc`: non-GUI `test-ui-engine-exec/Main.hs:250, 315` intentionally passes `[]` to `startUnreadyEngine`, while GUI Broker `ui/Main.hs:85` already enforces `require (not (null display)) "engine Wayland transport unavailable"`.
3. **Guest `/tmp` filter directories & Hyprland/WebKit census (future GUI phase only)**:
   - In GUI runs, `WebKit.hs:422` (`mkdtemp "/tmp/warlock-filter-XXXXXX"`) creates 3 retained directories in `/tmp` unless `/tmp` is mounted as bounded private `tmpfs` in `childSetupExec`; Hyprland `hyprctl clients -j` reports guest root-PIDns `enginePid` (not `1`) with `class: "GTK Application"`.
