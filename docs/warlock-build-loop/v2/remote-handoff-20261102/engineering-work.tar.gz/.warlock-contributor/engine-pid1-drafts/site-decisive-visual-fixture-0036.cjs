#!/usr/bin/env node
/**
 * Decisive Visual & Unavailable-Operation Fixture Proposal (0036)
 *
 * Scope: Root-only isolated qualification proposal (worker executes ZERO Node,
 * Elm, Playwright, or VM processes).
 *
 * Covers two source-bound visual contracts:
 *   Part A — Website CSS-Free Elm & 4-Step Beta Walkthrough (`SiteMain.elm` + `landing.css`):
 *     1. Zero `<style>` tags and zero `[style]` attributes inside `.wl-home-root`
 *        (`CSS owns presentation; Elm owns interaction policy`).
 *     2. External `landing.css` computed styles apply across `night`, `dawn`, and
 *        `high-contrast`, with `documentElement.scrollWidth <= innerWidth` at
 *        `320px`, `768px`, and `1440px`.
 *     3. Interactive 4-step `#beta-walkthrough` (`role="tablist"`) steps cleanly
 *        via click and keyboard (`ArrowRight`, `End`, `Home`; IME `229` ignored),
 *        rendering solid `.is-enabled` vs dashed `.is-unavailable` control items.
 *     4. WCAG 2.2 AA contrast (>= 4.5:1 text, >= 3.0:1 UI borders) and >= 24x24 CSS px
 *        interactive target boxes.
 *
 *   Part B — Current MVP `--application-only` Visual & Unavailable-Operation Oracle
 *            (bound to `typed-model-live-20261102` 1280x800 &
 *             `backend-private-diagnostics-20261102` 621x750 captures):
 *     1. Exact enabled vs disabled control inventory on `Foot` positive match:
 *        - Enabled (`disabled=false`, `aria-disabled="false"`, solid border):
 *          `bar:applications`, `control:search`, `control:close`, `control:refresh`,
 *          `pin:foot.desktop`.
 *        - Disabled (`disabled=true`, `aria-disabled="true"`, dashed border):
 *          6 bar utilities (`bar:overview`, `bar:switcher`, `bar:notifications`,
 *          `bar:files`, `bar:system`, `bar:settings`) + 4 popup launch/action
 *          controls (`jump:open:foot.desktop`, `entry:foot.desktop`,
 *          `entry:foot-server.desktop`, `entry:footclient.desktop`).
 *     2. Fullscreen `1280x800` vs 50/50 Tiled `621x750` `.surface-bar` geometry:
 *        - At `1280x800`: `.surface-actions` fits all 7 bar controls (`scrollWidth <= clientWidth`).
 *        - At `621x750`: `.surface-bar [role="status"]` remains unoccluded (`width >= 180`),
 *          while `.surface-actions` overflows horizontally (`scrollWidth > clientWidth`,
 *          `overflowX === "auto"`); records exact in-frame vs scrolled-out disabled
 *          controls without claiming pointer/AT scroll acceptance.
 *     3. Negative `footz` + `Refresh` retention (`query === "footz"`, 0 `entry:*` rows,
 *        status `"No matching applications. Change your search or Refresh."`).
 *     4. Decisive Copy-vs-Unavailable-Control Check (`--strict-app-only-status`):
 *        Fails RED if `[role="status"]` says `"Choose a matching application."` when
 *        every `entry:*` control is `disabled` (`Surface.elm:483`), and passes GREEN
 *        when status honestly reports that opening is unavailable in this session.
 *
 * Non-claims: Browser/DOM visual fixture checks never establish native Wayland/Hyprland,
 * physical OS IME, assistive-technology, pointer-scroll, or release acceptance.
 */

'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

function parseRgb(raw) {
  const m = String(raw || '').match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,/\s]+([\d.]+))?\s*\)/i);
  if (!m) return null;
  return { r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: m[4] === undefined ? 1 : Number(m[4]) };
}

function relLum(rgb) {
  const ch = (v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * ch(rgb.r) + 0.7152 * ch(rgb.g) + 0.0722 * ch(rgb.b);
}

function contrastRatio(fg, bg) {
  const l1 = relLum(fg);
  const l2 = relLum(bg);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2'
};

function startStaticServer(rootDir) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const reqUrl = new URL(req.url || '/', 'http://127.0.0.1');
      let rel = decodeURIComponent(reqUrl.pathname).replace(/^\/+/, '');
      if (!rel || rel.endsWith('/')) rel += 'index.html';
      const target = path.resolve(rootDir, rel);
      if (!target.startsWith(path.resolve(rootDir) + path.sep) && target !== path.resolve(rootDir)) {
        res.writeHead(403).end('Forbidden');
        return;
      }
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
        res.writeHead(404).end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream' });
      fs.createReadStream(target).pipe(res);
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port });
    });
  });
}

async function verifySiteCssFreeAndWalkthrough(browser, siteRoot) {
  const { server, port } = await startStaticServer(siteRoot);
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });

  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load', timeout: 20000 });
    await page.locator('#beta-walkthrough').waitFor({ state: 'visible', timeout: 10000 });

    const cssFreeAudit = await page.evaluate(() => {
      const root = document.querySelector('.wl-home-root');
      if (!root) return { missingRoot: true };
      const inlineStyles = root.querySelectorAll('style').length;
      const styleAttrs = root.querySelectorAll('[style]').length;
      const rootHasStyleAttr = root.hasAttribute('style');
      return {
        missingRoot: false,
        inlineStyles,
        styleAttrs: styleAttrs + (rootHasStyleAttr ? 1 : 0)
      };
    });
    record(
      'siteMainIs100PercentCssFreeInDom',
      !cssFreeAudit.missingRoot && cssFreeAudit.inlineStyles === 0 && cssFreeAudit.styleAttrs === 0,
      JSON.stringify(cssFreeAudit)
    );

    // Verify 4-step walkthrough keyboard + click transitions and solid vs dashed control styling
    const tab1 = page.locator('#wl-walk-tab-simulated-stage');
    await tab1.focus();
    await tab1.evaluate((el) =>
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true, isComposing: true, keyCode: 229 }))
    );
    record('walkthroughIgnoresIme229', (await tab1.getAttribute('aria-selected')) === 'true');

    await page.keyboard.press('ArrowRight');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-walk-tab-live-positive-foot' && document.activeElement.getAttribute('aria-selected') === 'true',
      { timeout: 5000 }
    );
    const step2Styles = await page.evaluate(() => {
      const enabledItem = document.querySelector('#wl-walkthrough-enabled .wl-home-control-item.is-enabled');
      const unavailItem = document.querySelector('#wl-walkthrough-unavailable .wl-home-control-item.is-unavailable');
      const panelText = document.getElementById('wl-walkthrough-panel')?.innerText || '';
      return {
        enabledBorder: enabledItem ? getComputedStyle(enabledItem).borderTopStyle : 'missing',
        unavailBorder: unavailItem ? getComputedStyle(unavailItem).borderTopStyle : 'missing',
        mentionsSixBarOps: ['bar:overview', 'bar:switcher', 'bar:notifications', 'bar:files', 'bar:system', 'bar:settings'].every((id) => panelText.includes(id)),
        mentionsFourPopupOps: ['jump:open:foot.desktop', 'Open Foot', 'Open Foot Server', 'Open Foot Client'].every((s) => panelText.includes(s))
      };
    });
    record(
      'walkthroughStep2ShowsEnabledSolidVsUnavailableDashedOps',
      step2Styles.enabledBorder === 'solid' &&
        step2Styles.unavailBorder === 'dashed' &&
        step2Styles.mentionsSixBarOps &&
        step2Styles.mentionsFourPopupOps,
      JSON.stringify(step2Styles)
    );

    await page.keyboard.press('End');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-walk-tab-lifecycle-backend-diagnostics' && document.activeElement.getAttribute('aria-selected') === 'true',
      { timeout: 5000 }
    );
    const step4Text = await page.locator('#wl-walkthrough-panel').innerText();
    record(
      'walkthroughStep4ReportsClosedBackendDiagnostics',
      step4Text.includes('selectedOperationSucceeded') && step4Text.includes('exitCode: 1') && step4Text.includes('FileNotFoundError')
    );

    await page.keyboard.press('Home');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-walk-tab-simulated-stage' && document.activeElement.getAttribute('aria-selected') === 'true',
      { timeout: 5000 }
    );

    // Responsive 320 / 768 / 1440 + theme contrast checks
    for (const [label, slug] of [['Night', 'night'], ['Dawn', 'dawn'], ['High contrast', 'high-contrast']]) {
      await page.getByRole('button', { name: label, exact: true }).click();
      const contrastInfo = await page.evaluate(() => {
        const root = document.querySelector('.wl-home-root');
        const heading = document.getElementById('beta-walkthrough-title');
        return {
          theme: root?.getAttribute('data-theme'),
          rootBg: root ? getComputedStyle(root).backgroundColor : '',
          headingFg: heading ? getComputedStyle(heading).color : ''
        };
      });
      const fg = parseRgb(contrastInfo.headingFg);
      const bg = parseRgb(contrastInfo.rootBg);
      const ratio = fg && bg ? contrastRatio(fg, bg) : 0;
      record(`theme_${slug}_ContrastAtLeast4_5`, contrastInfo.theme === slug && ratio >= 4.5, `ratio=${ratio.toFixed(2)}`);
    }
    await page.getByRole('button', { name: 'Night', exact: true }).click();

    for (const width of [320, 768, 1440]) {
      await page.setViewportSize({ width, height: 800 });
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
      record(`noHorizontalOverflowAt_${width}px`, !overflow);
    }

    await context.close();
  } finally {
    await new Promise((r) => server.close(r));
  }
  return checks;
}

function buildAppOnlySnapshot({ publication, query, positive, statusText }) {
  const barControls = [
    ['bar:applications', 'Applications', true],
    ['bar:overview', 'Task View', false],
    ['bar:switcher', 'Switch windows', false],
    ['bar:notifications', 'Notifications', false],
    ['bar:files', 'Files', false],
    ['bar:system', 'System', false],
    ['bar:settings', 'Settings', false]
  ].map(([identity, label, enabled]) => ({
    id: identity,
    domId: identity,
    label,
    detail: '',
    ariaLabel: label,
    enabled,
    focusOnly: false,
    checked: null
  }));

  const popupControls = [
    {
      id: 'control:search',
      domId: 'control:search',
      label: query,
      detail: '',
      ariaLabel: 'Search applications',
      enabled: true,
      focusOnly: false,
      checked: null
    },
    {
      id: 'control:close',
      domId: 'control:close',
      label: 'Windows',
      detail: '',
      ariaLabel: 'Windows',
      enabled: true,
      focusOnly: false,
      checked: null
    },
    {
      id: 'control:refresh',
      domId: 'control:refresh',
      label: 'Refresh',
      detail: '',
      ariaLabel: 'Refresh',
      enabled: true,
      focusOnly: false,
      checked: null
    }
  ];

  if (positive) {
    popupControls.push(
      {
        id: 'jump:open:foot.desktop',
        domId: 'jump:open:foot.desktop',
        label: 'Actions for Foot',
        detail: 'Application actions and recent files',
        ariaLabel: 'Actions for Foot',
        enabled: false,
        focusOnly: false,
        checked: null
      },
      {
        id: 'pin:foot.desktop',
        domId: 'pin:foot.desktop',
        label: 'Pin Foot',
        detail: 'Add to taskbar',
        ariaLabel: 'Pin Foot',
        enabled: true,
        focusOnly: false,
        checked: null
      },
      {
        id: 'entry:foot.desktop',
        domId: 'entry:foot.desktop',
        label: 'Open Foot',
        detail: '',
        ariaLabel: 'Open Foot',
        enabled: false,
        focusOnly: false,
        checked: null
      },
      {
        id: 'entry:foot-server.desktop',
        domId: 'entry:foot-server.desktop',
        label: 'Open Foot Server',
        detail: '',
        ariaLabel: 'Open Foot Server',
        enabled: false,
        focusOnly: false,
        checked: null
      },
      {
        id: 'entry:footclient.desktop',
        domId: 'entry:footclient.desktop',
        label: 'Open Foot Client',
        detail: '',
        ariaLabel: 'Open Foot Client',
        enabled: false,
        focusOnly: false,
        checked: null
      }
    );
  }

  return {
    surfaceProtocol: 2,
    publication: String(publication),
    lease: '1',
    mode: 'applications',
    status: statusText,
    motion: 'standard',
    appearance: {
      theme: 'night',
      textScale: 100,
      effectsOff: false,
      reducedTransparency: false
    },
    bar: barControls,
    popup: popupControls
  };
}

async function verifyMvpAppOnlyVisualContract(browser, compiledStageDir, strictStatusOracle) {
  // Expects an isolated Root-staged HTTP surface directory containing compiled bar.js + popup.js
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });
  if (!compiledStageDir || !fs.existsSync(compiledStageDir)) {
    record('mvpStageProvided', false, 'Pass --mvp-stage <isolated-http-stage-dir> under Root custody to run Part B');
    return checks;
  }

  const positiveSnap = buildAppOnlySnapshot({
    publication: 2,
    query: 'foot',
    positive: true,
    statusText: 'Choose a matching application.'
  });
  const negativeSnap = buildAppOnlySnapshot({
    publication: 3,
    query: 'footz',
    positive: false,
    statusText: 'No matching applications. Change your search or Refresh.'
  });

  let activeSnapshot = positiveSnap;
  const server = http.createServer((req, res) => {
    const u = new URL(req.url || '/', 'http://127.0.0.1');
    if (u.pathname === '/events') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify([{ topic: 'presentation', payload: activeSnapshot }]));
      return;
    }
    let rel = u.pathname.replace(/^\/+/, '') || 'index.html';
    const target = path.resolve(compiledStageDir, rel);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      res.writeHead(404).end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream' });
    fs.createReadStream(target).pipe(res);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;

  try {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load', timeout: 15000 });
    await page.locator('[data-surface-control="bar:applications"]').waitFor({ state: 'visible', timeout: 10000 });

    const audit1280 = await page.evaluate(() => {
      const enabledIds = ['bar:applications', 'control:close', 'control:refresh', 'pin:foot.desktop'];
      const disabledIds = [
        'bar:overview', 'bar:switcher', 'bar:notifications', 'bar:files', 'bar:system', 'bar:settings',
        'jump:open:foot.desktop', 'entry:foot.desktop', 'entry:foot-server.desktop', 'entry:footclient.desktop'
      ];
      const checkBtn = (id) => {
        const el = document.querySelector(`[data-surface-control="${id}"]`);
        if (!el) return { id, missing: true };
        return {
          id,
          disabled: el.disabled,
          ariaDisabled: el.getAttribute('aria-disabled'),
          borderStyle: getComputedStyle(el).borderTopStyle
        };
      };
      const actions = document.querySelector('.surface-actions');
      const popupStatus = document.querySelector('.surface-popup [role="status"]')?.textContent?.trim() || '';
      const allEntriesDisabled = ['entry:foot.desktop', 'entry:foot-server.desktop', 'entry:footclient.desktop'].every(
        (id) => document.querySelector(`[data-surface-control="${id}"]`)?.disabled === true
      );
      return {
        enabled: enabledIds.map(checkBtn),
        disabled: disabledIds.map(checkBtn),
        barFitsAt1280: actions ? actions.scrollWidth <= actions.clientWidth : false,
        popupStatus,
        allEntriesDisabled
      };
    });

    record(
      'positiveFootExactEnabledControlsSolid',
      audit1280.enabled.every((c) => !c.missing && c.disabled === false && c.ariaDisabled === 'false' && c.borderStyle === 'solid'),
      JSON.stringify(audit1280.enabled)
    );
    record(
      'positiveFootExactTenUnavailableControlsDashed',
      audit1280.disabled.every((c) => !c.missing && c.disabled === true && c.ariaDisabled === 'true' && c.borderStyle === 'dashed'),
      JSON.stringify(audit1280.disabled)
    );
    record('fullscreen1280FitsAllSevenBarControls', audit1280.barFitsAt1280);

    if (strictStatusOracle) {
      record(
        'appOnlyPositiveMatchStatusDoesNotInstructDisabledLaunch',
        !(audit1280.allEntriesDisabled && audit1280.popupStatus === 'Choose a matching application.'),
        `popupStatus=${JSON.stringify(audit1280.popupStatus)}`
      );
    }

    // Now resize to 621x750 (exact backend-private-diagnostics-20261102 50/50 tiled geometry)
    await page.setViewportSize({ width: 621, height: 750 });
    const audit621 = await page.evaluate(() => {
      const actions = document.querySelector('.surface-actions');
      const barStatus = document.querySelector('.surface-bar [role="status"]');
      const statusRect = barStatus ? barStatus.getBoundingClientRect() : null;
      return {
        overflowX: actions ? getComputedStyle(actions).overflowX : '',
        scrollsAt621: actions ? actions.scrollWidth > actions.clientWidth : false,
        statusWidth: statusRect ? statusRect.width : 0
      };
    });
    record(
      'tiled621PreservesStatusBoxAndUsesOverflowAutoOnToolbar',
      audit621.overflowX === 'auto' && audit621.scrollsAt621 && audit621.statusWidth >= 180,
      JSON.stringify(audit621)
    );

    // Negative footz snapshot check
    activeSnapshot = negativeSnap;
    await page.reload({ waitUntil: 'load' });
    await page.locator('[data-surface-field="control:search"]').waitFor({ state: 'visible', timeout: 10000 });
    const negAudit = await page.evaluate(() => ({
      query: document.querySelector('[data-surface-field="control:search"]')?.value,
      entryCount: document.querySelectorAll('[data-surface-control^="entry:"]').length,
      status: document.querySelector('.surface-popup [role="status"]')?.textContent?.trim()
    }));
    record(
      'negativeFootzRetainsQueryAndClearsEntries',
      negAudit.query === 'footz' && negAudit.entryCount === 0 && negAudit.status === 'No matching applications. Change your search or Refresh.',
      JSON.stringify(negAudit)
    );

    await context.close();
  } finally {
    await new Promise((r) => server.close(r));
  }
  return checks;
}

async function main() {
  const args = process.argv.slice(2);
  const siteIdx = args.indexOf('--site-root');
  const mvpIdx = args.indexOf('--mvp-stage');
  const strictStatus = args.includes('--strict-app-only-status');
  const siteRoot = siteIdx >= 0 ? path.resolve(args[siteIdx + 1]) : path.resolve(process.cwd(), 'site');
  const mvpStage = mvpIdx >= 0 ? path.resolve(args[mvpIdx + 1]) : '';

  const { chromium } = require('playwright');
  const browser = await chromium.launch({ headless: true });
  try {
    const siteChecks = await verifySiteCssFreeAndWalkthrough(browser, siteRoot);
    const mvpChecks = mvpStage ? await verifyMvpAppOnlyVisualContract(browser, mvpStage, strictStatus) : [];
    const allChecks = [...siteChecks, ...mvpChecks];
    const passed = allChecks.every((c) => c.ok);
    const out = {
      schema: 1,
      fixture: 'site-decisive-visual-fixture-0036',
      passed,
      nativeAccepted: false,
      releaseAccepted: false,
      checkCount: allChecks.length,
      checks: allChecks
    };
    process.stdout.write(JSON.stringify(out, null, 2) + '\n');
    process.exit(passed ? 0 : 1);
  } finally {
    await browser.close();
  }
}

if (require.main === module) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}

module.exports = { buildAppOnlySnapshot, verifySiteCssFreeAndWalkthrough, verifyMvpAppOnlyVisualContract };
