{-# LANGUAGE OverloadedStrings #-}
-- QA-only, unexecuted helper for a separately hashed Owner source copy with
-- terra-q-origin-owner-queue-observer.patch. One fresh owner per invocation.
-- The real harness must independently guarantee no HTTP GET/dequeue and no
-- concurrent owner/native issuer between these snapshots, retain its original
-- deadline, and record the eventual UiResult/cleanup independently. This
-- helper cannot prove those assumptions merely by reading queue lengths.
module OwnKeyOwnerQueueProbe (Probe(..), probeMalformedFresh) where

import Data.Text (Text)
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.Owner as Owner
import Warlock.Ui.Policy (Role(..))

data Probe = Probe
  { wasLive :: Bool
  , beforeQueue :: [(Role, Int)]
  , refusal :: Either Text ()
  , afterQueue :: [(Role, Int)]
  , stopsAfterRefusal :: Bool
  , observedExpectedBoundary :: Bool
  } deriving (Eq, Show)

-- `queueSnapshot` is the immutable locked reader published by the QA-copy
-- entrypoint. `payload` is one literal from invalidTopologies in
-- OwnKeyApprovedBoundary. This intentionally injects the real Owner callback
-- directly, as defense in depth: actual EngineAdapter rejects malformed source
-- events *earlier* before RPC. It is not a claim about that adapter's result.
probeMalformedFresh :: Owner.UiEndpoints -> IO [(Role,Int)]
  -> (Owner.TrustedOwnerEvent -> IO (Either Text ())) -> J.Json -> IO Probe
probeMalformedFresh endpoints queueSnapshot emit payload = do
  live <- not <$> Owner.uiShouldStop endpoints
  before <- queueSnapshot
  result <- emit (Owner.OwnerTopology payload)
  after <- queueSnapshot
  stopped <- Owner.uiShouldStop endpoints
  let correct = live && lookup Controller before == Just 0
        && result == Left "UnexpectedFields" && after == before && stopped
  pure (Probe live before result after stopped correct)
