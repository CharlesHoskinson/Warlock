{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
-- PREPARATION DRAFT ONLY: not compiled or run. This drives the integrated
-- broker over a real Unix socketpair and kernel SCM credentials. Its same-
-- process PID/UID/GID guard is a component fixture, not a held-pidfd, owned
-- child, production custody, namespace, GUI or original-acceptance proof.
-- The protected runner owns all execution and cleanup.
module Main (main) where

import Control.Concurrent (forkFinally, newEmptyMVar, putMVar, takeMVar, tryPutMVar)
import Control.Exception (SomeException, finally, onException)
import Control.Monad (unless, void)
import Data.IORef (IORef, modifyIORef', newIORef, readIORef, writeIORef)
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import qualified Data.Text as T
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Posix.Process (getProcessID)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (deadlineAfter, deadlineAbsoluteNs)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import Warlock.Protocol.Identity (parseCounter)
import qualified Warlock.Protocol.PeerCredential as Cred
import qualified Warlock.Protocol.EngineTransport as Wire
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.EngineProtocol as P
import qualified Warlock.Ui.EngineBroker as Broker
import qualified Warlock.Ui.Owner as Owner

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
bounded :: String -> IO a -> IO a
bounded label action = do
 value <- timeout 5000000 action
 maybe (ioError (userError (label ++ " timeout"))) pure value

recvExact :: S.Socket -> Int -> IO B.ByteString
recvExact sock n = go n [] where
 go 0 parts = pure (B.concat (reverse parts))
 go left parts = do
  bytes <- N.recv sock left
  check "unexpected peer EOF" (not (B.null bytes))
  go (left - B.length bytes) (bytes:parts)

recvFrame :: S.Socket -> (B.ByteString -> Either e Int) -> IO B.ByteString
recvFrame peer decodeLength = bounded "frame read" $ do
 header <- recvExact peer 4
 n <- either (const (ioError (userError "bad response frame"))) pure (decodeLength header)
 recvExact peer n

-- Component-only guard verifies the credentials the kernel actually delivered
-- against this test process. It cannot certify selected image, child identity,
-- held pidfd, reaper ownership or ancestry; production guard controls are
-- separate and must use a real owned child.
selfGuard :: Integer -> Integer -> Integer -> CredentialGuard String
selfGuard pid uid gid = CredentialGuard accept admit where
 accept peer = pure $ if Cred.credentialPid peer == pid && Cred.credentialUid peer == uid && Cred.credentialGid peer == gid
   then Right () else Left "unexpected test peer"
 admit peer action = do
  valid <- accept peer
  case valid of Left reason -> pure (Left reason); Right () -> Right <$> action

data Fixture = Fixture
 { fixtureBroker :: Broker.Broker String, fixturePeer :: S.Socket
 , fixtureStartup :: P.Startup, fixtureTrace :: IORef [String]
 , fixtureProjection :: IORef (Maybe J.Json)
 , fixtureEntered :: IO (), fixtureRelease :: IO ()
 }

-- Every fixture owns fresh test resources and a single test deadline. This
-- never changes or renews the application's original admission deadline.
withFixture :: (Fixture -> IO ()) -> IO ()
withFixture action = do
 pid <- toInteger <$> getProcessID
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 deadline <- deadlineAfter 20000000 >>= need
 sid <- need (P.sessionId "91")
 startup <- need (P.startup 12001 12002 12003 (T.pack (deadlineAbsoluteNs deadline)) sid)
 let (controller,bar,popup) = P.startupOrigins startup
 trace <- newIORef []
 projectionCell <- newIORef (Just (J.JObject [("frame",J.JObject [("publication",J.JString "11"),("lease",J.JString "10")])]))
 entered <- newEmptyMVar
 release <- newEmptyMVar
 let record label work = modifyIORef' trace (++ [label]) >> work
     endpoints = Owner.UiEndpoints controller bar popup
       (record "stop" (putMVar entered () >> takeMVar release >> pure False))
       (record "remaining" (pure 4321))
       (record "projection" (readIORef projectionCell))
     owner event = case event of
       Owner.OwnerTopology _ -> record "topology" (pure (Right ()))
       Owner.OwnerDismiss _ -> record "dismiss" (pure (Right ()))
       Owner.OwnerEscape _ -> record "escape" (pure (Left "stale native UI projection"))
       Owner.OwnerReflow _ -> record "reflow" (pure (Right ()))
 (brokerSocket,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 -- Broker enables SO_PASSCRED before the test sends any bytes.
 prepared <- Broker.prepareBroker brokerSocket deadline startup endpoints owner `onException` S.close peer
 broker <- Broker.attachBroker prepared (selfGuard pid uid gid) `onException` (void (Broker.closePrepared prepared) >> S.close peer)
 let cleanup = void (tryPutMVar release ()) >> void (Broker.closeBroker broker) >> S.close peer
     fixture = Fixture broker peer startup trace projectionCell (bounded "stop callback entry" (takeMVar entered)) (void (tryPutMVar release ()))
 action fixture `finally` cleanup

handshake :: Fixture -> IO ()
handshake fixture = do
 let broker = fixtureBroker fixture; peer = fixturePeer fixture; initial = fixtureStartup fixture
 before <- Broker.serveBrokerOnce broker
 check "broker refuses request handling before startup" (before == Broker.NotReady)
 let ready = "{\"engineReady\":1,\"deadline\":\"" <> C.pack (T.unpack (P.startupDeadline initial)) <> "\",\"incarnation\":\"91\"}"
 N.sendAll peer =<< need (Wire.startupPrefix ready)
 result <- bounded "startup" (Broker.completeStartup broker)
 check "startup written locally" (result == Broker.StartupWrittenLocally)
 bytes <- recvFrame peer Wire.startupHeaderLength
 check "startup preserves origins, deadline and incarnation" (P.decodeStartup bytes == Right initial)

sendRequest :: Fixture -> P.Session -> P.Request -> IO P.Session
sendRequest fixture client request = do
 let (pending,encoded) = P.beginRequest client request
 raw <- need encoded
 N.sendAll (fixturePeer fixture) =<< need (Wire.enginePrefix raw)
 pure pending

receiveReply :: Fixture -> P.Session -> P.Reply -> IO P.Session
receiveReply fixture pending expected = do
 bytes <- recvFrame (fixturePeer fixture) Wire.engineHeaderLength
 let (next,result) = P.acceptReply pending bytes
 check ("typed reply " ++ show expected) (result == Right expected && not (P.isPoisoned next))
 pure next

runMethod :: Fixture -> P.Session -> P.Request -> P.Reply -> IO P.Session
runMethod fixture state request reply = do
 pending <- sendRequest fixture state request
 actual <- bounded "broker request" (Broker.serveBrokerOnce (fixtureBroker fixture))
 check "broker local reply" (actual == Broker.ReplyWrittenLocally)
 receiveReply fixture pending reply

main :: IO ()
main = do
 withFixture $ \fixture -> do
  handshake fixture
  let broker = fixtureBroker fixture
  pending <- sendRequest fixture (P.newSession (fixtureStartup fixture)) P.GetStop
  done <- newEmptyMVar
  -- The callback yields on an MVar. A second broker admission must return
  -- Busy while the first is inside the real adapter callback, before release.
  _ <- forkFinally (Broker.serveBrokerOnce broker) (putMVar done)
  (do fixtureEntered fixture
      concurrent <- Broker.serveBrokerOnce broker
      check "concurrent admission returns Busy" (concurrent == Broker.Busy)
      fixtureRelease fixture
      worker <- bounded "first broker admission" (takeMVar done)
      case worker of Right result -> check "first callback replied" (result == Broker.ReplyWrittenLocally)
                     Left problem -> ioError (userError ("broker worker failed: " ++ show (problem :: SomeException)))
   ) `finally` fixtureRelease fixture
  c1 <- receiveReply fixture pending (P.StopReply False)
  c2 <- runMethod fixture c1 P.GetRemaining (P.RemainingReply 4321)
  old <- readIORef (fixtureProjection fixture)
  projectedOld <- traverse (need . P.projection) old
  c3 <- runMethod fixture c2 P.GetLastProjection (P.ProjectionReply projectedOld)
  sc <- need (P.scope "7" "8")
  revision <- either (ioError . userError . show) pure (parseCounter False "9")
  lease <- either (ioError . userError . show) pure (parseCounter False "10")
  publication <- either (ioError . userError . show) pure (parseCounter False "11")
  c4 <- runMethod fixture c3 (P.OwnerEvent (P.Topology revision Nothing)) (P.EventReply P.Accepted)
  c5 <- runMethod fixture c4 (P.OwnerEvent (P.Dismiss sc lease)) (P.EventReply P.Accepted)
  let newProjection = J.JObject [("frame",J.JObject [("publication",J.JString "12"),("lease",J.JString "12")])]
  writeIORef (fixtureProjection fixture) (Just newProjection)
  c6 <- runMethod fixture c5 (P.OwnerEvent (P.Escape sc publication lease)) (P.EventReply P.Stale)
  c7 <- runMethod fixture c6 (P.OwnerEvent (P.Reflow sc lease)) (P.EventReply P.Accepted)
  new <- need (P.projection newProjection)
  _ <- runMethod fixture c7 P.GetLastProjection (P.ProjectionReply (Just new))
  trace <- readIORef (fixtureTrace fixture)
  check "exact callback sequence with no overlap duplicate" (trace == ["stop","remaining","projection","topology","dismiss","escape","reflow","projection"])
 -- Fresh authenticated socketpair: a strict malformed request must close the
 -- broker without invoking any owner/read callback. Separate peer coverage owns
 -- foreign credentials, partial frames, EOF and custody behavior.
 withFixture $ \fixture -> do
  handshake fixture
  let invalidHeader = "{\"version\":1,\"direction\":\"request\",\"session\":\"91\",\"request\":\"1\",\"method\":\"stop\",\"extra\":0}"
      len = B.length invalidHeader
      inner = B.pack [fromIntegral (len `div` 16777216), fromIntegral (len `div` 65536), fromIntegral (len `div` 256), fromIntegral len] <> invalidHeader <> "null"
  N.sendAll (fixturePeer fixture) =<< need (Wire.enginePrefix inner)
  result <- bounded "malformed refusal" (Broker.serveBrokerOnce (fixtureBroker fixture))
  trace <- readIORef (fixtureTrace fixture)
  check "malformed closed with no callback" (result == Broker.Indeterminate && null trace)
  closed <- Broker.serveBrokerOnce (fixtureBroker fixture)
  check "malformed cannot replay" (closed == Broker.Closed)
 putStrLn "broker detailed controls: same-process SCM fixture; no custody acceptance"
