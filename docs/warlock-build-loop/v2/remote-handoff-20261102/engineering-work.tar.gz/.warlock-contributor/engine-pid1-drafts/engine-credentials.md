# Engine PID1: credential boundary proposal

Status: preparation draft only. No implementation, model execution, kernel test, native acceptance, or release claim. Preserve the original 242 requirements, 417 scenarios, original deadline D, failed evidence and stop histories. This draft does not alter the public authority or readiness gates.

## Boundary and existing source

The broker remains the sole UI/native owner and keeps its original authenticated Native endpoint, private-network witness, listener(s), and policy authority. PID1/engine is a direct owned child in the new PID namespace, with only its fixed protocol IPC endpoint plus the minimum explicitly reviewed bootstrap/lifeline descriptors. Engine and its helpers receive no Native or listener FD. Pre-fork Unix `socketpair` SO_PEERCRED identifies the creator at connection creation, not the later engine writer: it is not an engine authentication check. No JSON PID, environment value, cookie, asserted UID, socketpair creator, or namespace-local PID manufactures authority.

Public `Warlock.Protocol.PeerCredential` exposes an opaque `PeerCredential` and read-only `credentialPid`, `credentialUid`, `credentialGid`. Public `Warlock.Protocol.CredentialGuard` pairs `checkFragment` with rank-N `withCredentialAdmission`. `Warlock.Protocol.CredentialIngress` publicly owns a socket, enables the existing credential route, and `receiveCredentialIngress` accepts this guard. Internal `Warlock.Transport.PeerCredentials.receiveCredentialChunk` uses SO_PASSCRED/recvmsg, MSG_CMSG_CLOEXEC and its descriptor cleanup/quarantine ledger; malformed, missing or multiple credentials, control truncation, unexpected rights and uncertain closure are refusals. The existing ingress has native/desktop codec profiles; engine events cannot silently be treated as those envelopes. Existing `Warlock.Bootstrap.ScopedPeer` is bound to a resolver Session, UiImage, fd0, owner thread and registration epoch, so is not a PID1 guard. Reuse its synchronous admission discipline, not its constructor or mistaken identities.

Current `EngineCustody` owns direct-child pidfd and lifeline, verifies a child by `waitid(P_PIDFD, WEXITED|WNOHANG|WNOWAIT)`, uses PID1 close_range and PR_SET_PDEATHSIG, and targets only the owned child in cleanup. It does not currently provide the proposed authenticated engine-event transport or held-exec guarantee. One process component must own the lifecycle and be the only reaper; other observers use read-only, non-consuming observation. Resolve integration with existing process-custody rather than introduce a second wait/reaper or arbitrary executor.

## Proposed typed interface (not existing Haskell API)

```haskell
-- All constructors private; no caller-supplied PID, fd, credentials or process.
data EngineCustody       -- sole owner of selected direct child and its pidfd
data EngineIngress      -- scoped broker endpoint and serialized admission
data EngineEventView    -- checked, immutable, bounded event data only
data EngineRefusal      -- closed sum, including uncertainty and D expiry

withOwnedEngineIngress
  :: EngineCustody -> OriginalDeadline
  -> (EngineIngress -> IO a) -> IO (Either EngineRefusal a)

receiveEngineEvent
  :: EngineIngress
  -> (EngineEventView -> IO ())
  -> IO (Either EngineRefusal ())
```

The callback contract is a synchronous read-only notification over a checked immutable view: it receives no socket, FD, credential constructor, process/session constructor, native capability or executor, cannot change custody, and cannot make independent policy grants. Haskell IO does not enforce this restriction by type alone; the actual callback wiring must be narrowly reviewed and confined. Its completion and retirement are tracked; dispatch and callback occur only within a live admission lease, never after retirement begins. Event effects requiring UI/native authority are separately decided by the existing broker policy, not by the engine event or callback. `OriginalDeadline` is the existing absolute D, not a newly extendible timer. API names/types are conceptual: a protocol-owned narrow engine-event facade must wrap the existing internal credential reader and frame machinery; do not expose `Warlock.Transport` private constructors, raw reads or a general spawn/execute interface. Adapt codec deliberately and verify framing, size limits and partial/coalesced stream behavior.

## Kernel identity and descriptor contract

1. Create the socketpair with CLOEXEC, enable SO_PASSCRED on the receiving broker endpoint before any peer bytes can be queued, and retain its owned identity. Parent captures the actual fork result as host PID while child ownership prevents PID reuse; open and retain its pidfd, verify direct-child ownership without consuming status, and check liveness around publication. If any step is uncertain, refuse. Do not accept events until custody, endpoint and credential guard are live.
2. For **each received fragment**, compare the real recvmsg `SCM_CREDENTIALS` PID in the broker's PID namespace with that retained direct-child host PID and compare UID/GID with the independently established mappings/contract. Bind all fragments of one event to the same accepted sender. At final synchronous admission recheck the same owned endpoint, pidfd incarnation, direct-child status, liveness, scope and D; serialize retirement against admission. A valid credential is an observation, not a reusable token. Child exit/reuse, a foreign or mixed sender, incorrect UID/GID, unexpected ancillary data, EOF mid-frame, timeout, invalid frame, ownership loss, or closure uncertainty must refuse without dispatch/replay. Review the Linux capability and user/PID namespace semantics and ensure an engine cannot use credentials-spoofing privilege; don't assume same UID alone suffices.
3. Both socketpair ends are CLOEXEC by default. Exec necessarily closes a descriptor that still has FD_CLOEXEC: a fixed child IPC FD needs a narrowly controlled inheritance step (e.g. audited `dup2` of the intended end immediately before held-image exec), with all other descriptors closed, and early engine startup must restore and verify CLOEXEC before it can fork helpers or start threads. This explicitly bounded exec exception is not a general inherited descriptor exemption. No Native/listener/pidfd for unrelated ownership reaches engine or helper; verify descriptor inventories on actual exec and helper paths. A helper must not retain the IPC writer unless explicitly authorized; otherwise it could transmit or prolong EOF.
4. Execute only the already resolved and held approved engine image through the existing owned executable/launch pathway. Pin image identity through the actual exec, preserve one lifecycle owner/reaper, validate all inherited descriptors and close unknowns; if the existing pathway cannot provide the required held-image exec with this namespace/FD contract, treat it as an integration gap, not permission for a new arbitrary executor or path-based fallback. Any late exec/cleanup uncertainty remains failure.
5. An outside-namespace parent may appear to PID1 as PID 0. Child-side getppid()==0 or a translated PID-0 peer credential is neither evidence of parent liveness nor positive parent authentication. The broker authenticates engine-to-broker messages as above; engine must not claim it has positively authenticated an unrepresentable parent. A parent-death proof must cover parent death before and after `PR_SET_PDEATHSIG`, check and continuously monitor a correctly owned lifeline, exclude escaped duplicate writers across fork/exec, and demonstrate shutdown of the owned PID1 and descendants. PDEATHSIG alone has a registration race; EOF alone may be delayed by an inherited writer. No generic timeout extension or blanket EACCES success.

## Source correspondence and required independent checks

- `protocol/src/Warlock/Protocol/{PeerCredential,CredentialGuard,CredentialIngress}.hs` and `protocol/src/Warlock/Protocol/Ingress/Internal.hs`: public opacity, paired guards and owned ingress; engine codec adaptation remains proposed.
- `protocol/src/Warlock/Transport/PeerCredentials.hsc`: actual ancillary parsing, close-on-receive rights and quarantine; kernel provenance/capability assumptions need root-owned verification.
- `runtime/ui/Warlock/Ui/EngineCustody.hsc`: current direct-child pidfd, one-owner shutdown and PDEATHSIG/lifeline primitives; it is not yet engine exec/credential admission.
- `runtime/formal/ui-engine-lifetime.qnt`: lifetime abstraction. Add separately reviewed model correspondence only under a future model assignment; distinguish fork, credential observation, admission, death and retirement interleavings. Kernel credentials, FD closure, held executable, capability drops, scheduler and process identity are assumptions to validate in real controls, not results proven by model counts.

Root-owned future controls must cover actual child positive; creator SO_PEERCRED mismatch; foreign same-UID writer and foreign UID/GID; PID reuse/death; mixed fragment senders and partial frame; missing/truncated/malformed ancillary and rights/close uncertainty; fd swapping and helper inheritance; death before/after PDEATHSIG registration and escaped lifeline writer; held-image replacement attempt; concurrent retirement/callback drain; and expiry under original D. Test no execution here. Failed/unknown cleanup remains failed/unknown, never a native acceptance or whole-EARS claim.
