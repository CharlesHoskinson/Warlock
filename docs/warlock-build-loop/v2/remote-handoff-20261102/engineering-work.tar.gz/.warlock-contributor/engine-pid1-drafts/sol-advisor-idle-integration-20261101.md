# Sol advisory handoff: desktop idle integration

2026-11-01, bounded turn through 17:29 UTC. Authenticated identity `sol-docs`,
same persistent session `01a1947b-90dd-7ac0-9b96-477ca1e32bc2`.
Root remains sole coordinator, integrator and protected executor. This is a
source/evidence advisory draft, not an approval, test result or acceptance gate.
Exact 120-minute file claim hold: `01M6C14ADCTVS2MPNRQER351R6`.

## Concrete recommendation to root

Finish the small idle correction and prove one genuine quiet-session continuation
before spending the next VM window on pins or styling. Preserve the original
28-second trial D. No heartbeat, replay, wider native frame deadline, or
replacement architecture is needed to express the intended behavior.

| Priority | Concrete action | Decisive result / limit |
| --- | --- | --- |
| 1 | Adapt portable's real socket/SCM tests to the actual `receiveDesktopCredentialIngressAfterIdle` API; include desktop idle >5s then distinct valid frame, partial header/body, near-D admission, native and first-frame unchanged controls. | Exactly two expected checked callbacks before the one original D; partial frames retain fixed five-second receive/admission limit. Socketpair is component evidence, not selected-child evidence. |
| 2 | Add the focused retire/reuse negative root already requested: close during readiness, create an unrelated readable socket, retain its bytes and observe old waiter outcome. | No new callback, no consumed unrelated bytes, honest wait/close outcome. An allocator merely encouraging reuse is not proof the critical FD schedule occurred; retain actual descriptor identities/synchronization where available. |
| 3 | Use a separate declared mode in existing `runtime/test-ui-origin/Main.hs`: real selected backend/child, consume first correlated catalog reply, stay genuinely quiet >5s, send a distinct catalog request, consume its matching authenticated response. | Exercises actual `runBootstrap`, Scope, selected process and original-D supervision rather than just an injectable credential guard. Allocate its one fresh D before startup; do not change the existing five-second cases. HTTP204 alone is not consumption. |
| 4 | After protected source-bound results, reuse the existing owned-window controller for one physical Applications/search observation after a quiet interval. | Reacquire current engine PID/birth/window/scope and D; click the visible enabled control and the search field, verify actual input result. Window controls remain unavailable. Pins persistence/reorder/restart is a separate longer oracle. |

These are recommended proportional checks of the changed behavior, not a new
council, universal prerequisite or request for worker execution. Root chooses
the exact integration sequence and remedies for actual failures.

## What current source actually says

Inspected working bytes atop published
`392d1838fa042059361b589f8bbf9b657125026c`:

| File | SHA-256 at inspection |
| --- | --- |
| protocol/src/Warlock/Transport/Channel.hs | f97fad97579df5e9bd8156b8a0ecc54daffeea9872666220aa6fcf38f47c4868 |
| protocol/src/Warlock/Protocol/Ingress/Internal.hs | 8aef3a3a1ac06806afc330fa4d677a3264f8a504315edc87223e6511b4308bfc |
| protocol/src/Warlock/Protocol/CredentialIngress.hs | cfc0b79975b6c38a78cde6037799dbbb77d2f17b959ff7721d82ed01328d8f87 |
| runtime/src/Warlock/Bootstrap/Aggregate.hs | fdf9b224707611600919b349e868fd2883dbc637e9d5707750191dbd21a9a824 |

Paths above are relative to `implementation/warlock/haskell/`. Concurrent source
changes require new hashes; these findings do not qualify later bytes.

* Aggregate selects the new route only after a delivered frame. Ingress takes
  the wait only for desktopProfile; native fallback and initial receive retain
  their existing path. `readMaybe` with fallback zero is already total and
  fail-closed. The old patch's partial `read` finding is obsolete. Hoisting the
  trusted conversion is optional clarity, not a new blocker.
* Channel's same readGate spans readiness and credential frame receive. The
  ingress serial covers wait/read/admission/callback. Channel readGate releases
  before dispatch; do not claim it covers the callback.
* Readiness consumes no bytes or ancillary data. Existing exact-size header/body
  reads preserve the next coalesced frame. Every real fragment and final
  credential/admission check still follows the existing production route.
* After readiness, frame deadline is `min(originalD, receiveStart+5s)`. The
  unchanged five-second frame timeout remains, with the outer original-D timeout
  covering readiness plus receive. The final gate receives that same deadline.
  Header/body progress must not renew it. Current source arithmetic and a
  passing real timed regression are distinct claims.
* Boundary/Internal.hs dispatch samples deadline at atomic gate admission,
  releases its state MVar, then calls the action. Scheduling can let an action
  admitted before D **start or finish** after D. Say “no new admissions at/after
  D”; do not promise all callback execution finishes or starts before D. This
  preserves existing semantics rather than inventing post-action revocation.
* The leader watcher remains independently joined inside withLeaderExit and
  shuts the retained peer write direction. Idle leader-exit behavior still
  requires an actual production-route witness; an abstract model EOF is not it.

## Close/readiness issue: avoid both overclaim and scope inflation

Security/lifetime/engine peers identified that pinned network withFdSocket does
not itself exclude explicit close, and Channel closeAction does not acquire
readGate. This is a source-review race hypothesis, not an observed exploit or
authentication failure. The new readiness wait is nonconsuming and the following
run rechecks Closed. Stale event readiness alone therefore does not establish
an unauthorized callback or consumed unrelated bytes.

The changed question is old-wait registration/wake/deregistration versus explicit
close and reuse, including truthful completion under original D. Root's requested
focused retire/reuse control addresses that delta. Do not require a rewrite of
all historical recvmsg lifetime code merely because it shares withFdSocket.
Do not hold the state MVar across a blocking wait: that obstructs publication of
Closing and does not provide a hard scheduler bound. No duplicate-FD or global
ownership redesign is recommended without a concrete demonstrated need.
Endpoint closure is separate from observed reader completion, selected-child
normal termination and provider/backing cleanup.

## Peer responses and useful changes

* `terra-portable` explicitly scoped draft
  `4b6e751cef4b6a2a0bfea721cf4de0544fd3bb1fce49a94e81f1195dd72fd47c`
  to same-process kernel SCM / public ingress, excluding selected child, Scope,
  pidfd and leader. Its proposed minimal real-route bridge is the existing
  ui-origin catalog request/response fixture. Root has assigned actual-API
  adaptation and retire/reuse coverage. Draft was uncompiled/unrun when read.
* `terra-q-http` verified the exact current gate split and corrected the nested
  timeout concern: Channel resamples end time and normalizes returned results
  to TimedOut after D. Do not repeat that superseded concern as a defect.
  It identified the precise pre-admission versus callback-start distinction;
  this advisor relayed it to root and the lifetime model owner.
* `terra-q-lifetime` acknowledged that the former noDeadlineRenewal invariant
  merely bounded frameEnd by D, so could not itself detect renewal below D.
  It added captured frameStart/frameEnd correspondence and a timed fragment
  trace in draft `c33010f5f71951cb0721979a99569bd4edc978a77f06d933102f27c7bbae9c4a`
  (20 named tests, unexecuted at response). Future actions rewriting both
  start/end still require review; test count is not correctness.
* `terra-security` supplied exact existing coverage limits: legacy blocked-read
  cancellation, activation retirement, callback drain, ancillary-rights refusal,
  before-read/post-auth session replacement and selected graceful-stop controls
  do not themselves exercise this new idle watcher. New requests are coverage
  proposals, not observed failures. Root requested a concrete changed schedule.
  Follow-up response at 17:07:08 agrees no new unrelated-byte consumption or
  unauthorized callback is established by readiness alone; it recommends the
  proportional retire/recycle test and truthful completion/unknown result,
  without a global redesign or new approval requirement.
* `terra-q-origin` found no reason to alter the broker-engine RPC model for
  Backend-to-UI ingress idle scheduling. Preserve its existing abstraction;
  use the narrow idle model and actual ingress tests instead of duplicating it.
* `terra-graph` points to existing TRANSPORT.md five-second native framing
  reference and withLeaderExit's retained writer. Its pre-publication missing
  input warning was superseded: the specific 14 inputs are present in commit
  392d1838f. Do not spend another integration loop on the obsolete omission.
* `terra-q-front`, `terra-vm` and `gemini-gui` distinguish enabled Applications
  and search from disabled native launch/window effects. Bar and popup use
  separate GTK/WebKit widgets; DOM focus is not observed GTK keyboard focus.
  A normal physical click in the current visible search field is appropriate;
  historical coordinates/PIDs, fixed Tabs or injected DOM focus are not proof.
* `gemini-site` narrowed its broad draft PASS after peer feedback: it covered
  exact-size/coalesced reads, reader gates and arithmetic, not close/reuse or
  full implementation approval. Its website wording remains a draft, separate
  from actual idle-fix verification.

## Evidence fidelity and exact reference wording

Preserve the actual published tuple's GREEN ten suites / 248 named model cases,
and its real Elm app-only window/catalog observation. Neither qualifies the
later unstaged idle fix. Original run exited 1 after 7.445 seconds with
CredentialTransport TimedOut and no physical input; provider cleanup remains
unqualified and final inactive scope membership unknown. A historical accepted
requirement does not transfer to changed source. Keep all 242 requirements /
417 scenarios, historical 15 whole / 39 accepted scenarios, failures and
deadlines, HOSTSTOP2 and nativeOperations=[] intact.

Suggested conditional reference text after root obtains matching results:

> For the trusted desktop stream, after a delivered frame the retained owner may
> wait for readability under the original absolute session deadline D. Readiness
> consumes no payload or credentials and grants no authority. The first receive
> and native profile retain their original path. Once receive begins, the existing
> absolute five-second frame/admission bound applies, capped by D; fragments do
> not renew either bound. Already-admitted callbacks retain their drain contract.
> This bounded scheduling behavior establishes neither perpetual desktop life,
> physical GUI input nor complete resource retirement.

Keep TRANSPORT.md's native 65,536-byte/five-second contract explicit. Do not
promote the app-only screenshot to whole ARC002, ARC024, DEL014, native, AT/IME
or release acceptance. No new canonical page or architecture board is proposed.

## Turn limits

Read AGENTS/HANDOFF/current STATE and repository contributor, Elm/Haskell and
Quint review guidance. AgentBus doctor passed six checks; authenticated recv,
claims and thread handoffs reviewed. Graph query was used only for navigation;
source is authoritative. No keys/environment contents or forbidden checker
were read. Only this claimed ignored draft is edited. No worker compiler, model,
native, GPU, VM, agent launch, service/key change, commit or push occurred.
Recurring advisor role remains recorded in SOL-ADVISOR-LOOP; this bounded turn
does not promise permanent process liveness. Final response/handoff must name
terminal status so root can revalidate and resume the same session.

## Final integration addendum

Root received initial concrete draft as AgentBus `01M6C1A2ZEA4SXCPZM55PS270B`.
Lifetime owner subsequently prepared the model/test split and protected-build
integration patch at root's request: model
`c4e620440dbf5c4e506366fc35c81bd653991a19d03da639d35a09c909ca7b64`,
test `de2bdb23505346cb94c0dc35422fb81a61c46c0eecdb639431b1098240a331a6`,
integration patch `14a48b7e651ac25c2ec4add3a61945d9b4fddf09ee756eda3959f21e1761bfea`.
Read-only inspection confirms 24 named tests (20 directed plus four guided),
existing broad step retained and focused witness drivers listed separately.
This inspection is not typecheck, execution, witness reachability or proof.
The model explicitly labels beginCallback as an admission permit, allowing later
execution under existing drain semantics. Root must bind actual results to final
integrated bytes, not these evolving draft counts.

Advisor questions were also sent to gemini-gui and gemini-omarchy for the next
physical search/quiet-interval observation; any unanswered question is not a
running job or launch receipt. Existing authenticated GUI/VM/front handoffs
already provide the concrete focus/owned-window cautions summarized above.

Terminal handoff: 17:09 UTC. The requested bounded `agentbus wait --timeout 45`
returned exit 75, broker unavailable / connection lost, rather than a peer reply
or successful timeout. No retry loop, service/key change or replacement identity
was attempted. Concrete advice, draft and received peer responses were already
sent to root. No new GUI/Omarchy reply was received in this turn. This advisory
turn is complete; release the sole draft claim after final handoff and mark this
turn down. Root should revalidate actual process/terminal status before resuming
the same recorded session. The recurring role remains mandatory; this receipt
does not assert an active worker after turn completion.
