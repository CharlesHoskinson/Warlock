# Wave 17 Visual Inspection of `live-01.png` & Pure-Elm Styling/Layout Patch (`idle-delivery-1700`)

- **Author**: `gemini-gui` (`warlock-20261031-setup`)
- **Timestamp (UTC)**: `2026-11-01T17:08:00Z` (governing availability cutoff `2026-11-01T17:25:00Z`)
- **Canonical Patch Draft**:
  - Path: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/AppOnlyHierarchyEmptyState.patch`
  - SHA-256: `a5bb1f057587109ad97715de8f82aee483936f8e50e8518af0c5a1773ee21a49` (`279` lines, `18,266` bytes; verified `git apply --check` clean against `HEAD` `e63cd930d`)
- **Honesty & Scope Boundaries**:
  - **Preparation draft only** — zero repository production, model, or tool files were edited; zero compilers, tests, Quint models, browser harnesses, GPU tools, or VM runs were executed.
  - All `242` original requirements / `417` scenarios (`15 / 242` whole and `39 / 417` scenarios historical source-scoped), original deadlines `D` (`28s`), failed evidence, `HOSTSTOP2`, and `nativeOperations = []` are preserved unchanged.

---

## 1. Explicit Visual Confirmation of `live-01.png`

- **Explicitly Seen**: **YES** — `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-display-20261101T163508Z/live-01.png` (`324,023` bytes, `sha256:0a9e25a720deb71751c9958bcbe810cbf760bc1ea6dcc6459c0e9c57fd3483ef`) and `live-00.png` (`296,984` bytes, `sha256:d6592a8262eca09cf225d3dd48144eb243746b529dedfdc0fa1f6260752365aa`) were **directly inspected via native multimodal image reading**.
- **What `live-01.png` Shows (`1280 × 800` Omarchy Wayland Desktop)**:
  1. **Left half (`[12, 38]`, `623 × 750` during split)**: Pre-existing `Foot` terminal (`PID 2095`, `charl@warlock-vm:~`) completely intact and undisturbed (`[sudo] password for charl: ... SETUP-DONE ... sudo ufw allow 22/tcp ... ~ ) []`), restored to full `[12, 38] 1256 × 750` after clean scope exit.
  2. **Right half (`[647, 38]`, `621 × 750`, active light-blue Hyprland border)**: Owned same-ELF PID-1 display engine (`PID 100517`, `NSpid=[100517, 1]`, undecorated `gtkWindowSetDecorated win 0`, zero GTK chrome/widgets):
     - **Top `HttpBar` (`bView`, `y = 38..110`, `621 × 72`)**:
       - `.surface-bar` (`y = 38..94`, `56px` CSS `calc(3em + 8px)`):
         - **`Applications`** (`x ≈ 653..776, y ≈ 42..90`, center `(714, 66)`): **Enabled**, warm ivory `#f6efe8` bold text inside solid Lacquer `#fca399` border on `#351c1f` selected surface.
         - **`Task View`** (`x ≈ 782..875`) and **`Switch windows`** (`x ≈ 881..1006`): **Disabled** (`dashed` `#4d4446` border, muted `#9a8e8b` text), visually confirming `Shell.applicationOnly = True` (`nativeOperations = []`). (`Notifications`, `Files`, `System`, `Settings` remain disabled inside the horizontal `.surface-actions` scrollport.)
         - **Right status strip (`x ≈ 1018..1267`)**: `3px` coral Lacquer left accent rule + 2-line wrapped text `"Applications connected. Window controls unavailable."`.
       - **Sub-bar gap (`y = 94..110`, `16px`)**: `bView`'s `72px` GTK height minus `56px` `.surface-bar` CSS height, painted `#100e0e` (`palette.canvas`) by `0 100vh 0 100vh palette.canvas`, creating a `16px` pitch-black trench between the taskbar hairline and `Popup`.
     - **Lower `HttpPopup` (`pView`, `y = 110..787`, `621 × 677`)**:
       - Renders directly on flat `#100e0e` `palette.canvas` with **no elevated panel frame** and **no empty-state guidance**:
         - `<h1>Choose a window</h1>` (`3px` coral left bar, `1px` subtle bottom rule) — **contradicting** `"Applications connected. Window controls unavailable."` directly beneath it!
         - `<p role="status">Applications connected. Window controls unavailable.</p>`
         - Empty `0px`-tall `<div class="surface-controls" role="group"></div>` followed by ~`560px` of raw pitch-black `#100e0e` void.

---

## 2. Summary of `AppOnlyHierarchyEmptyState.patch` (Pure Elm Only)

Touches **only** `implementation/warlock/src/SurfaceRenderer.elm` and `implementation/warlock/src/SurfaceTheme.elm` (zero new `.elm` files, preserving `check-snapshot-contracts.py:58` source-inventory equality):

### A. Visible 3-Tier Lacquer Hierarchy & Taskbar Seam (`SurfaceTheme.elm`)
1. **Recessed Taskbar Sub-Shelf (`barRootStyles`)**:
   - Preserves `.surface-bar` `height: calc(3em + 8px)` (`56px` at `100%`, `104px` at `200%` — required by `settings-browser.mjs:90` and `feedback-context-browser.mjs:179`) and `.surface-actions` `padding: 0 3px`.
   - Changes the outer fill shadow from `0 100vh 0 100vh palette.canvas` to `0 100vh 0 100vh palette.surfaceRecessed` (`#131011` Night / `#eae3d9` Dawn) so any extra `bView` allocation (`72px` in `Mvp.hsc:840`) forms a cohesive recessed shelf instead of a raw black trench.
2. **Cohesive 3-Tier Elevated Popup Panel (`popupHeadingForModeStyles` + `popupStatusStyles` + `popupControlsPanelStyles`)**:
   - Keeps `> h1`, `> p[role="status"]`, and `> .surface-controls` as **direct children** of `.surface-popup` (zero wrapper `<div>` added; legacy `shell.css` child combinators `.surface-popup > h1` and `.surface-popup > p[role=status]`, `popup-adapter.js` `100vh` scrollport measurement, and `h1.textContent` / `p[role=status].textContent` remain 100% intact).
   - Joins those three direct children into a **top-anchored, content-hugging `max-width: 52rem` (`margin: 0 auto`) Lacquer sheet (`palette.surface` `#191516` Night / `#fffdf9` Dawn / `#000000` HighContrast)** over the `#100e0e` `palette.canvas` backdrop (`padding: 6px 8px 12px 8px`):
     - **Header cap (`h1`)**: `border-radius: 8px 8px 0 0`, `background-color: palette.surface`, `border-left: 3px solid palette.brandAccent`, and **`border-top: 2px solid` `palette.brandAccent` when open vs `palette.borderControl` when `closed`** — giving immediate visual hierarchy when `Applications` opens vs closes.
     - **Status band (`p[role="status"]`)**: `background-color: palette.surfaceRecessed`, `border-left: 3px solid stripeColor` (with `statusStripeColor` updated so `"Type to search applications."` and `"Choose a matching application."` also use `palette.brandAccent`).
     - **Controls body (`.surface-controls`)**: `border-radius: 0 0 8px 8px`, `background-color: palette.surface`, `padding: 8px`, `min-width: 0`, and `box-shadow: palette.snapShadow` when open & `softEffectsEnabled` (`"none"` when `closed`, `effectsOff`, or `HighContrast` — preserving `layer-appearance-browser.mjs:41`). Inside `applications` mode, disabled `entry:*` cards (`palette.surfaceRecessed` `#131011`) now visibly recess into the `#191516` panel while enabled `pin:*`, `jump:open:*`, `Close`, and `Refresh` controls (`#262022` / `#1e191b`) visibly stand proud above it.

### B. Popup Placement & Structural Empty States (`SurfaceRenderer.elm` + `SurfaceTheme.elm`)
1. **Structural `isAppOnlySession` Predicate (Fixes `D2` Without Fragile Prefix Matching)**:
   - Checks `List.any (\item -> item.identity == "bar:applications" && item.enabled) snapshot.bar && (List.any (\item -> item.identity == "bar:settings" && not item.enabled) snapshot.bar || String.contains "Window controls unavailable." snapshot.status)` (matching `Surface.elm:423-424`, where `bar:settings` is disabled iff `applicationOnly == True` on any attached session, even after a subsequent pin/catalog `Refused` or `Unknown` status replaces `"Applications connected..."`).
   - Exposes `data-surface-scope="application-only" | "window-shell"` on `.surface-popup` for diagnostics without altering wire payloads.
2. **Honest Closed Heading & Non-Interactive Empty-State Cards**:
   - When `snapshot.mode == "closed" && isAppOnlySession`: renders `<h1>Application workspace</h1>` (instead of `"Choose a window"`) plus keyed `("empty:closed-app-only", ...)` inside `.surface-controls` explaining that `Applications`, search, pin reorder, and catalog refresh are available while window/launch controls remain disabled (`nativeOperations = []`).
   - Also provides clean non-interactive empty-state cards for `closed` detached (`"Window host disconnected"`), `closed` ordinary window shell (`"No active panel open"`), and `applications` with zero `entry:*` items (`"Reading desktop catalog"`, `"Application catalog unavailable"`, or `"No matching applications"` — appended *after* `keyedControl` items so `<input id="launcher-search">` retains its exact keyed DOM node and focus across status/query updates per `feedback-context-browser.mjs:305`).

---

## 3. Preserved Semantics, Focus & QA Contracts

- **Zero interactive controls, focus stops, or wire actions added**: `.surface-empty-state` uses `<div class="surface-empty-state"><p>...</p><p>...</p></div>` (`no <button>`, `no <input>`, `no tabindex`, `no [role="option"]`), preserving `accessibility-browser.mjs:45`, `Presentation.focusTarget`, keyboard `Tab`/`Home`/`End`/`Escape`, and `nativeOperations = []`.
- **Dual-`WebKitWebView` Physical Input Reminder for Root / `terra-vm` (`Mvp.hsc:838-850`)**:
  - Because `bView` and `pView` are separate `GtkWidget`s inside `GtkBox`, physically clicking `Applications` in `bView` (`~(714, 66)` in `live-01.png`) leaves GTK4 widget focus on `bView` even after `HttpPopup.elm:57` calls `Browser.Dom.focus "launcher-search"` inside `pView`. Either click `#launcher-search` inside `pView` before physical typing or call `gtk_widget_grab_focus pView` in `Mvp.hsc` on popup open.
