# Engine actor adapter: source correspondence (draft)

Preparation only. This proposes an interface for independent review; it is not
implemented, compiled, tested, a model result, or original/native acceptance.
Elm remains the only presentation policy authority. Broker alone owns the native
fd 0, peer credentials, HTTP listeners, admitted actions, and owner state. The
engine receives no native/window grant and may report only observed GDK facts.
Original deadlines, refusals, stop histories and uncertain cleanup are retained.

## Current source boundary

* `runtime/src/Warlock/Ui/Owner.hs` SHA256
  `e6100f7ae8b5512c66b9cbde2a81a167719f6415c1e92fc33570974d5b69ad2f`:
  `UiEndpoints` contains fixed `controllerOrigin`, `barOrigin`, `popupOrigin`,
  and read callbacks `uiShouldStop :: IO Bool`, `uiRemainingMicros :: IO Int`,
  `uiLastProjection :: IO (Maybe J.Json)`. `runUiOwner` supplies these and a
  callback `TrustedOwnerEvent -> IO (Either Text ())` to the engine.
* `runtime/ui/Warlock/Ui/Mvp.hsc` SHA256
  `57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6`:
  actual mapped/unmapped GDK surface and input observations derive events; a
  stale dismiss does not prevent the following empty topology retirement.
* `runtime/ui/Warlock/Ui/WebKit.hs` was observed at SHA256
  `b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a`;
  current guard/build tuple must be re-pinned by root before integration.
* `runtime/formal/ui-frontend-delivery.qnt` SHA256
  `90698235d64f2a18ac80061e736a2c8491a5d2322f18398e4e378d22d708658e`
  models bounded delivery and focus abstractions, not this process split,
  transport, actual GDK/GTK/IME, provider confinement or physical input.

## Proposed narrow actor contract

On verified, held-executable startup, broker gives the authenticated engine
incarnation exactly the three role-specific origins and original monotonic
absolute deadline. Origin values remain fixed for that incarnation; the engine
cannot select a different listener, binding, scope, or native authority. Broker
exposes the following read-only RPC operations, retaining the semantics of the
corresponding callbacks, including explicit failure/unknown:

| Request | Reply | Source correspondence |
| --- | --- | --- |
| `ReadStop` | `Stop Bool` or failure | `uiShouldStop` |
| `ReadRemaining` | nonnegative remaining microseconds or failure | `uiRemainingMicros`, bounded by original D |
| `ReadProjection` | `Absent` or exact bounded projection snapshot, or failure | `uiLastProjection` |

`Absent` is a valid observed value, not a timeout, broken transport, cancellation,
or acknowledgment. Reply values are observations, not grants. A stop or elapsed
D must remain serviceable even while any synchronous engine callback is waiting;
exact request sequencing and multiplexing must be independently reviewed to
avoid a self-deadlock. The original owner is authoritative for current scope and
projection at event admission, regardless of an earlier snapshot.

The engine may send only this closed event sum, with strict bounded encoding,
exact keys and canonical full-width counter atoms; no generic raw gateway,
arbitrary event constructor, or unvalidated JSON escape hatch is exported:

| Event | Required source fields | Broker action |
| --- | --- | --- |
| `Topology` | exact `viewProtocol`, `kind`, `revision`, `views`; protocol 2 also `locations` | Reconstruct `OwnerTopology`, run existing topology/scope/revision validation; accept at most one owned scope; clear last projection only after successful enqueue. |
| `Dismiss` | `scope`, `lease` | Reconstruct `OwnerDismiss` and validate current scope/lease. |
| `Escape` | `scope`, `publication`, `lease` | Reconstruct `OwnerEscape` and validate current scope/publication/lease. |
| `Reflow` | `scope`, `lease` | Reconstruct `OwnerReflow` and validate current scope/lease. |

Topology version, exact shape, bounded geometry and monotonic revision remain
Owner checks; dismiss/reflow do not gain an invented publication field. Values
must originate in actual owned surface observations and source state, not fixture
scope IDs, fabricated GDK facts, or synthesized window/native grants. Decoder
validation precedes reconstructing each existing constructor; Owner validates
again against its current state. Valid well-formed obsolete projection returns
the existing `stale native UI projection` nonfatal refusal. Stale dismiss on
unmap must still allow the subsequent empty topology; stale escape/reflow keep
the existing nonfatal behavior. Malformed event, authorization failure, queue
full and stale event must remain distinct. Owner's existing failure policy must
not be weakened to make an IPC test pass.

The wire design is a proposal: separate explicit request/reply and event/reply
variants, engine-incarnation and opaque request correlation, exact fields,
strict size limits, and explicit handling of EOF, malformed, foreign, duplicate,
late, out-of-order and replayed frames. Reserve before emitting an event; an
uncertain send/response never grants a replay, native ACK, clean retirement, or
unchanged-state observation. Return only `Accepted`, the exact stale refusal,
or a bounded failure/unknown disposition; never claim success from HTTP 204.
Broker owns the policy checks and one reaper; coordinate the actual framing,
SCM credentials, held executable and child identity with the independently
reviewed spawn/protocol owners. Child exit, process-namespace exit, provider
confinement, callback retirement and backing release are separate observations;
missing evidence stays unknown/quarantined under the original D. No claims of
successful PID1 execution, GTK confinement, or safe cleanup follow from this API.

## Independent source-bound checks for root

1. Round-trip all three role origins and three read operations through the real
   adapter; verify current state, stop and original deadline, and preserve full
   width identity atoms. Distinguish absent projection from channel failure.
2. Exercise every event from a genuine owned source on the production route;
   verify Owner sees the exact schema and rejects malformed, excess, duplicate,
   foreign, old revision, wrong scope, stale lease/publication and queue overflow.
   Verify no callback or authority on denied/poisoned frames.
3. Sequence actual topology, committed projection, reflow and escape, then
   supersede projection and deliver stale events. Verify stale dismiss followed
   by empty topology still retires; no replay or stale-event owner failure.
4. Exercise outstanding reads/events across child death, EOF, timeout, stop,
   late response and missing retirement; assert unknown/quarantine, one reaper,
   retained backing, original deadline and no manufactured ACK/receipt.
5. Independently inspect real process/image/SCM identities, held exec, inherited
   descriptors, authenticated broker-only fd0/listeners, provider and callback
   retirement. Verify real GDK map/input/focus/IME separately where required.

Root alone runs protected builds, models, QA and VM/native execution. No check
has been run for this draft. Original 242/417, deadlines, failed evidence,
HOSTSTOP2, main desktop and prior acceptance boundaries remain unchanged.
