# Warlock Persistent Custody Prerequisite Stack Guide (`v16`, `012747Z`)

> **Status**: SOURCE-ONLY DRAFT (`HARD HOLD` for Root review/integration). No protected compiler, Cabal, Quint, VM, GPU, or native execution was performed by `gemini-omarchy`. Original 242 requirements / 417 scenarios (`18/242`, `42/417` accepted), `nativeOperations = []`, `HOSTSTOP2`, and all prior failed/frozen artifacts (`v11`..`v15`) remain preserved untouched.

## 1. Frozen `v16` Artifacts (`.warlock-contributor/engine-pid1-drafts/`)
- **Standalone Unified Patch against `HEAD` `8d1100f0e84461a9617bbb6c6fb5373d732d4cc7`**:
  - `gemini-omarchy-persistent-custody-prereqs-v16-012747Z.patch`
  - SHA-256: `52f50109ca655152e738ed4c74e4d435efddc1059fcdf834397ad80912c57786`
- **Exact Delta from `v15` (`36ada0d6...`) to `v16`**:
  - `gemini-omarchy-persistent-custody-v15-to-v16-delta-012747Z.patch`
  - SHA-256: `6b22eabb9347fed0253d513ffab38230ebe307772ef83fe5dcb77a3dffda0e64`

## 2. What `v16` Converges Over `v15` (`36ada0d6...`)
1. **Engine Nonblocking Held-Borrow Release (`terra-engine-held-nonblocking-release-001.patch` `af5d12a1...` folded byte-for-byte)**:
   - `Warlock/Platform/Executable/Internal.hs` postimage SHA-256 equals `e82f1abd6273749372d42d400212788f1f6d449f868f7beffeaefd5eebea1d0c` (`e82f1abd...`).
   - `borrowHeldWhile` returns the 4-tuple `(FilePath, IO Bool, IO (), IO (Maybe Bool))` where `releaseTry` is nonblocking (`Nothing` = `released` or `gate` occupied with zero decrement; `Just True` = released once; `Just False` = sticky `BorrowUnknown`/`HeldUnknown`), while `borrowHeldInterruptible` unwraps to the 3-tuple so non-`Persistent` callers stay unchanged.
2. **Security Token-Bound Raw `Owner` Borrow + `CoreTransfer` Receipts (`Owner.hs`)**:
   - Incorporates `terra-security`'s `BorrowToken` (`retainTrackedBorrow`, `tryReleaseTrackedBorrow`, `tryAbortTrackedNoInput`) and adds symmetric `CoreToken` (`retainTrackedCore`, `closeTrackedCore`, `tryAbortTrackedPreSpawn`) plus nonblocking `tryFailUnsettled` / `tryQuarantinePreSpawn`, preserving `Owner`'s 7-field constructor and legacy `retainBorrow` / `releaseBorrows` / `retainCore`.
   - `prepareInput` claims `TransferTicket` under `mask` before retaining `ticket` + `TrackedCore` on `rawOwner`, preventing unclaimed-ticket residue when `claimTransferWhen` refuses (`StartupRefused TransferUnavailable` / `TimedOut`).
3. **Same-Owner `CallbackGate`-Serialized Pre-Spawn Borrow Release, `StopD` Resampling & Final Atomic Pre-Spawn Arbitration (`Persistent/Internal.hs`)**:
   - `releaseBorrowPreSpawn` serializes each nonblocking `tryReleaseTrackedBorrow` commit under `CallbackGate` after verifying `min base latchedStopD` remains positive (waiting outside `CallbackGate` in `<= 1ms` / `stopReadyVar` steps when `HeldExecutable`'s gate returns `Nothing`), closing the `StopDuringReleaseControls` race without blocking on contended `HeldExecutable` gates.
   - `closeInputPreSpawn` resamples `preSpawnEffectiveDl` (`min base latchedStopD`) before and after closing pre-spawn input.
   - `finalizePreSpawnAbort` atomically arbitrates `phaseVar` + `CallbackGate` + `remainingMicros` + `O.tryAbortTrackedPreSpawn` before transitioning `rawOwner` to `Idle` (`Available`) and `phaseVar` to `PhaseRetired`, closing `SecurityFinalStopRaceControls.runLateStop` (quarantining both `PersistentQuarantined` and `Quarantined` when `StopD` latched and expired before finalization, while settling cleanly to `StartupRefused SessionClosed` when `StopD` remains unexpired or `StartupRefused TimedOut` when no stop latched).
   - Includes `#ifdef WARLOCK_BORROW_QA` startup/finalize hooks (`qa-held-borrow-gate-blocked`, `qa-startup-borrow-retained`, `qa-prespawn-before-finalize`) stripped in production `library` builds, and preserves line-67 import context so `terra-security-v11-owner-abort-race-qa-seam.patch` (`4e1f1d87`) applies with `--fuzz=0`.
   - Preserves `DeadlineStop.hs` and `process-custody.cabal` byte-identical to `v15` (`25` outer owners / `15` quarantined) while adding Section 23 controls (`23a`–`23e`, 5 `StablePtr`-rooted `preSpawnRegistry` owners) in `PersistentControls.hs`.
   - **No new per-syscall physical stop gate** is introduced inside admitted live callbacks; Root decides syscall admission-vs-inflight-`Unknown` semantics from original oracles.

## 3. Verified Zero-Fuzz 19-Patch Production Source Stack (`--fuzz=0`)
Apply EITHER a fresh composite OR the ordered constituent patches below against `8d1100f0e84461a9617bbb6c6fb5373d732d4cc7`:
1. `gemini-omarchy-persistent-custody-prereqs-v16-012747Z.patch` (`52f50109ca655152e738ed4c74e4d435efddc1059fcdf834397ad80912c57786`)
2. `terra-engine-lexical-ingress-integration.patch` (`74b07921d42d7a9ef2d7c58fe0365964ceeb5fe58294d6049d96400fe3192783`)
3. `terra-q-front-context-ingress-001.patch` (`c9fe0c1ac30e5775fd963b5e0508711c4fee79074253a183a50f66ea985834f5`)
4. `terra-q-front-owned-ingress-001.patch` (`51f9669976294b69d68c91b6bed8dfe7e59e750710c21ca8f028a1110387c014`)
5. `sol-outbound-pin-rebase-001.patch` (`33c3f67c74b62067188539e4bdd192ff149d8a5a327e48ef4f0e913aaea97815`)
6. `terra-portable-persistent-scope-001.patch` (`c55ee1346a16ac0a3c9760ac417389be9abc96902e8809a828fb28f7b605d7c7`)
7. `terra-portable-registration-deadline-001.patch` (`4a3245e6a118e7be69d540f48b28c49f674440d93fddea0f7641850ea64d85e6`)
8. `terra-portable-socket-context-001.patch` (`262f9403c0b0cd4acd29d83ec0eab66b081b5754e1cf1679371defcf9f2f1df4`)
9. `terra-portable-owned-pump-002.patch` (`ffaaadeefa0ca92ef4cb3e4fd6a8905fa9f18f128014ad4fba2f4c2e42c83bdc`)
10. `terra-portable-persistent-bootstrap-002.patch` (`ca1736bc1b4326e2f91065c5a8679a240403be6da63664331e32efe72fa37ceb`)
11. `terra-portable-bootstrap-cleanup-004.patch` (`14140811c7c5c7a0a8640aa8f9e7b439fa8ddfdd931d08f1d11f120dbb3714a4`)
12. `terra-portable-backend-request-sharing-001.patch` (`49584c7a13453ff47862d4b6f30cf067514fff57e1017cece62deefd3b81531f`)
13. `terra-portable-persistent-backend-001.patch` (`78c7440cec9873307938a959a856f41724e918efaa124466278eb744e3215eb2`)
14. `terra-portable-persistent-backend-owner-002.patch` (`a197b4bbd580d6f6ed897c78dc64ffab6f7ef843e34effcadcaf7c70b77e139e`)
15. `terra-portable-persistent-backend-owner-003.patch` (`71a70cb34289824d9644f355f3f9f339062db3cf9bf9154d1dafc0ffe1544833`)
16. `terra-portable-backend-v14-frame-004.patch` (`727732cf659b2fd0e64061bb945730d7f8cf934eed282d1d0a99a69f43431d3b`)
17. `terra-portable-persistent-request-order-005.patch` (`699067ed51381e68f8001108537dcc3398dd3f0e2e7a34d02580a9d13f36cc24`)
18. `terra-portable-persistent-reserve-frame-006.patch` (`8ba57f02bd79a5d655996126624884a15227bf72907a685cf643fd72354043bf`)
19. *(Optional Backend retirement layer once Sol supplies `retireCatalogIfSettled` / `retirePinStoreIfSettled`)*: `terra-portable-persistent-settled-retire-007.patch` (`49ca7b04c900e263df6621cfe4f925ae6f45e41d6684207f24f5ffb13914eab5`)
