{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY, UNEXECUTED. New preowned selected route; requires post-activation
-- QA hook, OWNER_QA stop gate seam, isolated held borrow-qa, and separately
-- reviewed guardian/fixture ancestry. Timeout is not a completion receipt.
module PostborrowStopGateBusyControls (Probe, newProbe, runPostborrowStopGateBusy) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, SessionExit(..), newPersistentOwner, persistentHeldNoInput,
  startBudgetAfter, startBudgetDeadline, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook, qaHoldPersistentStopGate, qaPersistentPendingIssues)
import Warlock.Platform.Executable (HeldExecutable, qaHeldBorrowCount)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe HeldExecutable))
 (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException ())) (MVar Result) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("postborrow stop gate: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 3000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
expired :: AdmissionDeadline -> IO ()
expired deadline = do
 left <- remainingMicros deadline
 if left <= 0 then pure () else threadDelay (min left 1000) >> expired deadline

runPostborrowStopGateBusy :: Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runPostborrowStopGateBusy (Probe owner held ownerTid stopTid borrowed resumeBorrow stopEntered stopUnlock stopDone ownerDone spawns used) supply = mask $ \restore -> do
 first <- atomicModifyIORef' used (\old -> (True,not old))
 check "single-use Probe" first
 let hook stage = case stage of
      "qa-startup-borrow-retained" -> putMVar borrowed () >> readMVar resumeBorrow
      "persistent-before-spawn" -> atomicModifyIORef' spawns (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar resumeBorrow ())
      void (tryPutMVar stopUnlock ())
      let waitOne ref done = do
           worker <- readIORef ref
           case worker of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
      waitOne stopTid stopDone
      waitOne ownerTid ownerDone
     run = do
      executable <- restore (supply owner)
      writeIORef held (Just executable)
      selection <- need (persistentHeldNoInput executable [] [("LANG","C"),("LC_ALL","C")])
      start <- startBudgetAfter 1000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop
         (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar ownerDone)
       writeIORef ownerTid (Just tid)
       pure tid
      within "actual selected borrow retained" (readMVar borrowed)
      before <- qaHeldBorrowCount executable
      check "exactly one active borrow" (before == Just 1)
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldPersistentStopGate owner (putMVar stopEntered ()) (readMVar stopUnlock))) (putMVar stopDone)
       writeIORef stopTid (Just tid)
       pure tid
      within "actual same owner stop gate locked" (readMVar stopEntered)
      within "original start deadline expires" (expired (startBudgetDeadline start))
      void (tryPutMVar resumeBorrow ())
      result <- within "owner returns while stop gate held" (readMVar ownerDone)
      count <- readIORef spawns
      pending <- within "actual pending retained" (qaPersistentPendingIssues owner)
      active <- qaHeldBorrowCount executable
      check "unavailable gate cannot become clean or spawn" $
       count == 0 && maybe False (const True) pending && active == Just 1 &&
       case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False
      void (tryPutMVar stopUnlock ())
      stopped <- within "gate holder completion" (readMVar stopDone)
      check "gate holder returned" (case stopped of Right () -> True; _ -> False)
 restore run `finally` finish
