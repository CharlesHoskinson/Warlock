-- ROOT-ONLY, UNEXECUTED source control. Requires test-only WARLOCK_OWNER_QA
-- seam for qaHoldPersistentStopGate and the exact stop-deadline-read patch.
-- No process is spawned by these controls. Root retains Probe/worker on every
-- timeout; callback completion is not thread join or resource cleanup proof.
module StopDeadlineReadControls (Probe, newProbe, runStopDeadlineControls) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Persistent
 (PersistentOwner, StopDeadlineObservation(..), StopReceipt(..), newPersistentOwner,
  requestSessionStop, stopBudgetMicros, tryPersistentStopDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaHoldPersistentStopGate)

data Probe = Probe PersistentOwner (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar (Either SomeException ())) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("stop deadline: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 3000000 action >>= maybe (ioError (userError (label ++ ": retain Probe"))) pure

runStopDeadlineControls :: Probe -> IO ()
runStopDeadlineControls (Probe owner workerRef entered release done used) = mask $ \restore -> do
 already <- atomicModifyIORef' used (\x -> (True,x))
 check "one-shot probe" (not already)
 let finish = do
      void (tryPutMVar release ())
      worker <- readIORef workerRef
      case worker of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     run = do
      before <- tryPersistentStopDeadline owner
      check "fresh owner is not latched" (before == StopDeadlineNotLatched)
      _ <- mask_ $ do
       worker <- forkFinally (restore (qaHoldPersistentStopGate owner (putMVar entered ()) (readMVar release))) (putMVar done)
       writeIORef workerRef (Just worker)
       pure worker
      within "actual owner stop gate held" (readMVar entered)
      blocked <- within "stop deadline read does not wait for held gate" (tryPersistentStopDeadline owner)
      check "busy observation is distinct from not latched" (blocked == StopDeadlineBusy)
      void (tryPutMVar release ())
      ended <- within "gate holder callback" (readMVar done)
      check "gate callback returned" (case ended of Right () -> True; _ -> False)
      budget <- either (ioError . userError . show) pure (stopBudgetMicros 1000000)
      first <- requestSessionStop owner budget
      deadline1 <- tryPersistentStopDeadline owner
      second <- requestSessionStop owner budget
      deadline2 <- tryPersistentStopDeadline owner
      check "first stop latches one immutable original deadline" $
       first == StopLatchedBeforeLive && second == StopAlreadyRequested &&
       case (deadline1,deadline2) of
        (StopDeadlineLatched d1,StopDeadlineLatched d2) -> d1 == d2
        _ -> False
 restore run `finally` finish
