{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY; SOURCE ONLY, UNEXECUTED. One actual owner with nested pinned
-- image and a separate genuinely unbound positive owner. QA hook 071 is
-- isolated build only. Root must retain Host and an independent guardian on
-- every failure/timeout. No test timeout cancels any process or cleanup.
module PortableSealLoss072 (Host,newHost,runCase,retained) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (IOException,SomeAsyncException,SomeException,finally,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import Foreign.StablePtr (newStablePtr)
import System.IO (Handle,hIsOpen)
import System.IO.Error (ioeGetErrorString)
import System.Timeout (timeout)
import Warlock.Capture.Process (SessionObservation(..),ToolError(..))
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Capture.Process.Owner (OwnerStatus(Available))
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,SessionExit(..),StartupAdmissionFailure(..),
  newPersistentOwner,startBudgetFromDeadline,persistentUnderlyingStatus,
  withPersistentBoundNestedStartup,runPersistentBoundImage)
import Warlock.Capture.Process.Persistent.Internal
 (SealedImageReceipt,persistentFixture,withPersistentOwnerHook,qaSetAfterSealCommit)
import Warlock.Platform.Executable (LeaseRole(UiImage))
import Warlock.Platform.Resolver (Identity,Pin,Link)

data Host = Host PersistentOwner PersistentOwner Handle Handle (IORef Bool)
 (IORef [ThreadId]) (MVar (Either SomeException ())) (IORef Int) (IORef Int)
 (IORef Int) (IORef Int) (IORef Int)
newHost :: Handle -> Handle -> IO Host
newHost blockedInput positiveInput = do
 bound <- newPersistentOwner
 unbound <- newPersistentOwner
 host <- Host bound unbound blockedInput positiveInput <$> newIORef False <*> newIORef [] <*> newEmptyMVar
  <*> newIORef 0 <*> newIORef 0 <*> newIORef 0 <*> newIORef 0 <*> newIORef 0
 -- The external process guardian also retains Host; this root survives an
 -- observer timeout or exception, rather than finalizing an uncertain owner.
 _ <- newStablePtr host
 pure host
retained :: Host -> IO ([ThreadId],Maybe (Either SomeException ()))
retained (Host _ _ _ _ _ workers done _ _ _ _ _) = (,) <$> readIORef workers <*> tryReadMVar done
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("seal-loss: " ++ label)))
start :: AdmissionDeadline -> IORef [ThreadId] -> MVar (Either SomeException ()) -> IO () -> IO ()
start deadline workers done action = mask $ \_ -> do
 gate <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (do
   readMVar gate
   remainingMicros deadline >>= check "original D before worker entry" . (>0)
   action))
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right () -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar gate ()
await :: AdmissionDeadline -> MVar a -> IO a
await deadline done = do
 left <- remainingMicros deadline
 check "original D before observation" (left>0)
 observed <- timeout left (readMVar done)
 case observed of
  Nothing -> ioError (userError "seal-loss: Unknown; retain both owners and guardian")
  Just result -> do
   remainingMicros deadline >>= check "receipt before original D" . (>0)
   pure result

-- Root supplies independent real pinned image inputs, fresh fixture child,
-- private resources and the existing D/StopBudget; it must validate actual
-- owner-specific source hashes. legacyExe/args point to the real harmless QA
-- child which exits normally. Both input Handles stay caller-owned until an
-- admitted selected process claims one. No path or deadline comes from UI.
runCase :: Host -> AdmissionDeadline -> StopBudget -> B.ByteString -> Identity -> [Pin]
 -> B.ByteString -> [Link] -> Integer -> B.ByteString -> FilePath -> [String] -> IO ()
runCase (Host bound unbound blockedInput positiveInput used workers done blockedSpawn blockedVerify positiveSpawn positiveVerify positiveLive)
 originalD stopBudget rootPath rootIdentity pins imagePath links size digest legacyExe legacyArgs = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated run" fresh
 start originalD workers done $ do
  outcome <- withPersistentBoundNestedStartup bound (startBudgetFromDeadline originalD) $ \_ seal scope -> do
   prepared <- runPersistentBoundImage scope rootPath rootIdentity pins imagePath links size digest UiImage
   receipt <- case prepared of
    Right (Right (_,value)) -> pure value
    _ -> ioError (userError "real owner image preparation not confirmed")
   -- This exact injected error occurs AFTER actual sealed owner state commit
   -- and receipt construction but BEFORE seal returns it to this caller.
   qaSetAfterSealCommit (ioError (userError "lost-seal-receipt-qa"))
   lost <- (try (seal receipt) :: IO (Either IOException (Either StartupAdmissionFailure SealedImageReceipt)))
    `finally` qaSetAfterSealCommit (pure ())
   check "only expected seal-return fault caught" $ case lost of
    Left err -> ioeGetErrorString err == "lost-seal-receipt-qa"
    Right _ -> False
   repeated <- seal receipt
   check "same prepared receipt cannot reconstruct lost seal" $ case repeated of
    Left (StartupAdmissionRefused OwnerBusy) -> True
    _ -> False
   let boundFixture = persistentFixture legacyExe legacyArgs blockedInput
   denied <- withPersistentOwnerHook bound boundFixture 4096 (startBudgetFromDeadline originalD) stopBudget
    (\_ -> modifyIORef' blockedVerify (+1) >> pure (Right ()))
    (\_ -> pure ())
    (\stage -> if stage == "persistent-before-spawn" then modifyIORef' blockedSpawn (+1) else pure ())
   raw <- persistentUnderlyingStatus bound
   stillOpen <- hIsOpen blockedInput
   spawnCount <- readIORef blockedSpawn
   verifyCount <- readIORef blockedVerify
   check "bound fallback refused before owner begin, input transfer or spawn" $
    (case denied of Left (StartupRefused OwnerBusy) -> True; _ -> False)
    && raw == Available && stillOpen && spawnCount == 0 && verifyCount == 0
   -- Return Unknown explicitly: no output is allowed to imply that the lost
   -- sealed receipt or any retained owner part was safely retired.
   pure (Left StartupAdmissionUnknown)
  check "lost seal scope remains unknown" (outcome == Left StartupAdmissionUnknown)
  -- A distinct actual unbound owner exercises the same legacy fixture path as
  -- a positive control; no broad ban is inferred from the bound refusal.
  let positive = persistentFixture legacyExe legacyArgs positiveInput
  succeeded <- withPersistentOwnerHook unbound positive 4096 (startBudgetFromDeadline originalD) stopBudget
   (\observed -> do
     modifyIORef' positiveVerify (+1)
     check "actual unbound child identity" (observedPid observed>0 && observedExecutable observed==legacyExe)
     pure (Right ()))
   (\_ -> modifyIORef' positiveLive (+1))
   (\stage -> if stage == "persistent-before-spawn" then modifyIORef' positiveSpawn (+1) else pure ())
  spawns <- readIORef positiveSpawn
  verifies <- readIORef positiveVerify
  lives <- readIORef positiveLive
  check "genuinely unbound legacy positive completes" $
   (case succeeded of Right ((),LeaderReaped _) -> True; _ -> False)
   && spawns==1 && verifies==1 && lives==1
 result <- await originalD done
 either throwIO pure result
-- The retained bound image, its separately owned parts, direct process, and
-- guardian are not treated as retired or native acceptance by this control.
