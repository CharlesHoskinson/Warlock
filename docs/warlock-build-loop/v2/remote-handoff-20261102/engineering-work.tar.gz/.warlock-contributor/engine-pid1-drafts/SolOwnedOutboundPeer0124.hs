{-# LANGUAGE OverloadedStrings #-}
-- Root-only pinned child fixture. Bounded TERM ignore is QA-only, and makes a
-- real stop-before-admission witness independent of immediate process death.
-- Root retains the exact namespace/child and may not infer cleanup from exit.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless)
import qualified Data.ByteString as B
import qualified Data.Text.Encoding as TE
import System.Directory (doesFileExist)
import System.Environment (getArgs)
import System.FilePath (isAbsolute)
import System.IO (Handle, BufferMode(NoBuffering), hClose, hFlush, hSetBinaryMode, hSetBuffering)
import System.Posix.IO (OpenMode(WriteOnly), defaultFileFlags, exclusive, fdToHandle, openFd)
import System.Posix.Signals (Handler(Ignore), installHandler, sigTERM)
import System.Posix.Types (Fd(..))
import System.Timeout (timeout)
import qualified Warlock.Protocol.Framing as F
import qualified Warlock.Protocol.StrictJson as J

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

packet :: B.ByteString
packet = "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"\",\"bar\":[],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"7\"}],\"focus\":[]}"

readFrame :: Handle -> IO B.ByteString
readFrame input = do
  header <- B.hGet input 4
  count <- must (F.desktopGatewayHeaderLength header)
  bytes <- B.hGet input count
  unless (B.length bytes == count) (ioError (userError "short reply"))
  pure bytes

waitRemoval :: FilePath -> Int -> IO ()
waitRemoval marker left = do
  exists <- doesFileExist marker
  if not exists then pure () else if left <= 0 then ioError (userError "owned marker remained")
    else threadDelay 10000 >> waitRemoval marker (left - 1)

main :: IO ()
main = do
  args <- getArgs
  (mode,marker,receipt) <- case args of
    [m,a,b] | m `elem` ["Positive","ExpiredCeiling","StopBeforeAdmission","StopAfterAdmission"]
                && isAbsolute a && isAbsolute b && a /= b -> pure (m,a,b)
    _ -> ioError (userError "expected known mode and two distinct owned absolute paths")
  _ <- installHandler sigTERM Ignore Nothing
  input <- fdToHandle (Fd 0)
  hSetBinaryMode input True
  hSetBuffering input NoBuffering
  bytes <- must (F.desktopCommitPrefix packet)
  B.hPut input bytes
  hFlush input
  observed <- timeout (if mode == "Positive" then 1500000 else 250000) (readFrame input)
  -- Exclusive private receipt contains observed data only. Parent uses an
  -- independent literal expected reply; no reducer output becomes an oracle.
  fd <- openFd receipt WriteOnly (Just 0o600) defaultFileFlags{exclusive=True}
  output <- fdToHandle fd
  B.hPut output (TE.encodeUtf8 (J.renderJson (J.JObject [("received",maybe J.JNull (J.JString . TE.decodeUtf8) observed)])))
  hClose output
  waitRemoval marker 200
  hClose input
