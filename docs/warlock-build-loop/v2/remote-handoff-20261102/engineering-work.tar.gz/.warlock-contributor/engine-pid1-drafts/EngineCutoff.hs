-- PREPARATION DRAFT. Do not treat as integrated, tested, or native evidence.
-- For review only: extract the child-local cutoff decisions from
-- EngineEntrypoint and supply remainingMicros ORIGINAL_D as 'remaining'.
module Warlock.Ui.EngineCutoff (localStop, localRemaining) where

-- Each sample is of the SAME original absolute D. This does not renew D,
-- authenticate RPC or enforce a hard real-time timer. Exceptions and uncertain
-- remote results propagate unchanged; a caller must retain fail-closed poison.
localStop :: IO Int -> IO Bool -> IO Bool
localStop remaining remote = do
  before <- remaining
  if before <= 1000000 then pure True else do
    requested <- remote
    after <- remaining
    pure (requested || after <= 1000000)

localRemaining :: IO Int -> IO Int -> IO Int
localRemaining remaining remote = do
  before <- remaining
  if before <= 1000000 then pure before else do
    observed <- remote
    after <- remaining
    pure (min before (min after observed))

-- Proposed integration text, not applied:
--   let remaining = remainingMicros deadline
--       endpoints = remote { uiShouldStop = localStop remaining (uiShouldStop remote)
--                          , uiRemainingMicros = localRemaining remaining (uiRemainingMicros remote) }
-- Keep the existing broker/child RPC deadline, errors, poisoning, original D,
-- owner authority and cleanup unchanged. This closes returned-value staleness
-- but is NOT by itself a complete 1s cutoff: WebKit reads stop then remaining,
-- so remaining can cross the boundary after stop returned False. Root must
-- review the caller sequence and test that interleaving; never represent an
-- actual positive cleanup budget as zero merely to force a stop. Unsafe
-- provider/nonthreaded scheduling still needs an independent watchdog.
