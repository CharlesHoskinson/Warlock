-- PREPARATION DRAFT / PATCH FRAGMENT, NOT A BUILDABLE MODULE OR ACCEPTANCE.
-- Intended to live INSIDE existing Warlock.Ui.EngineCustody.hsc so Custody,
-- requireForkOwnership, openPidfd, verifyChild, stopCustody and abandonCustody
-- are the SAME existing private owner. Do not instantiate a second reaper.
-- Root alone may integrate, compile or execute it. All names marked NEW are
-- missing narrowly owned helpers and must be actually implemented/reviewed.
-- No callback below may be supplied by untrusted callers. Immutable facts are
-- exposed publicly; PID, raw descriptors, child actions and waiters are not.
--
-- REQUIRED imports in that existing module (illustrative):
-- Control.Exception (mask, onException, try, SomeException, throwIO)
-- System.Exit (ExitCode(ExitFailure))
-- System.Posix.Process (forkProcess, exitImmediately)
-- qualified Network.Socket as S
-- Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
-- Warlock.Ui.EngineSpawn (ChildInputs, childSetupExec)
--
-- startEngineCustody is called by the NEW runUiOwnerPrepared hook only AFTER
-- native adoption, witness verification, document preparation and all three
-- origin/listener bindings but BEFORE launch of listener/native Haskell workers.
-- Parent remains nonthreaded; `requireForkOwnership` checks actual OS tasks and
-- SIGCHLD disposition. The owner retains those real bound listeners and fd0;
-- neither is passed to the engine. Do not change any original deadline.
--
-- NEW opaque `PreparedEngine` is package-owned, NOT a general spawn object. A
-- masked constructor must, before unshare/fork and while the original owners
-- are leased, open the approved /proc/self/exe as a held descriptor, pin its
-- device/inode/size/hash and compare against the current selected owner image;
-- create an owned Unix socketpair and O_CLOEXEC lifeline; obtain the child's RPC
-- source inside withFdSocket; duplicate EXACTLY held image, child socket and
-- lifeline read via F_DUPFD_CLOEXEC into three raw pre-retained pending slots.
-- The original Socket/Handle stays alive while duplicating. No managed wrapper
-- or finalizer ever owns the raw duplicate numbers. The constructor pins argv,
-- envp, poll/capability buffers, fixed engine-only mode, raw numbers and the
-- same absolute D in memory; validates no collisions, identities, ELF and
-- strict environment; and enables SO_PASSCRED on the broker socket. Duplicates
-- and all partially acquired resources belong to the existing Custody pending
-- owner BEFORE the next fallible action. Cleanup must withdraw each ownership
-- record once, close without retry, and quarantine on ambiguity. Acquisition
-- and slot-registration atomicity under synchronous failure remain a proof gate.
--
-- The following code shows actual parent ordering; NEW operations are explicitly
-- unresolved and must NOT be stubbed to report success:
--   prepareEngineOwned :: AdmissionDeadline -> EngineBinding -> IO PreparedEngine
--   childInputs        :: PreparedEngine -> ChildInputs
--   childBrokerSocket  :: PreparedEngine -> S.Socket
--   lifeWriteOwned     :: PreparedEngine -> CInt
--   releaseParentChildCopies :: PreparedEngine -> IO ()
--       closes parent copies of raw child duplicates and original child-only
--       endpoints, never the parent RPC socket or lifeline writer; records each
--       close result; uncertain close is fatal/quarantined.
--   transferPublishedCustody :: PreparedEngine -> Custody -> IO ()
--       atomically transfers socket/lifeline/pidfd to the owned live ledger.
--   authenticateEngineReady :: AdmissionDeadline -> PreparedEngine -> CInt
--                              -> CInt -> IO (Either StartError ReadyEvidence)
--       requires kernel SCM credentials for EVERY received fragment, no CMSG
--       truncation/unexpected rights, host PID exactly the selected direct child,
--       mapped UID/GID, live pidfd, birth identity, exact same held executable,
--       PID1/namespace/proc tuple, nonce, fixed manifest and original D. Engine
--       itself checks and continually monitors its post-exec lifeline before
--       ready; no privileged WebDriver or page-supplied assertion is accepted.
--   retirePreparedBeforeFork :: PreparedEngine -> IO ()
--   retirePreparedAfterFork  :: PreparedEngine -> IO ()
--       idempotent by withdrawn ownership; record/return cleanup uncertainty.
--   markForkedChild :: PreparedEngine -> CInt -> IO ()
--       publish direct-child identity in already-retained pending state before
--       any other fallible parent work. If impossible, parent MUST terminate.
--   markPidfd :: PreparedEngine -> CInt -> IO ()
--       records pidfd before verification or any other fallible work.
--   abortOwnedChild :: AdmissionDeadline -> PreparedEngine -> Custody -> IO ()
--       uses ONLY stopCustody/abandonCustody and reports unknown if stop/reap
--       cannot be proven; never fabricate clean exit, never wildcard wait.
--
-- This fragment must be reviewed for asynchronous/synchronous exception and
-- ownership gaps before use. EXIT on loss of child ownership is intentionally
-- fail closed, not a successful cleanup or a retry with a relaxed namespace.

startEngineCustody :: AdmissionDeadline -> EngineBinding -> IO EngineSession
startEngineCustody deadline binding = mask $ \restore -> do
  left <- remainingMicros deadline
  when (left <= 500000) (ioError (userError "engine startup deadline"))
  requireForkOwnership
  prepared <- prepareEngineOwned deadline binding
  -- close only resources actually held by the pending ledger. No blind close or
  -- guessed fd. Failure before unshare/fork returns no live child.
  let beforeForkFailure = retirePreparedBeforeFork prepared
  (do
    leftBeforeFork <- remainingMicros deadline
    when (leftBeforeFork <= 500000) (ioError (userError "engine startup deadline"))
    requireForkOwnership
    _ <- throwErrnoIfMinus1 "engine unshare PID" (c_unshare #{const CLONE_NEWPID})
    -- PID namespace-for-children cannot be undone: every subsequent failure
    -- must terminate the owner process after its owned cleanup attempt.
    pid <- forkProcess (childSetupExec (childInputs prepared))
    -- The child path never returns from exec or _exit. The parent is masked.
    -- If publication or pidfd_open fails here, ordinary exception unwinding is
    -- NOT enough; pidfd ownership may not exist. Enforce terminal failure.
    let fatalUnpublished = do
          retirePreparedAfterFork prepared
          exitImmediately (ExitFailure 119)
    (do
       markForkedChild prepared (fromIntegral pid)
       requireForkOwnership
       pidfd <- openPidfd (fromIntegral pid)
       markPidfd prepared pidfd
       owned <- verifyChild pidfd
       unless owned (ioError (userError "engine child ownership uncertain"))
       -- Construct the EXISTING sole custody; cells take ownership once.
       life <- newIORef (Just (lifeWriteOwned prepared))
       pidfdCell <- newIORef (Just pidfd)
       let custody = Custody life pidfdCell
       transferPublishedCustody prepared custody
       let abort = abortOwnedChild deadline prepared custody
       (do
          releaseParentChildCopies prepared
          remaining <- remainingMicros deadline
          when (remaining <= 0) (ioError (userError "engine startup deadline"))
          -- The bounded verifier must use the original deadline and pidfd; it
          -- returns Left on EOF, unexpected creds, namespace mismatch or any
          -- unknown fact. It must not block past D or invent ready.
          result <- restore (authenticateEngineReady deadline prepared (fromIntegral pid) pidfd)
          proof <- either (ioError . userError . show) pure result
          afterReady <- remainingMicros deadline
          when (afterReady <= 0) (ioError (userError "engine ready after deadline"))
          pure (EngineSession custody (childBrokerSocket prepared) proof))
          `onException` abort)
      `onException` fatalUnpublished)
   `onException` beforeForkFailure

-- IMPORTANT integration hazards of the illustrative fragment:
-- * The nested exception handlers above are a patch sketch: after ownership is
--   transferred, `fatalUnpublished`/beforeForkFailure must be guarded by an
--   explicit one-way phase state so they cannot double-close, double-stop or
--   turn an already handled failure into a clean result. Root should implement
--   a monotonic Pending -> Forked -> Published -> Ready -> Retired/Uncertain
--   owner, not literally paste this without changing those handlers.
-- * Parent `exitImmediately` on missing pidfd cannot be represented as a
--   measured cleanup pass. If the parent dies before child installs PDEATHSIG,
--   the child has a copy of the lifeline writer until exec due to CLOEXEC, so
--   pre-exec poll alone can give false liveness. Engine-only FIRST post-exec
--   action must rearm/check parent death, poll lifeline with inherited writer
--   now gone, and refuse before GTK/ready/messages on EOF/data/error. Prove
--   this and parent-death races under actual exec. If child hangs before exec,
--   PID1 descendant cleanup cannot be asserted without an independent observed
--   owner; retain unknown and fail closed. There is no native acceptance here.
-- * Return type EngineSession and ReadyEvidence are proposed opaque types. A
--   read-only facts API must not transfer raw handles or provide signal/wait.
--   The wire handshake, pidfd/SCM verifier, held-self acquisition, finite FD
--   validator, raw pending ledger, and engine dispatcher are NOT implemented by
--   this fragment. Parent must verify D and identity, not trust a child string.
-- * Root must separately prove private mount/capability drop, actual executable
--   identity, FD census/CLOEXEC, no mutable or stale finalizer closes of raw
--   numbers, postfork Haskell/RTS safety, one-thread broker, no extra owner or
--   reaper, no GTK before cap verification, and original-obligation behavior.
