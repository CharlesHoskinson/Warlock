# Persistent Custody Prerequisite `v8` Consolidated Source Review & Cutoff Handoff (`225558Z`)

- **Owner**: `gemini-omarchy` (`warlock-20261031-setup`)
- **Canonical Base (`HEAD`)**: `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70` (canonical files untouched; zero worker compiler/model/VM/native runs)
- **Preserved Immutable Prior Patches**:
  - `v6` full: `gemini-omarchy-persistent-custody-prereqs-v6-220528Z.patch` (`sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`)
  - `v6 -> v7` delta: `gemini-omarchy-persistent-custody-v6-to-v7-delta-225558Z.patch` (`sha256:f06aac4e4e5b207ad35e90bbd068413cacef79624462b46b01c7206c0f05d5d1`)
  - `v7` full: `gemini-omarchy-persistent-custody-prereqs-v7-225558Z.patch` (`sha256:5aba617d4adbce8db604beefff8f9260ee2108a8c2c4b4b7795e5aaf892fd1b0`)
- **Consolidated `v8` Artifacts (All Peer Source Reviews Folded)**:
  - `v7 -> v8` delta: `gemini-omarchy-persistent-custody-v7-to-v8-delta-225558Z.patch` (`sha256:660d8aadefc6b3d4c20b2b4638d711dd783a53b77f90c7afa07052b822dc90d1`)
  - `v6 -> v8` delta: `gemini-omarchy-persistent-custody-v6-to-v8-delta-225558Z.patch` (`sha256:04d431a09171a34a55f978854828435763f3ad25bbb02560e4ac2b36ea52b9df`)
  - `HEAD -> v8` full: `gemini-omarchy-persistent-custody-prereqs-v8-225558Z.patch` (`sha256:76fe15f4f66a26e6669662d6fb630fe4b207c31e6bc3322866618f50e0d1e93c`, strict `diff --git a/... b/...` headers verified)
  - `v8` manifest: `gemini-omarchy-persistent-custody-v8-manifest-225558Z.json`

## 1. Peer Source Findings Folded into `v8`
1. **Strict `a/... b/...` git headers on new files (`terra-engine` `01M6CPDZZ7289CWRSQ6ETPW7QJ`)**: Fixed new-file `diff --git a/implementation/...` header normalization in `HEAD -> v8` full patch and verified with both `git apply --check` and `patch --dry-run -p1 --fuzz=0`.
2. **Pre-claim resample + post-completion absolute `D` check (`terra-engine`, `terra-q-lifetime`, `terra-q-front`, `terra-q-network`, `sol-docs`)**:
   - `boundedByDl` now re-samples `remainingMicros dl` after `Right (Just val)` so no cleanup step finishing after `D` counts as `completed`.
   - `closeOwnedPidfdDl` bounds `persistent-before-pidfd-close-precheck` under `boundedByDl closeDl`, re-samples `leftAtClaim <- remainingMicros closeDl` inside `mask` immediately before claiming `InternalPidfdClosing` (retaining `PidfdKnownOpen` on expiry; **Control #18a**), and after `closeFd` returns `Right (Just ())` records truthful `PidfdClosed` receipt while returning `Right Nothing` if `remainingMicros closeDl <= 0` so containment quarantines on late close without retrying `closeFd` (**Control #18b**).
3. **Retain `PidfdKnownOpen` when leader reap is unconfirmed (`terra-q-network` `01M6CPDFN2MJ0DBJK1HG49H2AE`)**: `finishContainment` and `cleanupStartup` invoke `closeOwnedPidfdDl` only when leader reap succeeded; if `terminateLeaderDl` fails with time remaining, the verified pidfd stays `PidfdKnownOpen` (**Control #17**).
4. **Control #14 exact expired-`D` failure list & QA fixture custody (`terra-security`, `terra-q-lifetime`)**:
   - Control #14 asserts the exact 7-element expired-`D` failure list `["pidfd-close","stdout-stop","stderr-stop","stdout-join","stderr-join","stdout-close","stderr-close"]`.
   - Replaced all raw numeric `c_kill` calls in `PersistentControls.hs` with package-internal `reapQuarantinedTestChildInternal` (`pidfd_send_signal` + `waitForProcess` reap receipt; `allowClosePidfd = False` in Control #13 where GHC epoll unregister was skipped).
   - Wrapped Control #12 and Control #7 worker probes in `forkFinally` + `boundedTest` (`2s` timeout) + `finally` release.
5. **Quint Model Correspondence (`terra-q-lifetime-two-pin-v7.qnt` `5a9a6f4c` + `_test.qnt` `2ae4e083`)**: Reviewed source correspondence: `ProposedOrder`, `unregisterFails` (retaining `wakePin`, latching `stopped`, preserving prior `stopD`), and `unregisterFailureContained` match `v7`/`v8` `runWakeScope`; `registrationSafe = False` before `threadWaitReadSTM` (`terra-graph` `01M6CPE6BXBAN12KCXMP`) is intentional conservative quarantine because partial event-manager registration disposition is unknown on exception.
6. **Ingress Deferred-Close Boundary (`74b07921` / `5795989c`) & Unimplemented Call Chain**: Unchanged from `v7` — private `Gate`/`SocketPins` borrowing alone never confirms socket cleanup; `PersistentAggregate`/`TrustedPump` and canonical provider callsites remain unimplemented (`nativeOperations = []`; `17/242` whole EARS, `41/417` scenarios).
