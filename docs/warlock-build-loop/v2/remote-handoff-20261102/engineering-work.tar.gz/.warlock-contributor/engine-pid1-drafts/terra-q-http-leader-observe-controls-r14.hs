{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, SOURCE ONLY, UNEXECUTED. Host must retain Case, actual worker,
-- child ProcessHandle/pidfd and independent process guardian on every outcome.
-- QA hooks are around the observeChild GROUP, never individual syscalls.
module QHttpLeaderObserveR14 (Mode(..),Case,newCase,hook,finishCase,releaseBarrier) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),deadlineAbsoluteNs,remainingMicros)
import Warlock.Capture.Process.Persistent.Internal
 (PersistentOwner,PersistentStatus(..),PidfdCustody(..),SessionExit(..),StopBudget,StopReceipt(..),
  StopDeadlineObservation(..),CleanupDeadlineObservation(..),requestSessionStop,
  tryPersistentStopDeadline,tryPersistentCleanupDeadline,persistentPidfdCustody,persistentStatus)

data Mode = BeforeObservation | ReturnedObservation deriving (Eq,Show)
data Case = Case PersistentOwner Mode (IORef [String]) (IORef Bool) (MVar ()) (MVar ()) (IORef (Maybe ThreadId)) (IORef (Maybe (MVar (Either SomeException StopReceipt))))
newCase :: PersistentOwner -> Mode -> IO Case
newCase owner mode = Case owner mode <$> newIORef [] <*> newIORef False <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef Nothing
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ release _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("leader-observe: " ++ label)))
within :: AdmissionDeadline -> String -> IO a -> IO a
within original label action = do
 left <- remainingMicros original
 if left<=0 then ioError (userError (label ++ ": retain owner and guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure result
absolute :: AdmissionDeadline -> IO Integer
absolute d = maybe (ioError (userError "invalid actual deadline")) pure (readMaybe (deadlineAbsoluteNs d))
awaitExpired :: AdmissionDeadline -> AdmissionDeadline -> IO ()
awaitExpired original selected = do
 left <- remainingMicros selected
 if left<=0 then pure () else do
  remainingMicros original >>= check "original observation D remains live" . (>0)
  threadDelay (min left 1000)
  awaitExpired original selected

-- Passed directly to the actual withPersistentOwnerHook invocation for the
-- same verified live selected child. The provided live body should return
-- normally, causing real implicit containment BEFORE any explicit stop.
-- Mode 1 parks before the group admission; mode 2 parks after the actual group
-- returned, inside its existing bounded action. No signal hook is generated.
hook :: Case -> String -> IO ()
hook (Case _ mode seen used reached release _ _) stage = do
 atomicModifyIORef' seen (\xs -> (stage:xs,()))
 let wanted = case mode of
      BeforeObservation -> stage=="persistent-before-leader-observation"
      ReturnedObservation -> stage=="qa-leader-observe-group-return"
 whenWanted wanted
 where
  whenWanted False = pure ()
  whenWanted True = do
   first <- atomicModifyIORef' used (\old -> (True,not old))
   if first then putMVar reached () >> readMVar release else pure ()

-- Production stop executes on a strongly retained worker, with a barrier so
-- its ThreadId is published before dispatch. The supervisor never kills it.
launchStop :: IORef (Maybe ThreadId) -> IORef (Maybe (MVar (Either SomeException StopReceipt))) -> PersistentOwner -> StopBudget -> AdmissionDeadline -> AdmissionDeadline -> IO (MVar (Either SomeException StopReceipt))
launchStop retained retainedDone owner budget originalD implicitD = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 writeIORef retainedDone (Just done)
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar start
   a <- remainingMicros originalD
   b <- remainingMicros implicitD
   check "existing deadlines live before stop entry" (min a b>0)
   requestSessionStop owner budget
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 writeIORef retained (Just tid)
 putMVar start ()
 pure done
waitExisting :: [AdmissionDeadline] -> String -> MVar a -> IO a
waitExisting bounds label done = do
 left <- minimum <$> mapM remainingMicros bounds
 if left<=0 then ioError (userError (label ++ ": Unknown; retain guardian")) else do
  value <- timeout left (readMVar done)
  maybe (ioError (userError (label ++ ": Unknown; retain guardian"))) pure value
awaitFirst :: PersistentOwner -> AdmissionDeadline -> AdmissionDeadline -> IO AdmissionDeadline
awaitFirst owner originalD implicitD = do
 a <- remainingMicros originalD
 b <- remainingMicros implicitD
 check "existing D elapsed before first StopD observation" (min a b>0)
 state <- tryPersistentStopDeadline owner
 case state of
  StopDeadlineLatched d -> pure d
  StopDeadlineFailed _ -> ioError (userError "actual first StopD failed")
  _ -> threadDelay (min 1000 (min a b)) >> awaitFirst owner originalD implicitD

-- Run on a retained supervisor, never the owner worker. Host starts the real
-- selected live child, verifies actual SessionObservation/identity, and puts
-- the actual withPersistentOwnerHook result into done. A missing real implicit
-- no-explicit-stop route or missing group hook fails, rather than forging D.
-- A separate pre-existing ExitRaceControls ordinary live-child case remains
-- the positive production route; this function is the two negative schedules.
finishCase :: Case -> AdmissionDeadline -> StopBudget -> MVar (Either SomeException (Either SessionExit ((),SessionExit))) -> IO ()
finishCase c@(Case owner mode seen _ reached _ worker retainedDone) originalD budget done = do
 within originalD "actual observation barrier" (readMVar reached)
 initialStop <- tryPersistentStopDeadline owner
 implicit <- tryPersistentCleanupDeadline owner
 implicitD <- case implicit of
  CleanupDeadlineSelected d -> pure d
  _ -> ioError (userError "real implicit containment D not selected")
 check "first explicit stop not yet requested" (initialStop==StopDeadlineNotLatched)
 before <- reverse <$> readIORef seen
 let count x = length (filter (==x) before)
 check "actual nonvacuous group schedule" $ case mode of
  BeforeObservation -> count "persistent-before-leader-observation"==1 && count "qa-leader-observe-group-entry"==0
  ReturnedObservation -> count "qa-leader-observe-group-entry"==1 && count "qa-leader-observe-group-return"==1
 stopDone <- launchStop worker retainedDone owner budget originalD implicitD
 firstD <- awaitFirst owner originalD implicitD
 let chosen = StopDeadlineLatched firstD
 receipt <- waitExisting [originalD,implicitD,firstD] "actual first stop receipt" stopDone >>= either throwIO pure
 firstNs <- absolute firstD
 implicitNs <- absolute implicitD
 check "actual first StopD is strictly tighter" (receipt==StopNoLiveSession && firstNs<implicitNs)
 awaitExpired originalD firstD
 releaseBarrier c
 result <- within originalD "actual owner completion observation" (readMVar done)
 events <- reverse <$> readIORef seen
 after <- tryPersistentStopDeadline owner
 status <- within originalD "read-only owner status" (persistentStatus owner)
 custody <- persistentPidfdCustody owner
 check "late/no-entry observation cannot authorize signal or clean receipt" $
  after==chosen && "persistent-before-leader-kill" `notElem` events &&
  (case result of Right (Left (ExitUncertain CleanupUncertain _)) -> True; _ -> False) &&
  (case status of PersistentQuarantined _ -> True; _ -> False) &&
  (case custody of PidfdKnownOpen _ _ -> True; _ -> False) &&
  case mode of
   BeforeObservation -> "qa-leader-observe-group-entry" `notElem` events
   ReturnedObservation -> length (filter (=="qa-leader-observe-group-return") events)==1
-- The group may contain several open/read/readlink calls; these observations
-- cannot prove any individual syscall was skipped or canceled. A returned
-- late group is unknown, not a clean receipt, and the real child remains in
-- the guardian's custody. No physical/native/whole cleanup acceptance.
