# Converged Persistent Custody Foundation `v17` (`r2`, `012747Z`)

- **Canonical `HEAD`**: `05dc05572817d9821132ef6e29100efe8046f418` (`19/242` requirements, `42/417` scenarios; `DEL-010` independently accepted on `02b0aba0b128a184177dc166450c5302b017c50e`; zero native/GUI/provider/AT/IME/hardware/release acceptance claimed).
- **Verification Scope**: Source-only static audit (`PROD_NO_MACROS` + `QA_MACROS` CPP/delimiter/tab/CR checks across 239 module modes) and isolated `patch -p1 --fuzz=0` / `git apply --check` verification across all three stacks below. **Zero compiler, test, Quint, VM, GPU, or native execution performed by worker.**

## 1. Frozen `v17` Patch Artifacts (Preserving `v10`..`v16` Immutable)

| Artifact | Exact Disk SHA-256 | Purpose |
| --- | --- | --- |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v17-012747Z.patch` | `0e3b54a28eb4c9373e4f17d719b2c271a3df80cfe51df9eb98b7adb313ca5fa9` | Single self-contained 12-file production patch (`held-document` + `process-custody`) on `05dc05572817d9821132ef6e29100efe8046f418`, byte-identical to applying `v15` + 12 reviewed `terra-engine`/`terra-security` patches (`957021a6`..`fd59a20a`) |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v15-to-v17-delta-012747Z.patch` | `56621de63571aa09d2e2451b50d6d2488598b30a3e28fb7cb6f5ba5d670f3f4f` | Exact 6-file delta from frozen `v15` (`36ada0d60068d39f536abb16d4de9e7d345d0909adefcc494348ad5f76ba9d23`) to `v17` |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-owner-gate-qa-seam-v17-012747Z.patch` | `a56b8cd6976f638ce70019efce36ff9681019063cbfd39c883c59a33f26c5ea1` | Rebased `WARLOCK_OWNER_QA` seam for `Owner.hs` + `process-custody.cabal` (replaces `0c387d71`, which failed `--fuzz=0` on `Owner.hs` export header after `186d2baa`; preserves exact Cabal postimage `483a076d351046ffa72563f996f6987e3a8a14d7b2172673aea32b3ae973db89`) |

## 2. Minimal Reviewed Production Foundation Sequence (`--fuzz=0`)

Excludes `terra-portable-bootstrap-cleanup-004.patch` and `Backend` runtime wiring (`001`..`008`):

1. `gemini-omarchy-persistent-custody-prereqs-v17-012747Z.patch` (`0e3b54a28eb4c9373e4f17d719b2c271a3df80cfe51df9eb98b7adb313ca5fa9`)
2. `terra-engine-lexical-ingress-integration.patch` (`74b07921d42d7a9ef2d7c58fe0365964ceeb5fe58294d6049d96400fe3192783`)
3. `terra-q-front-context-ingress-001.patch` (`c9fe0c1ac30e5775fd963b5e0508711c4fee79074253a183a50f66ea985834f5`)
4. `terra-q-front-owned-ingress-001.patch` (`51f9669976294b69d68c91b6bed8dfe7e59e750710c21ca8f028a1110387c014`)
5. `sol-outbound-pin-rebase-001.patch` (`33c3f67c74b62067188539e4bdd192ff149d8a5a327e48ef4f0e913aaea97815`)
6. `sol-store-acquisition-settled-v3-0140.patch` (`bdaa2f8b1272129aa3b745bf2621c727b1379ff55a258713603937f5f540c951` — apply on clean committed HEAD; skip if already applied in working tree)

## 3. Full QA Seam + Suite Overlay Sequence on `v17` (All 9 Overlays Verified `--fuzz=0`)

1. `gemini-omarchy-owner-gate-qa-seam-v17-012747Z.patch` (`a56b8cd6976f638ce70019efce36ff9681019063cbfd39c883c59a33f26c5ea1`)
2. `terra-engine-preowned-caller-qa-seam-002.patch` (`bb5e3bc4fc540b290d5808ce67b6622d89559705245c372e9487c49b6e44b294`)
3. `terra-security-v11-owner-abort-race-qa-seam.patch` (`4e1f1d876fa823968b6524315d11aebb06080d9729b688b4d973c8e6ed38389e`)
4. `terra-security-preowned-final-qa-seam-003.patch` (`89d42d8474aebc4b4e696e0deabda96e159b990f04ed132672f0ae832ade5185`)
5. `terra-graph-retained-fixture-qa-overlay-0031.patch` (`8fecc177272151059dfd0ca1acff2c075b33b1b1a2eaae3ffea776cedbcb8716`)
6. `terra-engine-held-preowned-qa-003.patch` (`75e53e92c59d0ffa3a983dfab71b414d5ab474c5c988de528277fa7996395025`)
7. `terra-engine-preowned-transition-suite-001.patch` (`c9beaeb3025cb536d04baa91e7b4bd385889e0ea53bd3e7f87682281c74c4f26`)
8. `terra-engine-preowned-exception-suite-001.patch` (`fbfcdcc58738bbca85cb0864bbd1973317cf2bd340a8dd4ac2609e6c12cf1cb5`)
9. `terra-engine-preowned-finish-gates-suite-001.patch` (`e42335b5b7f1e0b5c6dcc5867dbff05d4a8bacd3d6427970d5c9372fecf935b9`)

## 4. Open Boundaries & Non-Claims

- `terra-security-owner-pending-observer-001.patch` (`52aa80b052940c486fc9c5b40ed32e4bc8a09bce3941f8ee55bf90e9e1d8edc5`) remains excluded per `terra-security`'s `HOLD` notice.
- In-flight kernel `close`/`hClose` syscalls completing after `StopD` preserve `ExitUncertain CleanupUncertain` (`Unknown`) without claiming clean retirement; no universal physical stop gate is claimed.
- Root-only compiler, test suite, Quint model, guardian, and VM/native verification remain required.
