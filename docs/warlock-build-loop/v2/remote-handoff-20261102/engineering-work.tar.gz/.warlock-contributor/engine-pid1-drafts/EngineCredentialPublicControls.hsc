{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE OverloadedStrings #-}
#define _GNU_SOURCE 1
#include <sys/socket.h>
#include <sys/uio.h>
#include <unistd.h>
-- PREPARATION DRAFT, UNCOMPILED/UNEXECUTED. Protocol test executable imports
-- only PUBLIC Warlock.Protocol.EngineTransport / PeerCredential, not private
-- Warlock.Transport internals, fabricated PeerCredential, or asserted PID.
-- Run only under root's isolated, bounded component runner after review.
-- These are kernel-reader controls, not proof EngineBroker/EngineCustody wiring,
-- private PID namespaces, parent lineage, EARS, native acceptance or release.
module Main (main) where

import Control.Exception (bracket, finally)
import Control.Monad (unless)
import qualified Data.ByteString as B
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import Foreign
import Foreign.C
import System.Directory (listDirectory)
import System.Exit (ExitCode(..))
import System.Posix.IO (createPipe, closeFd)
import System.Posix.Process (ProcessStatus(Exited), forkProcess, getProcessID, getProcessStatus, exitImmediately)
import System.Posix.Types (Fd(..))
import System.Posix.User (getRealUserID, getRealGroupID)
import System.Timeout (timeout)
import qualified Warlock.Protocol.EngineTransport as Transport
import qualified Warlock.Protocol.PeerCredential as Credential

foreign import ccall unsafe "sendmsg" c_sendmsg :: CInt -> Ptr () -> CInt -> IO (#{type ssize_t})

check :: String -> Bool -> IO ()
check label value = unless value (ioError (userError label))

withPair :: ((S.Socket,S.Socket) -> IO a) -> IO a
withPair = bracket (S.socketPair S.AF_UNIX S.Stream S.defaultProtocol)
  (\(receiveSocket,sendSocket) -> S.close receiveSocket `finally` S.close sendSocket)

-- The root-selected wrapper's original component deadline bounds the whole
-- test; this inner bound prevents a missing send from being mistaken for EOF.
receiveOne :: Transport.CredentialReader -> S.Socket -> IO (Either Transport.CredentialError Transport.CredentialChunk)
receiveOne reader socket = do
  result <- timeout 2000000 (Transport.receiveCredentialChunk reader socket 1)
  case result of Nothing -> ioError (userError "receive timed out"); Just value -> pure value

-- Parent is the only reaper of this exact child. Child's send is one byte and
-- process exits; PID stays owned/unreaped during receive. No wildcard waits.
withSendingChild :: S.Socket -> B.ByteString -> (Integer -> IO a) -> IO a
withSendingChild socket byte action = bracket
  (forkProcess (N.sendAll socket byte >> exitImmediately ExitSuccess))
  (\pid -> do status <- getProcessStatus True False pid
              check "child exit not observed successful" (status == Just (Exited ExitSuccess)))
  (action . toInteger)

actualCredential :: Either Transport.CredentialError Transport.CredentialChunk -> IO (B.ByteString,Credential.PeerCredential)
actualCredential result = case result of
  Right (Transport.CredentialChunk bytes actual) -> pure (bytes,actual)
  _ -> ioError (userError "expected actual kernel credentials")

-- A pre-fork socketpair's creator SO_PEERCRED is not the later child's sender
-- PID. One actual parent chunk and then a child chunk on the same stream also
-- provide two different kernel credentials: consumers must reject one frame
-- that mixes them. This test observes the public reader, not Broker refusal.
actualChildAndChangedFragment :: IO ()
actualChildAndChangedFragment = withPair $ \(incoming,outgoing) -> do
  Transport.enablePassCredentials incoming
  reader <- Transport.newCredentialReader
  parent <- toInteger <$> getProcessID
  uid <- toInteger <$> getRealUserID
  gid <- toInteger <$> getRealGroupID
  N.sendAll outgoing "a"
  first <- receiveOne reader incoming >>= actualCredential
  withSendingChild outgoing "b" $ \child -> do
    second <- receiveOne reader incoming >>= actualCredential
    let (firstBytes,firstCred) = first
        (secondBytes,secondCred) = second
    check "parent sender credential" (firstBytes == "a" && Credential.credentialPid firstCred == parent
      && Credential.credentialUid firstCred == uid && Credential.credentialGid firstCred == gid)
    check "child actual positive sender credential" (child > 0 && child /= parent && secondBytes == "b"
      && Credential.credentialPid secondCred == child && Credential.credentialUid secondCred == uid
      && Credential.credentialGid secondCred == gid)
    check "mixed frame must be distinguishable" (firstCred /= secondCred)
    reusable <- Transport.credentialReaderReusable reader
    check "successful reader reusable after sole receive quiesces" reusable

-- Kernel rights are real. All cmsghdr lengths and offsets come from the same
-- host headers as the receive reader. The source pipe remains ours: received
-- copies must be refused and retired by the reader's own ledger.
sendRight :: S.Socket -> Fd -> IO ()
sendRight socket (Fd ownedFd) = S.withFdSocket socket $ \fd ->
 allocaBytes 1 $ \payload -> allocaBytes #{size struct iovec} $ \iov ->
 allocaBytes #{size struct msghdr} $ \msg -> allocaBytes #{const CMSG_SPACE(sizeof(int))} $ \control -> do
  fillBytes iov 0 #{size struct iovec}
  fillBytes msg 0 #{size struct msghdr}
  fillBytes control 0 #{const CMSG_SPACE(sizeof(int))}
  poke payload (120 :: Word8)
  #{poke struct iovec, iov_base} iov (castPtr payload :: Ptr ())
  #{poke struct iovec, iov_len} iov (1 :: CSize)
  #{poke struct msghdr, msg_iov} msg (castPtr iov :: Ptr ())
  #{poke struct msghdr, msg_iovlen} msg (1 :: CSize)
  #{poke struct msghdr, msg_control} msg (castPtr control :: Ptr ())
  #{poke struct msghdr, msg_controllen} msg (fromIntegral (#{const CMSG_SPACE(sizeof(int))} :: Int) :: CSize)
  #{poke struct cmsghdr, cmsg_len} control (fromIntegral (#{const CMSG_LEN(sizeof(int))} :: Int) :: CSize)
  #{poke struct cmsghdr, cmsg_level} control (#{const SOL_SOCKET} :: CInt)
  #{poke struct cmsghdr, cmsg_type} control (#{const SCM_RIGHTS} :: CInt)
  pokeByteOff control #{const CMSG_LEN(0)} ownedFd
  sent <- c_sendmsg fd (castPtr msg) 0
  check "send actual SCM_RIGHTS" (sent == 1)

-- FD-count oracle requires isolated single-thread fixture: no unrelated FD
-- opens/closes in the sampling window. A count mismatch is a failure, not an
-- attempt to close unrecognized FDs. Public reusable status is only a quiescent
-- reader observation; it does not prove whole-process cleanup or child exit.
rightsRefused :: IO ()
rightsRefused = withPair $ \(incoming,outgoing) -> do
 Transport.enablePassCredentials incoming
 reader <- Transport.newCredentialReader
 bracket createPipe (\(a,b) -> closeFd a `finally` closeFd b) $ \(pipeRead,_) -> do
  before <- length <$> listDirectory "/proc/self/fd"
  sendRight outgoing pipeRead
  result <- receiveOne reader incoming
  after <- length <$> listDirectory "/proc/self/fd"
  check "real SCM_RIGHTS refused" (case result of Left Transport.RightsRefused -> True; _ -> False)
  check "no additional received descriptor retained" (before == after)
  reusable <- Transport.credentialReaderReusable reader
  check "known successfully closed rights leave reusable reader" reusable

missingCredentialRefused :: IO ()
missingCredentialRefused = withPair $ \(incoming,outgoing) -> do
 reader <- Transport.newCredentialReader
 N.sendAll outgoing "x"
 result <- receiveOne reader incoming
 check "no SO_PASSCRED refuses missing credentials" (case result of Left Transport.MissingCredential -> True; _ -> False)

main :: IO ()
main = do
 actualChildAndChangedFragment
 missingCredentialRefused
 rightsRefused

-- Further ROOT-ONLY controls, not represented by the above test: production
-- Broker public route actually rejects a frame whose header/body were written by
-- different processes and never calls an owner callback; actual EngineCustody
-- guard accepts the held live child and rejects a foreign same-UID writer, dead
-- or reused child, wrong user/mapping and expired D; an isolated PID-namespace
-- engine receiver observes PID 0 for the out-of-namespace broker but does NOT
-- treat 0/UID/GID as positive parent identity, and controls a different outside
-- sender with the same visible tuple to demonstrate the lineage limitation.
-- Use actual held executable, exclusive endpoint/lifeline and pre-fork
-- SO_PASSCRED; no user namespace/unshare or PID0 observation is assumed here.
-- Duplicate/malformed ancillary parser cases require the existing private
-- synthetic parser fixture: no claim that a conforming kernel emitted them.
-- Readiness observations never reset the original deadline or failed history.
