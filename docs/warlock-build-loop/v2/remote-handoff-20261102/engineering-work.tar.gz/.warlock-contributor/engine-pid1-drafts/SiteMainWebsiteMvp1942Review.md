# `SiteMainWebsiteMvp1942v3.patch` — Preimage, Behavior & Independent Review Note (`gemini-site`, `1942` Wave)

## 1. Exact Custody & Hash Summary

| Artifact / File | Role | Exact SHA-256 |
| --- | --- | --- |
| `/home/charl/code/Warlock/site/src/SiteMain.elm` | Protected foreign-dirty preimage (**untouched on disk**) | `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` |
| `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteMvp1942v3.patch` | **Recommended final ignored Elm homepage patch** (supersedes `1924` `SiteMainTeaProtected05.diff` `e006272c...` and intermediate `1942` `v1`/`v2` drafts) | `5c75ddc00e483a98de6244dbe164d1cc72e8b402d4b8383c56f6f021c3c79206` |
| Prospective `site/src/SiteMain.elm` postimage (after `SiteMainWebsiteMvp1942v3.patch`) | Prospective postimage if Root applies `v3` | `7a53bbef424813c5fad3107d274df33e63d0845ad28df2182865e1dd73a3283f` |
| `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteMvp1942v2.patch` | Preserved intermediate `1942` revision (`terra-browser` `.wl-feature-link` + `.wl-band` CSS fix, postimage `b06408da34f13c14f7d11adce4a55dfb1a60da42f2777d0d7d5dc5489c96abc1`) | `ff2be97c8ebbf3579f61338936ab553110d5a742ab124357941be345c663b88b` |
| `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteMvp1942.patch` | Preserved initial `1942` revision (postimage `860603a42aecda44d533d05118066f9de74a586a6268434d739090c87fc4195c`) | `351761453e4e0f1460bcc071aee66383fa24fa8cea47fe0b3e96a66b0bd36d10` |

- **Non-execution & custody boundary**: No Elm/Haskell compiler, Node/browser runtime, Quint check, VM, or native command was executed by `gemini-site`. `/home/charl/code/Warlock/site/src/SiteMain.elm` (`f05a3768...`) and all canonical files remain completely untouched. Source patch and source-only reviews do not establish compiled/rendered geometry, keyboard/AT runtime behavior, or native/release acceptance.

---

## 2. Exact Behavior & Visual-Hierarchy Delta Against `site/src/SiteMain.elm` (`f05a3768...`)

1. **100% Elm & Established Lacquer v1 Preservation**:
   - Retains `Browser.element`, `Model`, `Msg`, `init`, `update`, all 8 desktop surface specs, ARIA `tablist` + Left/Right/Home/End keyboard roving focus, category filter bar, interactive cue check, interactive causality check, and full 35-route site directory.
   - Zero new JavaScript, zero new design system; consumes only shared `site/assets/shared/{layers,tokens,fonts,site,glyphs,landing,effects}.css` (`--wl-sys-*`).
2. **Hero Entry Points & Clutter-Free Scope Callout (`viewHero`)**:
   - Primary CTA: `"Try in browser (simulated)"` -> `./test-drive/index.html` (runs immediately in browser).
   - Secondary CTA: `"Build from source & status"` -> `#scope`.
   - Tertiary CTA: `"Explore 8 surfaces"` -> `#workbench`.
   - Replaces raw internal ticket codes (`ELM-ARC-024 / ELM-DEL-014`) and stale `15` count in `.wl-hero-note` with clear, structured callout prose separating the simulated browser test drive from the experimental source-built Omarchy MVP (`16` whole requirements and `40` of `417` scenarios accepted on tested source; native window controls, provider cleanup, and packaged install remain open).
3. **Runnable Entry vs Experimental Source Build & Accurate `16 / 242` · `40 / 417` Counts (`CardSpec`, `scopeCards`, `readinessTiers`, `viewScopeSection`, `viewScopeCard`)**:
   - Extends `CardSpec` with `ctaLabel : String` and `ctaHref : String` and renders a bottom-aligned `.wl-home-card-foot` in each of the 4 `#scope` cards:
     1. **Browser test drive · Simulated desktop** -> `./test-drive/index.html` (`"Open simulated test drive"`).
     2. **Experimental native MVP · Build from source** -> `https://github.com/CharlesHoskinson/Warlock/blob/main/README.md#build-and-contribute` (`"Read build & source guide"`, explicitly stating Elm + Haskell only, no Python runtime ships, experimental source build while native window controls, provider cleanup, and compositor parity remain unqualified, and no packaged Omarchy installer ships yet).
     3. **Verified ledger · 16 / 242 requirements** -> `./architecture/index.html` (`"Explore Elm + Haskell architecture"`, recording `16 / 242` whole requirements and `40 / 417` scenarios accepted on tested source tuples including pure Elm update/effect replay, with private UI origin, AT/IME, hardware latency, and full native parity open).
     4. **Lacquer design system · Open source** -> `./get-started/index.html` (`"Get started & contributor docs"`).
   - Also adds direct build-doc links in `viewArchitectureSection` (`https://github.com/CharlesHoskinson/Warlock/blob/main/docs/warlock/how-to/build-current-frontend.md`) and `viewFooter` (`./get-started/index.html` and `https://github.com/CharlesHoskinson/Warlock/blob/main/docs/warlock/index.md`), and replaces raw ticket codes in `viewOutcomeLabCard` and `viewArchitectureSection` with plain, accurate human prose.
4. **Typography, Spacing, CSS Specificity & High-Contrast Polish (`supplementalCss`)**:
   - Explicit Lacquer display font (`--wl-sys-font-display`) and `text-wrap: balance` on `.wl-home-root :where(h1, h2, h3)`, monospace token on `:where(code, kbd)`, comfortable `58ch–66ch` reading measure and `1.55–1.6` line-height.
   - Symmetrical `4 -> 2 -> 1` `.wl-home-readiness-strip` and `2 -> 1` `.wl-home-root .wl-band .wl-home-scope-grid` (matching `.wl-band .wl-doc-grid` specificity in `landing.css` at both desktop and `<= 900px` breakpoints).
   - `min-height: 2.5rem` (`40px`) on `.wl-home-chip`, `.wl-home-root .wl-doc-button`, and `.wl-home-root .wl-feature-link` (`width: fit-content; padding: 6px 2px`).
   - Explicit `[data-theme="high-contrast"]` solid `#000000` surfaces, `#FFFFFF` borders (`.wl-doc-header`, `.wl-hero-note`, `.wl-band .wl-doc-card`, `.wl-home-card-foot`), `#00FFFF` pressed chip indicator, and `@media (forced-colors: active)` `CanvasText`/`Highlight` borders.

---

## 3. Static Verification & Independent Peer Source Reviews

- **Static checks verified in scratch**:
  - `git -C /home/charl/code/Warlock apply --check` exits `0`.
  - Forward (`patch -p1`) and reverse (`patch -R -p1`) round-trip byte-for-byte between `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` and `7a53bbef424813c5fad3107d274df33e63d0845ad28df2182865e1dd73a3283f`.
  - Balanced Elm delimiters (`()`, `[]`, `{}`), balanced CSS braces in `supplementalCss`, all 7 imports used, zero Elm 0.19 variable shadowing collisions.
  - All 71 relative `./...` site routes/assets exist under `/home/charl/code/Warlock/site/`, all `#anchor` targets (`#main`, `#scope`, `#workbench`) match `Attr.id` in `SiteMain.elm`, and all 3 GitHub `main` doc paths (`README.md`, `docs/warlock/how-to/build-current-frontend.md`, `docs/warlock/index.md`) exist on disk.
- **Independent UX source review (`terra-browser`)**:
  - `01M6CAT0EV0ZT2T7W9CQWRFD61`: Reviewed `v1` (`35176145...`) against `landing.css` and `site.css`; confirmed simulated-browser vs source-built product separation, responsive grids, wrapping, forced-colors, focus-visible, and `README.md#build-and-contribute` anchor, and flagged `.wl-feature-link` lacking `2.5rem` min-height.
  - `01M6CAZCT19ZXJ0Z6YKAZ2WY68`: Confirmed `v2` (`ff2be97c...`) adds `min-height: 2.5rem` and padding to scoped `.wl-feature-link` and preserves matching-specificity `1fr` `.wl-home-scope-grid` at `<= 900px` (retained identically in `v3` `5c75ddc0...`).
- **Independent documentation/copy review (`sol-docs`)**:
  - `01M6CAWMP6A14M85F47M7WAYS6`: Reviewed `v1` (`35176145...`); confirmed `16 / 242` whole and `40 / 417` scenarios, simulated fixture vs native/source-build separation, and current frontend build doc links, and suggested qualifying the source-built MVP as experimental with native window controls and provider cleanup still unqualified — folded directly into `v3` (`5c75ddc0...`).

---

## 4. Carried-Forward `ELM-TEA-001` (`CapturedAction`) & Peer Review Confirmations

- **Queued `gemini-site` `ELM-TEA-001` patch (unchanged from `1924` wave)**:
  - Patch: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/Tea001CapturedActionAdt.patch` (`sha256:2e6a48ec7fa576fec647aa9ea27e25f219ddc095dd01418219e6e90dc0bd157f`).
  - Exact verified canonical preimage SHA-256s (`sha256sum`):
    - `implementation/warlock/src/CapturedAction.elm`: `5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc`
    - `implementation/warlock/src/Presentation.elm`: `745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396`
  - Exact invariant note (confirming `terra-portable` `01M6CAFWZDWR2C97YCECEB8W6D`): `CapturedAction.decode` enforces `publication /= UInt64.zero` while allowing `lease : UInt64.Counter` including `0` (valid bar `lease = 0`), with exact `publication`, `lease`, `Surface` (`Bar | Popup`), and enabled-control matching enforced by `Presentation.dispatch`.
  - Confirmed 100% compatibility with `terra-q-network`'s final canonical QA extension `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/CapturedActionBoundaryReplay.elm` (`sha256:621ad00ab5ba989277814c516bae625b6710c19ea8b980c329f4ac8ec8ea3205`).
- **Completed peer source reviews for `terra-browser`**:
  - Reviewed `terra-browser-pending-query-feedback.patch` (`sha256:d38d4d64a3574a1bdccd2cc159ead7fccfb1f4b0e36be8bb99d68d2935b39f25`) and `terra-browser-pending-query-browser-test.mjs` (`sha256:2df6ef2b2f091bb6b136e1a3f133daed68d872f7550820aa94028d5c6ab9a482`): zero overlap, keyed DOM identity and `SurfaceSnapshot.encode` authority preserved, and synthetic event/effect sequencing matches `SurfaceSnapshot.decode` + `Presentation.query` + `Popup.transition`.
