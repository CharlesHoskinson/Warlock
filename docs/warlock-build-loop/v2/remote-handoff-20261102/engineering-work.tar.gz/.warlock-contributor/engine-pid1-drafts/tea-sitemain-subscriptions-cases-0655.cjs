'use strict';

/*
 * Independent ELM-TEA-004 (tea-subscriptions) literal oracle for the 9th
 * Browser.element root (`0655` gated pendingFocus + PendingFocusFrame):
 *   site/src/SiteMain.elm + site/src/SiteBetaStatus.elm
 * Proves:
 * 1. Tab/Escape transitions set `pendingFocus = Just (...)` and activate
 *    `subscriptions = [ PendingFocusFrame ]` (`onAnimationFrameDelta`) while
 *    emitting `[]` effects (`Dom.focus` is NOT spawned immediately).
 * 2. Intervening unrelated controls (`StepSpotlight`, `ToggleMobileNav`,
 *    `CloseMobileNav`, `BetaStatusMsg`) clear `pendingFocus = Nothing` and drop
 *    `subscriptions` back to `[]` (`_Browser_cancelAnimationFrame`), preventing
 *    `Dom.focus` from ever being spawned even if a stale `FlushPendingFocus`
 *    is replayed.
 * 3. Bidirectional coalescing (`ArrowRight -> SelectSpotlight` and
 *    `SelectSpotlight -> ArrowLeft`) coalesces into a single `PendingSpotlightTab`
 *    and emits exactly one `FocusSpotlightTab` upon `FlushPendingFocus`.
 */

const empty = () => ({ $: '[]' });
const list = items => {
  let out = empty();
  for (let i = items.length - 1; i >= 0; i--) {
    out = { $: '::', a: items[i], b: out };
  }
  return out;
};
const none = () => ({ $: 'Nothing' });
const just = value => ({ $: 'Just', a: value });
const tag = name => ({ $: name });

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function equalLiteral(left, right) {
  if (Object.is(left, right)) return true;
  if (typeof left !== typeof right || left === null || right === null ||
      typeof left !== 'object' || Array.isArray(left) !== Array.isArray(right)) return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every((key, i) =>
    key === rightKeys[i] && equalLiteral(left[key], right[key]));
}

function cloneLiteral(value) {
  if (value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(cloneLiteral);
  const copy = {};
  for (const key of Object.keys(value).sort()) copy[key] = cloneLiteral(value[key]);
  return copy;
}

function literalPatches(given, patches) {
  const result = cloneLiteral(given);
  for (const change of patches) {
    let cursor = result;
    for (let i = 0; i < change.path.length - 1; i++) cursor = cursor[change.path[i]];
    const leaf = change.path[change.path.length - 1];
    if (!equalLiteral(cursor[leaf], change.before)) {
      throw new Error('unexpected literal before at ' + change.path.join('.'));
    }
    if (equalLiteral(change.before, change.after)) {
      throw new Error('noop literal change at ' + change.path.join('.'));
    }
    cursor[leaf] = cloneLiteral(change.after);
  }
  return result;
}

const betaState = (filter, mvpTrack, focusSeq, lastFocusMiss) => ({
  $: 'State',
  a: {
    filter: tag(filter),
    focusSeq,
    lastFocusMiss,
    mvpTrack: tag(mvpTrack),
  },
});

const pendingTab = (seq, surface) => ({ $: 'PendingSpotlightTab', a: seq, b: tag(surface) });
const pendingMobileToggle = seq => ({ $: 'PendingMobileNavToggle', a: seq });

const initialSiteState = () => ({
  model: {
    betaStatus: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
    category: tag('CategoryAll'),
    cues: {
      activeApplication: true,
      switcherCandidate: false,
      windowFocused: true,
    },
    lastTabFocusMiss: none(),
    mobileNavOpen: false,
    motion: tag('MotionStandard'),
    outcomeSample: tag('SampleObserved'),
    pendingFocus: none(),
    spotlight: tag('SurfaceTaskbar'),
    tabFocusSeq: 0,
    theme: tag('ThemeNight'),
  },
  subscriptions: empty(),
});

const siteEffects = items => ({ $: 'SiteStepEffects', a: list(items) });
const focusTabEffect = (seq, surface) => ({ $: 'FocusSpotlightTab', a: seq, b: tag(surface) });
const focusMobileToggleEffect = seq => ({ $: 'FocusMobileNavToggle', a: seq });
const betaFilterEffect = (seq, filter) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusFilterTab', a: seq, b: tag(filter) },
});
const betaMvpEffect = (seq, track) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusMvpTab', a: seq, b: tag(track) },
});

function buildGatedFocusCoalescingAndCancellationCase() {
  const s0 = initialSiteState();
  // 1. ArrowRight (KeyboardStepSpotlight +1): queues PendingSpotlightTab(1, SurfaceLauncher), activates [PendingFocusFrame], emits [] effects!
  const s1 = literalPatches(s0, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskbar'), after: tag('SurfaceLauncher') },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(1, 'SurfaceLauncher')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  // 2. Negative cancellation before rAF: StepSpotlight +1 -> SurfaceSwitcher clears pendingFocus = Nothing, drops subscriptions -> [] (_Browser_cancelAnimationFrame), emits []!
  const s2 = literalPatches(s1, [
    { path: ['model', 'spotlight'], before: tag('SurfaceLauncher'), after: tag('SurfaceSwitcher') },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(1, 'SurfaceLauncher')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 3. Forward coalescing: ArrowRight -> SurfaceTaskView (seq 3), then pointer SelectSpotlight SurfaceFiles (seq 4) before FlushPendingFocus
  const s3 = literalPatches(s2, [
    { path: ['model', 'spotlight'], before: tag('SurfaceSwitcher'), after: tag('SurfaceTaskView') },
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(3, 'SurfaceTaskView')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s4 = literalPatches(s3, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskView'), after: tag('SurfaceFiles') },
    { path: ['model', 'tabFocusSeq'], before: 3, after: 4 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(3, 'SurfaceTaskView')), after: just(pendingTab(4, 'SurfaceFiles')) },
  ]);
  // 4. FlushPendingFocus: clears pendingFocus -> Nothing, drops subscriptions -> [], emits ONLY FocusSpotlightTab(4, SurfaceFiles)
  const s5 = literalPatches(s4, [
    { path: ['model', 'pendingFocus'], before: just(pendingTab(4, 'SurfaceFiles')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 5. Inverse coalescing: pointer SelectSpotlight SurfaceSettings (seq 5), then ArrowLeft -> SurfaceNotifications (seq 6), then FlushPendingFocus
  const s6 = literalPatches(s5, [
    { path: ['model', 'spotlight'], before: tag('SurfaceFiles'), after: tag('SurfaceSettings') },
    { path: ['model', 'tabFocusSeq'], before: 4, after: 5 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(5, 'SurfaceSettings')) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s7 = literalPatches(s6, [
    { path: ['model', 'spotlight'], before: tag('SurfaceSettings'), after: tag('SurfaceNotifications') },
    { path: ['model', 'tabFocusSeq'], before: 5, after: 6 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(5, 'SurfaceSettings')), after: just(pendingTab(6, 'SurfaceNotifications')) },
  ]);
  const s8 = literalPatches(s7, [
    { path: ['model', 'pendingFocus'], before: just(pendingTab(6, 'SurfaceNotifications')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  // 6. Current-seq Dom.NotFound recorded only in bounded internal diagnostic lastTabFocusMiss
  const s9 = literalPatches(s8, [
    { path: ['model', 'lastTabFocusMiss'], before: none(), after: just('wl-tab-notifications') },
  ]);

  return {
    name: 'sitemain-gated-pending-focus-cancellation-and-bidirectional-coalescing',
    worker: 'sitemain',
    given: s0,
    steps: [
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s1, effects: siteEffects([]) } },
      { input: { kind: 'step-spotlight', delta: 1 }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s3, effects: siteEffects([]) } },
      { input: { kind: 'select-spotlight', surface: 'files' }, expected: { state: s4, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s5, effects: siteEffects([focusTabEffect(4, 'SurfaceFiles')]) } },
      { input: { kind: 'select-spotlight', surface: 'settings' }, expected: { state: s6, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: -1 }, expected: { state: s7, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s8, effects: siteEffects([focusTabEffect(6, 'SurfaceNotifications')]) } },
      { input: { kind: 'tab-focus-settled', seq: 6, surface: 'notifications', missingDomId: 'wl-tab-notifications' }, expected: { state: s9, effects: siteEffects([]) } },
    ],
  };
}

function buildMobileNavAndBetaStatusCancellationCase() {
  const s0 = initialSiteState();
  const s1 = literalPatches(s0, [
    { path: ['model', 'mobileNavOpen'], before: false, after: true },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
  ]);
  const s2 = literalPatches(s1, [
    { path: ['model', 'mobileNavOpen'], before: true, after: false },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingMobileToggle(2)) },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s3 = literalPatches(s2, [
    { path: ['model', 'pendingFocus'], before: just(pendingMobileToggle(2)), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  const s4 = literalPatches(s3, [
    { path: ['model', 'lastTabFocusMiss'], before: none(), after: just('wl-home-nav-toggle') },
  ]);
  // Queue a tab focus, then cancel it via child BetaStatusMsg before FlushPendingFocus!
  const s5 = literalPatches(s4, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskbar'), after: tag('SurfaceLauncher') },
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
    { path: ['model', 'pendingFocus'], before: none(), after: just(pendingTab(3, 'SurfaceLauncher')) },
    { path: ['model', 'lastTabFocusMiss'], before: just('wl-home-nav-toggle'), after: none() },
    { path: ['subscriptions'], before: empty(), after: list([tag('PendingFocusFrame')]) },
  ]);
  const s6 = literalPatches(s5, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
      after: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
    },
    { path: ['model', 'tabFocusSeq'], before: 3, after: 4 },
    { path: ['model', 'pendingFocus'], before: just(pendingTab(3, 'SurfaceLauncher')), after: none() },
    { path: ['subscriptions'], before: list([tag('PendingFocusFrame')]), after: empty() },
  ]);
  const s7 = literalPatches(s6, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
      after: betaState('FilterOpenNativeGates', 'TrackProtectedCpu', 2, none()),
    },
    { path: ['model', 'tabFocusSeq'], before: 4, after: 5 },
  ]);

  return {
    name: 'sitemain-mobile-escape-and-beta-status-cancels-pending-tab-focus',
    worker: 'sitemain',
    given: s0,
    steps: [
      { input: { kind: 'toggle-mobile-nav' }, expected: { state: s1, effects: siteEffects([]) } },
      { input: { kind: 'escape-mobile-nav' }, expected: { state: s2, effects: siteEffects([]) } },
      { input: { kind: 'flush-pending-focus' }, expected: { state: s3, effects: siteEffects([focusMobileToggleEffect(2)]) } },
      { input: { kind: 'mobile-nav-focus-settled', seq: 2, missingDomId: 'wl-home-nav-toggle' }, expected: { state: s4, effects: siteEffects([]) } },
      { input: { kind: 'keyboard-step', delta: 1 }, expected: { state: s5, effects: siteEffects([]) } },
      { input: { kind: 'beta-select-filter', filter: 'native-gates' }, expected: { state: s6, effects: siteEffects([betaFilterEffect(1, 'FilterOpenNativeGates')]) } },
      { input: { kind: 'beta-keyboard-step-mvp', delta: 1 }, expected: { state: s7, effects: siteEffects([betaMvpEffect(2, 'TrackProtectedCpu')]) } },
    ],
  };
}

const SITE_MAIN_CASES = [
  buildGatedFocusCoalescingAndCancellationCase(),
  buildMobileNavAndBetaStatusCancellationCase(),
];

module.exports = {
  SITE_MAIN_CASES,
  initialSiteState,
};
