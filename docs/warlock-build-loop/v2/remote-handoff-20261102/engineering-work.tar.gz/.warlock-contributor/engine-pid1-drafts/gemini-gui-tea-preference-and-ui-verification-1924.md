# Independent Verification of Canonical Preference/UX TEA Corpus (`run06`), Whole `ELM-TEA-001` Finite-Type Inventory, and MVP UI / Accessibility / Focus / IME Preservation (`tea-final-1924`)

- **Author**: `gemini-gui` (`did:key:z6Mkrcc8RjEN24HqB6sSQoRcsSxfHrM8RWjMbAURibZF1Erc`)
- **Run**: `warlock-20261031-setup`
- **Observed UTC**: `2026-11-01T19:30:35Z` (governing cutoff `2026-11-01T19:58:00Z`)
- **Scope**: Pure static source verification of canonical `implementation/warlock/qa/tea-contract-cases.cjs`, Root's protected `run06` receipt (`tea-typed-state-20261101`), production Elm modules (`implementation/warlock/src/*.elm`), whole-frontend `ELM-TEA-001` (`tea-typed-model`) finite-type/authority inventory, and MVP UI usability/accessibility/focus/IME parity. **Component/source verification only — NOT native GUI, AT/IME runtime, or whole original EARS/release acceptance** (`15` historical whole / `39` scenarios of `242` / `417`, `nativeOperations = []`, `HOSTSTOP2` preserved).

---

## 1. Pinned Canonical Source & Evidence Tuple Verified

| File | SHA-256 | Role / Verification |
|---|---|---|
| `implementation/warlock/qa/tea-contract-cases.cjs` | `ab9d3f43d5bbe5b8588274e839d1530e145a68f92d651056a3a694b4735e7b59` | Canonical 58-case `DesktopPolicy` complete `Model`/`Effect` oracle (`2559` lines) |
| `implementation/warlock/qa/tea-contract.cjs` | `15597108de923405823578f89f2c667988f8602f12ddb68f449c365bb17319b8` | Reversible 85-byte `TEA_CONTRACT_OBSERVE_V1` runner (`2` fresh runs/case) |
| `implementation/warlock/qa/TeaContractReplay.elm` | `a63153fc341d548a4382f78f6de331da62dd0d4882bb28d0c4e7dfd20387ed13` | Owning `DesktopPolicy` worker harness |
| `implementation/warlock/qa/evidence/tea-typed-state-20261101/report.json` | `6e2124772c3a7f831633994ca963fa1536c88a3caa07827daece247f85b22e5d` | Protected `run06` (`elm-cpu-1793561026384253514`): **`passed: true`** (`19` commands, `58` cases, `134` tested transitions, `31` excluded preludes, `87` typed checks, `6` `--optimize` production roots) |
| `implementation/warlock/qa/evidence/tea-typed-state-20261101/review-packet.json` | `4a81b6c15239ba9f888166ddce65fdef4ce6122adf7a8f0aeb255eb0eaf46113` | Exact 129-input source hash manifest |
| `implementation/warlock/src/Desktop.elm` | `91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4` | Finite `SaveReceipt` / `ShortcutSaveReceipt` decoders (`lines 120–150`) & `Desktop.Incoming` |
| `implementation/warlock/src/Surface.elm` | `91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca` | `settingsControls`, `status`, and Bar/Popup projection |
| `implementation/warlock/src/Notifications.elm` | `e61311c370fc0367844deb21a9ba3274a64f41faabe19bec6743af71685e2201` | Finite `Urgency`, `EntryState`, `OutcomeStatus`, `Verb` ADTs |
| `implementation/warlock/src/JumpList.elm` | `2ef6dbc9738771b1e13c8d42feb70c0905be8651d791a43199264b32883de195` | Finite `ActionKind` (`DesktopAction \| RecentAction`) |
| `implementation/warlock/src/ReconciliationFrame.elm` | `5f9480ab13609f26a3f57f37431e9eb29c658b1c009b463321e0f277d37b8ac5` | Finite `ProofKind`, `RetirementOperation`, `GrantState` |
| `implementation/warlock/src/Main.elm` / `HttpMain.elm` | `a63de0a1...` / `58a3b1f2...` | Native-port and HTTP-transport `DesktopPolicy` effect interpreters |
| `implementation/warlock/src/Bar.elm` / `HttpBar.elm` | `aa3cd927...` / `74d4b6b8...` | Pure `Bar.step` taskbar renderer & transport wrappers |
| `implementation/warlock/src/Popup.elm` / `HttpPopup.elm` | `fb24afed...` / `4185692e...` | Pure `Popup.transition` popup renderer, IME `Composition`, & fail-closed HTTP preview gate |
| `implementation/warlock/src/SurfaceRenderer.elm` | `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98` | Accessible DOM rendering, injective DOM ID escaping, IME composition wiring |
| `implementation/warlock/src/Presentation.elm` | `745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396` | Publication/lease admission, `focusTarget`, and same-lease `localEdit` rebase |
| `implementation/warlock/src/Announcement.elm` | `a1e6660c082c7c68657e356c2e4742cd8fd60e843192b88fa0609fb696a40f9f` | Keyed `aria-live` (`polite`/`assertive`) status announcer |

---

## 2. Independent Verification of Integrated Preference & UX TEA Corpus (`run06`)

1. **Exact Integration & Zero Reducer Harvesting Confirmed**:
   - Canonical `implementation/warlock/qa/tea-contract-cases.cjs` (`ab9d3f43...`) integrates `gemini-gui`'s pure source-derived preference receipt factory (`lines 1417–2451`, matching frozen draft `e154e44c78ec453bd7dbed9dcf12220f381b39dfa7d520182031dffd6dc7ac57`) and `terra-browser`'s UX companion (`lines 2454–2543`, matching frozen draft `bebcc5a394cf97349ca6ec6cf384d1cb3bbba60a0d63f1fc75672c0a1220263f`) via `buildAdditionalCases` (`lines 2545–2557`).
   - Protected `run06` (`tea-typed-state-20261101/report.json`, `6e212477...`) passed on the first run with **zero failures and zero reducer output capture**:
     - `58` complete `Model`/every-`Effect` histories (`26` base + `6` pin + `10` prior additional + `7` `buildPreferenceReceiptCases` + `9` `buildPreferenceFeedbackCases`).
     - `134` tested non-prelude transitions (`101` prior + `24` preference + `9` UX) and `31` excluded setup preludes (`15` prior + `7` preference + `9` UX), each executed across `2` fresh worker runs.
2. **9-Event Reachable Prelude & Counter Alignment Verified**:
   - All `16` new cases (`7` preference + `9` UX) share `buildPreferenceSeeds`'s reachable 9-event prelude (`setup: 9`, `setupTimers: 0` at `lines 2070, 2112, 2149`):
     1. `view-topology` (`revision: "1"`, view `(7, 1)`) -> `publication: "1"`.
     2. `shell-attached` (`lifetime: "1"`, `session: "2"`, `frontend: "3"`) -> `publication: "2"`, `requestId: "1"`.
     3. `pointer-ownership` (`serial: "1"`, `state: "idle"`, `owner: null`) -> clears `PointerOwnership.blocked` (`Desktop.elm:621`, `PointerOwnership.elm:25–33`); `publication` advances `"4" -> "5"` while `Desktop.presentation` stays `"3"` (`Desktop.elm:946` returns `(next, [])` without `Desktop.advance`).
     4. `surface-action` `bar:settings` -> opens Settings (`lease: "1"`, `publication: "6"`, `requests: 2..5` for `shell-settings`, `motion-preferences`, `shortcut-preferences`, `projection-request`).
     5–7. Authoritative read snapshots (`shell-settings` rev `1`, `motion-preferences` rev `1` `System`, `shortcut-preferences` rev `1` + fingerprint `a`×64) -> `publication: "7".."9"`.
     8–9. Domain draft edit + `settings:save` / `settings:motion:save` / `settings:shortcuts:save` -> enters `pending` (`request: "5"`, `publication: "11"`, `Desktop.presentation: "3"`).
3. **Wire-Order & Incoming-Key-Order Soundness Verified**:
   - Outgoing `batch.wire` strings in `buildPreferenceSeeds` / `buildPreferenceReceiptCases` use `wireBinding` (`lifetime, session, frontend` matching `Binding.encode` at `Binding.elm:21–24`) and exact `Desktop.elm` / `Shell.elm` `E.object` field order.
   - Incoming events in `buildPreferenceFeedbackCases` (`lines 2518–2521`) pass `copy(bindingJson)` (`frontend, lifetime, session`); `Binding.decoder` (`Binding.elm:11–13`) sorts `Tuple.first` field names before decoding, and neither the `8` malformed cases (`NIL`) nor `ux-pending-settings-valid-unknown-is-distinct` (`requests: []`) registers a new `Batch`, so existing `batches` retain exact `wireBinding` serialization.

---

## 3. Whole-Frontend `ELM-TEA-001` (`tea-typed-model`) Finite-Type & Authority Inventory

Per `tea-typed-state-20261101/component-observation.json` (`line 196`), whole `ELM-TEA-001` adjudication requires an explicit inventory of retained custom ADTs, authoritative-observation separation, and any remaining finite `String` fields across `implementation/warlock/src/*.elm`:

### 3.1 Verified Custom Finite ADTs in Retained `Model`s
- **Root / Output / Surface / Shell / Window Lifecycle**:
  - `DesktopPolicy.Msg` (`Incoming | Deadline | TransportLost`) & `DesktopPolicy.Effect` (`Publish | Delay`) (`DesktopPolicy.elm:13–15`).
  - `OutputController.Scope` (`Scope Counter Counter`) & `Event` (`OutputController.elm:21,39`).
  - `SurfaceController.Event` & `Effect` (`SurfaceController.elm:19–20`); `ReconciliationFrame.ProofKind`, `RetirementOperation` (`Observe | Retire`), `GrantState` (`Granted | Retired`) (`ReconciliationFrame.elm:12–26`).
  - `Shell.Phase` (`Detached | Binding | Ready | Disconnected | Exhausted`) (`Shell.elm:32`).
  - `Effects.Operation` (10 constructors) & `Effects.Status` (`Pending | Committed | Refused | Cancelled | Unknown`) (`Effects.elm:12–13`).
  - `Launch.ResultState` (`Submitted | Refused | Unknown`), `Launch.Phase` (`Idle | Pending | Settled`), opaque `Model`/`PendingToken`/`Acknowledgement`/`Selection` (`Launch.elm:13–45`).
  - `WorkspaceNavigation.Status` (`Pending | Unknown | Committed | Refused`) (`WorkspaceNavigation.elm:10`).
  - `OverviewRecovery.Model` (`Idle | Choosing | Issued | Returning`) (`OverviewRecovery.elm:9`).
  - `PointerOwnership.State` (`Idle | Moving | Resizing`) (`PointerOwnership.elm:5`).
  - `Shortcuts.Route` (`Applications | System | Notifications`) (`Shortcuts.elm:5`).
  - `AdapterNotice.Source` (9 constructors) (`AdapterNotice.elm:9`).
- **Preferences, Pins, System, Files, JumpList, Notifications, Renderers**:
  - `Pins.Confirmation` (`Saving | Unconfirmed (Maybe Counter)`) (`Pins.elm:8`).
  - `Settings.Theme` (`Night | Dawn | HighContrast`) & `Settings.SaveOutcome` (`Saved | Refused | Unconfirmed`) (`Settings.elm:7,10`).
  - `Motion.Profile` (`Reduced | Full`) (`Motion.elm:9`) & `MotionPreferences.Override` (`System | Reduce | Full`) (`MotionPreferences.elm:7`).
  - `ShortcutPreferences.Choice` (`Undecided | Keep | Default | Alternate`) (`ShortcutPreferences.elm:7`).
  - `SystemMenu.Operation` (`Volume | Mute | Network | Suspend | Reboot | PowerOff | Lock | Logout`) (`SystemMenu.elm:7`).
  - `Notifications.Urgency`, `EntryState`, `OutcomeStatus`, `Verb` (`Notifications.elm:8–11`).
  - `JumpList.ActionKind` (`DesktopAction | RecentAction`) (`JumpList.elm:7`).
  - `Desktop.PopupOrigin` (`PointerEntry | KeyboardEntry`), `FocusDestination`, `ChoiceToken`, `ViewStamp`, `SaveReceipt`, `ShortcutSaveReceipt` (`Desktop.elm:104–122`).
  - `Popup.Composition` (`Idle | Preediting { baseline : String, before : Maybe String }`), `Popup.Effect`, `Bar.Effect` (`Popup.elm:19–21`, `Bar.elm:137`).

### 3.2 Remaining Closed-Vocabulary `String` Fields & String-Passed Receipt Boundaries (Concrete Audit List)
1. **Retained `Model` / `Snapshot` Fields Still Represented as Closed-Set `String`s**:
   - `ShortcutPreferences.Model.conflicts : List String` (`ShortcutPreferences.elm:12,67–73,87–91`): closed 3-route vocabulary `["applications","system","notifications"]` (with `label`, `choices`, `row`, and `edit` dispatching on `String` with `_ ->` fallback to `notifications` at `lines 46, 50, 54, 72`, whereas `Shortcuts.elm:5` already defines `type Route = Applications | System | Notifications`).
   - `Motion.Observation.source : String` (`Motion.elm:10,45`): decoder restricts to closed 2-element set `["portal","gtk"]`, retained in `Motion.Model.observation`.
   - `SystemMenu.Snapshot` capability/permission fields (`SystemMenu.elm:12–14,28–30`, retained in `SystemMenu.Model.snapshot`):
     - `network.permission : String` — restricted via `option ["yes","no","auth"]` (`line 28`).
     - `power.suspend`, `power.reboot`, `power.poweroff : String` — restricted via `option ["yes","no","na","challenge"]` (`line 29`).
   - `OutputController.Batch.observations : List (String, Counter)` (`OutputController.elm:37`): finite observation-kind tag paired with `requestId`.
   - `SurfaceSnapshot.Details.mode : String` (`12` closed modes validated at `SurfaceSnapshot.elm:48`) and `SurfaceSnapshot.Details.motion : String` (`["reduced","full"]` validated at `SurfaceSnapshot.elm:35`), retained in `Presentation.Model` (`Bar.Model` / `Popup.Model`).
   - *(Transient envelope, not retained in `Model`)*: `CapturedAction` (`CapturedAction.elm:8`) stores `surface : String` (`["bar","popup"]`) and `trigger : Maybe String` (`["pointer","keyboard"]`) behind an opaque constructor (`gemini-site` currently holds a draft claim on `Tea001CapturedActionAdt.patch`).
2. **String-Passed Outcome Boundaries in `Desktop.Incoming` (No Unguarded `Unknown` Coercion Remaining)**:
   - Unlike the pre-`d6fa51ec` preference bug (now closed by `saveReceiptDecoder` / `shortcutSaveReceiptDecoder` at `Desktop.elm:919,1059,1075`), **all remaining `Desktop.Incoming` outcome handlers reject unsupported status strings** before mutating state, though `5` child `receive` functions still accept `String` parameters rather than typed receipt ADTs:
     - `Settings.receive` (`Settings.elm:56`), `MotionPreferences.receive` (`MotionPreferences.elm:62`), `ShortcutPreferences.receive` (`ShortcutPreferences.elm:106`): called via `saveReceiptName` / `shortcutSaveReceiptName` from `Desktop.elm:925,1063,1079`.
     - `Pins.receive` (`Pins.elm:65`): guarded at `Desktop.elm:1100` (`List.member receipt.status ["Saved","Refused","Unknown"]`).
     - `JumpList.receive` (`JumpList.elm:46–49`): guarded by `List.member status ["Submitted","Refused","Unknown"]` (`Desktop.elm:980`).
     - `Files.receive` (`Files.elm:52–56`): guarded by `List.member status ["Opened","Refused","Unknown"]` (`Desktop.elm:998`).
     - `SystemMenu.receive` (`SystemMenu.elm:73–76`): guarded by `List.member status ["Committed","Submitted","Refused","Unknown"]` (`Desktop.elm:1016`).
     - `Notifications.receiveReason` (`Desktop.elm:1043–1048`): `"reason"` validated against `["","expired","changed","unavailable","already-handled"]` and `"status"` decoded inside `Notifications` into `OutcomeStatus`.

---

## 4. MVP Usability, Pending/`Unknown`/Recovery Guidance, Accessibility, Focus & IME Verification

1. **Pure TEA Effect Separation & Native-Port / HTTP-Transport Parity (`ELM-TEA-002`)**:
   - `Main.elm` (`1–29`) and `HttpMain.elm` (`1–55`) interpret the exact same pure `DesktopPolicy.update : Policy.Msg -> Policy.Model -> (Policy.Model, List Policy.Effect)`. `HttpMain.lost` (`lines 15–18`) maps `UiHttp.Lost` strictly to `Policy.TransportLost` (`"host-disconnected"`), never rebinding, retrying a mutation, or synthesizing receipts.
   - `Bar.elm` (`134–170`) and `HttpBar.elm` (`16–50`) share pure `Bar.step` (`Dispatch` + `ResetStatusViewport`).
   - `Popup.elm` (`35–145`) and `HttpPopup.elm` (`19–63`) share pure `Popup.transition` and `Popup.view`; `HttpPopup.supported` (`lines 19–24, 33–35`) fails closed (`UiHttp.stop` + `role="alert"`) on any non-empty native `PreviewCommand` or `PaintRequest`.
   - Zero domain state or optimistic native truth resides in `Bar`, `Popup`, `HttpBar`, `HttpPopup`, `Presentation`, `SurfaceRenderer`, or `Announcement`.
2. **Canonical Pending / `Unknown` / Refused / `Stored` Recovery Guidance**:
   - Across `Settings`, `MotionPreferences`, `ShortcutPreferences`, `Pins`, `Files`, and `SystemMenu`, `pending /= Nothing` disables mutation controls (`enabled = False`, `aria-disabled="true"`) while keeping read-only `Refresh` actions enabled and surfacing `"Saving …"` in both `role="status"` and `settings-save-caption-*` (`aria-describedby` on `settings:save`, `settings:motion:save`, `settings:shortcuts:save` at `SurfaceRenderer.elm:103–105,129`).
   - Valid `"Unknown"` outcomes preserve `pending` (blocking duplicate writes) and display explicit non-replay guidance (`"… save not confirmed. Refresh to read the stored values; this write will not be repeated."`). Subsequent higher-revision read snapshots reconcile `pending` cleanly (`ShortcutPreferences.observe` at `lines 85–99` distinguishes `settled` live-matched saves from per-route `conflicts` while preserving user `draft`; `ShortcutPreferences.receive` at `lines 110–113` distinguishes `"Saved"` from `"Stored"` when disk persisted but live bindings changed).
3. **Accessible Names, Roles, States, Visual Tokens & Live Regions**:
   - `SurfaceRenderer.elm:52–72,90–97` injectively escapes reserved `StatusScroll` / `surface-control-` prefixes (`escapeControlDomId`) and computes collision-free `preview-description-*` and `settings-save-caption-*` IDs (`findNonCollidingPrefix`).
   - Every rendered control carries explicit `aria-label` (`item.ariaLabel`), semantic `role` (`button`, `option` inside `role="listbox"` for switcher, `menuitem` / `menuitemcheckbox` inside `role="menu"` for window actions, `role="toolbar"` `"Warlock taskbar"` on bar), `aria-disabled`, `aria-current`, and mode-appropriate `aria-pressed` / `aria-checked` / `aria-selected` / `aria-expanded` (`SurfaceRenderer.elm:112–132,145–148`).
   - Search and Files path fields (`SurfaceRenderer.elm:124–132`) pair `<label for=...>` with `aria-label`, `autocomplete="off"`, `disabled (not item.enabled)`, and clear placeholders.
   - Theme and motion attributes (`data-theme`, `data-text-scale` `100/125/150/200`, `data-effects`, `data-reduced-transparency`, `data-motion` `reduced/full`) apply uniformly to both `.surface-popup` and `.surface-bar` (`SurfaceRenderer.elm:145–146`).
   - `Announcement.elm:27–48` validates exact `publication`, `lease`, and surface `recipient` before rendering a keyed `role="status"` live region (`aria-live="assertive"` iff `interrupt == True`, `"polite"` otherwise, `aria-atomic="true"`), driven solely by `OutcomeAnnouncements.observe`.
4. **Focus Routing & IME Preedit (`Popup.Composition`) Preservation**:
   - `Presentation.focusTarget` (`Presentation.elm:19–36`) restricts focus restoration to exact `(surface, publication, lease)` frames and controls with `enabled || focusOnly` (`focusOnly` capped at `<= 1` notification item in `SurfaceSnapshot.elm:48`, rendered without HTML `disabled` but with `aria-disabled="true"` and `data-focus-only="true"` so keyboard/AT focus is never dropped on item disablement).
   - Both `Popup.elm:129` and `HttpPopup.elm:54` suppress incoming `"focus"` commands whenever `composition /= Popup.Idle`, preventing background publications from stealing focus or aborting active IME composition.
   - `Popup.elm:72–108` + `Presentation.localEdit` (`Presentation.elm:72–81`) + `SurfaceSnapshot.pendingQuery` (`SurfaceSnapshot.elm:74–75`):
     - `compositionstart` and `input` (`isComposing == True`) hold `Preediting { baseline, before }`, expose `data-input-composing="true"`, keep `pendingQuery` local without emitting premature `surface-query` dispatches, disable `entry:*` and `files:*` open/launch triggers while composing or while `pendingQuery /= Nothing`, and restore `before` if composition cancels unchanged on `compositionend`.
     - Same-lease `Presentation.localEdit` rebases live input edits across advancing `publication`s within the same `lease`, preventing dropped keystrokes without relaxing exact-publication admission on external ports or button actions.
