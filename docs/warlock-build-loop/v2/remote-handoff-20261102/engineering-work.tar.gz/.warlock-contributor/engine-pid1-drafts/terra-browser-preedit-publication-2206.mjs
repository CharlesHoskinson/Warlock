// UNRUN browser-component regression for actual compiled HttpPopup -> Popup.
// Use a fresh isolated target and the controlled /events + /actions adapter;
// bind full source closure, compiler, generated HTML/JS, harness and this file.
// Injected presentations and synthetic composition are not producer, native
// keyboard/IME/AT, compositor presentation or input-to-photon evidence.
// Compare Sol's older narrow patch postimage 7126b495 (expected RED) against
// corrected a127e308 postimage 9761aa5d (expected GREEN); both are predictions
// until Root executes. The candidate patches share Popup preimage ebb12fa8.
// A POST 204 is transport completion, never authoritative query acceptance.
//
// Harness matches controlledPopupHttp 47ef21a0: assertSourceIdentity,
// assertNetworkIsolation, deliverPresentation, actions, waitForActionCount,
// respondAction, settleElm, evaluate, until and synchronous throwing check.
// Root supplies complete closure attestation, all-session network isolation,
// exclusive dispatcher, bounded CDP calls, overall deadline and cleanup.

export async function popupPreeditPublication2206({ assertSourceIdentity,
  assertNetworkIsolation, deliverPresentation, actions, waitForActionCount,
  respondAction, settleElm, evaluate, until, check, expectedPopupSha256 }) {
  const candidateHashes = [
    '7126b4950eaf8dbebf1aeb72169ea54b35f54fdec2364aa81cc2de42a239cb9e',
    '9761aa5d5679574fbee43a57b81e48fed0b76c63d80543ee99804432c6cddf6a'
  ];
  if (!candidateHashes.includes(expectedPopupSha256)) throw Error('Explicit reviewed candidate hash required');
  await assertSourceIdentity({
    'implementation/warlock/src/HttpPopup.elm':'4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354',
    'implementation/warlock/src/UiHttp.elm':'3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419',
    'implementation/warlock/src/Presentation.elm':'745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396',
    'implementation/warlock/src/Popup.elm':expectedPopupSha256,
    'implementation/warlock/src/SurfaceSnapshot.elm':'9c85362ec27496438eb5a159e2c162704ef2922ba41df172a17e81787203913a',
    'implementation/warlock/src/SurfaceRenderer.elm':'58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e'
  });
  await assertNetworkIsolation();
  const row=(id,domId,label,ariaLabel)=>({id,domId,label,ariaLabel,detail:'',enabled:true});
  const frame=(publication,query,status)=>({surfaceProtocol:2,publication,lease:'7',mode:'applications',status,bar:[],popup:[
    row('control:search','launcher-search',query,'Search applications'),
    row('control:close','close-applications','Windows','Close applications and return to windows'),
    row('control:refresh','refresh-applications','Refresh','Refresh applications'),
    row('entry:org.example.Foot','entry-foot','Foot','Open Foot')
  ]});
  const query=(publication,value)=>({surfaceProtocol:2,kind:'surface-query',surface:'popup',publication,lease:'7',id:'control:search',query:value});
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const read=()=>evaluate(`(() => {
    const root=document.querySelector('.surface-popup'), field=root?.querySelector('[data-surface-field="control:search"]');
    const control=id=>root?.querySelector('[data-surface-control="'+id+'"]');
    const state=id=>{const n=control(id); return n?{disabled:n.disabled,aria:n.getAttribute('aria-disabled')}:null};
    return {publication:root?.dataset.publication,lease:root?.dataset.lease,value:field?.value,
      focused:document.hasFocus()&&document.activeElement===field,sameField:field===window.heldSearch,
      selectionStart:field?.selectionStart,selectionEnd:field?.selectionEnd,
      composing:root?.parentElement?.getAttribute('data-input-composing'),
      status:root?.querySelector('[role="status"]')?.textContent,
      close:state('control:close'),refresh:state('control:refresh'),entry:state('entry:org.example.Foot')};
  })()`);
  await deliverPresentation(frame('1','','Type to search applications.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='1'`);
  await evaluate(`(() => {window.heldSearch=document.querySelector('[data-surface-field="control:search"]');window.heldSearch.focus();})()`);
  let state=await read();
  check('initial search receives browser focus',state.focused&&state.sameField&&state.value==='',state);
  await evaluate(`(() => {const f=window.heldSearch;f.value='c';f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'c'}));})()`);
  await waitForActionCount(1);
  check('first user draft emits c under publication one',same(await actions(),[query('1','c')]),await actions());
  await respondAction(0,204,'');
  await evaluate(`(() => {const f=window.heldSearch;f.value='b';f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'b'}));})()`);
  await waitForActionCount(2);
  const wires=[query('1','c'),query('1','b')];
  // Port delivery can precede the browser's animation-frame DOM patch.
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent==='Results may not match current input. Previous: Type to search applications.' && document.querySelector('[data-surface-field="control:search"]')?.value==='b' && document.querySelector('[data-surface-control="entry:org.example.Foot"]')?.disabled===true`);
  state=await read();
  check('later b is pending, focused and prior result cannot be launched',
    same(await actions(),wires)&&state.value==='b'&&state.focused&&state.sameField&&
    state.entry?.disabled===true&&state.entry?.aria==='true'&&
    state.status==='Results may not match current input. Previous: Type to search applications.',state);
  await evaluate(`(() => {const f=window.heldSearch;f.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true,data:''}));f.value='c';f.setSelectionRange(1,1);f.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'c'}));})()`);
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='true'`);
  state=await read();
  check('synthetic preedit retains focus and blocks every other control',state.value==='c'&&state.focused&&state.sameField&&
    state.close?.disabled===true&&state.close?.aria==='true'&&state.refresh?.disabled===true&&state.refresh?.aria==='true'&&
    state.entry?.disabled===true&&state.entry?.aria==='true'&&same(await actions(),wires),state);
  await evaluate(`(() => {const close=document.querySelector('[data-surface-control="control:close"]');close.focus();close.click();})()`);
  state=await read();
  check('disabled close cannot take focus or emit an action',state.focused&&same(await actions(),wires),state);
  await deliverPresentation(frame('2','c','Choose a matching application.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='2'`);
  state=await read();
  check('matching newer authority does not interrupt preedit',state.publication==='2'&&state.lease==='7'&&state.value==='c'&&
    state.focused&&state.sameField&&state.composing==='true'&&state.entry?.disabled===true&&
    state.status==='Results may not match current input. Previous: Choose a matching application.'&&same(await actions(),wires),state);
  await evaluate(`(() => {const f=window.heldSearch;f.setSelectionRange(1,1);f.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'c'}));})()`);
  // Do not wait for the expected settled status itself: the older candidate
  // must fail the literal assertion below rather than be mislabeled as absent.
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='false'`);
  await settleElm();
  state=await read();
  check('committing matching authority clears pending without losing browser focus',state.composing==='false'&&state.value==='c'&&
    state.focused&&state.sameField&&state.selectionStart===1&&state.selectionEnd===1&&
    state.status==='Choose a matching application.'&&state.entry?.disabled===false&&state.entry?.aria==='false',state);
  await respondAction(1,204,'');
  await settleElm();
  check('obsolete b transport completion causes no c replay',same(await actions(),wires),await actions());
  // A bounded drain does not prove no future work. Producer admission and actual
  // close/refresh recovery require an independently observed production route.
}
