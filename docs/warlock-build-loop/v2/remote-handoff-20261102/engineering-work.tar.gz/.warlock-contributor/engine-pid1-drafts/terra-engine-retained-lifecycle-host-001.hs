{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY; UNEXECUTED. Host adapter for the twelve direct input/stop tests.
-- This is not a process guardian or a cleanup receipt. The existing Root QA
-- host must remain alive and retain every registered value on success, error,
-- timeout and cancellation until an independently justified disposition.
-- Root owns a separate child guardian even where a case expects no spawn.
module TerraRetainedLifecycleHost (Host(..), runDirectLifecycleControls) where

import Control.Exception (mask)
import System.IO (Handle)
import qualified InputRetentionControls as Input
import qualified InflightCloseStopControls as Inflight
import qualified StopMintFailureControls as Mint

-- keep must establish a strong root BEFORE returning and never drop a root
-- merely because a control returned or threw. freshInput must return a fresh,
-- open handle that the same host already retains, even if acquisition fails.
-- The host is responsible for its own failure/async publication ordering.
data Host = Host
 { keep :: forall a. a -> IO ()
 , freshInput :: IO Handle
 }

runDirectLifecycleControls :: Host -> IO ()
runDirectLifecycleControls host = do
 run Input.newProbe Input.runFixtureFailure
 run Input.newProbe Input.runFixtureSuccess
 run Input.newProbe Input.runTicketFailure
 run Input.newProbe Input.runTicketSuccess
 run Input.newProbe Input.runFixtureStartupException
 run Input.newProbe Input.runTicketStartupException
 run Inflight.newProbe Inflight.runNoStop
 run Inflight.newProbe Inflight.runLateStop
 run Mint.newProbe Mint.runFixtureFailure
 run Mint.newProbe Mint.runTicketFailure
 run Mint.newProbe Mint.runFixturePositive
 run Mint.newProbe Mint.runTicketPositive
 where
  run :: IO p -> (p -> Handle -> IO ()) -> IO ()
  run make action = mask $ \restore -> do
   probe <- make
   keep host probe
   input <- freshInput host
   restore (action probe input)
