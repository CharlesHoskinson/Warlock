# Persistent Custody Prerequisites `v9` Consolidation (`232706Z`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Base Canonical `HEAD`**: `e5ce2487c8ec67ced1405dc0d3219c6f39effc5a` (verified `git apply --check` and `patch --dry-run -p1 --fuzz=0`)
- **Execution Status**: **UNEXECUTED SOURCE PROPOSAL** (Root retains all GHC/Cabal/Quint/Elm/VM/GPU/native execution after active `001` qualification completes).
- **Preserved Counts & Gates**: `17/242` whole EARS, `41/417` scenarios, `28s`/`30s`/`5s`/`500ms`/original `D`, `HOSTSTOP2`, `nativeOperations = []`.

## Frozen Artifacts (`v9`, Preserving `v6` / `v7` / `v8` Immutable)

- `gemini-omarchy-persistent-custody-v8-to-v9-delta-232706Z.patch`: `sha256:0f3fba9802f6b569d4db3731d99cba116ecaba819a48c9fed9bf3d77652cf02e`
- `gemini-omarchy-persistent-custody-prereqs-v9-232706Z.patch`: `sha256:d9c7d29f78215ea70b444afe399ad3aa9dc85a5461535c919f1ce0b5cb3554e6`
- Preserved `v8` full patch (`225558Z`): `sha256:76fe15f4f66a26e6669662d6fb630fe4b207c31e6bc3322866618f50e0d1e93c`
- Preserved `v7` full patch (`225558Z`): `sha256:5aba617d4adbce8db604beefff8f9260ee2108a8c2c4b4b7795e5aaf892fd1b0`
- Preserved `v6` full patch (`220528Z`): `sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`

## Five Peer-Reviewed `v8` Defects Closed in `v9`

1. **Masked `InternalPidfdClosed` Commit + Post-Claim Pre-Syscall Rollback (`terra-graph`, `terra-security`, `terra-q-lifetime`, `terra-engine`)**:
   - Inside `closeOwnedPidfdDl`, `closeFd pfd >> writeIORef pidfdCell InternalPidfdClosed >> O.pendingMarkFD pending pfd True` now executes under inner `mask` immediately upon `closeFd` return; post-close `remainingMicros` and `"persistent-after-pidfd-close-receipt"` run outside `timeout`, preserving truthful `PidfdClosed` when `D` expires after `closeFd` returns while still returning `Right Nothing` so containment quarantines.
   - Added bounded `"persistent-after-pidfd-claim-before-syscall"` + `remainingMicros` re-check that rolls `InternalPidfdClosing` back to `InternalPidfdKnownOpen` if aborted/expired before `O.pendingMarkFD pending pfd False` and `closeFd`.
   - Split literal controls into **#18b** (interruptible timeout in `"persistent-in-pidfd-close"` -> `PidfdCloseUncertain`), **#18c** (delay in `"persistent-after-pidfd-close-receipt"` -> `PidfdClosed` receipt + `expectedExpiredCloseFailures` quarantine), and **#18d** (delay in `"persistent-after-pidfd-claim-before-syscall"` -> rollback to `PidfdKnownOpen`).

2. **Skip Pointless Pipe EOF Capture on Unreaped Leader (`terra-security`)**:
   - In `finishContainment`, `captured` is skipped (`pure (Right Nothing)`) when `not leaderWasReaped`, preventing containment from burning the remaining `StopDeadline` waiting for pipe EOF from a still-alive unreaped child and restoring exact singleton `["leader-reap"]` quarantine in Control **#17**.

3. **Zero Production Quarantine-Bypass Helper & Zero `c_kill` in Controls (`terra-security`, `terra-q-lifetime`)**:
   - Deleted `reapQuarantinedTestChildInternal` and `retainedChildCell` from `Warlock.Capture.Process.Persistent.Internal`.
   - Added QA-only `[marker, "exit-when-removed"]` (`10ms` `System.Posix.Files.fileExist` poll, `5s` bounded self-exit cap) to `fixture-graceful/Main.hs`.
   - Controls **#4**, **#7**, **#13**, and **#17** retain quarantined `PersistentOwner` values in `retainedQuarantinedOwners` (`14` total), verify `PidfdKnownOpen` + live child while `marker` exists, then remove `marker` and observe self-exit via `leaderExited` (`WNOWAIT`).
   - Control **#12** `finally` explicitly checks `timeout 2000000 (readMVar tombWorkerDone)` and retains `tombOwner` + throws `ioError` if `Nothing`.

4. **Final `stderr-close` Pre-Entry & Post-Return `D` Resampling (`terra-engine`, `sol-docs`)**:
   - Added `boundedByDlObserved` around `closeB` (`"qa-stderr-after-budget-sample"`, `"qa-stderr-close-entered"`, `"qa-stderr-after-close-return"`), resampling `remainingMicros` before and after each hook so all 3 cases (`Positive`, `DelayBeforeClose`, `DelayAfterClose`) of `terra-engine-owner-v8-final-close-controls.hs` work natively against `v9` without needing a separate seam patch, plus Control **#19**.

5. **Interruptible Bounded `HeldExecutable` Borrow Release (`terra-engine`, `terra-q-lifetime`)**:
   - Added `borrowHeldInterruptible` in `Warlock.Platform.Executable.Internal` (re-exported via `Warlock.Platform.Executable` and `Warlock.Capture.Process.Lease`, keeping `borrowHeld` unchanged). `releaseNow` blocks on `gate` under normal `mask` (interruptible by `System.Timeout.timeout` when contended, restoring `released = False` without mutating `Live n` on interrupt, and committing `Live (n-1)` + `released = True` under `uninterruptibleMask_` once acquired).
   - Bounded borrow release across both `finishContainment` (`["borrow-release"]`) and all pre-spawn aborts (`["startup-borrow-release"]`), emitting `"qa-before-held-borrow-release:" ++ deadlineAbsoluteNs dl` and never calling `O.releaseBorrows` or `O.settle` unless `releaseNow` succeeded within `D` (Control **#20**).
   - **Peer review note on `terra-engine-held-gate-contention-controls.hs:125`**: `System.Timeout.timeout` wakes up *after* `D` (`>= deadline` + kernel timer slack), so `completedNs <- getMonotonicTimeNSec` after `withPersistentOwnerHook` returns under contention will satisfy `completedNs >= deadline`; `observed <- timeout 1200000 (readMVar (ownerDone probe))` returning `Just _` *before* `tryPutMVar releaseHolder ()` on line 112 already proves structurally that `ownerAction` interrupted its contended wait at `D` rather than blocking on `holder`.

## Unimplemented Production Call-Chain (Downstream Integration Boundary)

1. **`warlock-ui-engine` `Channel.hs` / `SocketOwner` / `TrustedPump` (`terra-engine`, `terra-q-network`, `terra-q-front`)**:
   - Must consume `LiveSession` (`withLiveSessionWakeSTM`, `withLiveFrameAdmission`, `enterLiveFrameAction`) without renewing `AdmissionDeadline` or treating private gate/pin borrowing as proof of peer socket cleanup.
2. **Engine / App Launch Supervision (`terra-engine`, `sol-docs`)**:
   - Must wire `withPersistentOwner` / `requestSessionStop` only for explicit app-session lifecycles after Root completes current `001` (`36` + `43` + `4c`) integration and protected `cabal test` qualification of `held-document` + `process-custody`.
