{-# LANGUAGE OverloadedStrings #-}
-- Ignored draft sequence & property test suite for Warlock.Capture.Process.Persistent
-- paired with gemini-omarchy-persistent-app-only-210356Z.patch.
-- Validates contract 951861, terra_q_lifetime_app_owner, and peer-reviewed fixes:
--   * StartBudget <= 30s (exact 28s trial preserved without +2s grace)
--   * Diagnostic runSelectedDetailed still expires at original D
--   * Persistent LiveSession survives idle past StartBudget without renewing per-op D
--   * Wrapper-owned LiveOperationFailure: callback returns IO (Either ToolError a);
--     any post-dispatch Left/timeout/stop maps to OperationOutcomeUnknown (never pre-dispatch)
--   * Single shared StopDeadline across drain + leader reap + pipe close (no multi-window stop)
--   * QA hook persistent-after-operation-drain-before-reap proves callback completion precedes reap
--   * Hung callback/observation drain quarantines owner without reaping underneath callback
module Main (main) where

import Control.Concurrent (forkIO, newEmptyMVar, putMVar, takeMVar, threadDelay)
import Control.Exception (mask_)
import Control.Monad (forM_, unless)
import Data.Bits (shiftR, xor)
import qualified Data.ByteString.Char8 as C
import Data.IORef (newIORef, readIORef, writeIORef)
import Data.Word (Word64)
import GHC.Clock (getMonotonicTimeNSec)
import System.Directory (doesFileExist, getTemporaryDirectory, removeFile)
import System.Environment (getArgs)
import System.IO (IOMode(ReadMode), hClose, openFile, openTempFile)
import Warlock.Capture.Process.Internal
 ( AdmissionDeadline
 , Captured(..)
 , OwnerStatus(..)
 , SelectedOutcome(..)
 , SessionObservation(..)
 , ToolError(..)
 , awaitLeader
 , deadlineAbsoluteNs
 , deadlineAfter
 , deadlineFromAbsoluteNs
 , deadlineFromAbsoluteNsAt
 , newOwner
 , remainingMicros
 , runSelectedDetailed
 , selectedFixture
 )
import Warlock.Capture.Process.Persistent.Internal
 ( LiveOperationFailure(..)
 , LiveSession
 , LiveWaitOutcome(..)
 , PersistentStatus(..)
 , SessionExit(..)
 , StopReceipt(..)
 , awaitLiveSessionStopOrExit
 , newPersistentOwner
 , observeLiveSession
 , persistentFixture
 , persistentStatus
 , persistentUnderlyingStatus
 , requestSessionStop
 , runBoundedLiveOperation
 , startBudgetAfter
 , startBudgetDeadline
 , startBudgetFromDeadline
 , stopBudgetMicros
 , stopBudgetMicrosValue
 , withPersistentOwner
 , withPersistentOwnerHook
 )

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("FAILED: " ++ label)))

nextSeed :: Word64 -> (Word64, Word64)
nextSeed s0 =
 let s1 = s0 + 0x9E3779B97F4A7C15
     z0 = (s1 `xor` shiftR s1 30) * 0xBF58476D1CE4E5B9
     z1 = (z0 `xor` shiftR z0 27) * 0x94D049BB133111EB
     z2 = z1 `xor` shiftR z1 31
 in (z2, s1)

newMarker :: IO FilePath
newMarker = do
 dir <- getTemporaryDirectory
 (path, handle) <- openTempFile dir "persistent-owned-ready"
 hClose handle
 removeFile path
 pure path

awaitMarker :: FilePath -> Int -> IO Bool
awaitMarker _ 0 = pure False
awaitMarker path steps = do
 ready <- doesFileExist path
 if ready then pure True else threadDelay 10000 >> awaitMarker path (steps - 1)

cleanMarker :: FilePath -> IO ()
cleanMarker path = do
 exists <- doesFileExist path
 if exists then removeFile path else pure ()

runPureBudgetProperties :: Word64 -> IO ()
runPureBudgetProperties initialSeed = do
 let nowSample = 100000000000 :: Word64
     parseAt = deadlineFromAbsoluteNsAt nowSample
 check "exact-28s-deadline-preserved"
  (case parseAt "128000000000" of
    Right d28 ->
     let sb28 = startBudgetFromDeadline d28
     in deadlineAbsoluteNs (startBudgetDeadline sb28) == "128000000000"
    Left _ -> False)
 check "exact-30s-cap-retained"
  (case parseAt "130000000000" of
    Right d30 -> deadlineAbsoluteNs d30 == "130000000000"
    Left _ -> False)
 check "beyond-30s-cap-refused" (parseAt "130000000001" == Left BadArguments)
 check "stop-budget-zero-refused" (stopBudgetMicros 0 == Left BadArguments)
 check "stop-budget-negative-refused" (stopBudgetMicros (-1) == Left BadArguments)
 check "stop-budget-above-30s-refused" (stopBudgetMicros 30000001 == Left BadArguments)
 let loop 0 _ = pure ()
     loop k seed = do
      let (draw, seed') = nextSeed seed
          candidateUs = fromIntegral (draw `mod` 40000000) - 5000000 :: Int
          expectedValid = candidateUs >= 1 && candidateUs <= 30000000
      case stopBudgetMicros candidateUs of
       Right sb ->
        check ("seeded-stop-budget-valid-seed=" ++ show initialSeed ++ "-step=" ++ show k)
         (expectedValid && stopBudgetMicrosValue sb == candidateUs)
       Left err ->
        check ("seeded-stop-budget-invalid-seed=" ++ show initialSeed ++ "-step=" ++ show k)
         (not expectedValid && err == BadArguments)
      loop (k - 1) seed'
 loop (64 :: Int) initialSeed

main :: IO ()
main = do
 let masterSeed = 0x5741524C4F434B31 :: Word64
 runPureBudgetProperties masterSeed
 (dOrig :: AdmissionDeadline) <- deadlineAfter 4000000 >>= either (ioError . userError . show) pure
 dReimported <- deadlineFromAbsoluteNs (deadlineAbsoluteNs dOrig)
 check "issued-absolute-deadline-bytes-immutable" (dReimported == Right dOrig)
 args <- getArgs
 case args of
  [childExe] -> do
   stop2s <- either (ioError . userError . show) pure (stopBudgetMicros 2000000)

   -- Sequence 1: StartBudget expiry during readiness refuses entry without
   -- borrowing StopBudget (+2s) as implicit startup grace.
   startupOwner <- newPersistentOwner
   startupMarker <- newMarker
   startupInput <- openFile "/dev/null" ReadMode
   start150ms <- startBudgetAfter 150000 >>= either (ioError . userError . show) pure
   liveEnteredRef <- newIORef False
   t0 <- getMonotonicTimeNSec
   startupRes <- withPersistentOwner
    startupOwner
    (persistentFixture childExe [startupMarker] startupInput)
    4096
    start150ms
    stop2s
    (\_ -> threadDelay 400000 >> pure (Right ()))
    (\_ -> writeIORef liveEnteredRef True)
   t1 <- getMonotonicTimeNSec
   liveEntered <- readIORef liveEnteredRef
   startupPhase <- persistentStatus startupOwner
   startupRaw <- persistentUnderlyingStatus startupOwner
   cleanMarker startupMarker
   check "startup-timeout-never-enters-live" (not liveEntered)
   check "startup-timeout-refused-cleanly" (startupRes == Left (StartupRefused TimedOut))
   check "startup-timeout-no-stopbudget-grace" (t1 - t0 < 1500000000)
   check "startup-timeout-retires-persistent-owner" (startupPhase == PersistentRetired && startupRaw == Available)

   -- Sequence 2: Single-use PersistentOwner refuses second session reuse.
   reuseInput <- openFile "/dev/null" ReadMode
   startReuse <- startBudgetAfter 500000 >>= either (ioError . userError . show) pure
   reuseRes <- withPersistentOwner
    startupOwner
    (persistentFixture childExe [startupMarker] reuseInput)
    4096
    startReuse
    stop2s
    (\_ -> pure (Right ()))
    (\_ -> pure ())
   hClose reuseInput
   check "single-use-owner-refuses-reuse" (reuseRes == Left (StartupRefused OwnerBusy))

   -- Sequence 3: Coexistence + Wrapper-Owned Unknown + Pre-Reap Drain Barrier Hook.
   trialOwner <- newOwner
   trialMarker <- newMarker
   trialInput <- openFile "/dev/null" ReadMode
   trialDl <- deadlineAfter 180000 >>= either (ioError . userError . show) pure
   trialOut <- runSelectedDetailed trialOwner (selectedFixture childExe [trialMarker] trialInput) 4096 trialDl awaitLeader
   cleanMarker trialMarker
   check "diagnostic-trial-still-expires-at-original-D"
    (selectedOperation trialOut == Left TimedOut && selectedCustody trialOut == Available)

   liveOwner <- newPersistentOwner
   liveMarker <- newMarker
   liveInput <- openFile "/dev/null" ReadMode
   liveStart <- startBudgetAfter 250000 >>= either (ioError . userError . show) pure
   let startNsBytes = deadlineAbsoluteNs (startBudgetDeadline liveStart)
   escapedSessionRef <- newIORef (Nothing :: Maybe LiveSession)
   sideEffectEnteredRef <- newIORef False
   drainCompletedBeforeReapRef <- newIORef False
   callbackFinishedFlagRef <- newIORef False
   liveRes <- withPersistentOwnerHook
    liveOwner
    (persistentFixture childExe [liveMarker] liveInput)
    4096
    liveStart
    stop2s
    (\obs -> do
      ok <- awaitMarker liveMarker 150
      check "readiness-observed-positive-pid" (observedPid obs > 0)
      pure (if ok then Right () else Left TimedOut))
    (\session -> do
      writeIORef escapedSessionRef (Just session)
      threadDelay 350000
      remStart <- remainingMicros (startBudgetDeadline liveStart)
      check "start-budget-expired-during-idle-without-killing-live-session"
       (remStart == 0 && deadlineAbsoluteNs (startBudgetDeadline liveStart) == startNsBytes)

      -- Operation 1a: post-dispatch timeout yields OperationOutcomeUnknown TimedOut.
      opDl1 <- deadlineAfter 120000 >>= either (ioError . userError . show) pure
      let opNs1 = deadlineAbsoluteNs opDl1
      opRes1 <- runBoundedLiveOperation session opDl1 (threadDelay 220000 >> pure (Right ("late" :: String)))
      check "post-dispatch-timeout-is-explicit-unknown-never-refusal"
       (opRes1 == Left (OperationOutcomeUnknown TimedOut) && deadlineAbsoluteNs opDl1 == opNs1)

      -- Operation 1b (peer-review counterexample check): callback enters, mutates
      -- state, and returns Left BadArguments -> wrapper MUST report OperationOutcomeUnknown,
      -- NEVER OperationRefusedPreDispatch!
      opDl1b <- deadlineAfter 600000 >>= either (ioError . userError . show) pure
      postEntryLeft <- runBoundedLiveOperation session opDl1b (writeIORef sideEffectEnteredRef True >> pure (Left BadArguments :: Either ToolError String))
      enteredSideEffect <- readIORef sideEffectEnteredRef
      check "entered-callback-left-always-classified-unknown"
       (enteredSideEffect && postEntryLeft == Left (OperationOutcomeUnknown BadArguments))

      -- Expired opDl1 is refused pre-dispatch without entering callback.
      preRefusedEntered <- newIORef False
      preRefused <- runBoundedLiveOperation session opDl1 (writeIORef preRefusedEntered True >> pure (Right ("never" :: String)))
      didEnterPreRefused <- readIORef preRefusedEntered
      check "expired-deadline-refused-pre-dispatch"
       (not didEnterPreRefused && preRefused == Left (OperationRefusedPreDispatch TimedOut))

      -- Operation 2: distinct fresh AdmissionDeadline succeeds; spawn a short
      -- in-flight callback right before liveBody returns so hook proves drain before reap.
      opDl2 <- deadlineAfter 800000 >>= either (ioError . userError . show) pure
      check "second-operation-has-distinct-deadline" (deadlineAbsoluteNs opDl2 /= opNs1)
      obs2 <- observeLiveSession session opDl2
      check "live-observation-succeeds-under-distinct-deadline"
       (case obs2 of Right o -> observedPid o > 0; Left _ -> False)

      cbStarted <- newEmptyMVar
      _ <- forkIO $ do
       _ <- runBoundedLiveOperation session opDl2 $ do
        putMVar cbStarted ()
        threadDelay 60000
        writeIORef callbackFinishedFlagRef True
        pure (Right ())
       pure ()
      takeMVar cbStarted

      waitDone <- newEmptyMVar
      _ <- forkIO (awaitLiveSessionStopOrExit session >>= putMVar waitDone)
      threadDelay 10000
      r1 <- requestSessionStop liveOwner stop2s
      r2 <- requestSessionStop liveOwner stop2s
      woke <- takeMVar waitDone
      check "one-shot-stop-signal-sent-and-idempotent"
       ((r1 == StopSignalSent || r1 == StopLeaderAlreadyExited) && r2 == StopAlreadyRequested)
      check "live-wait-wakes-on-stop-or-exit"
       (woke == LiveStopRequested || woke == LiveLeaderExited)
      pure ("completed-live" :: String))
    (\stage ->
      if stage == "persistent-after-operation-drain-before-reap" then do
       cbDone <- readIORef callbackFinishedFlagRef
       writeIORef drainCompletedBeforeReapRef cbDone
      else pure ())
   cleanMarker liveMarker
   drainedBeforeReap <- readIORef drainCompletedBeforeReapRef
   check "callback-definitely-completed-before-reap-hook" drainedBeforeReap
   case liveRes of
    Right (tag, LeaderReaped captured) ->
     check "persistent-leader-reaped-captured-ready"
      (tag == "completed-live" && output captured == C.pack "READY\n")
    other -> ioError (userError ("unexpected persistent exit: " ++ show other))
   livePhaseAfter <- persistentStatus liveOwner
   liveRawAfter <- persistentUnderlyingStatus liveOwner
   check "persistent-owner-retired-and-underlying-settled"
    (livePhaseAfter == PersistentRetired && liveRawAfter == Available)

   afterStop <- requestSessionStop liveOwner stop2s
   check "stop-after-retirement-reports-no-live-session" (afterStop == StopNoLiveSession)
   maybeEscaped <- readIORef escapedSessionRef
   case maybeEscaped of
    Nothing -> ioError (userError "missing escaped session")
    Just escaped -> do
     freshDl <- deadlineAfter 500000 >>= either (ioError . userError . show) pure
     escapedObs <- observeLiveSession escaped freshDl
     escapedOp <- runBoundedLiveOperation escaped freshDl (pure (Right ()))
     check "escaped-live-session-refused-pre-dispatch"
      (escapedObs == Left SessionClosed && escapedOp == Left (OperationRefusedPreDispatch SessionClosed))

   -- Sequence 4a: Hung in-flight callback (masked past StopBudget) quarantines owner
   -- without reaching persistent-after-operation-drain-before-reap or reaping!
   cbQuarOwner <- newPersistentOwner
   cbQuarMarker <- newMarker
   cbQuarInput <- openFile "/dev/null" ReadMode
   cbQuarStart <- startBudgetAfter 1000000 >>= either (ioError . userError . show) pure
   stopShort <- either (ioError . userError . show) pure (stopBudgetMicros 120000)
   cbEntered <- newEmptyMVar
   cbRelease <- newEmptyMVar
   reapHookReachedRef <- newIORef False
   cbQuarRes <- withPersistentOwnerHook
    cbQuarOwner
    (persistentFixture childExe [cbQuarMarker] cbQuarInput)
    4096
    cbQuarStart
    stopShort
    (\_ -> do
      ok <- awaitMarker cbQuarMarker 150
      pure (if ok then Right () else Left TimedOut))
    (\session -> do
      opDl <- deadlineAfter 2000000 >>= either (ioError . userError . show) pure
      _ <- forkIO (runBoundedLiveOperation session opDl (mask_ (putMVar cbEntered () >> takeMVar cbRelease >> pure (Right ()))) >>= \_ -> pure ())
      takeMVar cbEntered
      pure ())
    (\stage ->
      if stage == "persistent-after-operation-drain-before-reap" then
       writeIORef reapHookReachedRef True
      else pure ())
   cbQuarPhase <- persistentStatus cbQuarOwner
   cbQuarRaw <- persistentUnderlyingStatus cbQuarOwner
   reapHookReached <- readIORef reapHookReachedRef
   putMVar cbRelease ()
   cleanMarker cbQuarMarker
   check "hung-callback-drain-quarantines-without-reaping"
    (not reapHookReached
      && cbQuarRes == Left (ExitUncertain CleanupUncertain ["persistent-callback-not-drained"])
      && cbQuarPhase == PersistentQuarantined ["persistent-callback-not-drained"]
      && cbQuarRaw == Quarantined ["persistent-callback-not-drained"])

   -- Sequence 4b: Hung in-flight SessionScope observation exceeding StopBudget quarantines.
   quarOwner <- newPersistentOwner
   quarMarker <- newMarker
   quarInput <- openFile "/dev/null" ReadMode
   quarStart <- startBudgetAfter 1000000 >>= either (ioError . userError . show) pure
   enteredHook <- newEmptyMVar
   releaseHook <- newEmptyMVar
   quarRes <- withPersistentOwnerHook
    quarOwner
    (persistentFixture childExe [quarMarker] quarInput)
    4096
    quarStart
    stopShort
    (\_ -> do
      ok <- awaitMarker quarMarker 150
      pure (if ok then Right () else Left TimedOut))
    (\session -> do
      obsDl <- deadlineAfter 2000000 >>= either (ioError . userError . show) pure
      _ <- forkIO (observeLiveSession session obsDl >>= \_ -> pure ())
      takeMVar enteredHook
      pure ())
    (\stage ->
      if stage == "persistent-scope-observation" then
       putMVar enteredHook () >> takeMVar releaseHook
      else pure ())
   quarPhase <- persistentStatus quarOwner
   quarRaw <- persistentUnderlyingStatus quarOwner
   putMVar releaseHook ()
   cleanMarker quarMarker
   check "hung-observation-drain-quarantines-both-owners"
    (quarRes == Left (ExitUncertain CleanupUncertain ["persistent-observation-not-drained"])
      && quarPhase == PersistentQuarantined ["persistent-observation-not-drained"]
      && quarRaw == Quarantined ["persistent-observation-not-drained"])

   -- Sequence 5: Seeded multi-step live schedule (4 seeded sessions x variable ops).
   forM_ [1 .. 4 :: Int] $ \roundIx -> do
    let (draw, _) = nextSeed (masterSeed + fromIntegral roundIx)
        opCount = 1 + fromIntegral (draw `mod` 4) :: Int
    schedOwner <- newPersistentOwner
    schedMarker <- newMarker
    schedInput <- openFile "/dev/null" ReadMode
    schedStart <- startBudgetAfter 1000000 >>= either (ioError . userError . show) pure
    schedRes <- withPersistentOwner
     schedOwner
     (persistentFixture childExe [schedMarker] schedInput)
     4096
     schedStart
     stop2s
     (\_ -> do
       ok <- awaitMarker schedMarker 150
       pure (if ok then Right () else Left TimedOut))
     (\session -> do
       forM_ [1 .. opCount] $ \stepIx -> do
        stepDl <- deadlineAfter 400000 >>= either (ioError . userError . show) pure
        obs <- observeLiveSession session stepDl
        opOut <- runBoundedLiveOperation session stepDl (pure (Right stepIx))
        check ("seeded-schedule-round=" ++ show roundIx ++ "-step=" ++ show stepIx)
         (opOut == Right stepIx && case obs of Right o -> observedPid o > 0; Left _ -> False)
       sr <- requestSessionStop schedOwner stop2s
       check ("seeded-schedule-stop-round=" ++ show roundIx)
        (sr == StopSignalSent || sr == StopLeaderAlreadyExited))
    cleanMarker schedMarker
    schedPhase <- persistentStatus schedOwner
    check ("seeded-schedule-leader-reaped-round=" ++ show roundIx)
     (case schedRes of Right ((), LeaderReaped _) -> schedPhase == PersistentRetired; _ -> False)

  _ -> ioError (userError "expected graceful-stop-child executable path")
