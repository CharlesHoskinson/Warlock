# Persistent Process-Custody Consolidated Stack Guide (`v14`, Wave `20261102T002904Z`)

## 1. Scope, Authority, and Honest Status
- **Owner**: `gemini-omarchy` (`held-document` + `process-custody` source stack ONLY).
- **Canonical `HEAD`**: `af1bf0efeb195a9ac9e9664547d695967b41111f` (working-tree `Backend.hs`: `641e06dc8326fdf7d4e1be2aaa316d5739fcf161d5854c895c3d800a48450c06`).
- **Status**: **SOURCE DRAFT ONLY** — zero worker GHC/Cabal/Elm/Quint/VM/native execution. Root alone selects, compiles, executes, and qualifies. Accepted counts remain **`18/242` whole EARS** and **`42/417` scenarios** (`nativeOperations = []`; `HOSTSTOP2` and all deadlines/failures preserved).
- **Supersedes `v12` (`7df4cdf0...`) and `v13` (`3716614f...`)** (kept immutable on disk). Do NOT use `v12` or `v13`: `v14` fixes three source defects caught in peer review and enforces Root's `persistent-request-budget-decision.json` (`17060de85514e82f192dcd41975ac39ad2df657e2c2fd0980176ac8bc4316551`).

## 2. What Changed in `v14` Over `v13`
1. **Compile/Type & Exception-Safety Fixes (from `terra-engine`, `terra-q-lifetime`, `terra-q-front` reviews)**:
   - Fixed missing `pure` on `Right True -> pure (Left (OperationOutcomeUnknown SessionClosed))` inside `postLive` in batch execution.
   - Added explicit `forall a.` and monomorphic-exception `tryAny :: IO b -> IO (Either SomeException b)` in both `enterLiveFrameAction` and `runBatchStepWithBudget`, eliminating expression-level `:: IO (Either SomeException ... a)` rigid type-variable shadowing under `ScopedTypeVariables`.
   - Allocated `succeededRef <- newIORef False` **before** `modifyMVar frameStateVar` (`admitBatchActionAttempt` / `inFlight = True`) so `finally` wraps admission immediately with zero unguarded allocation gap.
2. **Root `5s` Per-Request Cap, Lexical Callback `AdmissionDeadline`, and Stricter-Authority Clamping**:
   - `maxPersistentActionBudgetMicros = 5000000` (`5s` trusted app-only per-request cap; `actionBudgetMicros` accepts `1..5000000` us only; `defaultPersistentActionBudget = 5000000` us).
   - Removed raw unbudgeted `enterLiveBatchAction` from exports so no batch caller can bypass `ActionBudget` (`<= 5s`).
   - Added package-private `capAdmissionDeadline :: AdmissionDeadline -> AdmissionDeadline -> AdmissionDeadline` in `Warlock.Capture.Process.Internal` (`min` on monotonic `Word64` ns without renewal).
   - `maxLiveFrameBatchRequests = 16`, `maxLiveFrameBatchActions = 17` (`16` checked `DesktopCommit` requests + `1` optional initial attachment).
   - `beginLiveFrameBatch :: LiveFrameAdmission -> AdmissionDeadline -> Int -> IO (Either ToolError LiveFrameBatch)` (`0..17` steps; preserves exact 3-arg call compatibility with `terra-portable-persistent-backend-001..003.patch`).
   - `beginLiveFrameRequestBatch :: LiveFrameAdmission -> AdmissionDeadline -> Bool -> Int -> IO (Either ToolError LiveFrameBatch)` (explicit `allowAttachment :: Bool` + `0..16` request quota, enforcing `enterLiveBatchAttachment` before `enterLiveBatchRequest` when `allowAttachment == True`).
   - `enterLiveBatchAttachment :: LiveFrameBatch -> ActionBudget -> (AdmissionDeadline -> IO (Either ToolError a)) -> IO (Either LiveOperationFailure a)`.
   - `enterLiveBatchRequest :: LiveFrameBatch -> ActionBudget -> Maybe AdmissionDeadline -> (AdmissionDeadline -> IO (Either ToolError a)) -> IO (Either LiveOperationFailure a)` — checks open/poison/quota/stop first, mints one immutable `<= 5s` `AdmissionDeadline`, clamps to `Maybe AdmissionDeadline` via `capAdmissionDeadline`, verifies live peer, and passes that **exact** `AdmissionDeadline` lexically to the callback (for `Backend` + `sendPersistentCredentialIngress`).
   - `enterLiveBatchBudgetedAction :: LiveFrameBatch -> ActionBudget -> (AdmissionDeadline -> IO (Either ToolError a)) -> IO (Either LiveOperationFailure a)` (`= \b bud act -> enterLiveBatchRequest b bud Nothing act`).
3. **Exact Metadata Alignment (`terra-graph` review)**:
   - Every folded and downstream patch path and full 64-hex SHA-256 in the `v14` manifest was computed directly from `.warlock-contributor/engine-pid1-drafts/` on disk, including `sol-outbound-pin-rebase-001.patch` (`33c3f67c74b62067188539e4bdd192ff149d8a5a327e48ef4f0e913aaea97815`).

## 3. Artifacts (`v14`)
- Standalone patch against canonical `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f`:
  - `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v14-002904Z.patch`
  - `sha256:4a8d3bf1b595f6270989bda73d88fedaf39b9c7d86d0520128fd83c4fea9a645`
- Incremental delta from `v13` (`3716614fc6e299d3504d8778beecf96150c66239a6a5ecb70fff6f365862b526`) to `v14`:
  - `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v13-to-v14-delta-002904Z.patch`
  - `sha256:dd7e1a009dc0b6893c040d34dc12bf15f3b1b62e54e18bd43cd08fa17b6f6954`

## 4. Zero-Fuzz Patch Composition Checks Performed (Source-Only, No Compiler Run)
- **15-patch 4-package stack (`patch -p1 --fuzz=0`, `rc = 0`)**:
  `v14` -> `terra-engine-lexical-ingress-integration.patch` (`74b07921`) -> `terra-q-front-context-ingress-001.patch` (`c9fe0c1a`) -> `terra-q-front-owned-ingress-001.patch` (`51f96699`) -> `sol-outbound-pin-rebase-001.patch` (`33c3f67c`) -> `terra-portable-persistent-scope-001.patch` (`c55ee134`) -> `terra-portable-registration-deadline-001.patch` (`4a3245e6`) -> `terra-portable-socket-context-001.patch` (`262f9403`) -> `terra-portable-owned-pump-002.patch` (`ffaaadee`) -> `terra-portable-persistent-bootstrap-002.patch` (`ca1736bc`) -> `terra-portable-bootstrap-cleanup-004.patch` (`14140811`, HOLD review item) -> `terra-portable-backend-request-sharing-001.patch` (`49584c7a`) -> `terra-portable-persistent-backend-001.patch` (`78c7440c`, HOLD review item) -> `terra-portable-persistent-backend-owner-002.patch` (`a197b4bb`, HOLD review item) -> `terra-portable-persistent-backend-owner-003.patch` (`71a70cb3`, HOLD review item).
- **8-patch isolated QA seam/race/startup-route overlay on `v14` (`patch -p1 --fuzz=0`, `rc = 0`, zero rebase required from `v13`!)**:
  `v14` -> `terra-security-owner-gate-qa-seam.patch` (`0c387d71`) -> `terra-security-v13-unborrowed-qa-wiring.patch` (`b1e8e867`) -> `terra-engine-held-gate-qa-seam-006.patch` (`2f139c80`) -> `terra-engine-v13-startup-joint-qa-seam-001.patch` (`78b4f34d`) -> `terra-security-v11-owner-abort-race-qa-seam.patch` (`4e1f1d87`) -> `terra-security-v11-abort-races-wiring-v2.patch` (`9be29f6f`) -> `terra-engine-v13-startup-route-wiring-001.patch` (`349552cb`).

## 5. Remaining Integration / Evidence Gaps for Root
1. Protected GHC compilation and execution of `held-document`, `process-custody` (including `deadline-stop-controls` + isolated QA seam suites), `protocol`, and `runtime` remain Root-owned and unexecuted.
2. In `runtime` (`terra-portable` HOLD drafts):
   - `terra-portable-bootstrap-cleanup-004.patch` (`14140811`) still calls `retireRegistration` rather than `tryRetireRegistrationBefore` (`4a3245e6`) and remains marked HOLD by `terra-security`/`terra-portable`.
   - `terra-portable-persistent-backend-001.patch` (`78c7440c`) calls `enterLiveBatchBudgetedAction` for every element of `requests` before checking `lastWrite` replay dedup (`terra-q-origin` review point: duplicate request IDs within/across frames should avoid minting a new `ActionBudget` if deduplicated pre-entry, or `Backend` must align quota/dedup explicitly).
3. Live guest/native Omarchy `D28` diagnostic follow-up (`selectedOperationError = unsuccessful, exitCode = 1`) and all native/GUI/provider/AT/IME/hardware/resource/release obligations remain unaccepted (`18/242` whole, `42/417` scenarios).
