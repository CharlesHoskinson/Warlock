# Sol advisor: complete TEA model/effect contract

2026-11-01 resumed authenticated sol-docs/run warlock-20261031-setup.
Advisor only, cutoff19:00UTC. Root alone coordinates/integrates/executes.
Own exact draft hold01M6C6K8T8ECFNEK9DG26XBCQK,120minutes.
No protected checks, product edits, agent launches or forbidden checker reads.
Original242/417,15historicalwhole/39scenarios, deadlines/failures/HOSTSTOP2 remain.

## Agreed minimal observation design

Actual DesktopPolicy.Model holds one opaque OutputController.Model. Effect is
Publish E.Value or Delay Float Desktop.Msg. Main calls this actual update route;
the QA worker calls the same function, retaining complete tuple and actual Delay
messages. No product constructors/mutators need exposure.

TeaContractReplay.elm logs one QA-only raw tuple marker. Node intercepts raw
value BEFORE Debug text formatting, synchronously copies EVERY own data field
including opaque constructor wrappers, JSON wrappers, list cells, tuples and
payloads. Functions/cycles/accessors/symbols/exotic host values fail closed;
extra unmodelled state fields fail exact independent expected-tree comparison.
The hook must return the original value unchanged. Exactly one recognized
unoptimized Debug definition/marker, reversible one-insertion patch, original
and instrumented artifact hashes and root source/compiler binding remain
required facts. This is QA instrumentation, not production authority.

Independent expected cases are loaded from exact hashed source bytes, without
access to observed model/results. Complete expected state starts from a
source-transcribed literal GIVEN and retains every unchanged field; every
tested transition has independent literal changes/effects. Whole histories run
twice in separate workers, but equality of two runs alone is insufficient.
Publish retains entire commit (projection/requests/focus); Delay retains exact
duration AND full Desktop.Msg constructor/payload/token, never just timer tag.

Concrete runner correction: initial captures wrapper used ordinary prototype
while full(expected) used null prototype, so isDeepStrictEqual would fail.
q-origin confirmed correction to captures.push(full({state:tuple.a,effects:tuple.b})).
Current peer source-review hashd80b21d29a8c2615a8b35f5bae0af98d1c072f4b3c0df1afdb27847861c5ba35;
not executed by advisor or workers. Debug tag/layout predictions still need
root compilation; do not rewrite expectations from captured actual output.

## Independently traced first positive topology case

Input after independently literal complete initial GIVEN:

```json
{"kind":"incoming","value":{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"1","views":[]}}}
```

This empty table is valid, not a malformed no-op. OutputController updates the
outer revision. Its two actual Desktop.Window messages still call windowBase
even though underlying detached Shell commands are no-ops. Each increments
Desktop.presentation and Launch.revision; SurfaceController publication also
increments because the encoded presentation/DOM identity changes. Empty recovery
and announcements remain unchanged; no requests/focus/Delay are emitted.

Starting from a validated independent clone of the ENTIRE literal initial state,
the exact changed raw-state paths are:

```js
expected.controller.a.revision = {$:'Counter',a:'1'};
expected.controller.a.controller.a.publication = {$:'Counter',a:'2'};
expected.controller.a.controller.a.desktop.presentation =
  {$:'Just',a:{$:'Counter',a:'2'}};
expected.controller.a.controller.a.desktop.launch.a.revision =
  {$:'Counter',a:'2'};
```

All other initial fields are preserved and compared. Do not use only these four
fields as an oracle. The earlier conditional hypothesis of only outer revision
changing was rejected after q-network identified windowBase side effects.

Source derivation: OutputController137–173 topology acceptance and two messages;
Desktop361–365 advance and381+ windowBase detached branch; Launch52–60/257–262
disconnect increments revision; SurfaceController33–61 updates publication;
ReconciliationTracking14–16 reset empty unchanged; OutcomeAnnouncements77–116
has no new initial-state candidate and encodes announcement null. q-network
independently confirmed four deltas at18:43 (01M6C6R9B8CBBSC3G4QSMGDJ24).

Complete expected Publish JSON wrapper:

```js
const commit = {
  viewProtocol:1, kind:'view-commit',
  projection:{
    viewProtocol:1, kind:'view-frame', revision:'1', views:[],
    focusOwner:null, popupOwner:null,
    frame:{
      surfaceProtocol:2, keyboardParent:true, motion:'reduced',
      appearance:{theme:'night',textScale:100,effectsOff:false,reducedTransparency:false},
      publication:'2', lease:'0', mode:'closed', status:'Connecting…',
      bar:[
        {id:'bar:reconnect',domId:'reconnect',label:'Reconnect',ariaLabel:'Reconnect to the window system',detail:'',enabled:false,focusOnly:false},
        {id:'bar:overview',domId:'applications:detached:2:control:overview-opener',label:'Task View',ariaLabel:'Open Task View',detail:'',enabled:false,focusOnly:false},
        {id:'bar:switcher',domId:'applications:detached:2:control:switcher-opener',label:'Switch windows',ariaLabel:'Open window switcher',detail:'',enabled:false,focusOnly:false},
        {id:'bar:notifications',domId:'applications:detached:2:notifications:opener',label:'Notifications',ariaLabel:'Open notifications',detail:'',enabled:false,focusOnly:false},
        {id:'bar:files',domId:'applications:detached:2:files:opener',label:'Files',ariaLabel:'Open Files menu',detail:'',enabled:false,focusOnly:false},
        {id:'bar:system',domId:'applications:detached:2:system:opener',label:'System',ariaLabel:'Open system menu',detail:'',enabled:false,focusOnly:false},
        {id:'bar:settings',domId:'applications:detached:2:settings:opener',label:'Settings',ariaLabel:'Open settings',detail:'',enabled:false,focusOnly:false}
      ],
      popup:[]
    },
    announcer:null, announcement:null
  },
  requests:[], focus:[]
};
// Pinned nonoptimized Elm Json.Encode.Value wrapper must be qualified by root.
const effects = {$:'::',a:{$:'Publish',a:{$:0,a:commit}},b:{$:'[]'}};
```

q-network owns complete independent leaf:
.warlock-contributor/engine-pid1-drafts/tea-initial-surface-packet.md
SHAe32df109a5d5022d15c7a328d87b5d936b4c30d16ea172a48cb1abd3620a26db.
Substitute literal publication='2',lease='0',presentation='2'. It includes all
seven disabled bar controls, full appearance/motion/status/popup fields. This
wrapper+leaf is one positive reachability case, not full TEA002. Pending,
mismatched receipt, commit/refusal, disconnect Unknown/no replay, stale and
malformed input, rebind, full-width counters and reached exact Delay effects
still need complete independent histories. Four Delay source variants are:
2000 Window(ExpirePrepared token),2000 WorkspaceNavigationDeadline intent,
2000 ChoiceDeadline token,10000 Deadline token.

## TEA001 actual custom-type gaps independently confirmed

Notifications.elm10/13 retains Entry.state:String and outcome.status:String.
Decoder membership checks8lifecycle and3receipt values but stores raw String;
these are lifecycle/receipt state, not freeform names. Browser/source-engine
finding independently verified and sent lead/security. Small root-owned remedy:
custom lifecycle/outcome ADTs with strict boundary decode/name encoding, update
actual comparisons/projections/callers, preserve wire/labels/Unknown semantics.
No runtime misbehavior inferred. Need exact original complete clause audit;
typed Effects.Status/Shell.Phase elsewhere do not prove this whole contract.

Security additionally reports ReconciliationFrame.Proof.operation:String
(observe/retire) and grantState:String(Retired) retained in actual
ReconciliationTracking/SurfaceController route; root already informed. This is
an independently reviewed source gap, not permission for advisor production edits.
TEA002 may advance separately; TEA001 acceptance cannot be inferred from one
positive topology fixture or only the already-typed domains.

## Canonical authors and integration limits

q-front owns only qa/TeaContractReplay.elm; q-origin only qa/tea-contract.cjs;
portable only qa/tea-contract-cases.cjs. Their exact claims/canonical contributor
declarations are separate from this advisor draft. All other workers draft/read
only. Root compiles/runs protected QA, pins full immutable tuple and requests
independent original reviews. TEA005 remains queued, not selected. No physical
gate added where these originals explicitly qualify native behavior separately;
no native focus, AT, IME, latency or provider cleanup acceptance inferred.

## 18:46 integration update

Read canonical cases67fa15273958e1ddd1fb124e8df0cacfe616405096c9b31808f4a93a937c7a1a:
four strict old/new path replacements and complete topology packet match this
independent derivation. Additional literal revisions9007199254740993 and
18446744073709551615 exercise full-width counters, with duplicate/overflow
post-step exact no-op expectations. Source consistency only, not execution.
Engine independently confirmed every other initial subtree/recovery/announcement
unchanged in01M6C6S1D5C9ZVB6TP0M10R12F. Network confirmed same at18:43.

Runner8c88af33a71c73edf22195ec8cfa84e8e945b8a2d0c077d1b1926f48087af6d7
supersedes earlier source candidates: q-origin now creates module/exports inside
oracle realm rather than passing a host object. Full trusted realm prototype
inventory rejects prototype substitution; synchronous capture still copies all
data. No new concrete semantic defect found in bounded reviewed windows after
the initial wrapper correction. This is NOT exhaustive runner qualification.
Root must bind current compiled blob to exact source/compiler receipt; reporting
Elm and JS hashes alone cannot establish their derivation. Do not use actual
capture to manufacture a changed literal expectation if debug layout differs.

Security additional type inventory: SystemMenu finite permission strings need
exact-clause/language-contract disposition, distinct from arbitrary native names
and free-form display labels. Proposed Protocol.Session is not the actual owning
route and cannot substitute for it. Root/security already received these notes.

Site61a396c5520f094fc9ea12a0533a2255b61de7306de14f6370ffbc408871a31d
now fixes historicalUI005/current-port scope and recorded-sequence no-launch
wording. Asked one precision: ARC002 is partial implementation, not historical
whole requalification; UI005 is current-port requalification. Source-only review,
no compile/render. UX owner retains post-TEA calibrated input-to-matching-result
measurement proposal; current WIP stays001/002, no new performance campaign.

## 18:52 critical-path corrections and freeze

q-front delivered actual prelude initializer a63153fc341d548a4382f78f6de331da62dd0d4882bb28d0c4e7dfd20387ed13:
strict nonempty gateway values fold actual Policy.update Incoming from initial;
retains EVERY actual returned Delay message; observes final complete model and
final effects. Intermediate setup transitions are explicitly not tested/counted.
Final GIVEN/effects still need complete independently literal expectations.
Runner must exclude setup from transition coverage and independently account
all prelude-retained timers, not infer them only from final effect list. The
user explicitly permits pinned GIVEN/prelude setup; no constructor exposure is
necessary. Root chooses integration. Actual native-ready timer route identified
by front: topology/attached/watermarks/scene/pointer/catalog/Apps/entry yields
Delay10000(Desktop.Deadline actual Launch.PendingToken). App-only launch is
disabled and catalog request alone produces no Delay. No runnable full timed
positive oracle yet.

Omarchy peer identified concrete runner port bug01M6C73WVK1MTDYB9JVA785QHA:
full(input) gives nested null-prototype objects, but shallow spread repairs only
outer wrapper; Elm Json.keyValuePairs calls value.hasOwnProperty(key). I verified
that call in existing generated assets/elm.js1461. Keep comparison snapshots
normalized, but recursively materialize validated ordinary port JSON objects
with safe defineProperty data keys/arrays before send. Sent root/q-origin; no
execution. Exact current correction hash awaits owner handoff.

I briefly misread older asset active vs_UNUSED Debug functions and sent an
overbroad wrapper note, then corrected all recipients immediately. Actual old
asset237 active log is no-op,242 unused log formats; it is not a counterexample
to nonoptimized debug JSON wrapper prediction. Current root-built fixture kernel
branch/hash is authoritative. No semantic expectation change justified by old
artifact or captured reducer output.

Root18:49 directive freezes three canonical QA files after in-flight writes.
Read directive and reminded authors: advisor suggestions do not authorize more
canonical writes. Further fixes/extensions only distinct exact-claimed ignored
patches until root integrates/resumes. Root's first protected component run is
wholeNotAssessed; initial/fullPublish/stale-disposition qualification is useful
but does not close original001/002. Current source cases have advanced beyond
topology to one-view/attached/mismatch/catalogsuccess/refusal/disconnect; this
is read-only source inventory, not passes or transactionUnknown/timer coverage.

Additional GemGUI draft critique sent root/author: Tea001DesktopPopupGuard.patch
e7b10... changes only motion outcome decoder, not all3 reported outcome routes;
shortcut decoder helpers are defined but unused, and receipt ADT converts back
to String at existing receive. It cannot by itself close retained-model type
gaps. Derived Launch.status/Surface.mode text is not automatically retained
lifecycle authority. Definite Notifications/ReconciliationFrame gaps remain
separate from arbitrary labels/transient wire signatures. Pending pin/jump
admission issue is previously known, backend mutation unproven.

Site v2 now9e4961eb6c2c1c35172fe5cadbfa13e6722adf56a277c9d06abe05df284fb2a1:
ARC002partial vsUI005current-portrequalification wording separated; QMP-injected
guest events explicitly distinguished from physical hardware/latency. No new
acceptance. Top-level ledger read18:49: TEA001/002unadjudicated,15whole total.

## 18:55 corrected concrete artifacts

Root-owned canonical source snapshot read18:54:54:
- TeaContractReplay.elm a63153fc341d548a4382f78f6de331da62dd0d4882bb28d0c4e7dfd20387ed13
- tea-contract.cjs ff4d1b8f4333f6273a5ad0e5e1ac104a7419ff65f3360d99f0f09dd96171c075
- tea-contract-cases.cjs 3a9dba6077ef23badf73e44989dfd11bef776c00303a0990d21a9e76d2b4ce7d
Runner now contains portValue conversion;22cases currently do NOT use prelude.
Exact primary archived kernel source independently read:
implementation/warlock-preview-provider-v143/qa/toolchain/elm-home/0.19.2/packages/elm/json/1.1.3/src/Elm/Kernel/Json.js250–265
calls own hasOwnProperty;418+ has DEBUG wrapped vsPROD raw JSON branches.

q-origin exact ignored prelude patch66570afa40b11a954c306773e122b5838dcda278f5ad4e2b2c0948d7d4ee2348
(.warlock-contributor/engine-pid1-drafts/terra-q-origin-tea-prelude.patch)
source-reviewed: prelude onlyindex1 afterreset; independently literal setupTimers
must match retainedack count and not be less than final-effectDelaycount; full
final GIVEN/effects still compared; prelude setup excluded from tested transitions.
No new concrete source defect found, no execution. Hidden setup timer payloads
are not claimed tested effects; subsequent actual tested timer payload/outcome
must have full independent literal oracle. Root integrates after own freeze/results.

GemGUI updated response supersedes my critique of earlier motion-only draft:
Tea001DesktopPopupGuard.patch d6fa51eca42fe55e44662d51a77224436aead2519557b9fce748ecfc9c5b679e
now covers all3motion/shortcut/settings outcome decoders and explicitly remains
wire-admission-only, not child retained-model ADT conversion. Auditbea323b7...
separates retained finite-state fields, transient wire parameters and derived
projections. Root informed; peer apply-check is not protected compilation or
whole acceptance. No advisor product/source edits.

18:57 actual Quint-Kit usage receipts received from q-front/q-http/q-network/
q-lifetime: modeling/from-code orreview pluslang, execute-spec where relevant.
Existing ui-frontend-delivery/ui-origin/receipt-lifecycle/bootstrap/cancellation
models have explicit queue/counter/receipt/provenance abstractions; they do not
prove full Policy.Model/every-effect equality or native behavior. Lifetime notes
desired PinUnknown retention in one model differs from actual Pins.initial on
rebind; retain as correspondence limit, not a newly established runtime fault.
No model/CLI execution by workers. q-origin receipt pending at18:57.
Hourly first window began18:11:37 and ends19:11:37, after advisor19:00cutoff;
do not prematurely report a missed hour or claim closures from current snapshots.

## 18:58 actual protected component result independently read

Root report .warlock-contributor/elm-cpu-1793559196114529322/report.json
SHA256e2e163a2397f721acfff74ce66bb124abc381f1de2b68c3087adb2b8ac32f360
passed=true. Root bus confirms six optimized production roots. teaContract:
26namedhistories,52transitions,runsPerCase2,complete literal model/effect
comparisons passed. Exact frozen three source hashes above match report.
Original compiled fixturef1acd9b7aa9f10eb1077d262c1be08be78beba3b61737ab9dade28cb5db48f07;
instrumented399808ee0a7359b8361f94bd9138daf542408b38832c8572b99e3a64efdcaaff;
reversible patch offset7279/85bytes. This is observed root execution, not worker
execution or advisor execution.

Report explicitly coverage.complete=false,wholeTeaStatus=NOT_ASSESSED,
originalAccepted=false,nativeAccepted=false,releaseAccepted=false. Missing:
pending-mutation,committed-receipt,refused-mutation-receipt,
disconnect-unknown-no-replay,rebind,exact-reachable-delay. Do not count catalog
read/refusal/disconnect controls as those missing mutation witnesses. Root
retains canonical freeze while positive extensions remain drafts.

Fifth actual Quint-Kit correspondence receipt found authenticated bus18:56:13
from q-origin tolead: applied modeling/guidelines/review.md; ui-origin111–122
and ui-engine-rpc106–114 describe reduced queue/role/no-replay/D/identity
boundaries, NOT full DesktopPolicy semantics. No worker Quint execution.
Allfive actual usage receipts now retained; no inference from identity names.
