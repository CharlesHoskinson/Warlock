# `gemini-gui` Wave `20261101T220528Z` Final Updated Handoff (`2228`)

## 1. Primary `HttpPopup` Retained-Query-on-Transport-Failure (Frozen, RED->GREEN `elm-cpu-1793571720808943074`)
- **Source patch**: `gemini-gui-http-popup-retained-query-source-2205.patch` (`sha256:fcf8f9c0803ef723cf8284ed4a91126a138cdedc8add8def3750ae746c66d3df`)
  - `implementation/warlock/src/HttpPopup.elm`: `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354` -> `e814d56f212765154436c1ab01cc2657b669a6d5d68f5c6d2180ccb64c9eeeb3`
- **QA patch**: `gemini-gui-http-popup-retained-query-qa-2205.patch` (`sha256:08748bbe5cb046beecc3de53de97aa7350fcc9b729cb038a3edb271c372bb6dc`)
  - `implementation/warlock/qa/ui-http.cjs`: `66630f5becf42691f132973a6c66959d328e17ddade428bef6a83a95b9e45cdd` -> `da32ed550a2afeaa062367ab4cf366e985fe469bf43f223a0301b3da4725933a`
- **Atomic bundle**: `gemini-gui-http-popup-retained-query-bundle-2205.patch` (`sha256:30a0eb4a8e1e1c53580fecf10ee5f1f5d59bef29b7939729f2aec9121757b783`)
- **5 Independent CONCURs**: `sol-docs` (`01M6CJTXPJ3Q1D561TEDQC4Q3K`), `terra-browser` (`01M6CJQSBZZ0QVZJVCSEJFTPS3`), `terra-q-http` (`01M6CJR4QJPG6RNQ5WXR8PACRN`), `terra-q-front` (`01M6CJR9E98CV50XADM38CHQHM`), `gemini-site` (`01M6CK609K9GK15X27NG0609CG`, `0c9985c4...`).
- **Corrected Quint Model SHA-256 (`terra-q-http` `01M6CK8M2BARCGSNMH14XVZPFY`)**: `terra-q-http-popup-loss-2213.qnt` = `1a8ed9c33032cf4af2a2a58a4042a4b716ed016084e9ed8725c1171477d28d84` (superseding `57b69c0f`).
- **Manual Restart vs Actual Recovery & WebKitGTK `Browser.Navigation.reload` Analysis**:
  - Current `e814d56f` preserves read-only draft/confirmed field only; manual restart initializes clean (`Popup.initial` + `UiHttp.initial`, zero auto-restore and zero unconfirmed replay).
  - Source check (`Warlock/Ui/Policy.hs:82-83,105-111` + `Warlock/Ui/WebKit.hs:83-87,442-462`): `Browser.Navigation.reload` (`document.location.reload(false)`) is allowed by `navigationAllowed` (`documentUri` = `http://127.0.0.1:<port>/index.html`) when the HTTP listener is alive, **but if the HTTP listener is unreachable**, main-frame `load-failed` (`WebKit.hs:448-452`) sets `loadFailed = True` and exits the entire `runWebKit` loop (`WebKit.hs:462`), destroying the retained read-only draft. Keep read-only preservation separate from any reload button.

## 2. Minimal `Bar.elm`-Only Waiting Placeholder + `ui-http.cjs` Fixture Atop `da32ed55` (`01M6CKCP29TDZ66NSTTHPA3NPV`)
- **Source patch**: `gemini-gui-bar-waiting-placeholder-source-2228.patch` (`sha256:becb4c2b4216a38d9fe168c98088160bd397640e7846a33a18a0d40256f4e52d`)
  - `implementation/warlock/src/Bar.elm`: `aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7` -> `0066a2c484c922e34453c4e6f2668c7ac596bbd5c814acf8596d4d8993d129b6`
  - `implementation/warlock/src/HttpBar.elm` (`74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8`) alert/error handling **UNCHANGED**.
  - Renders `"Waiting for desktop controls"` (`data-bar-state="waiting"`, `role="status"`, `aria-live="polite"`, `Settings.defaults` Night theme / reduced motion, zero `<button>` / action authority) both before first frame and after malformed-presentation invalidation.
- **QA patch (atop `da32ed55`)**: `gemini-gui-bar-waiting-placeholder-qa-2228.patch` (`sha256:271339639df5ffcf83cb23cfb0591453b9fabad2f214948ca79265d836ed2986`)
  - `implementation/warlock/qa/ui-http.cjs`: `da32ed550a2afeaa062367ab4cf366e985fe469bf43f223a0301b3da4725933a` -> `a29d40bac5728cdfd7a56fbcc60f66b3f44bb427a8eb5f24a761c44f6dfc8e8a` (and stacks cleanly with `0a1b3245...` -> `b786f5594ab9604a3ef33737a92012b8f49156af4348fe407b1d26d5a7d386ad`).
- **Atomic bundle**: `gemini-gui-bar-waiting-placeholder-bundle-2228.patch` (`sha256:2f742fef1103e030fe59787e553bc1ddd85943c98a924af9db9beaf320f03b45`)
- **Independent UX Peer Review**: `terra-browser` CONCUR (`01M6CKSAPQ9112YCFFBVDQ7ZE8`); notes dark waiting placeholder is a negative control for Apps-button readiness (require `[data-surface-control="bar:applications"]`).

## 3. Retained Next-Wave Artifacts & Peer Review Receipts
- `Surface.elm` `applicationOnly` matching status: `522d858ca3a0e022ab660a2990005333d3ee777119178d0c3a631ad2ecda5856` + `terra-browser` `20c0d925108a9cffe5085bc82aa0e54d70d899d44d3e50e04a5e61ffe6dc8f09` (`01M6CJZZC8EX3714H3CJ2PF7KA`).
- Peer review CONCUR on `terra-browser-ime-cancel-2224.mjs` (`sha256:a22711d9a017f752e73993b3f410bf13a2e52176dabd45a22d46d3aea3dcd7d3`, `01M6CKP9W90TWZ8EXVPEVTR26H`).
