{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY, UNEXECUTED SOURCE CONTROL. Requires exact projected v7 owner
-- (5a78c4a8...) plus terra-engine-owner-final-close-delay-seam.patch.
-- Each case uses a separately owned selected child and independently supplied
-- test StopBudget; it never changes the existing 28s/30s diagnostic budget.
-- The hook simulates scheduler delay BEFORE timeout starts, not a real slow or
-- noninterruptible kernel close. No native/provider/descendant acceptance.
module OwnerFinalCloseDeadlineControls (runOwnerFinalCloseDeadlineControls) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless, when)
import Data.IORef (newIORef, readIORef, writeIORef, modifyIORef')
import System.IO (Handle)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError)
import Warlock.Capture.Process.Persistent
  ( PersistentOwner, PersistentStatus(..), PidfdCustody(..), SessionExit(..)
  , newPersistentOwner, persistentStatus, persistentPidfdCustody
  , startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal
  ( persistentFixture, withPersistentOwnerHook )

data Case = Positive | FinalCloseSampleDelay deriving (Eq,Show)
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("owner-final-close: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- Caller must publish the fresh owner and exact input handle to a durable
-- recovery owner before return; it retains them on any failure/uncertainty.
-- The helper never closes a possibly retained process or fd on a failed case.
-- verifyReady must establish this same selected child's real startup readiness.
runOwnerFinalCloseDeadlineControls :: (PersistentOwner -> IO Handle) -> FilePath -> [String]
  -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runOwnerFinalCloseDeadlineControls acquireAndRetain executable args verifyReady =
 mapM_ runOne [Positive,FinalCloseSampleDelay]
 where
  runOne testCase = do
   owner <- newPersistentOwner
   input <- acquireAndRetain owner
   startup <- startBudgetAfter 3000000 >>= must
   stop <- must (stopBudgetMicros 1000000)
   delayed <- newIORef False
   pidfdAttempted <- newIORef (0 :: Int)
   let stall stage = do
        when (stage == "persistent-in-pidfd-close") (modifyIORef' pidfdAttempted (+1))
        let target = case testCase of
             FinalCloseSampleDelay -> "qa-stderr-after-budget-sample"
             Positive -> "no-such-hook"
        when (stage == target) $ do
         writeIORef delayed True
         -- More than the entire one-second stop budget; never substitutes a D.
         threadDelay 1200000
   outcome <- withPersistentOwnerHook owner
    (persistentFixture executable args input) 4096 startup stop verifyReady (\_ -> pure ()) stall
   state <- persistentStatus owner
   custody <- persistentPidfdCustody owner
   sawDelay <- readIORef delayed
   attempts <- readIORef pidfdAttempted
   let failed = case outcome of Left (ExitUncertain _ _) -> True; _ -> False
       quarantined = case state of PersistentQuarantined _ -> True; _ -> False
   case testCase of
    Positive -> check "positive owner retires" (case outcome of
     Right ((), LeaderReaped _) -> state == PersistentRetired && custody == PidfdClosed && attempts == 1
     _ -> False)
    FinalCloseSampleDelay -> do
     check "final-close sample delay was reached" sawDelay
     -- A close that actually completed may be recorded as closed; it does not
     -- become an in-budget cleanup receipt merely because the call returned.
     check "late final close cannot report clean retirement" (failed && quarantined && custody == PidfdClosed)
