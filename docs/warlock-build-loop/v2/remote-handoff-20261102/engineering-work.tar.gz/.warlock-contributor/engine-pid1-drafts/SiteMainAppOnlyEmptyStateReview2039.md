# 2039 Website Onboarding/Keyboard Patch & App-Only Empty-State Peer Review (`gemini-site`)

## 1. Website Elm Onboarding & Semantic Keyboard/Focus Deliverables (`2039`)

- **Foreign Uncommitted Preimage (`site/src/SiteMain.elm` — untouched)**:
  - Path: `/home/charl/code/Warlock/site/src/SiteMain.elm`
  - SHA-256: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`
  - `site/elm.json` SHA-256: `ffe9bc4f6811166a7bbafca49540bf7b8af214118dd9aff2f4707890eb9824dc`
- **Deliverable 1A (Frozen `v1` Patch) — `SiteMainOnboardingKeyboard2039.patch`**:
  - Path: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainOnboardingKeyboard2039.patch`
  - Patch SHA-256: `07b9565922f585ab227f24e5751b2abdb1c71a5afd7da3b17a367275a1e37697`
  - Postimage SHA-256: `b71532a2bdb398396ab72fffc195ff0d73616abbd4b4ea594ae11ef269f912bc`
- **Deliverable 1B (Composition-Hardened `v2` Patch per `terra-browser` `01M6CE45YKWT23QPX6QRQQMY1Y` & `01M6CE48YZAD3T7FV2DYP0B1VB`) — `SiteMainOnboardingKeyboard2039v2.patch`**:
  - Path: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainOnboardingKeyboard2039v2.patch`
  - Patch SHA-256: `55c7b7f57d8df1639f67af0f49d74e7c09737b7fb8cb4c820621f6520060677d`
  - Postimage SHA-256: `fdea1c7575f93ecbf46e17bdc3f29715fe40ac9ddc3e0a955002daf12d396530`
  - Adds `decodeNonComposingKey` (`isComposing == True || keyCode == 229 || key == "Process"` rejected) shared by `decodeEscapeKey` and `decodeWorkbenchTabKey`.
- **Deliverable 2 (`Platform.worker` Pure-Elm Replay Module)**:
  - `SiteMainKeyboardFocusReplay2039.elm` SHA-256: `de9ca31386f0b8c7d173bffa7964d4adebbfd177d2cb2ba1a97e790135b400e0`
  - `SiteMainKeyboardFocusReplay2039v2.elm` SHA-256: `de9ca31386f0b8c7d173bffa7964d4adebbfd177d2cb2ba1a97e790135b400e0`
- **Deliverable 3 (Structured Browser Semantic Keyboard/Focus Acceptance Oracle)**:
  - `SiteMainKeyboardFocusOracle2039.json` SHA-256: `440dd73ec5550ad08566235dd3a9388e29a3954a8cb0a2bbf1bb1ea5d21f7d41`
  - `SiteMainKeyboardFocusOracle2039v2.json` SHA-256: `b6a7a8a25887100a0dce51041a6f0fdedbf443477aed36581409c99f68bc3729` (adds `KBD-06` physical `Dom.focus` side-effect race check under rapid close/reopen/tab-switch and `KBD-07` W3C UI Events IME composition guard check).
- **Explicit Qualification**:
  - Neither `elm make` nor headless browser execution was run by `gemini-site` (protected execution belongs exclusively to Root `lead`).
  - As `terra-browser` noted (`01M6CE45YKWT23QPX6QRQQMY1Y`), `FocusSettled` sequence/target guards in pure Elm only prevent stale model receipt updates *after* `Dom.focus` has already attempted the DOM side effect; pure replay cannot prove the absence of physical focus races under rapid close/reopen or cross-target transitions (`KBD-06`).
  - All copy is source-matched to **`16 / 242` whole EARS** (`ELM-TEA-002` pure update accepted at `889e9458d`; `ELM-TEA-001` incomplete), **`40 / 417` scenarios**, and **live Omarchy VM app-only component scope under a 28-second diagnostic trial budget** (not a persistent desktop session, window controls and provider cleanup unqualified, no native Omarchy installer).

---

## 2. Peer Review of `gemini-gui` 2039 App-Only Empty-State Deliverables

### Reviewed Artifacts & Verified Digests
1. `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.patch`
   - SHA-256: `4194a3e206aecf31cd2987d803167ed0d904b1a33b6369b7223c907b40347869`
   - `git -C /home/charl/code/Warlock apply --check`: **PASS (`rc = 0`)** against canonical `Surface.elm` (`65120ff4...`), `SurfaceRenderer.elm` (`d6cc2985...`), and `SurfaceTheme.elm` (`be9d20b7...`).
2. `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch`
   - SHA-256: `67a3b21fdb49ee0e789b6c710ad5fa79ba6f725fffb6c4edfa96d370542149af`
   - `git -C /home/charl/code/Warlock apply --check`: **PASS (`rc = 0`)**.
3. `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.md`
   - SHA-256: `d1ccfbc27c9eed1cfeec60f27f2096d649ab08886e534f6f90df264c183cd78e`

### Technical Findings & Three-Way Merge Assessment
1. **Clean Orthogonality with `Popup.elm` / `SurfaceSnapshot.elm` Pending-Query Patches**:
   - Because `gemini-gui-app-only-hierarchy-empty-state-2039.patch` (`4194a3e2...`) touches only `Surface.elm`, `SurfaceRenderer.elm`, and `SurfaceTheme.elm` (leaving `Popup.elm` and `SurfaceSnapshot.elm` untouched), it avoids the `Popup.elm:54` hunk collision with `gemini-gui-popup-pending-query-mvp-2016.patch` (`1c7393cd...`) and `terra-browser-pending-query-feedback.patch` (`d38d4d64...`).
   - Note for Root integration: if Root also desires `applications`-mode empty-state cards (`empty:applications-no-match` / `loading` / `unavailable`) from `AppOnlyHierarchyEmptyState.patch` (`ef1bb568...`), those cards must be gated on `queryConfirmed = (model.pendingQuery == Nothing && not (isComposing model))` in `Popup.elm`. By scoping `4194a3e2...` strictly to `snapshot.mode == "closed" && List.isEmpty snapshot.popup`, `4194a3e2...` requires no `Popup.elm` change.
2. **Closed App-Only Heading & Empty-State Card (`SurfaceRenderer.elm:31-60`)**:
   - Strips only the single exact `Surface.elm:442` compact prefix (`"Compact presentation; open Applications, search or use pages for every application and pin action. · "`), checks `isCanonicalAppOnlyNotice` (`canonicalContextStatus == "Applications connected. Window controls unavailable." || String.endsWith " · Applications connected. Window controls unavailable." canonicalContextStatus`), replaces misleading `h1` `"Choose a window"` with `"Application workspace"` when `snapshot.mode == "closed" && isCanonicalAppOnlyNotice`, and renders keyed `("empty:closed-app-only", ...)` (`"Open Applications to browse the catalog"` / `"Select Applications in the taskbar to search entries, manage taskbar pins, or refresh the list."`).
   - Preserves `SurfaceSnapshot` wire JSON, `controlIdentities`, direct-child `.surface-popup > h1`, `.surface-popup > p[role="status"]`, `.surface-popup > .surface-controls` selectors, and introduces zero view-side `entry:*` heuristics or `data-surface-scope` overclaims.
3. **Important Integration Precaution on `Surface.elm:440-445` Hunk**:
   - `4194a3e2...` modifies `Surface.notice` so that when `mode model == "closed" && model.windows.shell.applicationOnly && contextNotice model /= Shell.status model.windows.shell` (which occurs in closed app-only mode when `pins.notice`, `Launch.status`, or `catalogFailure` overrides `contextNotice`), `Surface.notice` appends `" · Applications connected. Window controls unavailable."`.
   - While this keeps `isCanonicalAppOnlyNotice` true after a closed-mode launch/pin/catalog-failure notice, Root should verify during `check_elm_cpu.py` / `standalone-mvp.cjs` / `feedback-context-browser.mjs` that no existing test asserts exact string equality on `Surface.notice` (e.g. `"Launch submitted."` or `"Applications were not opened. Choose Applications again."`) in `applicationOnly` closed mode without the suffix. If any existing CPU/browser assertion expects the unsuffixed string, dropping the `Surface.elm` hunk while keeping `SurfaceRenderer.elm` + `SurfaceTheme.elm` preserves 100% of existing `Surface.notice` strings and still renders `"Application workspace"` + `empty:closed-app-only` in normal idle app-only closed mode.
4. **Proper Qualification of VM `run-01` & `attempt-02/run-01` Evidence**:
   - `run-01` (`host-journey-result.json` `9c0ecae8...`): first QMP motion `not-dispatched` (`AssertionError`), `guestTrialResult.exit = 1`, `providerCleanupQualified = false`, `28.704s` controller elapsed including cleanup — not clean normal retirement.
   - `attempt-02/run-01` (`host-journey-result.json` `89f2cb5e...`): `001-applications-ready.png` (`97f3cc6a...`) showed top bar (`y=40..94`) still unpainted white `(253,252,253)` when `001` was captured and `Applications` click dispatched (`qmpReceiptCount = 4`), while `002..006` showed the bar rendered with a WebKitGTK horizontal scrollbar at `y=79..88` and the bottom pane still in `"Choose a window"` (`guestTrialResult.exit = -9`, `forced = true` at `28.081s`). Adding `style "scrollbar-width" "none"` in `SurfaceTheme.barActionsStyles` is a sound preventative CSS hygiene improvement alongside the host-driver bar-pixel readiness gate, without claiming live-VM proof before Root's next bounded run.
