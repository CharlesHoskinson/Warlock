{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED: one Case per independently guarded QA process; real
-- config, owned display and original startup D; retain Case/worker/guardian on
-- error or watchdog timeout. Scope hooks are QA only and convey no authority.
module QHttpPreFirstStepControls (Mode(..),Case,newCase,releaseBarrier,runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,newIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
 loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
 persistentBackendCounts,persistentBackendStartupRefusal,qaFirstStepHooks,qaFirstStepObservations)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P

data Mode = StopBeforeFirst | StopDuringFirst | NoStopPositive deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 stopBudget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions stopBudget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ release _ _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
-- This is an outer QA watchdog, not a changed operation or cleanup deadline.
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
runCase :: Case -> Mode -> FilePath -> IO ()
runCase c@(Case owner start entered release completed worker used) mode path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "fresh case" fresh
 exists <- doesPathExist path
 check "real config" (isAbsolute path && exists)
 initial <- qaFirstStepObservations
 check "no previous entries" (initial == (0,Nothing))
 loaded <- restore (within "config" (loadPersistentBackendConfig owner path))
 check "same owner loaded config" (loaded == Right ())
 let barrier = putMVar entered () >> readMVar release
 case mode of
  StopBeforeFirst -> qaFirstStepHooks barrier (pure ())
  StopDuringFirst -> qaFirstStepHooks (pure ()) barrier
  NoStopPositive -> qaFirstStepHooks (pure ()) (pure ())
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar completed result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  case mode of
   NoStopPositive -> let waitDisplay = do
                            observation <- qaFirstStepObservations
                            if observation == (1,Just (Right ())) then pure () else do
                             ended <- tryReadMVar completed
                             case ended of
                              Just _ -> ioError (userError "actor ended before real display completion")
                              Nothing -> threadDelay 1000 >> waitDisplay
                     in within "display positive" waitDisplay
   _ -> within "selected preparation barrier" (readMVar entered)
  observation <- qaFirstStepObservations
  case mode of
   StopBeforeFirst -> check "scope entered; first action unentered" (observation == (0,Nothing))
   StopDuringFirst -> check "actual display action entered" (observation == (1,Nothing))
   NoStopPositive -> check "actual display completed" (observation == (1,Just (Right ())))
  stop <- within "same-owner stop" (requestPersistentBackendStop owner)
  case mode of
   NoStopPositive -> pure ()
   _ -> check "stop latched in actual preparation scope" (stop == P.StopLatchedBeforeLive)
  releaseBarrier c
  outcome <- within "actor completion" (readMVar completed)
  actual <- either throwIO pure outcome
  final <- qaFirstStepObservations
  case mode of
   StopBeforeFirst -> check "zero-entry known refusal survives complete production scope" $
    final == (0,Just (Left (P.StartupAdmissionRefused SessionClosed))) &&
    persistentBackendStartupRefusal actual == Just (P.StartupAdmissionRefused SessionClosed) &&
    persistentBackendCounts actual == (0,0)
   StopDuringFirst -> check "in-flight action remains unknown" $
    final == (1,Just (Left P.StartupAdmissionUnknown)) &&
    persistentBackendStartupRefusal actual == Just P.StartupAdmissionUnknown &&
    persistentBackendCounts actual == (0,0)
   NoStopPositive -> check "real display positive" (final == (1,Just (Right ())))
