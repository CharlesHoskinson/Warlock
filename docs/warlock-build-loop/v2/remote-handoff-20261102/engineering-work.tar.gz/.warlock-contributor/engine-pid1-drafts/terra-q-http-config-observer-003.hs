-- QA-ONLY same-module fragment appended/exported in isolated Backend actor014
-- build, with QA Store seam002. Read-only: no config, fd or mutator escapes.
-- Acquiring count must be observed only at a stable held-after-acquire barrier.
qaPersistentConfigState :: PersistentBackendOwner -> IO (Bool,Bool,Bool,Bool,Int)
qaPersistentConfigState (PersistentBackendOwner _ _ _ _ _ _ _ _ _ _ used store installed confirmed) = do
  seen <- readIORef used
  owner <- readIORef store
  value <- readIORef installed
  receipt <- readIORef confirmed
  acquiring <- maybe (pure 0) qaStoreAcquiringCount owner
  let present x = case x of Nothing -> False; Just _ -> True
  pure (seen,present owner,present value,receipt,acquiring)
