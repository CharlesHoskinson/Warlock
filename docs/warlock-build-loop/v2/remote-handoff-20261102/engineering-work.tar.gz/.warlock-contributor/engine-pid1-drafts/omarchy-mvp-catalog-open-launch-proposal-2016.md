# Native App-Only MVP Catalog `Open <App>` Diagnosis, Architectural Separation & Minimal Typed Launch Proposal (`2016`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **AgentBus Run**: `warlock-20261031-setup`
- **Inspected Git Commit**: `59a2f38ab2b26f6d76cad34039b59911a36188dc` (`ELM-TEA-002` `tea-pure-update` accepted at immutable Elm source commit `889e9458d1707c456f5bb6e9af560383b066229e`; `16 / 242` whole requirements, `40 / 417` scenarios; `nativeOperations = []`; `HOSTSTOP2` preserved)
- **Status**: Source-bound architectural diagnosis + minimal typed interface/implementation proposal (design draft only; zero canonical source edits; zero acceptance claims)

---

## Executive Answer

1. **Why every catalog `Open <Name>` (`entry:<id>`) button is disabled today**:
   - The Elm `Launch` domain is **already** bound (`Desktop.elm:430` -> `Launch.bind`) and **already** receives the live catalog snapshot (`Desktop.elm:1091` -> `Launch.catalog`), so `Launch.select` (`Launch.elm:88-104`) would already return `Just selection`.
   - However, `"application-attached"` (`Backend.hs:193-196` -> `Desktop.hs:200` -> `Shell.elm:179-188`) sets a single coarse boolean `model.windows.shell.applicationOnly = True` that conflates *"compositor window operations unavailable"* with *"host `.desktop` launching unavailable"*.
   - **Four concrete source gates** currently block or break catalog `Open <Name>` in app-only MVP mode:
     1. **UI Surface Gate (`Surface.elm:310-314`)**: `ready = not model.windows.shell.applicationOnly && ...` evaluates to `False`, forcing `choice = Nothing`, `enabled = False`, `message = Nothing` on every `entry:<id>` (`Open <Name>`) control.
     2. **TEA Pointer-Ownership Gate (`Desktop.elm:621, 732-742` + `PointerOwnership.elm:25-33`)**: App-only sessions have no native compositor pointer observer (`PointerOwnership.blocked == True`). `gestureAction (Start _)` is `True` (`Desktop.elm:758`), and `applicationGesture` (`Desktop.elm:732-742`) omits `Start _`. Even if `Surface.elm:310` enabled the button, `Desktop.updateOrdinary` (`L621`) would silently drop `Desktop.Start selection`.
     3. **OutputController Batch & Oversize Gates (`OutputController.elm:274, 286-291, 296-300` vs `Warlock/Ui/Owner.hs:211-218`)**: `OutputController.register` omits `"application-launch"` from local oversize accounting (`L274`) and pushes every bound request commit onto `model.batches` (max `16`, `L296`), whereas real `Owner.hs` never emits `"view-disposition"` (`"admitted"`, enforced by `test-ui-origin/Main.hs:308-315`) — locking out all outbound requests on the **17th** interactive refresh/pin/launch in a live session unless pure-application batches retire upon authoritative backend reply.
     4. **Haskell Protocol & Backend Authority Gap (`Warlock/Protocol/Desktop.hs:21-30, 117-123, 197-248`, `Warlock/Backend/Catalog.hs:39-48, 83-87`, `Warlock/Backend.hs:131-185`)**: Haskell currently implements only `CatalogRead` (`"catalog-request"`) and `PinsWrite` (`"taskbar-pins-write"`). Any `"application-launch"` request hits `Left "unsupported desktop request kind"` (`Desktop.hs:123`) -> `Owner.hs:210` `HTTP 400`, `.desktop` parsing discards provenance/Exec fields, and `Warlock.Backend` has no `lastLaunch` high-water / `Unknown`-before-fork / no-replay state or ordinary-session spawner.

2. **Is safe approved Haskell host application launching separable from unsupported compositor window operations?**
   - **Yes — cleanly and strictly separable, without fake `"attached"` grants and with `"nativeOperations": []` preserved.**
   - Compositor window operations (`minimize`, `restore`, `activate`, `maximize`, `pin` always-on-top, `snap`, `transfer-workspace`, window menus/pickers, overview, switcher) mutate live compositor window incarnations via `Warlock.Native.Cancellation` + an ABI-paired compositor provider. Those **must remain disabled** (`"nativeOperations": []`, `Shell.available == False`).
   - Crucially, **taskbar pin launching (`bar:pin:<id>` at `Surface.elm:409`) and `NewInstance` (`Desktop.elm:1375`) must ALSO remain disabled** while `Shell.available == False`: per `ELM-UI-004` (`docs/elm-roadmap/requirements.json:5094`), activating a taskbar pin must obey the `0 / 1 / >1` open-window family table *without launching duplicates when windows already exist*, which is unknowable without compositor window observation.
   - By contrast, clicking **`Open <Name>` (`entry:<id>`) inside the Applications popup** (`Surface.elm:310-314`) is an explicit user request to launch a verified XDG `.desktop` entry from the pinned catalog generation. Executing that `.desktop` entry in `warlock-ui-backend` (which runs in the ordinary user host session `UID 1000`, **outside** `warlock-ui-owner`'s private network/user namespaces and **outside** `Process.Bootstrap`'s self-destructing UI cgroup) requires **zero** compositor window authority, **zero** `nativeOperations`, and **zero** relaxation of per-operation `D` or no-replay invariants.

---

## 1. Exact Source Callchain Why `Open <Name>` Is Disabled Today

Tracing the live app-only MVP path on `59a2f38ab2b26f6d76cad34039b59911a36188dc`:

1. **Backend Attachment Emission (`implementation/warlock/haskell/runtime/src/Warlock/Backend.hs:193-196` & `implementation/warlock/haskell/protocol/src/Warlock/Protocol/Desktop.hs:200-207`)**:
   - When `BackendConfig.applicationAttachment == True`, `firstCommit` emits `D.ApplicationAttached (D.owner attached)` with `"kind": "application-attached"` and `"nativeOperations": []`.
2. **Shell Attachment Transition (`implementation/warlock/src/Shell.elm:179-188`)**:
   - `Shell.update (Incoming raw)` validates exact fields `["protocolVersion","kind","binding","nativeOperations"]` and `List.isEmpty operations`, transitioning to:
     `{ detached | applicationOnly = True, binding = Just binding, phase = Reconciling, reconnecting = False, notice = "Applications connected. Window controls unavailable." }`.
   - `Shell.available` (`Shell.elm:79`) returns `False` (`not model.applicationOnly && ...`).
3. **Launch Domain Is Already Bound & Populated (`implementation/warlock/src/Desktop.elm:428-431, 1091` & `implementation/warlock/src/Launch.elm:62-104, 180-255`)**:
   - `Desktop.windowBase` (`Desktop.elm:430`) detects `previousBinding == Nothing` -> `Just binding` and calls `Launch.bind (host binding) model.launch`.
   - When `"application-catalog"` arrives, `Desktop.update` (`Desktop.elm:1091`) calls `Launch.catalog receipt.snapshot model.launch`.
   - `DesktopPolicy.elm:51` (`Delay 10000 (Desktop.Deadline token)`) and `HttpMain.elm:31-32` (`Process.sleep`) already wire the per-operation Elm launch deadline (`10s` -> `Settled intent Unknown` -> `"control:acknowledge"`, zero silent retry), and `Desktop.elm:1105-1115` already decodes `"application-launch-outcome"`.
4. **Immediate UI Disabling Line (`implementation/warlock/src/Surface.elm:310-314`)**:
   ```elm
   ready = not model.windows.shell.applicationOnly && not (List.member (Launch.status model.launch) ["Pending","Unknown"])
   entryControl entry =
       let choice = if ready then Launch.select (Catalog.id entry.identity) model.launch |> Maybe.map Desktop.Start else Nothing
           label="Open "++entry.name
       in {id="entry:" ++ Catalog.id entry.identity, ..., enabled=choice/=Nothing, message=choice}
   ```
   Because `model.windows.shell.applicationOnly` is `True`, `ready` is hardcoded `False`, disabling every `entry:<id>` button.
5. **Secondary TEA Reducer Disabling Line (`implementation/warlock/src/Desktop.elm:621, 732-759` & `implementation/warlock/src/PointerOwnership.elm:25-33`)**:
   - `PointerOwnership.blocked` (`PointerOwnership.elm:28-33`) returns `True` whenever `binding == Just _` and `observation == Nothing` (always true in app-only sessions).
   - `Desktop.updateOrdinary` (`Desktop.elm:621`) blocks any `gestureAction` unless `model.windows.shell.applicationOnly && applicationGesture message`.
   - `Start _` is a `gestureAction` (`Desktop.elm:758`), and `applicationGesture` (`Desktop.elm:732-742`) lists `OpenApplications`, `RefreshApplications`, `CloseApplications`, `ApplicationsPage`, `SearchQuery`, `TogglePin`, `MovePin` — **omitting `Start _`**.
6. **Haskell Wire & Backend Rejection (`implementation/warlock/haskell/protocol/src/Warlock/Protocol/Desktop.hs:21-30, 117-123` & `implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs:205-210`)**:
   - `Desktop.hs:117-123` rejects `"kind": "application-launch"` with `Left "unsupported desktop request kind"`, causing `Owner.hs:210` to return `HTTP 400` on `POST /commit`.

---

## 2. Companion Live-Usability Trap Uncovered in `OutputController.elm` vs `Warlock/Ui/Owner.hs`

Inspecting the commit pipeline end-to-end uncovered a latent 16-action live-session lockup that directly affects interactive catalog search/refresh, pin writes, and launches:

1. **What `OutputController.register` does (`implementation/warlock/src/OutputController.elm:274-301`)**:
   - Every bound commit with non-empty `requests` (`catalog-request`, `taskbar-pins-write`, or `application-launch`) checks `List.length model.batches >= 16` (`L296`) and prepends a `Batch` to `model.batches` (`L300`).
   - Also, at `L274`, `applicationOnly = List.length catalogs + List.length pins == List.length requests` omits `"application-launch"`, so an oversized launch commit would set `batchExhausted = True` instead of settling locally as unsent.
2. **What `Owner.hs` actually sends (`implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs:211-218` & `test-ui-origin/Main.hs:308-315`)**:
   - Unlike the JS mock harness (`qa/ui-http.cjs`), real `Owner.hs` forwards `/commit` to `Warlock.Backend` and returns `204` **without** synthesizing `"view-disposition"` (`"batch-disposition"` `"admitted"`). Furthermore, `test-ui-origin/Main.hs:308-315` explicitly asserts that the next `GET /events` after a `[catalogRequest]` commit is `"native-event"` (`"application-catalog"`), **not** `"view-disposition"`.
   - Because `model.batches` is currently drained only in `receiveDisposition` (`OutputController.elm:345-378`), the **17th** interactive request (`Refresh`, `Pin`/`Unpin`, or `Open <Name>`) in a real Omarchy session hits `List.length model.batches >= 16` -> `refuse ()` -> `batchExhausted = True` (`"The request was not sent. Waiting for window transport recovery."`) permanently.
3. **Minimal Test-Preserving Resolution (`OutputController.elm`)**:
   - Keep `Owner.hs` unchanged (preserving `test-ui-origin/Main.hs:308-315`) and keep `Batch` insertion + `receiveDisposition` unchanged (preserving all `preflight-unsent` / `admitted` `OutputController` CPU tests).
   - Add `pins : List CatalogRequest` and `launches : List LaunchBatchRequest` to `Batch` (`L37`), include `launches` in `applicationOnly` (`L274`) + local `Desktop.LaunchUnsent` settlement (`L288`), and in `OutputController.updateCore` (`L108-133`), when `Desktop.Incoming raw` delivers an authoritative backend reply (`"application-catalog"`, `"taskbar-pins-outcome"`, `"application-launch-outcome"`) matching a pending request in a pure-application batch (`List.isEmpty batch.observations && List.isEmpty batch.operations`), mark that request satisfied and remove the `Batch` once its application requests are empty.

---

## 3. Architectural Separation Proof: Host `.desktop` Launch vs Compositor Window Operations

| Dimension | Compositor Window Operations (Remain Disabled) | Approved Host `.desktop` Launch (Separable & Safe) |
| :--- | :--- | :--- |
| **Authority & Wire Grant** | `"attached"` + non-empty `nativeOperations` / `action-projection` / `geometry-facts` | `"application-attached"` with **`"nativeOperations": []`** + explicit optional `"hostLaunch": true` |
| **Elm Capability Predicate** | `Shell.available model.windows.shell == False` | `Shell.catalogLaunchAvailable model.windows.shell == True` (closed sum type; aligns with `ELM-TEA-001`) |
| **Controls Enabled** | **None** (`bar:overview`, `bar:switcher`, `bar:group:*`, `bar:pin:*`, `jump:open:*`, `NewInstance`, `files`, `system`, `notifications`, `settings` all stay disabled) | **Only** explicit Applications popup `entry:<id>` (`Open <Name>`) + `control:acknowledge` on `Unknown` |
| **Why `bar:pin:<id>` Stays Disabled** | `ELM-UI-004` (`requirements.json:5094`) forbids taskbar pin duplicate launches when windows already exist; requires compositor scene observation | Explicit catalog `Open <Name>` inside Applications is an unambiguous launch command in `ELM-UI-004` / `Launch.elm` |
| **Executing Process & Context** | Future ABI-paired compositor provider + `Warlock.Native.Cancellation` journal | **`warlock-ui-backend`** (`Warlock.Backend`), running in the ordinary host user session (`UID 1000`), **outside** `warlock-ui-owner` private net/user namespaces and **outside** `Process.Bootstrap` UI cgroup |
| **Deadline `D` & No-Replay** | `Warlock.Native.Cancellation` host reservation slots | `lastLaunch` high-water cell in `Warlock.Backend`: `Unknown` (`"submission-not-confirmed"`) persisted **before** `fork`/`execve`; duplicate `(request, intent)` resends stored reply without re-spawning; `CLOEXEC` exec-status pipe bounded by `D_op = min(remainingBackendD, perLaunchBudgetNs)` |

### Why `warlock-ui-backend` Preserves Ordinary Apps Host Context
- `warlock-ui-owner` enters a private network namespace (`Warlock.Ui.PrivateNetwork`) and spawns WebKit inside unprivileged user/PID/mount namespaces; `Warlock.Capture.Process.Bootstrap` places the UI child inside a dedicated cgroup killed when UI session deadline `D` expires. Launching user apps from `warlock-ui-owner` or inside the UI cgroup would either trap the app without network/DBus/host UID map or kill the user's launched app when the Warlock popup closes!
- `warlock-ui-backend` runs in the ordinary host desktop session (`UID 1000`). At backend startup (before spawning any UI child, mirroring `DisplayEnvironment` capture before namespace entry), `Warlock.Backend.LaunchEnv` captures an immutable opaque `HostLaunchEnvironment`:
  - Verified user identity (`euid == uid`, non-zero ordinary user) and working directory fallback (`HOME` directory verified as accessible directory, else `"/"`).
  - Explicit allowlisted ordinary session environment variables only (`HOME`, `USER`, `LOGNAME`, `PATH`, `LANG`, `LC_ALL`, `LC_CTYPE`, `TZ`, `XDG_RUNTIME_DIR`, `WAYLAND_DISPLAY`, `DISPLAY`, `XDG_SESSION_TYPE`, `XDG_CURRENT_DESKTOP`, `XDG_SESSION_DESKTOP`, `DESKTOP_SESSION`, `DBUS_SESSION_BUS_ADDRESS`, `XDG_DATA_DIRS`, `XDG_CONFIG_DIRS`, `XDG_DATA_HOME`, `XDG_CONFIG_HOME`, `XDG_CACHE_HOME`, `XDG_STATE_HOME`) — stripping all `WARLOCK_*`, `LD_PRELOAD`, `LD_LIBRARY_PATH`, `WEBKIT_*`, `GSETTINGS_*`, and test-harness variables.
  - Detached spawn (`setsid()` + detached intermediate fork, FDs `0, 1, 2` opened to `/dev/null`, all FDs `>= 3` except the `O_CLOEXEC` exec-status pipe closed via `close_range` / bounded sweep, signal mask cleared and `SIGPIPE`/`SIGCHLD` reset to `SIG_DFL`, optional `Path=` `chdir` validated before `execve`, direct `execve(resolvedExecutable, argv, cleanEnv)` with **zero `/bin/sh` invocation**).

---

## 4. Minimal Typed Interface & Implementation Proposal

### 4.1 Elm Changes (`src/Shell.elm`, `src/Surface.elm`, `src/Desktop.elm`, `src/OutputController.elm`, `src/Launch.elm`)

1. **`Shell.elm` — Closed Sum Type Replacing Raw `applicationOnly : Bool` (Directly Supports `ELM-TEA-001`)**:
   ```elm
   type AttachmentMode
       = WindowShellMode
       | ApplicationOnlyMode HostLaunchCapability

   type HostLaunchCapability
       = HostLaunchUnavailable
       | HostDesktopLaunch
   ```
   - Expose `applicationOnly : Model -> Bool`, `available : Model -> Bool` (unchanged semantics: `True` **only** when `mode == WindowShellMode && phase == Ready && ...`), and `catalogLaunchAvailable : Model -> Bool`:
     ```elm
     catalogLaunchAvailable : Model -> Bool
     catalogLaunchAvailable model =
         model.binding /= Nothing
             && model.phase /= Detached
             && model.phase /= Exhausted
             && (case model.attachmentMode of
                     WindowShellMode -> True
                     ApplicationOnlyMode HostDesktopLaunch -> True
                     ApplicationOnlyMode HostLaunchUnavailable -> False
                )
     ```
   - Backward-compatible `"application-attached"` decoder (`Shell.elm:179-188`):
     - Always require `"protocolVersion": 3`, `"kind": "application-attached"`, `"binding"`, and **`"nativeOperations": []`** (still fails closed if `nativeOperations` is non-empty!).
     - Accept either exact 4-field `["protocolVersion","kind","binding","nativeOperations"]` -> `ApplicationOnlyMode HostLaunchUnavailable` (so **100% of existing `test-desktop`, `test-ui-mvp`, `test-ui-origin`, and `ui-standalone-bootstrap.qnt` vectors pass unchanged**) OR exact 5-field `["protocolVersion","kind","binding","nativeOperations","hostLaunch"]` with `"hostLaunch": Bool` -> `ApplicationOnlyMode (if hostLaunch then HostDesktopLaunch else HostLaunchUnavailable)`.

2. **`Surface.elm:310`**:
   ```elm
   ready =
       Shell.catalogLaunchAvailable model.windows.shell
           && not (List.member (Launch.status model.launch) [ "Pending", "Unknown" ])
   ```
   - `Surface.elm:324` (`jump:open:*`), `Surface.elm:409` (`bar:pin:*`), `Surface.elm:424` (`bar:notifications`, `bar:files`, `bar:system`, `bar:settings`), and `Desktop.elm:1375` (`NewInstance`) remain gated on `not (Shell.applicationOnly ...)` / `Shell.available`, preserving `ELM-UI-004` and empty window ops.

3. **`Desktop.elm:621, 732-742, 1383-1389` + `Launch.unsent`**:
   - In `Desktop.elm:732-742` (`applicationGesture`), add `Start _ -> True` (and in `Desktop.elm:621`, gate the `Start _` pointer-ownership exemption on `Shell.catalogLaunchAvailable model.windows.shell`).
   - In `Desktop.elm:1383` (`Start selection`), guard `if not (Shell.catalogLaunchAvailable model.windows.shell) || MenuBridge.preparedSnapshot model.windows.menus /= Nothing then (model, []) else ...`.
   - Add `Launch.unsent : Binding.Binding -> Intent -> Model -> Model` and `Desktop.LaunchUnsent Binding.Binding Launch.Intent` so local `OutputController` omission settles `Pending` cleanly to `Refused` without leaving `Launch` stuck in `Pending` until the 10s timer.

4. **`OutputController.elm:37, 108-133, 265-301`**:
   - Decode `"application-launch"` in `launchRequest` alongside `catalogRequest` and `pinRequest`; include `launches` in `applicationOnly` (`L274`) and settle via `Desktop.LaunchUnsent` in `refuse ()` (`L288`).
   - Retire pure-application `Batch` entries (`List.isEmpty batch.observations && List.isEmpty batch.operations`) when matching authoritative replies (`"application-catalog"`, `"taskbar-pins-outcome"`, `"application-launch-outcome"`) arrive in `Desktop.Incoming`, preventing the 17th-action `batches >= 16` exhaustion in live `Owner.hs` sessions while keeping `receiveDisposition` intact.

---

### 4.2 Haskell Protocol & Backend Changes (`Warlock.Protocol.Desktop`, `Warlock.Backend.Catalog`, `Warlock.Backend.Launch`, `Warlock.Backend`)

1. **`implementation/warlock/haskell/protocol/src/Warlock/Protocol/Desktop.hs`**:
   - Add closed ADTs matching `Launch.elm:169-206` & `Desktop.elm:1105-1115, 1388` byte-for-byte:
     ```haskell
     data LaunchIntent = LaunchIntent
       { launchRequest  :: !Counter
       , launchLifetime :: !Counter
       , launchCatalog  :: !Counter
       , launchEntry    :: !Text -- non-empty, <= 256 chars, no control chars < 32
       } deriving (Eq, Show)

     data LaunchRefusal
       = RetiredAuthority        -- "retired-authority"
       | RequestReuse            -- "request-reuse"
       | RetiredRequest          -- "retired-request"
       | CatalogUnavailable      -- "catalog-unavailable"
       | StaleCatalog            -- "stale-catalog"
       | RemovedEntry            -- "removed-entry"
       | NativeEntryUnavailable  -- "native-entry-unavailable"
       | DesktopEntryRaced       -- "desktop-entry-raced"
       deriving (Eq, Show)

     data LaunchOutcome
       = LaunchSubmitted                     -- status="Submitted", reason="native-submission-accepted"
       | LaunchUnknown                       -- status="Unknown",   reason="submission-not-confirmed"
       | LaunchRefused !LaunchRefusal        -- status="Refused",   reason=<exact Launch.elm token>
       deriving (Eq, Show)
     ```
   - Extend `DesktopRequest` with `ApplicationLaunch !Binding !LaunchIntent` (`"kind": "application-launch"`, exact fields `["protocolVersion","kind","binding","intent"]`).
   - Extend `DesktopReply` with:
     - `ApplicationAttached !Binding !Bool`: encodes exact 4-field `{"protocolVersion":3,"kind":"application-attached","binding":...,"nativeOperations":[]}` when `hostLaunch == False` (100% byte-identical for all existing tests!) and adds `"hostLaunch": true` (`"nativeOperations": []` still empty!) when `hostLaunch == True`.
     - `ApplicationLaunchReply !Binding !LaunchIntent !LaunchOutcome`: encodes `{"protocolVersion":3,"kind":"application-launch-outcome","binding":...,"outcome":{"catalogProtocol":1,"kind":"launch-outcome","intent":...,"status":...,"reason":...}}`.

2. **`implementation/warlock/haskell/runtime/src/Warlock/Backend/Catalog.hs`**:
   - Extend the backend-internal snapshot representation (`LoadedCatalog`, keeping wire `D.CatalogSnapshot` unchanged!) with a `Map Text PinnedDesktopEntry` recording:
     - Winning `(rootDirectoryPath, relativeDesktopPath)` (respecting XDG precedence where earlier roots shadow later roots by desktop ID),
     - `directoryStamp` + regular-file `(dev, ino, size, mtimeSec, mtimeNsec, sha256)` captured under `Warlock.Backend.Store` (`O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC` + `openat` `O_RDONLY | O_NOFOLLOW | O_CLOEXEC`),
     - Validated `LaunchPlan`:
       - If `Terminal=true`, `DBusActivatable=true` without valid `Exec`, missing/malformed XDG `Exec` quoting, unsupported/unsafe field codes, or non-executable `TryExec`/`Exec` target -> `UnlaunchableEntry` (yields `LaunchRefused NativeEntryUnavailable` when invoked; never invokes `/bin/sh`).
       - Otherwise `DirectExec { execPath :: OsPath, argv :: [ByteString], workingDir :: Maybe OsPath }` stripping XDG URL/file placeholders (`%f`, `%F`, `%u`, `%U`, deprecated `%d`/`%D`/`%n`/`%N`/`%v`/`%m`) when launching with zero file arguments and expanding `%%` -> `%`, `%c` -> localized name, `%k` -> `.desktop` path, `%i` -> `--icon <icon>` per XDG Desktop Entry Spec.

3. **`implementation/warlock/haskell/runtime/src/Warlock/Backend.hs` + `Warlock/Backend/Launch.hs` — Per-Operation `D` & Zero-Replay State Machine**:
   - `BackendConfig` adds optional `"applicationLaunch": Bool` (defaults to `False`; valid only when `"applicationAttachment": true` and `Maybe HostLaunchEnvironment` was captured at startup before any namespace/child setup).
   - `BackendState` adds `lastLaunch :: IORef (Maybe (Counter, D.LaunchIntent, D.DesktopReply))` and `activeCatalog :: IORef (Maybe LoadedCatalog)`.
   - On `D.ApplicationLaunch reqBinding intent`:
     1. **Authority & Monotonic High-Water Check (Pure / In-Memory)**:
        - `reqBinding /= bound || D.launchLifetime intent /= D.lifetime bound` -> reply `LaunchRefused RetiredAuthority` (do not advance `lastLaunch`).
        - If `lastLaunch` holds `(lastId, lastIntent, lastReply)`:
          - `D.launchRequest intent == lastId && intent == lastIntent` -> **return `lastReply` verbatim without touching filesystem or `fork`** (exact idempotent resend, zero replay, matching `lastWrite` at `Backend.hs:155-158` and `adapter/catalog_authority.py:55-58`).
          - `D.launchRequest intent == lastId && intent /= lastIntent` -> reply `LaunchRefused RequestReuse`.
          - `D.launchRequest intent < lastId` -> reply `LaunchRefused RetiredRequest`.
     2. **Stale/Removed/Race Verification Before Fork (`O_NOFOLLOW`)**:
        - Compare `D.launchCatalog intent` against `activeCatalog`:
          - `Nothing` -> `CatalogUnavailable` (recorded in `lastLaunch`).
          - `loadedGeneration /= D.launchCatalog intent` -> `StaleCatalog` (recorded in `lastLaunch`).
        - Re-stat all catalog root directories (`Store.directoryStamp`) and re-open/hash the winning `.desktop` file with `O_NOFOLLOW`:
          - Root directory stamp changed or shadowing higher-priority root gained same `.desktop` ID -> `DesktopEntryRaced` / `StaleCatalog`.
          - File disappeared -> `RemovedEntry`.
          - File stat/SHA-256 differs from pinned `PinnedDesktopEntry` -> `DesktopEntryRaced`.
          - Entry plan is `UnlaunchableEntry` or `TryExec`/executable resolution fails `X_OK` regular-file check -> `NativeEntryUnavailable`.
     3. **Pre-Commit `Unknown` Reservation + Bounded Detached Spawn (`D_op`)**:
        - **Before calling `fork`**, write `(D.launchRequest intent, intent, D.ApplicationLaunchReply bound intent D.LaunchUnknown)` into `lastLaunch`! If an asynchronous exception or deadline expiry interrupts after `fork` before pipe confirmation, `lastLaunch` permanently retains `LaunchUnknown` (`"submission-not-confirmed"`) and never replays!
        - Compute `D_op = min remainingBackendDeadline (nowMonotonicNs + perLaunchExecBudgetNs)` (e.g. `2_000_000_000` ns = `2s`, strictly inside Elm's `10s` `DesktopPolicy` timer and the `28s` session `D` with `8s` reserve).
        - Open `pipe2(..., O_CLOEXEC)`. Fork intermediate child -> `setsid()` -> fork grandchild -> close read end, redirect `0,1,2` to `/dev/null`, close all FDs `>= 3` except status write FD (`FD_CLOEXEC` set), reset signals, `execve(execPath, argv, cleanHostEnv)`. On `execve` failure, write `errno` (`4` bytes) to status pipe and `_exit(127)`. Intermediate child `_exit(0)` immediately; parent `waitpid`s intermediate child (microseconds, zero zombies) and `poll()`s the status pipe read end until `D_op`:
          - **`EOF` (`0` bytes read)**: `execve` succeeded (`O_CLOEXEC` closed write FD across `execve`!) -> update `lastLaunch` to `LaunchSubmitted` (`"native-submission-accepted"`) and return it.
          - **`errno` read (`4` bytes)**: `execve` failed cleanly before new image started -> update `lastLaunch` to `LaunchRefused NativeEntryUnavailable` and return it.
          - **`poll` timeout at `D_op` or `EINTR`/IO error**: close pipe; `LaunchUnknown` (`"submission-not-confirmed"`) is already persisted in `lastLaunch` -> return `LaunchUnknown`.

---

## 5. Proportional Verification Matrix (For Root Execution Under Serialized Gate)

1. **`protocol:test-desktop`**:
   - Round-trip & strict-field rejection tests for `ApplicationAttached _ False` (4 fields, byte-identical), `ApplicationAttached _ True` (5 fields, `"nativeOperations": []` still enforced, non-empty `nativeOperations` still rejected!), `ApplicationLaunch`, and `ApplicationLaunchReply` across all 10 `LaunchOutcome` status/reason pairs + malformed counters/control-char entry IDs.
2. **`runtime:test-ui-mvp` & `runtime:test-ui-origin`**:
   - Verify existing `applicationAttachment = True` (`applicationLaunch = False`) tests pass unchanged.
   - Add `applicationLaunch = True` test cases covering:
     - `Submitted` (`"native-submission-accepted"`) against a fixture `.desktop` writing a marker outside the UI namespace/cgroup;
     - Duplicate `(request, intent)` replay returning cached `Submitted` with spawn count strictly `== 1`;
     - Same `request` + different `intent` -> `Refused "request-reuse"`; lower `request` -> `Refused "retired-request"`; wrong `lifetime` -> `Refused "retired-authority"`;
     - Mutated `.desktop` between catalog snapshot and launch -> `Refused "desktop-entry-raced"`; deleted `.desktop` -> `Refused "removed-entry"`; old catalog generation -> `Refused "stale-catalog"`; `Terminal=true` -> `Refused "native-entry-unavailable"`;
     - Simulated `D_op` timeout before `execve` pipe close -> `Unknown "submission-not-confirmed"`, persisted in `lastLaunch` with zero retry.
3. **Elm & `OutputController` Property/Sequence Checks (`FUZZING-CONTRACTS.md`)**:
   - Verify `Surface.controls` in `ApplicationOnlyMode HostDesktopLaunch` enables `entry:<id>` (`Open <Name>`) while keeping `bar:overview`, `bar:switcher`, `bar:pin:<id>`, `jump:open:<id>`, `NewInstance`, `bar:files`, `bar:system`, `bar:notifications`, `bar:settings` disabled (`Shell.available == False`).
   - Verify `Desktop.update (Start selection)` passes `PointerOwnership.blocked` in `ApplicationOnlyMode HostDesktopLaunch` and is blocked in `ApplicationOnlyMode HostLaunchUnavailable`.
   - Verify `> 16` sequential `RefreshApplications` / `TogglePin` / `Start` round-trips against `Owner`-style `native-event` replies never hit `OutputController.batchExhausted`.
4. **Quint Model Alignment (`implementation/warlock/haskell/runtime/formal/ui-standalone-bootstrap.qnt`)**:
   - Preserve `nativeOperations == []` invariant while modeling `hostLaunch` as an orthogonal boolean capability on `ApplicationAttached` that enables only `ApplicationLaunch` in `warlock-ui-backend` without granting any compositor `WindowEffect`.

---

## 6. Peer-Review Addendum on `omarchy-mvp-authoritative-query-correlation-1936.md` (`terra-browser` `01M6CAXB2CQG9HQZPN7BCSVDKY`)

Incorporating `terra-browser`'s exact boundary review on the `1936` `UI005` query-correlation draft:
1. **Server HTTP Write (`Owner` `200` + `fsync`) vs Elm `HttpPopup` Acceptance & WebKit Paint**:
   - `Owner.hs` logging + `fsync` after `sendResponse 200` on `Renderer` `GET /events` proves **authenticated server-side socket write ordering**, *not* that `HttpPopup` completed `Popup.Present` (`HttpPopup.elm:51`) and WebKit composited the new frame before `screendump` executed.
   - Therefore, without either (a) a visual transition witness (e.g. an intermediate matching prefix frame followed by the non-matching `UI005` empty-results transition on the same `lease`/`publication` chain) or (b) a post-`Popup.Present` client acknowledgement / painted marker before `screendump`, server-write correlation alone remains a **bounded transport witness** rather than standalone end-to-end visual acceptance.
2. **QMP Command Correlation**:
   - QMP reply readers should assign monotonic `"id"` fields on outbound QMP commands (`input-send-event`, `screendump`) and require matching `"id"` + `"return"` object (with `"error"` absent), ignoring asynchronous QMP `"event"` frames rather than accepting any `"return"` line.
