{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; UNEXECUTED. An independently guarded process must retain this
-- Case, the backend owner, worker and all root/proc descriptors on every exit.
-- The supplied config and display are real; the actor owns the only RootAdmission.
module QHttpResolverOpenControls (Mode(..), Case, newCase, releaseBarrier, runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,newIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
  persistentBackendCounts,qaOpenHooks,qaOpenObservations,qaOpenCurrentSlots)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Platform.Resolver.Internal (QaRootSlot(..))

data Mode = NoStopPositive | StopBeforeOpen | StopAfterOpen deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
  (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current budget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ release _ _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
-- A QA watchdog only; the Case and guardian remain live on timeout.
within :: String -> IO a -> IO a
within label act = timeout 5000000 act >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure

-- No timer is supplied on wire or restarted: the config's actual StartD and
-- owner's existing stop budget govern the actual actor. A guardian bounds QA.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase c@(Case owner start entered release completed workerSlot used) mode path = mask $ \restore -> do
  fresh <- atomicModifyIORef' used (\old -> (True,not old))
  check "single isolated case" fresh
  exists <- doesPathExist path
  check "real owned configuration" (isAbsolute path && exists)
  before <- qaOpenObservations
  check "unvisited open probes" (before==(0,0,Nothing,Nothing))
  configured <- restore (within "config" (loadPersistentBackendConfig owner path))
  check "same-owner configuration" (configured==Right ())
  let barrier = putMVar entered () >> readMVar release
  case mode of
    StopBeforeOpen -> qaOpenHooks barrier (pure ())
    StopAfterOpen -> qaOpenHooks (pure ()) barrier
    NoStopPositive -> qaOpenHooks (pure ()) (pure ())
  thread <- forkIOWithUnmask $ \unmask -> do
    result <- try (unmask (takeMVar start >> runPersistentBackend owner))
    putMVar completed result
  writeIORef workerSlot (Just thread)
  putMVar start ()
  restore $ do
    case mode of
      NoStopPositive -> let waitOpen = do
                              (_,_,first,slotSnapshot) <- qaOpenObservations
                              if first==Just (Right ()) && slotSnapshot==Just (QaSlotOpen,QaSlotUnused)
                                then pure () else do
                                  ended <- tryReadMVar completed
                                  case ended of
                                    Just _ -> ioError (userError "actor ended before successful actual root open")
                                    Nothing -> threadDelay 1000 >> waitOpen
                        in within "actual root-open positive" waitOpen
      _ -> within "open barrier" (readMVar entered)
    (calls,entries,receipt,slots) <- qaOpenObservations
    case mode of
      StopBeforeOpen -> check "before first admitted open" $
        calls==1 && entries==0 && receipt==Nothing && slots==Nothing
      StopAfterOpen -> check "actual open already stored; proc not opened" $
        calls==1 && entries==1 && receipt==Nothing && slots==Just (QaSlotOpen,QaSlotUnused)
      NoStopPositive -> check "actual first open returned under owner" $
        entries==1 && receipt==Just (Right ()) && slots==Just (QaSlotOpen,QaSlotUnused)
    stop <- within "same-owner stop" (requestPersistentBackendStop owner)
    case mode of
      NoStopPositive -> pure ()
      _ -> check "real owner latched stop" (stop==P.StopLatchedBeforeLive)
    releaseBarrier c
    outcome <- within "actor result" (readMVar completed)
    case outcome of
      Left problem -> throwIO problem
      Right actual -> do
        (finalCalls,finalEntries,finalReceipt,finalSnapshot) <- qaOpenObservations
        current <- qaOpenCurrentSlots
        case mode of
          StopBeforeOpen -> check "specific refusal before physical entry; unused slots" $
            finalCalls==1 && finalEntries==0 && finalReceipt==Just (Left (P.StartupAdmissionRefused SessionClosed)) &&
            finalSnapshot==Nothing && current==Just (QaSlotUnused,QaSlotUnused) && persistentBackendCounts actual==(0,0)
          StopAfterOpen -> check "in-flight open uncertain; actual root remains owned; no proc replay" $
            finalCalls==1 && finalEntries==1 && finalReceipt==Just (Left P.StartupAdmissionUnknown) &&
            finalSnapshot==Just (QaSlotOpen,QaSlotUnused) && current==Just (QaSlotOpen,QaSlotUnused) &&
            persistentBackendCounts actual==(0,0)
          NoStopPositive -> check "actual root-open receipt and slot captured" $
            finalEntries==1 && finalReceipt==Just (Right ()) && finalSnapshot==Just (QaSlotOpen,QaSlotUnused)
