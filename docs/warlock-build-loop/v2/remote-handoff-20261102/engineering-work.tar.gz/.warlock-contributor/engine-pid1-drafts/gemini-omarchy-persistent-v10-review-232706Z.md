# Persistent Custody Prerequisites `v10` Consolidation (`232706Z`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Base Canonical `HEAD`**: `bdeac73491a05d6c61932642b184c20b44f0e80e` (also applies cleanly to `e5ce2487c8ec67ced1405dc0d3219c6f39effc5a`; verified `git apply --check` and `patch --dry-run -p1 --fuzz=0`)
- **Execution Status**: **UNEXECUTED SOURCE PROPOSAL** (Root retains all GHC/Cabal/Quint/Elm/VM/GPU/native execution).
- **Preserved Counts & Gates**: `17/242` whole EARS, `41/417` scenarios, `28s`/`30s`/`5s`/`500ms`/original `D`, `HOSTSTOP2`, `nativeOperations = []`.

## Frozen Artifacts (`v10`, Preserving `v6` / `v7` / `v8` / `v9` Immutable)

- `gemini-omarchy-persistent-custody-v9-to-v10-delta-232706Z.patch`: `sha256:7f19e67dad6b1245f42925c2b616d283ac9e237f22d348dafc84230020d5d6a8`
- `gemini-omarchy-persistent-custody-prereqs-v10-232706Z.patch`: `sha256:420bf001311fa1849afbb82066d0582959af4de3a7773d7aec1711ed54958861`
- Preserved `v9` full patch (`232706Z`): `sha256:d9c7d29f78215ea70b444afe399ad3aa9dc85a5461535c919f1ce0b5cb3554e6` (delta `0f3fba9802f6b569d4db3731d99cba116ecaba819a48c9fed9bf3d77652cf02e`)
- Preserved `v8` full patch (`225558Z`): `sha256:76fe15f4f66a26e6669662d6fb630fe4b207c31e6bc3322866618f50e0d1e93c`
- Preserved `v7` full patch (`225558Z`): `sha256:5aba617d4adbce8db604beefff8f9260ee2108a8c2c4b4b7795e5aaf892fd1b0`
- Preserved `v6` full patch (`220528Z`): `sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`

## Three Peer-Reviewed `v9` Source Gaps Closed in `v10`

1. **Masked-Interruptible `takeMVar` + Sticky 3-State `BorrowRelease` (`terra-security` `1b9138c0`, `terra-q-lifetime`, `terra-q-network`, `sol-docs`, `terra-engine`)**:
   - Folded `terra-security-v9-held-release-sticky-v2.patch` (`sha256:1b9138c04e4671640ef3925f0f5d0df2a369e9e29f79e6e6e9291fc7a98ff511`) verbatim into `Warlock.Platform.Executable.Internal` (`postimage sha256:e14ace50e91327659ac6e5615c12bcd338542c303a43a738d6127668635aa8b9`), aligned with `terra-q-lifetime-held-release.qnt`:
     - `borrowHeld` now runs under `mask` with `pure (Right (path,release)) \`onException\` release`, closing the unmasked `fmap` leak.
     - `borrowHeldInterruptible` uses `data BorrowRelease = BorrowPending | BorrowReleased | BorrowUnknown`, masked-interruptible `takeMVar released` and `takeMVar gate \`onException\` putMVar released BorrowPending` (no `restore` around `takeMVar`, closing post-wakeup async `MVar` loss), and short `uninterruptibleMask_` commit returning `True` only on `Live n | n > 0` (`BorrowReleased`) and sticky `False` on non-live/`HeldUnknown` (`BorrowUnknown`), with `release = uninterruptibleMask_ (releaseNow >> pure ())`.
   - In `Warlock.Capture.Process.Persistent.Internal`, all 3 borrow-release sites (`abortPreSpawnNothing`, `abortPreSpawnWithInput`, `finishContainment`) require `borrowReleased (Right (Just True)) = True; _ = False` so `Right (Just False)` (`HeldUnknown`) always quarantines (`["borrow-release"]` or `["startup-borrow-release"]`) and never calls `O.releaseBorrows` or `O.settle`.
   - Added package-private `qaOverrideBorrowRelease` in `Persistent.Internal` (not exported publicly) and Controls **#21a** (live stop sticky `False` receipt with ample budget -> `["borrow-release"]` quarantine) and **#21b** (pre-spawn abort sticky `False` receipt -> `["startup-borrow-release"]` quarantine without spawning).

2. **Pre-`PendingUncertain` Hook Placement & Final Pre-`closeFd` `remainingMicros` Sample (`terra-q-front`)**:
   - In `closeOwnedPidfdDl`, moved `hook "persistent-before-pidfd-close"` into the bounded `claimGap` check *before* `O.pendingMarkFD pending pfd False` (rolling `pidfdCell` back to `InternalPidfdKnownOpen` on abort/expiry; verified by Control **#18e**), and added a final `leftAtClose <- remainingMicros closeDl` sample immediately before `closeFd pfd` inside the masked `timeout` region so an over-budget `persistent-in-pidfd-close` hook cannot enter `closeFd` even if GHC's timer thread has not yet delivered `Timeout`. User-space sampling remains bounded up to OS scheduler preemption between monotonic read and `close(2)` entry.

3. **Outer Retention of Quarantined Test Owners Through `DeadlineStop.main` Exit & Honest Containment Scope (`terra-security`, `sol-docs`, `terra-vm`)**:
   - `PersistentControls` exports `runPersistentControlsRetaining :: FilePath -> IO [PersistentOwner]` (preserving `runPersistentControls = void . runPersistentControlsRetaining`), and `DeadlineStop.main` binds and verifies `length retainedQuarantined == 17` as its final assertion so no quarantined test `PersistentOwner` can be garbage-collected before suite exit.
   - **Explicit Honest Scope Caveat**: Retaining quarantined owners until test-suite process exit prevents early GC and keeps quarantined `ProcessHandle`s un-reaped (`awaitFixtureExited` uses `waitid(WNOWAIT)` to observe zombie self-exit), but OS test-process exit is *not* an owned reap, GHC event-manager deregistration, or pipe/pidfd closure receipt. Coordinate with `terra-vm-fixture-registry-0001.hs` (`WarlockFixtureRegistry`) before claiming cross-fixture reap/cleanup receipts.

## Explicit Open Follow-Ons & Peer Artifact Compatibility

1. **Startup `borrowHeld` Gate Contention (`terra-graph-persistent-borrow-acquire-2357.md`)**:
   - `v10` makes *release* (`releaseNow`) interruptible under `StartBudget`/`StopDeadline`, while initial borrow *acquisition* still uses `transition gate` (`uninterruptibleMask_`). `terra-graph-persistent-borrow-acquire-2357.md` proposes `borrowHeldWhile`, which currently carries an explicit `engine/security` peer-review HOLD on `abortBeforeBorrow` phase ordering (`PhaseRetired` before confirmed `O.abortBegin`) and is therefore intentionally not folded prematurely into `v10`.
2. **Release Contention Strict `completedNs <= D` Oracle (`terra-engine-held-gate-contention-controls.hs`)**:
   - `v10` prevents unbounded `uninterruptibleMask_` blocking and late `O.settle` under contended borrow release (quarantining `["borrow-release"]`); returning strictly `<= D` in wall/monotonic nanoseconds after `System.Timeout.timeout` wakeup remains an open Root reserve/scheduler question, so `HeldGateContentionControls.hs` remains an intentional strict-timeliness oracle.
3. **`HeldExecutable` QA Seam (`terra-engine-borrow-cancel-unknown-seam.patch` + `BorrowCancelUnknownControls.hs`)**:
   - `v10` keeps `Executable/Internal.hs` at exact postimage `e14ace50e91327659ac6e5615c12bcd338542c303a43a738d6127668635aa8b9`. Note for Root/`terra-engine`: Hunk #1 of `seam.patch` (`54914688`) has zero trailing context lines (`@@ -1,5 +1,10 @@`), which `git apply` / `patch --fuzz=0` treat as an EOF match (though default `patch -p1` applies it with fuzz 1, offset +1 on Hunk #2); adding 3 trailing context lines (`@@ -1,8 +1,13 @@`) makes `git apply --check` / `patch --fuzz=0` pass cleanly.
4. **Downstream Unimplemented Production Callsites**:
   - `implementation/warlock/haskell/ui-engine/src/Warlock/UiEngine/Channel.hs` (`TrustedPump` / `SocketOwner` `LiveSession` integration) and `ui-engine` persistent app-session launch supervision remain separate, unintegrated downstream slices gated on Root's protected `cabal test` qualification of `held-document` + `process-custody`.
