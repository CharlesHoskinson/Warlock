{-# LANGUAGE OverloadedStrings #-}
-- PREPARATION DRAFT ONLY: not built, tested or native acceptance.  Integrate
-- into test-ui-origin's actual selected child under a real Backend/private-net
-- witness. Use a FRESH selected process and original deadline per case: owner
-- adopts fd0 and is not reusable. Do not replace the HTTP probes with stubs.
module OwnerPreparedCases (Case(..), runPreparedCase, runAsyncCase) where

import Control.Exception (AsyncException(ThreadKilled), finally, throwIO, try)
import Data.IORef
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.Owner as Owner
import Warlock.Ui.Config (UiConfig)
import Warlock.Ui.Policy (Origin)
import Warlock.Ui.PrivateNetwork (PeerNetwork)

data Case = PrepareThrows | RunThrows | RetireThrows | TopologyRepeat deriving (Eq, Show)

-- Inputs must be the actual production-fixture witness/config and existing
-- socket-based HTTP checks from test-ui-origin/Main.hs, not mock predicates.
-- liveDocument must issue real GET /index.html to the supplied role origin,
-- require HTTP 200 and exact prepared document bytes; listenerClosed must
-- attempt a fresh connection in the same private namespace and report refusal.
-- The caller records the returned named assertions and marks any False as test
-- failure, while Backend retains selected-image/peer/IPC provenance. Check root's
-- original D outside this helper, retain full raw errors and never extend D.
runPreparedCase :: Case -> PeerNetwork -> UiConfig
                -> (Origin -> IO Bool) -> (Origin -> IO Bool)
                -> IO [(String, Bool)]
runPreparedCase which witness config liveDocument listenerClosed = do
  prepares <- newIORef (0 :: Int)
  runs <- newIORef (0 :: Int)
  retires <- newIORef (0 :: Int)
  partialReleases <- newIORef (0 :: Int)
  origins <- newIORef ([] :: [Origin])
  httpObserved <- newIORef False
  topologyRefused <- newIORef False
  let prepare endpoints ownerEvent = do
        modifyIORef' prepares (+1)
        let controller = Owner.controllerOrigin endpoints
            bar = Owner.barOrigin endpoints
            popup = Owner.popupOrigin endpoints
        writeIORef origins [controller,bar,popup]
        case which of
          -- Model an acquired partial preparation whose own contract must
          -- unwind before it throws: Owner never receives a retire action.
          PrepareThrows ->
            (ioError (userError "controlled prepare failure"))
              `finally` modifyIORef' partialReleases (+1)
          _ -> do
            let runEngine = do
                  modifyIORef' runs (+1)
                  -- Workers have been launched before this runs. This goes
                  -- through real listener/admission/document serving, not a
                  -- mirrored state assertion or an invented native ACK.
                  delivered <- liveDocument controller
                  writeIORef httpObserved delivered
                  case which of
                    RunThrows -> ioError (userError "controlled engine failure")
                    TopologyRepeat -> do
                      let topology = J.JObject [("viewProtocol",J.JNumber "1"),
                            ("kind",J.JString "view-topology"),("revision",J.JString "1"),
                            ("views",J.JArray [])]
                      first <- ownerEvent (Owner.OwnerTopology topology)
                      second <- ownerEvent (Owner.OwnerTopology topology)
                      writeIORef topologyRefused (first == Right () && second == Left "stale UI topology")
                      pure (Owner.EngineResult True True)
                    _ -> pure (Owner.EngineResult True True)
                retireEngine = do
                  modifyIORef' retires (+1)
                  case which of
                    RetireThrows -> ioError (userError "controlled retirement failure")
                    _ -> pure ()
            pure (runEngine,retireEngine)
  result <- Owner.runUiOwnerPrepared witness config prepare
  ps <- readIORef prepares
  rs <- readIORef runs
  ts <- readIORef retires
  releases <- readIORef partialReleases
  delivered <- readIORef httpObserved
  topologyBad <- readIORef topologyRefused
  bound <- readIORef origins
  closed <- mapM listenerClosed bound
  let exactlyThreeDistinct = case bound of
        [a,b,c] -> a /= b && b /= c && a /= c
        _ -> False
      count = case which of
        PrepareThrows -> ps == 1 && rs == 0 && ts == 0 && releases == 1
        _ -> ps == 1 && rs == 1 && ts == 1 && releases == 0
      http = case which of PrepareThrows -> not delivered; _ -> delivered
      -- A prepare function that throws is responsible for unwinding its own
      -- partial allocations. No returned engine/retirement receipt exists, so
      -- the Owner must conservatively withhold cleanup certification even if
      -- this fixture observes its local partial-release action.
      -- After returned engine acquisition, a throwing retire action cannot
      -- certify engine cleanup even if EngineResult earlier reported True.
      cleanupHonest = case which of
        PrepareThrows -> not (Owner.uiEngineCleanup result) && not (Owner.uiCleanup result)
        RunThrows -> not (Owner.uiEngineCleanup result) && not (Owner.uiCleanup result)
        RetireThrows -> not (Owner.uiEngineCleanup result) && not (Owner.uiCleanup result)
        _ -> True
      retireCaseObserved = case which of
        RetireThrows -> Owner.uiFailure result /= Nothing
        TopologyRepeat -> topologyBad && Owner.uiFailure result /= Nothing
        _ -> True
  pure [("selected route prepared three distinct role origins", exactlyThreeDistinct),
        ("selected route executes expected acquire/run/retire counts", count),
        ("live production HTTP document observed only after preparation", http),
        ("all owned listeners refuse after cleanup", length closed == 3 && and closed),
        ("controlled failure never produces owner success", not (Owner.uiPassed result)),
        ("engine and overall cleanup not certified after preparation/run/retire exception", cleanupHonest),
        ("retire exception is retained as owner failure", retireCaseObserved)]

-- Separate fresh selected-child control. The engine raises the actual
-- asynchronous exception constructor while runEngine is restored/unmasked;
-- this is a controlled in-process propagation case, not an external kill or a
-- physical engine teardown receipt. The outer fixture catches only ThreadKilled
-- after Owner's cleanup and observes all listener closures.
runAsyncCase :: PeerNetwork -> UiConfig -> (Origin -> IO Bool) -> (Origin -> IO Bool)
             -> IO [(String, Bool)]
runAsyncCase witness config liveDocument listenerClosed = do
  retires <- newIORef (0 :: Int)
  origins <- newIORef ([] :: [Origin])
  delivered <- newIORef False
  let prepare endpoints _ = do
        let controller = Owner.controllerOrigin endpoints
        writeIORef origins [controller, Owner.barOrigin endpoints, Owner.popupOrigin endpoints]
        pure ((do
          result <- liveDocument controller
          writeIORef delivered result
          throwIO ThreadKilled),
          modifyIORef' retires (+1))
  outcome <- try (Owner.runUiOwnerPrepared witness config prepare)
    :: IO (Either AsyncException Owner.UiResult)
  retired <- readIORef retires
  didDeliver <- readIORef delivered
  bound <- readIORef origins
  closed <- mapM listenerClosed bound
  pure [("async cancellation propagates", case outcome of Left ThreadKilled -> True; _ -> False),
        ("cancellation occurs after real HTTP document", didDeliver),
        ("prepared retire action runs exactly once on cancellation", retired == 1),
        ("cancellation closes all three owned listeners", length closed == 3 && and closed)]

-- Preserve existing exerciseOwner production HTTP sequence as separate cases:
-- stale dismiss/reflow/escape are nonfatal and a fresh escape succeeds. The
-- fresh-child TopologyRepeat case above instead checks owner-fatal topology.
-- Do not convert an HTTP 204 into a backend or native ACK.
-- External child death, externally delivered cancellation, provider/OS
-- retirement and original D need separate root-owned checks; this controlled
-- in-process cancellation does not prove them.
