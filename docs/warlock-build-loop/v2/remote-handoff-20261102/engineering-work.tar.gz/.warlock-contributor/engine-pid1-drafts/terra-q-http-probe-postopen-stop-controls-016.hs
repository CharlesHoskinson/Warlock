{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Expected RED on Resolver016: after a real probe-open
-- step returns, candidate016 starts walk stat outside any same-owner step.
-- Host roots Case, actual owner/worker/Root/all fds and an independent
-- guardian BEFORE either exported action. Never guess, retry or close a
-- retained/unknown descriptor as test cleanup.
module QHttpProbePostOpenStop016 (Mode(..),Case,newCase,runResolution,finishCase,releaseBarrier) where
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try)
import Control.Monad (unless,void)
import qualified Data.ByteString as B
import Data.IORef
import System.Posix.Types (Fd)
import System.Timeout (timeout)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..),requestSessionStop,tryPersistentStopDeadline)
import Warlock.Platform.Resolver.Internal
 (Root,Pin,Link,Resolution,ResolveError,Hooks,RootAdmission,RootAdmissionFailure(..),
  LeaseCustody,newLeaseCustody,ProbeCustody,newProbeCustody,QaProbeSlot(..),qaProbeSlots,qaProbeEventHook,
  resolveSnapshotViaRetained)

data Mode = Positive | StopAfterOpen deriving (Eq,Show)
type Result = Either SomeException (Either RootAdmissionFailure (Either ResolveError (Resolution,())))
data Case = Case PersistentOwner StopBudget LeaseCustody ProbeCustody (IORef [String]) (IORef Bool)
 (MVar ()) (MVar ()) (MVar Result) (IORef Bool)
newCase :: PersistentOwner -> StopBudget -> IO Case
newCase owner budget = Case owner budget <$> newLeaseCustody <*> newProbeCustody <*> newIORef [] <*> newIORef False
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ _ _ release _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("probe-postopen: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure

-- Invoked ON the actual Engine scope thread, by a production-path driver. The
-- passed admit MUST be that same-owner rank-2 step adapter; a fake Right
-- adapter or synthetic root cannot qualify this fixture. Fixture arguments
-- name a real known-good rooted executable with at least one path component.
runResolution :: Case -> RootAdmission -> Root -> [Pin] -> B.ByteString -> [Link]
 -> Integer -> Integer -> B.ByteString -> Hooks -> IO ()
runResolution (Case _ _ leaseOwner probeOwner events hookUsed opened release done used)
 admit root pins path links size limit digest hooks = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 let event name = do
      atomicModifyIORef' events (\xs -> (name:xs,()))
      if name=="after-probe-open" then do
       first <- atomicModifyIORef' hookUsed (\old -> (True,not old))
       if first then putMVar opened () >> readMVar release else pure ()
      else pure ()
     consume :: Fd -> B.ByteString -> IO ()
     consume _ _ = pure ()
 qaProbeEventHook event
 result <- try (restore (resolveSnapshotViaRetained admit leaseOwner probeOwner root pins path links size limit digest hooks consume))
 putMVar done result

-- Called by the separately retained supervisor while the real owner thread is
-- parked. The observation watchdog is NOT a new product D or cleanup timer.
finishCase :: Case -> Mode -> IO ()
finishCase c@(Case owner budget _ probeOwner events _ opened _ done _) mode = do
 within "actual admitted probe open" (readMVar opened)
 before <- reverse <$> readIORef events
 slots <- qaProbeSlots probeOwner
 check "real first probe slot open before metadata" (before==["after-probe-open"] && slots==[QaProbeOpen])
 firstD <- case mode of
  Positive -> pure Nothing
  StopAfterOpen -> do
   receipt <- within "same-owner actual stop" (requestSessionStop owner budget)
   selected <- tryPersistentStopDeadline owner
   check "first stop actually latched" $
    receipt==StopLatchedBeforeLive && case selected of StopDeadlineLatched _ -> True; _ -> False
   pure (Just selected)
 releaseBarrier c
 result <- within "actual resolver completion" (readMVar done)
 observed <- reverse <$> readIORef events
 case mode of
  Positive -> check "actual valid root/probe walk reaches metadata and full callback" $
   "before-walk-stat" `elem` observed && case result of Right (Right (Right (_,()))) -> True; _ -> False
  StopAfterOpen -> do
   laterD <- tryPersistentStopDeadline owner
   -- This literal security boundary is deliberately RED on candidate016:
   -- its body starts getFdStatus after the stopped open step returned.
   check "stop prevents a new post-open walk stat" $
    not ("before-walk-stat" `elem` observed) && Just laterD==firstD &&
    case result of Right (Left RootAdmissionUnknown) -> True; _ -> False
