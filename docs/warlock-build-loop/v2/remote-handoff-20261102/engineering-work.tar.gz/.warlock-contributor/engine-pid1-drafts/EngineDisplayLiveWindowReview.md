# Live Window Screenshot & 7.45s Idle-Timeout Diagnostic Review (`engine-display-20261101T163508Z`)

- **Diagnostic Evidence Directory**: `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-display-20261101T163508Z`
- **Qualified Freeze & Component Report**: `.warlock-contributor/evidence/engine-display-qualified-freeze-20261101.json` bound to `.warlock-contributor/haskell-cpu-1793550462035880723/report.json` (`sha256:d2a6b3a8bb8eec181a3e9bc5e4bdc1b820092245101d870b7c492d2ae8c4e6f2`, all 10 suites + 248 named Quint model cases PASS)
- **Guest Binaries**:
  - `warlock-ui-owner`: `sha256:7ed083bd270776183ee9569e7715438d89f93296a117f382457e0fbf4260943c` (`700,496` B, `dev=58`, `ino=36472`)
  - `warlock-ui-backend`: `sha256:0c42a97eca6f55dcbe607f0b371150d5e7073d62db1bff5ba68ec40f11c71b45` (`24,080` B, `dev=58`, `ino=36473`)
- **Live Screenshots Inspected**:
  - `live-00.png`: `sha256:d6592a8262eca09cf225d3dd48144eb243746b529dedfdc0fa1f6260752365aa` (`296,984` B, `at: 61518.743340394`)
  - `live-01.png`: `sha256:0a9e25a720deb71751c9958bcbe810cbf760bc1ea6dcc6459c0e9c57fd3483ef` (`324,023` B, `at: 61521.948914425`)
- **Scope Boundary**: App-only native-on-VM diagnostic (`providerCleanupQualified: false`, `nativeOperations: []`, `nativeAccepted: false`, `releaseAccepted: false`). Zero extra acceptance gates created; `HOSTSTOP2`, `15 / 242` whole requirements, and `39 / 417` scenarios remain unchanged.

---

## 1. Visual & Architectural Review of `live-00.png` and `live-01.png`

1. **Desktop & Foreign-Process Preservation**:
   - Left half of workspace `1` (`at: [12, 38]`, `size: [1256, 750]` before split) preserves the existing `foot` terminal (`PID 2095`, `stableId: 18000005`) intact across both captures and in `preservation-after.json`; `idle-restoration.json` and `host-idle-restoration.json` both exited `0`.
2. **Owned Held-ELF PID-1 Window Lineage (`observations.json`)**:
   - Right half of workspace `1` (`at: [647, 38]`, `size: [621, 750]`) maps `class: "GTK Application"` owned by outer PID `100517` (`warlock-ui-owner`, `dev=58`, `ino=36472`, `NSpid: [100517, 1]`), spawned by broker `100516` under `warlock-ui-backend` `100509`.
   - All three isolated WebKit Bubblewrap (`bwrap`) + `xdg-dbus-proxy` + `WebKitWebProcess` trees (`100568`, `100580`, `100588`, `NSpid` depth 3) plus `WebKitNetworkProcess` (`100529`, `NSpid: [100529, 9]`) are live inside the child PID namespace.
3. **Progression from `live-00.png` to `live-01.png` (Elm-Only GUI Policy Verification)**:
   - **`live-00.png` (`+0.90s`)**: Undecorated GTK4 container (`Mvp.hsc:806` `gtkWindowSetDecorated window 0`) has mapped cleanly in Hyprland's right split with zero GTK headerbar, title label, or stock widgets while the three role `WebKitWebView`s compile content filters and load `HttpBar.html`, `HttpPopup.html`, and `HttpMain.html`.
   - **`live-01.png` (`+4.10s`)**: All three Elm documents have loaded over their distinct private-namespace `127.0.0.1` origins and completed end-to-end `OwnerTopology` -> `DesktopCommit` -> `Backend` -> `presentation` projection:
     - **Top `Bar` strip (`HttpBar.html`, `72px`)**: Renders dark Lacquer chrome with **`Applications`** enabled/highlighted (warm coral-red border, crisp light `#F6EFE8` label), **`Task View`** and **`Switch windows`** honestly disabled (dashed border, muted text, matching `nativeOperations: []`), and right-side status notice **`"Applications connected. Window controls unavailable."`** with coral-red leading accent bar.
     - **Primary `Popup` workspace (`HttpPopup.html`)**: Renders dark Lacquer canvas (`#100E0E` / `#141112`), section heading **`"Choose a window"`** with coral-red leading bar, and matching honest status card **`"Applications connected. Window controls unavailable."`** (standby state prior to opening the `Applications` launcher).
     - **Hidden `Controller` cell (`HttpMain.html`)**: `1x1` `opacity: 0.0` untargetable view (`Mvp.hsc:852-859`) introduces zero visible seam or focus artifact.

---

## 2. Exact Source Root Cause of the `7.445s` Exit (`CredentialTransport TimedOut`)

The `elapsed: 7.445s` (`exit: 1`, `forcedAtOriginalDeadline: false`) termination in `trial-result.json` was **not** a GTK, WebKit, display, or engine-broker failure:

- **`backend.stdout` exact receipt**:
  ```json
  {"schema":1,"passed":false,"cleanup":true,"callbacks":3,"operations":1,"auth":"Just (FrameObserved (CredentialFrameRejected (CredentialTransport TimedOut)))","credentialRows":9,"selectedPid":100516,"nativeAccepted":false,"releaseAccepted":false}
  ```
- **Why `TimedOut` fired at `~7.45s`**:
  1. During the first `~2.4s`, Elm `Controller` delivered **3** authenticated `DesktopCommit` frames (`callbacks: 3`, `credentialRows: 9`) and `warlock-ui-backend` (`Backend.hs:196,199`) answered with `ApplicationAttached` + `CatalogReply` (`operations: 1`), producing the connected UI shown in `live-01.png`.
  2. With `physicalInputs: []` and steady window geometry (`621x750`), `Mvp.hsc` emitted no further topology/reflow/escape events and Elm `Controller` sent no further commits.
  3. `warlock-ui-backend`'s frame loop (`Warlock/Bootstrap/Aggregate.hs:82-92`) blocks in `receiveCredentialIngress`, which calls `Warlock/Transport/Channel.hs:127-137` (`receiveCredentialFrame`):
     ```haskell
     start <- getMonotonicTimeNSec
     let deadline = toInteger start + 5000000000
     result <- try (timeout 5000000 (frame deadline))
     ...
     Right Nothing -> failFrame (CredentialTransport TimedOut)
     ```
  4. Because `Channel.hs:128-129` enforces a **fixed 5.0-second per-frame idle read timeout** (`5,000,000` us) rather than waiting up to the session's `AdmissionDeadline` (or treating idle silence differently from mid-frame stall), **5.0 seconds after the 3rd Elm commit (`~2.45s + 5.00s = 7.445s`)** `failFrame` closed the backend socket with `CredentialTransport TimedOut`, `Aggregate.hs:90-91,97` returned `False` -> `refuseAfterExit session`, and `cleanup: true` retired all 22 processes cleanly.
