-- QA-ONLY same-module declaration fragment, appended to the isolated Backend
-- candidate 011+012 and exported only in that isolated test build. Never ship.
-- This is read-only and cannot obtain/replace config, StoreOwner or custody.
qaPersistentConfigState :: PersistentBackendOwner -> IO (Bool,Bool,Bool)
qaPersistentConfigState (PersistentBackendOwner _ _ _ _ _ _ _ _ _ _ used store installed) = do
  seen <- readIORef used
  owner <- readIORef store
  value <- readIORef installed
  let present x = case x of Nothing -> False; Just _ -> True
  pure (seen,present owner,present value)
