#!/usr/bin/env python3
"""Root-only isolated source-extracted mocks. No guest, VM, proc or QMP calls.

Set REVIEWED_GUEST_CONTROLLER and REVIEWED_GUEST_SHA256 to the exact reviewed
integrated controller. Exercises actual sample/members/principal functions with
synthetic dependencies. It does not establish live process or cleanup facts.
"""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import re
from types import SimpleNamespace
import unittest


def load_functions(names, namespace):
    path = Path(os.environ['REVIEWED_GUEST_CONTROLLER'])
    raw = path.read_bytes()
    expected = os.environ['REVIEWED_GUEST_SHA256']
    if len(expected) != 64 or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('controller hash mismatch')
    tree = ast.parse(raw, filename=str(path))
    found = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            if node.name in found: raise ValueError('duplicate function')
            found[node.name] = node
    if set(found) != set(names): raise ValueError('missing function')
    for node in found.values():
        module = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
        exec(compile(module, str(path), 'exec'), namespace)
    return namespace


class FakePath:
    data = {}
    def __init__(self, path): self.path = str(path)
    def __truediv__(self, part): return FakePath(self.path.rstrip('/')+'/'+str(part))
    def __str__(self): return self.path
    @property
    def name(self): return self.path.rsplit('/',1)[-1]
    def read_text(self):
        item=self.data[self.path]
        if isinstance(item,Exception): raise item
        return item
    def is_dir(self): return True
    def lstat(self):
        item=self.data[self.path]
        if isinstance(item,Exception): raise item
        return item


def fixture(group_stamps=None):
    stamps=iter(group_stamps) if group_stamps is not None else None
    unit='warlock-live-usability-0123456789abcdef.scope'
    group='/qa-harness.slice/'+unit
    img={'warlock-ui-owner':{'device':1,'inode':2,'size':3,'sha256':'a'},
         'warlock-ui-backend':{'device':1,'inode':4,'size':5,'sha256':'b'}}
    common={'uid':1000,'core':['1','1'],'cgroup':'0::'+group}
    procmap={
      11:{**common,'pid':11,'birth':'11','ppid':12,'device':1,'inode':2,'size':3,'namespacePids':[11,1]},
      12:{**common,'pid':12,'birth':'12','ppid':13,'device':1,'inode':2,'size':3,'namespacePids':[12]},
      13:{**common,'pid':13,'birth':'13','ppid':99,'device':1,'inode':4,'size':5,'namespacePids':[13]}}
    state={'guestRoot':'/qa','deadlineMonotonicNs':'28000000010','generatedMonotonicNs':'10',
           'unit':unit,'launcherPID':13,'images':img,'attempt':'attempt'}
    FakePath.data={'/qa/run-01/controller-state.json':json.dumps(state),
                   '/qa/run-01/backend.json':json.dumps({'deadlineMonotonicNs':'28000000010'})}
    responses={('omarchy-shell','lock','isLocked'):'false',
      ('hyprctl','clients','-j'):json.dumps([{'pid':11,'mapped':True,'address':'owned','at':[647,38],'size':[621,750]}]),
      ('hyprctl','activewindow','-j'):json.dumps({'pid':11,'address':'owned'}),
      ('hyprctl','monitors','-j'):json.dumps([{'width':1280,'height':800,'scale':1,'transform':0,'x':0,'y':0,'dpmsStatus':True,'name':'monitor'}]),
      ('hyprctl','layers','-j'):'{}',('hyprctl','cursorpos','-j'):'{"x":700,"y":100}'}
    def command(args): return SimpleNamespace(stdout=responses[tuple(args)])
    namespace={'json':json,'math':__import__('math'),'Path':FakePath,'os':SimpleNamespace(getuid=lambda:1000),
      'time':SimpleNamespace(monotonic_ns=lambda:10),'command':command,
      'members':lambda _unit:([11,12,13],{'known':True,'properties':{'ActiveState':'active','MemoryMax':'2147483648','ControlGroup':group}}),
      'file_pin':lambda path,_expected:img[path.name], 'proc':lambda pid:procmap[pid], 'foot':lambda:{'pid':2095,'birth':'6930'},
      'proc_context':lambda:{'proc':[1,2],'pidNamespace':[3,4],'cgroupRoot':[5,6],'mount':['1','rw','rw']},
      'group_stamp':lambda _group:next(stamps) if stamps is not None else [5,7]}
    return load_functions(['sample'],namespace)['sample'],state,responses


class GuardTests(unittest.TestCase):
    def test_positive_owned_sample(self):
        sample,_,_=fixture(); result=sample(FakePath('/qa'))
        self.assertEqual(result['identity']['engine']['pid'],11)
        self.assertEqual(result['identity']['backend']['birth'],'13')

    def test_lock_failure_is_named_without_raw_data(self):
        sample,_,responses=fixture();responses[('omarchy-shell','lock','isLocked')]='true'
        with self.assertRaisesRegex(AssertionError,'^sample-L70$'):sample(FakePath('/qa'))

    def test_active_window_failure_is_named(self):
        sample,_,responses=fixture();responses[('hyprctl','activewindow','-j')]='{"pid":42,"address":"foreign"}'
        with self.assertRaisesRegex(AssertionError,'^sample-L90$'):sample(FakePath('/qa'))

    def test_pinned_birth_change_does_not_pass(self):
        sample,_,_=fixture();pinned=copy.deepcopy(sample(FakePath('/qa'))['identity']);pinned['engine']['birth']='changed'
        with self.assertRaisesRegex(AssertionError,'^sample-L102$'):sample(FakePath('/qa'),pinned)

    def test_cgroup_directory_identity_change_during_sample_refuses(self):
        sample,_,_=fixture([[5,7],[5,8]])
        with self.assertRaisesRegex(ValueError,'observation context changed'):
            sample(FakePath('/qa'))

    def test_group_stamp_requires_directory_and_reports_inode(self):
        group='/qa'
        FakePath.data={'/sys/fs/cgroup/qa':SimpleNamespace(st_mode=0o40755,st_dev=5,st_ino=7)}
        stamp=load_functions(['group_stamp'],{'Path':FakePath,'stat':__import__('stat')})['group_stamp']
        self.assertEqual(stamp(group),[5,7])
        FakePath.data['/sys/fs/cgroup/qa']=SimpleNamespace(st_mode=0o40755,st_dev=5,st_ino=8)
        self.assertEqual(stamp(group),[5,8])
        FakePath.data['/sys/fs/cgroup/qa']=SimpleNamespace(st_mode=0o100644,st_dev=5,st_ino=8)
        with self.assertRaises(ValueError):stamp(group)
        FakePath.data['/sys/fs/cgroup/qa']=PermissionError('private')
        with self.assertRaises(PermissionError):stamp(group)

    def test_principal_missing_denied_mismatch_and_context(self):
        context={'proc':[1,2],'pidNamespace':[3,4],'cgroupRoot':[5,6],'mount':['1','rw','rw']}
        namespace={'Path':FakePath,'proc_context':lambda:context}
        observe=load_functions(['parse_birth','principal_observation'],namespace)['principal_observation']
        record=lambda birth:'11 (worker) '+ ' '.join(['S']+['0']*18+[birth])
        FakePath.data={'/proc/11/stat':record('9')}
        self.assertEqual(observe(11,'9',context),('present',{'pid':11,'birth':'9'}))
        FakePath.data['/proc/11/stat']=record('10')
        self.assertEqual(observe(11,'9',context),('different-birth',None))
        FakePath.data['/proc/11/stat']=FileNotFoundError('secret')
        self.assertEqual(observe(11,'9',context),('absent',None))
        states=iter([context,{'changed':True}]);namespace['proc_context']=lambda:next(states)
        self.assertEqual(observe(11,'9',context),('unknown','ValueError'))
        namespace['proc_context']=lambda:context
        FakePath.data['/proc/11/stat']=PermissionError('secret')
        self.assertEqual(observe(11,'9',context),('unknown','PermissionError'))
        FakePath.data['/proc/11/stat']='malformed'
        self.assertEqual(observe(11,'9',context),('unknown','ValueError'))
        self.assertEqual(observe(11,'9',{'different':True}),('unknown','ValueError'))
        def unavailable(): raise FileNotFoundError('private')
        namespace['proc_context']=unavailable
        self.assertEqual(observe(11,'9',context),('unknown','FileNotFoundError'))

    def test_cleanup_success_and_uncertainty_are_distinct(self):
        cleanup=load_functions(['cleanup_passes'],{})['cleanup_passes']
        good={'launcherReaped':True,'scopeInventoryConfirmedEmpty':True,
              'footPreserved':True,'idleRestore':{'exactEnabledRestored':True},
              'originalOwnedBirthsRemain':[],'originalOwnedBirthsUnknown':[]}
        self.assertIs(cleanup(None,good),True)
        for key in ('launcherReaped','scopeInventoryConfirmedEmpty','footPreserved'):
            bad=copy.deepcopy(good);bad[key]=False
            with self.subTest(key=key):self.assertIs(cleanup(None,bad),False)
        for key in ('originalOwnedBirthsRemain','originalOwnedBirthsUnknown'):
            bad=copy.deepcopy(good);bad[key]=[{'role':'engine'}]
            with self.subTest(key=key):self.assertIs(cleanup(None,bad),False)
        self.assertIs(cleanup('forced or failed',good),False)
        bad=copy.deepcopy(good);bad['idleRestore']['exactEnabledRestored']=False
        self.assertIs(cleanup(None,bad),False)

    def test_cgroup_incomplete_inventory_is_not_empty(self):
        FakePath.data={'/sys/fs/cgroup/qa/cgroup.procs':'11\n'}
        props='ControlGroup=/qa\nActiveState=active\nMemoryMax=2147483648\n'
        fakeos=SimpleNamespace(walk=lambda root,onerror:iter([('/sys/fs/cgroup/qa',[],['cgroup.procs'])]))
        namespace={'Path':FakePath,'os':fakeos,'re':re,'command':lambda *_a,**_k:SimpleNamespace(returncode=0,stdout=props)}
        members=load_functions(['members'],namespace)['members'];unit='warlock-live-usability-0123456789abcdef.scope'
        self.assertEqual(members(unit)[0],[11])
        fakeos.walk=lambda root,onerror:iter([('/sys/fs/cgroup/qa',[],[])])
        with self.assertRaises(OSError):members(unit)


if __name__=='__main__':unittest.main()
