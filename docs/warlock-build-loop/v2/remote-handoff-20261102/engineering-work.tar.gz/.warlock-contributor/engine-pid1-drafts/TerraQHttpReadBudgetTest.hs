{-# LANGUAGE OverloadedStrings #-}
-- PREPARATION ONLY: root integrates/reviews and runs under an independently
-- owned process watchdog. This uses real socketpair/SCM receive/framing and
-- real Broker/Protocol, but a permissive fixture CredentialGuard: it tests
-- deadline/dispatch, NOT peer authentication, namespace custody or acceptance.
module Main (main) where

import Control.Exception (bracket)
import Control.Monad (unless, when)
import qualified Data.ByteString as B
import Data.IORef (IORef, modifyIORef', newIORef, readIORef)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import Warlock.Capture.Process.Bootstrap
  (AdmissionDeadline, deadlineAfter, deadlineAbsoluteNs, remainingMicros)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import qualified Warlock.Protocol.EngineTransport as Transport
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.EngineBroker as Broker
import qualified Warlock.Ui.EngineProtocol as Protocol
import Warlock.Ui.Owner (UiEndpoints(..))

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
check :: String -> Bool -> IO ()
check label value = unless value (ioError (userError label))

-- Fixture-only guard: real credentials still traverse recvmsg, but the fixture
-- does not prove their process identity and must never be used in production.
fixtureGuard :: IORef Int -> CredentialGuard ()
fixtureGuard fragments = CredentialGuard
  (\_ -> modifyIORef' fragments (+1) >> pure (Right ()))
  (\_ action -> Right <$> action)

data Fixture = Fixture S.Socket (Broker.Broker ()) AdmissionDeadline Protocol.Startup (IORef Int) (IORef Int)

openFixture :: IO Fixture
openFixture = do
  deadline <- deadlineAfter 2000000 >>= must
  sid <- must (Protocol.sessionId "1")
  startup <- must (Protocol.startup 12001 12002 12003 (T.pack (deadlineAbsoluteNs deadline)) sid)
  let (controller,bar,popup) = Protocol.startupOrigins startup
  calls <- newIORef 0
  fragments <- newIORef 0
  let endpoints = UiEndpoints controller bar popup
        (modifyIORef' calls (+1) >> pure False) (pure 1000000) (pure Nothing)
      owner _ = ioError (userError "unexpected owner event")
  (peer,endpoint) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  prepared <- Broker.prepareBroker endpoint deadline startup endpoints owner
  broker <- Broker.attachBroker prepared (fixtureGuard fragments)
  pure (Fixture peer broker deadline startup calls fragments)

closeFixture :: Fixture -> IO ()
closeFixture (Fixture peer broker _ _ _ _) = do
  _ <- Broker.closeBroker broker
  S.close peer

ready :: AdmissionDeadline -> B.ByteString
ready deadline = TE.encodeUtf8 $ J.renderJson $ J.JObject
  [("engineReady",J.JNumber "1"),
   ("deadline",J.JString (T.pack (deadlineAbsoluteNs deadline))),
   ("incarnation",J.JString "1")]

readExactly :: S.Socket -> Int -> IO B.ByteString
readExactly socket = go []
  where
    go pieces 0 = pure (B.concat (reverse pieces))
    go pieces n = do
      bytes <- N.recv socket n
      when (B.null bytes) (ioError (userError "unexpected EOF"))
      go (bytes:pieces) (n - B.length bytes)

readOuter :: S.Socket -> (B.ByteString -> Either e Int) -> IO B.ByteString
readOuter socket lengthOf = do
  header <- readExactly socket 4
  size <- either (const (ioError (userError "invalid length"))) pure (lengthOf header)
  readExactly socket size

start :: Fixture -> IO ()
start (Fixture peer broker deadline _ _ _) = do
  frame <- must (Transport.startupPrefix (ready deadline))
  N.sendAll peer frame
  result <- Broker.completeStartup broker
  check "ready startup local write" (result == Broker.StartupWrittenLocally)
  _ <- readOuter peer Transport.startupHeaderLength
  pure ()

validRequest :: Protocol.Startup -> IO (Protocol.Session,B.ByteString)
validRequest startup = do
  let (pending,encoded) = Protocol.beginRequest (Protocol.newSession startup) Protocol.GetStop
  raw <- must encoded
  frame <- must (Transport.enginePrefix raw)
  pure (pending,frame)

-- Positive control demonstrates the real startup and reply path can work;
-- the negative tests below are not satisfied by a permanently inert broker.
positiveValidStop :: IO ()
positiveValidStop = bracket openFixture closeFixture $ \f@(Fixture peer broker _ startup calls _) -> do
  start f
  (pending,frame) <- validRequest startup
  N.sendAll peer frame
  result <- Broker.serveBrokerOnce broker
  check "reply locally written" (result == Broker.ReplyWrittenLocally)
  reply <- readOuter peer Transport.engineHeaderLength
  let (_,answer) = Protocol.acceptReply pending reply
  check "real protocol stop reply" (answer == Right (Protocol.StopReply False))
  count <- readIORef calls
  check "exactly one stop callback" (count == 1)

-- Current behavior witness: partial prefix consumes the SAME D, no callback,
-- then channel retirement. It is NOT a claim that a 500ms reserve exists.
partialStartupPrefix :: IO ()
partialStartupPrefix = bracket openFixture closeFixture $ \(Fixture peer broker deadline _ calls fragments) -> do
  frame <- must (Transport.startupPrefix (ready deadline))
  N.sendAll peer (B.take 3 frame)
  result <- Broker.completeStartup broker
  check "partial startup becomes indeterminate" (result == Broker.Indeterminate)
  again <- Broker.completeStartup broker
  check "startup not replayed" (again == Broker.Closed)
  count <- readIORef calls
  check "no callback for partial startup" (count == 0)
  seen <- readIORef fragments
  check "startup prefix actually reached credential guard" (seen > 0)
  left <- remainingMicros deadline
  check "current full-D wait leaves no guaranteed 500ms reserve" (left < 500000)

-- The initial prefix and some body are genuine generated request bytes. The
-- blocked receive must not dispatch; a subsequent call cannot revive/replay.
partialRequestBody :: IO ()
partialRequestBody = bracket openFixture closeFixture $ \f@(Fixture peer broker deadline startup calls fragments) -> do
  start f
  before <- readIORef fragments
  (_,frame) <- validRequest startup
  N.sendAll peer (B.take 5 frame)
  result <- Broker.serveBrokerOnce broker
  check "partial body becomes indeterminate" (result == Broker.Indeterminate)
  again <- Broker.serveBrokerOnce broker
  check "partial request cannot be replayed" (again == Broker.Closed)
  count <- readIORef calls
  check "partial request never invoked callback" (count == 0)
  after <- readIORef fragments
  check "request fragment actually reached credential guard" (after > before)
  left <- remainingMicros deadline
  check "current full-D read leaves no guaranteed 500ms reserve" (left < 500000)

main :: IO ()
main = positiveValidStop >> partialStartupPrefix >> partialRequestBody

{-
Root controls: execute each case in its own root-owned process with an external
watchdog and record nonthreaded RTS/provider mode; System.Timeout in the same
RTS is NOT an independent watchdog. For a proposed 500ms cleanup reserve, add
an independently gated test that holds a correctly credentialed partial frame
open: with ample initial D, require read admission to retire by D-500ms (with
explicit measurement tolerance), then use the remaining original D for sole
reaper/cleanup. The current Broker waits to D, so this proposed expectation is
an UNMET contract, not a passing assertion above. If D is already <=500ms, no
new read budget exists; refuse without inventing a deadline. Do not require a
fixed 500ms of real cleanup after a stall or claim an unobserved clean reap.

Entrypoint.readFrame and withinDeadline are private. Root must exercise them
through the real authenticated engine-only entry, owned peer, namespace and
external watchdog (no fabricated child receipt): valid startup/reply positive;
header/body fragments stop before D; changed/missing/extra credentials, EOF,
late reply, and D expiry fail/poison with no replay; 500ms reserve if adopted.
The entrypoint uses unsafe GTK/FFI with a nonthreaded RTS, so independently
withhold return across D in an owned provider fixture and verify what actually
stops. A timer in that same RTS cannot prove liveness. Separately, a root-only
controlled custody test must block the actual admission callback while stop
attempts its shared gate; the external watchdog must retain stuck/unknown
results and verify no double reap. No fake authentication, GUI success, native
acceptance, test execution or production permission is asserted here.
-}
