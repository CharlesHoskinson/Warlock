# `1924` Wave Packet — `CapturedAction` Closed-ADT Patch, Proportional Replay Draft, and Separate Website / Usable-MVP Forward Plan

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run / Cutoff**: `warlock-20261031-setup` · `2026-11-01T19:58:00Z`
- **Scope & Execution Boundary**: Source-only authorship and read-only source verification in ignored drafts under `.warlock-contributor/engine-pid1-drafts/`. **Zero** canonical source/model/QA edits, **zero** compiler/Node/Quint/VM/GPU execution, **zero** access to `tools/check_auth_cpu.py`, and **zero** edits to foreign-dirty `site/src/SiteMain.elm` (`sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`).
- **Delivery Ledger Truth Retained**: `15 / 242` historical whole requirements and `39 / 417` accepted scenarios (`0` net-new whole EARS in the first `18:11:37–19:11:37 UTC` window against the `2–3` whole EARS/hour operational target); `ELM-TEA-001` / `ELM-TEA-002` remain unadjudicated; `UX-PERFORMANCE-ACCEPTANCE.md` physical-hardware latency/resource targets remain `UNMEASURED`; `nativeOperations: []` and `HOSTSTOP2` preserved.

---

## Part 1 — `ELM-TEA-001` Retained-State Repair: `CapturedAction` Closed `Surface` & `Trigger` ADTs

### 1.1 Deliverable Inventory & SHA-256 Hashes

| Artifact | Path | SHA-256 | Notes |
| --- | --- | --- | --- |
| Production ADT patch (ignored draft) | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/Tea001CapturedActionAdt.patch` | `2e6a48ec7fa576fec647aa9ea27e25f219ddc095dd01418219e6e90dc0bd157f` | Verified via `git apply --check` + forward/reverse `patch --batch -p1` round-trip in scratch |
| Prospective `CapturedAction.elm` preimage → postimage | `implementation/warlock/src/CapturedAction.elm` | `5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc` → `58d38d4ee1315d9957a2d92e67615c237de1cc007b444c5c415a213d765697a5` | Canonical file untouched |
| Prospective `Presentation.elm` preimage → postimage | `implementation/warlock/src/Presentation.elm` | `745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396` → `a0b74f3c3e85b67dc4d5e9b3991d6a7b9320c30955a6f7c48fcf53c98521b13a` | Sole `CapturedAction.surface` consumer across all `src/**` & `qa/**` |
| Unchanged existing QA caller | `implementation/warlock/qa/PopupEntryReplay.elm` | `a0843e1679dfe8c5aa06ab034102aa7c1de1d1a518770d328f5712cae566ae02` (unchanged) | Calls only `CapturedAction.decode` and `CapturedAction.encode`; signatures & wire bytes preserved |
| Proportional standalone QA worker draft | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/CapturedActionReplay.elm` | `8eef1b4c848c62bda2659ca4b223d168132ed45cf11ca821073d9a6ba1f45559` | `22` unique boolean checks + `4` raw encoded wire observations; frozen `typed-state.cjs` 4-worker CLI left untouched |

### 1.2 Pre-Overlap Coordination & Read-Only Peer Reviews

- **Pre-overlap coordination completed** with `terra-security` (`01M6C9AGH44V1PDM7M63Z8A1TB`), `terra-graph` (`01M6C9AFP569PHQGKCHX64E82V`), and `terra-q-origin` (`01M6C9AGTS39BY5FYD71HX1KDK`) before writing.
- **Independent read-only source reviews completed**:
  - `terra-graph` (`01M6C9FZ469XVJCDDXVEY6SE6F`): Verified `Tea001CapturedActionAdt.patch` (`2e6a48ec...`) against `CapturedAction.elm` and `Presentation.elm` — confirmed opaque wrapper retained, `Bar`/`Popup` and `Pointer`/`Keyboard` mappings, optional `trigger`, sorted field validation, counter guards, encoding key order, and confirmed `Presentation.elm` is the sole `CapturedAction.surface` consumer (`no source-level mismatch found`).
  - `terra-security` (`01M6C9GCKEFM69FN3HGTD0KWR9`): Read-only reviewed `2e6a48ec...` — confirmed finite `surface`/`trigger` maps preserve decoder shape, strict fields, canonical `publication`/`lease`, optional `trigger`, and `encode` values/order, and confirmed `Presentation.elm` is the sole `surface` accessor while `PopupEntryReplay.elm` uses `decode`/`encode`. Noted exact specification precision on `identity`: Elm's `not (String.any (\c -> Char.toCode c < 32) candidate.name)` rejects ASCII C0 control characters (`U+0000..U+001F`) and enforces `1..512` length without rejecting `DEL` (`U+007F`), while the Haskell action boundary enforces its own stricter wire check. Adopted verbatim (`c0ControlIdentityRefused` in `CapturedActionReplay.elm`).

### 1.3 Source Authority vs Native Authority Separation (`ELM-TEA-001`)

1. **Opaque UI Transport Envelope, Never Native Input Capability**:
   - `CapturedAction` (`type CapturedAction = CapturedAction { publication : Counter, lease : Counter, surface : Surface, identity : String, trigger : Maybe Trigger }`) keeps its constructor unexported (`module CapturedAction exposing (CapturedAction, Surface(..), Trigger(..), ...)`).
   - `Surface = Bar | Popup` and `Trigger = Pointer | Keyboard` eliminate the two closed finite `String` fields inside `CapturedAction`, while keeping `identity : String` as a bounded (`1..512`, non-C0) open control-identifier vocabulary (`"bar:applications"`, `"bar:group:..."`, `"entry:..."`, `"control:close"`, etc.).
   - A decoded `CapturedAction` proves only that a renderer-side message matched the current accepted `SurfaceSnapshot`'s `(publication, lease, surface, enabled control id)` in `Presentation.dispatch` (`Bar.elm` passes `False` -> `CapturedAction.Bar`; `Popup.elm` passes `True` -> `CapturedAction.Popup`). It is **not** an authenticated physical/compositor input-origin capability and **never** grants window, launch, or native effect authority.
2. **Single Policy Authority Preserved in `Surface.resolve` / `Desktop.update`**:
   - Relayed wire payloads emitted by `Presentation.dispatch` still enter the single policy route (`Surface.resolve` -> `Desktop.SurfaceEntry` / `Desktop.update`), which re-verifies `(publication, lease)`, current enabled controls on `Desktop.Model`, pointer-ownership gates (`PointerOwnership.blocked`), motion readiness, and `Effects` reservation rules before proposing any `Desktop.Effect`.
   - Native window/process execution and authenticated credential transport remain exclusively owned by the Haskell runtime/broker and compositor.
3. **Exact Wire & Error-Ordering Fidelity**:
   - Input wire keys remain strictly `["id","kind","lease","publication","surface","surfaceProtocol"]` when `"trigger"` is absent and `+ ["trigger"]` when present (`"Action fields"` on missing, extra, or duplicate keys).
   - Invalid `"trigger"` strings still fail with `"Action origin"` before `"Action scope"`, and invalid `"surface"` strings, wrong `surfaceProtocol`/`kind`, `publication == 0`, or empty/`>512`/C0 `id` still fail with `"Action scope"`.
   - `CapturedAction.encode` preserves exact field order and omits `"trigger"` when `trigger == Nothing` (required so `Surface.resolveAction`'s strict key-set check accepts omitted-trigger actions identically before and after relay).

### 1.4 Root Integration & `contributor extend` Handoff Notes

If Root selects `Tea001CapturedActionAdt.patch` for the next `tea-model-effects` tuple:
- Declare path extensions in `.warlock-contributor/tea-model-effects.json` before applying:
  - `implementation/warlock/src/CapturedAction.elm` (preimage `5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc`)
  - `implementation/warlock/src/Presentation.elm` (preimage `745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396`)
  - Optional QA worker: `implementation/warlock/qa/CapturedActionReplay.elm` (copy from `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/CapturedActionReplay.elm`, `sha256:8eef1b4c848c62bda2659ca4b223d168132ed45cf11ca821073d9a6ba1f45559`).
- Per `terra-q-origin` (`01M6C9AGTS39BY5FYD71HX1KDK`), canonical `implementation/warlock/qa/typed-state.cjs` is currently frozen as a 4-worker CLI (`NotificationsReplay`, `JumpListReplay`, `NotificationRelevanceReplay`, `RetirementProofReplay`); Root may either run `CapturedActionReplay.elm` via a separate runner check or explicitly extend `typed-state.cjs` with its 22-key manifest:
  ```js
  CapturedActionReplay: Object.freeze([
    'barPointerDecodesTypedAndEncodesExactWire',
    'barKeyboardDecodesTypedAndEncodesExactWire',
    'barOmittedTriggerDecodesNothingAndOmitsWireTrigger',
    'popupPointerDecodesTypedAndEncodesExactWire',
    'popupKeyboardDecodesTypedAndEncodesExactWire',
    'popupOmittedTriggerDecodesNothingAndOmitsWireTrigger',
    'presentationDispatchAcceptsMatchingBarAndPopupRoles',
    'presentationDispatchRefusesCrossSurfaceMismatch',
    'surfaceResolveAcceptsRelayedTriggersAndPopupClose',
    'max512IdentityBoundaryAccepted',
    'invalidSurfaceRefused',
    'invalidTriggerRefused',
    'nullTriggerRefused',
    'extraFieldRefused',
    'missingFieldRefused',
    'duplicateKeyRefused',
    'wrongProtocolRefused',
    'wrongKindRefused',
    'zeroPublicationRefused',
    'emptyIdentityRefused',
    'overlongIdentityRefused',
    'c0ControlIdentityRefused',
  ])
  ```

---

## Part 2 — Separate Website & Usable-MVP Forward Recommendations (Non-TEA Adjudication Track)

> **Strict Separation Notice**: Nothing in Part 2 modifies canonical or foreign-dirty `site/src/SiteMain.elm` (`f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`), and browser/website presentation or CSS/DOM hierarchy improvements **never** establish `ELM-TEA-001` / `ELM-TEA-002` closure, physical-hardware `UX-PERFORMANCE-ACCEPTANCE.md` latency, `ELM-UI-005` / `ELM-UI-007` native acceptance, or release readiness.

### 2.1 Refreshed Homepage Diff Candidate (`SiteMainTeaProtected05.diff`)

- **Ignored Draft Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainTeaProtected05.diff`
- **SHA-256**: `e006272c4e3bbb0b325479986969d83a5f51ce48391efb7428b031981e0d2f69`
- **Target Preimage -> Prospective Postimage**: `site/src/SiteMain.elm` `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` → `6974b66ff3a45fc8e887aa416d86cd4c4295cc7d4840240ab05ae85381052854` (`git apply --check` + forward/reverse `patch --batch` round-trip verified; prior `SiteMainTeaContractPublished31a92.diff` `9e4961eb...` preserved intact).
- **What `SiteMainTeaProtected05.diff` carries forward for Root's next site publication window**:
  1. **Current Published & Protected CPU Facts Without Overclaiming**: Updates homepage scope card 2, hero ledger row 2, and readiness tier 2 from `31a92dce9` to published `873d9c518` + protected report `1793560906209268899` (`6` optimized production Elm roots, `4` typed-state workers / `87` typed controls across `Notifications`, `NotificationRelevance`, `JumpList`, and `RetirementProof`, and `42` complete `DesktopPolicy` histories / `101` transitions run twice with `15` GIVEN setup preludes, retaining two prior RED QA reports without relaxing any product guard) alongside `3f88ed9b4` (`10` Haskell suites & `273` named model tests).
  2. **Honest First-Hour Target & Open-Gate Accounting**: Explicitly records that historical verdicts remain `15 / 242` whole requirements and `39 / 417` scenarios (`0` net-new whole closures in the first `18:11–19:11 UTC` window against the `2–3` whole EARS/hour operational target), `ELM-TEA-001` / `ELM-TEA-002` remain unadjudicated, software-VM QMP `run-01`/`run-03`/`run-08` (`qvxz9`) are not physical hardware input or latency proof, `ELM-UI-005` current-port authoritative `pendingQuery` correlation remains unverified, physical-hardware `UX-PERFORMANCE-ACCEPTANCE.md` targets remain `UNMEASURED`, and `ELM-ARC-024`, `ELM-DEL-014`, AT/IME, provider cleanup, and native/release gates remain `OPEN` (`nativeOperations: []`, `HOSTSTOP2` preserved).
  3. **Lacquer High-Contrast, Forced-Colors & Responsive Usability**: Retains `role="group"` tester CTAs, `aria-labelledby` scope cards, `40px` (`2.5rem`) minimum interactive chip height, explicit `data-theme="high-contrast"` `#00FFFF` pressed underline + dual inset ring, `@media (forced-colors: active)` `Canvas`/`CanvasText`/`Highlight` overrides (`backdrop-filter: none`), and 4→2→1 responsive readiness/scope grids.

### 2.2 Usable-MVP Product Surface Recommendations (Carry-Forward for Post-TEA Product Slice)

1. **Explicit `:state` Guidance Controls Over `snapshot.status` String Parsing (`Surface.elm` -> `SurfaceRenderer.elm`)**:
   - Carrying forward our `1900` source audit of `AppOnlyHierarchyEmptyState.patch`: when Root schedules usable-MVP empty-state and application-only utility hierarchy polish, emit explicit non-interactive guidance rows from `Surface.elm` (using `:state` control IDs with structured `label` + `detail`) rather than splitting `snapshot.status` on `" · "` or matching English substrings inside `SurfaceRenderer.elm`. This preserves `Surface.elm` as the single Elm presentation-content authority (`ELM-TEA-001`) and aligns with `terra-browser`'s `43`-control popup literal inventory (`terra-browser-settings-popup-literal.cjs`).
2. **Visually Distinguish `Popup.pendingQuery` From Authoritative `Catalog.search` Results (`ELM-UI-005` / `UX-PERFORMANCE-ACCEPTANCE.md` §Prioritized Review #2)**:
   - Currently `Popup.view` applies `SurfaceRenderer.pendingQuery query snapshot`, which updates the search input label and disables stale `entry:*` controls while awaiting the backend/policy projection, whereas `snapshot.status` still reflects the last accepted `Surface.packet`. Surfacing an explicit subtle `"Searching…"` / pending-sync badge in `SurfaceRenderer` whenever `Popup.pendingQuery /= Nothing` (and clearing it only on the matching authoritative `SurfaceSnapshot`) prevents users and visual observers from mistaking an older no-match/result list for the newly typed query, directly supporting `UX-PERFORMANCE-ACCEPTANCE.md`'s `100 ms p95 / 200 ms p99` search-key-to-matching-result contract without introducing a second search authority.
3. **First-Usable-Frame Readiness vs Early-Click Feedback (`UX-PERFORMANCE-ACCEPTANCE.md` §Prioritized Review #1)**:
   - Keep `Bar` utilities visibly disabled/loading with explicit `detail` text when `Desktop` attachment or pointer-ownership readiness (`PointerOwnership.blocked`) has not yet completed, rather than rendering enabled-looking controls before hit-test/allocation and session attachment settle.
