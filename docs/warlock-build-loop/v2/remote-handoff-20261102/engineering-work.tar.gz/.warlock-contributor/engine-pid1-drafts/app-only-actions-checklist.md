# First-window app-only actions: observation checklist

Preparation only. This is a source-bound observation plan, not a test result,
original EARS/native acceptance, or permission to interact with an unowned
window. Root alone performs the reviewed isolated guest/VM trial and records
actual source/image/ABI/session hashes, owned PID+birth/window identity, original
D, cleanup and raw evidence outside the repository. No actual window is assumed.
The configured app-only binding is local authenticated correlation, not a
compositor-issued window grant. Native operations remain `[]`; no fabricated
binding, GDK topology, user input, or acknowledgment.

## Source tuple inspected

* `src/Shell.elm` SHA256 `6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094`:
  strict protocol-3 `application-attached` only accepts empty `nativeOperations`;
  `applicationOnly` suppresses projection requests/refresh and native effects.
* `src/Desktop.elm` SHA256 `273622ad7a83a5538896b43831ffc705e3c38df9c1419ee0ec43cd5f81bec2c8`:
  `OpenApplications`, catalog request/reply, search, pin state and write route.
* `src/Surface.elm` SHA256 `c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb`:
  app-only catalog entries cannot launch; Applications and supported pins are
  exposed; Files/System/Notifications/Settings utilities are disabled.
* `src/Popup.elm` SHA256 `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58`:
  local pending query, composition baseline and same-field projection behavior.
* `src/UiHttp.elm` SHA256 `3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419`:
  one active post, bounded pending, fail/cancel; empty HTTP 204 is transport only.
* `haskell/runtime/src/Warlock/Backend.hs` SHA256
  `6d26e1f8362f96d9894143c719a79ade7610f9c444101eb9f9c4e52ad5da8099`:
  opt-in attachment reserved once; checked catalog/pins requests and replies.

Re-hash the actual source and artifacts used by the run; these hashes identify
this review, not necessarily the next runnable tuple.

## Ordered observations for an owned first window

- [ ] Verify selected broker/engine identity, isolated display and actual mapped
  positive GDK surface first. Record observed topology and presentation-only
  whole commit; ensure the checked backend sends `application-attached` with
  the exact authenticated binding and empty native operations. This does not
  prove compositor authority or a native window effect.
- [ ] Observe visible Applications entry on the mapped window. Activate that
  actual control in the owned scope; confirm `Desktop.OpenApplications` causes
  one authenticated `catalog-request` with matching full-width binding and
  requestId. Initial opening requests search focus; check actual focus rather
  than infer it from an Elm command.
- [ ] Observe the matching `application-catalog` backend response and resulting
  catalog/search UI. Record explicit loading, unavailable/empty and no-match
  states when genuinely produced; do not replace failed reads with fixtures or
  assume that any number of entries exists. Backend uses validated configured
  catalog roots and may return unavailable rather than a truncated snapshot.
- [ ] Confirm application entries/launch and unsupported utility controls are
  disabled in app-only mode. Do not click launch, grant native operations, or
  claim task/window control. Pin/unpin/reorder only a real displayed identity
  when `Pins.writable`, in a fresh run-owned pins root; correlate each
  `taskbar-pins-write` binding/requestId with `taskbar-pins-outcome` and the
  actual visible order. No host pin writes. Capture refusal/unknown as such.
- [ ] Type a nonempty search string in the owned field and observe the visible
  text and filtered result. On explicit Refresh, retain the field's focus and
  unsaved local input across a same-field accepted projection. Do not claim
  preservation after a deliberate field/lease change: `Popup.Present` clears
  pending/composition when the accepted field no longer matches.
- [ ] With actual IME available and separately observed, begin composition and
  confirm preedit remains visible in the same current enabled field and focus
  is retained; no search query/entry activation is dispatched during preedit.
  Commit a changed composition once; cancel/same-baseline must not synthesize a
  query. If no IME or observation is available, record unobserved, not pass.
- [ ] Exercise only an authorized controlled stale scope/lease/publication in
  the same session. Stale dismiss/reflow/escape are refused without an event;
  a current event can still be accepted. A stale topology is owner-fatal and
  must not be recategorized as stale projection. On real unmap, stale dismiss
  must not suppress the subsequent empty topology retirement. Do not replay any
  uncertain native/domain operation to demonstrate this.
- [ ] Capture `application-attached`, catalog and pin correlation, view-frame
  identity/revision/lease, input/focus observations, independent process and
  cleanup results with clock/deadline and failures. If transport returns HTTP
  204, record local transport completion only: it is not native ACK, backend
  consumption, successful pin persistence, window focus or physical input.
  For pins unknown/failure retain Unknown and do not repeat a write implicitly.

## Boundaries

The frontend-delivery Quint model abstracts finite roles, queues and focus
instructions; it does not establish actual WebKit filtering, GDK mapping,
physical focus/IME, AT, window management, native cleanup or original-scenario
acceptance. Existing CPU/model pass counts and a VM observation cannot replace
those observations. Preserve all 242/417, original deadlines, prior failures and
HOSTSTOP2; do not reset a stopped original or change the main desktop/Foot.
