# Converged Persistent Custody Foundation `v17` (`012747Z`)

- **Canonical `HEAD`**: `05dc05572817d9821132ef6e29100efe8046f418` (`19/242` requirements, `42/417` scenarios; `DEL-010` independently accepted on `02b0aba0b128a184177dc166450c5302b017c50e`; zero native/GUI/provider/AT/IME/hardware/release acceptance claimed).
- **Verification Scope**: Source-only static audit (`PROD_NO_MACROS` + `QA_MACROS` CPP/delimiter/tab/CR checks) and isolated `patch -p1 --fuzz=0` / `git apply --check` verification across all three stacks below. **Zero compiler, test, Quint, VM, GPU, or native execution performed by worker.**

## 1. Frozen `v17` Artifacts (Preserving `v11`..`v16` Immutable)

| Artifact | SHA-256 | Purpose |
| --- | --- | --- |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v17-012747Z.patch` | `0e3b54a28eb4c9373e4f17d719b2c271a3df80cfe51df9eb98b7adb313ca5fa9` | Single self-contained 12-file production patch (`held-document` + `process-custody`) on `05dc05572817d9821132ef6e29100efe8046f418`, byte-identical to applying the 13-patch `v15` + `terra-engine` (`957`+`905`+`0a`) + `terra-security` (`f6`+`f78`+`d9`+`186` + `ec8`+`b9`+`4d`+`af463a3a`+`fd59a20a`) chain |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v15-to-v17-delta-012747Z.patch` | `56621de63571aa09d2e2451b50d6d2488598b30a3e28fb7cb6f5ba5d670f3f4f` | Exact 6-file delta from frozen `v15` (`36ada0d6...`) to `v17` |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-owner-gate-qa-seam-v17-012747Z.patch` | `a56b8cd6976f638ce70019efce36ff9681019063cbfd39c883c59a33f26c5ea1` | Rebased `WARLOCK_OWNER_QA` seam for `Owner.hs` + `process-custody.cabal` (replaces `0c387d71`, which failed `--fuzz=0` on `Owner.hs` export header after `186d2baa`; preserves exact Cabal postimage `483a076d351046ffa72563f996f6987e3a8a14d7b2172673aea32b3ae973db89`) |

## 2. Defects Resolved Relative to `v15` (`36ada0d6`) and `0150` Check (`terra-graph-custody-chain-check-0150.json`)

1. **Pre-owned opaque `HeldBorrow` (`957021a6` + `905499c3` + `0a872264` + `f6ea512a` + `d9c161f8`)**: Allocates and retains `HeldBorrow` in `rawOwner` (`O.retainHeldBorrow`) *before* `activateHeldBorrowWhile`, eliminating closure-tuple `onException` uninterruptible-mask fallback and distinguishing `BorrowNotAcquired` from sticky `HeldUnknown` (`Just False`).
2. **Closed-core & deadline-bounded raw `Owner` finalization (`f78de583` + `186d2baa`)**: `tryAbortHeldNoInputBefore` / `tryAbortHeldWithCoreBefore` / `tryAbortHeldNotAcquiredBefore` verify `tryCoreClosedMatches` (`Closed (Core token)`) and monotonic `end` (`< D`) inside `Owner`'s `gate`, poisoning `rawOwner` on unconfirmed rollback rather than publishing `Idle`.
3. **Pre-spawn `StopD` resampling & nonblocking `CallbackGate` (`ec8cafb4` + `b9b20c7c` + `4d104dc2` + `af463a3a` + `fd59a20a`)**:
   - Replaces blocking `peekGateStop` after borrow (`latchedAfterBorrow`) and on `beforeSpawn == 0` with nonblocking `tryPeekPreSpawnStop`.
   - Replaces blocking `reserveSpawnUnderGate` with `tryReserveSpawnUnderGate cbGate startDl`, nonblockingly taking `CallbackGate` and re-sampling `remainingMicros startDl` *inside* `CallbackGate` before committing `SpawnReserved` (retaining `FixtureHandle` + `Pending` + `HeldBorrow` on busy gate).
   - Fixes `abortPreSpawnWithInput` for `persistentHeldNoInput` (`(Just _, Nothing, Right base) -> finishTracked pending base False False exitVal`).

## 3. Minimal Reviewed Production Foundation Sequence (`--fuzz=0`)

Excludes `terra-portable-bootstrap-cleanup-004.patch` (`14140811`) and `Backend` runtime wiring (`001`..`008`):

1. `gemini-omarchy-persistent-custody-prereqs-v17-012747Z.patch` (`0e3b54a28eb4c9373e4f17d719b2c271a3df80cfe51df9eb98b7adb313ca5fa9`)
2. `terra-engine-lexical-ingress-integration.patch` (`74b07921d42d5a424bf67ce4d7610903dcdf5765c29d045e08190b7d14d62367`)
3. `terra-q-front-context-ingress-001.patch` (`c9fe0c1ac30e96cc3824d363398f881f2a79939c73ac83f8107a098a3b4fa526`)
4. `terra-q-front-owned-ingress-001.patch` (`51f966997629873d7c3f0153a45861733b2e74a9887ca46b94c5b22e8bbcc629`)
5. `sol-outbound-pin-rebase-001.patch` (`33c3f67c74b68c4435f8c30854e3be60ccdbda5731a6fd0686bd37a8b5fb4203`)
6. `sol-store-acquisition-settled-v3-0140.patch` (`bdaa2f8b1272cd72521ab707bd4ab7f78998eb165a4021242fd40529e696d76b` — apply on clean `HEAD` `05dc05572`; skip if already staged in working tree)

## 4. Full QA Seam + Suite Overlay Sequence on `v17` (All 9 Overlays Verified `--fuzz=0`)

1. `gemini-omarchy-owner-gate-qa-seam-v17-012747Z.patch` (`a56b8cd6976f638ce70019efce36ff9681019063cbfd39c883c59a33f26c5ea1`)
2. `terra-engine-preowned-caller-qa-seam-002.patch` (`bb5e3bc4fc540b290d5808ce67b6622d89559705245c372e9487c49b6e44b294`)
3. `terra-security-v11-owner-abort-race-qa-seam.patch` (`4e1f1d876fa823968b6524315d11aebb06080d9729b688b4d973c8e6ed38389e`)
4. `terra-security-preowned-final-qa-seam-003.patch` (`89d42d8474aebc4b4e696e0deabda96e159b990f04ed132672f0ae832ade5185`)
5. `terra-graph-retained-fixture-qa-overlay-0031.patch` (`8fecc1772721912729a5fa083d39897290bd9b7b0e965b336ca8a8120e5c8175`)
6. `terra-engine-held-preowned-qa-003.patch` (`75e53e92c59d0ffa3a983dfab71b414d5ab474c5c988de528277fa7996395025`)
7. `terra-engine-preowned-transition-suite-001.patch` (`c9beaeb3025cb536d04baa91e7b4bd385889e0ea53bd3e7f87682281c74c4f26`)
8. `terra-engine-preowned-exception-suite-001.patch` (`fbfcdcc58738bbca85cb0864bbd1973317cf2bd340a8dd4ac2609e6c12cf1cb5`)
9. `terra-engine-preowned-finish-gates-suite-001.patch` (`e42335b5b7f1e0b5c6dcc5867dbff05d4a8bacd3d6427970d5c9372fecf935b9`)

## 5. Remaining Explicit Non-Claims & Open Boundaries

- `terra-security-owner-pending-observer-001.patch` (`52aa80b0`) remains intentionally excluded from `v17` per `terra-security`'s `HOLD` notice (`ownerPending` blocking `modifyMVar gate` would block `qaPersistentPendingIssues` if called while `rawGate` is held).
- Already-in-flight kernel `close`/`hClose` syscalls cannot be physically preempted mid-syscall without a kernel-level mechanism; if `StopD` expires before an in-flight input close or release returns, `v17` preserves `ExitUncertain CleanupUncertain` (`Unknown`) rather than claiming clean retirement, matching Root's boundary ("Root decides actual syscall admission-vs-inflight-Unknown semantics from original oracles; no new universal physical stop gate").
- Root-only compiler, test suite, Quint model, guardian, and VM/native verification remain required before any readiness or scenario claim.
