{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. One isolated guarded process per mode. The host must
-- supply the actual same-owner configured actor, selected authenticated child
-- and private pin directory; never fake a delivery result or native grant.
module QHttpDeliveryActor051 (Mode(..),Case,newCase,runCase,retainedWorkers) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,PersistentDelivery(..),
 runPersistentBackend,persistentBackendDelivery,persistentBackendCounts,qaBeforePersistentWriter,qaPersistentActionOutcome)
import Warlock.Backend.PinStore (PinStore,readPins)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Protocol.Codec (checkDesktopReply,desktopProfile,encodeServerCheckedWith)
import Warlock.Protocol.CredentialIngress (PersistentSendResult(..),enqueueCredentialIngress)
import Warlock.Protocol.Identity (binding,parseCounter)
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Ingress (Priority(..))
import Warlock.Transport.Channel (ChannelError(..))

data Mode = ActualQueueFull | InjectBeforeWriter deriving (Eq,Show)
data Case = Case PersistentBackendOwner PinStore (IORef Bool) (IORef Int) (IORef [ThreadId])
newCase :: PersistentBackendOwner -> PinStore -> IO Case
newCase owner observer = Case owner observer <$> newIORef False <*> newIORef 0 <*> newIORef []
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ _ threads) = readIORef threads
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("delivery: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
waitCell :: AdmissionDeadline -> String -> MVar a -> IO a
waitCell originalD label done = do
 left <- remainingMicros originalD
 if left<=0 then ioError (userError (label ++ ": retain Case and guardian")) else do
  outcome <- timeout left (readMVar done)
  maybe (ioError (userError (label ++ ": Unknown; retain Case and guardian"))) pure outcome
launch :: IORef [ThreadId] -> IO a -> IO (MVar (Either SomeException a))
launch threads action = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (readMVar start >> action))
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' threads (\xs -> (tid:xs,()))
 putMVar start ()
 pure done
observePins :: IORef [ThreadId] -> AdmissionDeadline -> PinStore -> IO D.PinSnapshot
observePins threads deadline store = do
 done <- launch threads (readPins store)
 result <- waitCell deadline "independent real pin read" done >>= either throwIO pure
 need result

-- The selected child must send the actual validated binding 1/2/3, id 7,
-- revision 1, identities [alpha] request. Root prepares a real private catalog
-- admitting alpha, an initially empty pin store, a positive actual IPC path,
-- configured actor, live selected child, scope/threads and separate guardian.
-- The checked outbound prefill is a valid local QA reply; it is not a peer ACK.
runCase :: Case -> AdmissionDeadline -> Mode -> IO ()
runCase (Case owner observer used hooks threads) originalD mode = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\was -> (True,not was))
 check "one case" fresh
 one <- need (parseCounter False "1")
 two <- need (parseCounter False "2")
 three <- need (parseCounter False "3")
 six <- need (parseCounter False "6")
 bound <- need (binding one two three)
 old <- restore (observePins threads originalD observer)
 check "literal fresh store baseline" (D.pinRevision old==one && D.pinIdentities old==[])
 raw <- need (D.pinsReply bound six D.PinRefused Nothing)
 checked <- need (checkDesktopReply raw)
 validReply <- need (encodeServerCheckedWith desktopProfile checked)
 qaBeforePersistentWriter $ \scope ingress -> do
  atomicModifyIORef' hooks (\n -> (n+1,()))
  case mode of
   InjectBeforeWriter -> ioError (userError "QA exception before writer invocation")
   ActualQueueFull -> do
    -- Real same-scope queue operation, with a valid encoded ordinary reply.
    -- No mocked PersistentSendResult: the actual writer must detect QueueFull.
    queued <- P.withLiveBatchWriteAdmission scope (enqueueCredentialIngress ingress Ordinary validReply)
    check "real ordinary slot occupied" (queued==Right (Right ()))
 done <- launch threads (runPersistentBackend owner)
 run <- restore (waitCell originalD "actual actor completion" done) >>= either throwIO pure
 delivery <- persistentBackendDelivery owner
 action <- qaPersistentActionOutcome
 n <- readIORef hooks
 saved <- restore (observePins threads originalD observer)
 let (_,operations) = persistentBackendCounts run
 check "one actual pin request persisted independent literal result" $
  n==1 && operations==1 && D.pinRevision saved==two && D.pinIdentities saved==["alpha"]
 check "entered domain action reports actual typed Unknown" $
  action==Just (Left (P.OperationOutcomeUnknown SpawnOrIO))
 case mode of
  ActualQueueFull -> check "actual queue refusal is local, after domain mutation" $
   delivery==DeliveryCompleted (SendRefused QueueFull)
  InjectBeforeWriter -> check "exception before writer leaves delivery InFlight" $
   delivery==DeliveryInFlight
-- InjectBeforeWriter does not claim an exception from sendAll. Local delivery
-- is not a peer receipt; no result above proves cleanup or native acceptance.
