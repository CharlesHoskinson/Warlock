# Sol live-GUI advisory — 17:30 continuation

Same sol-docs session01a1947b-90dd-7ac0-9b96-477ca1e32bc2; root is sole
coordinator/executor. Bounded advisor cutoff17:55UTC, Terra wave17:52UTC.
Own distinct claim01M6C2JSDQ6Q5AJXE3AF1YTTRN. Draft/source review only.

## Current evidence and priority

Directly inspected protected report1793553496966127943: passed=true,
build.passed=true,345source hashes, nativeAccepted=false, releaseAccepted=false.
User/root report all10suites/273named model cases and independent VM readiness
5b7fa20f. Guest217source/10file incremental delta with preimages and fresh dynamic
engine-idle-20261101T172728Z buildexit0 are reported; artifact inventory/trial
results were pending at resume. These do not transfer native or release acceptance.

Root's actual owned-window28s trial is the delivery priority. The reviewed QMP
skeleton is optional; a root-reviewed manual per-event fenced action is equally
within scope. No mandatory new driver, model or architecture gate is proposed.
Keep original D/native5s framing, all242/417, historical15whole/39scenarios,
retained failures, HOSTSTOP2 and nativeOperations=[] intact. Provider cleanup
remains unqualified; never infer it from local window closure or process exit.

## New source review: corrected GUI draft

AppOnlyHierarchyEmptyState.patch931a10e988cb0170d322de538283d4d6cd30a895ec096d335d4d2520945b810f
now uses exact canonical Loading/unavailable/no-match status after only the
fixed compact-presentation prefix. Default[] preserves pin/launch/error notices.
It no longer derives no-match from absence of visible paginated entry rows.
The prior counterexample is addressed on source inspection; keyed control prefix
is unchanged with passive guidance appended. GTK/wire are unchanged. No compile,
browser, physical focus, IME or style result is implied.

q-front's new caveat: Popup.pendingQuery/preedit may overlay the displayed field
while snapshot.status remains the accepted prior query. Supplementary query-result
cards can therefore amplify stale feedback. Smallest later screenshot remedy:
closed-state heading/guidance only, deferring supplemental search-result cards;
leave canonical status and search policy alone. No new wire/API/model required.
The heuristic isAppOnlySession may guide presentational copy but a
data-surface-scope attribute must not be presented as authenticated app-only
authority. Remove it or label it as a visual variant. Root/Gemini-GUI received
these points; root's actual screenshot/focus findings decide the next change.

## Physical-driver correction tracking

Old083c4 driver review is historical; do not repeat addressed issues as new
blockers. Requested the owner's new exact hash and mapping of changes before
reading a moving target. Review only current bulk-environment access, cgroup
unknown propagation, pgrep/layer schema errors, original-D dispatch budget,
baseline birth proof and current coordinates. Source review is not execution
qualification. Root may bypass this optional draft in favor of manual fences.

## Smallest real lifetime source seam

Verified against current source and terra-graph's source map:

* `Mvp.hsc:964-1029` can emit owner-acknowledged empty topology before stop.
  This is logical topology retirement; not physical GDK destruction or provider
  helper/reference retirement. Stop/D may skip a final normal step.
* `Mvp.hsc:1146-1156 retireMvpWindow` is the narrow local GTK teardown seam,
  already requiring closure-notifier retirement before object release. Witness
  its actual supported unmap/destruction/closure outcome without reading freed
  pointers; do not add a final post-D callback or send into a stopped Owner.
* `Owner.hs:264-295` records EngineResult before retireEngine; Main deliberately
  returnsFalseFalse. A future post-retirement fact cannot be fabricated by changing
  those booleans. WebKit filter callbacks, backing stores and helpers stay separate.

Next source proposal should follow the actual trial result: if typing fails,
target the exact observed Elm/GTK focus or field-state defect first; if the input
journey works, a bounded local surface-retirement observation at retireMvpWindow
is more useful than another broad topology/model campaign. Neither closes whole
ARC002 until its created-and-retired ownership oracle is observed. Original
UI005 no-match still requires its query/catalog fixture and named native/keyboard/
AT evidence as applicable; one screenshot is not whole UI005 or release.

## Worker limits

AGENTS/current HANDOFF/STATE and bus read; contributor/language instructions from
the same session retained. Doctor once:6checks passed. Source graph warned stale;
bounded actual-source reads are authoritative. No environment/key contents or
tools/check_auth_cpu.py read, no protected compiler/model/native/GPU/VM or agent
launch, no production edits, services or commits. Only this exact-claimed draft
is authored. Actual peer replies/trial observations will be appended before final
handoff. Presence at resume is not permanent liveness; terminal status follows.

## Actual idle observation and current peer deltas

Read engine-idle-20261101T172728Z/run-01 trial-result/backend output and viewed
late live-07.png. Trial-result SHA1dfb79c751d7b4de91768f014cb8d9bcffb791a79802a804a880c0d9cb806df1;
image SHA93567684e5cc887043c2ffe0d8080d0ed88b1647a2540e2be13710fb703f70df.
Eight screenshots, mapped samples over~26.4seconds (117rows reported by terra-vm),
physicalInputs=[], controller elapsed28.229s/exit1/failure=null and
forcedAtOriginalDeadline=false. Backend3callbacks/1operation, CredentialDelivered,
cleanup=true, passed=false. Final scope inactive/dead with empty ControlGroup,
membershipKnown=false; provider/native/release qualified fields remain false.
The screenshot still shows the closed “Choose a window” view and empty body,
not a search/input failure. No recurrence of earlier7.445s timeout is recorded.
These are sampled no-input observations, not uninterrupted visibility or stream
quiescence. The next actual enabled Applications/search route remains priority.

Precision: outer forcedAtOriginalDeadline=false is not proof every inner process
exited unsignaled. EngineCustody.stopCustody attempts owned pidfd SIGKILL before
polling; reapChild retains only si_pid>0. q-http agrees a narrow next observability
change can retain si_pid/si_code/si_status and signal-attempt/result in the SAME
sole reaper, without a new RPC, second waiter, D or promotion of FalseFalse.
Normal-exit evidence, original DEL021500ms drain and provider/backing/closure
retirement remain separate. Root received this correction and source proposal.

Graph refined its receipt language: Owner.Right() means validated enqueue, not
Elm applying, GDK destruction or provider retirement. Latest map
c7b344cf5e3d4984a0b8412fae558180a85f4079d43a21992dc4a4c53167fedb.

GUI v3ef1bb568ae123152b6e17d12abe5e1def81f987f236d16a80cf6837f6e2b50b8
passes no-pending-and-not-composing from Popup to a pure renderer argument,
suppresses supplemental query cards while false, removes heuristic
data-surface-scope/settings classification and uses exact canonical app-only
notice for closed guidance. Specific prior findings are addressed on source
review. Its six-case matrix is proposed, not executed; no full style/IME pass.

## Root's minimal manual helper: concrete review

Root provided current manual-physical.py outside checkout, not the optional large
Gemini driver. Read all source at SHAee7128b4eab3af1f1c635cf368c089572efc3f0dae7eb54cb4cdfcd26def5e42.
It has no process-environment read, strict cgroup walk and reads fail on error,
fresh engine birth/lineage/ELF/scope/activewindow/Foot, original-D8s margin,
supported monitor bounds, current operator hitbox, foreign/layer disjointness,
motion/re-gate and release-in-finally, printable short token only. No full DOM
proof is required to perform this root-controlled visible-field observation.

One concrete issue was found before execution: actual qmp.py returns an error
dictionary without a nonzero subprocess exit, and its keys mode discards the
reply. Merely check_returncode can therefore record completed/key despite QMP
error. Sent root a local fix: inspect cmd's printed controlled dictionary, require
return/no error; send explicit send-key through that checked cmd path and retain
reply. No global qmp.py edit/new framework/gate needed. Root reply/final bytes
still required; review is source-only and not input acceptance.

## Optional revised Gemini driver, not root's chosen helper

Owner handed off c58268cd37ff29f728b22f1637d28cb9c411373ac67a88307e0d48e049f65ddc.
Targeted reads confirm bulk `/proc/PID/environ` access is removed, explicit
display/session inputs replace it, cgroup walk/proc census propagate unknown,
pgrep/layer schema errors refuse, current hitboxes and host-elapsed/D checks are
present. Those old findings must not be recounted as current defects.

New concrete mismatch: qmp_call uses json.loads on actual qmp.py cmd output,
which is Python repr, and send-keys still calls keys mode, which emits no reply.
Thus the new reply check fails valid operations rather than qualifying them.
Also an emergency release path can suppress button-up or move a held pointer to
a guessed empty gutter after the main fence failed. That is not established
per-event ownership/deadline safety or safe latch neutralization. Root/owner
received both findings; terra-vm independently confirms the fallback issue.
No full review of this expanded optional driver, no execution and no gate on
root's separate small helper is implied.

Final optional-driver ed7f7fa6c196fc003ef4fa562a7ffdbaf506dbc26f726ec0e04929e5a54a0e46
was handed off and targeted source re-read confirms the actual repr parser,
checked explicit send-key and removal of automatic gutter events. A possible
held latch now remains failure/recovery-required. The specific c582 findings are
addressed; no full expanded-code review or execution qualification is inferred.

## 17:46 actual Applications and readiness screenshots

Viewed root-retained run-03-query.png SHAca5d63e49ae2ae6d72d027c44843ef72180ebf281f71ecb7a5d0639ea556c1d0:
Applications is open, search field/Refresh visible, status “Type to search
applications.”,62matching applications/0pinned and page1–8of64 controls. The field
shows its placeholder, not an entered query. This is concrete catalog rendering,
not proof of search keystrokes or no-match. A filename “query” is not an oracle.

Read physical-journey-05-result.json SHA85f3e957f933230d012d94c46c04d596d3abe0ebad3019df9b6d73c482d299ac:
events=[], completedPhysicalSequence=false, current control not observed:ready.
Viewed run-05-ready.png SHA6f54ecc83134aac5907441dd2b9b0e2ea3f3d3bb22062cb51361000db7ad2f29:
the widget layout is full-width, Applications at left~8–130px and heading near
x24/y84. physical-journey-05.py uses exact pixel comparison against the older
right-tiled template crop(670,120,850,148). Thus readiness fails before input,
consistent with changed screenshot geometry. Old clickbox660–770px would not be
Applications in this image. Root received the precise diagnosis as
01M6C3FN0TT1SZM1839XGQEND0. Reacquire fresh owned identity/geometry/hitbox; retain
this failure. No product source/focus bug or native acceptance follows.

Delivery-speed recommendation sent to root: retained run01 already establishes
its sampled late no-input observation. Unless a combined idle/input oracle is
specifically selected, the next fresh28s physical trial need not spend another
five seconds waiting before first input. Keep D unchanged and budget for actual
enabled Applications/search interaction; component stream-quiet proof stays
separate. No worker input/VM operation occurred.

## Final QA evidence naming finding

Read physical-journey-07.py SHA58f9571abeeb142e7f2cb0c9392f3cd74ead69b8a6addee75593889c5b628249:
its copy still redirects guest trial05.stdout/stderr and finally writes
physical-journey-05-result.json. Root was notified urgently as
01M6C3YEQD9Q7REDFY834477FY. Preserve original preimages/terminal captures and
use distinct next-run paths; do not rewrite failed evidence to fit later runs.

The earlier run05 result read at original SHA85f3e957f933230d012d94c46c04d596d3abe0ebad3019df9b6d73c482d299ac
contained the following body, copied from the earlier tool observation, not
claimed as a replacement original artifact:

```json
{
  "controllerPID": 110196,
  "originalDurationSeconds": 28,
  "nativeAccepted": false,
  "releaseAccepted": false,
  "events": [],
  "providerCleanupQualified": false,
  "completedPhysicalSequence": false,
  "failure": "RuntimeError: current control not observed: ready"
}
```

The same path later contains controllerPID113379 with run07 paths/events,
including current PID113418 and a helper-completed Applications click, then
failure “current control not observed: applications-open”. Viewed run07's
applications-open image still shows the closed view; filenames/transport-local
completion are not GUI state or keystroke/no-match evidence. Root should retain
actual command replies and correlate the final image/result before attributing
the failure to Elm/GTK focus. No worker operation or product edit occurred.

Terminal handoff before17:55UTC: all concrete findings/received peer responses
have been sent to root. Only this claimed draft is written. Original242/417,
historical15whole/39scenarios, D, failures/HOSTSTOP2/nativeOperations[] and
unqualified provider retirement are preserved in every claim. Recurring advisor
role remains mandatory; root must revalidate actual CLI/terminal status before
resuming the same session. Presence down after final handoff is not a goal pause
or permanent worker-liveness claim.
