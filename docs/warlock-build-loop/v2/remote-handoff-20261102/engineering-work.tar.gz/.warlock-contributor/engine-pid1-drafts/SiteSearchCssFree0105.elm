module SiteSearch exposing
    ( AppearanceTheme(..)
    , CategoryFilter(..)
    , Model
    , MotionMode(..)
    , Msg(..)
    , RouteEntry
    , ScopeBadge(..)
    , allRoutes
    , decodeEscapeClear
    , decodeEscapeMenu
    , filteredRoutes
    , init
    , initialModel
    , main
    , update
    , view
    )

import Browser
import Browser.Dom as Dom
import Html exposing (Html)
import Html.Attributes as Attr
import Html.Events as Events
import Json.Decode as Decode
import Task


main : Program () Model Msg
main =
    Browser.element
        { init = init
        , view = view
        , update = update
        , subscriptions = \_ -> Sub.none
        }



-- MODEL (CSS-FREE ELM: ALL PRESENTATION LIVES IN site.css + landing.css)


type AppearanceTheme
    = ThemeNight
    | ThemeDawn
    | ThemeHighContrast


type MotionMode
    = MotionStandard
    | MotionReduced


type CategoryFilter
    = FilterAll
    | FilterDesktopAndHome
    | FilterArchitectureAndStart
    | FilterFoundationsAndStyles
    | FilterComponents
    | FilterReference


type ScopeBadge
    = BadgeBetaWalkthrough
    | BadgeSimulatedStage
    | BadgeElmHaskellRuntime
    | BadgeTokensAndDocsOnly
    | BadgeComponentGuide
    | BadgeDesignFoundation
    | BadgeFrozenArchive


type alias RouteEntry =
    { title : String
    , path : String
    , section : String
    , category : CategoryFilter
    , badge : ScopeBadge
    , summary : String
    , keywords : List String
    }


type alias Model =
    { theme : AppearanceTheme
    , motion : MotionMode
    , mobileNavOpen : Bool
    , query : String
    , category : CategoryFilter
    , lastFocusError : Maybe String
    }


type Msg
    = SelectTheme AppearanceTheme
    | SelectMotion MotionMode
    | ToggleMobileNav
    | EscapeMobileNav
    | UpdateQuery String
    | ClearQuery
    | EscapeClearQuery
    | SelectCategory CategoryFilter
    | FocusSettled (Result Dom.Error ())


initialModel : Model
initialModel =
    { theme = ThemeNight
    , motion = MotionStandard
    , mobileNavOpen = False
    , query = ""
    , category = FilterAll
    , lastFocusError = Nothing
    }


init : () -> ( Model, Cmd Msg )
init _ =
    ( initialModel, Cmd.none )



-- UPDATE


update : Msg -> Model -> ( Model, Cmd Msg )
update msg currentModel =
    case msg of
        SelectTheme chosenTheme ->
            ( { currentModel | theme = chosenTheme }, Cmd.none )

        SelectMotion chosenMotion ->
            ( { currentModel | motion = chosenMotion }, Cmd.none )

        ToggleMobileNav ->
            ( { currentModel | mobileNavOpen = not currentModel.mobileNavOpen }, Cmd.none )

        EscapeMobileNav ->
            if currentModel.mobileNavOpen then
                ( { currentModel | mobileNavOpen = False }
                , Task.attempt FocusSettled (Dom.focus "wl-search-nav-toggle")
                )

            else
                ( currentModel, Cmd.none )

        UpdateQuery nextQuery ->
            ( { currentModel | query = nextQuery }, Cmd.none )

        ClearQuery ->
            ( { currentModel | query = "" }
            , Task.attempt FocusSettled (Dom.focus "query")
            )

        EscapeClearQuery ->
            if String.trim currentModel.query /= "" then
                ( { currentModel | query = "" }
                , Task.attempt FocusSettled (Dom.focus "query")
                )

            else
                ( currentModel, Cmd.none )

        SelectCategory chosenCategory ->
            ( { currentModel | category = chosenCategory }, Cmd.none )

        FocusSettled outcome ->
            case outcome of
                Ok () ->
                    ( { currentModel | lastFocusError = Nothing }, Cmd.none )

                Err (Dom.NotFound missingId) ->
                    ( { currentModel | lastFocusError = Just missingId }, Cmd.none )



-- IME-SAFE KEYBOARD DECODERS


decodeMissingDefaultField : String -> Decode.Decoder a -> a -> Decode.Decoder a
decodeMissingDefaultField fieldName valueDecoder defaultValue =
    Decode.maybe (Decode.field fieldName Decode.value)
        |> Decode.andThen
            (\maybeRaw ->
                case maybeRaw of
                    Nothing ->
                        Decode.succeed defaultValue

                    Just rawVal ->
                        case Decode.decodeValue valueDecoder rawVal of
                            Ok typed ->
                                Decode.succeed typed

                            Err _ ->
                                Decode.fail ("invalid field " ++ fieldName)
            )


decodeNonComposingEscape : Decode.Decoder ()
decodeNonComposingEscape =
    Decode.map3
        (\keyName composing code -> ( keyName, composing, code ))
        (Decode.field "key" Decode.string)
        (decodeMissingDefaultField "isComposing" Decode.bool False)
        (decodeMissingDefaultField "keyCode" Decode.int 0)
        |> Decode.andThen
            (\( keyName, composing, code ) ->
                if composing || code == 229 || keyName /= "Escape" then
                    Decode.fail "not non-composing Escape"

                else
                    Decode.succeed ()
            )


decodeEscapeMenu : Decode.Decoder Msg
decodeEscapeMenu =
    Decode.map (\_ -> EscapeMobileNav) decodeNonComposingEscape


decodeEscapeClear : Model -> Decode.Decoder ( Msg, Bool )
decodeEscapeClear currentModel =
    if String.trim currentModel.query == "" then
        Decode.fail "empty search query"

    else
        Decode.map (\_ -> ( EscapeClearQuery, True )) decodeNonComposingEscape



-- ROUTE FILTERING


filteredRoutes : String -> CategoryFilter -> List RouteEntry
filteredRoutes rawQuery chosenCategory =
    let
        needle =
            String.toLower (String.trim rawQuery)

        tokens =
            String.words needle

        matchesCategory entry =
            case chosenCategory of
                FilterAll ->
                    True

                _ ->
                    entry.category == chosenCategory

        haystack entry =
            String.toLower
                (String.join " "
                    ([ entry.title
                     , entry.section
                     , entry.summary
                     , badgeLabel entry.badge
                     ]
                        ++ entry.keywords
                    )
                )

        matchesTokens entry =
            let
                blob =
                    haystack entry
            in
            List.all (\tok -> String.contains tok blob) tokens
    in
    allRoutes
        |> List.filter matchesCategory
        |> List.filter matchesTokens



-- VIEW (CSS-FREE ELM: USES EXISTING site.css + landing.css CLASSES)


view : Model -> Html Msg
view currentModel =
    let
        matches =
            filteredRoutes currentModel.query currentModel.category
    in
    Html.div
        [ Attr.class "wl-home-root"
        , Attr.attribute "data-theme" (themeSlug currentModel.theme)
        , Attr.attribute "data-motion" (motionSlug currentModel.motion)
        , Attr.attribute "data-nav-open" (boolToken currentModel.mobileNavOpen)
        ]
        (sharedHeadLinks
            ++ [ Html.a [ Attr.class "wl-doc-skip", Attr.href "#main" ] [ Html.text "Skip to content" ]
               , viewHeader currentModel
               , Html.div [ Attr.class "wl-doc-layout" ]
                    [ viewSideNav
                    , Html.main_
                        [ Attr.id "main"
                        , Attr.tabindex -1
                        ]
                        [ Html.nav [ Attr.attribute "aria-label" "Breadcrumb" ]
                            [ Html.a [ Attr.href "../index.html" ] [ Html.text "Home" ]
                            , Html.text " / Search"
                            ]
                        , Html.article []
                            [ Html.h1 [] [ Html.text "Search" ]
                            , Html.p [ Attr.class "wl-doc-lead" ]
                                [ Html.text "Find design foundations, 19 shell components, Elm and Haskell runtime architecture, simulated browser scenarios, and live Omarchy --application-only beta status." ]
                            , viewSearchSection currentModel matches
                            , viewBrowseSection
                            ]
                        ]
                    , Html.aside [ Attr.class "wl-doc-toc" ]
                        [ Html.nav [ Attr.attribute "aria-label" "On this page" ]
                            [ Html.a [ Attr.href "#search" ] [ Html.text "Search" ]
                            , Html.a [ Attr.href "#browse" ] [ Html.text "Browse all sections" ]
                            ]
                        ]
                    ]
               , viewFooter
               ]
        )


sharedHeadLinks : List (Html msg)
sharedHeadLinks =
    let
        stylesheet path =
            Html.node "link"
                [ Attr.attribute "rel" "stylesheet"
                , Attr.href path
                ]
                []
    in
    [ Html.node "link"
        [ Attr.attribute "rel" "icon"
        , Attr.href "../assets/brand/identity/warlock-mark-mono.svg"
        ]
        []
    , stylesheet "../assets/shared/layers.css"
    , stylesheet "../assets/shared/tokens.css"
    , stylesheet "../assets/shared/fonts.css"
    , stylesheet "../assets/shared/site.css"
    , stylesheet "../assets/shared/glyphs.css"
    , stylesheet "../assets/shared/landing.css"
    , stylesheet "../assets/shared/effects.css"
    ]


viewHeader : Model -> Html Msg
viewHeader currentModel =
    Html.header
        [ Attr.class "wl-doc-header wl-home-header"
        , Events.on "keydown" decodeEscapeMenu
        ]
        [ Html.div [ Attr.class "wl-home-bar" ]
            [ Html.a
                [ Attr.class "wl-doc-brand"
                , Attr.href "../index.html"
                , Attr.attribute "aria-label" "Warlock home"
                ]
                [ Html.img
                    [ Attr.src "../assets/brand/identity/warlock-mark.svg"
                    , Attr.alt ""
                    , Attr.width 32
                    , Attr.height 32
                    ]
                    []
                , Html.span [] [ Html.text "WARLOCK" ]
                ]
            , Html.div [ Attr.class "wl-home-mobile-actions" ]
                [ Html.a
                    [ Attr.class "wl-doc-button wl-doc-button-primary wl-home-mobile-cta"
                    , Attr.href "../test-drive/index.html"
                    ]
                    [ Html.text "Test drive (sim)" ]
                , Html.button
                    [ Attr.id "wl-search-nav-toggle"
                    , Attr.type_ "button"
                    , Attr.class "wl-doc-button wl-home-nav-toggle"
                    , Attr.attribute "aria-expanded" (boolToken currentModel.mobileNavOpen)
                    , Attr.attribute "aria-controls" "wl-search-nav-drawer"
                    , Events.onClick ToggleMobileNav
                    ]
                    [ Html.text
                        (if currentModel.mobileNavOpen then
                            "Close menu"

                         else
                            "Menu"
                        )
                    ]
                ]
            ]
        , Html.div
            [ Attr.id "wl-search-nav-drawer"
            , Attr.class "wl-home-drawer"
            ]
            [ Html.nav
                [ Attr.class "wl-home-nav"
                , Attr.attribute "aria-label" "Primary"
                ]
                [ Html.a [ Attr.href "../index.html" ] [ Html.text "Home" ]
                , Html.a [ Attr.href "../test-drive/index.html" ] [ Html.text "Test drive (sim)" ]
                , Html.a [ Attr.href "../foundations/index.html" ] [ Html.text "Foundations" ]
                , Html.a [ Attr.href "../styles/index.html" ] [ Html.text "Styles" ]
                , Html.a [ Attr.href "../components/index.html" ] [ Html.text "Components" ]
                , Html.a [ Attr.href "../architecture/index.html" ] [ Html.text "Architecture" ]
                , Html.a [ Attr.href "../get-started/index.html" ] [ Html.text "Get started" ]
                , Html.a [ Attr.href "./index.html", Attr.attribute "aria-current" "page" ] [ Html.text "Search" ]
                ]
            , Html.div [ Attr.class "wl-home-toolbar" ]
                [ Html.div
                    [ Attr.class "wl-home-seg"
                    , Attr.attribute "role" "group"
                    , Attr.attribute "aria-label" "Page appearance theme"
                    ]
                    [ viewThemeBtn currentModel.theme ThemeNight "Night"
                    , viewThemeBtn currentModel.theme ThemeDawn "Dawn"
                    , viewThemeBtn currentModel.theme ThemeHighContrast "High contrast"
                    ]
                , Html.div
                    [ Attr.class "wl-home-seg"
                    , Attr.attribute "role" "group"
                    , Attr.attribute "aria-label" "Motion preference"
                    ]
                    [ viewMotionBtn currentModel.motion MotionStandard "Standard motion"
                    , viewMotionBtn currentModel.motion MotionReduced "Reduced motion"
                    ]
                ]
            ]
        ]


viewThemeBtn : AppearanceTheme -> AppearanceTheme -> String -> Html Msg
viewThemeBtn activeTheme targetTheme labelText =
    Html.button
        [ Attr.type_ "button"
        , Attr.class "wl-home-seg-btn"
        , Attr.attribute "aria-pressed" (boolToken (activeTheme == targetTheme))
        , Events.onClick (SelectTheme targetTheme)
        ]
        [ Html.text labelText ]


viewMotionBtn : MotionMode -> MotionMode -> String -> Html Msg
viewMotionBtn activeMotion targetMotion labelText =
    Html.button
        [ Attr.type_ "button"
        , Attr.class "wl-home-seg-btn"
        , Attr.attribute "aria-pressed" (boolToken (activeMotion == targetMotion))
        , Events.onClick (SelectMotion targetMotion)
        ]
        [ Html.text labelText ]


viewSideNav : Html msg
viewSideNav =
    Html.nav
        [ Attr.id "site-nav"
        , Attr.class "wl-doc-nav"
        , Attr.attribute "aria-label" "Section directory"
        ]
        (List.map
            (\entry ->
                Html.a
                    (if entry.path == "search/index.html" then
                        [ Attr.href ("../" ++ entry.path)
                        , Attr.attribute "aria-current" "page"
                        ]

                     else
                        [ Attr.href ("../" ++ entry.path) ]
                    )
                    [ Html.text entry.title ]
            )
            allRoutes
        )


viewSearchSection : Model -> List RouteEntry -> Html Msg
viewSearchSection currentModel matches =
    let
        trimmed =
            String.trim currentModel.query

        hasFilter =
            trimmed /= "" || currentModel.category /= FilterAll

        statusMessage =
            if not hasFilter then
                "Enter keywords (for example: beta walkthrough, application-only, Haskell diagnostics, tokens, snap) or filter by category."

            else if List.isEmpty matches then
                "0 matching guides for current filter. Clear search or browse all 42 sections below."

            else
                String.fromInt (List.length matches)
                    ++ (if List.length matches == 1 then
                            " matching guide"

                        else
                            " matching guides"
                       )
    in
    Html.section [ Attr.id "search" ]
        [ Html.label [ Attr.for "query" ] [ Html.text "Search the guide" ]
        , Html.div [ Attr.class "wl-home-toolbar" ]
            [ Html.input
                [ Attr.id "query"
                , Attr.attribute "data-search" ""
                , Attr.type_ "search"
                , Attr.attribute "autocomplete" "off"
                , Attr.placeholder "Search beta walkthrough, Elm, Haskell, components, tokens…"
                , Attr.value currentModel.query
                , Events.onInput UpdateQuery
                , Events.preventDefaultOn "keydown" (decodeEscapeClear currentModel)
                ]
                []
            , if trimmed /= "" then
                Html.button
                    [ Attr.type_ "button"
                    , Attr.class "wl-doc-button"
                    , Events.onClick ClearQuery
                    ]
                    [ Html.text "Clear query" ]

              else
                Html.text ""
            ]
        , Html.div
            [ Attr.class "wl-home-seg"
            , Attr.attribute "role" "group"
            , Attr.attribute "aria-label" "Filter search scope"
            ]
            [ viewCategoryChip currentModel.category FilterAll "All (42)"
            , viewCategoryChip currentModel.category FilterDesktopAndHome "Home & Desktop (3)"
            , viewCategoryChip currentModel.category FilterArchitectureAndStart "Architecture & Start (4)"
            , viewCategoryChip currentModel.category FilterFoundationsAndStyles "Foundations & Styles (14)"
            , viewCategoryChip currentModel.category FilterComponents "Components (20)"
            , viewCategoryChip currentModel.category FilterReference "Reference (1)"
            ]
        , Html.p
            [ Attr.attribute "data-search-status" ""
            , Attr.attribute "role" "status"
            , Attr.attribute "aria-live" "polite"
            ]
            [ Html.text statusMessage ]
        , Html.div
            [ Attr.attribute "data-search-results" ""
            , Attr.class "wl-doc-stack"
            ]
            (if not hasFilter then
                []

             else
                viewGroupedMatches matches
            )
        ]


viewCategoryChip : CategoryFilter -> CategoryFilter -> String -> Html Msg
viewCategoryChip activeFilter targetFilter labelText =
    Html.button
        [ Attr.type_ "button"
        , Attr.class "wl-home-seg-btn"
        , Attr.attribute "aria-pressed" (boolToken (activeFilter == targetFilter))
        , Events.onClick (SelectCategory targetFilter)
        ]
        [ Html.text labelText ]


viewGroupedMatches : List RouteEntry -> List (Html msg)
viewGroupedMatches matches =
    let
        sectionOrder =
            [ "Home"
            , "Desktop"
            , "Architecture"
            , "Get started"
            , "Foundations"
            , "Styles"
            , "Components"
            , "Reference"
            ]

        renderSection secName =
            let
                secItems =
                    List.filter (\r -> r.section == secName) matches
            in
            if List.isEmpty secItems then
                Nothing

            else
                Just
                    (Html.section []
                        [ Html.h3 [] [ Html.text secName ]
                        , Html.ul []
                            (List.map
                                (\item ->
                                    Html.li []
                                        [ Html.a [ Attr.href ("../" ++ item.path) ] [ Html.text item.title ]
                                        , Html.text (" — [" ++ badgeLabel item.badge ++ "] " ++ item.summary)
                                        ]
                                )
                                secItems
                            )
                        ]
                    )
    in
    List.filterMap renderSection sectionOrder


viewBrowseSection : Html msg
viewBrowseSection =
    let
        browseGroups =
            [ ( "Home", [ "index.html", "search/index.html" ] )
            , ( "Desktop", [ "test-drive/index.html" ] )
            , ( "Foundations"
              , [ "foundations/index.html"
                , "foundations/principles/index.html"
                , "foundations/accessibility/index.html"
                , "foundations/layered-windows/index.html"
                , "foundations/interaction/index.html"
                ]
              )
            , ( "Styles"
              , [ "styles/index.html"
                , "styles/color/index.html"
                , "styles/typography/index.html"
                , "styles/shape/index.html"
                , "styles/elevation-glow/index.html"
                , "styles/motion/index.html"
                , "styles/effects/index.html"
                , "styles/css-architecture/index.html"
                , "styles/iconography/index.html"
                ]
              )
            , ( "Components"
              , [ "components/index.html"
                , "components/taskbar/index.html"
                , "components/application-groups/index.html"
                , "components/launcher/index.html"
                , "components/window-picker/index.html"
                , "components/window-switcher/index.html"
                , "components/task-view/index.html"
                , "components/workspace-transfer/index.html"
                , "components/previews/index.html"
                , "components/popup-surfaces/index.html"
                , "components/window-menu/index.html"
                , "components/snap-layouts/index.html"
                , "components/application-actions/index.html"
                , "components/notifications/index.html"
                , "components/appearance-settings/index.html"
                , "components/motion-shortcuts-help/index.html"
                , "components/files/index.html"
                , "components/system-menu/index.html"
                , "components/dialogs/index.html"
                , "components/status-recovery/index.html"
                ]
              )
            , ( "Architecture", [ "architecture/index.html" ] )
            , ( "Get started"
              , [ "get-started/index.html"
                , "get-started/contributing/index.html"
                , "get-started/licenses/index.html"
                ]
              )
            , ( "Reference", [ "reference/catalog/v6/index.html" ] )
            ]

        findByPath targetPath =
            List.head (List.filter (\r -> r.path == targetPath) allRoutes)
    in
    Html.section [ Attr.id "browse" ]
        ([ Html.h2 [] [ Html.text "Browse all sections" ]
         , Html.p [] [ Html.text "Every page in the 42-route Warlock site registry is directly reachable below." ]
         ]
            ++ List.map
                (\( groupTitle, paths ) ->
                    Html.section []
                        [ Html.h3 [] [ Html.text groupTitle ]
                        , Html.ul []
                            (List.filterMap
                                (\p ->
                                    Maybe.map
                                        (\entry ->
                                            Html.li []
                                                [ Html.a [ Attr.href ("../" ++ entry.path) ] [ Html.text entry.title ] ]
                                        )
                                        (findByPath p)
                                )
                                paths
                            )
                        ]
                )
                browseGroups
        )


viewFooter : Html msg
viewFooter =
    Html.footer [ Attr.class "wl-doc-footer" ]
        [ Html.p [] [ Html.text "Warlock. Crafted for flow · Elm + Haskell." ]
        , Html.a [ Attr.href "../get-started/contributing/index.html" ] [ Html.text "Contribute" ]
        , Html.a [ Attr.href "../get-started/licenses/index.html" ] [ Html.text "Licenses and attribution" ]
        , Html.p [] [ Html.text "Apache License 2.0" ]
        ]



-- HELPERS & COMPLETE 42-ROUTE REGISTRY


themeSlug : AppearanceTheme -> String
themeSlug chosenTheme =
    case chosenTheme of
        ThemeNight ->
            "night"

        ThemeDawn ->
            "dawn"

        ThemeHighContrast ->
            "high-contrast"


motionSlug : MotionMode -> String
motionSlug chosenMotion =
    case chosenMotion of
        MotionStandard ->
            "standard"

        MotionReduced ->
            "reduced"


boolToken : Bool -> String
boolToken flag =
    if flag then
        "true"

    else
        "false"


badgeLabel : ScopeBadge -> String
badgeLabel badge =
    case badge of
        BadgeBetaWalkthrough ->
            "Elm + Haskell beta walkthrough"

        BadgeSimulatedStage ->
            "Simulated browser stage"

        BadgeElmHaskellRuntime ->
            "Elm + Haskell runtime & prototype map"

        BadgeTokensAndDocsOnly ->
            "Design tokens & notices only (no desktop binary)"

        BadgeComponentGuide ->
            "Component spec & specimen"

        BadgeDesignFoundation ->
            "Lacquer design foundation"

        BadgeFrozenArchive ->
            "Frozen v6 catalog baseline"


allRoutes : List RouteEntry
allRoutes =
    [ { title = "Home"
      , path = "index.html"
      , section = "Home"
      , category = FilterDesktopAndHome
      , badge = BadgeBetaWalkthrough
      , summary = "Interactive 4-step beta walkthrough, MVP scope matrix (18/242 EARS, 42/417 scenarios), and CSS-free Elm workbench."
      , keywords = [ "Warlock desktop", "beta", "walkthrough", "mvp", "omarchy", "application-only", "evidence", "elm", "haskell", "foot", "footz" ]
      }
    , { title = "Test drive"
      , path = "test-drive/index.html"
      , section = "Desktop"
      , category = FilterDesktopAndHome
      , badge = BadgeSimulatedStage
      , summary = "Compiled Elm shell across 16 simulated Omarchy desktop scenarios and guided tour; client windows are fixtures."
      , keywords = [ "desktop", "simulation", "simulated", "browser", "tour", "scenarios", "fixtures" ]
      }
    , { title = "Search"
      , path = "search/index.html"
      , section = "Home"
      , category = FilterDesktopAndHome
      , badge = BadgeDesignFoundation
      , summary = "Instant Elm search across all 42 site routes, components, and runtime status guides."
      , keywords = [ "search", "find", "directory", "routes" ]
      }
    , { title = "Architecture"
      , path = "architecture/index.html"
      , section = "Architecture"
      , category = FilterArchitectureAndStart
      , badge = BadgeElmHaskellRuntime
      , summary = "Production Elm + Haskell ownership (closed Backend failure/retirement diagnostics, ELM-DEL-017 partial) and 35-node prototype explorer."
      , keywords = [ "Elm", "Haskell", "flows", "backend", "diagnostics", "process-custody", "held-document", "elf-observation", "architecture" ]
      }
    , { title = "Foundations"
      , path = "foundations/index.html"
      , section = "Foundations"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Core Lacquer design principles, accessibility commitments, layered windows, and input rules."
      , keywords = [ "foundations", "lacquer", "design" ]
      }
    , { title = "Principles"
      , path = "foundations/principles/index.html"
      , section = "Foundations"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Calm authority, explicit state transitions, and honest separation of intent from native observation."
      , keywords = [ "principles", "honesty", "calm" ]
      }
    , { title = "Accessibility"
      , path = "foundations/accessibility/index.html"
      , section = "Foundations"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Keyboard navigation, high-contrast theme, reduced motion, IME composition safety, and ARIA announcements."
      , keywords = [ "accessibility", "keyboard", "contrast", "high-contrast", "reduced-motion", "ime", "aria" ]
      }
    , { title = "Layered windows"
      , path = "foundations/layered-windows/index.html"
      , section = "Foundations"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Spatial hierarchy across desktop workspace, output taskbars, shared popups, and modal confirmations."
      , keywords = [ "layered", "windows", "surfaces", "z-order" ]
      }
    , { title = "Interaction"
      , path = "foundations/interaction/index.html"
      , section = "Foundations"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Captured press-and-release activation, pending vs observed receipts, and focus custody."
      , keywords = [ "interaction", "gestures", "focus", "activation" ]
      }
    , { title = "Styles"
      , path = "styles/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Night, Dawn, and High-contrast palettes, typography, shape, elevation, motion, and CSS cascade layers."
      , keywords = [ "styles", "themes", "night", "dawn", "high-contrast" ]
      }
    , { title = "Color"
      , path = "styles/color/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Semantic color tokens and verified contrast across Night, Dawn, and High-contrast themes."
      , keywords = [ "color", "palette", "contrast", "tokens" ]
      }
    , { title = "Typography"
      , path = "styles/typography/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Inter, Space Grotesk, and JetBrains Mono type scale and text-scaling rules."
      , keywords = [ "typography", "fonts", "inter", "space grotesk", "jetbrains mono" ]
      }
    , { title = "Shape"
      , path = "styles/shape/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Corner radii, border hairlines, and hit-target spacing tokens."
      , keywords = [ "shape", "radius", "geometry" ]
      }
    , { title = "Elevation and glow"
      , path = "styles/elevation-glow/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Lacquer surface depth, focus rings, and restrained active-surface illumination."
      , keywords = [ "elevation", "glow", "shadows", "focus" ]
      }
    , { title = "Motion"
      , path = "styles/motion/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Choreographed transitions and immediate reduced-motion behavior."
      , keywords = [ "motion", "animation", "reduced-motion" ]
      }
    , { title = "Effects"
      , path = "styles/effects/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Backdrop translucency and opaque reduced-transparency fallbacks."
      , keywords = [ "effects", "translucency", "backdrop" ]
      }
    , { title = "CSS architecture"
      , path = "styles/css-architecture/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Explicit @layer cascade order, semantic custom properties, and CSS-free Elm view separation."
      , keywords = [ "css", "architecture", "layers", "tokens" ]
      }
    , { title = "Iconography"
      , path = "styles/iconography/index.html"
      , section = "Styles"
      , category = FilterFoundationsAndStyles
      , badge = BadgeDesignFoundation
      , summary = "Crisp symbolic glyphs and fallback application marks."
      , keywords = [ "iconography", "icons", "glyphs" ]
      }
    , { title = "Components"
      , path = "components/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Index of all 19 Warlock desktop shell component specifications and interactive specimens."
      , keywords = [ "components", "catalog", "specimens" ]
      }
    , { title = "Taskbar"
      , path = "components/taskbar/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Per-output top bar hosting Applications, Task View, Switcher, pinned groups, and utility openers."
      , keywords = [ "taskbar", "bar", "panel" ]
      }
    , { title = "Application groups"
      , path = "components/application-groups/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Grouped running windows and pinned launchers with focus and instance cues."
      , keywords = [ "application", "groups", "pins" ]
      }
    , { title = "Launcher"
      , path = "components/launcher/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Applications search, IME-safe query filtering, no-match feedback, and Refresh retention."
      , keywords = [ "launcher", "applications", "search", "refresh", "foot", "footz" ]
      }
    , { title = "Window picker"
      , path = "components/window-picker/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Multi-window family chooser with preview cards and keyboard selection."
      , keywords = [ "window", "picker", "family" ]
      }
    , { title = "Window switcher"
      , path = "components/window-switcher/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Activation-ordered window cycling and candidate inspection."
      , keywords = [ "window", "switcher", "alt-tab" ]
      }
    , { title = "Task View"
      , path = "components/task-view/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Workspace overview, empty-workspace navigation, and window filtering."
      , keywords = [ "task", "view", "workspaces", "overview" ]
      }
    , { title = "Workspace transfer"
      , path = "components/workspace-transfer/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Checked window movement across numbered workspaces."
      , keywords = [ "workspace", "transfer", "move" ]
      }
    , { title = "Previews"
      , path = "components/previews/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Grant-scoped live window thumbnails and explicit icon fallbacks."
      , keywords = [ "previews", "thumbnails", "fallback" ]
      }
    , { title = "Popup surfaces"
      , path = "components/popup-surfaces/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Shared popup container ownership, dismissal, and focus return."
      , keywords = [ "popup", "surfaces", "flyout" ]
      }
    , { title = "Window menu"
      , path = "components/window-menu/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Context actions for focus, minimize, maximize, float, and close."
      , keywords = [ "window", "menu", "context" ]
      }
    , { title = "Snap layouts"
      , path = "components/snap-layouts/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Work-area placement regions for eligible floating windows."
      , keywords = [ "snap", "layouts", "tiling", "floating" ]
      }
    , { title = "Application actions"
      , path = "components/application-actions/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Jump-list desktop actions, new-instance commands, and recent items."
      , keywords = [ "application", "actions", "jump", "recent" ]
      }
    , { title = "Notifications"
      , path = "components/notifications/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Bounded notification history, producer identity, and polite announcements."
      , keywords = [ "notifications", "history", "alerts" ]
      }
    , { title = "Appearance settings"
      , path = "components/appearance-settings/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Draft-until-saved theme, text scale, effects, and transparency controls."
      , keywords = [ "appearance", "settings", "theme", "scale" ]
      }
    , { title = "Motion, shortcuts and help"
      , path = "components/motion-shortcuts-help/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Motion preference drafts, shortcut conflict handling, and inline keyboard help."
      , keywords = [ "motion", "shortcuts", "help", "chords" ]
      }
    , { title = "Files"
      , path = "components/files/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Omarchy Files quick-navigation panel, collections, and status refresh."
      , keywords = [ "files", "explorer", "folders" ]
      }
    , { title = "System menu"
      , path = "components/system-menu/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Audio volume/mute, NetworkManager state, and session power controls."
      , keywords = [ "system", "menu", "audio", "network", "power" ]
      }
    , { title = "Dialogs"
      , path = "components/dialogs/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Inline session operation confirmations and explicit cancel paths."
      , keywords = [ "dialogs", "confirmation", "cancel" ]
      }
    , { title = "Status recovery"
      , path = "components/status-recovery/index.html"
      , section = "Components"
      , category = FilterComponents
      , badge = BadgeComponentGuide
      , summary = "Truthful pending, refused, unknown, and read-only failure recovery states."
      , keywords = [ "status", "recovery", "refused", "unknown", "readonly" ]
      }
    , { title = "Get started"
      , path = "get-started/index.html"
      , section = "Get started"
      , category = FilterArchitectureAndStart
      , badge = BadgeTokensAndDocsOnly
      , summary = "Enter the simulated desktop, check live Omarchy --application-only beta scope, or download CSS/JSON tokens and fonts (no desktop binary yet)."
      , keywords = [ "get started", "download", "tokens", "fonts", "beta", "omarchy", "mvp", "install", "css" ]
      }
    , { title = "Contributing"
      , path = "get-started/contributing/index.html"
      , section = "Get started"
      , category = FilterArchitectureAndStart
      , badge = BadgeTokensAndDocsOnly
      , summary = "Source-bound verification workflow separating native evidence, CPU suites, and browser fixtures."
      , keywords = [ "contributing", "evidence", "source", "verification" ]
      }
    , { title = "Licenses"
      , path = "get-started/licenses/index.html"
      , section = "Get started"
      , category = FilterArchitectureAndStart
      , badge = BadgeTokensAndDocsOnly
      , summary = "Apache-2.0 license and bundled Inter, Space Grotesk, and JetBrains Mono font notices."
      , keywords = [ "licenses", "apache", "fonts", "attribution" ]
      }
    , { title = "Frozen v6 catalog"
      , path = "reference/catalog/v6/index.html"
      , section = "Reference"
      , category = FilterReference
      , badge = BadgeFrozenArchive
      , summary = "Immutable five-reviewer consensus design catalog specimen archive."
      , keywords = [ "catalog", "archive", "v6", "frozen" ]
      }
    ]
