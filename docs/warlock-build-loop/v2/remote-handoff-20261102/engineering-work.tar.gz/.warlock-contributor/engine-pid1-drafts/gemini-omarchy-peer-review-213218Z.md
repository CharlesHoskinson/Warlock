# Source-Bound Peer Review (`20261101T213218Z`)

- **Reviewer**: `gemini-omarchy`
- **Canonical `HEAD`**: `112cde9c21b92e8cb39a404ffee1d52e9d612a6f`
- **Execution Status**: Source-only inspection (`git apply --check` / `patch --dry-run` only; zero worker compiler, model, Node, VM, or native runs).

## 1. `terra-q-lifetime` Persistent Scope Bridge v2 (`terra-q-lifetime-persistent-scope-bridge-v2.patch`, `sha256:5890b91382606b0af648518e35dec9698ff016d0b985db03c4d95ea203d36adf`)

### Verified Strengths
- **Resolves Prior v1 Startup-Deadline HOLD (`6f87c545`)**: `withScopedPersistentOwnedPeer` now delegates initial process observation to `Warlock.Capture.Process.Persistent.observeLiveStartup live` (`ScopedPeer.hs` L50-54), eliminating any caller-supplied `AdmissionDeadline` parameter at scope construction and binding startup identity capture to the exact `startDl` sealed inside `withPersistentOwner`.
- **Single-Gate Scope Lifecycle & Production Masking Preserved**: `withScopedObserver` (`ScopedPeer.hs` L55-74) and `runApprovedUsing` (`CurrentSessions.hs` L194-206) share the unchanged `mask`/`restore`/`finally (retireScope scope >> pure ())` discipline, single-active-admission `ScopeLive 0 -> ScopeLive 1` state machine, thread affinity (`WrongThread`), real UID match (`ForeignUser`), monotonic epoch match (`ForeignSession`), executable `(deviceID, fileID)` match, and inherited `fd0` identity check.
- **Bounded Per-Frame Observation Without Clock Renewal**: `guardForPersistentScope :: Scope -> FrameDeadline -> CredentialGuard PeerRefusal` (`CredentialScopeGuard.hs` L226-227) reuses the single `Channel`-minted opaque `FrameDeadline` across both `before` and `after` `/proc` observations in `current` (`ScopedPeer.hs` L138-147), refusing `Nothing` on `PersistentObserver` with `Left SessionClosed` (`L36`).
- **Compatible with Custody Freeze v2 (`0a3e953d`)**: Imports `(LiveSession, observeLiveSession, observeLiveStartup)` from `Warlock.Capture.Process.Persistent`, matching `gemini-omarchy-persistent-custody-freeze-v2-213218Z.patch` (`sha256:0a3e953d366bce733c203fa9486667dabf30108e36100d168950ef2a8d4ccb0c`) byte-for-byte.

### Remaining Integration Boundary (Non-Blocking for Scope Bridge Layer)
- Requires `terra-q-lifetime-frame-guard-prereq.patch` (`sha256:a93d0106ffcd46d8d7f4eb786b7732e7900627a7179cc2fb938835d8218a0213`) applied first so `Warlock.Transport.Channel` exports `(FrameDeadline, frameDeadlineNs)`.
- Does not yet wire `Warlock.Bootstrap.Aggregate` (next callsite order #3 in `gemini-omarchy-persistent-lifetime-manifest-213218Z.json`).

## 2. `terra-engine` Non-Consuming Idle Wait Helper (`terra-engine-persistent-idle-wait.hs`, `sha256:7e172af80f1203ac073b1ba086b8b06c0857c70b61d821cb7881aa6d8856f399`)

### Verified Strengths & Interface Alignment
- Uses `Socket.withFdSocket` + `bracket (threadWaitReadSTM (fromIntegral fd)) snd` + `atomically ((stopReady >> pure StopObserved) \`orElse\` (readable >> pure Readable))` with zero detached watcher threads, zero byte consumption, and stop-priority fairness.
- Paired with `liveSessionStopRequestedSTM :: LiveSession -> STM ()` added in `gemini-omarchy-persistent-custody-freeze-v2-213218Z.patch` (`0a3e953d`) using `GHC.Conc` from `base` (zero new Cabal package dependencies in `process-custody.cabal`; note `terra-engine-persistent-idle-wait.hs` currently imports `Control.Concurrent.STM` and can switch to `GHC.Conc (STM, atomically, orElse, threadWaitReadSTM)` if `protocol.cabal` avoids adding `stm`).
- **Explicit Boundary**: `liveSessionStopRequestedSTM` is a monotonic owner stop/retirement latch (`requestSessionStop` / `retireLive`), not an async `SIGCHLD`/`pidfd` child-exit monitor; on private `AF_UNIX` socketpairs without descriptor inheritance, direct child exit closes the peer fd and wakes `threadWaitReadSTM` with `Readable` (EOF verified by `Channel`'s credential reader).

## 3. `terra-q-http` Complete-Oracle Coordination (`tea-contract-cases.cjs`, preimage `ab9d3f43`)

- Verified `gemini-omarchy-tea-contract-cases-app-batch-oracles-213218Z.patch` (`sha256:73f8d437a0fc97864aa378943363fc6c033344461667698392b98625f870fbc2`) updates complete `DesktopPolicy.Model` / `batches` literals at ONLY the 3 pure-application terminal-reply locations (`catalogSuccessChanges` L314, `buildPinCases` L624-742, `buildLaunchDeadlineCases` L1094-1128), keeping `Batch`'s 9-field record unchanged and avoiding all overlap with `terra-q-http`'s UI005/Motion hunks (`terra-q-http-ui005-malformed-retirement.patch`).
