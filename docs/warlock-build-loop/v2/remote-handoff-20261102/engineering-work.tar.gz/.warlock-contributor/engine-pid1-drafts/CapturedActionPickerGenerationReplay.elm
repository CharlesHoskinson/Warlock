port module CapturedActionPickerGenerationReplay exposing (main)

{-| Source-only, synthetic Elm fixture. Actual Surface.resolve and Desktop
updates are used; fake publications and projection responses are not native
credentials or evidence of owner-issued leases. Root must integrate this file,
assert every check, and run the protected profile. -}

import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Shell
import Surface
import TaskbarShell
import UInt64

port outgoing : E.Value -> Cmd msg

counter text = D.decodeValue UInt64.decoder (E.string text) |> Result.withDefault UInt64.zero
bound = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]
native raw model = NativePointerFixture.incoming raw model |> Tuple.first
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",bound)]
window id = E.object [("incarnation",E.string id),("label",E.string ("Document "++id)),("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]
projection request = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",bound),("requestId",E.string request),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")]),("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),("windows",E.list identity [window "1",window "2"])])]
ready = Desktop.initial |> native attached |> native (projection "1")
groupId = "bar:group:" ++ (TaskbarShell.groups ready.windows |> List.head |> Maybe.map .key |> Maybe.withDefault "missing")

action publication lease = E.object [("surface",E.string "bar"),("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("publication",E.string publication),("lease",E.string lease),("id",E.string groupId),("trigger",E.string "pointer")]
open publication lease model =
    Surface.resolve (counter publication) (counter lease) (action publication lease) model
        |> Maybe.map (\message -> Desktop.update message model |> Tuple.first)
        |> Maybe.withDefault model

close held model = Desktop.update (Desktop.Window (TaskbarShell.Close held.scope held.generation)) model

readRequest effect =
    case effect of
        Desktop.WindowEffect (Shell.Send raw) ->
            E.encode 0 raw == "{\"protocolVersion\":3,\"kind\":\"projection-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"},\"requestId\":\"3\"}"
        _ -> False

sequence seed =
    let
        first = open (String.fromInt (seed * 2 + 1)) "0" ready
        closed = first.windows.picker |> Maybe.map (\held -> close held first |> Tuple.first) |> Maybe.withDefault first
        refreshed = native (projection "2") closed
        second = open (String.fromInt (seed * 2 + 2)) "1" refreshed
        checks =
            case (first.windows.picker,second.windows.picker) of
                (Just old,Just current) ->
                    let
                        (afterStale,staleEffects) = close old second
                        (afterCurrent,currentEffects) = close current second
                    in
                    [ ("same_scope_new_generation", old.scope == current.scope && old.generation /= current.generation)
                    , ("prior_close_cannot_retire_new_picker", afterStale == second && List.isEmpty staleEffects)
                    , ("current_close_retires_picker", afterCurrent.windows.picker == Nothing)
                    , ("current_close_starts_projection_read", afterCurrent.windows.shell.expected == Just (counter "3") && not (Shell.available afterCurrent.windows.shell) && List.length currentEffects == 1 && List.all readRequest currentEffects)
                    ]
                _ ->
                    [ ("same_scope_new_generation",False)
                    , ("prior_close_cannot_retire_new_picker",False)
                    , ("current_close_retires_picker",False)
                    , ("current_close_starts_projection_read",False)
                    ]
    in
    E.object [("seed",E.int seed),("closed_before_refresh",E.bool (closed.windows.picker == Nothing && closed.windows.shell.expected == Just (counter "2"))),("projection_restores_ready",E.bool (Shell.available refreshed.windows.shell)),("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]

result = E.object [("scope",E.string "Synthetic Elm picker generation; not native authentication"),("sequences",E.list sequence (List.range 1 32))]
main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\message model -> never message,subscriptions=\_ -> Sub.none}
