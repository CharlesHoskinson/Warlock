# Consolidated Persistent-Custody `v12` Stack Guide (`20261102T002904Z`)

## 1. Frozen Artifacts (`.warlock-contributor/engine-pid1-drafts/`)
- **Standalone `v12` patch against canonical `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f`**:
  - `gemini-omarchy-persistent-custody-prereqs-v12-002904Z.patch` (`sha256:7df4cdf0be86efa80b4526f1346f390de0b85185b6b7cf6be85798e0030b97bb`)
- **Incremental delta on top of `v11` (`f661f6eb`) + `946a7f74` + `c9969670` + `aa817b0a`**:
  - `gemini-omarchy-persistent-custody-v11stack-to-v12-delta-002904Z.patch` (`sha256:1a00e32600ae24e41b052573abf41f5852264232a460359551a0c1048d59870b`)
- **Preserved prior immutable variants**:
  - `gemini-omarchy-persistent-custody-prereqs-v11-232706Z.patch` (`sha256:f661f6eb5c92f0e6238921b7c35de0ab57d906a59c669a8d03141b91cab1dca8`) and `v6`–`v10` remain untouched on disk, so all `v11`-pinned QA seam overlays (`fece662c`, `9be29f6f`, `8fecc177`, `27f8df1e`) retain exact preimages.

## 2. What `v12` Consolidates (`held-document` + `process-custody` Only)
1. **Engine synchronous bounded startup borrow** (`c9969670`): `borrowHeldWhile` in `Warlock.Platform.Executable` + `Warlock.Capture.Process.Lease`, releasing active borrow without background orphan threads on startup timeout/stop/cancel.
2. **Security checked unborrowed startup abort** (`946a7f74` + `aa817b0a`): `tryAbortUnborrowed` in `Warlock.Capture.Process.Owner` + non-blocking `abortBeforeBorrow` in `Warlock.Capture.Process.Persistent.Internal` (`#ifdef WARLOCK_OWNER_QA` barrier compiled out of production).
3. **`-Wall -Werror` unused-import fix in `DeadlineStop.hs` line 5**: removes unused `IORef` type constructor (`import Data.IORef (newIORef, readIORef, writeIORef)`) caught by lexer/import audit.
4. **Trusted `ActionBudget` issuer + bounded per-request `LiveFrameBatch` admission** in `Warlock.Capture.Process.Persistent` (keeping 1-shot `enterLiveFrameAction` 100% unchanged):
   ```haskell
   ActionBudget -- opaque (1..30_000_000 us)
   actionBudgetMicros :: Int -> Either ToolError ActionBudget
   actionBudgetMicrosValue :: ActionBudget -> Int
   issueActionDeadline :: ActionBudget -> IO (Either ToolError AdmissionDeadline)

   LiveFrameBatch -- opaque per-frame serial batch capability
   maxLiveFrameBatchActions :: Int -- = 32
   beginLiveFrameBatch :: LiveFrameAdmission -> AdmissionDeadline -> Int -> IO (Either ToolError LiveFrameBatch)
   enterLiveBatchAction :: LiveFrameBatch -> AdmissionDeadline -> IO (Either ToolError a) -> IO (Either LiveOperationFailure a)
   enterLiveBatchBudgetedAction :: LiveFrameBatch -> ActionBudget -> IO (Either ToolError a) -> IO (Either LiveOperationFailure a)
   ```
   - `beginLiveFrameBatch adm frameDl maxActions` validates `0 <= maxActions <= 32`, checks `frameDl` once on frame entry alongside owner stop + synchronous `inScope scope frameDl` child liveness/identity, and transitions `FrameModeUnused -> FrameModeBatch maxActions False False` (mutually exclusive with `enterLiveFrameAction` and any second `beginLiveFrameBatch`).
   - `enterLiveBatchAction` / `enterLiveBatchBudgetedAction` enforces strict serial non-overlap, checks owner stop + fresh `actionDl` + synchronous `inScope scope actionDl` before each request without re-requiring expired `frameDl`, holds `CallbackGate` across each action, and atomically poisons the batch on any pre-dispatch stop/timeout/liveness failure or post-entry `OperationOutcomeUnknown`/exception (closing `witnessPostStopSecondEffect` from `terra-q-origin-frame-requests-001.qnt`).
5. **Deterministic `PersistentControls.hs` section 22** (25 pre-registered `StablePtr`-pinned owners total: 15 quarantined, 10 retired): covers `ActionBudget` bounds, fresh monotonic deadline issuance, `0`-quota presentation commits, mode mutual exclusion, positive 17-action batch (`1` attachment + `16` requests) surviving `frameDl` expiry after admission, 18th-action refusal, escaped batch refusal, sticky `OperationOutcomeUnknown` poison, and stop-between-requests zero-effect refusal.

## 3. Exact `Backend` Handler Wiring Pattern for `terra-portable`
Inside `handler (adm, frame) checked` (where `actionBudget` is fixed by trusted host configuration, e.g. `actionBudgetMicros 2000000`):
```haskell
frameDl <- deadlineFromAbsoluteNs (show (frameDeadlineNs frame)) >>= either (ioError . userError . show) pure
firstAttempt <- if attachmentEnabled
  then atomicModifyIORef' attachmentAttempted (\attempted -> (True, not attempted))
  else pure False
let quota = (if firstAttempt then 1 else 0) + length requests
batch <- beginLiveFrameBatch adm frameDl quota >>= either (ioError . userError . show) pure
when firstAttempt $ do
  attachedOut <- enterLiveBatchBudgetedAction batch actionBudget (Right <$> (construct (D.applicationAttached bound) >>= sendReply))
  either (ioError . userError . show) pure attachedOut
forM_ requests $ \req -> do
  reqOut <- enterLiveBatchBudgetedAction batch actionBudget (Right <$> handle req)
  either (ioError . userError . show) pure reqOut
```

## 4. Verified Zero-Fuzz 4-Package Production Stack Order (`patch -p1 --fuzz=0`, `rc = 0` on `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f`)
1. `gemini-omarchy-persistent-custody-prereqs-v12-002904Z.patch` (`7df4cdf0be86efa8`) — `held-document` + `process-custody`
2. `terra-engine-lexical-ingress-integration.patch` (`74b07921d42d7a9e`) — `protocol`
3. `terra-q-front-context-ingress-001.patch` (`c9fe0c1ac30e5775`) — `protocol`
4. `terra-q-front-owned-ingress-001.patch` (`51f9669976294b69`) — `protocol` (`protocol -> warlock-process-custody`)
5. `terra-portable-persistent-scope-001.patch` (`c55ee1346a16ac0a`) — `runtime` (`ScopedPeer` / `CurrentSessions` / `CredentialScopeGuard`)
6. `terra-portable-socket-context-001.patch` (`262f9403c0b0cd4a`) — `runtime` (`SocketOwnerT`)
7. `terra-portable-owned-pump-002.patch` (`ffaaadeefa0ca92e`) — `runtime` (`runPersistentCredentialPump`)
8. `terra-portable-persistent-bootstrap-002.patch` (`ca1736bc1b4326e2`) — `runtime` (`PersistentBootstrapOwner`)

## 5. Remaining Gaps Before Root Execution & Acceptance
- **Outbound send pin rebase**: `terra-engine-outbound-pin-followup.patch` (`a825f10c`) needs rebase onto `51f96699` (`CredentialIngressT ctx` send pin).
- **Persistent `Backend.hs` callsite**: `terra-portable` rebasing persistent `Backend` entry onto Root diagnostic `Backend.hs` (`641e06dc8326fdf7d4e1be2aaa316d5739fcf161d5854c895c3d800a48450c06`) consuming `PersistentBootstrapOwner` + `v12` `beginLiveFrameBatch` / `enterLiveBatchBudgetedAction`.
- **Isolated QA race suite**: when Root builds the `#ifdef WARLOCK_OWNER_QA` / `WARLOCK_BORROW_QA` component (`fece662c` + `9be29f6f` + `8fecc177` + `27f8df1e`), remove unused `IORef` from `DeadlineStop.hs` line 5 so `-Wall -Werror` passes cleanly, and run under Root-owned child guardian.
- **Evidence & ledger status**: zero compiler/Cabal/Quint/VM/native execution performed by source worker; ledger remains `18/242` whole EARS and `42/417` scenarios (`nativeOperations = []`, `HOSTSTOP2` and historical failures preserved).
