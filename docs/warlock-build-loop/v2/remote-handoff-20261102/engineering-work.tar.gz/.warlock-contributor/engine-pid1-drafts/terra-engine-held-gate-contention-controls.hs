{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY, UNEXECUTED controlled contention fixture. Requires the isolated
-- -DWARLOCK_HELD_TESTING build of held-document, projected v8 owner plus the
-- separate terra-engine-held-gate-contention-seam.patch. Never ship test API.
-- Actual held executable + owner release path; not a native/namespace/provider
-- or original-scenario acceptance test. A real test child/readiness is supplied.
module HeldGateContentionControls (Probe,newProbe,runPositive,runContention) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import Data.List (stripPrefix)
import GHC.Clock (getMonotonicTimeNSec)
import Text.Read (readMaybe)
import System.Timeout (timeout)
import Warlock.Platform.Executable (HeldExecutable, holdHeldGateForTest)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError)
import Warlock.Capture.Process.Bootstrap (OwnerStatus(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), PidfdCustody(..), SessionExit(..),
  newPersistentOwner, persistentStatus, persistentUnderlyingStatus, persistentPidfdCustody,
  persistentHeldNoInput, startBudgetAfter, stopBudgetMicros, withPersistentOwner)
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)

type OwnerResult = Either SomeException (Integer, Either SessionExit ((),SessionExit))
data Probe = Probe
 { ownerRef :: IORef (Maybe PersistentOwner)
 , heldRef :: IORef (Maybe HeldExecutable)
 , holderThread :: IORef (Maybe ThreadId)
 , ownerThread :: IORef (Maybe ThreadId)
 , holderDone :: MVar (Either SomeException ())
 , ownerDone :: MVar OwnerResult
 , used :: IORef Bool
 }
newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
                 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("held-gate: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 3000000 action >>= maybe (ioError (userError (label ++ " timeout; retain Probe/owner"))) pure

-- Caller must retain the supplied owner BEFORE acquiring the resolver-verified
-- HeldExecutable, and retain the exact lease/underlying file on every failure.
-- The Probe and its worker references must remain rooted until explicitly settled
-- by Root. Nothing here sends arbitrary PID signals or closes uncertain handles.
runPositive :: (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runPositive acquireAndRetain args ready = do
 owner <- newPersistentOwner
 held <- acquireAndRetain owner
 selected <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 startup <- startBudgetAfter 3000000 >>= must
 stop <- must (stopBudgetMicros 1000000)
 result <- withPersistentOwner owner selected 4096 startup stop ready (\_ -> pure ())
 state <- persistentStatus owner
 custody <- persistentPidfdCustody owner
 raw <- persistentUnderlyingStatus owner
 check "positive actual selected held owner" (state == PersistentRetired && custody == PidfdClosed && raw == Available &&
  case result of Right ((),LeaderReaped _) -> True; _ -> False)

runContention :: Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runContention probe acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 -- acquireAndRetain itself publishes before its fallible acquisition returns.
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selected <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 startup <- startBudgetAfter 3000000 >>= must
 stop <- must (stopBudgetMicros 1000000)
 startHolder <- newEmptyMVar
 acquired <- newEmptyMVar
 releaseHolder <- newEmptyMVar
 beforeRelease <- newEmptyMVar
 let holder = readMVar startHolder >> holdHeldGateForTest held (putMVar acquired ()) (readMVar releaseHolder)
     hook stage = case stripPrefix "qa-before-held-borrow-release:" stage of
       Nothing -> pure ()
       Just wire -> case readMaybe wire :: Maybe Integer of
        Nothing -> ioError (userError "invalid immutable stop deadline")
        Just deadline -> do
         putMVar startHolder ()
         readMVar acquired
         putMVar beforeRelease deadline
     ownerAction = do
       result <- withPersistentOwnerHook owner selected 4096 startup stop ready (\_ -> pure ()) hook
       completedNs <- getMonotonicTimeNSec
       pure (toInteger completedNs, result)
 -- Install cleanup before either fork; each masked publication records the
 -- worker before interruption. A timed-out completion remains retained, not joined.
 let releaseAndObserve = do
       void (tryPutMVar startHolder ())
       void (tryPutMVar releaseHolder ())
       mh <- readIORef (holderThread probe)
       mo <- readIORef (ownerThread probe)
       case mh of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar (holderDone probe)))
       case mo of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar (ownerDone probe)))
     exercise = do
       _ <- mask_ $ do
        hTid <- forkFinally (restore holder) (putMVar (holderDone probe))
        writeIORef (holderThread probe) (Just hTid)
        pure hTid
       _ <- mask_ $ do
        oTid <- forkFinally (restore ownerAction) (putMVar (ownerDone probe))
        writeIORef (ownerThread probe) (Just oTid)
        pure oTid
       deadline <- within "held gate actually locked" (readMVar beforeRelease)
       -- Since the held gate was acquired only after cleanup began, waiting
       -- longer than the entire one-second StopBudget crosses that exact D.
       observed <- timeout 1200000 (readMVar (ownerDone probe))
       void (tryPutMVar releaseHolder ())
       _ <- within "holder completion" (readMVar (holderDone probe))
       result <- within "owner completion" (readMVar (ownerDone probe))
       state <- persistentStatus owner
       raw <- persistentUnderlyingStatus owner
       let failed = case result of Right (_, Left (ExitUncertain _ _)) -> True; _ -> False
           quarantined = case state of PersistentQuarantined _ -> True; _ -> False
           rawQuarantined = case raw of Quarantined _ -> True; _ -> False
       -- Desired safety property: no unbounded owner wait or late clean success.
       -- Current v8 is expected to block past D and then possibly settle, so
       -- this is deliberately a RED target, not an observed test result.
       check "owner returned by deadline with uncertainty, not late success"
        (case observed of
          Just (Right (completedNs, _)) -> completedNs <= deadline && failed && quarantined && rawQuarantined
          _ -> False)
 restore exercise `finally` releaseAndObserve
