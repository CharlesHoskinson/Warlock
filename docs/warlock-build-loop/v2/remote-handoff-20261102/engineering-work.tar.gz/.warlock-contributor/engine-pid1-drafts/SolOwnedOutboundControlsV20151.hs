{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- Root-only, UNEXECUTED public-library fixture. Root must pre-root Retained and
-- the resolver-issued HeldExecutable before runCase. The child is the separately
-- built SolOwnedOutboundPeerV20151; Root pins that exact artifact independently.
-- No private constructors, private hooks, src-copy or CPP are used here.
module SolOwnedOutboundControlsV20151 (Mode(..), Retained, newRetained, runCase) where

import Control.Concurrent (threadDelay)
import Control.Exception (mask)
import Control.Monad (unless, when)
import qualified Data.ByteString as B
import Data.IORef
import qualified Data.Text.Encoding as TE
import System.Directory (doesFileExist, removeFile)
import System.FilePath (isAbsolute)
import System.IO (Handle, IOMode(ReadWriteMode), hIsClosed)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import qualified Network.Socket as S
import Warlock.Capture.Process.Bootstrap
  ( AdmissionDeadline, SessionObservation(..), ToolError(..), deadlineAbsoluteNs
  , deadlineAfter, deadlineFromAbsoluteNs, newTransferTicket, remainingMicros )
import Warlock.Capture.Process.Persistent
  ( LiveFrameAdmission, LiveOperationFailure(..), PersistentOwner, SessionExit(..)
  , StopReceipt(..), StopDeadlineObservation(..), tryPersistentStopDeadline, actionBudgetMicros, beginLiveFrameRequestBatch
  , enterLiveBatchRequest, newPersistentOwner, persistentHeld
  , requestSessionStop, startBudgetAfter, stopBudgetMicros, withPersistentOwner )
import Warlock.Platform.Executable (HeldExecutable)
import qualified Warlock.Protocol.Codec as Codec
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import qualified Warlock.Protocol.CredentialIngress as P
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (renderCounter)
import Warlock.Protocol.Ingress
  (ActivationResult(..), Direction(..), EndpointState(..), OfferResult(..), OwnerStatus(..), Priority(..), ingressBinding)
import qualified Warlock.Protocol.PeerCredential as Peer
import qualified Warlock.Protocol.StrictJson as J

data Mode = Positive | ExpiredCeiling | StopBeforeAdmission | StopAfterAdmission
  deriving (Eq, Show)
type Context = (LiveFrameAdmission, P.FrameDeadline)
data Retained = Retained
  PersistentOwner (IORef Bool) (IORef (Maybe HeldExecutable))
  (IORef (Maybe (P.CredentialIngressT Context)))
  (IORef (Maybe (S.Socket,S.Socket))) (IORef (Maybe Handle))

newRetained :: IO Retained
newRetained = Retained <$> newPersistentOwner <*> newIORef False
  <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("owned outbound: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
ns :: AdmissionDeadline -> IO Integer
ns d = maybe (ioError (userError "opaque deadline representation refused")) pure
  (readMaybe (deadlineAbsoluteNs d))

-- One fixed QA observation bound, additionally capped by any already-latched
-- same-owner StopD. Polling never mints a new deadline. Atomic publication means
-- existence is a complete closed receipt, not an in-progress file write.
awaitReceipt :: PersistentOwner -> AdmissionDeadline -> FilePath -> IO B.ByteString
awaitReceipt owner witness path = loop
 where
  left = do
   own <- remainingMicros witness
   stop <- tryPersistentStopDeadline owner
   case stop of
    StopDeadlineNotLatched -> pure own
    StopDeadlineLatched original -> min own <$> remainingMicros original
    _ -> ioError (userError "receipt observation has uncertain original StopD; retain owner")
  loop = do
   budget <- left
   check "fixed observation/stricter StopD remains" (budget > 0)
   exists <- doesFileExist path
   if not exists then threadDelay (min 1000 budget) >> loop else do
    actual <- timeout budget (B.readFile path)
    bytes <- maybe (ioError (userError "receipt observation expired; retain owner")) pure actual
    finalBudget <- left
    check "receipt completed inside original observation bound" (finalBudget > 0)
    limits <- must (J.bounds 2097408 16)
    tree <- must (J.decodeStrict limits bytes)
    _ <- must (J.exactObject ["received"] tree)
    pure bytes

-- An independent literal reply, never captured from a reducer or live output.
reply :: B.ByteString
reply = "{\"bridgeProtocol\":1,\"kind\":\"native-event\",\"payload\":{\"protocolVersion\":3,\"kind\":\"application-catalog\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"7\",\"snapshot\":null,\"preferences\":null}}"

-- keepPath is a distinct Root-created owned0600 marker. receiptPath must not
-- exist; Root retains its namespace before execution. This function never
-- guesses child/FD cleanup on an exception. Retained remains rooted by Root.
runCase :: Mode -> Retained -> HeldExecutable -> FilePath -> FilePath -> IO ()
runCase mode (Retained owner used heldCell ingressCell pairCell handleCell) held keepPath receiptPath = mask $ \restore -> do
  usedBefore <- atomicModifyIORef' used (\x -> (True,x))
  check "one-shot retained case" (not usedBefore)
  check "distinct owned absolute paths" (isAbsolute keepPath && isAbsolute receiptPath && keepPath /= receiptPath)
  marker <- doesFileExist keepPath
  previous <- doesFileExist receiptPath
  pending <- doesFileExist (receiptPath ++ ".writing")
  check "Root marker exists and both receipt paths are fresh" (marker && not previous && not pending)
  writeIORef heldCell (Just held)
  binding <- must (ingressBinding "1" "2" "3")
  stop <- must (stopBudgetMicros 2000000)
  budget <- must (actionBudgetMicros 500000)
  observed <- newIORef Nothing
  firstFrameD <- newIORef Nothing
  drift <- newIORef False
  credentialChecks <- newIORef (0 :: Int)
  callbacks <- newIORef (0 :: Int)
  actions <- newIORef (0 :: Int)
  deadlinePair <- newIORef Nothing
  actionOutcome <- newIORef Nothing
  nextOutcome <- newIORef Nothing
  localSend <- newIORef Nothing
  stopReceipt <- newIORef Nothing
  completeReceipt <- newIORef Nothing
  uid <- toInteger <$> getEffectiveUserID
  gid <- toInteger <$> getEffectiveGroupID
  let note frame = do
        let value=P.frameDeadlineNs frame
        old <- readIORef firstFrameD
        case old of Nothing -> writeIORef firstFrameD (Just value); Just original -> when (original /= value) (writeIORef drift True)
      accept credential = do
        modifyIORef' credentialChecks (+1)
        known <- readIORef observed
        pure $ case known of
          Just actual | Peer.credentialPid credential == toInteger (observedPid actual)
                     && Peer.credentialUid credential == uid && Peer.credentialGid credential == gid -> Right ()
          _ -> Left ("actual selected peer mismatch" :: String)
      guardFor _ frame = CredentialGuard
        (\credential -> note frame >> accept credential)
        (\credential action -> do
          note frame
          allowed <- accept credential
          case allowed of Left why -> pure (Left why); Right () -> Right <$> action)
      latch = do
        receipt <- requestSessionStop owner stop
        writeIORef stopReceipt (Just receipt)
        -- Ignoring TERM in this bounded QA child distinguishes stop from death.
        check "actual live selected owner stop signal" (receipt == StopSignalSent)
      handler (admission,frame) checked = do
        modifyIORef' callbacks (+1)
        note frame
        commit <- maybe (ioError (userError "checked desktop commit missing")) pure (Codec.checkedDesktopCommit checked)
        check "one independent literal catalog request" (case D.commitRequests commit of
          [request] -> D.requestKind request == D.CatalogRead && renderCounter (D.requestId request) == "7"
          _ -> False)
        frameD <- deadlineFromAbsoluteNs (show (P.frameDeadlineNs frame)) >>= must
        batch <- beginLiveFrameRequestBatch admission frameD False 1 >>= must
        ceiling <- deadlineAfter (if mode == ExpiredCeiling then 1000 else 250000) >>= must
        ceilingNs <- ns ceiling
        when (mode == ExpiredCeiling) $ do
          threadDelay 3000
          left <- remainingMicros ceiling
          check "negative ceiling is actually expired" (left == 0)
        when (mode == StopBeforeAdmission) latch
        result <- enterLiveBatchRequest batch budget (Just ceiling) $ \exactD -> do
          modifyIORef' actions (+1)
          exactNs <- ns exactD
          writeIORef deadlinePair (Just (ceilingNs,exactNs))
          check "stricter ceiling passed lexically without renewal" (exactNs == ceilingNs)
          when (mode == StopAfterAdmission) latch
          ingress <- readIORef ingressCell >>= maybe (ioError (userError "ingress not retained")) pure
          queued <- P.enqueueCredentialIngress ingress Ordinary reply
          check "literal outbound frame queued" (queued == Right ())
          sent <- P.sendPersistentCredentialIngress exactNs ingress
          writeIORef localSend (Just sent)
          -- Local completion and owner outcome are deliberately separate facts.
          pure (Right ())
        writeIORef actionOutcome (Just result)
        later <- enterLiveBatchRequest batch budget (Just ceiling) $ \_ -> modifyIORef' actions (+1) >> pure (Right ())
        writeIORef nextOutcome (Just later)
  ingress <- P.newDesktopCredentialIngressWithContext binding FromElm handler (\_ _ -> ioError (userError "unexpected server callback"))
  writeIORef ingressCell (Just ingress)
  (host,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  writeIORef pairCell (Just (host,peer))
  offered <- P.transferCredentialSocket ingress host
  check "exact host endpoint transferred once" (offered == OfferAccepted)
  active <- P.activateCredentialIngress ingress
  check "same ingress active" (active == ActivationLive)
  input <- S.socketToHandle peer ReadWriteMode
  writeIORef handleCell (Just input)
  ticket <- newTransferTicket input
  selection <- must (persistentHeld held [show mode,keepPath,receiptPath] ticket [("LANG","C"),("LC_ALL","C")])
  start <- startBudgetAfter 2000000 >>= must
  let verify value = writeIORef observed (Just value) >> pure (Right ())
      body live = do
        witness <- deadlineAfter 1750000 >>= must
        -- Actual same LiveSession supplies frame/wake scope; SCM credentials
        -- come from the real selected fd0 child, never a synthetic PID.
        received <- P.receivePersistentCredentialIngressOwned False live ingress guardFor
        case mode of
          Positive -> check "authenticated frame delivered" (received == Right (P.PersistentOutcome P.CredentialDelivered))
          ExpiredCeiling -> check "refused action does not fake frame rejection" (received == Right (P.PersistentOutcome P.CredentialDelivered))
          _ -> pure () -- Stop may conservatively change the outer wake outcome.
        -- Do not let normal owner retirement kill a child whose receipt is
        -- still being written. The child atomically publishes only after close.
        bytes <- awaitReceipt owner witness receiptPath
        writeIORef completeReceipt (Just bytes)
        removeFile keepPath
  completed <- restore (withPersistentOwner owner selection 4096 start stop verify body)
  case completed of
    Right ((),LeaderReaped _) -> do
      handleClosed <- hIsClosed input
      endpointStatus <- P.retireCredentialIngress ingress
      check "owned transferred handle and host endpoint closed" (handleClosed && endpoint endpointStatus == Just EndpointConfirmed)
    _ -> ioError (userError ("owner outcome unconfirmed; Root retains case: " ++ show completed))
  n <- readIORef callbacks
  count <- readIORef actions
  checkedCredentials <- readIORef credentialChecks
  changed <- readIORef drift
  result <- readIORef actionOutcome
  later <- readIORef nextOutcome
  sent <- readIORef localSend
  pair <- readIORef deadlinePair
  stopped <- readIORef stopReceipt
  receipt <- readIORef completeReceipt >>= maybe (ioError (userError "complete receipt not retained")) pure
  limits <- must (J.bounds 2097408 16)
  peerObserved <- must (J.decodeStrict limits receipt)
  let exactReply=J.JObject [("received",J.JString (TE.decodeUtf8 reply))]
      noReply=J.JObject [("received",J.JNull)]
      newAdmissionRefused = later == Just (Left (OperationRefusedPreDispatch SessionClosed))
  putStrLn ("outbound observation: " ++ show (mode,n,count,result,later,sent,stopped,pair))
  B.putStr receipt
  check "one real callback and stable authenticated frame D" (n == 1 && checkedCredentials >= 2 && not changed)
  case mode of
    Positive -> check "positive exact lexical D and independent peer bytes"
      (count == 1 && result == Just (Right ()) && sent == Just P.WrittenLocally && peerObserved == exactReply
        && maybe False (uncurry (==)) pair && later == Just (Left (OperationRefusedPreDispatch OwnerBusy)))
    ExpiredCeiling -> check "expired stricter ceiling invokes no sender"
      (count == 0 && result == Just (Left (OperationRefusedPreDispatch TimedOut)) && sent == Nothing && peerObserved == noReply && newAdmissionRefused)
    StopBeforeAdmission -> check "sticky stop refuses NEW action before dispatch"
      (stopped == Just StopSignalSent && count == 0 && result == Just (Left (OperationRefusedPreDispatch SessionClosed)) && sent == Nothing && peerObserved == noReply && newAdmissionRefused)
    StopAfterAdmission -> do
      -- No universal physical-byte absence oracle for an already-admitted
      -- action: report exact observation, require Unknown and no new dispatch.
      check "admitted action remains Unknown after stop; no replay"
        (stopped == Just StopSignalSent && count == 1 && result == Just (Left (OperationOutcomeUnknown SessionClosed))
          && newAdmissionRefused && (peerObserved == exactReply || peerObserved == noReply))
      putStrLn ("already-admitted local sender observation: " ++ show sent)
      B.putStr receipt

