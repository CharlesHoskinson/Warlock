'use strict';
// Source-derived QA factory for Root integration, not executed.  The context
// must consist of the independently authored literals/functions already in the
// green tea-contract-cases.cjs, never observed reducer or worker output.
// Exact base source hash and every added factory's hash belong in the handoff.
// Elm debug object tags and wire serialization still require Root's checks.
// Inlined reviewed q-origin factory source SHA256 113cf5419456680f52822d862cec39fba916c5652ee863b6682baf115d1a4b07.
// QA-only source-literal supplement. NOT RUN, and not a replacement for the
// separate pending settings/motion/shortcut finite-receipt cases. Integrator
// must inline the factory in the sandboxed oracle and supply ONLY the reviewed
// source-authored pinCases, cloneLiteral, NIL from tea-contract-cases.cjs.
// No reducer output or observed state may be used as an oracle dependency.
// Desktop.elm taskbar-pins-outcome rejects status outside Saved/Refused/Unknown
// before Pins.receive; Pins.elm preserves an Unknown reservation without replay.
function buildMalformedPinPreferenceCases(c) {
  if (!c || !Array.isArray(c.pinCases) || typeof c.cloneLiteral !== 'function' || !c.NIL) {
    throw new Error('independently authored pin literals required');
  }
  const copy = c.cloneLiteral;
  const candidates = c.pinCases.filter(x => x && x.name === 'pin-unknown-retains-reservation-no-replay');
  if (candidates.length !== 1) throw new Error('one canonical pin Unknown literal required');
  const baseline = candidates[0];
  if (!Array.isArray(baseline.steps) || baseline.steps.length < 4 ||
      baseline.steps[0].input.kind !== 'reset' || baseline.steps[1].input.kind !== 'prelude' ||
      baseline.steps[1].setupTimers !== 0) throw new Error('canonical pending prelude shape changed');
  const positive = baseline.steps[2];
  const late = baseline.steps[3];
  const payload = positive && positive.input && positive.input.value && positive.input.value.payload;
  if (!payload || payload.kind !== 'taskbar-pins-outcome' || payload.status !== 'Unknown' ||
      payload.requestId !== '3' || !payload.binding || payload.binding.lifetime !== '1' ||
      payload.binding.session !== '1' || payload.binding.frontend !== '1' || payload.preferences !== null ||
      !positive.expected || !late || !late.expected) throw new Error('canonical positive literal changed');
  return ['Stored', 'Bogus', 'saved', ''].map(status => {
    const invalid = copy(positive.input);
    invalid.value.payload.status = status;
    const before = copy(baseline.steps[1].expected.state);
    return {
      name: 'pin-pending-invalid-status-' + (status === '' ? 'empty' : status),
      steps: [
        copy(baseline.steps[0]),
        copy(baseline.steps[1]),
        { input: invalid, expected: { state: before, effects: copy(c.NIL) } },
        // The original independently literal matching Unknown is a positive
        // control after refusal; it must not replay the saved mutation.
        copy(positive),
        // Repeated Unknown is independently asserted as unchanged/no effect.
        copy(late),
      ],
    };
  });
}

// Inlined peer terra-q-network-window-receipts.cjs SHA256 149f2f4181b1c23ca1ccdeb2a692e6be6aa812eaee365375852013ec85c22275.
// Source-derived DRAFT. No reducer capture, model/compiler/test execution, or
// native authority. Source pins: DesktopPolicy 018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e;
// OutputController fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae;
// SurfaceController 2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998;
// Desktop 91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4;
// Shell 6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094;
// Effects 80c574e8c564c28a1fb11f1f89bb5bfa7ac97a92474bbf027a737324bb2a82cd;
// ActionProjection 911faed965465fac4e32f404d75a4d130b4e560cda191c7773eb96749be1d062;
// TaskbarShell eeb91d15cab97c94bf12ef3d1e25f513ac6c037774bef5150867eb01c6f86c26;
// Surface c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb;
// canonical QA c3272b69d6e22182063014649a04acdf0a87b1aaf61ce5b9b043c6f7bb1e5a9c.
// Root must review initial/prelude, artifact encoding and all
// state/effect values before integration. Factory is inlineable into QA runner.
function buildWindowReceiptCases(c) {
  const { cloneLiteral: copy, literalPatches: patch, initial, topologyChanges,
    oneViewChanges, oneScope, oneScopeJson, binding, bindingJson, host, empty,
    none, zero, NIL } = c;
  if ([copy,patch,initial,topologyChanges,oneViewChanges,oneScope,oneScopeJson,
       binding,bindingJson,host,empty,none,zero,NIL].some(x => x === undefined)) {
    throw new Error('independently literal window fixture dependencies missing');
  }
  const C = s => ({ $:'Counter', a:s });
  const J = x => ({ $:'Just', a:x });
  const L = xs => xs.reduceRight((b,a) => ({ $:'::', a,b }), empty());
  const dp = (...xs) => ['controller','a','controller','a','desktop', ...xs];
  const sp = (...xs) => dp('windows','shell',...xs);
  const pub = n => ['controller','a','controller','a','publication'];
  const change = (path,before,after) => ({ path,before,after });
  const P = (status, publication, group, requests) => {
    const prefix = 'applications:' + host + ':3:';
    const row = (id,domId,label,ariaLabel,detail,enabled) =>
      ({id,domId,label,ariaLabel,detail,enabled,focusOnly:false});
    const utility = [
      row('bar:applications',prefix+'control:opener','Applications','Open applications','',true),
      row('bar:overview',prefix+'control:overview-opener','Task View','Open Task View','',group === 'ready'),
      row('bar:switcher',prefix+'control:switcher-opener','Switch windows','Open window switcher','',group === 'ready'),
      row('bar:notifications',prefix+'notifications:opener','Notifications','Open notifications','',true),
      row('bar:files',prefix+'files:opener','Files','Open Files menu','',true),
      row('bar:system',prefix+'system:opener','System','Open system menu','',true),
      row('bar:settings',prefix+'settings:opener','Settings','Open settings','',true),
    ];
    const recovery = group === 'pending' || group === 'refused' ? [
      row('bar:recovery-refresh',prefix+'bar:recovery-refresh','Refresh window status',
          'Refresh window status; read observations without retrying actions','Observation only',group === 'refused')
    ] : [];
    const blocked = group === 'pending';
    const groupRow = group === 'none' ? [] : [row('bar:group:application:demo',
      'group:'+host+':1:1:application:demo','Window',
      'Minimize Window; Active'+(blocked?'; awaiting native confirmation':''),
      blocked?'Awaiting native confirmation; Active':'Active',group === 'ready')];
    return {viewProtocol:1,kind:'view-commit',projection:{
      viewProtocol:1,kind:'view-frame',revision:'1',views:[oneScopeJson],focusOwner:oneScopeJson,
      popupOwner:null,frame:{surfaceProtocol:2,keyboardParent:true,motion:'reduced',
        appearance:{theme:'night',textScale:100,effectsOff:false,reducedTransparency:false},
        publication,lease:'0',mode:'closed',status,bar:recovery.concat(groupRow,utility),popup:[]},
      announcer:{scope:oneScopeJson,surface:'bar'},announcement:null},requests,focus:[]};
  };
  const wrap = packet => ({ $:'::', a:{ $:'Publish', a:{ $:0,a:packet } }, b:empty() });
  const incoming = (kind,payload) => ({bridgeProtocol:1,kind,payload});
  const request = (kind,id) => ({protocolVersion:3,kind,binding:bindingJson,requestId:id});
  const startupRequests = [request('catalog-request','1'),request('shell-settings-request','2'),
    request('motion-preferences-request','3'),request('shortcut-preferences-request','4'),
    request('projection-request','1')];
  const attachedPacket = P('Updating window information…','4','none',startupRequests);
  const pair = (a,b) => ({ $:'#2',a,b });
  const startupBatch = {scope:oneScope,revision:C('1'),publication:C('4'),lease:C('0'),
    binding,wire:JSON.stringify(attachedPacket),observations:L([pair('projection-request',C('1'))]),
    operations:empty(),catalogs:L([{binding,request:C('1')}])};
  const context = {lifetime:C('1'),epoch:C('1'),output:C('1'),revision:C('1')};
  const wireContext = {lifetime:'1',epoch:'1',output:'1',revision:'1'};
  const window = {incarnation:C('1'),label:'Window',minimized:false,owner:none(),
    application:'demo',available:true,attention:false};
  // Debug constructor form for a one-node Dict, subject to Root's actual
  // compiler artifact qualification; this representation is not guessed from
  // a captured reducer result.
  const node = {$:'RBNode_elm_builtin',a:{$:'Black'},b:'1',c:C('1'),
    d:{$:'RBEmpty_elm_builtin'},e:{$:'RBEmpty_elm_builtin'}};
  const scene = {$:'Admitted',a:C('1'),b:J(C('1')),c:L([window]),d:node};
  const observed = {context,scene};
  const intent = {request:C('1'),generation:C('1'),incarnation:C('1'),operation:{$:'Minimize'},context};
  const wireIntent = {request:'1',generation:'1',incarnation:'1',operation:'minimize',context:wireContext};
  const transaction = status => ({intent,status:{$:status},effectProtocol:1});
  const issued = {binding,protocol:1,intent};
  const windowRequest = {protocolVersion:3,kind:'window-effect',effectProtocol:1,binding:bindingJson,intent:wireIntent};
  const pendingPacket = P('Minimize: applying to Window…','7','pending',[windowRequest]);
  const mutationBatch = {scope:oneScope,revision:C('1'),publication:C('7'),lease:C('0'),binding,
    wire:JSON.stringify(pendingPacket),observations:empty(),operations:L([issued]),catalogs:empty()};
  const oneViewChanges0 = copy(topologyChanges); oneViewChanges0[1].after=C('3');
  const oneView = patch(initial,oneViewChanges0.concat(copy(oneViewChanges)));
  const stateChanges = [
    change(pub(),C('3'),C('7')),
    change(dp('presentation'),J(C('2')),J(C('3'))),
    change(dp('request'),zero(),C('4')),
    change(dp('expected'),none(),J(C('1'))),
    change(dp('settingsExpected'),none(),J(C('2'))),
    change(dp('motionExpected'),none(),J(C('3'))),
    change(dp('shortcutExpected'),none(),J(C('4'))),
    change(dp('workspaceNavigation','binding'),none(),J(binding)),
    change(dp('launch','a','host'),none(),J(host)),
    change(dp('launch','a','revision'),C('2'),C('4')),
    change(dp('pointer','observation'),none(),J({binding,serial:C('1'),state:{$:'Idle'},owner:none()})),
    change(sp('binding'),none(),J(binding)),
    change(sp('request'),zero(),C('1')),
    change(sp('phase'),{$:'Detached'},{$:'Ready'}),
    change(sp('reconnecting'),true,false),
    change(sp('notice'),'Connecting…','Connected'),
    change(sp('effects','connected'),false,true),
    change(sp('effects','observed'),none(),J(observed)),
    change(sp('effects','request'),zero(),C('1')),
    change(sp('effects','generation'),zero(),C('1')),
    change(sp('effects','transaction'),none(),J(transaction('Pending'))),
    change(sp('effects','unresolved'),empty(),L([transaction('Pending')])),
    change(sp('issued'),empty(),L([issued])),
    change(['controller','a','batches'],empty(),L([mutationBatch,startupBatch])),
  ];
  const pending = patch(oneView,stateChanges);
  const topology = incoming('view-topology',{viewProtocol:1,kind:'view-topology',revision:'1',views:[oneScopeJson]});
  const attached = incoming('native-event',{protocolVersion:3,kind:'attached',binding:bindingJson});
  const projection = incoming('native-event',{protocolVersion:3,kind:'action-projection',binding:bindingJson,
    requestId:'1',context:wireContext,scene:{revision:'1',focused:'1',windows:[{incarnation:'1',
      label:'Window',minimized:false,owner:null,application:'demo',available:true}]}});
  const pointer = incoming('native-event',{protocolVersion:3,kind:'pointer-ownership',ownershipProtocol:1,
    binding:bindingJson,requestId:'1',serial:'1',state:'idle',owner:null});
  const mutate = incoming('view-action',{viewProtocol:1,kind:'view-action',scope:oneScopeJson,
    action:{surfaceProtocol:2,kind:'surface-action',surface:'bar',publication:'6',lease:'0',
      id:'bar:group:application:demo',trigger:'keyboard'}});
  // Shared source-literal native-ready GIVEN: exactly four real Policy.Incoming
  // inputs. The helper returns no captured output and introduces no authority.
  // Consumers may compose their own independently literal tested transitions.
  if (c.windowReadyOnly === true) {
    const ready = patch(pending,[
      change(pub(),C('7'),C('6')),
      change(sp('effects','request'),C('1'),zero()),
      change(sp('effects','generation'),C('1'),zero()),
      change(sp('effects','transaction'),J(transaction('Pending')),none()),
      change(sp('effects','unresolved'),L([transaction('Pending')]),empty()),
      change(sp('issued'),L([issued]),empty()),
      change(['controller','a','batches'],L([mutationBatch,startupBatch]),L([startupBatch])),
    ]);
    const readyPacket = P('Connected','6','ready',[]);
    return {input:{kind:'prelude',values:[copy(topology),copy(attached),copy(projection),copy(pointer)]},
      setupTimers:0,expected:{state:ready,effects:wrap(readyPacket)},
      literals:{binding:copy(binding),bindingJson:copy(bindingJson),scope:copy(oneScope),
        scopeJson:copy(oneScopeJson),context:copy(context),wireContext:copy(wireContext),
        startupBatch:copy(startupBatch),host}};
  }
  const reset = {input:{kind:'reset'},expected:{state:copy(initial),effects:copy(NIL)}};
  const given = {input:{kind:'prelude',values:[topology,attached,projection,pointer,mutate]},setupTimers:0,
    expected:{state:copy(pending),effects:wrap(pendingPacket)}};
  const receipt = status => ({kind:'incoming',value:incoming('native-event',{
    protocolVersion:3,kind:'effect-outcome',effectProtocol:1,binding:bindingJson,intent:wireIntent,
    status,reason:'applied',revision:'2',outputGeneration:'1'})});
  const cases = ['Committed','Refused'].map(status => {
    const statusText = status === 'Refused' ? 'Minimize: refused for Window. Refresh window status, then choose again.' : 'Connected';
    const packet = P(statusText,'8',status === 'Refused' ? 'refused':'settled',[request('projection-request','2')]);
    const readBatch = {scope:oneScope,revision:C('1'),publication:C('8'),lease:C('0'),binding,
      wire:JSON.stringify(packet),observations:L([pair('projection-request',C('2'))]),operations:empty(),catalogs:empty()};
    const settled = patch(pending,[
      change(pub(),C('7'),C('8')),
      change(sp('request'),C('1'),C('2')),
      change(sp('expected'),none(),J(C('2'))),
      change(sp('phase'),{$:'Ready'},{$:'Reconciling'}),
      change(sp('effects','transaction'),J(transaction('Pending')),J(transaction(status))),
      change(sp('effects','unresolved'),L([transaction('Pending')]),empty()),
      change(sp('issued'),L([issued]),empty()),
      change(['controller','a','batches'],L([mutationBatch,startupBatch]),L([readBatch,mutationBatch,startupBatch])),
    ]);
    const duplicate = receipt(status);
    const stale = receipt(status); stale.value.payload.intent = {...wireIntent,request:'2'};
    return {name:'window-minimize-'+status.toLowerCase()+'-duplicate-and-stale',steps:[
      copy(reset),copy(given),{input:receipt(status),expected:{state:copy(settled),effects:wrap(packet)}},
      {input:duplicate,expected:{state:copy(settled),effects:copy(NIL)}},
      {input:stale,expected:{state:copy(settled),effects:copy(NIL)}}]};
  });
  return cases;
}

// Inlined peer tea-delay-front.cjs SHA256 98f633ae25bd5eb4ac657d97988c7aa6075fc0bf5165f3c040e67fdf5efed4f2.

/* Source-derived QA draft; not executed. Insert this factory into the same
 * sandboxed oracle module as tea-contract-cases.cjs. The prelude uses actual
 * incoming policy events; no authority constructor is injected into the worker.
 * Runtime/model timers and native acceptance are outside this fixture. */
function buildLaunchDeadlineCases(c) {
  const { cloneLiteral: copy, literalPatches: patch, initial, topologyChanges,
    oneViewChanges, oneScope, oneScopeJson, binding, bindingJson, host,
    empty, none, zero, NIL } = c;
  if ([copy, patch, initial, topologyChanges, oneViewChanges, oneScope,
    oneScopeJson, binding, bindingJson, host, empty, none, zero, NIL]
    .some(value => value === undefined)) throw new Error('missing independently pinned source literal');
  const counter = value => ({ $: 'Counter', a: String(value) });
  const just = value => ({ $: 'Just', a: value });
  const list = values => values.reduceRight((tail, value) => ({ $: '::', a: value, b: tail }), empty());
  const tuple = (a, b) => ({ $: '#2', a, b });
  const prefix = n => 'applications:' + host + ':' + n + ':';
  const row = (id, domId, label, ariaLabel, detail, enabled) =>
    ({ id, domId, label, ariaLabel, detail, enabled, focusOnly: false });
  const bar = p => [
    row('bar:applications', prefix(p) + 'control:opener', 'Applications', 'Open applications', '', true),
    row('bar:overview', prefix(p) + 'control:overview-opener', 'Task View', 'Open Task View', '', false),
    row('bar:switcher', prefix(p) + 'control:switcher-opener', 'Switch windows', 'Open window switcher', '', false),
    row('bar:notifications', prefix(p) + 'notifications:opener', 'Notifications', 'Open notifications', '', true),
    row('bar:files', prefix(p) + 'files:opener', 'Files', 'Open Files menu', '', true),
    row('bar:system', prefix(p) + 'system:opener', 'System', 'Open system menu', '', true),
    row('bar:settings', prefix(p) + 'settings:opener', 'Settings', 'Open settings', '', true),
  ];
  const popup = (p, state, catalog) => {
    if (state === 'closed') return [];
    const rows = [
      row('control:search', 'launcher-search', '', 'Search applications', '', true),
      row('control:close', prefix(p) + 'control:close', 'Windows', 'Close applications and return to windows', '', true),
      row('control:refresh', prefix(p) + 'control:refresh', 'Refresh', 'Refresh applications', '', true),
    ];
    if (state === 'unknown') rows.push(row('control:acknowledge', prefix(p) + 'control:acknowledge',
      'I checked; allow another launch', 'I checked; allow another launch', '', true));
    if (catalog) rows.push(
      row('jump:open:sample.desktop', prefix(p) + 'jump:open:sample.desktop', 'Actions for Sample', 'Actions for Sample', 'Application actions and recent files', true),
      row('pin:sample.desktop', prefix(p) + 'pin:sample.desktop', 'Pin Sample', 'Pin Sample', 'Add to taskbar', true),
      row('entry:sample.desktop', prefix(p) + 'entry:sample.desktop', 'Open Sample', 'Open Sample', '', state === 'ready'));
    return rows;
  };
  const packet = (pub, lease, p, state, status, catalog, requests, focus) => ({
    viewProtocol: 1, kind: 'view-commit', projection: {
      viewProtocol: 1, kind: 'view-frame', revision: '1', views: [oneScopeJson],
      focusOwner: oneScopeJson, popupOwner: state === 'closed' ? null : oneScopeJson,
      frame: { surfaceProtocol: 2, keyboardParent: true, motion: 'reduced',
        appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
        publication: pub, lease, mode: state === 'closed' ? 'closed' : 'applications', status,
        bar: bar(p), popup: popup(p, state, catalog) },
      announcer: { scope: oneScopeJson, surface: state === 'closed' ? 'bar' : 'popup' }, announcement: null,
    }, requests, focus,
  });
  const request = (kind, id) => ({ protocolVersion: 3, kind, binding: bindingJson, requestId: id });
  const entry = { identity: { $: 'EntryId', a: 'sample.desktop' }, name: 'Sample', iconHint: '',
    wmclass: '', genericName: '', keywords: empty() };
  const dictEmpty = { $: 'RBEmpty_elm_builtin' };
  const dict = { $: 'RBNode_elm_builtin', a: { $: 'Black' }, b: 'sample.desktop', c: entry,
    d: dictEmpty, e: dictEmpty };
  const snapshot = { $: 'Snapshot', a: counter(1), b: counter(1), c: dict };
  const attachRequests = [request('catalog-request', '1'), request('shell-settings-request', '2'),
    request('motion-preferences-request', '3'), request('shortcut-preferences-request', '4'),
    request('projection-request', '1')];
  const attachPacket = packet('4', '0', '3', 'closed', 'Updating window information…', false, attachRequests, []);
  const openRequest = request('catalog-request', '5');
  const openPacket = packet('6', '1', '4', 'open', 'Loading applications…', false, [openRequest], ['launcher-search']);
  const catalogPacket = packet('7', '1', '5', 'ready', 'Type to search applications.', true, [], ['launcher-search']);
  const batch1 = { scope: oneScope, revision: counter(1), publication: counter(4), lease: zero(), binding,
    wire: JSON.stringify(attachPacket), observations: list([tuple('projection-request', counter(1))]),
    operations: empty(), catalogs: list([{ binding, request: counter(1) }]) };
  const batch2 = { scope: oneScope, revision: counter(1), publication: counter(6), lease: counter(1), binding,
    wire: JSON.stringify(openPacket), observations: empty(), operations: empty(),
    catalogs: list([{ binding, request: counter(5) }]) };
  const baseChanges = copy(topologyChanges);
  baseChanges[1].after = counter(3);
  const base = patch(initial, baseChanges.concat(copy(oneViewChanges)));
  const dp = ['controller', 'a', 'controller', 'a', 'desktop'];
  const path = (...tail) => dp.concat(tail);
  const given = patch(base, [
    { path: ['controller','a','controller','a','publication'], before: counter(3), after: counter(7) },
    { path: ['controller','a','controller','a','lease'], before: zero(), after: counter(1) },
    { path: path('presentation'), before: just(counter(2)), after: just(counter(5)) },
    { path: path('request'), before: zero(), after: counter(5) },
    { path: path('settingsExpected'), before: none(), after: just(counter(2)) },
    { path: path('motionExpected'), before: none(), after: just(counter(3)) },
    { path: path('shortcutExpected'), before: none(), after: just(counter(4)) },
    { path: path('open'), before: false, after: true },
    { path: path('workspaceNavigation','binding'), before: none(), after: just(binding) },
    { path: path('pointer','observation'), before: none(), after: just({ binding, serial: counter(1), state: { $: 'Idle' }, owner: none() }) },
    { path: path('applications'), before: none(), after: just(snapshot) },
    { path: path('pins','snapshot'), before: none(), after: just({ revision: counter(1), identities: empty() }) },
    { path: path('launch','a','host'), before: none(), after: just(host) },
    { path: path('launch','a','snapshot'), before: none(), after: just(snapshot) },
    { path: path('launch','a','revision'), before: counter(2), after: counter(6) },
    { path: path('windows','shell','binding'), before: none(), after: just(binding) },
    { path: path('windows','shell','phase'), before: { $: 'Detached' }, after: { $: 'Reconciling' } },
    { path: path('windows','shell','reconnecting'), before: true, after: false },
    { path: path('windows','shell','notice'), before: 'Connecting…', after: 'Updating window information…' },
    { path: path('windows','shell','request'), before: zero(), after: counter(1) },
    { path: path('windows','shell','expected'), before: none(), after: just(counter(1)) },
    { path: ['controller','a','batches'], before: empty(), after: list([batch2,batch1]) },
  ]);
  const gateway = (kind, payload) => ({ bridgeProtocol: 1, kind, payload });
  const native = (kind, fields) => gateway('native-event', { protocolVersion: 3, kind, ...fields });
  const action = (surface, publication, lease, id) => gateway('view-action', {
    viewProtocol: 1, kind: 'view-action', scope: oneScopeJson,
    action: { surfaceProtocol: 2, kind: 'surface-action', surface, publication, lease, id, trigger: 'keyboard' },
  });
  const values = [
    gateway('view-topology', { viewProtocol: 1, kind: 'view-topology', revision: '1', views: [oneScopeJson] }),
    native('attached', { binding: bindingJson }),
    native('pointer-ownership', { ownershipProtocol: 1, binding: bindingJson, requestId: '1', serial: '1', state: 'idle', owner: null }),
    action('bar', '5', '0', 'bar:applications'),
    native('application-catalog', { binding: bindingJson, requestId: '5',
      snapshot: { catalogProtocol: 1, lifetime: '1', generation: '1', entries: [
        { id: 'sample.desktop', name: 'Sample', iconHint: '', wmclass: '' } ] },
      preferences: { revision: '1', identities: [] } }),
  ];
  const publish = value => ({ $: 'Publish', a: { $: 0, a: value } });
  const intent = { request: counter(1), lifetime: counter(1), generation: counter(1), entry: 'sample.desktop' };
  const wireIntent = { request: '1', lifetime: '1', generation: '1', entry: 'sample.desktop' };
  const launchRequest = { protocolVersion: 3, kind: 'application-launch', binding: bindingJson, intent: wireIntent };
  const pendingPacket = packet('8', '1', '5', 'pending', 'Opening application…', true, [launchRequest], []);
  const batch3 = { scope: oneScope, revision: counter(1), publication: counter(8), lease: counter(1), binding,
    wire: JSON.stringify(pendingPacket), observations: empty(), operations: empty(), catalogs: empty() };
  const pending = patch(given, [
    { path: ['controller','a','controller','a','publication'], before: counter(7), after: counter(8) },
    { path: path('launchFromApplications'), before: false, after: true },
    { path: path('launch','a','request'), before: zero(), after: counter(1) },
    { path: path('launch','a','revision'), before: counter(6), after: counter(7) },
    { path: path('launch','a','phase'), before: { $: 'Idle' }, after: { $: 'Pending', a: host, b: intent } },
    { path: ['controller','a','batches'], before: list([batch2,batch1]), after: list([batch3,batch2,batch1]) },
  ]);
  const token = { $: 'PendingToken', a: host, b: intent };
  const pendingEffects = list([publish(pendingPacket), { $: 'Delay', a: 10000, b: { $: 'Deadline', a: token } }]);
  const unknown = patch(pending, [
    { path: ['controller','a','controller','a','publication'], before: counter(8), after: counter(9) },
    { path: path('launch','a','revision'), before: counter(7), after: counter(8) },
    { path: path('launch','a','phase'), before: { $: 'Pending', a: host, b: intent },
      after: { $: 'Settled', a: intent, b: { $: 'Unknown' } } },
  ]);
  const unknownPacket = packet('9', '1', '5', 'unknown',
    'The launch could not be confirmed. Check your windows before opening it again.', true, [], []);
  const reset = { input: { kind: 'reset' }, expected: { state: copy(initial), effects: copy(NIL) } };
  const givenStep = { input: { kind: 'prelude', values }, setupTimers: 0,
    expected: { state: copy(given), effects: list([publish(catalogPacket)]) } };
  const start = { input: { kind: 'incoming', value: action('popup', '7', '1', 'entry:sample.desktop') },
    expected: { state: copy(pending), effects: pendingEffects } };
  const submitted = patch(pending, [
    { path: ['controller','a','controller','a','publication'], before: counter(8), after: counter(9) },
    { path: path('open'), before: true, after: false },
    { path: path('launch','a','revision'), before: counter(7), after: counter(8) },
    { path: path('launch','a','phase'), before: { $: 'Pending', a: host, b: intent },
      after: { $: 'Settled', a: intent, b: { $: 'Submitted' } } },
  ]);
  const submittedPacket = packet('9', '1', '5', 'closed', 'Launch submitted.', true, [], []);
  const submittedReceipt = native('application-launch-outcome', { binding: bindingJson,
    outcome: { catalogProtocol: 1, kind: 'launch-outcome', intent: wireIntent,
      status: 'Submitted', reason: 'native-submission-accepted' } });
  return [
    { name: 'launch-delay-exact-timeout-and-stale-token', steps: [copy(reset), copy(givenStep), copy(start),
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(unknown), effects: list([publish(unknownPacket)]) } },
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(unknown), effects: copy(NIL) } },
    ] },
    { name: 'launch-delay-stale-after-matching-submitted', steps: [copy(reset), copy(givenStep), copy(start),
      { input: { kind: 'incoming', value: submittedReceipt }, expected: { state: copy(submitted), effects: list([publish(submittedPacket)]) } },
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(submitted), effects: copy(NIL) } },
    ] },
  ];
}

// Inlined q-http source SHA256 47972d000c4c678d3e7ee222bfa4bee4effe76217f941bb7266a95a30b823398.
// Source-derived, unexecuted QA draft. This is a pure-policy bridge fixture,
// NOT current application-only Haskell native authority or native acceptance.
// The independent window factory dependency is SHA-256
// 149f2f4181b1c23ca1ccdeb2a692e6be6aa812eaee365375852013ec85c22275.
// It must supply its source-literal Pending GIVEN, not captured reducer data.
// Root must review exact compiler tags, all fields and prelude reachability.
function buildWindowRebindCases(c) {
  const {cloneLiteral: copy, literalPatches: patch, buildWindowCases,
    oneScope, oneScopeJson, binding, bindingJson, host, empty, none, zero, NIL} = c;
  if ([copy,patch,buildWindowCases,oneScope,oneScopeJson,binding,bindingJson,host,
       empty,none,zero,NIL].some(x => x === undefined) ||
      typeof copy !== 'function' || typeof patch !== 'function' || typeof buildWindowCases !== 'function') {
    throw new Error('independent window GIVEN and complete literal context required');
  }
  const original = buildWindowCases(c);
  if (!Array.isArray(original) || !original[0] || !Array.isArray(original[0].steps) ||
      original[0].steps[0].input.kind !== 'reset' || original[0].steps[1].input.kind !== 'prelude') {
    throw new Error('unexpected source-literal window GIVEN');
  }
  const given = copy(original[0].steps[1]);
  const pending = given.expected.state;
  const C = s => ({$: 'Counter', a:s});
  const J = x => ({$: 'Just', a:x});
  const L = xs => xs.reduceRight((b,a) => ({$:'::',a,b}),empty());
  const dp = (...xs) => ['controller','a','controller','a','desktop',...xs];
  const sp = (...xs) => dp('windows','shell',...xs);
  const cp = (...xs) => ['controller','a',...xs];
  const change = (path,before,after) => ({path,before,after});
  const pair = (a,b) => ({$:'#2',a,b});
  const context = {lifetime:C('1'),epoch:C('1'),output:C('1'),revision:C('1')};
  const intent = {request:C('1'),generation:C('1'),incarnation:C('1'),operation:{$:'Minimize'},context};
  const wireContext = {lifetime:'1',epoch:'1',output:'1',revision:'1'};
  const wireIntent = {request:'1',generation:'1',incarnation:'1',operation:'minimize',context:wireContext};
  const tx = status => ({intent,status:{$:status},effectProtocol:1});
  const issued = {binding,protocol:1,intent};
  const B2 = {$:'Binding',a:C('1'),b:C('1'),c:C('2')};
  const b2 = {lifetime:'1',session:'1',frontend:'2'};
  const host2 = '{"lifetime":"1","session":"1","frontend":"2"}';
  const lostText = 'Window adapter unavailable. Reconnect to read current state. Unconfirmed actions will not be repeated.';
  const correlation = '{"outcome":"adapter-unavailable","binding":{"lifetime":"1","session":"1","frontend":"1"},"identity":{"adapter":"windows","request":"1","service":null,"revision":null}}';
  const announce = {interrupt:false,sequence:'1',correlation,text:lostText};
  const rawAnnounce = {interrupt:false,sequence:C('1'),correlation,text:lostText};
  const row = (id,domId,label,ariaLabel,detail,enabled) =>
    ({id,domId,label,ariaLabel,detail,enabled,focusOnly:false});
  const wrap = packet => L([{$:'Publish',a:{$:0,a:packet}}]);
  const gateway = payload => ({bridgeProtocol:1,kind:'native-event',payload});
  const viewAction = (publication,id) => ({kind:'incoming',value:{bridgeProtocol:1,kind:'view-action',payload:{
    viewProtocol:1,kind:'view-action',scope:oneScopeJson,action:{surfaceProtocol:2,kind:'surface-action',
      surface:'bar',publication,lease:'0',id,trigger:'keyboard'}}}});
  const ordinary = (wireHost,presentation) => {
    const p='applications:'+wireHost+':'+presentation+':';
    return [
      row('bar:overview',p+'control:overview-opener','Task View','Open Task View','',false),
      row('bar:switcher',p+'control:switcher-opener','Switch windows','Open window switcher','',false),
      row('bar:notifications',p+'notifications:opener','Notifications','Open notifications','',true),
      row('bar:files',p+'files:opener','Files','Open Files menu','',true),
      row('bar:system',p+'system:opener','System','Open system menu','',true),
      row('bar:settings',p+'settings:opener','Settings','Open settings','',true),
    ];
  };
  const group = (dom,blocked) => row('bar:group:application:demo',dom,'Window',
    'Minimize Window; Active'+(blocked?'; awaiting native confirmation':''),
    blocked?'Awaiting native confirmation; Active':'Active',false);
  const request = (kind,id) => ({protocolVersion:3,kind,binding:b2,requestId:id});
  const commit = (publication,status,bar,requests) => ({viewProtocol:1,kind:'view-commit',projection:{
    viewProtocol:1,kind:'view-frame',revision:'1',views:[oneScopeJson],focusOwner:oneScopeJson,popupOwner:null,
    frame:{surfaceProtocol:2,keyboardParent:true,motion:'reduced',
      appearance:{theme:'night',textScale:100,effectsOff:false,reducedTransparency:false},
      publication,lease:'0',mode:'closed',status,bar,popup:[]},
    announcer:{scope:oneScopeJson,surface:'bar'},announcement:announce},requests,focus:[]});
  const blockedGroup = group('group:'+host+':1:1:application:demo',true);
  const closedStatus = 'Minimize: not confirmed for Window. Reconnect to read window status; the action will not be repeated.';
  const lostBar = [row('bar:reconnect','reconnect','Reconnect','Reconnect to the window system','',true),
    ...ordinary(host,'4'),blockedGroup];
  const lostPacket = commit('8',closedStatus,lostBar,[]);
  const disconnected = patch(pending,[
    change(cp('controller','a','publication'),C('7'),C('8')),
    change(dp('presentation'),J(C('3')),J(C('4'))),
    change(dp('expected'),J(C('1')),none()),
    change(dp('settingsExpected'),J(C('2')),none()),
    change(dp('motionExpected'),J(C('3')),none()),
    change(dp('shortcutExpected'),J(C('4')),none()),
    change(dp('workspaceNavigation','binding'),J(binding),none()),
    change(dp('launch','a','revision'),C('4'),C('5')),
    change(dp('launch','a','host'),J(host),none()),
    change(sp('phase'),{$:'Ready'},{$:'Detached'}),
    change(sp('notice'),'Connected','Connection lost. Reconnect to continue.'),
    change(sp('effects','connected'),true,false),
    change(sp('effects','transaction'),J(tx('Pending')),J(tx('Unknown'))),
    change(sp('effects','unresolved'),L([tx('Pending')]),L([tx('Unknown')])),
    change(dp('adapterNotice'),none(),J({source:{$:'Windows'},binding,request:C('1'),service:none(),revision:none()})),
    change(cp('announcements','a'),zero(),C('1')),
    change(cp('announcements','b'),none(),J(rawAnnounce)),
  ]);
  const reconnectBar = [row('bar:reconnect','reconnect','Reconnect','Reconnect to the window system','',false),
    ...ordinary(host,'5'),blockedGroup];
  const reconnectPacket = commit('9',closedStatus,reconnectBar,[{protocolVersion:3,kind:'host-reconnect'}]);
  const reconnecting = patch(disconnected,[
    change(cp('controller','a','publication'),C('8'),C('9')),
    change(dp('presentation'),J(C('4')),J(C('5'))),
    change(dp('launch','a','revision'),C('5'),C('6')),
    change(sp('reconnecting'),false,true),
    change(sp('notice'),'Connection lost. Reconnect to continue.','Reconnecting…'),
  ]);
  const refresh = row('bar:recovery-refresh','applications:'+host2+':6:bar:recovery-refresh',
    'Refresh window status','Refresh window status; read observations without retrying actions','Observation only',true);
  const app = row('bar:applications','applications:'+host2+':6:control:opener',
    'Applications','Open applications','',true);
  const pendingRebindStatus = 'Minimize: not confirmed for Window. Check your windows; Refresh only reads status.';
  const requests = [request('catalog-request','5'),request('shell-settings-request','6'),
    request('motion-preferences-request','7'),request('shortcut-preferences-request','8'),
    request('projection-request','2')];
  const reboundBar = [refresh,group('detached-group',true),app,...ordinary(host2,'6')];
  const reboundPacket = commit('10',pendingRebindStatus,reboundBar,requests);
  const batch = {scope:oneScope,revision:C('1'),publication:C('10'),lease:zero(),binding:B2,
    wire:JSON.stringify(reboundPacket),observations:L([pair('projection-request',C('2'))]),
    operations:empty(),catalogs:L([{binding:B2,request:C('5')}])};
  // The two original batches are literal values from the separately authored
  // source-derived GIVEN; neither this code nor the dependency reads runtime output.
  const priorBatches = pending.controller.a.batches;
  const rebound = patch(reconnecting,[
    change(cp('controller','a','publication'),C('9'),C('10')),
    change(dp('presentation'),J(C('5')),J(C('6'))),
    change(dp('request'),C('4'),C('8')),
    change(dp('expected'),none(),J(C('5'))),
    change(dp('settingsExpected'),none(),J(C('6'))),
    change(dp('motionExpected'),none(),J(C('7'))),
    change(dp('shortcutExpected'),none(),J(C('8'))),
    change(dp('workspaceNavigation','binding'),none(),J(B2)),
    change(dp('launch','a','revision'),C('6'),C('8')),
    change(dp('launch','a','host'),none(),J(host2)),
    change(sp('binding'),J(binding),J(B2)),
    change(sp('request'),C('1'),C('2')),
    change(sp('expected'),none(),J(C('2'))),
    change(sp('phase'),{$:'Detached'},{$:'Reconciling'}),
    change(sp('reconnecting'),true,false),
    change(sp('notice'),'Reconnecting…','Updating window information…'),
    change(dp('adapterNotice'),J({source:{$:'Windows'},binding,request:C('1'),service:none(),revision:none()}),none()),
    change(cp('batches'),priorBatches,L([batch])),
  ]);
  const oldReceipt = requestId => ({kind:'incoming',value:gateway({protocolVersion:3,kind:'effect-outcome',
    effectProtocol:1,binding:bindingJson,intent:{...wireIntent,request:requestId},status:'Refused',
    reason:'dependency-mismatch',revision:'2',outputGeneration:'1'})});
  const refusedBar = [refresh,group('detached-group',false),app,...ordinary(host2,'6')];
  const refusedPacket = commit('11','Minimize: refused for Window. Refresh window status, then choose again.',refusedBar,[]);
  const historicalSettled = patch(rebound,[
    change(cp('controller','a','publication'),C('10'),C('11')),
    change(sp('effects','transaction'),J(tx('Unknown')),J(tx('Refused'))),
    change(sp('effects','unresolved'),L([tx('Unknown')]),empty()),
    change(sp('issued'),L([issued]),empty()),
  ]);
  // IMPORTANT: Shell.elm applies an exact retained old-binding receipt BEFORE
  // testing current binding. Thus the final step below describes code-as-built,
  // and contradicts a blanket 'all old receipts rejected' contract. It must not
  // be presented as proof of that contract or as authority to weaken it.
  return [{name:'window-pending-disconnect-rebind-historical-receipt',steps:[
    copy(original[0].steps[0]),given,
    {input:{kind:'transportLost'},expected:{state:copy(disconnected),effects:wrap(lostPacket)}},
    {input:viewAction('8','bar:group:application:demo'),expected:{state:copy(disconnected),effects:copy(NIL)}},
    {input:viewAction('8','bar:reconnect'),expected:{state:copy(reconnecting),effects:wrap(reconnectPacket)}},
    {input:{kind:'incoming',value:gateway({protocolVersion:3,kind:'attached',binding:b2})},
      expected:{state:copy(rebound),effects:wrap(reboundPacket)}},
    {input:oldReceipt('2'),expected:{state:copy(rebound),effects:copy(NIL)}},
    {input:oldReceipt('1'),expected:{state:copy(historicalSettled),effects:wrap(refusedPacket)}},
  ]}];
}

function buildAdditionalCases(c) {
  const { baseCases, materialize, cloneLiteral: copy, literalPatches: patch,
    attachedPacket, attachedBatch, oneScope, oneScopeJson, binding, host,
    disconnectedText, disconnectedCorrelation, matchingCatalog, empty, none, zero, NIL } = c;
  if (!Array.isArray(baseCases) || typeof materialize !== 'function' || typeof copy !== 'function' ||
      typeof patch !== 'function' || [attachedPacket,attachedBatch,oneScope,oneScopeJson,binding,host,
        disconnectedText,disconnectedCorrelation,matchingCatalog,empty,none,zero,NIL].some(x => x === undefined)) {
    throw new Error('complete independent rebind literal dependencies required');
  }
  const base = baseCases.find(item => item.name === 'catalog-pending-disconnect-rejects-late-receipt');
  if (!base) throw new Error('source-literal disconnected/reconnect baseline absent');
  const previous = materialize(base);
  if (!previous || !Array.isArray(previous.steps) || previous.steps.length !== 6 ||
      previous.steps[5].input.kind !== 'incoming') throw new Error('unexpected independent baseline shape');
  // previous is produced solely from source-transcribed literal cases, not a
  // fixture capture.  The explicit preconditions below bind every changed leaf;
  // all other fields remain in the complete copied model.
  const reconnecting = previous.steps[5].expected.state;
  const one = { $: 'Counter', a: '1' }, two = { $: 'Counter', a: '2' };
  const nextBindingJson = { lifetime: '1', session: '1', frontend: '2' };
  const nextBinding = { $: 'Binding', a: one, b: one, c: two };
  const nextHost = '{"lifetime":"1","session":"1","frontend":"2"}';
  const rows = attachedPacket.projection.frame.bar.map(row => ({
    id: row.id, domId: row.domId.replace(host, nextHost).replace(':3:', ':6:'),
    label: row.label, ariaLabel: row.ariaLabel, detail: row.detail, enabled: row.enabled, focusOnly: row.focusOnly,
  }));
  // All keys follow OutputController.commit/frame and Surface.packet's source
  // insertion order. The batch wire is the exact compact encoding of this
  // independent literal, not a copy of the runtime-emitted commit.
  const packet = { viewProtocol: 1, kind: 'view-commit', projection: {
    viewProtocol: 1, kind: 'view-frame', revision: '1', views: [oneScopeJson], focusOwner: oneScopeJson,
    popupOwner: null, frame: { surfaceProtocol: 2, keyboardParent: true, motion: 'reduced',
      appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
      publication: '7', lease: '0', mode: 'closed', status: 'Applications connected. Window controls unavailable.',
      bar: rows, popup: [] }, announcer: { scope: oneScopeJson, surface: 'bar' },
    announcement: { interrupt: false, sequence: '1', correlation: disconnectedCorrelation, text: disconnectedText },
  }, requests: [{ protocolVersion: 3, kind: 'catalog-request', binding: nextBindingJson, requestId: '2' }], focus: [] };
  const batch = { scope: oneScope, revision: one, publication: { $:'Counter', a:'7' }, lease: zero(),
    binding: nextBinding, wire: JSON.stringify(packet), observations: empty(), operations: empty(),
    catalogs: { $:'::', a: { binding: nextBinding, request: two }, b: empty() } };
  const changes = [
    { path:['controller','a','controller','a','publication'], before:{$:'Counter',a:'6'}, after:{$:'Counter',a:'7'} },
    { path:['controller','a','controller','a','desktop','presentation'], before:{$:'Just',a:{$:'Counter',a:'5'}}, after:{$:'Just',a:{$:'Counter',a:'6'}} },
    { path:['controller','a','controller','a','desktop','request'], before:one, after:two },
    { path:['controller','a','controller','a','desktop','expected'], before:none(), after:{$:'Just',a:two} },
    { path:['controller','a','controller','a','desktop','workspaceNavigation','binding'], before:none(), after:{$:'Just',a:nextBinding} },
    { path:['controller','a','controller','a','desktop','launch','a','revision'], before:{$:'Counter',a:'6'}, after:{$:'Counter',a:'8'} },
    { path:['controller','a','controller','a','desktop','launch','a','host'], before:none(), after:{$:'Just',a:nextHost} },
    { path:['controller','a','controller','a','desktop','windows','shell','binding'], before:{$:'Just',a:binding}, after:{$:'Just',a:nextBinding} },
    { path:['controller','a','controller','a','desktop','windows','shell','applicationOnly'], before:false, after:true },
    { path:['controller','a','controller','a','desktop','windows','shell','phase'], before:{$:'Detached'}, after:{$:'Reconciling'} },
    { path:['controller','a','controller','a','desktop','windows','shell','reconnecting'], before:true, after:false },
    { path:['controller','a','controller','a','desktop','windows','shell','notice'], before:'Reconnecting…', after:'Applications connected. Window controls unavailable.' },
    { path:['controller','a','controller','a','desktop','adapterNotice'], before:{$:'Just',a:{source:{$:'Windows'},binding,request:zero(),service:none(),revision:none()}}, after:none() },
    { path:['controller','a','batches'], before:{$:'::',a:attachedBatch,b:empty()}, after:{$:'::',a:batch,b:empty()} },
  ];
  const rebound = patch(reconnecting, changes);
  const input = { kind:'incoming', value:{ bridgeProtocol:1, kind:'native-event', payload:{
    protocolVersion:3, kind:'application-attached', binding:nextBindingJson, nativeOperations:[] } } };
  const effect = { $:'::', a:{$:'Publish',a:{$:0,a:packet}}, b:empty() };
  const reboundCase = { name:'catalog-rebind-new-frontend-no-old-replay', steps:copy(previous.steps).concat([
    { input, expected:{ state:copy(rebound), effects:effect } },
    { input:copy(matchingCatalog), expected:{ state:copy(rebound), effects:copy(NIL) } },
  ]) };
  const cases = [reboundCase];
  const missing = [];
  // Optional factories are independently authored/hashed complete literals,
  // passed explicitly by Root when integrated. A missing factory is reported,
  // never treated as coverage or replaced with a captured worker state.
  for (const [name, factory] of [['pin-malformed',buildMalformedPinPreferenceCases], ['window',buildWindowReceiptCases], ['window-rebind',buildWindowRebindCases], ['delay',buildLaunchDeadlineCases],
    ['preference',c.buildPreferenceReceiptCases]]) {
    if (factory === undefined) { missing.push(name); continue; }
    if (typeof factory !== 'function') throw new Error('invalid source-literal factory: ' + name);
    const more = factory({ ...c, buildWindowCases: buildWindowReceiptCases, windowReadyOnly: false });
    if (!Array.isArray(more) || more.length === 0) throw new Error('empty source-literal factory: ' + name);
    for (const item of more) {
      if (!item || typeof item.name !== 'string' || !Array.isArray(item.steps) || item.steps.length < 2) {
        throw new Error('invalid complete literal case: ' + name);
      }
      cases.push(item);
    }
  }
  if (new Set(cases.map(item => item.name)).size !== cases.length) throw new Error('duplicate case names');
  return { cases, missing };
}
module.exports = buildAdditionalCases;
