{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- End-to-end CPU/loopback control suite for the persistent application actor +
-- same-owner persistent UI native bridge (unexecuted by worker; Root alone
-- compiles and executes under protected QA). Does not claim native/WebKit or
-- release acceptance; unqualified EngineResult False False preserves child
-- ExitFailure 1 honestly.
module GeminiOmarchyPersistentUiPipelineControlsR1_062248Z (main, runParentSuite) where

import Control.Concurrent (forkFinally, newEmptyMVar, putMVar, takeMVar, threadDelay)
import Control.Exception (IOException, SomeException, bracket, finally, try)
import Control.Monad (forM_, unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.IORef (IORef, modifyIORef', newIORef, readIORef)
import Data.List (nub)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import GHC.Clock (getMonotonicTimeNSec)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import Numeric (showHex)
import System.Directory (canonicalizePath, createDirectory, getTemporaryDirectory, listDirectory, removeDirectoryRecursive)
import System.Environment (getArgs, getExecutablePath, unsetEnv)
import System.Exit (ExitCode(..), exitFailure)
import System.FilePath ((</>), isAbsolute, takeDirectory)
import System.Posix.Files (deviceID, fileID, getSymbolicLinkStatus, isRegularFile, setFileMode)
import System.Posix.IO (dupTo)
import System.Posix.Process (ProcessStatus(..), exitImmediately, forkProcess, getProcessID, getProcessStatus)
import System.Posix.Types (Fd(..))
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Backend
  ( DirectoryPin(..)
  , PersistentBackendRun
  , PersistentDelivery(..)
  , loadPersistentBackendConfig
  , newPersistentBackendOwner
  , persistentBackendCounts
  , persistentBackendDelivery
  , persistentBackendOutcome
  , persistentBackendStartupRefusal
  , retirePersistentBackend
  , runPersistentBackend
  )
import Warlock.Bootstrap (PersistentBootstrapResult(..), newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (deadlineAfter)
import qualified Warlock.Capture.Process.Persistent as Persistent
import Warlock.Protocol.CredentialIngress (PersistentSendResult(..))
import qualified Warlock.Protocol.Desktop as D
import qualified Warlock.Protocol.Framing as F
import Warlock.Protocol.Identity (Binding, Counter, binding, parseCounter)
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.Config as Config
import qualified Warlock.Ui.Native as Native
import qualified Warlock.Ui.Owner as Owner
import qualified Warlock.Ui.Policy as Policy
import Warlock.Ui.PrivateNetwork (enterPrivateNetwork, withPeerNetwork)

data HttpResponse = HttpResponse Int [(B.ByteString, B.ByteString)] B.ByteString deriving Show

data ChildMode = ModeOrdinary | ModeUnqualifiedEngine deriving (Eq, Show)

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

check :: IORef Int -> String -> Bool -> IO ()
check counterRef label ok = do
  modifyIORef' counterRef (+ 1)
  unless ok (ioError (userError label))

within :: String -> IO a -> IO a
within label act = timeout 10000000 act >>= maybe (ioError (userError (label ++ ": timed out"))) pure

jsonBytes :: J.Json -> B.ByteString
jsonBytes = TE.encodeUtf8 . J.renderJson

jObj :: [(T.Text, J.Json)] -> J.Json
jObj = J.JObject

jTxt :: String -> J.Json
jTxt = J.JString . T.pack

atKey :: T.Text -> J.Json -> J.Json
atKey keyName (J.JObject pairs) = maybe J.JNull id (lookup keyName pairs)
atKey _ _ = J.JNull

replaceKey :: T.Text -> J.Json -> J.Json -> J.Json
replaceKey keyName newVal (J.JObject pairs) =
  J.JObject ((keyName, newVal) : filter ((/= keyName) . fst) pairs)
replaceKey _ _ otherVal = otherVal

parseJson :: B.ByteString -> IO J.Json
parseJson rawBytes = do
  lim <- must (J.bounds (4 * 1024 * 1024) 32)
  must (J.decodeStrict lim rawBytes)

shaHex :: B.ByteString -> String
shaHex =
  concatMap (\octet -> let d = showHex octet "" in replicate (2 - length d) '0' ++ d)
    . B.unpack
    . SHA.hash

writePrivate :: FilePath -> B.ByteString -> IO ()
writePrivate filePath rawBytes = B.writeFile filePath rawBytes >> setFileMode filePath 0o600

freshDir :: FilePath -> IO FilePath
freshDir dirPath = createDirectory dirPath >> setFileMode dirPath 0o700 >> pure dirPath

mkCounter :: T.Text -> Counter
mkCounter = either (error . show) id . parseCounter False

expectedBinding :: Binding
expectedBinding =
  either (error . show) id
    (binding (mkCounter "9007199254740993") (mkCounter "9007199254740995") (mkCounter "9007199254740997"))

bindingJson :: J.Json
bindingJson = jObj
  [ ("lifetime", jTxt "9007199254740993")
  , ("session", jTxt "9007199254740995")
  , ("frontend", jTxt "9007199254740997")
  ]

scopeJson :: J.Json
scopeJson = jObj [("id", jTxt "1"), ("generation", jTxt "1")]

compilerHtml :: B.ByteString -> B.ByteString -> B.ByteString -> B.ByteString
compilerHtml titleBytes styleBytes scriptBytes = B.concat
  [ "<!DOCTYPE HTML>\n<html>\n<head>\n  <meta charset=\"UTF-8\">\n  <title>"
  , titleBytes
  , "</title>\n  <style>"
  , styleBytes
  , "</style>\n</head>\n\n<body>\n\n<pre id=\"elm\"></pre>\n\n<script>"
  , scriptBytes
  , "</script>\n\n</body>\n</html>"
  ]

focusControlJson :: Bool -> String -> J.Json
focusControlJson isEnabled domName = jObj
  [ ("id", jTxt ("qa:" ++ domName))
  , ("domId", jTxt domName)
  , ("label", jTxt "QA control")
  , ("ariaLabel", jTxt "QA control")
  , ("detail", jTxt "")
  , ("enabled", J.JBool isEnabled)
  , ("focusOnly", J.JBool False)
  ]

scopedProjection :: Maybe J.Json -> J.Json
scopedProjection selectedScope = jObj
  [ ("viewProtocol", J.JNumber "1")
  , ("kind", jTxt "view-frame")
  , ("revision", jTxt "1")
  , ("views", J.JArray (maybe [] (: []) selectedScope))
  , ("focusOwner", J.JNull)
  , ("popupOwner", J.JNull)
  , ("frame", jObj
      [ ("surfaceProtocol", J.JNumber "2")
      , ("publication", jTxt "1")
      , ("lease", jTxt "0")
      , ("mode", jTxt "closed")
      , ("status", jTxt "persistent UI pipeline QA")
      , ("bar", J.JArray [focusControlJson True "focus-valid"])
      , ("popup", J.JArray [])
      ])
  , ("announcer", J.JNull)
  , ("announcement", jTxt "Ready")
  ]

commitPayload :: J.Json -> [J.Json] -> [T.Text] -> B.ByteString
commitPayload proj reqs focusIds = jsonBytes $ jObj
  [ ("viewProtocol", J.JNumber "1")
  , ("kind", jTxt "view-commit")
  , ("projection", proj)
  , ("requests", J.JArray reqs)
  , ("focus", J.JArray (map J.JString focusIds))
  ]

desktopReqJson :: String -> Int -> [(T.Text, J.Json)] -> J.Json
desktopReqJson kindStr reqNum extras = jObj
  ( [ ("protocolVersion", J.JNumber "3")
    , ("kind", jTxt kindStr)
    , ("binding", bindingJson)
    , ("requestId", jTxt (show reqNum))
    ] ++ extras )

proposalJson :: String -> [String] -> J.Json
proposalJson revStr idents = jObj
  [ ("revision", jTxt revStr)
  , ("identities", J.JArray (map jTxt idents))
  ]

wireHttp :: B.ByteString -> B.ByteString -> [(B.ByteString, B.ByteString)] -> B.ByteString -> B.ByteString
wireHttp methodBytes targetBytes hdrs bodyBytes =
  methodBytes <> " " <> targetBytes <> " HTTP/1.1\r\n"
    <> B.concat [k <> ": " <> v <> "\r\n" | (k, v) <- hdrs]
    <> "\r\n"
    <> bodyBytes

postHeaders :: Policy.Origin -> B.ByteString -> [(B.ByteString, B.ByteString)]
postHeaders orig bodyBytes =
  [ ("Host", Policy.hostBytes orig)
  , ("Origin", Policy.originBytes orig)
  , ("X-Warlock-Api", "1")
  , ("Content-Type", "application/json")
  , ("Content-Length", C.pack (show (B.length bodyBytes)))
  ]

originPort :: Policy.Origin -> IO S.PortNumber
originPort orig = do
  let portStr = C.unpack (B.drop 1 (C.dropWhile (/= ':') (Policy.hostBytes orig)))
  parsed <- maybe (ioError (userError "invalid numeric origin port")) pure (readMaybe portStr :: Maybe Int)
  pure (fromIntegral parsed)

httpExchange :: Policy.Origin -> B.ByteString -> B.ByteString -> [(B.ByteString, B.ByteString)] -> B.ByteString -> IO HttpResponse
httpExchange orig methodBytes targetBytes hdrs bodyBytes = do
  exchanged <- timeout 3000000 $ bracket (S.socket S.AF_INET S.Stream S.defaultProtocol) S.close $ \sock -> do
    portNum <- originPort orig
    S.connect sock (S.SockAddrInet portNum (S.tupleToHostAddress (127, 0, 0, 1)))
    N.sendAll sock (wireHttp methodBytes targetBytes hdrs bodyBytes)
    rawResp <- recvAllBytes sock [] 0
    let (hdrPart, restPart) = B.breakSubstring "\r\n\r\n" rawResp
    unless (not (B.null restPart)) (ioError (userError "HTTP header terminator missing"))
    let hdrLines = C.lines hdrPart
    codeNum <- case hdrLines of
      firstLine : _ -> case C.words firstLine of
        _ : codeBytes : _ -> maybe (ioError (userError "HTTP status parse")) pure (readMaybe (C.unpack codeBytes))
        _ -> ioError (userError "HTTP status line malformed")
      [] -> ioError (userError "HTTP response empty")
    let lowerAscii ch = if ch >= 'A' && ch <= 'Z' then toEnum (fromEnum ch + 32) else ch
        parsedHdrs =
          [ (C.map lowerAscii k, C.dropWhile (== ' ') (C.filter (/= '\r') (B.drop 1 v)))
          | ln <- drop 1 hdrLines
          , let (k, v) = B.break (== 58) ln
          ]
        respBody = B.drop 4 restPart
    unless (lookup "content-length" parsedHdrs == Just (C.pack (show (B.length respBody))))
      (ioError (userError "HTTP Content-Length mismatch"))
    pure (HttpResponse codeNum parsedHdrs respBody)
  maybe (ioError (userError "HTTP exchange timed out")) pure exchanged
  where
    recvAllBytes sock acc totalBytes = do
      chunk <- N.recv sock 4096
      if B.null chunk
        then pure (B.concat (reverse acc))
        else do
          unless (totalBytes + B.length chunk <= 4 * 1024 * 1024) (ioError (userError "HTTP response cap exceeded"))
          recvAllBytes sock (chunk : acc) (totalBytes + B.length chunk)

pollControllerEvents :: Policy.Origin -> Int -> IO [J.Json]
pollControllerEvents controllerOrig expectedCount = go expectedCount (80 :: Int) []
  where
    hdrs = [("Host", Policy.hostBytes controllerOrig), ("X-Warlock-Api", "1")]
    go 0 _ acc = pure (reverse acc)
    go needed remaining acc
      | remaining <= 0 = ioError (userError ("timed out waiting for controller events; missing " ++ show needed))
      | otherwise = do
          HttpResponse codeNum _ bodyBytes <- httpExchange controllerOrig "GET" "/events" hdrs B.empty
          if codeNum == 200
            then do
              decoded <- parseJson bodyBytes
              go (needed - 1) 80 (decoded : acc)
            else threadDelay 5000 >> go needed (remaining - 1) acc

pollOneControllerEvent :: Policy.Origin -> IO J.Json
pollOneControllerEvent controllerOrig = do
  evts <- pollControllerEvents controllerOrig 1
  case evts of
    [singleEvt] -> pure singleEvt
    _ -> ioError (userError "expected 1 controller event")

pollTwoControllerEvents :: Policy.Origin -> IO (J.Json, J.Json)
pollTwoControllerEvents controllerOrig = do
  evts <- pollControllerEvents controllerOrig 2
  case evts of
    [firstEvt, secondEvt] -> pure (firstEvt, secondEvt)
    _ -> ioError (userError "expected 2 controller events")

directoryPinJson :: FilePath -> IO J.Json
directoryPinJson dirPath = do
  st <- getSymbolicLinkStatus dirPath
  pure $ jObj
    [ ("path", jTxt dirPath)
    , ("device", jTxt (show (deviceID st)))
    , ("inode", jTxt (show (fileID st)))
    ]

directoryPinFact :: FilePath -> IO DirectoryPin
directoryPinFact dirPath = do
  st <- getSymbolicLinkStatus dirPath
  pure (DirectoryPin dirPath (toInteger (deviceID st)) (toInteger (fileID st)))

ancestorPathList :: FilePath -> [FilePath]
ancestorPathList targetPath =
  reverse (takeWhile (/= "/") (iterate takeDirectory (takeDirectory targetPath)))

assetDocJson :: FilePath -> IO J.Json
assetDocJson filePath = do
  st <- getSymbolicLinkStatus filePath
  unless (isAbsolute filePath && isRegularFile st) (ioError (userError "asset must be absolute regular file"))
  rawBytes <- B.readFile filePath
  ancs <- mapM directoryPinJson (ancestorPathList filePath)
  pure $ jObj
    [ ("path", jTxt filePath)
    , ("device", jTxt (show (deviceID st)))
    , ("inode", jTxt (show (fileID st)))
    , ("size", jTxt (show (B.length rawBytes)))
    , ("sha256", jTxt (shaHex rawBytes))
    , ("ancestors", J.JArray ancs)
    ]

runPipelineChild :: ChildMode -> FilePath -> FilePath -> IO ()
runPipelineChild modeVal uiConfigPath obsPath = do
  checksRef <- newIORef (0 :: Int)
  enterPrivateNetwork
  uiStopBudget <- must (Persistent.stopBudgetMicros 4000000)
  uiStop <- Owner.newPersistentUiStop uiStopBudget
  uiCfg <- Config.loadPersistentUiConfig uiConfigPath >>= must
  preparedDocs <- Config.preparePersistentDocuments uiCfg
  uiOutcome <- withPeerNetwork $ \witness ->
    Owner.runPersistentUiOwner witness uiCfg uiStop $ \endpoints emit -> do
      let ctrlOrig = Owner.controllerOrigin endpoints
          barOrig = Owner.barOrigin endpoints
          popOrig = Owner.popupOrigin endpoints
          getHdrs orig = [("Host", Policy.hostBytes orig), ("X-Warlock-Api", "1")]
      check checksRef "distinct role origins"
        (length (nub (map Policy.originBytes [ctrlOrig, barOrig, popOrig])) == 3)
      forM_ [(Policy.Controller, ctrlOrig), (Policy.Bar, barOrig), (Policy.Popup, popOrig)] $ \(roleVal, orig) -> do
        HttpResponse codeNum hdrs bodyBytes <- httpExchange orig "GET" "/index.html" [("Host", Policy.hostBytes orig)] B.empty
        doc <- case filter ((== roleVal) . Config.documentRole) preparedDocs of
          [oneDoc] -> pure oneDoc
          _ -> ioError (userError "missing prepared role document")
        expectedCsp <- must (Policy.contentSecurityPolicy orig (Config.documentScriptHash doc) (Config.documentStyleHash doc))
        check checksRef ("exact held HTML and CSP for " ++ show roleVal)
          ( codeNum == 200
            && bodyBytes == Config.documentBytes doc
            && lookup "content-security-policy" hdrs == Just expectedCsp
            && lookup "x-content-type-options" hdrs == Just "nosniff"
          )
      -- Cross-origin and renderer source forgery refusals.
      let badCrossHdrs = ("Origin", Policy.originBytes ctrlOrig) : filter ((/= "Origin") . fst) (postHeaders barOrig "{}")
      HttpResponse crossCode _ _ <- httpExchange barOrig "POST" "/actions" badCrossHdrs "{}"
      check checksRef "cross-origin bar POST refused with 403" (crossCode == 403)
      let forgedBody = jsonBytes (jObj [("bridgeProtocol", J.JNumber "1"), ("kind", jTxt "native-event"), ("payload", jObj [])])
      HttpResponse forgedCode _ _ <- httpExchange barOrig "POST" "/actions" (postHeaders barOrig forgedBody) forgedBody
      check checksRef "renderer source forgery refused with 400" (forgedCode == 400)
      -- Trusted topology event + scoped commit + catalog + bar action + pin write.
      let topoPayload = jObj
            [ ("viewProtocol", J.JNumber "1")
            , ("kind", jTxt "view-topology")
            , ("revision", jTxt "1")
            , ("views", J.JArray [scopeJson])
            ]
      emit (Owner.OwnerTopology topoPayload) >>= must
      topoEvt <- pollOneControllerEvent ctrlOrig
      check checksRef "controller dequeues view-topology"
        (atKey "kind" topoEvt == jTxt "view-topology" && atKey "payload" topoEvt == topoPayload)
      let firstProj = scopedProjection (Just scopeJson)
          firstCommit = commitPayload firstProj [desktopReqJson "catalog-request" 1 []] ["focus-valid"]
      HttpResponse commit1Code _ _ <- httpExchange ctrlOrig "POST" "/commit" (postHeaders ctrlOrig firstCommit) firstCommit
      check checksRef "first persistent commit accepted" (commit1Code == 204)
      forM_ ["presentation", "announcements", "focus"] $ \expectedKind -> do
        HttpResponse barEvtCode _ barEvtBytes <- httpExchange barOrig "GET" "/events" (getHdrs barOrig) B.empty
        barPkt <- parseJson barEvtBytes
        check checksRef ("bar receives " ++ expectedKind)
          (barEvtCode == 200 && atKey "kind" barPkt == jTxt expectedKind)
      -- Receive application-attached + application-catalog over Fd 0 from PersistentBackendOwner.
      (evtA, evtB) <- pollTwoControllerEvents ctrlOrig
      check checksRef "first native reply is application-attached"
        (atKey "kind" evtA == jTxt "native-event" && atKey "kind" (atKey "payload" evtA) == jTxt "application-attached")
      check checksRef "second native reply is application-catalog"
        ( atKey "kind" evtB == jTxt "native-event"
          && atKey "kind" (atKey "payload" evtB) == jTxt "application-catalog"
          && atKey "requestId" (atKey "payload" evtB) == jTxt "1"
        )
      case modeVal of
        ModeUnqualifiedEngine -> do
          -- Honest unqualified engine negative control: never fabricate EngineResult True True.
          pure (Owner.EngineResult False False)
        ModeOrdinary -> do
          let actionBody = jsonBytes $ jObj
                [ ("surfaceProtocol", J.JNumber "2")
                , ("kind", jTxt "surface-query")
                , ("surface", jTxt "bar")
                , ("publication", jTxt "1")
                , ("lease", jTxt "0")
                , ("id", jTxt "launcher-search")
                , ("query", jTxt "alpha")
                ]
          HttpResponse actCode _ _ <- httpExchange barOrig "POST" "/actions" (postHeaders barOrig actionBody) actionBody
          check checksRef "bar surface-query action accepted" (actCode == 204)
          actEvt <- pollOneControllerEvent ctrlOrig
          check checksRef "controller receives view-action" (atKey "kind" actEvt == jTxt "view-action")
          let nextFrame = replaceKey "publication" (jTxt "2") (atKey "frame" firstProj)
              secondProj = replaceKey "frame" nextFrame firstProj
              pinWriteReq = desktopReqJson "taskbar-pins-write" 2 [("proposal", proposalJson "1" ["alpha"])]
              secondCommit = commitPayload secondProj [pinWriteReq] []
          HttpResponse commit2Code _ _ <- httpExchange ctrlOrig "POST" "/commit" (postHeaders ctrlOrig secondCommit) secondCommit
          check checksRef "second persistent commit (pins write) accepted" (commit2Code == 204)
          pinEvt <- pollOneControllerEvent ctrlOrig
          check checksRef "controller receives Saved taskbar-pins reply"
            ( atKey "kind" pinEvt == jTxt "native-event"
              && atKey "status" (atKey "payload" pinEvt) == jTxt "Saved"
              && atKey "revision" (atKey "preferences" (atKey "payload" pinEvt)) == jTxt "2"
            )
          _ <- Owner.requestPersistentUiStop uiStop
          shouldStopNow <- Owner.uiShouldStop endpoints
          check checksRef "requestPersistentUiStop latches uiShouldStop" shouldStopNow
          pure (Owner.EngineResult True True)
  totalChecks <- readIORef checksRef
  peerClosed <- Owner.persistentUiPeerClosed uiStop
  writePrivate obsPath $ jsonBytes $ jObj
    [ ("mode", jTxt (show modeVal))
    , ("checks", J.JNumber (T.pack (show totalChecks)))
    , ("peerClosed", J.JBool peerClosed)
    , ("uiPassed", J.JBool (Owner.uiPassed uiOutcome))
    , ("uiCleanup", J.JBool (Owner.uiCleanup uiOutcome))
    , ("uiEngineCleanup", J.JBool (Owner.uiEngineCleanup uiOutcome))
    , ("commits", J.JNumber (T.pack (show (Owner.uiCommitCount uiOutcome))))
    , ("actions", J.JNumber (T.pack (show (Owner.uiActionCount uiOutcome))))
    , ("nativeAcceptance", J.JBool False)
    , ("releaseAccepted", J.JBool False)
    ]
  unless (Owner.uiPassed uiOutcome) exitFailure

runSocketBoundaryChild :: String -> FilePath -> FilePath -> IO ()
runSocketBoundaryChild submode uiConfigPath obsPath = do
  enterPrivateNetwork
  case submode of
    "peer-close" -> do
      uiStopBudget <- must (Persistent.stopBudgetMicros 3000000)
      uiStop <- Owner.newPersistentUiStop uiStopBudget
      uiCfg <- Config.loadPersistentUiConfig uiConfigPath >>= must
      uiOutcome <- withPeerNetwork $ \witness ->
        Owner.runPersistentUiOwner witness uiCfg uiStop $ \endpoints _ -> do
          let ctrlOrig = Owner.controllerOrigin endpoints
          attEvt <- pollOneControllerEvent ctrlOrig
          unless (atKey "kind" attEvt == jTxt "native-event")
            (ioError (userError "expected native-event before clean peer close"))
          let waitPeerStop 0 = ioError (userError "clean peer close did not latch uiShouldStop")
              waitPeerStop n = do
                stoppingNow <- Owner.uiShouldStop endpoints
                if stoppingNow then pure () else threadDelay 5000 >> waitPeerStop (n - 1 :: Int)
          waitPeerStop 100
          pure (Owner.EngineResult True True)
      peerClosed <- Owner.persistentUiPeerClosed uiStop
      writePrivate obsPath $ jsonBytes $ jObj
        [ ("peerClosed", J.JBool peerClosed)
        , ("uiPassed", J.JBool (Owner.uiPassed uiOutcome))
        , ("uiCleanup", J.JBool (Owner.uiCleanup uiOutcome))
        ]
      unless (peerClosed && Owner.uiPassed uiOutcome && Owner.uiCleanup uiOutcome) exitFailure
    "truncated-gateway" -> do
      startDl <- deadlineAfter 3000000 >>= must
      opDl <- deadlineAfter 2000000 >>= must
      nativeEndp <- Native.adoptPersistentNative expectedBinding startDl
      recvRes <- try (Native.receivePersistentGateway nativeEndp (pure False) (pure opDl))
        :: IO (Either IOException Native.NativeReceive)
      retiredClean <- Native.retirePersistentNative nativeEndp
      let rejectedTruncated = case recvRes of
            Left _ -> True
            Right _ -> False
      writePrivate obsPath $ jsonBytes $ jObj
        [ ("rejectedTruncated", J.JBool rejectedTruncated)
        , ("retiredClean", J.JBool retiredClean)
        ]
      unless (rejectedTruncated && retiredClean) exitFailure
    _ -> ioError (userError "unknown socket-boundary submode")

runParentSuite :: FilePath -> IO ()
runParentSuite rootDir = do
  unsetEnv "WAYLAND_DISPLAY"
  unsetEnv "XDG_RUNTIME_DIR"
  existingEntries <- listDirectory rootDir
  unless (null existingEntries) (ioError (userError "fresh empty QA storage required"))
  checksRef <- newIORef (0 :: Int)
  selfExe <- getExecutablePath
  selfStat <- getSymbolicLinkStatus selfExe
  unless (isAbsolute selfExe && isRegularFile selfStat)
    (ioError (userError "test executable must be an absolute regular file"))
  selfBytes <- B.readFile selfExe
  let selfSha = shaHex selfBytes
      selfDev = show (deviceID selfStat)
      selfIno = show (fileID selfStat)
      selfSize = show (B.length selfBytes)
  selfAncestors <- mapM directoryPinJson (ancestorPathList selfExe)

  docsDir <- freshDir (rootDir </> "documents")
  let ctrlHtmlPath = docsDir </> "controller.html"
      barHtmlPath = docsDir </> "bar.html"
      popHtmlPath = docsDir </> "popup.html"
  writePrivate ctrlHtmlPath (compilerHtml "WarlockController" "body{margin:0}" "var controllerReady=1;")
  writePrivate barHtmlPath (compilerHtml "WarlockBar" "body{margin:0}" "var barReady=1;")
  writePrivate popHtmlPath (compilerHtml "WarlockPopup" "body{margin:0}" "var popupReady=1;")
  ctrlDocJson <- assetDocJson ctrlHtmlPath
  barDocJson <- assetDocJson barHtmlPath
  popDocJson <- assetDocJson popHtmlPath
  let documentsObj = jObj
        [ ("controller", ctrlDocJson)
        , ("bar", barDocJson)
        , ("popup", popDocJson)
        ]

  appsDir <- freshDir (rootDir </> "applications")
  writePrivate (appsDir </> "alpha.desktop") "[Desktop Entry]\nType=Application\nName=Alpha\nExec=/bin/true\n"
  appsPin <- directoryPinFact appsDir
  let appsPinJson = jObj
        [ ("path", jTxt (directoryPath appsPin))
        , ("device", jTxt (show (directoryDevice appsPin)))
        , ("inode", jTxt (show (directoryInode appsPin)))
        ]

  let runBackendCase :: String -> String -> IO (PersistentBackendRun, PersistentDelivery, Bool, J.Json, FilePath)
      runBackendCase caseName modeFlag = do
        caseDir <- freshDir (rootDir </> caseName)
        pinsDir <- freshDir (caseDir </> "pins")
        pinsPin <- directoryPinFact pinsDir
        let pinsPinJson = jObj
              [ ("path", jTxt (directoryPath pinsPin))
              , ("device", jTxt (show (directoryDevice pinsPin)))
              , ("inode", jTxt (show (directoryInode pinsPin)))
              ]
            uiCfgPath = caseDir </> "ui.json"
            backendCfgPath = caseDir </> "backend.json"
            obsPath = caseDir </> "observations.json"
        nowNs <- getMonotonicTimeNSec
        let dlJson = jTxt (show (toInteger nowNs + 8000000000))
            uiCfgObj = jObj
              [ ("schema", J.JNumber "1")
              , ("binding", bindingJson)
              , ("deadlineMonotonicNs", dlJson)
              , ("documents", documentsObj)
              ]
            selectedUiObj = jObj
              [ ("path", jTxt selfExe)
              , ("device", jTxt selfDev)
              , ("inode", jTxt selfIno)
              , ("size", jTxt selfSize)
              , ("sha256", jTxt selfSha)
              , ("arguments", J.JArray [jTxt "--persistent-ui-child", jTxt modeFlag, jTxt uiCfgPath, jTxt obsPath])
              , ("ancestors", J.JArray selfAncestors)
              ]
            backendCfgObj = jObj
              [ ("schema", J.JNumber "1")
              , ("applicationAttachment", J.JBool True)
              , ("binding", bindingJson)
              , ("deadlineMonotonicNs", dlJson)
              , ("ui", selectedUiObj)
              , ("catalogRoots", J.JArray [appsPinJson])
              , ("pinsRoot", pinsPinJson)
              , ("locale", jTxt "C")
              ]
        writePrivate uiCfgPath (jsonBytes uiCfgObj)
        writePrivate backendCfgPath (jsonBytes backendCfgObj)
        sessions <- newCurrentSessions
        stopBud <- must (Persistent.stopBudgetMicros 5000000)
        bOwner <- newPersistentBackendOwner sessions stopBud
        loadedCfg <- within (caseName ++ " load config") (loadPersistentBackendConfig bOwner backendCfgPath)
        check checksRef (caseName ++ " config loaded") (loadedCfg == Right ())
        bRun <- within (caseName ++ " run backend") (runPersistentBackend bOwner)
        bDeliv <- persistentBackendDelivery bOwner
        retiredOk <- within (caseName ++ " retire backend") (retirePersistentBackend bOwner)
        obsJson <- B.readFile obsPath >>= parseJson
        pure (bRun, bDeliv, retiredOk, obsJson, pinsDir)

  -- Case 1: Full end-to-end persistent application actor + same-owner UI native bridge.
  (ordRun, ordDeliv, _ordRetired, ordObs, ordPinsDir) <- runBackendCase "ordinary-pipeline" "ordinary"
  check checksRef "ordinary pipeline backend counts, delivery, and no startup refusal"
    ( persistentBackendCounts ordRun == (2, 2)
      && ordDeliv == DeliveryCompleted WrittenLocally
      && persistentBackendStartupRefusal ordRun == Nothing
    )
  check checksRef "ordinary pipeline reaps child ExitSuccess"
    (case persistentBackendOutcome ordRun of
      Right (PersistentBootstrapObserved (Right (_, Persistent.LeaderReaped ExitSuccess))) -> True
      _ -> False)
  check checksRef "ordinary pipeline UI child passed and cleaned up"
    ( atKey "uiPassed" ordObs == J.JBool True
      && atKey "uiCleanup" ordObs == J.JBool True
      && atKey "uiEngineCleanup" ordObs == J.JBool True
      && atKey "commits" ordObs == J.JNumber "2"
      && atKey "actions" ordObs == J.JNumber "1"
      && atKey "nativeAcceptance" ordObs == J.JBool False
      && atKey "releaseAccepted" ordObs == J.JBool False
    )
  savedPinsBytes <- B.readFile (ordPinsDir </> "taskbar.json")
  check checksRef "ordinary pipeline persisted taskbar.json"
    (savedPinsBytes == "{\"schema\":1,\"revision\":\"2\",\"identities\":[\"alpha\"]}")

  -- Case 2: Unqualified engine honesty negative control (EngineResult False False -> ExitFailure 1).
  (unqRun, _unqDeliv, _unqRetired, unqObs, _) <- runBackendCase "unqualified-engine" "unqualified-engine"
  check checksRef "unqualified engine child preserves ExitFailure 1 honestly"
    (case persistentBackendOutcome unqRun of
      Right (PersistentBootstrapObserved (Right (_, Persistent.LeaderReaped (ExitFailure 1)))) -> True
      _ -> False)
  check checksRef "unqualified engine child never claims uiPassed or uiEngineCleanup"
    ( atKey "uiPassed" unqObs == J.JBool False
      && atKey "uiCleanup" unqObs == J.JBool False
      && atKey "uiEngineCleanup" unqObs == J.JBool False
      && atKey "nativeAcceptance" unqObs == J.JBool False
    )

  -- Case 3: Socket boundary controls (clean NativePeerClosed vs truncated mid-frame refusal).
  let runForkedSocketCase :: String -> (S.Socket -> IO ()) -> IO (ProcessStatus, J.Json)
      runForkedSocketCase submode hostFeed = do
        caseDir <- freshDir (rootDir </> ("socket-" ++ submode))
        nowNs <- getMonotonicTimeNSec
        let uiCfgPath = caseDir </> "ui.json"
            obsPath = caseDir </> "obs.json"
            dlJson = jTxt (show (toInteger nowNs + 6000000000))
            uiCfgObj = jObj
              [ ("schema", J.JNumber "1")
              , ("binding", bindingJson)
              , ("deadlineMonotonicNs", dlJson)
              , ("documents", documentsObj)
              ]
        writePrivate uiCfgPath (jsonBytes uiCfgObj)
        bracket (S.socketPair S.AF_UNIX S.Stream S.defaultProtocol) (\(a, b) -> S.close a `finally` S.close b) $ \(hostSock, childSock) -> do
          childPid <- forkProcess $ do
            S.close hostSock
            S.withFdSocket childSock $ \rawFd -> do
              _ <- dupTo (Fd rawFd) (Fd 0)
              pure ()
            S.close childSock
            outcome <- try (runSocketBoundaryChild submode uiCfgPath obsPath) :: IO (Either SomeException ())
            exitImmediately (either (const (ExitFailure 1)) (const ExitSuccess) outcome)
          S.close childSock
          doneMVar <- newEmptyMVar
          _ <- forkFinally (hostFeed hostSock) (putMVar doneMVar)
          _ <- within ("host feed " ++ submode) (takeMVar doneMVar >>= either (ioError . userError . show) pure)
          let waitChild 0 = ioError (userError ("timed out waiting for socket child " ++ submode))
              waitChild n = do
                mbSt <- getProcessStatus False False childPid
                case mbSt of
                  Just stVal -> pure stVal
                  Nothing -> threadDelay 5000 >> waitChild (n - 1 :: Int)
          stVal <- waitChild 400
          obsJson <- B.readFile obsPath >>= parseJson
          pure (stVal, obsJson)

  framedAttach <- must (F.desktopGatewayPrefix (D.encodeDesktopGateway (D.applicationAttached expectedBinding)))
  (peerCloseSt, peerCloseObs) <- runForkedSocketCase "peer-close" $ \hostSock -> do
    N.sendAll hostSock framedAttach
    S.shutdown hostSock S.ShutdownSend
  check checksRef "clean boundary peer close latches persistentUiPeerClosed and exits 0"
    ( peerCloseSt == Exited ExitSuccess
      && atKey "peerClosed" peerCloseObs == J.JBool True
      && atKey "uiPassed" peerCloseObs == J.JBool True
      && atKey "uiCleanup" peerCloseObs == J.JBool True
    )

  (truncSt, truncObs) <- runForkedSocketCase "truncated-gateway" $ \hostSock -> do
    N.sendAll hostSock "\x00\x00"
    S.shutdown hostSock S.ShutdownSend
  check checksRef "truncated mid-header gateway fails closed rather than NativePeerClosed"
    ( truncSt == Exited ExitSuccess
      && atKey "rejectedTruncated" truncObs == J.JBool True
      && atKey "retiredClean" truncObs == J.JBool True
    )

  totalChecks <- readIORef checksRef
  putStrLn ("{\"schema\":1,\"suite\":\"persistent-ui-pipeline-controls\",\"passed\":true,\"checks\":" ++ show totalChecks ++ ",\"engineExecuted\":false,\"nativeAccepted\":false,\"releaseAccepted\":false}")

main :: IO ()
main = S.withSocketsDo $ do
  args <- getArgs
  case args of
    ["--persistent-ui-child", "ordinary", uiCfgPath, obsPath] ->
      runPipelineChild ModeOrdinary uiCfgPath obsPath
    ["--persistent-ui-child", "unqualified-engine", uiCfgPath, obsPath] ->
      runPipelineChild ModeUnqualifiedEngine uiCfgPath obsPath
    [storageDir] ->
      runParentSuite storageDir
    [] -> do
      tmpBase <- canonicalizePath =<< getTemporaryDirectory
      pidVal <- getProcessID
      nowNs <- getMonotonicTimeNSec
      let privRoot = tmpBase </> ("warlock-ui-pipeline-" ++ show pidVal ++ "-" ++ show nowNs)
      _ <- freshDir privRoot
      runParentSuite privRoot `finally` removeDirectoryRecursive privRoot
    _ -> ioError (userError "expected [] | [EMPTY_STORAGE] | [--persistent-ui-child MODE UI_CFG OBS]")
