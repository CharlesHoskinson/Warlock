# Omarchy Source & Controller Review: Pre-Userns `DisplayEnvironment` (`8210`)

- **Reviewer**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Bus Run**: `warlock-20261031-setup` (`lead` sole coordinator)
- **Reviewed Host Qualification Report**: `/home/charl/code/Warlock/.warlock-contributor/haskell-cpu-1793550462035880723/report.json` (`passed: true`, `manifestSHA256: 7a2c7706cbf05b3e68abd661c7789cd9ce9d24a5b714091176e6e6b275ac0a76`, `report.json` SHA-256 `d2a6b3a8bb8eec181a3e9bc5e4bdc1b820092245101d870b7c492d2ae8c4e6f2`)
- **Posture**: Preparation / source-bound review only. Zero source/model/tool edits, zero compiler/test/VM commands executed, `nativeOperations: []`, `15/242` whole requirements and `39/417` scenarios unchanged, historical `run-01` and `run-02-trace` preserved.

---

## 1. Verification of the 4-File `DisplayEnvironment` Fix & Post-Userns `overflowuid` (`65534`) Audit

1. **Pre-userns `DisplayEnvironment` capture (`Display.hs`, `ui/Main.hs`, `test-ui-display/Main.hs`, `runtime.cabal`) — Verified Sound**:
   - `captureDisplayEnvironment` (`implementation/warlock/haskell/runtime/src/Warlock/Ui/Display.hs:19-32`) runs in `warlock-ui-owner` (`implementation/warlock/haskell/runtime/ui/Main.hs:81`) **before** `enterPrivateNetwork` (`ui/Main.hs:83`), while root-owned ancestors `/run` and `/run/user` still report `st_uid == 0` instead of `65534` (`overflowuid`).
   - All ownership and mode guards remain unweakened (`Display.hs:93-128`): `/run` and `/run/user` require `fileOwner `elem` [0, uid]` and `fileMode .&. 0o022 == 0`; `/run/user/<uid>` requires `fileOwner == uid` and `0o700`; `/run/user/<uid>/<WAYLAND_DISPLAY>` requires `isSocket` and `fileOwner == uid`.
   - `DisplayEnvironment` (`Display.hs:5, 19`) exports its type and accessors (`displayRuntimeDir`, `displayWaylandName`) **without** exporting its data constructor, preventing unvalidated construction in production callers (`runBrokerMode` at `ui/Main.hs:34, 47`).
   - Adding `-with-rtsopts=-V0` to `ui-display-controls` (`implementation/warlock/haskell/runtime/runtime.cabal:131`) matches `warlock-ui-owner` (`runtime.cabal:36`) so GHC's RTS interval-timer OS thread does not trip the single-task `length tasks == 1` preflight in `PrivateNetwork.hsc:104` after `forkProcess` (`implementation/warlock/haskell/runtime/test-ui-display/Main.hs:53-57`).

2. **Downstream post-`enterPrivateNetwork` `overflowuid` (`65534`) audit (`ui/Main.hs:84-86`) — Verified Clean**:
   - `loadUiConfig` -> `readStartupFile` (`implementation/warlock/haskell/runtime/src/Warlock/Backend/Store.hsc:267-277`) traverses ancestor directories (`/` and `/home`, whose `st_uid` is now `65534`) with `O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC` **without** `st_uid == 0` assertions, and enforces `fileOwner == expectedUid` (`1000`, which **is** mapped in `uid_map`) only on the leaf `ui.json`.
   - `Owner.prepareDocuments` (`Owner.hs:249`) -> `Resolver.withRoot` (`implementation/warlock/haskell/held-document/src/Warlock/Platform/Resolver/Internal.hsc:76-92, 192-220`) pins `(st_dev, st_ino)` via `openat` + `O_NOFOLLOW` without root-ancestor UID checks. Neither `loadUiConfig` nor `prepareDocuments` will fail under the 1-UID user namespace.

---

## 2. Concrete New Omarchy-Specific Source Issues

### Issue S1 [HIGH — Omarchy Desktop Config/Cache/D-Bus Leakage Into `--engine-only` When `HOME` and `XDG_*_HOME` Are Omitted From `childEnv`]
- **Exact Source Locations**:
  - `implementation/warlock/haskell/runtime/ui/Main.hs:46-47` (`childEnv` supplies only `XDG_RUNTIME_DIR` and `WAYLAND_DISPLAY`)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc:739-747` (`sanitizedChildEnv` prepends only `LANG=C.UTF-8` and `LC_ALL=C.UTF-8`)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs:381, 421-426` (`gtk_init_check`, `mkdtemp "/tmp/warlock-filter-XXXXXX"`, `webkit_user_content_filter_store_new`)
- **Omarchy / GLib Mechanism**:
  1. When `HOME` and `XDG_{CONFIG,CACHE,DATA,STATE}_HOME` are absent from `environ`, GLib's `g_get_home_dir()` falls back to `getpwuid_r(1000)` in `/etc/passwd` -> `/home/charl`. Consequently, inside `warlock-ui-owner --engine-only` (`gtk_init_check` and WebKitGTK 6), GLib resolves:
     - `g_get_user_config_dir()` -> `/home/charl/.config`, causing GTK4 to parse Omarchy's live `/home/charl/.config/gtk-4.0/gtk.css` symlink into `/home/charl/.config/omarchy/current/theme/` (injecting host theme CSS into the undecorated GTK4 window chrome and coupling startup to live desktop theme files).
     - `g_get_user_cache_dir()` / `data_dir()` / `state_dir()` -> `/home/charl/.cache`, `/home/charl/.local/share`, `/home/charl/.local/state`, causing Mesa shader cache, Fontconfig cache, and WebKitGTK default `WebKitWebsiteDataManager` paths to read/mutate the live Omarchy user home directory during bounded trials.
  2. Passing host `XDG_RUNTIME_DIR=/run/user/1000` also exposes `/run/user/1000/bus` (live Omarchy `dbus-broker`, guest PID `824`) even when `DBUS_SESSION_BUS_ADDRESS` is unset, because GLib's `g_dbus_address_get_for_bus_sync(G_BUS_TYPE_SESSION)` automatically falls back to `unix:path=$XDG_RUNTIME_DIR/bus` (`/run/user/1000/bus`), allowing GTK4/WebKitGTK `xdg-desktop-portal` / `dconf` / `AT-SPI` traffic to reach the main Omarchy session bus.
  3. `childSetupExec` (`EngineCustody.hsc:581-588`) enters `CLONE_NEWNS` (`MS_REC | MS_PRIVATE`) and mounts a fresh `/proc`, but leaves `/tmp` bound to the guest host `/tmp`; because `WebKit.hs:361-365, 422-426` intentionally retains filter-store directories for WebKit async lifetime safety, each 3-surface run leaves three `warlock-filter-XXXXXX` directories in shared `/tmp`.
- **Source Remediation (for next declared source slice if needed; not blocking frozen `8210` diagnostic)**:
  - Point `HOME` and `XDG_{CONFIG,CACHE,DATA,STATE}_HOME` in `childEnv` (`EngineCustody.hsc:739-747` or `ui/Main.hs:46`) to an owned `0700` per-run directory (and optionally set `DBUS_SESSION_BUS_ADDRESS=disabled:` or mount a private `tmpfs` over `/tmp` inside `childSetupExec` after verifying WebKit `bwrap` compatibility).

### Issue S2 [HIGH — First Guest Execution of WebKitGTK 6 `bwrap` Inside 1-UID `CLONE_NEWUSER` + `CLONE_NEWPID` + `MS_NOEXEC /proc` + `NoNewPrivs=1`]
- **Exact Source Locations**:
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc:581-590` (`CLONE_NEWNS`, `MS_NOSUID | MS_NODEV | MS_NOEXEC` on `/proc`, `PR_SET_NO_NEW_PRIVS`, zero caps)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs:205, 427, 453-465` (`web-process-terminated` -> `loadFailed = True` -> `loop` exits before `stepMvpWindow`)
- **Concrete Risk & Diagnostic Signature**:
  - Historical `security-positive-01` (`Permissive.hs`) ran outside `enterPrivateNetwork` and `EngineCustody`; `security-negative-05-guard` exited before `gtk_init_check`; `155313Z/run-01` and `run-02-trace` failed at pre-fix `resolveDisplayEnvironment`. The upcoming `8210` trial is therefore the **first execution on Omarchy Arch (`webkitgtk-6.0`) of WebKit's `BubblewrapLauncher` (`/usr/bin/bwrap`) inside a 1-UID user namespace** (where `/usr`, `/lib64`, `/etc`, `/dev` report `st_uid == 65534` and `/proc` is mounted with `MS_NOEXEC`).
  - If `bwrap` or `xdg-dbus-proxy` fails inside the nested namespace, `onWebProcessTerminated` (`WebKit.hs:205`) sets `wsLoadFailed = True`, causing `WebKit.hs:462` (`any id failedFlags`) to exit `runMvpEventLoop` cleanly **before** `all id readyFlags` (`L465`) ever fires `stepMvpWindow` -> `Owner` commit RPC.
  - Consequently, `warlock-ui-backend` still observes `0` commits + `StreamEOF` (`exit: 1`) in `backend.stdout` — **identical on stdout** to a pre-GTK failure. Distinguish them immediately by `trial-result.json` `elapsed` (`<0.15s` = pre-GTK/broker abort vs `~0.35s–2.0s` + transient `/usr/bin/bwrap` or `WebKitWebProcess` in `observations.json` = WebKit sandbox failure) and `backend.stderr` (WebKit/bwrap writes failure reason to fd 2).

### Issue S3 [LOW/HARDENING — Pathname Re-Open of Wayland Socket Across Process Boundary Without Leaf Re-Stat in `--engine-only`]
- **Exact Source Locations**:
  - `implementation/warlock/haskell/runtime/src/Warlock/Ui/Display.hs:19, 53-55`
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineEntrypoint.hs:138-176` (`prepareEngine`)
- **Detail**:
  - `DisplayEnvironment` carries validated `(XDG_RUNTIME_DIR, WAYLAND_DISPLAY)` strings rather than a pre-opened socket/dir FD, and `gtk_init_check` (`WebKit.hs:381`) opens `$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY` by pathname inside `--engine-only`. Even after `enterPrivateNetwork` maps only UID `1000`, the leaf `/run/user/1000` (`0700`) and `/run/user/1000/wayland-1` (`isSocket`) **still** report `st_uid == 1000` (only `/run` and `/run/user` become `65534`), so `prepareEngine` could optionally re-verify leaf `(uid == expectedUid, mode == 0700, isSocket)` before `gtk_init_check` in a future hardening pass. Not a blocker for `8210`.

---

## 3. Concrete Overlay & Bounded-Controller Issues Before Running `8210`

### Issue C1 [HIGH — `engine-vm-display-overlay-8210.json` Offline Cabal Cache Mismatch vs Proven `build-engine.sh`]
- **Exact Locations**:
  - `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/engine-vm-display-overlay-8210.json:27` (`guestBuildCommands`)
  - `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-pid1-20261101T155313Z/build-engine.sh:5, 8, 12, 15`
- **Defect**:
  - `engine-vm-display-overlay-8210.json:27` creates an **empty** `$WARLOCK_NEW_RUN/cabal-home`, `repo-cache`, and `store` with `active-repositories: :none` and runs `cabal ... build --offline`. In `mvp-dynamic.project`, `cryptohash-sha256 == 0.11.102.1` and `network == 3.2.0.0` are resolved from the pre-populated guest cache in `/home/charl/warlock-mvp-20261101T1058Z/build-dynamic/cabal-home` (`build-dynamic/cabal.config`), **not** pre-installed global GHC packages — so an empty `cabal-home`/`repo-cache` under `--offline` will fail dependency resolution.
  - **Fix for Root's guest build script**: Follow Root's proven `155313Z/build-engine.sh:8,12` pattern (`export GHC_ENVIRONMENT=- CABAL_DIR="$WARLOCK_OLD_BUILD/cabal-home"` and `--config-file="$WARLOCK_OLD_BUILD/cabal.config"`) while pointing `--builddir="$WARLOCK_NEW_BUILD/dist"` and `assets/` at the brand-new post-`8210` directory so `build-dynamic` and `155313Z` remain untouched.

### Issue C2 [MEDIUM — Bounded Guest Controller (`live-controller-engine-01.py`) Checklist for First Mapped Window]
- **Exact Locations**: `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-pid1-20261101T155313Z/live-controller-engine-01.py:5-7, 51, 56, 65-77`
- **Verified Clean**:
  - `L67-68` (`eligible` + `visible`): In Linux `af_unix`, when `--engine-only` (inside child `CLONE_NEWPID`) connects to Hyprland's `/run/user/1000/wayland-1` (in ancestor init PID namespace), `SO_PEERCRED` translates `sk_peer_pid` via `pid_nr_ns(..., init_pid_ns)` to the **outer** guest PID `r['pid']`, while `/proc/<outer_pid>/status` reports `NSpid: <outer_pid> 1` (`namespacePids[-1] == 1`) with `(st_dev, st_ino)` matching `warlock-ui-owner`. Thus `visible` will accurately match the mapped Hyprland client without matching `bwrap` or `WebKitWebProcess`.
- **Concrete Controller Adjustments for New Run Directory**:
  1. **Do not wrap the primary window trial in `strace -ff`** (`live-controller-engine-02-trace.py:63`): `ptrace` interferes with WebKitGTK 6 `bwrap` namespace/seccomp setup and adds latency against the `4.5s` / `28s` source budgets. Run untraced first.
  2. **Stage `idle-before.json` in the new `BUILD` directory before invoking the controller** (`L51` reads `BUILD/'idle-before.json'` unconditionally and raises `FileNotFoundError` in a fresh `BUILD` directory if omitted).
  3. **Dismiss transient Quickshell toasts right after `isLocked == 'false'`** (`L56`): Call `command(['omarchy-shell','notifications','dismissAll'])` before starting `warlock-ui-backend` so notification overlays cannot occlude the tiled right-half window (`[647, 38] 621x750` next to `Foot 2095`) during `grim` (`L72`).
  4. **Avoid truncating `backend.stdout` right at `D` (`L65, 74-76`)**: Once the window maps, `--engine-only` stays alive until `EngineEntrypoint.hs:323-325` triggers `localStop` at `D - 1.0s` (`engineShutdownMarginNs = 1_000_000_000`). If GTK4/WebKitGTK `bwrap` teardown + broker/owner/backend reap spans slightly across `D` (or lands inside the `time.sleep(0.2)` poll at `L73`), `L74-76` immediately sends `SIGKILL` to `UNIT`, truncating `backend.stdout` (`backendResultJson`). Keep `deadlineMonotonicNs` (`D`) strictly unchanged in `ui.json`/`backend.json`, record `exitedByOriginalDeadline = (p.poll() is not None)` at `time.monotonic() >= deadline`, and allow a short separate post-`D` reap poll (`~0.8s`, explicitly recorded as `exitedByOriginalDeadline: False` if post-`D`) before `SIGKILL`ing `UNIT`.
