'use strict';
/* Source-only QA draft. Root must independently bind Elm sources, compiler,
 * this runner and a read-only staged JS artifact to the protected report.
 * Usage: node focus-surface-result-runner.cjs COMPILED_ELM_JS SHA256 QA_BUDGET_MS
 * Root supplies a positive budget within its existing outer protected cap.
 * The watchdog and observation window are QA-only; product deadlines are unchanged.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const expected = [
  'synthetic_notification_frame_accepted','bar_exact_current','popup_exact_current',
  'focus_only_is_focusable','focus_only_not_action_authority','disabled_popup_rejected',
  'disabled_bar_rejected','popup_as_bar_rejected','bar_as_popup_rejected','unknown_role_rejected',
  'unknown_dom_rejected','empty_dom_rejected','oversized_dom_rejected','control_dom_rejected',
  'stale_publication_rejected','future_publication_rejected','stale_lease_rejected',
  'future_lease_rejected','zero_publication_rejected','full_width_current',
  'overflow_publication_rejected','wrong_version_rejected','wrong_kind_rejected',
  'extra_field_rejected','missing_frame_rejected','actual_picker_opens','actual_picker_literal_target',
  ...['missing:','null:','wrong-type:'].flatMap(prefix =>
    ['focusProtocol','kind','surface','publication','lease','domId'].map(field => prefix + field))
];
function exactDataFields(value, names, label) {
  if (value === null || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    throw new Error(label + ': expected plain object');
  const keys = Reflect.ownKeys(value);
  if (keys.some(key => typeof key !== 'string')) throw new Error(label + ': symbol key');
  const actual = [...keys].sort();
  const want = [...names].sort();
  if (actual.length !== want.length || actual.some((key, i) => key !== want[i]))
    throw new Error(label + ': missing or extra field');
  const data = Object.getOwnPropertyDescriptors(value);
  for (const name of want) {
    const desc = data[name];
    if (!desc || !desc.enumerable || !Object.prototype.hasOwnProperty.call(desc, 'value'))
      throw new Error(label + ': hidden or accessor field ' + name);
  }
  return data;
}
let completed = false;
let watchdog = null;
process.on('beforeExit', () => {
  if (!completed) {
    fs.writeSync(2, 'FocusSurface QA: worker exited without result\n');
    process.exitCode = 1;
  }
});
async function main() {
  if (process.argv.length !== 5 || !/^[a-f0-9]{64}$/.test(process.argv[3]) ||
      !/^[1-9][0-9]{0,4}$/.test(process.argv[4]) || Number(process.argv[4]) > 60000)
    throw new Error('expected COMPILED_ELM_JS SHA256 QA_BUDGET_MS (1..60000)');
  const qaBudgetMs = Number(process.argv[4]);
  watchdog = setTimeout(() => {
    fs.writeSync(2, 'FocusSurface QA: protected QA budget elapsed without a completed result\n');
    process.exit(1);
  }, qaBudgetMs);
  const artifact = path.resolve(process.argv[2]);
  const sha256 = crypto.createHash('sha256').update(fs.readFileSync(artifact)).digest('hex');
  if (sha256 !== process.argv[3]) throw new Error('compiled artifact hash mismatch');
  const output = require(artifact);
  const worker = output && output.Elm && output.Elm.FocusSurfaceBoundaryReplay;
  if (!worker || typeof worker.init !== 'function') throw new Error('missing Elm worker');
  const app = worker.init({flags:null});
  if (!app.ports || !app.ports.outgoing || typeof app.ports.outgoing.subscribe !== 'function')
    throw new Error('missing outgoing port');
  const result = await new Promise((resolve, reject) => {
    let seen = 0;
    let timer = null;
    app.ports.outgoing.subscribe(value => {
      if (++seen !== 1) {
        if (timer !== null) clearTimeout(timer);
        reject(new Error('duplicate output within observation window'));
        return;
      }
      timer = setTimeout(() => resolve(value), 25);
    });
  });
  const fields = exactDataFields(result, ['scope','checks'], 'result');
  if (fields.scope.value !== 'synthetic renderer focus instruction; no native focus authority')
    throw new Error('unexpected fixture scope');
  const checks = exactDataFields(fields.checks.value, expected, 'checks');
  for (const name of expected) if (checks[name].value !== true) throw new Error('failed check: ' + name);
  clearTimeout(watchdog);
  watchdog = null;
  completed = true;
  fs.writeSync(1, JSON.stringify({scope:'synthetic renderer focus; not native focus proof',
    artifact,sha256,checks:expected.length,duplicateObservationWindowMs:25,qaBudgetMs}) + '\n');
  process.exit(0);
}
main().catch(error => {
  if (watchdog !== null) clearTimeout(watchdog);
  watchdog = null;
  completed = true;
  fs.writeSync(2, 'FocusSurface QA: ' + String(error && error.message || error) + '\n');
  process.exit(1);
});
