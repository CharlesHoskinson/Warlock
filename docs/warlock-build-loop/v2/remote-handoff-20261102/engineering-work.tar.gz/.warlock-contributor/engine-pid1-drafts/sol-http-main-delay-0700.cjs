'use strict';
// Independent owning HttpMain expectations from the already authored and
// qualified literal policy table, never a reducer capture. Root executes only.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PIN = '41e3ccabc5843153b604205dd937c56890f659e294929788a959951d39b7bcb7';
const C = (tag,...args) => Object.fromEntries([['$',tag],...args.map((value,index)=>[String.fromCharCode(97+index),value])]);
const L = values => values.reduceRight((tail,head)=>C('::',head,tail),C('[]'));
const N = () => C('Nothing');
const J = value => C('Just',value);
const JSONV = value => ({$:0,a:value});
const SUB = () => ({$:2,m:C('[]')});
const D = (module,effects) => ({module,effects});
const H = effects => D('UiHttp',L(effects));
const READ = () => C('ReadEvents');
const SEND = packet => C('SendController',JSONV(packet));
function http(active=null,pending=[]) {
  return C('Model',{role:C('Controller'),pending:L(pending.map(JSONV)),
    active:active===null?N():J(JSONV(active)),polling:true,failed:N()});
}
const STATE = (policy,transport) => ({policy,http:transport});
const RET = (transport,effects,event=N()) => ({kind:'transition',value:C('#3',transport,L(effects),event)});
const EXPECT = (state,descriptions,transportReturns) => ({state,subscriptions:SUB(),descriptions,transportReturns});
function onePublish(effects) {
  if (effects.$!=='::' || effects.a.$!=='Publish' || effects.a.a.$!==0) throw Error('literal Publish expected');
  return effects.a.a.a;
}
function build(repository) {
  const filename=path.join(repository,'implementation/warlock/qa/tea-contract-cases.cjs');
  if(crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex')!==PIN) throw Error('independent literal source changed; explicit rebase required');
  const oracle=require(filename);
  const names=['launch-delay-exact-timeout-and-stale-token','launch-delay-stale-after-matching-submitted'];
  const cases=names.map(name=>{
    const source=oracle.cases.find(item=>item.name===name);
    if(!source) throw Error('complete independent named launch fixture missing');
    const policy=oracle.materialize(source);
    const [reset,given,start,fourth,fifth]=policy.steps;
    if(reset.input.kind!=='reset'||given.input.kind!=='prelude'||given.input.values.length!==5||given.setupTimers!==0||start.input.kind!=='incoming') throw Error('pinned named GIVEN shape changed');
    // Assert the literal complete Delay, including its full domain token;
    // a tag-only or duration-only expectation would silently weaken this test.
    const effects=start.expected.effects;
    if(effects.$!=='::'||effects.b.$!=='::'||effects.b.b.$!=='[]'||effects.b.a.$!=='Delay'||effects.b.a.a!==10000||effects.b.a.b.$!=='Deadline'||effects.b.a.b.a.$!=='PendingToken') throw Error('full source Delay message/token missing');
    const pendingPacket=onePublish(effects);
    const initial=http();
    const pendingHttp=http(pendingPacket);
    const prelude=given.input.values.flatMap(value=>[
      {kind:'polledOk',body:JSON.stringify(value)}, {kind:'postedOk',body:''},
    ]);
    // Ten actual owning transitions INITIALIZE the named GIVEN. No manually
    // assigned/private constructor model. Intermediate setup has no separate
    // literal oracle and is never reported as ten tested transitions. Its
    // complete trace is serialized/guarded and compared across fresh runs;
    // the final COMPLETE GIVEN below is independently asserted.
    const setupExpected=EXPECT(STATE(given.expected.state,initial),[H([])],[RET(initial,[])]);
    const steps=[
      {input:{kind:'init'},expected:EXPECT(STATE(reset.expected.state,initial),[H([READ()])],
        [{kind:'startup',value:C('#2',initial,L([READ()]))}])},
      {input:{kind:'polledOk',body:JSON.stringify(start.input.value)},
        expected:EXPECT(STATE(start.expected.state,pendingHttp),[
          H([READ()]),D('DesktopPolicy',effects),D('HttpMain.effects',effects),H([SEND(pendingPacket)]),
        ],[RET(initial,[READ()],J(C('Incoming',JSONV(start.input.value)))),RET(pendingHttp,[SEND(pendingPacket)])])},
    ];
    if(name==='launch-delay-exact-timeout-and-stale-token') {
      if(fourth.input.kind!=='deadline'||fifth.input.kind!=='deadline') throw Error('literal deadline sequence changed');
      const unknownPacket=onePublish(fourth.expected.effects);
      const uncertain=http(pendingPacket,[unknownPacket]);
      steps.push({input:{kind:'deadline',index:0},expected:EXPECT(STATE(fourth.expected.state,uncertain),[
        D('DesktopPolicy',fourth.expected.effects),D('HttpMain.effects',fourth.expected.effects),H([]),
      ],[RET(uncertain,[])])});
      steps.push({input:{kind:'deadline',index:0},expected:EXPECT(STATE(fifth.expected.state,uncertain),[
        D('DesktopPolicy',fifth.expected.effects),D('HttpMain.effects',fifth.expected.effects),
      ],[])});
    } else {
      if(fourth.input.kind!=='incoming'||fifth.input.kind!=='deadline') throw Error('literal matching receipt sequence changed');
      const submittedPacket=onePublish(fourth.expected.effects);
      const submittedHttp=http(pendingPacket,[submittedPacket]);
      steps.push({input:{kind:'polledOk',body:JSON.stringify(fourth.input.value)},
        expected:EXPECT(STATE(fourth.expected.state,submittedHttp),[
          H([READ()]),D('DesktopPolicy',fourth.expected.effects),D('HttpMain.effects',fourth.expected.effects),H([]),
        ],[RET(pendingHttp,[READ()],J(C('Incoming',JSONV(fourth.input.value)))),RET(submittedHttp,[])])});
      steps.push({input:{kind:'deadline',index:0},expected:EXPECT(STATE(fifth.expected.state,submittedHttp),[
        D('DesktopPolicy',fifth.expected.effects),D('HttpMain.effects',fifth.expected.effects),
      ],[])});
    }
    return {name:'HttpMain-full-wrapper-'+name,root:'HttpMain',setupPrelude:prelude,setupExpected,steps};
  });
  return {cases};
}
module.exports={schema:1,build,coverage:{complete:false,roots:['HttpMain'],
  scope:'exact complete Model/Sub.none/every typed Publish and Delay with domain message/token; independent named GIVEN',
  limits:['unexecuted source proposal; Root-only protected ordinary compiled owning-root replay',
    'ten named initializer transitions per run are NOT counted as independent tested transitions',
    'final named GIVEN and every TESTED transition have full independent literal state/effect assertions',
    'actual previously described timer message is input to owning callback; no token or model constructor forged',
    'timer scheduling/elapsed time and HTTP interpretation require separate optimized runtime tests',
    'synthetic native receipt is a pure boundary positive, never actual provider/native/GUI/release acceptance']}};
