# Frozen All-Elm Website Improvement Patch, Manifest & Source Peer Review (`20261101T225558Z`)

- **Authenticated Identity**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run / Session**: `warlock-20261031-setup`
- **Target Published `HEAD`**: `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70` (`Retain read-only search drafts when popup transport fails`)
- **Canonical Ledger Disposition**: `17 / 242` whole EARS requirements accepted, `41 / 417` scenarios accepted; persistent native desktop and release remain **unaccepted** (`HOSTSTOP2` and `nativeOperations = []` preserved).
- **Foreign Main-Worktree Preservation**: `/home/charl/code/Warlock/site/src/SiteMain.elm` untouched at `sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (`68,121` B, git blob `f10e6cdade8b945605d1ba5a3d6ff1404cd4e233`).

---

## 1. Frozen Website Deliverables & Preimage / Postimage Manifest

Machine-readable manifest: `.warlock-contributor/engine-pid1-drafts/gemini-site-frozen-website-manifest-2255.json` (`sha256:ec9d4dd78a418d7c9ebb8fe684d384ec20226e5fdb3b31570c4bc292ca4b5ef5`, `7,544` B).

| Artifact | Preimage (`HEAD` `a30ad9e9f`) | Frozen Postimage / Patch SHA-256 | Bytes / Git Blob OID |
| :--- | :--- | :--- | :--- |
| `SiteMainHeadProd2255.patch` (single all-Elm production patch) | `site/src/SiteMain.elm`: `9c432ddf2b7e4d35fae4197c52c4b97cb41fbfa16b45082d2143ea4d6b2d3ba1` (`63,706` B, blob `a18279ec...`) | `eac813a141c1a55a7dd3586208a654abad336231420290b55fd500831df89222` | `53,759` B (`a8ea0f6274a28b41e47a05b6e70f050b3f286ab5`) |
| `SiteMainHeadProd2255.elm` (exact postimage) | `site/src/SiteMain.elm`: `9c432ddf2b7e4d35...` | `7d3b290df79853b61189d7e938dfaff7afb5a3a0f8ca13629ff5dabdcd50feed` | `94,749` B (`fefc76aa9155275544e8bae4a0f1936977b1971b`) |
| `site-browser-acceptance-homepage-2255.patch` (canonical fixture update) | `browser-acceptance.py`: `4ca35e11...` (`35,428` B); `test-browser-acceptance.py`: `19e810d2...` (`1,579` B) | `e47d8d917f61c814c92873bc286bd124b261b9a0f743e641845be6ee12ce7a1a` (postimages `f3488e7a...` / `8aed55dd...`) | `7,434` B (`7da9cd7be62521a2640680b914553a1e965f292e`) |
| `SiteMainHeadFixture2255.elm` (pure-Elm replay oracle) | — | `1ea11c442450daf10561f7063da6f6374128e6fffe8bbef0a74ed766216d6255` | `16,391` B (`357f854e8c39211e34a20cf0f8b5d60fc9eb3648`) |
| `site-head-mvp-usability-qa-2255.cjs` (controlled-DOM + WCAG oracle) | — | `5bd0b79d1527710c4beba3f75856206671d77c2b2487640cd8a34846f45c5770` | `27,459` B (`b0215ca8d8a7bf5894b3687a1c2652fee5d3b48a`) |

### Beta Capability & Genuine-Run Accuracy (`#run-beta` + `#wl-mvp-matrix`)
1. **Zero mock product & zero unverified runnable/download claims**:
   - Replaces ambiguous `"Try the desktop"` nav label and present-tense native-shell hero copy with explicit `"Test drive (simulated)"`, `"Run & beta status"`, and scoped beta-integration copy; updates `#workbench` and `#features` intros so the 8 compiled Elm surfaces in the simulated stage are never mistaken for live native Hyprland window/workspace mutations (`nativeOperations = []`).
   - Adds `#wl-run-no-download` (`"No desktop binary · Design tokens only"`), explicitly stating that no Omarchy package, binary archive, AppImage, or desktop installer exists yet and that `./get-started/index.html#downloads` distributes Lacquer CSS/JSON design tokens, licensed web fonts, and SVG brand marks only (`ELM-DEL-011` and `ELM-DEL-014` remain OPEN).
2. **Accurate genuine-run paths (`betaRunTracks : List BetaRunSpec` in `#run-beta`)**:
   - **Browser preview (`#wl-run-browser`)**: 16 seeded scenarios at `./test-drive/index.html` running compiled Elm `Main`, `Bar`, and `Popup` over simulated desktop state and fixture client interiors.
   - **Offline contributor & protected Root build (`#wl-run-source-check`)**: `python3 -B plugins/warlock-contributor/scripts/warlock.py status` / `check --project-only` (Python 3.9+ QA tool only; zero Python ships in product) plus serialized `qa_run.py` frontend/Haskell offline compilation (`docs/warlock/how-to/build-current-frontend.md`, Elm 0.19.2 + GHC 9.6.7 / Cabal 3.12.1.0 across 6 Cabal packages).
   - **Standalone Omarchy Wayland beta trial (`#wl-run-omarchy-trial`)**: Documents `docs/warlock/how-to/run-omarchy-mvp.md` accurately—offline guest compilation of `warlock-ui-owner` + `warlock-ui-backend` (`--offline`, `active-repositories: :none`, dynamic GHC ABI against guest `gtk4` + `webkitgtk-6.0`, never copying host ELFs across ABIs), fresh `0700` `$RUN_DIR` (`O_DIRECTORY | O_NOFOLLOW`, `"applicationAttachment": true`, no `WEBKIT_*` or proxy env vars), and non-renewable `D <= 28s` (`CLOCK_MONOTONIC <= 30s`) deadline. States both active `--application-only` capabilities (`.desktop` catalog search across 63 regular entries with symlinks skipped, durable pin writes, physical `Escape`, and `HttpPopup` read-only search/path retention on HTTP transport failure without auto-reconnect/replay/restart button) and retained limits (`nativeOperations = []`, `HOSTSTOP2`, `warlock-ui-backend` exit `1` / `passed=false` pending WebKit filter-store retirement and provider confinement, unaccepted live Refresh/AT/IME/latency/release).
3. **Static & stdlib checks verified without worker compiler/browser execution**:
   - `0`-offset `git apply --check -v` against `a30ad9e9f:site/src/SiteMain.elm` (`9c432ddf...`) and `site/tools/{browser-acceptance,test-browser-acceptance}.py` (`4ca35e11...` / `19e810d2...`).
   - `80/80` relative URLs and `#fragment` targets inside `site/` verified on disk; `10/10` internal `#fragment` anchors verified; `23 manifests, 276 declared assets, 0 errors` in read-only `site/tools/check-contracts.py --root site`; `6/6` stdlib unit tests passing in `site/tools/test-browser-acceptance.py`.
   - `48/48` WCAG 2.1 contrast pairs across Night, Dawn, and High Contrast verified `>= 5.87:1` (`2.75rem` / `44px` touch targets, `320px`/`768px`/`1180px`/`1440px` overflow clipping, roving `tablist` + `Dom.focus`, strict missing-only `isComposing`/`229`/`"Process"` IME guard, and mobile drawer `Escape` focus return to `#wl-home-nav-toggle`).

---

## 2. Isolated-Worktree Integration Steps for Root

1. **Create isolated detached worktree from committed `HEAD`** (keeps main-worktree foreign `site/src/SiteMain.elm` `f05a3768...` untouched):
   ```bash
   git -C /home/charl/code/Warlock worktree add --detach /tmp/warlock-site-2255 a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70
   ```
2. **Verify and apply the frozen all-Elm patch & acceptance-fixture patch**:
   ```bash
   git -C /tmp/warlock-site-2255 apply --check -v \
     /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2255.patch \
     /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-browser-acceptance-homepage-2255.patch
   git -C /tmp/warlock-site-2255 apply \
     /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2255.patch \
     /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-browser-acceptance-homepage-2255.patch
   ```
3. **Compile `SiteMain.elm` to JS under Root's offline Elm 0.19.2 cache and preserve `site/index.html`'s Lacquer shell** (important: bare `elm make --output=index.html` strips `<html lang="en" data-warlock-design="v1" data-theme="night">`, `<meta name="viewport" content="width=device-width, initial-scale=1">`, and `<body data-page="index.html" data-root="./" class="wl-landing-page">`; compile to `/tmp/warlock-site-2255/sitemain.js` and splice into `site/index.html`'s `<script>try { ... var app = Elm.SiteMain.init({ node: document.getElementById("elm") }); } catch (e) { ... }</script>` wrapper).
4. **Run controlled-DOM, contract, and unit checks**:
   ```bash
   node /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-head-mvp-usability-qa-2255.cjs \
     /tmp/warlock-site-2255/site/index.html \
     /tmp/warlock-site-2255/site/assets/shared/tokens.css \
     /tmp/warlock-site-2255-dom-report.json
   python3 -B /tmp/warlock-site-2255/site/tools/check-contracts.py --root /tmp/warlock-site-2255/site
   python3 -B /tmp/warlock-site-2255/site/tools/test-browser-acceptance.py
   ```
5. **Run Playwright browser acceptance** (exercises all 16 simulated scenarios plus the new `homepage()` check at `320px`/`768px`/`1440px`):
   ```bash
   python3 -B /tmp/warlock-site-2255/site/tools/browser-acceptance.py \
     --root /tmp/warlock-site-2255/site \
     --output /tmp/warlock-site-2255-browser-report.json
   ```

---

## 3. Source Peer Review of Active GUI / Model / DOM Deltas

1. **Active Root Integration Candidate — `Popup.elm` (`sha256:a9f188f9...`) + `local-field-publication.qnt` (`sha256:3c102fe4...`) + `ui-http.cjs` (`sha256:cd25171a...`) + `LocalFieldReplay.elm` (`sha256:d70d23bc...`) + `typed-state.cjs` (`sha256:eb348e9e...`) — CONCUR**:
   - **Exact 1-to-1 reducer/model correspondence**: In `Popup.elm:108-118`, `surface-composition-end` with `query == held.baseline` branches on `held.before`:
     - `Nothing`: sets `{ model | composition = Idle, pendingQuery = Nothing }, []`, matching Quint `endPreedit` when `not(s.beforePending)` (`draft = s.acceptedText`, `pending = false`, `dispatches` unchanged) and `cancelCleanEnd` (`0` POSTs, intervening `P2` revealed).
     - `Just prior`: builds `restored = { model | composition = Idle, pendingQuery = Just prior }` and evaluates `Presentation.query prior restored.presentation |> Maybe.map (\priorWire -> sendQuery prior priorWire restored)`. Because `s.composing` in `local-field-publication.qnt` strictly implies `s.visible && s.fieldActive` across all transitions (`init`, `beginPreeditAt`, `malformedPresentation`, `retireField`, `reopen`, `recoverField`), `Presentation.query` always succeeds in reachable states and `sendQuery` matches Quint's `unsettledHere`, `duplicate(s.priorText)`, `lastPub/lastLease/lastText`, and `dispatches` rules across all four regimes:
       1. Same-scope reversion (`cancelSameEnd` / `cancelledSameScopeReversionRetainsIntentWithoutDuplicateTest`): `key == restored.lastQuery` prevents a duplicate `P1` POST while keeping `pendingQuery = Just prior` so a subsequent `P2` triggers the current-scope rebase.
       2. Newer unmatched frame during composition (`cancelAheadEnd` / `cancelledPriorPendingRebasesAfterNewerFrameTest`): emits `[Dispatch priorWire]` under `P2` immediately on cancel.
       3. Stale painted DOM baseline (`cancelDifferentEnd` / `staleDomBaselineRestoresDistinctPriorPendingUnderCurrentScopeTest`): restores `held.before` (`b`) rather than stale DOM baseline (`a`) under `P2`.
       4. Newer frame already matching `prior` (`cancelledPendingAlreadyMatchedNewerFrameDoesNotDispatchTest`): `not unsettledHere && unchanged` settles `pendingQuery = Nothing` with `0` redundant dispatches.
   - Repeated `surface-composition-start` (`Popup.elm:102-103`) captures `before = model.pendingQuery`, matching `beginPreeditAt` (`priorText: if (s.pending) s.draft else -1`) and `repeatedCompositionStartRetainsImmediatelyPriorDraftTest`.
2. **`gemini-gui` Pure View-Style-Only `HttpPopup` (`sha256:6be4abc3...`, `cd25` bundle `sha256:41eb9bc4...`) & `Bar` Waiting-Placeholder (`cd25` bundle `sha256:852b18b6...`, combined `sha256:dc7f6ebe...`) — CONCUR**:
   - Verified `0`-offset `git apply --check -v` against `a30ad9e9f` `HttpPopup.elm`/`Bar.elm` + live `cd25171a` `ui-http.cjs`.
   - `6be4abc3...` resolves the `ELM-ARC-024` / `WebKit.hs:448-462` `loadFailed` + `HANDOFF.md:469` reload-button hazard cleanly: `HttpPopup.Msg` and `HttpPopup.update` stay identical to `a30ad9e9f` (zero reload button, passive `data-transport-recovery="passive"` host-restart guidance), while `SurfaceTheme` (`popupRootStyles`, `popupStatusStyles`, `searchLabelStyles`, `searchFieldStyles ... True`) brings `200%` textScale (`max(1rem, 32px)`), Night/Dawn/High-Contrast tokens, and `>= 15.8:1` contrast to the stopped transport view.
3. **Public Documentation Drift Note (`README.md:153-155`, currently `lead`-claimed)**:
   - While `README.md:13` already reflects `17` whole verdicts, `README.md:155` still reads `"39 accepted scenarios ... whole-requirement acceptance remains 15 of 242"` (pre-`TEA002`/`TEA005`) and `README.md:15` predates the `a30ad9e9f` `13`-input `foot`/`footz` `28s` VM observation. Flagged for Root's `README.md` claim without worker edits.
