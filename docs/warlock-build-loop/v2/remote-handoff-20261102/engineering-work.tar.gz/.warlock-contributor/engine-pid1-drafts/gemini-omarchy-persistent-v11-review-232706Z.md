# Persistent Custody Prerequisites `v11` Consolidation (`232706Z`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Base Canonical `HEAD`**: `bdeac73491a05d6c61932642b184c20b44f0e80e` (also applies cleanly to `e5ce2487c8ec67ced1405dc0d3219c6f39effc5a`; verified `git apply --check` and `patch --dry-run -p1 --fuzz=0`)
- **Execution Status**: **UNEXECUTED SOURCE PROPOSAL** (Root retains all GHC/Cabal/Quint/Elm/VM/GPU/native execution).
- **Preserved Counts & Gates**: `17/242` whole EARS, `41/417` scenarios, `28s`/`30s`/`5s`/`500ms`/original `D`, `HOSTSTOP2`, `nativeOperations = []`.

## Frozen Artifacts (`v11`, Preserving `v6` / `v7` / `v8` / `v9` / `v10` Immutable)

- `gemini-omarchy-persistent-custody-v10-to-v11-delta-232706Z.patch`: `sha256:ab06d3b3bf914b93c960fe75ce66df2dea253e7eaed563178fc383e06d799002`
- `gemini-omarchy-persistent-custody-prereqs-v11-232706Z.patch`: `sha256:f661f6eb5c92f0e6238921b7c35de0ab57d906a59c669a8d03141b91cab1dca8`
- Preserved `v10` full patch (`232706Z`): `sha256:420bf001311fa1849afbb82066d0582959af4de3a7773d7aec1711ed54958861` (delta `7f19e67dad6b1245f42925c2b616d283ac9e237f22d348dafc84230020d5d6a8`)
- Preserved `v9` full patch (`232706Z`): `sha256:d9c7d29f78215ea70b444afe399ad3aa9dc85a5461535c919f1ce0b5cb3554e6` (delta `0f3fba9802f6b569d4db3731d99cba116ecaba819a48c9fed9bf3d77652cf02e`)
- Preserved `v8` full patch (`225558Z`): `sha256:76fe15f4f66a26e6669662d6fb630fe4b207c31e6bc3322866618f50e0d1e93c`
- Preserved `v7` full patch (`225558Z`): `sha256:5aba617d4adbce8db604beefff8f9260ee2108a8c2c4b4b7795e5aaf892fd1b0`
- Preserved `v6` full patch (`220528Z`): `sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`

## Three Peer-Reviewed `v10` Refinements Closed in `v11` (`Executable/Internal.hs` Unchanged at `e14ace50`)

1. **Removed Unguarded `qaOverrideBorrowRelease` Ownership Mutator (`terra-q-lifetime`, `sol-docs`)**:
   - Deleted `qaOverrideBorrowRelease` completely from `Warlock.Capture.Process.Persistent.Internal` so zero non-CPP test mutator can ever replace `borrowReleaseCell` in production builds.
   - Exported only the pure, stateless receipt classifier `borrowReleasedReceipt :: Either SomeException (Maybe Bool) -> Bool` (`Right (Just True) -> True; _ -> False`) from package-private `Persistent.Internal`, tested in Control **#21** alongside Control **#20** (`releaseBorrowBounded` deadline expiry) and `terra-engine`'s `-DWARLOCK_BORROW_QA` `BorrowCancelUnknownControls.hs` (`sha256:8c21a595ea0b64e3e242d50ad4ca8af806d3ec1f87c15bb125502228e3c23239`) + `terra-engine-borrow-cancel-unknown-seam.patch` (`sha256:5c43317213c2318e90ad563a5d402cedaccef8647534ef1ac232fe1fb5beace8`, verified zero-fuzz / zero-offset `git apply --check` and `patch -p1 --fuzz=0` on `v11`'s unchanged `Executable/Internal.hs` `e14ace50`).

2. **Pre-Registered Outer `IORef` + Unreleased GHC RTS `StablePtr` Across Exceptions & Spine Evaluation (`terra-vm`, `terra-security`)**:
   - `DeadlineStop.main` now allocates `outerRegistry :: IORef [(PersistentOwner, StablePtr PersistentOwner)]` *before* calling `runPersistentControlsWithRegistry outerRegistry child`, and `allocOwner` registers every one of the 24 test `PersistentOwner`s + an unreleased `Foreign.StablePtr.newStablePtr` *at allocation time, before acquisition/spawn begins* (including inside the 1-arg `runPersistentControls` wrapper).
   - This guarantees strong GHC RTS GC retention across both mid-flight exceptions and post-assertion spine evaluation through suite exit (`24` registered: `15` `PersistentQuarantined` + `9` `PersistentRetired`), while explicitly stating in both code and review that process exit + `waitid(WNOWAIT)` zombie self-exit are *not* owned child-reap, GHC event-manager deregistration, or pipe/pidfd closure receipts (referring Root to `terra-vm-fixture-registry-0001.hs` / `WarlockFixtureRegistry` for bounded outer guardian coordination).

3. **Exact Two-Stage `closeOwnedPidfdDl` Comment & In-Region `CloseUncertain` Semantics (`terra-graph`, `terra-q-front`)**:
   - Corrected the comment in `closeOwnedPidfdDl` to match exact code order: `leftBeforeSyscall` checks `closeDl > 0` *before* `O.pendingMarkFD pending pfd False` (rolling back to `InternalPidfdKnownOpen` on pre-entry expiry, verified by Controls **#18d** and **#18e**), whereas `leftAtClose` re-samples `closeDl` *after* `O.pendingMarkFD pending pfd False` and `hook "persistent-in-pidfd-close"` immediately before `closeFd pfd` (conservatively recording `InternalPidfdCloseUncertain` without calling `closeFd` if expired inside the `PendingUncertain` region; bounded up to OS scheduler preemption between user-space sample and `close(2)` entry).

## Retained `v9`/`v10` Closures & Explicit Open Follow-Ons

- **`HeldExecutable` Sticky 3-State Borrow Release (`terra-security` `1b9138c0`, `terra-q-lifetime`)**: `Executable/Internal.hs` remains byte-identical at `sha256:e14ace50e91327659ac6e5615c12bcd338542c303a43a738d6127668635aa8b9` (masked `borrowHeld` + `onException release`; masked-interruptible `takeMVar` without `restore`; sticky `BorrowPending | BorrowReleased | BorrowUnknown`; `borrowReleasedReceipt` requiring `Right (Just True)` at all 3 `Persistent/Internal.hs` sites).
- **Startup `borrowHeld` Gate Contention (`terra-graph-persistent-borrow-acquire-2357.md`)**: Carries an explicit `engine/security` peer-review HOLD on `abortBeforeBorrow` phase ordering (`PhaseRetired` before confirmed `O.abortBegin`) and remains an open follow-on outside `v11`.
- **Contended Release Strict `completedNs <= D` Oracle (`terra-engine-held-gate-contention-controls.hs`)**: `v11` prevents unbounded `uninterruptibleMask_` blocking and late `O.settle`; returning strictly `<= D` after `System.Timeout.timeout` wakeup remains an open Root reserve/scheduler question.
- **Downstream Unimplemented Production Callsites**: `ui-engine` `Channel.hs` (`TrustedPump` / `SocketOwner` `LiveSession` integration) and persistent app-session launch supervision remain separate downstream slices gated on Root's protected `cabal test` qualification of `held-document` + `process-custody`.
