# Engine retirement: source-bound route (preparation, not acceptance)

Scope: current PID1/held-exec direct route only. This is a proposed next source
slice, not an implementation, test result, provider qualification, native
acceptance, or permission to widen the seven application RPC methods.

## Actual evidence and obstruction

* `runtime/ui/Main.hs` SHA256 50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7,
  lines 59-75: the broker stops serving when owner stop is true, returns
  `EngineResult False False`, and its retirement closes the broker before
  calling `stopEngineProcess`. The latter can force PID1 through its owned
  pidfd. No local engine retirement receipt is received by the UI owner.
* `runtime/ui/Warlock/Ui/EngineEntrypoint.hs` SHA256
  941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080,
  lines 318-331, runs `runWebKit` without a Custody argument; the engine itself
  is PID1. It starts retiring before the original D but the broker may stop
  listening or kill it. Neither startup acknowledgement nor a local send is a
  peer-consumption or cleanup receipt.
* `runtime/ui/Warlock/Ui/WebKit.hs` SHA256
  b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a:
  `connectOwnedSignal` (220-237) observes a closure notifier before freeing
  the associated callback; `compileFilter` (293-356) observes completion on an
  owned context or retains its callback and C backing; `retireInOrder`
  (259-270) stops the dependent chain on uncertainty. These are local facts,
  not transmitted proof of whole-provider retirement. Calls into GLib are
  synchronous without a demonstrated hard execution bound.
* Same WebKit source, 389-426 and 479-498: stores and private directories are
  retained; `wholeClean` requires empty retained backing and all
  `productionCleanupFacts`. The actual route has no local Custody and its
  defaults retain `CallbackPending`, `ProviderUnqualified`, and deadline false.
  Never map `unref`, GTask cancellation, a PID1 pidfd exit, or a screenshot to
  a provider/backing/whole-engine completion receipt.
* `runtime/ui/Warlock/Ui/EngineCustody.hsc` SHA256
  5028eed1eae2df6f066d3868777af686aa0ddb889a651159b26cb3369c4129de,
  240-261 and 645-650: the owned pidfd path closes the lifeline, issues its
  signal and observes/reaps only the owned child within reserved time. This
  is process/namespace custody evidence, not a callback or filter-store receipt.
  `runtime/src/Warlock/Ui/Owner.hs` SHA256
  a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9,
  265-295, requires both result.engineCleanup and completed retirement.

## Narrow next source route, contingent on provider evidence

1. Introduce a distinct bounded terminal lifecycle phase on the existing
   parent-owned engine socket. Keep the seven application methods unchanged;
   terminal retirement is a strict, one-shot lifecycle envelope, not a raw
   gateway/native event or a new application authority. Reject extra fields,
   replay, foreign/mixed SCM credentials, stale incarnation, late messages and
   any receipt without the same live held-child/pidfd guard. Map malformed,
   EOF, timeout, cleanup exception and no receipt to unknown/false. Local
   write success alone does not count; original owner must receive and check it.
2. Let WebKit return a finite, typed, local-only result for each required signal
   closure-notifier receipt and filter task completion, plus exact unresolved
   backing status. It must not report callback retirement if a callback can
   still run, must retain backing when completion is missing, and must not
   assert provider child exit. A successful local receipt is necessary but not
   sufficient for `engineCleanup`.
3. In Main's stop phase, stop accepting application events, allow only that
   terminal receipt under the unchanged original D and existing source cutoffs,
   then ask the PID1 engine to exit voluntarily and observe the exact owned
   pidfd/reap receipt. The broker currently closes and kills first, so this
   sequencing requires a concrete source change. Lifeline/timeout/guard failure
   uses the existing owned termination path and remains uncertain; no arbitrary
   PID signal, global reaping, new D, unbounded blocking or fake success.
4. Separately establish the exact pinned WebKit 2.52.6 and guest 2.54.1 direct
   spawn/provider route and filter-store ownership contract. The engine cannot
   observe its own post-exit namespace and a local unref does not prove its
   descendants have exited. Retained directories need an owned identity and a
   reviewed removal/retirement receipt under D; do not accept arbitrary paths
   from the engine or remove backing while a callback/provider may still use it.
   Until exact provider evidence and backing ownership exist, keep the provider
   and backing fields unknown and `EngineResult False False`.

Original D has to cover terminal transfer, callback drain, owner close and
namespace receipt using existing source-backed cutoffs. No new permanent time
budget or additional fixed reserve is proposed. All normal-path and failure actions
must remain bounded; synchronous provider FFI has no proven hard bound, so a
post-call clock reading is not proof it finished before D. Forced termination,
late callback/closure notification, uncertain cleanup and unobserved namespace
exit stay distinct.

## Production-route controls proposed for root

* Authenticated positive terminal local receipt, followed by exact owned PID1
  exit/reap; prove those two receipts remain distinct and do not imply provider
  qualification. Fragment receipt with real SCM credentials; reject a foreign
  peer, changed credential, stale incarnation, duplicate terminal frame, and
  terminal after stop/deadline. Test actual production codec/guard/route.
* Disconnect before/while a signal callback is active, notifier delayed or
  absent, filter completion late/cancelled, and an injected release failure;
  ensure later dependent unrefs and backing removal are withheld. Verify no
  callback points to a freed Haskell closure; retain known uncertainty.
* Deadline crossing before/after each action, local reply received but PID1
  exit absent, namespace exit observed but local receipt missing, owner identity
  changed, and forced pidfd termination. No callback or file path accepted as
  authority after retirement, no five-second frame or original-D reset.
* Exact provider-version and supported direct-spawn controls plus an owned
  namespace-descendant case including reparent/process-group changes. A model,
  mock guard or process exit is not the provider observation.

No compiler, test, model, native or VM run was performed by this worker.
Source is frozen; this document does not modify production code.
