{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
-- Root-owned, unexecuted source fixture for scoped context ingress proposal.
-- Real local AF_UNIX / SCM credentials; token/scope/guard below are test-only
-- stand-ins, not selected-child provenance, native action or cleanup proof.
module Main (main) where

import Control.Exception (mask_)
import Control.Monad (unless)
import Data.IORef
import Foreign.StablePtr (newStablePtr)
import qualified Data.ByteString as B
import GHC.Conc (STM, TVar, atomically, newTVarIO, readTVar, retry, writeTVar)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Posix.Process (getProcessID)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import qualified Warlock.Protocol.CredentialIngress as Public
import Warlock.Protocol.Ingress.Internal
import qualified Warlock.Protocol.PeerCredential as Peer
import qualified Warlock.Protocol.Framing as Framing
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))

data Wake = Stop deriving (Eq, Show)
data Refusal = Revoked | Foreign deriving (Eq, Show)
type Context = (Int, Public.FrameDeadline)
data Retained = Retained (IORef (Maybe (CredentialIngressT Context))) (IORef (Maybe (S.Socket,S.Socket)))
type Registry = IORef [Retained]
data Fixture = Fixture (CredentialIngressT Context) S.Socket (TVar (Maybe Wake))
  (IORef Int) (IORef [(Int,Integer)]) (IORef Int) (Int -> Public.FrameDeadline -> CredentialGuard Refusal)

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError name))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 8000000 action >>= maybe (ioError (userError label)) pure
wakeSTM :: TVar (Maybe Wake) -> STM Wake
wakeSTM wake = readTVar wake >>= maybe retry pure

-- Registry is anchored before resource acquisition, including assertion and
-- cancellation paths. Retention is not a confirmed close or process cleanup.
fixture :: Registry -> IO Fixture
fixture registry = mask_ $ do
 ownerCell <- newIORef Nothing
 socketsCell <- newIORef Nothing
 atomicModifyIORef' registry (\xs -> (Retained ownerCell socketsCell : xs, ()))
 bound <- must (ingressBinding "1" "2" "3")
 pid <- toInteger <$> getProcessID
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 wake <- newTVarIO Nothing
 calls <- newIORef 0
 observed <- newIORef []
 entered <- newIORef 0
 let capture tag deadline = modifyIORef' observed ((tag, Public.frameDeadlineNs deadline) :)
     verify credential = Peer.credentialPid credential == pid && Peer.credentialUid credential == uid && Peer.credentialGid credential == gid
     allowed credential = do
      stopped <- atomically (readTVar wake)
      pure (if stopped /= Nothing then Left Revoked else if verify credential then Right () else Left Foreign)
     guard tag deadline = CredentialGuard
      (\credential -> capture tag deadline >> allowed credential)
      (\credential action -> do
       capture tag deadline
       admitted <- allowed credential
       case admitted of Left problem -> pure (Left problem); Right () -> Right <$> action)
     client (tag,deadline) _ = capture tag deadline >> modifyIORef' calls (+1)
 ingress <- newDesktopCredentialIngressWithContext bound FromElm client (\_ _ -> ioError (userError "unexpected native callback"))
 writeIORef ownerCell (Just ingress)
 (owned,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 writeIORef socketsCell (Just (owned,peer))
 offered <- transferCredentialSocket ingress owned
 check "offer" (offered == OfferAccepted)
 active <- activateCredentialIngress ingress
 check "activate" (active == ActivationLive)
 pure (Fixture ingress peer wake calls observed entered guard)

frame :: IO B.ByteString
frame = must $ Framing.desktopCommitPrefix $
 "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"QA\",\"bar\":[{\"id\":\"qa:focus-valid\",\"domId\":\"focus-valid\",\"label\":\"QA control\",\"ariaLabel\":\"QA control\",\"detail\":\"\",\"enabled\":true,\"focusOnly\":false}],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"7\"}],\"focus\":[]}"

scope :: IORef Int -> (Int -> IO a) -> IO (Either Refusal a)
scope count action = modifyIORef' count (+1) >> Right <$> action 42
refuse :: (Int -> IO a) -> IO (Either Refusal a)
refuse _ = pure (Left Revoked)
-- Deliberately adversarial scope adapter: if it returns Left after continuation,
-- the receiver must distinguish that from rejection before entering the frame.
afterEntry :: IORef Int -> (Int -> IO a) -> IO (Either Refusal a)
afterEntry count action = modifyIORef' count (+1) >> action 42 >> pure (Left Revoked)

clean :: Fixture -> IO ()
clean (Fixture ingress peer _ _ _ _ _) = do
 status <- retireCredentialIngress ingress
 check "confirmed test endpoint retirement" (endpoint status == Just EndpointConfirmed)
 S.close peer

main :: IO ()
main = do
 registry <- newIORef []
 _ <- newStablePtr registry
 packet <- frame
 -- Successful first frame: the fixed checked callback, fragment guard and
 -- admission guard all see exactly the same token and Channel deadline.
 yes@(Fixture ingress peer wake calls observed count guard) <- fixture registry
 N.sendAll peer packet
 delivered <- within "positive frame" (receivePersistentCredentialIngressScoped False (wakeSTM wake) ingress (scope count) guard)
 seen <- readIORef observed
 n <- readIORef calls
 scopes <- readIORef count
 check "fixed callback and guards see same context" (delivered == Right (PersistentOutcome CredentialDelivered) && n == 1 && scopes == 1 && length seen >= 4 && all (== head seen) seen && fst (head seen) == 42 && snd (head seen) > 0)
 -- Stop already visible before idle readiness must not enter another scope.
 atomically (writeTVar wake (Just Stop))
 stopped <- within "idle stop" (receivePersistentCredentialIngressScoped True (wakeSTM wake) ingress (scope count) guard)
 n2 <- readIORef calls
 scopes2 <- readIORef count
 check "idle stop never enters frame scope" (stopped == Right (PersistentOwnerWake Stop) && n2 == 1 && scopes2 == 1)
 clean yes
 -- Complete frame is buffered; refusal at scope gate must precede any read,
 -- and the tagged False result must not be called a successful receipt.
 no@(Fixture ing2 peer2 wake2 calls2 _ _ guard2) <- fixture registry
 N.sendAll peer2 packet
 refused <- within "scope refused" (receivePersistentCredentialIngressScoped True (wakeSTM wake2) ing2 refuse guard2)
 noCalls <- readIORef calls2
 check "pre-entry refusal does not dispatch" (refused == Left (False,Revoked) && noCalls == 0)
 clean no
 -- A scope wrapper that returns failure after running its continuation cannot
 -- claim no frame consumption; the result is explicitly tagged True.
 late@(Fixture ing3 peer3 wake3 calls3 _ count3 guard3) <- fixture registry
 N.sendAll peer3 packet
 ambiguous <- within "post-entry refusal" (receivePersistentCredentialIngressScoped True (wakeSTM wake3) ing3 (afterEntry count3) guard3)
 lateCalls <- readIORef calls3
 check "post-entry failure is marked consumed" (ambiguous == Left (True,Revoked) && lateCalls == 1)
 clean late
 retained <- readIORef registry
 check "fixture owners retained" (length retained == 3)
 putStrLn "scoped context ingress source controls completed"
