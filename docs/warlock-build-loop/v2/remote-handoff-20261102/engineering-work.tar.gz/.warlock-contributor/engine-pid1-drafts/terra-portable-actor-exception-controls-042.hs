{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY, unexecuted QA source. One mode per externally guarded process.
-- This calls the real Backend and same retained owner; hook is QA-only and
-- fires after the actual Catalog is published, before acquisition or spawn.
module PortableActorExceptionControls (Mode(..), Case, newCase, release, runCase) where
import Control.Concurrent (ThreadId, forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled), SomeException, fromException, mask, throwIO, try)
import Control.Monad (unless, void)
import Data.IORef (IORef, atomicModifyIORef', newIORef, writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner, PersistentBackendRun, newPersistentBackendOwner,
 loadPersistentBackendConfig, runPersistentBackend, requestPersistentBackendStop,
 retirePersistentBackend, qaAfterCatalogHook, qaBackendStopDeadline)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = InjectAsync | DuplicateStart deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
release :: Case -> IO ()
release (Case _ _ _ barrier _ _ _) = void (tryPutMVar barrier ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain owner, worker and guardian"))) pure
runCase :: Case -> Mode -> FilePath -> IO ()
runCase c@(Case owner start entered barrier done worker used) mode path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\was -> (True,not was))
 check "single case" fresh
 exists <- doesPathExist path
 check "absolute actual config" (isAbsolute path && exists)
 loaded <- restore (within "load actual config" (loadPersistentBackendConfig owner path))
 check "config belongs to actor owner" (loaded == Right ())
 qaAfterCatalogHook $ do
  putMVar entered ()
  case mode of InjectAsync -> throwIO ThreadKilled; DuplicateStart -> readMVar barrier
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar done result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within "actual catalog publication" (readMVar entered)
  case mode of
   InjectAsync -> do
    result <- within "actor exception" (readMVar done)
    case result of
     Left problem -> check "original ThreadKilled preserved" (case fromException problem of Just ThreadKilled -> True; _ -> False)
     Right _ -> ioError (userError "async exception was swallowed")
    stop <- within "owner stop observed" (qaBackendStopDeadline owner)
    check "same owner stop latched" (case stop of P.StopDeadlineLatched _ -> True; _ -> False)
    cleaned <- within "uncertain owner observation" (retirePersistentBackend owner)
    check "exception cannot report clean retirement" (not cleaned)
   DuplicateStart -> do
    second <- try (within "duplicate actor" (runPersistentBackend owner)) :: IO (Either SomeException PersistentBackendRun)
    check "duplicate rejected" (case second of Left _ -> True; Right _ -> False)
    beforeStop <- within "observe original stop gate" (qaBackendStopDeadline owner)
    check "duplicate did not stop first actor" (beforeStop == P.StopDeadlineNotLatched)
    stop <- within "explicit same-owner stop" (requestPersistentBackendStop owner)
    check "explicit stop latched" (stop == P.StopLatchedBeforeLive)
    release c
    _ <- within "first actor returns" (readMVar done) >>= either throwIO pure
    pure ()
