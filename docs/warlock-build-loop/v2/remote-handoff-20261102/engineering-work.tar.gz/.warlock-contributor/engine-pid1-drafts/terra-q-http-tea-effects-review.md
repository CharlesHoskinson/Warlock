# TEA001/002 policy effects and HTTP boundary review

2026-11-01; terra-q-http; source-only review, not an execution, fixture verdict, original EARS acceptance or native qualification. Root owns production source and every protected check. Current selected record: `.warlock-contributor/tea-model-effects.json`, revision `31a92dce92538f5282643c006854e23294b15bbe`.

## Reducer output that an independent oracle must retain

`DesktopPolicy.update` (`DesktopPolicy.elm:64-75`) routes a checked three-field gateway or deadline through `OutputController.update`, then `register`; the latter can change the complete model again. Compare the **post-register complete model**, the entire ordered list of policy effects, and literal independent expectations at each transition. `Policy.Model` contains an opaque `OutputController.Model`; its internal queues, batches, counters, controller, recovery and desktop state cannot be omitted merely because they are not displayed. A printed representation that hides functions or JSON is not a full observation. Reject unsupported/unobservable content. Any compiled-fixture observer must preserve values and reducer behavior, bind the exact generated source/artifact hashes, and independently prove non-mutation and full fidelity; it is QA instrumentation, not a new authority constructor.

`OutputController.commit` (`:218-225`) produces exact `viewProtocol`, `kind`, whole `projection`, ordered `requests`, and ordered `focus`. `register` (`:249-300`) can register a bound batch, emit a complete packet with empty requests, omit a packet, or locally settle/refuse and produce a bounded fallback. These branches and the changed resulting state matter. A kind-only, hash-only, projected-field, or count-only Publish comparison is not equality of the typed effect.

`DesktopPolicy.effectsFor` (`:48-61`) maps the following four descriptions; check ordered effects, full duration, exact message constructor and complete token/intent, including full-width counter fields:

| Source effect | Policy effect |
| --- | --- |
| `Shell.ArmPrepared token` | `Delay 2000 (Desktop.Window (TaskbarShell.ExpirePrepared token))` |
| `Desktop.ArmWorkspaceNavigation intent` | `Delay 2000 (Desktop.WorkspaceNavigationDeadline intent)` |
| `Desktop.ArmChoice token` | `Delay 2000 (Desktop.ChoiceDeadline token)` |
| `Desktop.Arm token` | `Delay 10000 (Desktop.Deadline token)` |

`Publish` precedes timers in this policy output. A constructor tag or duration alone cannot establish equality. Exercise a reached instance of every effect class and distinguish different payloads with identical tags and high counters. If a class cannot be reached using the real admitted prelude, report it as uncovered; do not add fixture-only mutators to opaque authorities.

## Independent semantic checks

Use named literal given/prelude and actual policy messages. Independently specify the entire semantic post-state and each effect after each transition, including every unchanged field, rather than copying reducer output into the expected record. Two equal executions are a determinism check but can both be wrong. Include positive admitted operation to pending, unrelated/mismatched receipt, matching committed and refused histories, disconnect to Unknown without replay, stale/malformed events, fresh binding/rebind, full-width counters and actual timed messages. Distinguish malformed *gateway* (rejected by `incomingEvent`, exact prior model and no effects) from a valid gateway containing a malformed domain envelope: domain decoders may record a refusal diagnostic, so do not assert a generic unchanged model for both.

`Effects.elm:12-19` explicitly separates `Operation`, `Status`, observed `Snapshot` and requested `Intent`; `Shell.elm:31-35` has `Phase`, opaque stamp, and effects. This is evidence of typed pieces, not proof of the whole TEA001 lifecycle, receipt and observation-versus-desire audit. Source-review every participating type and authoritative projection, including recovery and rebind; do not infer complete separation from the naming of a few types.

## Interpreter and transport scope

`Main.elm:15-31` interprets the full `Publish` on `surfaceCommits` and schedules the full `Delay` message via `Process.sleep`; `incoming` is its subscription. `HttpMain.elm:15-56` enqueues a full publication and schedules the same timer, but on `UiHttp.Lost` its `lost` helper updates policy with `TransportLost` and **discards that update's returned effects**. This is an exact source behavior to cover separately from the pure reducer, not by itself proof of a defect. In particular, examine whether any generated loss publication can be delivered after a failed transport before asserting a visible result. No alternative authority or synthetic receipt is implied.

`UiHttp.elm:62-69,78-85,108-142` has one active FIFO POST, bounded retained count 16, controller bytes 131072, renderer bytes 8192, 5-second individual HTTP timeouts, role-specific `/commit` or `/actions`, and `X-Warlock-Api: 1` on POST and GET. A 204 permits the next queued POST; it is not a native receipt. A failed delivery poisons the transport and is not replayed. Test error/unknown boundaries independently of the pure policy fixture and retain original deadlines.

`Owner.hs:185-226,400-430` admits framing/role/origin before dispatch, preflights the whole commit and all request bindings and projection/focus before queue and native send, and validates renderer action before enqueue. Successful preflight is still not an effect receipt. On a later native send failure, any already reserved projection and owner failure/cleanup behavior must be evaluated as its actual ordered trace; do not claim that no queue I/O occurred after a valid preflight. `Http.hs:19-80` has bounded headers/body, duplicate and transfer-coding refusal, observed extra-byte refusal and original admission deadline. No source assertion grants browser native authority.

## Source hashes

```
018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e  implementation/warlock/src/DesktopPolicy.elm
fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae  implementation/warlock/src/OutputController.elm
2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998  implementation/warlock/src/SurfaceController.elm
a63de0a105e1a13edc5eb67359b665032acba662650659b3a24d4f1999058b66  implementation/warlock/src/Main.elm
58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9  implementation/warlock/src/HttpMain.elm
3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419  implementation/warlock/src/UiHttp.elm
a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9  implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs
5c5d063cdd550a077aedce803656996fc63be34030df5ba635219ffed0d61d40  implementation/warlock/haskell/runtime/src/Warlock/Ui/Policy.hs
```

Quint source-intake correspondence separates policy state, effect description, HTTP queue, owner admission and native observation as different transitions; this note does not claim an executed model or equate a component result with an original verdict. TEA005 remains a later selected slice.
