{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, unexecuted; one isolated process per mode, actual Backend owner.
-- Every mutating call runs in a retained worker; timeouts watch only MVars.
module PortableCentralStopControls (Mode(..), Case, newCase, release, runCase, workers) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled),SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,newPersistentBackendOwner,requestPersistentBackendStop,
 qaCentralStopHook,qaCentralStopCalls,qaBackendStopDeadline)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = ConcurrentStop | InterruptedFirst deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (IORef [ThreadId]) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newIORef [] <*> newIORef False
release :: Case -> IO ()
release (Case _ _ gate _ _) = void (tryPutMVar gate ())
workers :: Case -> IO [ThreadId]
workers (Case _ _ _ ts _) = readIORef ts
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
wait :: AdmissionDeadline -> String -> MVar a -> IO a
wait deadline label done = do
 left <- remainingMicros deadline
 if left <= 0 then ioError (userError (label ++ ": original D expired; retain Case and guardian"))
 else timeout left (readMVar done) >>= maybe (ioError (userError (label ++ ": Unknown; retain Case and guardian"))) pure
waitBoth :: AdmissionDeadline -> AdmissionDeadline -> String -> MVar a -> IO a
waitBoth original stop label done = do
 a <- remainingMicros original
 b <- remainingMicros stop
 let left = min a b
 if left <= 0 then ioError (userError (label ++ ": original D expired; retain Case and guardian"))
 else timeout left (readMVar done) >>= maybe (ioError (userError (label ++ ": Unknown; retain Case and guardian"))) pure
launch :: IORef [ThreadId] -> IO a -> IO (MVar (Either SomeException a))
launch ts action = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (readMVar start >> action))
  putMVar done result
 writeIORef ts =<< ((tid :) <$> readIORef ts)
 putMVar start ()
 pure done
runCase :: AdmissionDeadline -> Case -> Mode -> IO ()
runCase original c@(Case owner entered gate ts used) mode = mask $ \restore -> do
 first <- atomicModifyIORef' used (\prior -> (True,not prior))
 check "case used once" first
 calls0 <- qaCentralStopCalls
 check "isolated zero counter" (calls0==0)
 qaCentralStopHook $ do
  putMVar entered ()
  case mode of ConcurrentStop -> readMVar gate; InterruptedFirst -> throwIO ThreadKilled
 stop1 <- launch ts (requestPersistentBackendStop owner)
 restore $ do
  wait original "first actual marker" entered
  case mode of
   ConcurrentStop -> do
    stop2 <- launch ts (requestPersistentBackendStop owner)
    second <- wait original "concurrent stop" stop2 >>= either throwIO pure
    callsBefore <- qaCentralStopCalls
    check "in-flight second call uncertain and physical stop unentered" (second==P.StopUncertain CleanupUncertain && callsBefore==0)
    release c
    firstReceipt <- wait original "first real stop" stop1 >>= either throwIO pure
    check "first actual stop is latched" (firstReceipt==P.StopLatchedBeforeLive)
    before <- qaBackendStopDeadline owner
    stopD <- case before of P.StopDeadlineLatched value -> pure value; _ -> ioError (userError "original first stop D absent")
    stop3 <- launch ts (requestPersistentBackendStop owner)
    third <- waitBoth original stopD "completed stop observation" stop3 >>= either throwIO pure
    after <- qaBackendStopDeadline owner
    callsAfter <- qaCentralStopCalls
    check "no retry or D renewal after completion" (third==firstReceipt && after==before && callsAfter==1)
   InterruptedFirst -> do
    result <- wait original "interrupted first" stop1
    case result of
     Left problem -> check "original ThreadKilled survives" (case fromException problem of Just ThreadKilled -> True; _ -> False)
     Right _ -> ioError (userError "interruption swallowed")
    stop2 <- launch ts (requestPersistentBackendStop owner)
    second <- wait original "second after interruption" stop2 >>= either throwIO pure
    deadline <- qaBackendStopDeadline owner
    calls <- qaCentralStopCalls
    check "no retry/no invented stop deadline" (second==P.StopUncertain CleanupUncertain && deadline==P.StopDeadlineNotLatched && calls==0)
