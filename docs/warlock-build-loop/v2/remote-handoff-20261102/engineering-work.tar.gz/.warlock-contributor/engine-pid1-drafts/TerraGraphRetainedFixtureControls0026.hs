-- Root-only QA source proposal; not compiled or executed. Root must allocate
-- and strongly retain every FixtureGuard before invocation, and provide a
-- separately reviewed outer guardian before any child is actually spawned.
-- These checks establish neither root-teardown fault safety nor child reaping.
module TerraGraphRetainedFixtureControls0026 (runFixtureInputControls, runVerifiedPositive) where

import Control.Exception (IOException, try)
import Control.Monad (unless)
import TerraGraphRetainedFixture0026
 (FixtureGuard, validFixtureInputs, validatedRetainedFixture)
import Warlock.Platform.Executable (HeldExecutable, qaHeldBorrowCount)

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("retained fixture: " ++ label)))

isRefused :: Either IOException a -> Bool
isRefused (Left _) = True
isRefused (Right _) = False

-- Root roots the supplied guard before this function. A malformed component
-- must fail before the resolver; a second call must not reuse that guard.
runFixtureInputControls :: FixtureGuard -> IO ()
runFixtureInputControls invalidGuard = do
 let positive = validFixtureInputs "/tmp" "owned-child"
     invalid = [ ("relative root", validFixtureInputs "tmp" "child")
               , ("empty name", validFixtureInputs "/tmp" "")
               , ("dot", validFixtureInputs "/tmp" ".")
               , ("dot dot", validFixtureInputs "/tmp" "..")
               , ("nested path", validFixtureInputs "/tmp" "dir/child")
               , ("nul in name", validFixtureInputs "/tmp" ['a','\0','b'])
               , ("nonascii name", validFixtureInputs "/tmp" ['\955'])
               , ("nonascii root", validFixtureInputs ['/', '\955'] "child")
               ]
 check "literal valid input" positive
 mapM_ (\(label, result) -> check label (not result)) invalid
 first <- try (validatedRetainedFixture invalidGuard "/tmp" "../child") :: IO (Either IOException HeldExecutable)
 second <- try (validatedRetainedFixture invalidGuard "/tmp" "child") :: IO (Either IOException HeldExecutable)
 check "actual invalid invocation refuses and guard stays one-shot" (isRefused first && isRefused second)

-- Run with a fresh Root-retained guard and a real resolver-verified fixture
-- executable in the exact root. Root must retain the returned held capability
-- and must not infer any child was started, closed or reaped by this check.
runVerifiedPositive :: FixtureGuard -> FilePath -> FilePath -> IO HeldExecutable
runVerifiedPositive guard rootDir name = do
 held <- validatedRetainedFixture guard rootDir name
 count <- qaHeldBorrowCount held
 check "resolver-issued held starts live with no borrows" (count == Just 0)
 repeated <- try (validatedRetainedFixture guard rootDir name) :: IO (Either IOException HeldExecutable)
 check "issued guard cannot issue twice" (isRefused repeated)
 pure held
