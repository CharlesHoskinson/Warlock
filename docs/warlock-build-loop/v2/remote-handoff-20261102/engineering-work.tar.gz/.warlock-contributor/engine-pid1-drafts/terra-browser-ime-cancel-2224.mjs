// UNRUN source-derived controlled HttpPopup browser fixtures, one fresh
// isolated target per exported function. Current Popup baseline 9761aa5d is
// predicted RED for the two outstanding-edit cases; no result is claimed.
// Inputs/composition and presentation frames are synthetic. Neither a 204,
// injected frame nor a bounded drain proves backend admission, native IME/AT,
// compositor presentation, hardware timing or absence of all future traffic.
//
// Interface: controlledPopupHttp 47ef21a0 plus expectedPopupSha256, evaluate,
// until and synchronous check. Root binds the full source/dependency closure,
// compiler, actual artifact and harness hashes, target isolation, all CDP
// sessions, one absolute deadline, initial document focus and owned cleanup.
// candidate must be independently reviewed and its exact Popup hash supplied.

const initialPopup='9761aa5d5679574fbee43a57b81e48fed0b76c63d80543ee99804432c6cddf6a';
const row=(id,domId,label,ariaLabel)=>({id,domId,label,ariaLabel,detail:'',enabled:true});
const frame=(publication,query,status)=>({surfaceProtocol:2,publication,lease:'7',mode:'applications',status,bar:[],popup:[
  row('control:search','launcher-search',query,'Search applications'),
  row('control:close','close-applications','Windows','Close applications and return to windows'),
  row('control:refresh','refresh-applications','Refresh','Refresh applications'),
  row('entry:org.example.Foot','entry-foot','Foot','Open Foot')
]});
const query=(publication,value)=>({surfaceProtocol:2,kind:'surface-query',surface:'popup',publication,lease:'7',id:'control:search',query:value});
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const notice=status=>'Results may not match current input. Previous: '+status;
const read=h=>h.evaluate(`(()=>{const root=document.querySelector('.surface-popup'),f=root?.querySelector('[data-surface-field="control:search"]'),entry=root?.querySelector('[data-surface-control="entry:org.example.Foot"]');return {publication:root?.dataset.publication,lease:root?.dataset.lease,value:f?.value,focused:document.hasFocus()&&document.activeElement===f&&f===window.heldSearch,composing:root?.parentElement?.getAttribute('data-input-composing'),status:root?.querySelector('[role="status"]')?.textContent,entryDisabled:entry?.disabled};})()`);
async function setup(h){
  if(!/^[0-9a-f]{64}$/.test(h.expectedPopupSha256)) throw Error('Explicit reviewed Popup source hash required');
  await h.assertSourceIdentity({
    'implementation/warlock/src/Popup.elm':h.expectedPopupSha256,
    'implementation/warlock/src/HttpPopup.elm':'e814d56f212765154436c1ab01cc2657b669a6d5d68f5c6d2180ccb64c9eeeb3',
    'implementation/warlock/src/UiHttp.elm':'3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419',
    'implementation/warlock/src/Presentation.elm':'745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396',
    'implementation/warlock/src/SurfaceSnapshot.elm':'9c85362ec27496438eb5a159e2c162704ef2922ba41df172a17e81787203913a',
    'implementation/warlock/src/SurfaceRenderer.elm':'58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e'
  });
  await h.assertNetworkIsolation();
  await h.deliverPresentation(frame('1','','Type to search applications.'));
  await h.until(`document.querySelector('.surface-popup')?.dataset.publication==='1'`);
  await h.evaluate(`window.heldSearch=document.querySelector('[data-surface-field="control:search"]');window.heldSearch.focus()`);
  const seen=await read(h);
  h.check('initial focused empty field',seen.focused&&seen.value===''&&seen.publication==='1',seen);
}
async function edit(h,value){
  await h.evaluate(`(()=>{const f=window.heldSearch;f.value=${JSON.stringify(value)};f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:null}));})()`);
}
async function start(h){
  await h.evaluate(`window.heldSearch.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true,data:''}))`);
  await h.until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='true'`);
}
async function preedit(h,value){
  await h.evaluate(`(()=>{const f=window.heldSearch;f.value=${JSON.stringify(value)};f.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'漢'}));})()`);
}
async function cancel(h,value){
  await h.evaluate(`(()=>{const f=window.heldSearch;f.value=${JSON.stringify(value)};f.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:''}));})()`);
  await h.until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='false'`);
  await h.settleElm();
}

// Negative control: no pre-existing local pending edit, no new POST on cancel.
export async function ordinaryCancel2224(h){
  await setup(h); await start(h); await preedit(h,'漢'); await cancel(h,'');
  const seen=await read(h);
  h.check('ordinary cancel returns to confirmed empty query without POST',seen.focused&&seen.value===''&&seen.status==='Type to search applications.'&&seen.entryDisabled===false&&same(await h.actions(),[]),seen);
}

// Same-scope f then reversal to empty; first f can still cause a P2 frame.
export async function cancelWithReversedOutstanding2224(h){
  await setup(h); await edit(h,'f'); await h.waitForActionCount(1);
  h.check('first exact query',same(await h.actions(),[query('1','f')]),await h.actions());
  await h.respondAction(0,204,''); await edit(h,''); await h.waitForActionCount(2);
  const wires=[query('1','f'),query('1','')];
  h.check('reversed empty is queued with same publication',same(await h.actions(),wires),await h.actions());
  await h.until(`document.querySelector('[data-surface-field="control:search"]')?.value==='' && document.querySelector('.surface-popup [role="status"]')?.textContent==='Results may not match current input. Previous: Type to search applications.' && document.querySelector('[data-surface-control="entry:org.example.Foot"]')?.disabled===true`);
  await start(h); await preedit(h,'漢'); await cancel(h,'');
  let seen=await read(h);
  h.check('cancel preserves unresolved empty latest intent',seen.focused&&seen.value===''&&seen.status===notice('Type to search applications.')&&seen.entryDisabled===true&&same(await h.actions(),wires),seen);
  await h.deliverPresentation(frame('2','f','Choose a matching application.'));
  await h.until(`document.querySelector('.surface-popup')?.dataset.publication==='2'`);
  seen=await read(h);
  h.check('older f publication cannot replace canceled-back empty draft',seen.focused&&seen.value===''&&seen.status===notice('Choose a matching application.')&&seen.entryDisabled===true,seen);
  await h.respondAction(1,204,''); await h.waitForActionCount(3);
  h.check('empty query rebased exactly once after older publication',same(await h.actions(),[...wires,query('2','')]),await h.actions());
  await h.respondAction(2,204,''); await h.deliverPresentation(frame('3','','Type to search applications.'));
  await h.until(`document.querySelector('.surface-popup')?.dataset.publication==='3'`);await h.settleElm();
  seen=await read(h);
  h.check('matching empty projection settles without replay',seen.focused&&seen.value===''&&seen.status==='Type to search applications.'&&same(await h.actions(),[...wires,query('2','')]),seen);
}

// Prior b intent predates preedit; newer P2 c arrives before cancellation to b.
export async function cancelAfterNewerPublication2224(h){
  await setup(h); await edit(h,'c'); await h.waitForActionCount(1); await h.respondAction(0,204,'');
  await edit(h,'b'); await h.waitForActionCount(2);
  const wires=[query('1','c'),query('1','b')];
  h.check('prior current-scope c then b wires',same(await h.actions(),wires),await h.actions());
  await h.until(`document.querySelector('[data-surface-field="control:search"]')?.value==='b' && document.querySelector('.surface-popup [role="status"]')?.textContent==='Results may not match current input. Previous: Type to search applications.' && document.querySelector('[data-surface-control="entry:org.example.Foot"]')?.disabled===true`);
  await start(h); await preedit(h,'b漢');
  await h.deliverPresentation(frame('2','c','Choose a matching application.'));
  await h.until(`document.querySelector('.surface-popup')?.dataset.publication==='2'`);
  await cancel(h,'b');
  let seen=await read(h);
  h.check('cancel retains original pending b under newer c',seen.focused&&seen.value==='b'&&seen.status===notice('Choose a matching application.')&&seen.entryDisabled===true,seen);
  await h.respondAction(1,204,''); await h.waitForActionCount(3);
  h.check('cancel rebases b once under current publication',same(await h.actions(),[...wires,query('2','b')]),await h.actions());
  await h.respondAction(2,204,'');await h.deliverPresentation(frame('3','b','Choose a matching application.'));
  await h.until(`document.querySelector('.surface-popup')?.dataset.publication==='3'`);await h.settleElm();
  seen=await read(h);
  h.check('matching b projection settles without replay',seen.focused&&seen.value==='b'&&seen.status==='Choose a matching application.'&&same(await h.actions(),[...wires,query('2','b')]),seen);
}

export { initialPopup as baselinePopupSha256 };
