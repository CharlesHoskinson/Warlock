{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. All spawned test threads are retained before start;
-- timeout reads only completion MVars, never cancels a product stop/driver.
-- Host retains the Case, real child, root and independent process guardian.
module QHttpCleanupDeadlineR13 (Case,newCase,runCase,retainedWorkers) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),deadlineAbsoluteNs,remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),SessionExit(..),StopBudget,StopReceipt(..),
  StopDeadlineObservation(..),CleanupDeadlineObservation(..),newPersistentOwner,
  newPersistentRootCustody,persistentStatus,requestSessionStop,tryPersistentStopDeadline,
  tryPersistentCleanupDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaWithActualCleanupGate)
import Warlock.Platform.Resolver (Identity(..),RootCustody,withRetainedRoot)

data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool) (IORef [ThreadId])
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False <*> newIORef []
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ threads) = readIORef threads
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("cleanup-deadline: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
absolute :: AdmissionDeadline -> IO Integer
absolute d = maybe (ioError (userError "invalid internal deadline")) pure (readMaybe (deadlineAbsoluteNs d))
-- This is exclusively a read of a retained completion cell. It is NOT
-- wrapped around the actual production action and never cancels its worker.
waitCell :: [AdmissionDeadline] -> String -> MVar a -> IO a
waitCell deadlines label cell = do
 left <- minimum <$> mapM remainingMicros deadlines
 if left<=0 then ioError (userError (label ++ ": Unknown; retain worker and guardian")) else do
  result <- timeout left (readMVar cell)
  maybe (ioError (userError (label ++ ": Unknown; retain worker and guardian"))) pure result

-- Thread cannot enter its production action until its actual ThreadId has
-- been published into the retained Case. Exceptions are published first;
-- asynchronous exceptions are then propagated, not silently converted.
launch :: IORef [ThreadId] -> IO a -> IO (MVar (Either SomeException a))
launch threads action = mask $ \_ -> do
 begin <- newEmptyMVar
 done <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (readMVar begin >> action))
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' threads (\xs -> (tid:xs,()))
 putMVar begin ()
 pure done
runStop :: IORef [ThreadId] -> [AdmissionDeadline] -> PersistentOwner -> StopBudget -> String -> IO StopReceipt
runStop threads bounds owner budget label = do
 remaining <- mapM remainingMicros bounds
 check (label ++ ": deadline live before launch") (minimum remaining>0)
 done <- launch threads $ do
  left <- minimum <$> mapM remainingMicros bounds
  check (label ++ ": deadline live before dispatch") (left>0)
  requestSessionStop owner budget
 completed <- waitCell bounds label done
 either throwIO pure completed

-- naturalDrive must execute a real same-owner natural child lifecycle and
-- return its actual SessionExit. It cannot fabricate a phase, pid, D, or root.
-- Driver and each distinct stop are strongly retained before running. If any
-- wait expires, report Unknown; never retry, kill, release or infer cleanup.
runCase :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO SessionExit) -> IO ()
runCase (Case owner rootCell used threads) originalD stopBudget naturalDrive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case" fresh
 remainingMicros originalD >>= check "original D live" . (>0)
 driver <- launch threads $ do
  noStop <- tryPersistentStopDeadline owner
  noCleanup <- tryPersistentCleanupDeadline owner
  check "fresh owner has no invented cleanup D" (noStop==StopDeadlineNotLatched && noCleanup==CleanupDeadlineNotSelected)
  held <- qaWithActualCleanupGate owner $ do
   c <- tryPersistentCleanupDeadline owner
   s <- tryPersistentStopDeadline owner
   pure (c,s)
  check "same actual held gate yields Busy" (held==Just (CleanupDeadlineBusy,StopDeadlineBusy))
  root <- newPersistentRootCustody owner >>= need
  writeIORef rootCell (Just root)
  st <- getFileStatus "/"
  let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
  acquired <- withRetainedRoot root "/" ident $ \_ -> do
   natural <- naturalDrive owner
   phase <- persistentStatus owner
   check "real selected child naturally reaped and owner retired" $
    (case natural of LeaderReaped _ -> True; _ -> False) && phase==PersistentRetired
   beforeStop <- tryPersistentStopDeadline owner
   selected <- tryPersistentCleanupDeadline owner
   implicitD <- case selected of
    CleanupDeadlineSelected d -> pure d
    _ -> ioError (userError "real natural exit did not select containment D")
   check "implicit D exists without first explicit stop" (beforeStop==StopDeadlineNotLatched)
   remainingMicros implicitD >>= check "selected implicit D live" . (>0)
   first <- runStop threads [originalD,implicitD] owner stopBudget "first actual stop"
   explicit <- tryPersistentStopDeadline owner
   stopD <- case explicit of
    StopDeadlineLatched d -> pure d
    _ -> ioError (userError "first explicit stop D not selected")
   both <- tryPersistentCleanupDeadline owner
   implicitNs <- absolute implicitD
   stopNs <- absolute stopD
   actualNs <- case both of
    CleanupDeadlineSelected d -> absolute d
    _ -> ioError (userError "selected cleanup D became unknown")
   check "first stop intersects existing containment D" $
    first==StopUncertain CleanupUncertain && actualNs==min implicitNs stopNs
   repeated <- runStop threads [originalD,implicitD,stopD] owner stopBudget "distinct repeated stop"
   afterStop <- tryPersistentStopDeadline owner
   afterCleanup <- tryPersistentCleanupDeadline owner
   check "repeat cannot renew either deadline" $
    repeated==StopAlreadyRequested && afterStop==explicit && afterCleanup==both
  check "actual retained root callback returned" (acquired==Right ())
 outcome <- restore $ waitCell [originalD] "real rooted lifecycle" driver
 either throwIO pure outcome
