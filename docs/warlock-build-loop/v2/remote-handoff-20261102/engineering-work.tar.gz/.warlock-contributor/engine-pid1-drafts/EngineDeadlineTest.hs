-- PREPARATION DRAFT. Root-owned runtime test; uses only public library APIs.
-- No test has been executed. Parser edge cases already covered by the existing
-- process-custody deadline-stop-controls internal suite are not duplicated.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Monad (forM_, unless)
import Warlock.Capture.Process.Bootstrap
  ( ToolError(..), deadlineAfter, deadlineAbsoluteNs )
import Warlock.Ui.EngineDeadline

assert :: String -> Bool -> IO ()
assert label ok = unless ok (ioError (userError label))

main :: IO ()
main = do
  -- Rejections use the actual public importer, without exposing opaque values.
  forM_ ["", "0", "01", "+2", "-2", " 2", "2 ", "2.0", "2e0", "18446744073709551616"] $ \raw -> do
    result <- fromAuthenticatedStartup raw
    case result of
      Left BadArguments -> pure ()
      _ -> ioError (userError ("noncanonical absolute D accepted: " ++ show raw))

  -- One fixture D is created once. Repeated stages and the imported peer must
  -- preserve that exact original absolute value; they cannot renew the timer.
  made <- deadlineAfter 30000000
  case made of
    Left _ -> ioError (userError "fixture deadline creation")
    Right original -> do
      let owner = fromOwner original
          originalWire = deadlineAbsoluteNs original
          stages = [Startup, RpcRead, RpcWrite, Stop]
      assert "wire is original" (absoluteWire owner == originalWire)
      imported <- fromAuthenticatedStartup originalWire
      case imported of
        Left _ -> ioError (userError "fixture elapsed or startup rejected")
        Right child -> do
          assert "import retains exact D" (absoluteWire child == originalWire)
          forM_ stages $ \stage -> do
            budget <- plan child stage
            case budget of
              Available actual n -> assert "stage and positive bounded budget"
                (actual == stage && n > 0 && n <= 30000000)
              Expired _ -> ioError (userError "fixture unexpectedly expired")
            assert "planning did not renew D" (absoluteWire child == originalWire)
            completion <- checkCompletion child stage
            assert "test stage finishes before D" (completion == InTime stage)

  -- Separate expired fixture: each stage must refuse and every post-operation
  -- assessment is uncertain, never a claimed success. This does not touch the
  -- user's production D. OS scheduling may extend the sleep; that is harmless.
  short <- deadlineAfter 1000
  case short of
    Left _ -> ioError (userError "short fixture deadline creation")
    Right original -> do
      let expired = fromOwner original
          originalWire = deadlineAbsoluteNs original
      threadDelay 20000
      forM_ [Startup, RpcRead, RpcWrite, Stop] $ \stage -> do
        budget <- plan expired stage
        assert "expired stage refused" (budget == Expired stage)
        completion <- checkCompletion expired stage
        assert "expired completion uncertain" (completion == DeadlinePassedOutcomeUnknown stage)
        assert "expired D not renewed" (absoluteWire expired == originalWire)
