module SiteGetStarted exposing
    ( AppearanceTheme(..)
    , FocusTarget(..)
    , Model
    , MotionMode(..)
    , Msg(..)
    , OnboardingTrack(..)
    , TrackSpec
    , decodeEscapeMenu
    , decodeTrackTabKey
    , init
    , initialModel
    , main
    , onboardingTracks
    , stepTrack
    , trackTabDomId
    , update
    , view
    )

import Browser
import Browser.Dom as Dom
import Html exposing (Html)
import Html.Attributes as Attr
import Html.Events as Events
import Json.Decode as Decode
import Task


main : Program () Model Msg
main =
    Browser.element
        { init = init
        , view = view
        , update = update
        , subscriptions = \_ -> Sub.none
        }



-- MODEL (CSS-FREE ELM: ALL PRESENTATION LIVES IN site.css + landing.css)


type AppearanceTheme
    = ThemeNight
    | ThemeDawn
    | ThemeHighContrast


type MotionMode
    = MotionStandard
    | MotionReduced


type OnboardingTrack
    = TrackSimulatedBrowser
    | TrackSourceVerification
    | TrackOmarchyBetaTrial
    | TrackDesignFoundations


type FocusTarget
    = FocusTrackTab OnboardingTrack
    | FocusMobileMenuToggle


type alias TrackSpec =
    { track : OnboardingTrack
    , slug : String
    , shortTitle : String
    , badge : String
    , summary : String
    , availableNow : List String
    , unavailableOrGated : List String
    , commandOrAction : String
    }


type alias Model =
    { theme : AppearanceTheme
    , motion : MotionMode
    , mobileNavOpen : Bool
    , activeTrack : OnboardingTrack
    , tabFocusSeq : Int
    , lastFocusMiss : Maybe String
    }


type Msg
    = SelectTheme AppearanceTheme
    | SelectMotion MotionMode
    | ToggleMobileNav
    | EscapeMobileNav
    | SelectTrack OnboardingTrack
    | KeyboardStepTrack Int
    | KeyboardJumpTrack OnboardingTrack
    | FocusSettled Int FocusTarget (Result Dom.Error ())


initialModel : Model
initialModel =
    { theme = ThemeNight
    , motion = MotionStandard
    , mobileNavOpen = False
    , activeTrack = TrackSimulatedBrowser
    , tabFocusSeq = 0
    , lastFocusMiss = Nothing
    }


init : () -> ( Model, Cmd Msg )
init _ =
    ( initialModel, Cmd.none )



-- UPDATE


orderedTracks : List OnboardingTrack
orderedTracks =
    [ TrackSimulatedBrowser
    , TrackSourceVerification
    , TrackOmarchyBetaTrial
    , TrackDesignFoundations
    ]


trackSlug : OnboardingTrack -> String
trackSlug track =
    case track of
        TrackSimulatedBrowser ->
            "simulated-browser"

        TrackSourceVerification ->
            "source-verification"

        TrackOmarchyBetaTrial ->
            "omarchy-beta-trial"

        TrackDesignFoundations ->
            "design-foundations"


trackTabDomId : OnboardingTrack -> String
trackTabDomId track =
    "wl-start-tab-" ++ trackSlug track


trackPanelDomId : OnboardingTrack -> String
trackPanelDomId track =
    "wl-start-panel-" ++ trackSlug track


focusTargetDomId : FocusTarget -> String
focusTargetDomId target =
    case target of
        FocusTrackTab track ->
            trackTabDomId track

        FocusMobileMenuToggle ->
            "wl-start-nav-toggle"


stepTrack : Int -> OnboardingTrack -> OnboardingTrack
stepTrack delta current =
    let
        findIdx idx remaining =
            case remaining of
                [] ->
                    0

                first :: rest ->
                    if first == current then
                        idx

                    else
                        findIdx (idx + 1) rest

        itemAt fallback idx remaining =
            case remaining of
                [] ->
                    fallback

                first :: rest ->
                    if idx <= 0 then
                        first

                    else
                        itemAt fallback (idx - 1) rest

        total =
            List.length orderedTracks

        nextIdx =
            modBy (Basics.max 1 total) (findIdx 0 orderedTracks + delta)
    in
    itemAt TrackSimulatedBrowser nextIdx orderedTracks


update : Msg -> Model -> ( Model, Cmd Msg )
update msg currentModel =
    case msg of
        SelectTheme chosenTheme ->
            ( { currentModel | theme = chosenTheme }, Cmd.none )

        SelectMotion chosenMotion ->
            ( { currentModel | motion = chosenMotion }, Cmd.none )

        ToggleMobileNav ->
            ( { currentModel | mobileNavOpen = not currentModel.mobileNavOpen }, Cmd.none )

        EscapeMobileNav ->
            if currentModel.mobileNavOpen then
                let
                    nextSeq =
                        currentModel.tabFocusSeq + 1
                in
                ( { currentModel | mobileNavOpen = False, tabFocusSeq = nextSeq }
                , Task.attempt
                    (FocusSettled nextSeq FocusMobileMenuToggle)
                    (Dom.focus "wl-start-nav-toggle")
                )

            else
                ( currentModel, Cmd.none )

        SelectTrack chosenTrack ->
            ( { currentModel
                | activeTrack = chosenTrack
                , tabFocusSeq = currentModel.tabFocusSeq + 1
              }
            , Cmd.none
            )

        KeyboardStepTrack delta ->
            let
                nextTrack =
                    stepTrack delta currentModel.activeTrack

                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | activeTrack = nextTrack
                , tabFocusSeq = nextSeq
              }
            , Task.attempt
                (FocusSettled nextSeq (FocusTrackTab nextTrack))
                (Dom.focus (trackTabDomId nextTrack))
            )

        KeyboardJumpTrack targetTrack ->
            let
                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | activeTrack = targetTrack
                , tabFocusSeq = nextSeq
              }
            , Task.attempt
                (FocusSettled nextSeq (FocusTrackTab targetTrack))
                (Dom.focus (trackTabDomId targetTrack))
            )

        FocusSettled seq target outcome ->
            let
                matchesCurrent =
                    seq
                        == currentModel.tabFocusSeq
                        && (case target of
                                FocusTrackTab track ->
                                    track == currentModel.activeTrack

                                FocusMobileMenuToggle ->
                                    not currentModel.mobileNavOpen
                           )
            in
            if not matchesCurrent then
                ( currentModel, Cmd.none )

            else
                case outcome of
                    Ok () ->
                        ( { currentModel | lastFocusMiss = Nothing }, Cmd.none )

                    Err (Dom.NotFound _) ->
                        ( { currentModel | lastFocusMiss = Just (focusTargetDomId target) }, Cmd.none )



-- IME-SAFE KEYBOARD DECODERS


decodeMissingDefaultField : String -> Decode.Decoder a -> a -> Decode.Decoder a
decodeMissingDefaultField fieldName valueDecoder defaultValue =
    Decode.maybe (Decode.field fieldName Decode.value)
        |> Decode.andThen
            (\maybeRaw ->
                case maybeRaw of
                    Nothing ->
                        Decode.succeed defaultValue

                    Just rawVal ->
                        case Decode.decodeValue valueDecoder rawVal of
                            Ok typed ->
                                Decode.succeed typed

                            Err _ ->
                                Decode.fail ("invalid field " ++ fieldName)
            )


decodeNonComposingKey : Decode.Decoder String
decodeNonComposingKey =
    Decode.map3
        (\keyName composing code -> ( keyName, composing, code ))
        (Decode.field "key" Decode.string)
        (decodeMissingDefaultField "isComposing" Decode.bool False)
        (decodeMissingDefaultField "keyCode" Decode.int 0)
        |> Decode.andThen
            (\( keyName, composing, code ) ->
                if composing || code == 229 || keyName == "Process" then
                    Decode.fail "IME composition active"

                else
                    Decode.succeed keyName
            )


decodeEscapeMenu : Decode.Decoder Msg
decodeEscapeMenu =
    decodeNonComposingKey
        |> Decode.andThen
            (\keyName ->
                if keyName == "Escape" then
                    Decode.succeed EscapeMobileNav

                else
                    Decode.fail "not Escape"
            )


decodeTrackTabKey : Decode.Decoder ( Msg, Bool )
decodeTrackTabKey =
    decodeNonComposingKey
        |> Decode.andThen
            (\keyName ->
                case keyName of
                    "ArrowRight" ->
                        Decode.succeed ( KeyboardStepTrack 1, True )

                    "ArrowDown" ->
                        Decode.succeed ( KeyboardStepTrack 1, True )

                    "ArrowLeft" ->
                        Decode.succeed ( KeyboardStepTrack -1, True )

                    "ArrowUp" ->
                        Decode.succeed ( KeyboardStepTrack -1, True )

                    "Home" ->
                        Decode.succeed ( KeyboardJumpTrack TrackSimulatedBrowser, True )

                    "End" ->
                        Decode.succeed ( KeyboardJumpTrack TrackDesignFoundations, True )

                    _ ->
                        Decode.fail "unhandled track tab key"
            )



-- VIEW (CSS-FREE ELM: PRESERVES ALL 6 CANONICAL SECTION IDs)


view : Model -> Html Msg
view currentModel =
    Html.div
        [ Attr.class "wl-home-root"
        , Attr.attribute "data-theme" (themeSlug currentModel.theme)
        , Attr.attribute "data-motion" (motionSlug currentModel.motion)
        , Attr.attribute "data-nav-open" (boolToken currentModel.mobileNavOpen)
        ]
        (sharedHeadLinks
            ++ [ Html.a [ Attr.class "wl-doc-skip", Attr.href "#main" ] [ Html.text "Skip to content" ]
               , viewHeader currentModel
               , Html.div [ Attr.class "wl-doc-layout" ]
                    [ viewSideNav
                    , Html.main_
                        [ Attr.id "main"
                        , Attr.tabindex -1
                        ]
                        [ Html.nav [ Attr.attribute "aria-label" "Breadcrumb" ]
                            [ Html.a [ Attr.href "../index.html" ] [ Html.text "Home" ]
                            , Html.text " / "
                            , Html.a [ Attr.href "../get-started/index.html" ] [ Html.text "Get started" ]
                            , Html.text " / Get started"
                            ]
                        , Html.article []
                            [ Html.h1 [] [ Html.text "Get started" ]
                            , Html.p [ Attr.class "wl-doc-lead" ]
                                [ Html.text "Try the simulated browser stage immediately, inspect how to verify the Elm and Haskell beta from source, or download the design foundations." ]
                            , viewDesktopSection
                            , viewOnboardingTracksSection currentModel
                            , viewDownloadsSection
                            , viewIntegrationSection
                            , viewArchitectureSection
                            , viewContributeSection
                            ]
                        ]
                    , Html.aside [ Attr.class "wl-doc-toc" ]
                        [ Html.nav [ Attr.attribute "aria-label" "On this page" ]
                            [ Html.a [ Attr.href "#desktop" ] [ Html.text "Enter the desktop" ]
                            , Html.a [ Attr.href "#onboarding-tracks" ] [ Html.text "Beta onboarding tracks" ]
                            , Html.a [ Attr.href "#downloads" ] [ Html.text "Download the foundations" ]
                            , Html.a [ Attr.href "#integration" ] [ Html.text "Integrate the CSS" ]
                            , Html.a [ Attr.href "#architecture" ] [ Html.text "Elm and Haskell architecture" ]
                            , Html.a [ Attr.href "#contribute" ] [ Html.text "Contribute" ]
                            ]
                        ]
                    ]
               , viewFooter
               ]
        )


sharedHeadLinks : List (Html msg)
sharedHeadLinks =
    let
        stylesheet path =
            Html.node "link"
                [ Attr.attribute "rel" "stylesheet"
                , Attr.href path
                ]
                []
    in
    [ Html.node "link"
        [ Attr.attribute "rel" "icon"
        , Attr.href "../assets/brand/identity/warlock-mark-mono.svg"
        ]
        []
    , stylesheet "../assets/shared/layers.css"
    , stylesheet "../assets/shared/tokens.css"
    , stylesheet "../assets/shared/fonts.css"
    , stylesheet "../assets/shared/site.css"
    , stylesheet "../assets/shared/glyphs.css"
    , stylesheet "../assets/shared/landing.css"
    , stylesheet "../assets/shared/effects.css"
    ]


viewHeader : Model -> Html Msg
viewHeader currentModel =
    Html.header
        [ Attr.class "wl-doc-header wl-home-header"
        , Events.on "keydown" decodeEscapeMenu
        ]
        [ Html.div [ Attr.class "wl-home-bar" ]
            [ Html.a
                [ Attr.class "wl-doc-brand"
                , Attr.href "../index.html"
                , Attr.attribute "aria-label" "Warlock home"
                ]
                [ Html.img
                    [ Attr.src "../assets/brand/identity/warlock-mark.svg"
                    , Attr.alt ""
                    , Attr.width 32
                    , Attr.height 32
                    ]
                    []
                , Html.span [] [ Html.text "WARLOCK" ]
                ]
            , Html.div [ Attr.class "wl-home-mobile-actions" ]
                [ Html.a
                    [ Attr.class "wl-doc-button wl-doc-button-primary wl-home-mobile-cta"
                    , Attr.href "../test-drive/index.html"
                    ]
                    [ Html.text "Test drive (sim)" ]
                , Html.button
                    [ Attr.id "wl-start-nav-toggle"
                    , Attr.type_ "button"
                    , Attr.class "wl-doc-button wl-home-nav-toggle"
                    , Attr.attribute "aria-expanded" (boolToken currentModel.mobileNavOpen)
                    , Attr.attribute "aria-controls" "wl-start-nav-drawer"
                    , Events.onClick ToggleMobileNav
                    ]
                    [ Html.text
                        (if currentModel.mobileNavOpen then
                            "Close menu"

                         else
                            "Menu"
                        )
                    ]
                ]
            ]
        , Html.div
            [ Attr.id "wl-start-nav-drawer"
            , Attr.class "wl-home-drawer"
            ]
            [ Html.nav
                [ Attr.class "wl-home-nav"
                , Attr.attribute "aria-label" "Primary"
                ]
                [ Html.a [ Attr.href "../index.html" ] [ Html.text "Home" ]
                , Html.a [ Attr.href "../test-drive/index.html" ] [ Html.text "Test drive (sim)" ]
                , Html.a [ Attr.href "../foundations/index.html" ] [ Html.text "Foundations" ]
                , Html.a [ Attr.href "../styles/index.html" ] [ Html.text "Styles" ]
                , Html.a [ Attr.href "../components/index.html" ] [ Html.text "Components" ]
                , Html.a [ Attr.href "../architecture/index.html" ] [ Html.text "Architecture" ]
                , Html.a [ Attr.href "../get-started/index.html", Attr.attribute "aria-current" "page" ] [ Html.text "Get started" ]
                , Html.a [ Attr.href "../search/index.html" ] [ Html.text "Search" ]
                ]
            , Html.div [ Attr.class "wl-home-toolbar" ]
                [ Html.div
                    [ Attr.class "wl-home-seg"
                    , Attr.attribute "role" "group"
                    , Attr.attribute "aria-label" "Page appearance theme"
                    ]
                    [ viewThemeBtn currentModel.theme ThemeNight "Night"
                    , viewThemeBtn currentModel.theme ThemeDawn "Dawn"
                    , viewThemeBtn currentModel.theme ThemeHighContrast "High contrast"
                    ]
                , Html.div
                    [ Attr.class "wl-home-seg"
                    , Attr.attribute "role" "group"
                    , Attr.attribute "aria-label" "Motion preference"
                    ]
                    [ viewMotionBtn currentModel.motion MotionStandard "Standard motion"
                    , viewMotionBtn currentModel.motion MotionReduced "Reduced motion"
                    ]
                ]
            ]
        ]


viewThemeBtn : AppearanceTheme -> AppearanceTheme -> String -> Html Msg
viewThemeBtn activeTheme targetTheme labelText =
    Html.button
        [ Attr.type_ "button"
        , Attr.class "wl-home-seg-btn"
        , Attr.attribute "aria-pressed" (boolToken (activeTheme == targetTheme))
        , Events.onClick (SelectTheme targetTheme)
        ]
        [ Html.text labelText ]


viewMotionBtn : MotionMode -> MotionMode -> String -> Html Msg
viewMotionBtn activeMotion targetMotion labelText =
    Html.button
        [ Attr.type_ "button"
        , Attr.class "wl-home-seg-btn"
        , Attr.attribute "aria-pressed" (boolToken (activeMotion == targetMotion))
        , Events.onClick (SelectMotion targetMotion)
        ]
        [ Html.text labelText ]


viewSideNav : Html msg
viewSideNav =
    Html.nav
        [ Attr.id "site-nav"
        , Attr.class "wl-doc-nav"
        , Attr.attribute "aria-label" "Section links"
        ]
        [ Html.a [ Attr.href "../index.html" ] [ Html.text "Home" ]
        , Html.a [ Attr.href "../test-drive/index.html" ] [ Html.text "Test drive" ]
        , Html.a [ Attr.href "../foundations/index.html" ] [ Html.text "Foundations" ]
        , Html.a [ Attr.href "../styles/index.html" ] [ Html.text "Styles" ]
        , Html.a [ Attr.href "../components/index.html" ] [ Html.text "Components" ]
        , Html.a [ Attr.href "../architecture/index.html" ] [ Html.text "Architecture" ]
        , Html.a [ Attr.href "../get-started/index.html", Attr.attribute "aria-current" "page" ] [ Html.text "Get started" ]
        , Html.a [ Attr.href "../get-started/contributing/index.html" ] [ Html.text "Contributing" ]
        , Html.a [ Attr.href "../get-started/licenses/index.html" ] [ Html.text "Licenses and attribution" ]
        ]


viewDesktopSection : Html msg
viewDesktopSection =
    Html.section [ Attr.id "desktop" ]
        [ Html.h2 [] [ Html.text "Enter the desktop" ]
        , Html.p []
            [ Html.a
                [ Attr.class "wl-doc-button wl-doc-button-primary"
                , Attr.href "../test-drive/index.html"
                ]
                [ Html.text "Enter the simulated desktop" ]
            , Html.text " "
            , Html.a
                [ Attr.class "wl-doc-button"
                , Attr.href "../index.html"
                ]
                [ Html.text "Inspect live beta walkthrough on Home" ]
            ]
        , Html.p []
            [ Html.text "Real compiled Elm interface on a simulated Omarchy desktop: explore all 16 browser scenarios, window groups, workspaces, snap layouts, and shell surfaces immediately. Client window interiors and service responses are deterministic fixtures." ]
        , Html.p []
            [ Html.strong [] [ Html.text "Live Omarchy beta status (commit 8d1100f0e): " ]
            , Html.text "Authored production uses Elm and Haskell only (18 of 242 whole requirements and 42 of 417 scenarios recorded; persistent desktop host, native window controls, application launch, and release acceptance remain open). Current bounded "
            , Html.code [] [ Html.text "--application-only" ]
            , Html.text " trials ("
            , Html.code [] [ Html.text "D <= 28 s" ]
            , Html.text ") exercise read-only "
            , Html.code [] [ Html.text "Applications" ]
            , Html.text " catalog search ("
            , Html.code [] [ Html.text "foot" ]
            , Html.text ", "
            , Html.code [] [ Html.text "footz" ]
            , Html.text ", and "
            , Html.code [] [ Html.text "Refresh" ]
            , Html.text " query retention) while keeping the six non-Applications bar openers and "
            , Html.code [] [ Html.text "Open <App>" ]
            , Html.text " launches disabled ("
            , Html.code [] [ Html.text "nativeOperations = []" ]
            , Html.text ", child "
            , Html.code [] [ Html.text "exitCode = 1" ]
            , Html.text ")."
            ]
        ]


viewOnboardingTracksSection : Model -> Html Msg
viewOnboardingTracksSection currentModel =
    let
        activeSpec =
            findTrackSpec currentModel.activeTrack
    in
    Html.section [ Attr.id "onboarding-tracks" ]
        [ Html.h2 [] [ Html.text "Choose your beta onboarding track" ]
        , Html.p []
            [ Html.text "Use Left/Right arrow keys, Home, or End to compare what runs in your browser right now versus source verification and isolated Omarchy trials." ]
        , Html.div
            [ Attr.class "wl-home-tabs"
            , Attr.attribute "role" "tablist"
            , Attr.attribute "aria-label" "Beta onboarding tracks"
            , Events.preventDefaultOn "keydown" decodeTrackTabKey
            ]
            (List.map (viewTrackTab currentModel.activeTrack) onboardingTracks)
        , Html.div
            [ Attr.id (trackPanelDomId activeSpec.track)
            , Attr.class "wl-home-card"
            , Attr.attribute "role" "tabpanel"
            , Attr.attribute "aria-labelledby" (trackTabDomId activeSpec.track)
            , Attr.tabindex 0
            ]
            [ Html.p [ Attr.class "wl-home-badge" ] [ Html.text activeSpec.badge ]
            , Html.h3 [] [ Html.text activeSpec.shortTitle ]
            , Html.p [] [ Html.text activeSpec.summary ]
            , Html.h4 [] [ Html.text "Available and verified in this track" ]
            , Html.ul [] (List.map (\item -> Html.li [] [ Html.text item ]) activeSpec.availableNow)
            , Html.h4 [] [ Html.text "Unavailable or still gated" ]
            , Html.ul [] (List.map (\item -> Html.li [] [ Html.text item ]) activeSpec.unavailableOrGated)
            , Html.pre [] [ Html.code [] [ Html.text activeSpec.commandOrAction ] ]
            ]
        ]


viewTrackTab : OnboardingTrack -> TrackSpec -> Html Msg
viewTrackTab activeTrack spec =
    let
        isSelected =
            activeTrack == spec.track
    in
    Html.button
        [ Attr.id (trackTabDomId spec.track)
        , Attr.type_ "button"
        , Attr.class "wl-home-tab"
        , Attr.attribute "role" "tab"
        , Attr.attribute "aria-selected" (boolToken isSelected)
        , Attr.attribute "aria-controls" (trackPanelDomId spec.track)
        , Attr.tabindex
            (if isSelected then
                0

             else
                -1
            )
        , Events.onClick (SelectTrack spec.track)
        ]
        [ Html.text spec.shortTitle ]


viewDownloadsSection : Html msg
viewDownloadsSection =
    Html.section [ Attr.id "downloads" ]
        [ Html.h2 [] [ Html.text "Download the foundations" ]
        , Html.p []
            [ Html.strong [] [ Html.text "No desktop binary, AppImage, or Omarchy package installer is published yet " ]
            , Html.text "(reproducible release qualification "
            , Html.code [] [ Html.text "ELM-DEL-011" ]
            , Html.text " and reversible Omarchy deployment "
            , Html.code [] [ Html.text "ELM-DEL-014" ]
            , Html.text " remain open). The downloads below provide the licensed design tokens, fonts, and brand marks only:"
            ]
        , Html.ul []
            [ Html.li []
                [ Html.a [ Attr.href "../assets/shared/tokens.css", Attr.attribute "download" "" ] [ Html.text "CSS tokens" ]
                , Html.text " and "
                , Html.a [ Attr.href "../assets/shared/tokens.json", Attr.attribute "download" "" ] [ Html.text "JSON tokens" ]
                ]
            , Html.li []
                [ Html.a [ Attr.href "../assets/fonts/inter-variable.woff2", Attr.attribute "download" "" ] [ Html.text "Inter" ]
                , Html.text ", "
                , Html.a [ Attr.href "../assets/fonts/space-grotesk-bold.woff2", Attr.attribute "download" "" ] [ Html.text "Space Grotesk Bold" ]
                , Html.text ", and "
                , Html.a [ Attr.href "../assets/fonts/jetbrains-mono-regular.woff2", Attr.attribute "download" "" ] [ Html.text "JetBrains Mono Regular" ]
                ]
            , Html.li []
                [ Html.a [ Attr.href "../assets/brand/identity/warlock-mark.svg", Attr.attribute "download" "" ] [ Html.text "Warlock mark" ]
                , Html.text " and "
                , Html.a [ Attr.href "../assets/brand/identity/warlock-mark-mono.svg", Attr.attribute "download" "" ] [ Html.text "monochrome mark" ]
                ]
            ]
        , Html.p []
            [ Html.text "Read the "
            , Html.a [ Attr.href "licenses/index.html" ] [ Html.text "font notices and attribution" ]
            , Html.text " before redistribution."
            ]
        ]


viewIntegrationSection : Html msg
viewIntegrationSection =
    Html.section [ Attr.id "integration" ]
        [ Html.h2 [] [ Html.text "Integrate the CSS" ]
        , Html.p []
            [ Html.text "Opt in with "
            , Html.code [] [ Html.text "data-warlock-design=\"v1\"" ]
            , Html.text " on the root element and choose "
            , Html.code [] [ Html.text "data-theme=\"night\"" ]
            , Html.text ", "
            , Html.code [] [ Html.text "dawn" ]
            , Html.text ", or "
            , Html.code [] [ Html.text "high-contrast" ]
            , Html.text ". Load the shared cascade order first, followed by tokens, fonts, site, and effects:"
            ]
        , Html.pre []
            [ Html.code []
                [ Html.text
                    (String.join "\n"
                        [ "<link rel=\"stylesheet\" href=\"../assets/shared/layers.css\">"
                        , "<link rel=\"stylesheet\" href=\"../assets/shared/tokens.css\">"
                        , "<link rel=\"stylesheet\" href=\"../assets/shared/fonts.css\">"
                        , "<link rel=\"stylesheet\" href=\"../assets/shared/site.css\">"
                        , "<link rel=\"stylesheet\" href=\"../assets/shared/effects.css\">"
                        ]
                    )
                ]
            ]
        ]


viewArchitectureSection : Html msg
viewArchitectureSection =
    Html.section [ Attr.id "architecture" ]
        [ Html.h2 [] [ Html.text "Elm and Haskell architecture" ]
        , Html.p []
            [ Html.text "Every visible Warlock surface uses The Elm Architecture (typed models, pure updates, messages, and explicit ports or origin-bound HTTP), paired with a Haskell backend that supervises child processes, serves verified HTML, checks binary dependencies, and reports closed failure and retirement diagnostics ("
            , Html.code [] [ Html.text "ELM-DEL-017" ]
            , Html.text " partial; 32 ordinary logs scanned with zero leaked credential, draft, or pixel markers) without shipping a Python runtime. "
            , Html.a [ Attr.href "../architecture/index.html" ] [ Html.text "Explore the component architecture" ]
            , Html.text "."
            ]
        ]


viewContributeSection : Html msg
viewContributeSection =
    Html.section [ Attr.id "contribute" ]
        [ Html.h2 [] [ Html.text "Contribute" ]
        , Html.p []
            [ Html.a [ Attr.href "contributing/index.html" ] [ Html.text "Read contribution guidance" ]
            , Html.text " and "
            , Html.a [ Attr.href "licenses/index.html" ] [ Html.text "licenses and attribution" ]
            , Html.text "."
            ]
        ]


viewFooter : Html msg
viewFooter =
    Html.footer [ Attr.class "wl-doc-footer" ]
        [ Html.p [] [ Html.text "Warlock. Crafted for flow · Elm + Haskell." ]
        , Html.a [ Attr.href "../get-started/contributing/index.html" ] [ Html.text "Contribute" ]
        , Html.a [ Attr.href "../get-started/licenses/index.html" ] [ Html.text "Licenses and attribution" ]
        , Html.p [] [ Html.text "Apache License 2.0" ]
        ]



-- DATA & HELPERS


themeSlug : AppearanceTheme -> String
themeSlug chosenTheme =
    case chosenTheme of
        ThemeNight ->
            "night"

        ThemeDawn ->
            "dawn"

        ThemeHighContrast ->
            "high-contrast"


motionSlug : MotionMode -> String
motionSlug chosenMotion =
    case chosenMotion of
        MotionStandard ->
            "standard"

        MotionReduced ->
            "reduced"


boolToken : Bool -> String
boolToken flag =
    if flag then
        "true"

    else
        "false"


findTrackSpec : OnboardingTrack -> TrackSpec
findTrackSpec target =
    let
        pick remaining =
            case remaining of
                [] ->
                    simulatedTrackSpec

                first :: rest ->
                    if first.track == target then
                        first

                    else
                        pick rest
    in
    pick onboardingTracks


simulatedTrackSpec : TrackSpec
simulatedTrackSpec =
    { track = TrackSimulatedBrowser
    , slug = "simulated-browser"
    , shortTitle = "1. Browser test drive (sim)"
    , badge = "Instant in any modern browser · Simulated desktop fixtures"
    , summary = "Runs the real compiled Elm shell against an in-browser simulated Omarchy workspace across 16 scenarios and a guided tour."
    , availableNow =
        [ "All 16 interactive shell scenarios (Taskbar, Launcher, Switcher, Task View, Snap, Notifications, Settings, Files, System)"
        , "Guided interactive tour with simulated service fault injection (Success, Delayed, Refused, Unknown, Unavailable)"
        , "Keyboard shortcut legend and browser-safe chord alternatives"
        ]
    , unavailableOrGated =
        [ "Client window interiors and service responses are browser fixtures, not host Wayland/X11 windows"
        , "Browser demonstrations never qualify native Hyprland, AT/IME, or release obligations"
        ]
    , commandOrAction = "Open ../test-drive/index.html or click 'Enter the simulated desktop' above."
    }


onboardingTracks : List TrackSpec
onboardingTracks =
    [ simulatedTrackSpec
    , { track = TrackSourceVerification
      , slug = "source-verification"
      , shortTitle = "2. Source & CPU checks"
      , badge = "Commit 8d1100f0e · Source-bound Elm + Haskell suites"
      , summary = "Contributors verify pure Elm reducers, narrow HTTP/port interop, and Haskell process/origin/diagnostics suites from source."
      , availableNow =
            [ "Whole ELM-TEA-001 (bdeac7349), ELM-TEA-002, and ELM-TEA-005 accepted on their recorded source tuples (18/242 EARS, 42/417 scenarios)"
            , "Protected 345-input Haskell profile passes 10 suites / 64 commands; 32 ordinary logs scanned with 0 leaked credential/draft/pixel markers (ELM-DEL-017 partial)"
            , "7,293 HTTP/DOM checks, 137 typed controls, and 61 policy histories verified on CPU"
            ]
      , unavailableOrGated =
            [ "CPU and Quint model results are separate claims and never substitute for native Omarchy GUI acceptance"
            , "Protected QA launcher serializes suite execution; do not treat component observations as whole-EARS closure"
            ]
      , commandOrAction = "git clone https://github.com/CharlesHoskinson/Warlock.git\n# See docs/HANDOFF.md and docs/warlock/how-to/run-omarchy-mvp.md"
      }
    , { track = TrackOmarchyBetaTrial
      , slug = "omarchy-beta-trial"
      , shortTitle = "3. Isolated Omarchy trial"
      , badge = "Bounded D <= 28 s · --application-only read-only search"
      , summary = "Runs the Haskell/WebKitGTK host inside an isolated Omarchy session alongside Hyprland without replacing your main desktop."
      , availableNow =
            [ "17 guarded guest inputs exercise Applications -> Search ('foot' match, 'footz' no-match) -> Refresh query retention"
            , "Bar opens Applications (bar:applications) and Popup supports Search (control:search), Refresh (control:refresh), and Close (control:close)"
            , "Closed Backend diagnostics pinpoint selectedOperationSucceeded = false (child exitCode = 1) while confirming all 3 backend retirement classes"
            ]
      , unavailableOrGated =
            [ "Six bar openers (bar:overview, bar:switcher, bar:notifications, bar:files, bar:system, bar:settings) are disabled (nativeOperations = [])"
            , "Application launch (entry:*, jump:open:*) and pin mutations are disabled in --application-only mode; HttpPopup has no automatic reconnect"
            , "Overall trial still exits 1 (selectedOperationSucceeded = false) and strict QA cgroup check hits FileNotFoundError after retirement; HOSTSTOP2 & native/release acceptance remain open"
            ]
      , commandOrAction = "# Follow docs/warlock/how-to/run-omarchy-mvp.md in an isolated Omarchy VM/session only\n# Never overwrite /usr/share/omarchy or load mismatched Hyprland plugin ABIs"
      }
    , { track = TrackDesignFoundations
      , slug = "design-foundations"
      , shortTitle = "4. Tokens & CSS only"
      , badge = "No desktop binary or installer published yet"
      , summary = "Adopt Warlock's Lacquer CSS tokens, @layer cascade, licensed fonts, and brand marks in web documentation."
      , availableNow =
            [ "Downloadable tokens.css, tokens.json, Inter, Space Grotesk Bold, JetBrains Mono Regular, and SVG marks"
            , "Night, Dawn, and High-contrast theme tokens plus reduced-motion cascade support"
            ]
      , unavailableOrGated =
            [ "No desktop binary, AppImage, pacman package, or Omarchy installer is available for download (ELM-DEL-011 and ELM-DEL-014 open)"
            ]
      , commandOrAction = "Download tokens.css / tokens.json in #downloads below and review get-started/licenses/index.html."
      }
    ]
