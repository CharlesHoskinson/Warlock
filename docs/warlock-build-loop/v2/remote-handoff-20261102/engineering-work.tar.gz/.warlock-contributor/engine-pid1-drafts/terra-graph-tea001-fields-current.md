# TEA001 current finite-field and authority inventory

Source-only review of the exact hashes below. TEA002 is independently accepted for source commit 889e9458d1707c456f5bb6e9af560383b066229e, acceptance commit 59a2f38ab2b26f6d76cad34039b59911a36188dc; this TEA001 work does not reopen it. New source changes require their own applicable qualification, and native claims remain separate. Six-root, 73-local-module lexical type index `terra-graph-tea001-six-root-type-index-postwave.md` SHA256 6d9a1d9b7223891a153be8f1d30c6ead478f0283d088690b87de021580fc6b00 matches all indexed source hashes as of this review. It is not a compiler graph or proof that all type/authority obligations are met.

## Already typed in current source

- Effects.Operation and Status, Shell.Phase, Launch.Phase/ResultState, WorkspaceNavigation.Status, Menu.Action/Outcome/Status, Settings.SaveOutcome, Pins.Confirmation, Motion.Profile, MotionPreferences.Override, ShortcutPreferences.Choice.
- JumpList.Action.kind is ActionKind DesktopAction/RecentAction, with protected component report 1793560906209268899 recording the four matching type/wire/negative/description checks. Notifications.EntryState/Verb/OutcomeStatus and ReconciliationFrame.ProofKind/RetirementOperation/GrantState are typed in this tuple. Source qualification is not whole TEA001 acceptance.
- Desktop ingress SaveReceipt and ShortcutSaveReceipt types reject unknown status strings, but several downstream child `receive` APIs continue to accept String. Their actual boundary and independent malformed pending-state cases need evaluation, not invented whole closure.

## Current retained finite Strings or scoped audit candidates

| Source and retained value | Exact source-admitted set or role | Status / caution |
| --- | --- | --- |
| Motion.Observation.source | portal, gtk (`Motion.elm:45`) | Actual ignored patch `terra-graph-tea001-motion-source.patch` SHA256 59c0f0f6944e4cf55ada6bc4206b2f0bf8346bd3a8bf8a0655f548b717dd87dd is source-reviewed, not integrated or tested; source+qa/MotionReplay.elm require Root declaration/claim. |
| Snap.Proposal.region | six named regions; lives in Effects.SnapPlacement | security draft `terra-security-tea001-snap-region.patch` SHA256 c7c8c7540e8bad4dbe0d016b412bb71d297f657acf8477edd6bdf6416bff962d source-reviewed; no integration/test claimed. |
| CapturedAction surface and optional trigger | bar/popup, pointer/keyboard; opaque transport, not native-origin authority | gemini-site draft `Tea001CapturedActionAdt.patch` SHA256 2e6a48ec7fa576fec647aa9ea27e25f219ddc095dd01418219e6e90dc0bd157f source-reviewed; no integration/test claimed. |
| SystemMenu.Snapshot network.permission and power.{suspend,reboot,poweroff} | network yes/no/auth; power yes/no/na/challenge | finite native-observed capabilities; inspect Sol's active ownership and preserve exact wire/eligibility. Network.state and session.state are only length-bounded; do not invent enums. |
| GeometryProjection.Capabilities.operations | negotiated finite operation names | stored List String affects eligibility. Audit exact decoder, historical compatibility and all effect authority before deciding conversion. |
| PreviewPresenter.Entry.iconKind | application/generic/unavailable | retained Popup preview state; compare icon consistency and independent native-preview authority. |
| SurfaceSnapshot.Details.mode/motion | validated finite presentation modes and motion | renderer cache, not native observation itself. Assess semantics and any local editing paths separately; Details.status is human-readable prose. |
| NativePreviewProposalIngress.Proposal/Ticket/Packet.kind | exact temporary wire discriminators | persistent Model is grant+raw-command queue; classify lifecycle relevance and native authority before proposing type change. |
| Settings/MotionPreferences/ShortcutPreferences/Files/JumpList/SystemMenu/Notifications receive status args | finite checks and matching differ by domain | Some transient String APIs follow validated Desktop ingress, some perform their own finite match. Audit direct callers and pending/Unknown semantics; preserve all source-bound regressions. |

Source string names alone do not constitute proof of a missing custom type: labels, identities, provider/native free text, workspace IDs, receipt correlation strings, exact batch wire and user-entered paths remain text unless their actual contract says otherwise. Boolean/Maybe state can still hide invalid lifecycle combinations; a type-name scan alone is not the required whole-001 audit.

## Single-authority and observation checks still required

DesktopPolicy -> OutputController -> SurfaceController -> Desktop is the main policy route. Main and HttpMain interpret typed descriptions; renderer Presentation caches scoped projections. Popup.pendingQuery and composition are renderer-local, with actions suppressed until policy synchronization (`Popup.elm:54,78-117`); verify all renderer paths and native capability authorities independently before closing 001. Compare observed `Effects.Model.observed`, Motion.observation and Settings.snapshot against desired transaction/draft/pending/applied state; do not treat an unconfirmed request as a native observation. The original EARS needs typed compiler checks, deterministic replay and independent boundary fixtures tied to exact source hashes, plus independent source/authority review; it has not yet been accepted.

## Source hashes
a63de0a105e1a13edc5eb67359b665032acba662650659b3a24d4f1999058b66  implementation/warlock/src/Main.elm
58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9  implementation/warlock/src/HttpMain.elm
018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e  implementation/warlock/src/DesktopPolicy.elm
fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae  implementation/warlock/src/OutputController.elm
2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998  implementation/warlock/src/SurfaceController.elm
91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4  implementation/warlock/src/Desktop.elm
e101862bae874426f0cf9aaf02340c6582abdeea21dec38c32003da7f94e8a69  implementation/warlock/src/Motion.elm
8ee61de4cd63557d3f2928893ed35ce93f1e3290128847e66ca388aa5d98ec8e  implementation/warlock/src/Snap.elm
e61311c370fc0367844deb21a9ba3274a64f41faabe19bec6743af71685e2201  implementation/warlock/src/Notifications.elm
5f9480ab13609f26a3f57f37431e9eb29c658b1c009b463321e0f277d37b8ac5  implementation/warlock/src/ReconciliationFrame.elm
5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc  implementation/warlock/src/CapturedAction.elm
f1b5708b8b4d1c7c02e46542bc041abb9e8cb0524d965ee4b03ab97f586a544c  implementation/warlock/src/GeometryProjection.elm
cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054  implementation/warlock/src/SystemMenu.elm
10769b8d9a86e5e5b35f1f292d9837a38b20a0ba636d5baa0ee0c3b8fcdac1cc  implementation/warlock/src/PreviewPresenter.elm
58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7  implementation/warlock/src/SurfaceSnapshot.elm
d13f4d63327eae4a80052252c8ba1f1e40db0f69954b46470ccff248e5ba0e7c  implementation/warlock/src/Settings.elm
d3130d74c3172cb1808df38efd7a2cc267ba5ae346b564544661d3d539f5c560  implementation/warlock/src/MotionPreferences.elm
d8c1a63f199612161e078e0f6c7f75cbbfa190953e19325e50169debc425dcec  implementation/warlock/src/ShortcutPreferences.elm
c2099647bca3b325ca21485bb3a246e0b6d7c2a693d0bcfd5f10dedbad7a89f7  implementation/warlock/src/Files.elm
2ef6dbc9738771b1e13c8d42feb70c0905be8651d791a43199264b32883de195  implementation/warlock/src/JumpList.elm
c81a02d9644b5d31154017bd77b4cf1f90407d01e2026981a73df18a3a85eb25  implementation/warlock/qa/MotionReplay.elm
