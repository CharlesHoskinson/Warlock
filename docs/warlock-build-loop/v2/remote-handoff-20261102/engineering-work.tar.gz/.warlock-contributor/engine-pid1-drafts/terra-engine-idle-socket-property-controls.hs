-- Root-only source property fixture, seed 20261101, 32 socketpair schedules.
-- Requires draft module compiled with -DWARLOCK_IDLE_TEST; not executed here.
-- Tests only candidate socket readiness/retirement, not SCM, owner pidfd,
-- frame dispatch, provider cleanup, native behavior, or scenario acceptance.
module Main (main) where

import Control.Concurrent (ThreadId, forkFinally, newEmptyMVar, putMVar, readMVar)
import Control.Concurrent.STM (atomically, retry)
import Control.Exception (SomeException, mask_)
import Control.Monad (forM_, unless)
import qualified Data.ByteString as B
import Data.IORef
import GHC.Clock (getMonotonicTimeNSec)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Timeout (timeout)
import Warlock.Transport.IdleSocketLifetime

-- Published empty cells retain resources before any potentially blocking work;
-- this test-local registry is not production or durable quarantine.
data Held = Held (IORef (Maybe (S.Socket,S.Socket)))
                 (IORef (Maybe IdleSocketLifetime)) (IORef [ThreadId])
fixture :: IORef [Held] -> IO (IdleSocketLifetime,S.Socket,S.Socket,IORef [ThreadId])
fixture registry = mask_ $ do
  sockets <- newIORef Nothing
  owner <- newIORef Nothing
  workers <- newIORef []
  atomicModifyIORef' registry (\xs -> (Held sockets owner workers : xs, ()))
  (a,b) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  writeIORef sockets (Just (a,b))
  gate <- newIdleSocketLifetime a (S.close a)
  writeIORef owner (Just gate)
  pure (gate,a,b,workers)
spawn :: IORef [ThreadId] -> IO a -> IO (IO (Either SomeException a))
spawn workers task = mask_ $ do
  done <- newEmptyMVar
  tid <- forkFinally task (putMVar done)
  atomicModifyIORef' workers (\xs -> (tid:xs,()))
  pure (readMVar done)
within :: String -> IO a -> IO a
within label task = timeout 2000000 task >>= maybe (ioError (userError label)) pure
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
receiveExactly :: S.Socket -> Int -> IO B.ByteString
receiveExactly sock = go [] where
  go chunks 0 = pure (B.concat (reverse chunks))
  go chunks n = do
    part <- N.recv sock n
    if B.null part then ioError (userError "unexpected EOF")
      else go (part:chunks) (n - B.length part)

payload :: Int -> B.ByteString
payload caseNo = B.pack [ fromIntegral ((20261101 + caseNo * 37 + i * 71) `mod` 256)
                       | i <- [0 .. caseNo `mod` 63] ]

main :: IO ()
main = do
  retained <- newIORef []
  forM_ [0..31 :: Int] $ \caseNo -> do
    (gate,owned,peer,workers) <- fixture retained
    probe <- newIdleTestProbe
    let marker = payload caseNo
        ownerEvent = if caseNo `mod` 3 == 1 then pure (17 :: Int) else retry
    done <- spawn workers (waitIdleWithProbe gate probe ownerEvent)
    within "registration" (atomically (probeRegisteredSTM probe))
    N.sendAll peer marker
    -- Same single original stop D for the sole retire attempt and close.
    now <- toInteger <$> getMonotonicTimeNSec
    let stopD = now + 1500000000
    if caseNo `mod` 3 == 2 then do
      -- Retirement is latched while registration is intentionally parked.
      closing <- spawn workers (retireIdleSocket gate stopD)
      within "retire latch" (atomically (retiringSTM gate))
      releaseTestProbe probe
      wake <- within "retire wake" done
      check "retire priority" (case wake of Right (Just IdleRetiring) -> True; _ -> False)
      bytes <- within "retire bytes" (receiveExactly owned (B.length marker))
      check "retire did not consume" (bytes == marker)
      outcome <- within "drain" closing
      permit <- case outcome of Right (Drained p) -> pure p; _ -> ioError (userError "retire did not drain")
      closed <- closeAfterDrain permit
      check "close after drain" (closed == CloseCompleted)
    else do
      -- Case 1 has a prelatched owner wake and buffered bytes; event-manager
      -- readiness is asynchronous, so simultaneous-ready is not established.
      releaseTestProbe probe
      wake <- within "ready wake" done
      check "expected wake" (if caseNo `mod` 3 == 1
        then case wake of Right (Just (OwnerWake 17)) -> True; _ -> False
        else case wake of Right (Just SocketReadable) -> True; _ -> False)
      bytes <- within "ready bytes" (receiveExactly owned (B.length marker))
      check "readiness did not consume" (bytes == marker)
      result <- retireIdleSocket gate stopD
      permit <- case result of Drained p -> pure p; _ -> ioError (userError "ready did not drain")
      closed <- closeAfterDrain permit
      check "close after wait" (closed == CloseCompleted)
      repeated <- closeAfterDrain permit
      check "permit one-shot" (repeated == ClosePermitUsed)
    S.close peer
  held <- readIORef retained
  check "all fixture resources recorded" (length held == 32)
  putStrLn "idle socket 32 seeded source properties passed"
