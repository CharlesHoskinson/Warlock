{-# LANGUAGE OverloadedStrings #-}
-- UNRUN Root-only component fixture for private protocol source patch 779e9611.
-- Compile with its same-package test modules; no public probe or raw FD export.
-- Actual AF_UNIX registration/owner retirement, but synthetic credential guard;
-- no child, pidfd, SCM delivery, provider cleanup or original acceptance claim.
module Main (main) where

import Control.Concurrent (forkFinally)
import Control.Concurrent.MVar (newEmptyMVar, putMVar, readMVar)
import Control.Exception (mask_)
import Control.Monad (unless)
import Data.IORef (IORef, atomicModifyIORef', modifyIORef', newIORef, readIORef, writeIORef)
import GHC.Conc (STM, atomically, retry)
import qualified Network.Socket as Socket
import System.Timeout (timeout)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import Warlock.Protocol.Ingress.Internal
import Warlock.Transport.Channel (CredentialFrameError(..))

-- Kept through this fixture process: uncertainty is not a durable quarantine
-- receipt. Root owns process bounds and must retain failure output.
data Retained = Retained (IORef (Maybe CredentialIngress)) (IORef (Maybe (Socket.Socket, Socket.Socket)))
type Registry = IORef [Retained]

data Fixture = Fixture CredentialIngress Socket.Socket (IORef Int)

require :: String -> Bool -> IO ()
require name ok = unless ok (ioError (userError name))
within :: String -> IO a -> IO a
within name action = timeout 2000000 action >>= maybe (ioError (userError name)) pure

newFixture :: Registry -> IO Fixture
newFixture registry = mask_ $ do
  ownerCell <- newIORef Nothing
  socketCell <- newIORef Nothing
  atomicModifyIORef' registry (\items -> (Retained ownerCell socketCell : items, ()))
  binding <- either (ioError . userError . show) pure (ingressBinding "1" "2" "3")
  calls <- newIORef 0
  let callback _ = modifyIORef' calls (+1)
  ingress <- newDesktopCredentialIngress binding FromElm callback callback
  writeIORef ownerCell (Just ingress)
  (owned, peer) <- Socket.socketPair Socket.AF_UNIX Socket.Stream Socket.defaultProtocol
  writeIORef socketCell (Just (owned, peer))
  offered <- transferCredentialSocket ingress owned
  require "socket offer" (offered == OfferAccepted)
  activated <- activateCredentialIngress ingress
  require "socket activation" (activated == ActivationLive)
  pure (Fixture ingress peer calls)

-- No frame is admitted in these tests. This permissive guard is a source seam,
-- not authentication or proof of owner identity/stop-to-dispatch serialization.
fixtureGuard :: CredentialGuard ()
fixtureGuard = CredentialGuard (\_ -> pure (Right ())) (\_ action -> Right <$> action)
ownerNever :: STM ()
ownerNever = retry

main :: IO ()
main = do
  registry <- newIORef []

  -- Retirement first: a fresh later request must not register with epoll or
  -- invoke a callback. The ordinary unborrowed close must be confirmed.
  Fixture retired peerA callsA <- newFixture registry
  probeA <- newWaitProbe
  retiredA <- within "retire first" (retireCredentialIngress retired)
  require "retire-first confirmed close" (endpoint retiredA == Just EndpointConfirmed)
  late <- within "late receive" (receivePersistentCredentialIngressWithProbe (Just probeA) True ownerNever retired (const fixtureGuard))
  seenA <- timeout 30000 (atomically (waitProbeRegistered probeA))
  countA <- readIORef callsA
  require "retire-first did not register or dispatch"
    (late == PersistentOutcome CredentialNotLive && seenA == Nothing && countA == 0)
  Socket.close peerA

  -- Registration first: the probe is set only after actual threadWaitReadSTM
  -- registration while the SharedClose pin is held. Concurrent retire must
  -- fail closed as uncertain, never close a borrowed FD or authorize retry.
  Fixture active peerB callsB <- newFixture registry
  probeB <- newWaitProbe
  done <- newEmptyMVar
  _ <- forkFinally
    (receivePersistentCredentialIngressWithProbe (Just probeB) True ownerNever active (const fixtureGuard))
    (putMVar done)
  within "registration barrier" (atomically (waitProbeRegistered probeB))
  retiredB <- within "retire during registered wait" (retireCredentialIngress active)
  require "overlapping retirement is uncertain" (endpoint retiredB == Just EndpointUncertain)
  releaseWaitProbe probeB
  outcome <- within "waiter unregister and return" (readMVar done)
  countB <- readIORef callsB
  require "no delivery after retirement" (countB == 0 && case outcome of
    Right (PersistentCloseUncertain (CredentialFrameRejected (CredentialTransport Closed))) -> True
    _ -> False)
  repeated <- within "repeat retirement observation" (retireCredentialIngress active)
  require "uncertainty stays latched" (endpoint repeated == Just EndpointUncertain)
  -- The peer is closed only after the waiting thread joined. The uncertain
  -- owned endpoint is deliberately not blindly closed or reported as cleaned.
  Socket.close peerB
  retained <- readIORef registry
  require "fixture owners retained" (length retained == 2)
  putStrLn "close/register source controls completed; uncertain owner retained"
