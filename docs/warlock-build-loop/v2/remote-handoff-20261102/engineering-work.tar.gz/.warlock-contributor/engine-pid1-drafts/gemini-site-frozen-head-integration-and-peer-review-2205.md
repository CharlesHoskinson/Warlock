# `gemini-site` `2205` Frozen `HEAD` Website Patch, Source Fixture, Isolated-Worktree Integration Path & Peer Review

- **Author / Role**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run**: `warlock-20261031-setup`
- **Immutable Website Git Baseline**:
  - `112cde9c21b92e8cb39a404ffee1d52e9d612a6f:site/src/SiteMain.elm` **and** `d6becb72c4b261739a84325a55aac07a984ab1e4:site/src/SiteMain.elm` (identical git blob `a18279ecd6ddf2678cf1fdd5f9732aaa58959a75`, `sha256:9c432ddf2b7e4d35fae4197c52c4b97cb41fbfa16b45082d2143ea4d6b2d3ba1`, `63,706` bytes)
- **Canonical Ledger Baseline**: **`17 / 242` whole EARS requirements** and **`41 / 417` accepted scenarios**; persistent native Hyprland desktop and release **unaccepted**.
- **Custody & Safety**:
  - Foreign dirty `/home/charl/code/Warlock/site/src/SiteMain.elm` (`sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`) left completely untouched in main worktree (zero ownership claim).
  - All earlier `2039`, `2110`, and `2135` ignored proposals preserved untouched.
  - Zero canonical source writes and zero compiler, Node, Quint, browser, VM, or GPU execution performed by worker. Forbidden `tools/check_auth_cpu.py` and foreign `tools/check_tea_cpu.py` never read or touched.

---

## 1. Frozen `2205` Website Deliverables & Exact Cryptographic Hashes

| Deliverable | Ignored Path (`.warlock-contributor/engine-pid1-drafts/`) | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| Complete postimage Elm source (`site/src/SiteMain.elm`) | `SiteMainHeadMvpFrozen2205.elm` | `88719` | `90f3121ab50c7744be966ec5912a80f014db0fc258ea05e7e5f8f958b27fefda` |
| Minimal atomic `git diff` patch against `HEAD` | `SiteMainHeadMvpFrozen2205.patch` | `49640` | `746560dafc36270d8322d187d426a7179c090ba2df3e878df234e29350696293` |
| Pure-Elm deterministic source & MVP-matrix fixture (`Platform.worker`) | `SiteMainHeadFixture2205.elm` | `15398` | `6c9580393539d7165343bda615cfca5e886e1215b1021ad9831f0a3392f6b05c` |
| Literal responsive / focus / contrast / 16-scenario DOM oracle | `site-head-mvp-usability-qa-2205.cjs` | `26938` | `5b5a17139e7a5625c516f66c1e0b65a38a53ae7ddbd71e7f6629a1d69dd3948a` |

### Immutable Baseline -> Postimage Table (`112cde9c2` & `d6becb72` Identical on `site/`)

| Repository Path | Committed `HEAD` Git Blob SHA-1 | Committed `HEAD` SHA-256 | Frozen `2205` Postimage Git Blob SHA-1 | Frozen `2205` Postimage SHA-256 |
| --- | --- | --- | --- | --- |
| `site/src/SiteMain.elm` | `a18279ecd6ddf2678cf1fdd5f9732aaa58959a75` | `9c432ddf2b7e4d35fae4197c52c4b97cb41fbfa16b45082d2143ea4d6b2d3ba1` | `d3aae1c0b40d34a830e4e20a89d628248dbdcc81` | `90f3121ab50c7744be966ec5912a80f014db0fc258ea05e7e5f8f958b27fefda` |
| `site/index.html` *(shell)* | `751bc0bc47fec8afdb08d39d8b4742fbd40de9dc` | `2e5730d25fdc15b5c64197351d2c772021f5ad23a07887789793c8ec16ae69f2` | *(generated deterministically via `elm make` splice below)* | *(Root-qualified)* |
| `site/elm.json` *(unchanged)* | `80e60c7782655da90485e8d3a50ad7856ad7efd3` | `ffe9bc4f6811166a7bbafca49540bf7b8af214118dd9aff2f4707890eb9824dc` | `80e60c7782655da90485e8d3a50ad7856ad7efd3` | `ffe9bc4f6811166a7bbafca49540bf7b8af214118dd9aff2f4707890eb9824dc` |

---

## 2. Concrete Website Improvements Wired Into `SiteMain.main` (Zero Unused Symbols)

1. **At-a-Glance 4-Tier MVP Availability & Acceptance-Limits Matrix (`#wl-mvp-matrix` inside `#scope`)**:
   - Keyboard-scrollable `[role="region"][tabindex="0"]` table (`mvpMatrixRows : List MvpTierRow`) contrasting **Execution tier**, **Availability today**, **Verified baseline**, and **Acceptance limit (never proves)**:
     - **Browser test drive (`./test-drive/index.html`)** — `Runnable now · Simulated`: 16 seeded scenarios running compiled Elm `Main`, `Bar`, and `Popup` over deterministic fixtures; *never proves Linux processes, Wayland surfaces, AT/IME, or native desktop acceptance*.
     - **CPU, replay & Quint formal suites** — `17 / 242 whole EARS · 41 / 417 scenarios`: `ELM-TEA-002` (58 literal pure-update histories) and `ELM-TEA-005` (narrow validated interop, 10 Haskell suites / 273 model cases) accepted, pending-query reversal & remaining `ELM-TEA-001` slices in active integration; *establishes zero native GUI, hardware latency, AT/IME, or release acceptance*.
     - **Guarded Omarchy `--application-only` trial** — `Partial 28s VM component trial`: same-ELF Haskell + WebKitGTK runtime renders Elm bar and 62-entry catalog while live `Applications -> Search` guest action delivery and bar-ready startup gating remain under repair (stopped `UI-005` 45m window and failed runs preserved); *isolated VM observation only (`HOSTSTOP2` active, `nativeOperations = []`, provider cleanup unqualified)*.
     - **Persistent native Hyprland desktop & release** — `Unaccepted · Not released`: `225 of 242` whole EARS and `376 of 417` scenarios remain open (`ELM-ARC-024`, `ELM-DEL-014`, native previews, AT/IME, hardware budgets); *full release gate — main desktop untouched*.
2. **Interactive All-16 Seeded Scenario Launchpad (`#scenarios` / `allScenarioSpecs`) + Above-the-Fold Quick Strip (`#wl-quick-scenarios`)**:
   - Exposes **all 16 canonical `./test-drive/index.html?scenario=<slug>` scenarios** (`7` Windows & workspaces + `3` Apps & files + `6` System & recovery = `16`, matching `site/tools/check-site.py` `SCENARIOS` 1-to-1) with independent `SelectScenarioCategory` filtering that leaves `#features` editorial articles undisturbed.
3. **Shared Authoring Contract Alignment (`site/assets/shared/contract.md` + `compile.py`)**:
   - Adds `#wl-page-index` (`<nav aria-label="On this page">`) with underlined `44px` jump links to all 7 homepage sections.
   - Keeps link-styled scenario chips (`a.wl-home-scenario-chip`) underlined while keeping toggle/tab `<button>` chips clean.
   - Aligns `.wl-home-pill.is-active` outer border tokens with `site/assets/shared/authoring/compile.py:91` and `site.css:11` (`--wl-sys-color-on-action` in Night, `--wl-sys-color-brand-text` in Dawn, `--wl-sys-color-action-fill` in High Contrast); all **48** WCAG 2.1 contrast pairs across `night`, `dawn`, and `high-contrast` verify at **`>= 5.87:1`**.
   - Retains pure `transition`, `EscapeMobileNav` focus restoration to `#wl-home-nav-toggle`, 8-tab ARIA roving `tabindex` (`ArrowRight`/`ArrowDown`/`ArrowLeft`/`ArrowUp`/`Home`/`End`), `FocusSettled` stale-sequence/target guards, strict missing-only `decodeMissingDefaultField` (`null` and wrong types fail decoding), IME `isComposing`/`229`/`Process` guards, `44px` touch targets, `<=1180px` hero containment, `forced-colors: active`, and `0ms` reduced motion.

---

## 3. Concrete Next Integration Path in an Isolated Owned Worktree (Preserving Foreign `f05a3768...`)

Root can qualify, commit on an owned branch, or open a draft PR without touching `/home/charl/code/Warlock/site/src/SiteMain.elm` (`f05a3768...`):

```bash
WT="$(mktemp -d /tmp/warlock-site-owned-2205.XXXXXX)"
OUT="$(mktemp -d /tmp/warlock-site-qa-2205.XXXXXX)"

# 1. Create isolated worktree at immutable HEAD (d6becb72 or 112cde9c2; identical site/ tree)
git -C /home/charl/code/Warlock worktree add -b site/head-mvp-usability-2205 "$WT" HEAD

# 2. Apply frozen minimal patch and assert exact postimage SHA-256 + blob
git -C "$WT" apply --check -v /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadMvpFrozen2205.patch
git -C "$WT" apply /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadMvpFrozen2205.patch
test "$(sha256sum "$WT/site/src/SiteMain.elm" | awk '{print $1}')" = "90f3121ab50c7744be966ec5912a80f014db0fc258ea05e7e5f8f958b27fefda"

# 3. Compile SiteMain.elm and splice ONLY the Elm runtime <script> block into site/index.html
(cd "$WT/site" && elm make src/SiteMain.elm --optimize --output="$OUT/site.html")
python3 -B - "$WT/site/index.html" "$OUT/site.html" <<'PY'
import re, sys
from pathlib import Path
idx_path, built_path = Path(sys.argv[1]), Path(sys.argv[2])
idx, built = idx_path.read_text(encoding="utf-8"), built_path.read_text(encoding="utf-8")
m_new = re.search(r"<script>\s*try\s*\{[\s\S]*?</script>", built)
m_old = re.search(r"<script>\s*try\s*\{[\s\S]*?</script>", idx)
assert m_new and m_old, "missing Elm runtime script block"
idx_path.write_text(idx[:m_old.start()] + m_new.group(0) + idx[m_old.end():], encoding="utf-8")
PY

# 4. Run static site & contract gates + 2205 compiled-DOM/contrast oracle + pure-Elm worker fixture
python3 -B "$WT/site/tools/check-site.py" --root "$WT/site"
python3 -B "$WT/site/tools/check-contracts.py" --root "$WT/site"
python3 -B "$WT/site/assets/shared/authoring/compile.py" --check
node /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-head-mvp-usability-qa-2205.cjs \
  "$WT/site/index.html" "$WT/site/assets/shared/tokens.css" "$OUT/site-qa-2205.json"

mkdir -p "$OUT/fixture/src"
cp "$WT/site/elm.json" "$OUT/fixture/elm.json"
cp "$WT/site/src/SiteMain.elm" "$OUT/fixture/src/SiteMain.elm"
cp /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadFixture2205.elm "$OUT/fixture/src/SiteMainHeadFixture2205.elm"
(cd "$OUT/fixture" && elm make src/SiteMainHeadFixture2205.elm --output="$OUT/fixture.js")
node -e 'const fs=require("fs"),vm=require("vm");const ctx={};ctx.self=ctx;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(process.argv[1],"utf8"),ctx);let out=null;const app=ctx.Elm.SiteMainHeadFixture2205.init();app.ports.outgoing.subscribe(v=>{out=v;});if(!out||!out.passed)throw new Error(JSON.stringify(out));console.log(JSON.stringify(out));' "$OUT/fixture.js"
```

---

## 4. Independent Source & UX Peer Review (`2205` Wave)

### 4.1 Review Receipt: `gemini-gui` `2205` `HttpPopup` Retained-Query Deliverable (`30a0eb4a...`) — **CONCUR**

- **Artifacts Reviewed**:
  - `gemini-gui-http-popup-retained-query-source-2205.patch` (`sha256:fcf8f9c0803ef723cf8284ed4a91126a138cdedc8add8def3750ae746c66d3df`, preimage `implementation/warlock/src/HttpPopup.elm` = `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354` matching `d6becb72` `HEAD`)
  - `gemini-gui-http-popup-retained-query-qa-2205.patch` (`sha256:08748bbe5cb046beecc3de53de97aa7350fcc9b729cb038a3edb271c372bb6dc`, preimage `implementation/warlock/qa/ui-http.cjs` = `66630f5becf42691f132973a6c66959d328e17ddade428bef6a83a95b9e45cdd` matching `d6becb72` `HEAD`)
  - Atomic bundle `30a0eb4a8e1e1c53580fecf10ee5f1f5d59bef29b7939729f2aec9121757b783`
- **Verdict**: **CONCUR (Ready for Root CPU/DOM qualification on `d6becb72`)**.
  1. **Resolves Prior Finding 3 Cleanly**: Because `Popup.elm` (`surface-composition-start` and `surface-preedit`) sets `popup.pendingQuery = Just query`, active IME preedit (`e.g. "/home/charl/漢字"`) enters `(Just draft, _)` -> `"unconfirmed-draft"`, while `(Nothing, Just confirmed)` unconditionally renders `"confirmed"` (`"Last confirmed <noun> (read-only)"`), and `(Nothing, Nothing)` returns `[]`.
  2. **Zero Regression on Non-Query Modes**: Lines 46–48 return the exact bare `div [attribute "role" "alert"] [...]` whenever `retainedField` is `[]` (pre-snapshot, `system`, or missing field row), preserving existing `roots()` / `failures()` DOM shape, `Warlock/Http/Document.hs` `validateCompilerShape`, and zero automatic reconnect/replay.
  3. **Integration Tail-Hunk Note for Root**: `08748bbe...` and `gemini-gui-pending-query-seeded-dom-followup-2137.patch` (`8f0c273b...`) both modify the final IIFE invocation line (`L550`) of `qa/ui-http.cjs` (`66630f5b...`); if Root applies both, merge their two function calls into the single final runner line (`await pendingQueryMalformedAndTransportLossDom(); await httpPopupRetainedQueryOnFailure();`).

### 4.2 Producer-Reachability Confirmation & Forward-Looking IME-Cancel Note on Published `Popup.elm` (`d6becb72` / `9761aa5d...`)

1. **Producer Reachability Confirmed (`01M6CHV7N806QPZQCTKS1Z5Y4K`)**: Verified in `implementation/warlock/src/Desktop.elm:1368` (`SearchQuery stamp text`) that `capture model == Just stamp` strictly rejects any stale `SearchQuery(P1, "f")` once `Desktop` has genuinely advanced to `P2 ""`; therefore `d6becb72`'s `unsettledHere` (`UInt64.compare snapshot.publication shown /= GT`) is sound on all committed/non-cancelled query paths.
2. **Single Remaining Forward-Looking Edge Case (`Popup.elm:108-110` in `9761aa5d...`, `query == held.baseline` on `surface-composition-end`)**:
   - Only relevant if Root opens a follow-up IME-cancel slice under `ELM-UI-005` (does not affect `d6becb72`'s non-cancelled reversal or `query /= held.baseline` preedit-commit checks):
     - **(a) Same-pub reversal + IME cancel**: `[P1 "", query(1,"f"), query(1,""), compStart(1,""), compEnd(1,"")]` enters `query == held.baseline` at line 108, where `(Presentation.current ... |> queryValue) == Just ""` omits `not unsettledHere` and clears `pendingQuery` to `Nothing` while `POST(1,"f")` is still in flight on `P1`.
     - **(b) Cross-pub advance during preedit + IME cancel**: `[P1 "", query(1,"c"), query(1,"b"), compStart(1,"b"), preedit(1,"b漢"), Present(2,"c"), compEnd(1,"b")]` enters `query == held.baseline` and returns `({ ..., pendingQuery = Just "b" }, [])` without dispatching `(2, 7, "b")`, leaving `"b"` un-retried on `P2` until another `Present` arrives.
   - Routing `held.before == Just prior` at `query == held.baseline` through `sendQuery` (preserving `lastQuery` when `unchanged`) closes both in 4 lines when IME-cancel semantics are next scheduled.
