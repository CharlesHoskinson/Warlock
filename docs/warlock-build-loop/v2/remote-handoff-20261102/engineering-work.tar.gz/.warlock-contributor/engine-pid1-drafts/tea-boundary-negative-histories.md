# TEA boundary negative histories — independent fixture inputs (draft)

Source inspection only, 2026-11-01. No compiler, tests, model, native, or VM run. This draft is a proposed addition for the three independently owned QA files, not an acceptance or a replacement for their complete positive/negative histories.

## Complete-state oracle contract

Let `M0` be the **whole** independently pinned `DesktopPolicy.initial` fixture, including the entire opaque `OutputController.Model` and recursively all contained state. The replay's read-only, complete observer must capture all values (including opaque state) with exact JSON and custom-constructor payloads; reject unsupported values rather than omitting them. Its canonical `M0` must be an independently reviewed literal, not reducer output copied into expected output. For each independent case below start from exactly `M0`; expected final complete state is exactly `M0` (all fields, not a projection); expected *entire* ordered `List DesktopPolicy.Effect` is exactly `[]` (there is no Publish and no Delay). Repeat each from a separately pinned complete noninitial pending fixture `MP` where the case is explicitly marked ANY, requiring result exactly `MP` and `[]`; this ensures the pending transaction, binding, batches, timers, and observations are retained. The inputs are literal JSON values, not native-authentication evidence.

Every case is `DesktopPolicy.update (DesktopPolicy.Incoming input) before`. JSON below denotes actual JSON values, not JSON text strings. Case names and expected outputs are written independently from the reducer.

| Case | Input | Given | Literal complete expected result |
|---|---|---|---|
| outer-extra | `{"bridgeProtocol":1,"kind":"view-topology","payload":{},"extra":true}` | ANY | `(before, [])` |
| outer-missing | `{"bridgeProtocol":1,"kind":"view-topology"}` | ANY | `(before, [])` |
| outer-wrong-version | `{"bridgeProtocol":2,"kind":"native-event","payload":{}}` | ANY | `(before, [])` |
| outer-unknown-kind | `{"bridgeProtocol":1,"kind":"not-an-owner-route","payload":{}}` | ANY | `(before, [])` |
| outer-not-object | `[]` | ANY | `(before, [])` |
| topology-extra | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"1","views":[],"extra":true}}` | `M0` | `(M0, [])` |
| topology-stale | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"0","views":[]}}` | `M0` | `(M0, [])` |
| topology-leading-zero | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"01","views":[]}}` | `M0` | `(M0, [])` |
| topology-overflow | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"18446744073709551616","views":[]}}` | `M0` | `(M0, [])` |
| topology-not-string | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":1,"views":[]}}` | `M0` | `(M0, [])` |
| topology-zero-scope | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"1","views":[{"id":"0","generation":"1"}]}}` | `M0` | `(M0, [])` |
| topology-duplicate-id | `{"bridgeProtocol":1,"kind":"view-topology","payload":{"viewProtocol":1,"kind":"view-topology","revision":"1","views":[{"id":"1","generation":"1"},{"id":"1","generation":"2"}]}}` | `M0` | `(M0, [])` |
| foreign-action-scope | `{"bridgeProtocol":1,"kind":"view-action","payload":{"viewProtocol":1,"kind":"view-action","scope":{"id":"1","generation":"1"},"action":{}}}` | `M0` | `(M0, [])` |
| foreign-dismiss-scope | `{"bridgeProtocol":1,"kind":"view-dismiss","payload":{"scope":{"id":"1","generation":"1"},"lease":"1"}}` | `M0` | `(M0, [])` |
| malformed-disposition | `{"bridgeProtocol":1,"kind":"view-disposition","payload":{"viewProtocol":1,"kind":"batch-disposition","extra":true}}` | ANY | `(before, [])` |

`ANY` means either exact complete fixture `M0` or `MP`; it does not mean arbitrary fabricated invalid state. Check each individual result, then an ordered mixed history of these same no-ops starting at `MP`: after **each** transition the complete state remains `MP` and its complete ordered effects remain `[]`. Include a genuine valid positive topology and full-width values `"9007199254741001"` and `"18446744073709551615"` in separate positive/overflow histories; do not imply that this table itself exercises acceptance of those values.

## Pending exact disposition and receipt contrasts

A separately pinned pending fixture `MP` should record its **literal** current binding `B`, view scope `S`, revision `R`, publication `P`, lease `L`, and *exact serialized batch string* `W`. A valid-shaped `view-disposition` certificate uses exactly fields `viewProtocol`, `kind`, `disposition`, `scope`, `revision`, `publication`, `lease`, `binding`, `batch` with `viewProtocol=1`, `kind="batch-disposition"`, `disposition="preflight-unsent"`, and `S/R/P/L/B/W` as above. Produce separately named cases that replace **one** of `S`, `R`, `P`, `L`, `B`, or `W` with a separately specified different valid value. Each independently expected *complete* result is `(MP, [])`: no batch retirement, local proof of omission, command refusal, new request, or timer. The receipt wire must be a literal from the independently reviewed given fixture, not copied from the reducer's actual output. Include the matching preflight refusal as a separate positive with its independently enumerated complete resulting model and effects; mismatched cases alone do not cover refusal.

For an actual `native-event` effect receipt the prelude must include a concrete issued `(binding, effectProtocol, intent)` and full pending state. Each separately named **well-formed** foreign binding/request/generation/incarnation/operation/context/protocol receipt must be selected so it is *not equal to any issued tuple*; predict the whole state and all effects only after checking the complete SurfaceController recovery and Desktop routes. Historical issued tuples may remain valid even after a binding changes, so “not the current binding” alone does not prove no-op. A valid matching receipt may settle an older tracked tuple; retain that nuance and test exact commit, refusal, Unknown, disconnect and rebind separately with independently literal whole models/effects.

Crucial distinction: malformed **outer** bridge is dropped with `(before, [])`. For malformed `effect-outcome` within a valid native event, `TaskbarShell.native` specifically intercepts invalid `NativeOutcome.valid` and does not call `Shell.update`; a standalone `Shell.rejectEnvelope` reading therefore does not establish a diagnostic or publication on the actual owning route. Independently check the complete route, including `SurfaceController` recovery and announcement tracking, before asserting full-state no-op. Other malformed native kinds may reach `Shell.rejectEnvelope`, so their behavior cannot be generalized from this particular interception.

## Boundary and provenance

`DesktopPolicy.incomingEvent` validates an exact three-field object but does **not** authenticate who selected `kind`. `Owner.hs` obtains role from the separately bound listener, `admitRequest` checks the request, and its accepted `Actions` path calls `gateway "view-action"`; its native receive route supplies the native event. Synthetic `Incoming {kind:"native-event",...}` models a trusted-owner-delivered domain event, not evidence that a renderer can mint one or that OS peer authentication was tested. Renderer payload and authenticated-owner/native provenance need separate source-linked boundary controls run only by Root. No assertion here proves native execution, actual browser behavior, or an original EARS.

A compiled-fixture observer must identify exact source/artifact hashes and preserve all nested custom constructors, JSON contents, and full ordered `Publish`/`Delay` arguments; exact `Desktop.Msg` and token inside `Delay` are mandatory. It must be read-only, must fail on unobserved/functions/unknown shapes, and must not expose authority constructors or mutate the reducer. Do not use `Debug.toString` when opaque JSON/functions are elided. Graph retrieval reported stale inputs; these findings were checked against source.

## Source hashes

```
018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e  implementation/warlock/src/DesktopPolicy.elm
fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae  implementation/warlock/src/OutputController.elm
ea57b2c448f5f510ceef256bc0670bd464fc997d29d144741ab1ce3fd004d709  implementation/warlock/src/OutcomeAnnouncements.elm
0cc99c46ec41da3433304cb14d8e0b324e71f476c8ca6b4a7fec79d359fab36b  implementation/warlock/src/Binding.elm
0c32ee015c1882d9d754d9dcda5a454e8a1d71f85d3bbd60d9280dd564531baa  implementation/warlock/src/UInt64.elm
a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9  implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs
f84ee49b10aee296e88155cb734be1f07c770ca00a890fb3d1d16d38d3212a3b  implementation/warlock/qa/ReceiptOutputLifecycleReplay.elm
```
