# Persistent app ownership and deadlines: source-bound interface proposal

Preparation only, 2026-11-01. No source implementation, test, model or native
execution. Current production and the 28-second trial stay unchanged; no new
authority or original-scenario acceptance is claimed. The intended result is a
separate reviewed persistent product route, not a new timeout for the current
bounded bootstrap. `EngineResult False False` continues to express unqualified
provider/callback cleanup.

## Current boundary and concrete counterexample

* `process-custody/.../Process/Internal.hsc` (f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f), `deadlineAfter` and
  `deadlineFromAbsoluteNsAt`, only admit a future absolute monotonic D within
  30 seconds. `runSelectedHook` lines 439–446 wraps the **whole session
  conversation** in its remaining D. Expiry closes the session; retained
  custody and final child/cleanup observations are distinct. It is not a
  handshake-only deadline. The selected-session observation is scoped under
  that same D. A callback return at startup does not transfer the authenticated
  session, pidfd, input ticket, guard or cleanup right out of that scope.
* `runtime/src/Warlock/Bootstrap/Aggregate.hs` (fdf9b224707611600919b349e868fd2883dbc637e9d5707750191dbd21a9a824) supplies that D to `runSelectedDetailed` and desktop inter-frame
  waiting inside `withApprovedOwnedPeer`. The scoped guard and peer identity
  depend on the real selected session and registration, not a JSON ready byte.
* `runtime/ui/Main.hs` (50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7), `Ui/Owner.hs` (a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9), `Ui/Native.hs` (a3467864d1f675d7943c6799d5b192f7a36f5494792fb6e2cb9f1671d6053665) and `Ui/EngineBroker.hs` (63cebd1a5ec38b7faa6b713dacec64f62b1e15e5cda8dbc1284dd757e6d29a04) pass the same D into owner stop, HTTP, native endpoint,
  RPC and engine custody. `EngineEntrypoint.hs` (941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080) imports D, monitors it and
  begins drain before expiry. Broker reserves 500ms under D. A later fresh
  `deadlineAfter` inside one of these objects is neither a continuation of its
  existing owner scope nor a valid way to keep the approved child alive.
* `Transport/Channel.hs` (f97fad97579df5e9bd8156b8a0ecc54daffeea9872666220aa6fcf38f47c4868) gives a frame an absolute five-second bound, starts it only
  when a desktop idle wait becomes readable, preserves the exclusive reader,
  and uses min(frame D, session D). This change did not make the session
  unbounded. `Protocol/Wire.hs` (680237349b3d2e5583849e1c3d43fdc8ebf5313d462e7820b9db8ee8d16c74fd) validates the applicable selection deadline as
  exactly accepted monotonic time + 2 seconds. Preserve each original action
  deadline verbatim through admission, prepare, commit/cancel, receipt and
  recovery; other operations keep their own existing contract bounds.
* `native-authority/src/Warlock/Native/Cancellation/Internal.hs`
  (85e1ef5008c223121decf3f34a6ad083b7a26d785a2ab9f074bc7a5928056bc7) `commit`
  accepts a caller-supplied `now`, checks it against D, then formats and
  installs ExecutionUnknown before entering the provider. The sample can be
  stale by the time it is checked, and installation/provider entry can occur
  after D. The source calls for provider final checks without yielding; it
  does not prove an actual mutation-time clock check. Any future no-late-
  admission or no-late-mutation claim therefore needs an independently
  qualified fresh-check linearization and actual provider enforcement. Native
  operations remain unqualified and disabled in the current product route.

## Proposed smallest ownership seam (not implemented)

Introduce a separate internal persistent-session process owner with an opaque,
non-serializable state. It must be implemented at the real process-custody and
peer-registration boundary, not as a wrapper around `runSelectedDetailed`:

```haskell
-- Interface sketch only: constructors and all minting remain internal.
data StartBudget                 -- original absolute startup D; <=30s
data SessionOwner                -- owns process, pidfd/birth, RPC and lifeline
data LiveSession                 -- borrowed capability; no raw PID or fd
data StopBudget                  -- bounded explicit stop operation
data ActionTicket                -- existing authenticated immutable action D
data SessionExit = CleanExit | ExitUncertain
data StopReceipt = StopConfirmed | StopUncertain

withPersistentOwner
  :: StartBudget -> ReviewedSpawn ->
     (LiveSession -> IO a) -> IO (Either StartFailure (a, SessionExit))
requestSessionStop
  :: LiveSession -> StopBudget -> IO StopReceipt
withActionAdmission
  :: LiveSession -> ActionTicket -> (AdmittedAction -> IO a)
  -> IO (Either ActionFailure a)
```

Types above are ownership/API requirements, not an importable Haskell module;
`ReviewedSpawn`, `StartFailure`, `AdmittedAction` and `ActionFailure` are
placeholders for the existing validated authorities and explicit result types.
The nested lifetime of `LiveSession` must be enforced by the real owner; ordinary
Haskell abstract types alone do not provide linearity. The one owner remains
live and exclusively responsible for its child and registrations until stopped,
observed dead or conclusively retired. The stop function is a one-shot operation
owned by that same enclosing owner, not a second public signal API.

1. Under the original immutable startup D, acquire the held executable and
   parent/birth identity, private network/display witness, fd0 peer, engine
   namespace/lifeline, PID1 identity and per-fragment credential guard. Publish
   the live capability only after the real readiness receipts required by a
   future contract; a local RPC write or a window map alone is insufficient.
   The original peer PID/fd0 must never be proxied or fabricated. Startup
   failure or ambiguous transfer leaves the original owner responsible for all
   acquired resources and reports uncertainty if cleanup cannot be observed.
2. A persistent capability must be minted by a new reviewed custody primitive
   that owns its own registration and live selected child **from creation**.
   Existing callback-scoped `Session` cannot escape its `runSelectedDetailed`
   callback; the current bounded child still terminates under its original D.
   If the design instead uses an explicit ownership transfer, the source must
   demonstrate a single atomic transfer of every close/signal/read/admission
   right, peer registration and liveness witness before the old scope ends.
   Neither duplication nor a gap between owners is permitted. No such primitive
   or proof exists in the current route.
3. Once live, wait for input without minting a new session D or heartbeat.
   Race owned reader readiness against owner-stop/death notification without
   consuming bytes, then start the same five-second first-byte/fragment/SCM
   frame bound; one reader and credentials on every fragment remain mandatory.
   Treat partial writes, deadline crossings, decode/admission failure and
   unobserved callbacks as uncertainty or refusal according to the relevant
   original contract, never retry a mutation automatically. The current first
   receive/admission and desktop idle route remain unchanged until an explicitly
   reviewed new runtime contract replaces them.
4. Each physical action obtains its already-authorized absolute action D once,
   from the trusted original admission/selection source. No caller, page,
   engine, queue, reconnect, freshness poll or session renewal can mint or
   extend it. Validate immediately before actual mutation and after any
   potentially blocking boundary; timeout after submission remains Unknown.
   Keep the original correlation, spent/attempt marker and reservation until a
   matching authoritative terminal or explicit reconciliation resolves it.
   The user-facing persistent surface may stay up while an action is Unknown;
   that is not permission to replay or to convert Unknown to Refused/Committed.
5. Explicit close, broker loss, child exit or lifeline closure first stops new
   admission, then independently drains admitted callbacks, retires per-action
   work, closes RPC/owned handles and kills only the owned namespace through
   the existing custody scheme. A bounded trusted stop budget begins at that
   stop event; it does not extend startup or any action D. Keep separate
   receipts for namespace descendants, callback/backing retirement, and owner/
   peer custody. Retain/quarantine callable GLib callbacks/backing when their
   completion is not observed. pidfd exit, gobject unref, socket close or
   HTTP 204 alone cannot establish those receipts. Unsafe synchronous FFI can
   exceed a Haskell timeout, so hard timing remains unproved.

## Required source-bound controls for Root, not worker execution

* A real held child and credential socket prove same original fd0 owner/PID;
  startup refusal, owner death and close races leave exactly one cleanup owner.
  Test before/after admission and transfer interruption, malformed credentials,
  PID reuse, cross-binding and peer exit using owned child fixtures only.
* Preserve an idle live session beyond 30s only on the separately qualified
  persistent route, then perform two distinct operations; each frame remains
  bounded from readiness and each independently admitted action retains its own
  original absolute D. The current 28s run continues to stop at 28s.
* Expire an action before and after submission; check no new admission after
  its D and no synthesized terminal or automatic retry. An already admitted
  callback can act or finish after D; observe its authoritative result if
  available, otherwise retain Unknown through disconnect/rebind until a
  separately verified matching reconciliation. A stronger no-mutation-after-D
  claim requires an independently enforced check at the actual provider
  mutation, not a Haskell timeout or postcheck.
* Stall each RPC/HTTP/credential fragment, callback and teardown stage; check
  exact frame deadline, cancellation, callback quarantine and independent
  cleanup receipts; retain failed/uncertain evidence. Use deterministic seeds,
  actual production routes and no tests that equate local writes to delivery.

Source and formal review, compiled controls and separately authorized native
trials must be bound to the exact new tuple before use. This document does not
change deadlines, original 242/417 obligations, prior failures, HOSTSTOP2,
current gate behavior or nativeOperations=[].
