{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY, UNEXECUTED. One guardian-owned process per case. Root must use
-- the real same-owner Engine lexical scope and a validated real image/root;
-- the optional API still cannot authenticate arbitrary supplied custodians.
module QHttpExecutableIssue025 (Mode(..),Case,newCase,runAcquire,finishCase,releaseBarrier) where
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try)
import Control.Monad (unless,void)
import qualified Data.ByteString as B
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..),requestSessionStop,tryPersistentStopDeadline)
import Warlock.Platform.Descriptor (ReadCustody,newReadCustody)
import Warlock.Platform.Executable.Internal
 (ExecutableLease,HeldExecutable,LeaseRole(..),LeaseState(..),newExecutableLease,
  executableLeaseState,acquireExecutableLeaseRetained,issueRetainedExecutable)
import Warlock.Platform.Resolver.Internal
 (Root,Pin,Link,Resolution,ResolveError,RootAdmission,RootAdmissionFailure(..),
  LeaseCustody,ProbeCustody,newLeaseCustody,newProbeCustody)

data Mode = Positive | StopBeforeIssue deriving (Eq,Show)
type Acquire = Either RootAdmissionFailure (Either ResolveError ())
type Issued = Either RootAdmissionFailure (Maybe (HeldExecutable,Resolution,LeaseRole))
type Result = Either SomeException (Acquire,Maybe Issued)
data Case = Case PersistentOwner StopBudget LeaseCustody ProbeCustody ReadCustody ExecutableLease
 (IORef (Maybe HeldExecutable)) (IORef Int) (IORef Bool) (MVar ()) (MVar ()) (MVar Result)
newCase :: PersistentOwner -> StopBudget -> IO Case
newCase owner budget = Case owner budget <$> newLeaseCustody <*> newProbeCustody <*> newReadCustody
 <*> newExecutableLease <*> newIORef Nothing <*> newIORef 0 <*> newIORef False
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ _ _ _ _ _ release _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("executable-issue: " ++ label)))
within :: [AdmissionDeadline] -> String -> IO a -> IO a
within ds label action = do
 left <- minimum <$> mapM remainingMicros ds
 if left<=0 then ioError (userError (label ++ ": retain owner and guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure result

-- Called ON the actual owner scope thread, with its authentic rank-2 admitted
-- step and actual rooted image identity, size, digest, pins and links. The
-- caller owns and pre-roots this Case plus its scope worker before entry.
-- A fake adapter or synthetic root is not an acceptable test host.
runAcquire :: Case -> AdmissionDeadline -> RootAdmission -> Root -> [Pin] -> B.ByteString -> [Link] -> Integer -> B.ByteString -> IO ()
runAcquire (Case _ _ leaseOwner probeOwner readOwner executable held issued used acquired release done)
 originalD admit root pins path links size digest = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case" fresh
 result <- try $ restore $ within [originalD] "actual retained executable path" $ do
  acquisition <- acquireExecutableLeaseRetained admit leaseOwner probeOwner readOwner executable root pins path links size digest UiImage
  case acquisition of
   Right (Right ()) -> do
    actual <- executableLeaseState executable
    check "actual resolved image reached confirming" (actual==UncertainLease)
    putMVar acquired ()
    readMVar release
    atomicModifyIORef' issued (\n -> (n+1,()))
    receipt <- issueRetainedExecutable admit executable
    case receipt of
     Right (Just (h,_,_)) -> writeIORef held (Just h)
     _ -> pure ()
    pure (acquisition,Just receipt)
   _ -> pure (acquisition,Nothing)
 putMVar done result

-- Stop is delivered while acquisition has returned and before the distinct
-- issue call. A before-entry refusal is exact; no replay or issued executable
-- is inferred. Positive independently requires the actual returned owner-held
-- executable, not merely a tag or captured model result.
finishCase :: Case -> AdmissionDeadline -> Mode -> IO ()
finishCase c@(Case owner budget _ _ _ executable held issued _ acquired _ done) originalD mode = do
 within [originalD] "actual acquired confirming image" (readMVar acquired)
 selected <- case mode of
  Positive -> pure Nothing
  StopBeforeIssue -> do
   stop <- within [originalD] "same-owner real first stop" (requestSessionStop owner budget)
   first <- tryPersistentStopDeadline owner
   check "stop latched before issue" (stop==StopLatchedBeforeLive)
   case first of
    StopDeadlineLatched d -> pure (Just d)
    _ -> ioError (userError "first StopD unavailable")
 releaseBarrier c
 result <- within (originalD : maybe [] pure selected) "actual issue outcome" (readMVar done)
 state <- executableLeaseState executable
 stored <- readIORef held
 calls <- readIORef issued
 later <- tryPersistentStopDeadline owner
 let retained = case stored of Just _ -> True; Nothing -> False
 case mode of
  Positive -> check "actual issue and retained held executable" $
   calls==1 && retained && state==MovedLease &&
   case result of Right (Right (Right ()),Just (Right (Just (_,_,UiImage)))) -> True; _ -> False
  StopBeforeIssue -> check "pre-entry refusal, no issue and no deadline renewal" $
   calls==1 && not retained && state==UncertainLease &&
   later==maybe StopDeadlineNotLatched StopDeadlineLatched selected &&
   case result of Right (Right (Right ()),Just (Left RootAdmissionRefused)) -> True; _ -> False
-- A held/moved fd is deliberately retained; only Root's separately reviewed
-- real custody/retirement path can dispose of it. No numeric fd guessing.
