#!/usr/bin/env node
/**
 * Decisive Visual & Reachable-Usability Fixture Proposal (0154)
 *
 * Scope: Root-only isolated qualification proposal (worker executes ZERO Node,
 * Elm, Playwright, or VM processes).
 *
 * Upgrade over 0138: Aligns Part B wire framing 100% with UiHttp.elm,
 * SurfaceSnapshot.elm, Settings.elm, HttpBar.elm, and HttpPopup.elm:
 *   - GET /events returns HTTP 200 `{ bridgeProtocol: 1, kind: 'presentation', payload }`
 *     once per publication on separate ephemeral servers for HttpBar and HttpPopup,
 *     and HTTP 204 empty body on subsequent polls until publication advances.
 *   - POST /actions returns HTTP 204 empty body so renderer receipts drain cleanly
 *     without triggering `DeliveryUnconfirmed`.
 *   - Presentation snapshot uses `motion: 'reduced'`, exact `Settings.defaults`
 *     (`{ theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false }`),
 *     and 6-field controls `{ id, domId, label, ariaLabel, detail, enabled }` (never `checked: null`).
 *   - Accepts `--http-bar-js <path> --http-popup-js <path>` directly (auto-hosting
 *     separate local origins in a dual-iframe stage at 1280x800 and 621x750)!
 *   - Adds `--strict-disabled-reason` alongside `--strict-app-only-status` and
 *     `--strict-close-label` to verify converged gemini-gui + terra-browser 0142 postimages.
 *
 * Non-claims: Browser/DOM visual fixture checks never establish native Wayland/Hyprland,
 * physical OS IME, assistive-technology, pointer-scroll, or release acceptance.
 */

'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

function parseRgb(raw) {
  const m = String(raw || '').match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,/\s]+([\d.]+))?\s*\)/i);
  if (!m) return null;
  return { r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: m[4] === undefined ? 1 : Number(m[4]) };
}

function relLum(rgb) {
  const ch = (v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * ch(rgb.r) + 0.7152 * ch(rgb.g) + 0.0722 * ch(rgb.b);
}

function contrastRatio(fg, bg) {
  const l1 = relLum(fg);
  const l2 = relLum(bg);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2'
};

function startStaticServer(rootDir) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const reqUrl = new URL(req.url || '/', 'http://127.0.0.1');
      let rel = decodeURIComponent(reqUrl.pathname).replace(/^\/+/, '');
      if (!rel || rel.endsWith('/')) rel += 'index.html';
      const target = path.resolve(rootDir, rel);
      if (!target.startsWith(path.resolve(rootDir) + path.sep) && target !== path.resolve(rootDir)) {
        res.writeHead(403).end('Forbidden');
        return;
      }
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
        res.writeHead(404).end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream' });
      fs.createReadStream(target).pipe(res);
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port });
    });
  });
}

async function verifyConvergedSiteEntrypoints(browser, siteRoot) {
  const { server, port } = await startStaticServer(siteRoot);
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });

  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load', timeout: 20000 });
    await page.locator('#scope #beta-walkthrough').waitFor({ state: 'visible', timeout: 10000 });

    const domAudit = await page.evaluate(() => {
      const root = document.querySelector('.wl-home-root');
      if (!root) return { missingRoot: true };
      const txt = root.innerText || '';
      const walkItems = root.querySelectorAll('#scope #beta-walkthrough ol.wl-home-walkthrough > li').length;
      return {
        missingRoot: false,
        inlineStyles: root.querySelectorAll('style').length,
        styleAttrs: root.querySelectorAll('[style]').length + (root.hasAttribute('style') ? 1 : 0),
        walkItems,
        honest18: txt.includes('18 of 242') && txt.includes('42 of 417') && !txt.includes('Fifteen whole'),
        honestBackend: txt.includes('selectedOperationSucceeded = false') && txt.includes('FileNotFoundError') && txt.includes('nativeOperations = []')
      };
    });
    record(
      'siteMainCssFreeAndHonest18Of242Walkthrough',
      !domAudit.missingRoot &&
        domAudit.inlineStyles === 0 &&
        domAudit.styleAttrs === 0 &&
        domAudit.walkItems === 4 &&
        domAudit.honest18 &&
        domAudit.honestBackend,
      JSON.stringify(domAudit)
    );

    const tabTaskbar = page.locator('#wl-tab-taskbar');
    await tabTaskbar.focus();
    await tabTaskbar.evaluate((el) =>
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true, isComposing: true, keyCode: 229 }))
    );
    record('workbenchIgnoresIme229', (await tabTaskbar.getAttribute('aria-selected')) === 'true');
    await page.keyboard.press('ArrowRight');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-tab-launcher' && document.activeElement.getAttribute('aria-selected') === 'true',
      { timeout: 5000 }
    );
    record('workbenchArrowRightMovesFocusAndSelection', true);

    for (const themeLabel of ['Night', 'Dawn', 'High contrast']) {
      await page.setViewportSize({ width: 1440, height: 900 });
      await page.getByRole('button', { name: themeLabel, exact: true }).click();
      for (const [w, h] of [[320, 640], [768, 900], [930, 900], [1440, 900]]) {
        await page.setViewportSize({ width: w, height: h });
        const noOverflow = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
        record(`noHorizontalOverflow_${themeLabel.replace(/\s+/g, '')}_${w}x${h}`, noOverflow);
      }
      if (themeLabel === 'High contrast') {
        const hcContrast = await page.evaluate(() => {
          const hero = document.querySelector('.wl-hero');
          const secBtn = document.querySelector('.wl-hero-actions .wl-doc-button:not(.wl-doc-button-primary)');
          return {
            heroBg: hero ? getComputedStyle(hero).backgroundColor : '',
            btnBorder: secBtn ? getComputedStyle(secBtn).borderTopColor : '',
            btnFg: secBtn ? getComputedStyle(secBtn).color : '',
            btnBg: secBtn ? getComputedStyle(secBtn).backgroundColor : ''
          };
        });
        const heroBg = parseRgb(hcContrast.heroBg);
        const btnBorder = parseRgb(hcContrast.btnBorder);
        const btnFg = parseRgb(hcContrast.btnFg);
        const btnBg = parseRgb(hcContrast.btnBg);
        const borderRatio = heroBg && btnBorder ? contrastRatio(btnBorder, heroBg) : 0;
        const textRatio = btnFg && btnBg ? contrastRatio(btnFg, btnBg) : 0;
        record('highContrastHeroButtonBorderAndTextContrast', borderRatio >= 3.0 && textRatio >= 7.0, JSON.stringify({ borderRatio, textRatio }));
      }
    }

    await page.setViewportSize({ width: 320, height: 640 });
    const homeToggle = page.locator('#wl-home-nav-toggle');
    await homeToggle.click();
    await page.locator('#wl-home-nav-drawer a').first().focus();
    await page.keyboard.press('Escape');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-home-nav-toggle' && document.querySelector('.wl-home-root')?.getAttribute('data-nav-open') === 'false',
      { timeout: 5000 }
    );
    record('homeMobileEscapeReturnsFocusToToggle', true);

    await page.setViewportSize({ width: 1440, height: 900 });
    await page.evaluate(() => {
      try { localStorage.removeItem('warlock-doc-theme-v1'); } catch {}
    });
    await page.goto(`http://127.0.0.1:${port}/get-started/index.html`, { waitUntil: 'load', timeout: 15000 });
    const docThemeBtn = page.locator('[data-theme-toggle]');
    await docThemeBtn.click();
    const t1 = await page.evaluate(() => document.documentElement.dataset.theme);
    await docThemeBtn.click();
    const t2 = await page.evaluate(() => document.documentElement.dataset.theme);
    await docThemeBtn.click();
    const t3 = await page.evaluate(() => document.documentElement.dataset.theme);
    record('docThemeToggleCyclesDawnHighContrastNight', t1 === 'dawn' && t2 === 'high-contrast' && t3 === 'night', `${t1}->${t2}->${t3}`);

    await page.setViewportSize({ width: 320, height: 640 });
    const docNavBtn = page.locator('[data-nav-toggle]');
    await docNavBtn.click();
    await page.locator('#site-nav a').first().focus();
    await page.keyboard.press('Escape');
    const docEscOk = await page.evaluate(
      () => document.activeElement?.hasAttribute('data-nav-toggle') && document.getElementById('site-nav')?.hidden === true
    );
    record('docMobileEscapeReturnsFocusToNavToggle', docEscOk);

    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(`http://127.0.0.1:${port}/search/index.html`, { waitUntil: 'load', timeout: 15000 });
    const searchInput = page.locator('input[data-search]');
    await searchInput.evaluate((el) => {
      el.value = 'beta omarchy';
      el.dispatchEvent(new InputEvent('input', { bubbles: true, isComposing: true }));
    });
    const duringCompose = await page.locator('[data-search-results] a').count();
    await searchInput.evaluate((el) => el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true })));
    await page.waitForFunction(() => document.querySelectorAll('[data-search-results] a').length >= 2, { timeout: 5000 });
    const afterCompose = await page.locator('[data-search-results] a').count();
    record('searchGuardsImeComposingAndMatchesMultiWordQuery', duringCompose === 0 && afterCompose >= 2, JSON.stringify({ duringCompose, afterCompose }));

    await context.close();
  } finally {
    await new Promise((r) => server.close(r));
  }
  return checks;
}

function controlRow(id, domId, label, ariaLabel, detail, enabled) {
  return { id, domId, label, ariaLabel, detail, enabled };
}

function buildAppOnlySnapshot({ publication, query, positive, statusText, closeLabel }) {
  const barControls = [
    controlRow('bar:applications', 'bar-applications', 'Applications', 'Open Applications', '', true),
    controlRow('bar:overview', 'bar-overview', 'Task View', 'Open Task View', '', false),
    controlRow('bar:switcher', 'bar-switcher', 'Switch windows', 'Switch windows', '', false),
    controlRow('bar:notifications', 'bar-notifications', 'Notifications', 'Open Notifications', '', false),
    controlRow('bar:files', 'bar-files', 'Files', 'Open Files', '', false),
    controlRow('bar:system', 'bar-system', 'System', 'Open System menu', '', false),
    controlRow('bar:settings', 'bar-settings', 'Settings', 'Open Settings', '', false)
  ];

  const popupControls = [
    controlRow('control:search', 'launcher-search', query, 'Search applications', '', true),
    controlRow('control:close', 'control-close', closeLabel, 'Close applications and return to windows', '', true),
    controlRow('control:refresh', 'control-refresh', 'Refresh', 'Refresh applications', '', true)
  ];

  if (positive) {
    popupControls.push(
      controlRow('jump:open:foot.desktop', 'jump-open-foot', 'Actions for Foot', 'Actions for Foot', 'Application actions unavailable in this session', false),
      controlRow('pin:foot.desktop', 'pin-foot', 'Pin Foot', 'Pin Foot', 'Add to taskbar', true),
      controlRow('entry:foot.desktop', 'entry-foot', 'Open Foot', 'Open Foot', 'Opening unavailable in this session', false),
      controlRow('entry:foot-server.desktop', 'entry-foot-server', 'Open Foot Server', 'Open Foot Server', 'Opening unavailable in this session', false),
      controlRow('entry:footclient.desktop', 'entry-footclient', 'Open Foot Client', 'Open Foot Client', 'Opening unavailable in this session', false)
    );
  }

  return {
    surfaceProtocol: 2,
    publication: String(publication),
    lease: '1',
    mode: 'applications',
    status: statusText,
    motion: 'reduced',
    appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
    bar: barControls,
    popup: popupControls
  };
}

function startUiHttpSurfaceServer(compiledJsPath, elmModuleName, getSnapshot) {
  const jsSource = fs.readFileSync(compiledJsPath, 'utf8');
  const htmlShell = `<!doctype html><html lang="en"><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;overflow:hidden}</style></head><body><div id="app"></div><script src="/app.js"></script><script>Elm.${elmModuleName}.init({node:document.getElementById('app')});</script></body></html>`;
  let deliveredPublication = null;

  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const u = new URL(req.url || '/', 'http://127.0.0.1');
      if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
        deliveredPublication = null;
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(htmlShell);
        return;
      }
      if (req.method === 'GET' && u.pathname === '/app.js') {
        res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8' });
        res.end(jsSource);
        return;
      }
      if (req.method === 'GET' && u.pathname === '/events') {
        if (req.headers['x-warlock-api'] !== '1') {
          res.writeHead(400).end('Missing X-Warlock-Api');
          return;
        }
        const snap = getSnapshot();
        if (!snap || deliveredPublication === snap.publication) {
          res.writeHead(204).end();
          return;
        }
        deliveredPublication = snap.publication;
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ bridgeProtocol: 1, kind: 'presentation', payload: snap }));
        return;
      }
      if (req.method === 'POST' && u.pathname === '/actions') {
        req.resume();
        req.on('end', () => {
          if (req.headers['x-warlock-api'] !== '1') {
            res.writeHead(400).end('Missing X-Warlock-Api');
            return;
          }
          res.writeHead(204).end();
        });
        return;
      }
      res.writeHead(404).end('Not found');
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port, resetDelivery: () => { deliveredPublication = null; } });
    });
  });
}

function startDualStageServer(barPort, popupPort) {
  const stageHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;width:100%;height:100%;background:#100E0E;display:flex;flex-direction:column}#popup{width:min(100%,560px);flex:1 1 auto;border:0}#bar{width:100%;height:56px;flex:0 0 56px;border:0}</style></head><body><iframe id="popup" title="Applications" src="http://127.0.0.1:${popupPort}/"></iframe><iframe id="bar" title="Taskbar" src="http://127.0.0.1:${barPort}/"></iframe></body></html>`;
  return new Promise((resolve, reject) => {
    const server = http.createServer((_req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(stageHtml);
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port }));
  });
}

async function verifyMvpAppOnlyVisualContract(browser, httpBarJs, httpPopupJs, strictStatusOracle, strictCloseLabel, strictDisabledReason) {
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });
  if (!httpBarJs || !httpPopupJs || !fs.existsSync(httpBarJs) || !fs.existsSync(httpPopupJs)) {
    record('mvpCompiledBundlesProvided', false, 'Pass --http-bar-js <HTTP_BAR.js> --http-popup-js <HTTP_POPUP.js> under Root custody');
    return checks;
  }

  const positiveSnap = buildAppOnlySnapshot({
    publication: 2,
    query: 'foot',
    positive: true,
    statusText: strictStatusOracle ? 'Matching applications are shown, but opening is unavailable in this session.' : 'Choose a matching application.',
    closeLabel: strictCloseLabel ? 'Close applications' : 'Windows'
  });
  const negativeSnap = buildAppOnlySnapshot({
    publication: 3,
    query: 'footz',
    positive: false,
    statusText: 'No matching applications. Change your search or Refresh.',
    closeLabel: strictCloseLabel ? 'Close applications' : 'Windows'
  });

  let activeSnapshot = positiveSnap;
  const barSrv = await startUiHttpSurfaceServer(httpBarJs, 'HttpBar', () => activeSnapshot);
  const popSrv = await startUiHttpSurfaceServer(httpPopupJs, 'HttpPopup', () => activeSnapshot);
  const stageSrv = await startDualStageServer(barSrv.port, popSrv.port);

  try {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${stageSrv.port}/`, { waitUntil: 'load', timeout: 15000 });
    const barFrame = page.frameLocator('#bar');
    const popFrame = page.frameLocator('#popup');
    await barFrame.locator('[data-surface-control="bar:applications"]').waitFor({ state: 'visible', timeout: 10000 });
    await popFrame.locator('[data-surface-control="control:close"]').waitFor({ state: 'visible', timeout: 10000 });

    const barAudit1280 = await barFrame.locator('.surface-bar').evaluate((barRoot) => {
      const checkBtn = (id) => {
        const el = barRoot.querySelector(`[data-surface-control="${id}"]`);
        if (!el) return { id, missing: true };
        return {
          id,
          disabled: el.disabled,
          ariaDisabled: el.getAttribute('aria-disabled'),
          disabledReason: el.getAttribute('data-disabled-reason') || '',
          describedBy: el.getAttribute('aria-describedby') || '',
          borderStyle: getComputedStyle(el).borderTopStyle
        };
      };
      const actions = barRoot.querySelector('.surface-actions');
      return {
        applications: checkBtn('bar:applications'),
        disabledBar: ['bar:overview', 'bar:switcher', 'bar:notifications', 'bar:files', 'bar:system', 'bar:settings'].map(checkBtn),
        barFitsAt1280: actions ? actions.scrollWidth <= actions.clientWidth : false,
        alertCount: document.querySelectorAll('[role="alert"]').length
      };
    });

    const popAudit1280 = await popFrame.locator('.surface-popup').evaluate((popRoot) => {
      const checkBtn = (id) => {
        const el = popRoot.querySelector(`[data-surface-control="${id}"]`);
        if (!el) return { id, missing: true };
        return {
          id,
          text: el.textContent?.trim() || '',
          ariaLabel: el.getAttribute('aria-label') || '',
          disabled: el.disabled,
          ariaDisabled: el.getAttribute('aria-disabled'),
          describedBy: el.getAttribute('aria-describedby') || '',
          borderStyle: getComputedStyle(el).borderTopStyle
        };
      };
      return {
        enabledPopup: ['control:close', 'control:refresh', 'pin:foot.desktop'].map(checkBtn),
        disabledPopup: ['jump:open:foot.desktop', 'entry:foot.desktop', 'entry:foot-server.desktop', 'entry:footclient.desktop'].map(checkBtn),
        popupStatus: popRoot.querySelector('[role="status"]')?.textContent?.trim() || '',
        closeBtn: checkBtn('control:close'),
        alertCount: document.querySelectorAll('[role="alert"]').length
      };
    });

    record('uiHttpZeroTransportAlerts', barAudit1280.alertCount === 0 && popAudit1280.alertCount === 0);
    record(
      'positiveFootExactEnabledControlsSolid',
      [barAudit1280.applications, ...popAudit1280.enabledPopup].every(
        (c) => !c.missing && c.disabled === false && c.ariaDisabled === 'false' && c.borderStyle === 'solid'
      )
    );
    record(
      'positiveFootExactTenUnavailableControlsDashed',
      [...barAudit1280.disabledBar, ...popAudit1280.disabledPopup].every(
        (c) => !c.missing && c.disabled === true && c.ariaDisabled === 'true' && c.borderStyle === 'dashed'
      )
    );
    record('fullscreen1280FitsAllSevenBarControls', barAudit1280.barFitsAt1280);

    if (strictStatusOracle) {
      const allEntriesDisabled = popAudit1280.disabledPopup.filter((c) => c.id.startsWith('entry:')).every((c) => c.disabled);
      record(
        'appOnlyPositiveMatchStatusDoesNotInstructDisabledLaunch',
        !(allEntriesDisabled && popAudit1280.popupStatus === 'Choose a matching application.'),
        `popupStatus=${JSON.stringify(popAudit1280.popupStatus)}`
      );
    }
    if (strictCloseLabel) {
      record(
        'closeApplicationsVisibleLabelHonestAndAriaPreserved',
        popAudit1280.closeBtn.text.includes('Close applications') &&
          popAudit1280.closeBtn.ariaLabel === 'Close applications and return to windows',
        JSON.stringify(popAudit1280.closeBtn)
      );
    }
    if (strictDisabledReason) {
      record(
        'disabledBarAndEntryExposeTruthfulDescribedByReason',
        barAudit1280.disabledBar.every((c) => c.disabledReason.length > 0 && c.describedBy.length > 0) &&
          popAudit1280.disabledPopup.every((c) => c.describedBy.length > 0),
        JSON.stringify({ bar: barAudit1280.disabledBar[0], entry: popAudit1280.disabledPopup[1] })
      );
    }

    await page.setViewportSize({ width: 621, height: 750 });
    const audit621 = await barFrame.locator('.surface-bar').evaluate((barRoot) => {
      const actions = barRoot.querySelector('.surface-actions');
      const barStatus = barRoot.querySelector('[role="status"]');
      const statusRect = barStatus ? barStatus.getBoundingClientRect() : null;
      return {
        overflowX: actions ? getComputedStyle(actions).overflowX : '',
        scrollsAt621: actions ? actions.scrollWidth > actions.clientWidth : false,
        statusWidth: statusRect ? statusRect.width : 0
      };
    });
    record(
      'tiled621PreservesStatusBoxAndUsesOverflowAutoOnToolbar',
      audit621.overflowX === 'auto' && audit621.scrollsAt621 && audit621.statusWidth >= 180,
      JSON.stringify(audit621)
    );

    activeSnapshot = negativeSnap;
    await popFrame.locator('[data-publication="3"]').waitFor({ state: 'visible', timeout: 10000 });
    const negAudit = await popFrame.locator('.surface-popup').evaluate((popRoot) => ({
      query: popRoot.querySelector('[data-surface-field="control:search"]')?.value,
      entryCount: popRoot.querySelectorAll('[data-surface-control^="entry:"]').length,
      status: popRoot.querySelector('[role="status"]')?.textContent?.trim()
    }));
    record(
      'negativeFootzRetainsQueryAndClearsEntries',
      negAudit.query === 'footz' && negAudit.entryCount === 0 && negAudit.status === 'No matching applications. Change your search or Refresh.',
      JSON.stringify(negAudit)
    );

    await context.close();
  } finally {
    await new Promise((r) => stageSrv.server.close(r));
    await new Promise((r) => popSrv.server.close(r));
    await new Promise((r) => barSrv.server.close(r));
  }
  return checks;
}

async function main() {
  const args = process.argv.slice(2);
  const getArg = (flag) => {
    const idx = args.indexOf(flag);
    return idx >= 0 && idx + 1 < args.length ? args[idx + 1] : '';
  };
  const siteRoot = getArg('--site-root');
  const httpBarJs = getArg('--http-bar-js');
  const httpPopupJs = getArg('--http-popup-js');
  const strictStatus = args.includes('--strict-app-only-status');
  const strictClose = args.includes('--strict-close-label');
  const strictReason = args.includes('--strict-disabled-reason');

  const { chromium } = require('playwright');
  const browser = await chromium.launch({ headless: true });
  try {
    const report = {
      schema: 1,
      fixture: 'site-decisive-visual-fixture-0154',
      siteChecks: siteRoot ? await verifyConvergedSiteEntrypoints(browser, siteRoot) : [],
      mvpChecks:
        httpBarJs || httpPopupJs
          ? await verifyMvpAppOnlyVisualContract(browser, httpBarJs, httpPopupJs, strictStatus, strictClose, strictReason)
          : []
    };
    const all = [...report.siteChecks, ...report.mvpChecks];
    report.passed = all.length > 0 && all.every((c) => c.ok);
    process.stdout.write(JSON.stringify(report, null, 2) + '\n');
    process.exitCode = report.passed ? 0 : 1;
  } finally {
    await browser.close();
  }
}

if (require.main === module) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
