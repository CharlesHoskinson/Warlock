{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; UNEXECUTED. Run exactly one Case per independently guarded host.
-- Config, display, StartD, same-owner StopBudget and real '/' identity are
-- real. The host roots Case/worker/fds and its guardian on every outcome.
module QHttpResolverEachStep (Mode(..),Case,newCase,releaseBarrier,runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,newIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
 loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
 persistentBackendCounts,persistentBackendStartupRefusal,qaResolverHooks,qaResolverSteps,qaResolverSlots,qaResolverStopD)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Platform.Resolver.Internal (QaRootSlot(..))

-- Source mapping in Resolver011/013: 1 root open, 2 root identity, 3 proc
-- open, 4 proc stat, 5 proc fstatfs. WholeValid positively reaches the actual
-- lexical callback after all five have returned, then stops before seal.
data Mode = BeforeStep Int | DuringStep Int | WholeValid deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ release _ _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError ("resolver-each-step: " ++ name)))
-- This is only the QA observation watchdog; it cannot mint/extend StartD or StopD.
within :: String -> IO a -> IO a
within label act = timeout 5000000 act >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
expectedSlots :: Int -> (QaRootSlot,QaRootSlot)
expectedSlots n | n==1 = (QaSlotUnused,QaSlotUnused)
                | n<=3 = (QaSlotOpen,QaSlotUnused)
                | otherwise = (QaSlotOpen,QaSlotOpen)
runCase :: Case -> Mode -> FilePath -> IO ()
runCase c@(Case owner start entered release completed worker used) mode path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single use" fresh
 let selected = case mode of BeforeStep n -> n; DuringStep n -> n; WholeValid -> 6
 check "finite actual step index" (selected>=1 && selected<=6 && (mode==WholeValid || selected<=5))
 exists <- doesPathExist path
 check "real owned config" (isAbsolute path && exists)
 initial <- qaResolverSteps
 check "isolated probes unused" (initial==(0,0,[]))
 configured <- restore (within "config" (loadPersistentBackendConfig owner path))
 check "same owner config" (configured==Right ())
 let barrier = putMVar entered () >> readMVar release
     before n = case mode of BeforeStep wanted | n==wanted -> barrier; _ -> pure ()
     inside n = case mode of DuringStep wanted | n==wanted -> barrier; _ -> pure ()
     beforeSeal = case mode of WholeValid -> barrier; _ -> pure ()
 qaResolverHooks before inside beforeSeal
 tid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try (unmask (readMVar start >> runPersistentBackend owner))
  putMVar completed outcome
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within "actual selected boundary" (readMVar entered)
  (attempts,entries,prior) <- qaResolverSteps
  slots <- qaResolverSlots
  let (wantAttempts,wantEntries) = case mode of
       BeforeStep n -> (n,n-1)
       DuringStep n -> (n,n)
       WholeValid -> (5,5)
      previous = case mode of WholeValid -> 5; _ -> selected-1
      expected = case mode of WholeValid -> (QaSlotOpen,QaSlotOpen); _ -> expectedSlots selected
  check "actual prior admissions and root slots" $
   attempts==wantAttempts && entries==wantEntries && prior==replicate previous (Right ()) && slots==Just expected
  stop <- within "same-owner stop" (requestPersistentBackendStop owner)
  firstD <- qaResolverStopD owner
  check "first StopD selected before release" $
   stop==P.StopLatchedBeforeLive && case firstD of P.StopDeadlineLatched _ -> True; _ -> False
  releaseBarrier c
  outcome <- within "actor result" (readMVar completed) >>= either throwIO pure
  (endAttempts,endEntries,receipts) <- qaResolverSteps
  laterD <- qaResolverStopD owner
  let expectedReceipts = case mode of
       BeforeStep _ -> replicate previous (Right ()) ++ [Left (P.StartupAdmissionRefused SessionClosed)]
       DuringStep _ -> replicate previous (Right ()) ++ [Left P.StartupAdmissionUnknown]
       WholeValid -> replicate 5 (Right ())
  check "no subsequent Resolver action; per-step result and original StopD" $
   endAttempts==wantAttempts && endEntries==wantEntries && receipts==expectedReceipts && firstD==laterD &&
   persistentBackendStartupRefusal outcome==Just P.StartupAdmissionUnknown && persistentBackendCounts outcome==(0,0)
