'use strict';

/*
 * Independent ELM-TEA-004 (tea-subscriptions) literal oracle for the 9th
 * Browser.element root: site/src/SiteMain.elm + site/src/SiteBetaStatus.elm.
 * Every GIVEN, intermediate state delta, typed SiteEffect list, and empty
 * SiteSubscription plan (`[]` -> `Sub.none`) is authored directly from the Elm
 * source definitions, never captured from runtime output.
 */

const empty = () => ({ $: '[]' });
const list = items => {
  let out = empty();
  for (let i = items.length - 1; i >= 0; i--) {
    out = { $: '::', a: items[i], b: out };
  }
  return out;
};
const none = () => ({ $: 'Nothing' });
const just = value => ({ $: 'Just', a: value });
const tag = name => ({ $: name });

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function equalLiteral(left, right) {
  if (Object.is(left, right)) return true;
  if (typeof left !== typeof right || left === null || right === null ||
      typeof left !== 'object' || Array.isArray(left) !== Array.isArray(right)) return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every((key, i) =>
    key === rightKeys[i] && equalLiteral(left[key], right[key]));
}

function cloneLiteral(value) {
  if (value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(cloneLiteral);
  const copy = {};
  for (const key of Object.keys(value).sort()) copy[key] = cloneLiteral(value[key]);
  return copy;
}

function literalPatches(given, patches) {
  const result = cloneLiteral(given);
  for (const change of patches) {
    let cursor = result;
    for (let i = 0; i < change.path.length - 1; i++) cursor = cursor[change.path[i]];
    const leaf = change.path[change.path.length - 1];
    if (!equalLiteral(cursor[leaf], change.before)) {
      throw new Error('unexpected literal before at ' + change.path.join('.'));
    }
    if (equalLiteral(change.before, change.after)) {
      throw new Error('noop literal change at ' + change.path.join('.'));
    }
    cursor[leaf] = cloneLiteral(change.after);
  }
  return result;
}

const betaState = (filter, mvpTrack, focusSeq, lastFocusMiss) => ({
  $: 'State',
  a: {
    filter: tag(filter),
    focusSeq,
    lastFocusMiss,
    mvpTrack: tag(mvpTrack),
  },
});

const initialSiteState = () => ({
  model: {
    betaStatus: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
    category: tag('CategoryAll'),
    cues: {
      activeApplication: true,
      switcherCandidate: false,
      windowFocused: true,
    },
    lastTabFocusMiss: none(),
    mobileNavOpen: false,
    motion: tag('MotionStandard'),
    outcomeSample: tag('SampleObserved'),
    spotlight: tag('SurfaceTaskbar'),
    tabFocusSeq: 0,
    theme: tag('ThemeNight'),
  },
  subscriptions: empty(),
});

const siteEffects = items => ({ $: 'SiteStepEffects', a: list(items) });
const focusTabEffect = (seq, surface) => ({ $: 'FocusSpotlightTab', a: seq, b: tag(surface) });
const focusMobileToggleEffect = seq => ({ $: 'FocusMobileNavToggle', a: seq });
const betaFilterEffect = (seq, filter) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusFilterTab', a: seq, b: tag(filter) },
});
const betaMvpEffect = (seq, track) => ({
  $: 'BetaStatusEffect',
  a: { $: 'FocusMvpTab', a: seq, b: tag(track) },
});

function buildSpotlightFocusRaceCase() {
  const s0 = initialSiteState();
  // 1. ArrowRight (KeyboardStepSpotlight +1): SurfaceTaskbar -> SurfaceLauncher, seq 0 -> 1
  const s1 = literalPatches(s0, [
    { path: ['model', 'spotlight'], before: tag('SurfaceTaskbar'), after: tag('SurfaceLauncher') },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
  ]);
  // 2. Pointer SelectSpotlight SurfaceFiles before rAF settles: seq 1 -> 2, queues FocusSpotlightTab 2 SurfaceFiles
  const s2 = literalPatches(s1, [
    { path: ['model', 'spotlight'], before: tag('SurfaceLauncher'), after: tag('SurfaceFiles') },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
  ]);
  // 3. Inverse race: pointer SelectSpotlight SurfaceSettings (seq 2 -> 3) then ArrowLeft (KeyboardStepSpotlight -1 -> SurfaceNotifications, seq 3 -> 4)
  const s3 = literalPatches(s2, [
    { path: ['model', 'spotlight'], before: tag('SurfaceFiles'), after: tag('SurfaceSettings') },
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
  ]);
  const s4 = literalPatches(s3, [
    { path: ['model', 'spotlight'], before: tag('SurfaceSettings'), after: tag('SurfaceNotifications') },
    { path: ['model', 'tabFocusSeq'], before: 3, after: 4 },
  ]);
  // 4. Current-seq Dom.NotFound recorded as bounded internal diagnostic
  const s5 = literalPatches(s4, [
    { path: ['model', 'lastTabFocusMiss'], before: none(), after: just('wl-tab-notifications') },
  ]);
  // 5. External Previous/Next button (StepSpotlight +1 -> SurfaceSettings): increments seq 4 -> 5, clears miss, emits [] (Cmd.none, no focus steal)
  const s6 = literalPatches(s5, [
    { path: ['model', 'spotlight'], before: tag('SurfaceNotifications'), after: tag('SurfaceSettings') },
    { path: ['model', 'tabFocusSeq'], before: 4, after: 5 },
    { path: ['model', 'lastTabFocusMiss'], before: just('wl-tab-notifications'), after: none() },
  ]);

  return {
    name: 'sitemain-arrow-pointer-bidirectional-focus-race-and-step-invalidation',
    worker: 'sitemain',
    given: s0,
    steps: [
      {
        input: { kind: 'keyboard-step', delta: 1 },
        expected: { state: s1, effects: siteEffects([focusTabEffect(1, 'SurfaceLauncher')]) },
      },
      {
        input: { kind: 'select-spotlight', surface: 'files' },
        expected: { state: s2, effects: siteEffects([focusTabEffect(2, 'SurfaceFiles')]) },
      },
      {
        input: { kind: 'tab-focus-settled', seq: 1, surface: 'launcher', missingDomId: 'wl-tab-launcher' },
        expected: { state: s2, effects: siteEffects([]) },
      },
      {
        input: { kind: 'tab-focus-settled', seq: 2, surface: 'files', missingDomId: null },
        expected: { state: s2, effects: siteEffects([]) },
      },
      {
        input: { kind: 'select-spotlight', surface: 'settings' },
        expected: { state: s3, effects: siteEffects([focusTabEffect(3, 'SurfaceSettings')]) },
      },
      {
        input: { kind: 'keyboard-step', delta: -1 },
        expected: { state: s4, effects: siteEffects([focusTabEffect(4, 'SurfaceNotifications')]) },
      },
      {
        input: { kind: 'tab-focus-settled', seq: 4, surface: 'notifications', missingDomId: 'wl-tab-notifications' },
        expected: { state: s5, effects: siteEffects([]) },
      },
      {
        input: { kind: 'step-spotlight', delta: 1 },
        expected: { state: s6, effects: siteEffects([]) },
      },
    ],
  };
}

function buildMobileNavAndBetaStatusCase() {
  const s0 = initialSiteState();
  // 1. ToggleMobileNav opens menu, increments seq 0 -> 1 without programmatic focus
  const s1 = literalPatches(s0, [
    { path: ['model', 'mobileNavOpen'], before: false, after: true },
    { path: ['model', 'tabFocusSeq'], before: 0, after: 1 },
  ]);
  // 2. EscapeMobileNav closes menu, increments seq 1 -> 2, emits FocusMobileNavToggle 2
  const s2 = literalPatches(s1, [
    { path: ['model', 'mobileNavOpen'], before: true, after: false },
    { path: ['model', 'tabFocusSeq'], before: 1, after: 2 },
  ]);
  // 3. MobileNavFocusSettled seq 2 Dom.NotFound recorded only in bounded diagnostic lastTabFocusMiss
  const s3 = literalPatches(s2, [
    { path: ['model', 'lastTabFocusMiss'], before: none(), after: just('wl-home-nav-toggle') },
  ]);
  // 4. CloseMobileNav increments seq 2 -> 3 with [] effects; stale seq 2 settlement ignored
  const s4 = literalPatches(s3, [
    { path: ['model', 'tabFocusSeq'], before: 2, after: 3 },
  ]);
  // 5. Child SiteBetaStatus transitions preserve subscriptions == []
  const s5 = literalPatches(s4, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterAll', 'TrackBrowserStage', 0, none()),
      after: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
    },
  ]);
  const s6 = literalPatches(s5, [
    {
      path: ['model', 'betaStatus'],
      before: betaState('FilterOpenNativeGates', 'TrackBrowserStage', 1, none()),
      after: betaState('FilterOpenNativeGates', 'TrackProtectedCpu', 2, none()),
    },
  ]);

  return {
    name: 'sitemain-mobile-nav-bounded-diagnostic-and-child-beta-subscriptions',
    worker: 'sitemain',
    given: s0,
    steps: [
      {
        input: { kind: 'toggle-mobile-nav' },
        expected: { state: s1, effects: siteEffects([]) },
      },
      {
        input: { kind: 'escape-mobile-nav' },
        expected: { state: s2, effects: siteEffects([focusMobileToggleEffect(2)]) },
      },
      {
        input: { kind: 'mobile-nav-focus-settled', seq: 2, missingDomId: 'wl-home-nav-toggle' },
        expected: { state: s3, effects: siteEffects([]) },
      },
      {
        input: { kind: 'close-mobile-nav' },
        expected: { state: s4, effects: siteEffects([]) },
      },
      {
        input: { kind: 'mobile-nav-focus-settled', seq: 2, missingDomId: null },
        expected: { state: s4, effects: siteEffects([]) },
      },
      {
        input: { kind: 'beta-select-filter', filter: 'native-gates' },
        expected: { state: s5, effects: siteEffects([betaFilterEffect(1, 'FilterOpenNativeGates')]) },
      },
      {
        input: { kind: 'beta-keyboard-step-mvp', delta: 1 },
        expected: { state: s6, effects: siteEffects([betaMvpEffect(2, 'TrackProtectedCpu')]) },
      },
    ],
  };
}

const SITE_MAIN_CASES = [
  buildSpotlightFocusRaceCase(),
  buildMobileNavAndBetaStatusCase(),
];

module.exports = {
  SITE_MAIN_CASES,
  initialSiteState,
};
