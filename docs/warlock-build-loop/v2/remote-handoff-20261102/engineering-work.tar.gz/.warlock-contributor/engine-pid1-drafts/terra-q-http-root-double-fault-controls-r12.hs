{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Exact r12 candidate 0a8fbb03; one actual same-owner
-- root pair per guardian-owned host. A physically completed close never
-- becomes authority merely because its internal part marker says Confirmed.
module QHttpRootDoubleFaultR12 (Mode(..),Case,newCase,runCase,runImplicitBeforeFirstStop) where
import Control.Exception (mask)
import Control.Monad (unless)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),StopBudget,StopReceipt(..),StopDeadlineObservation(..),CleanupDeadlineObservation(..),
  newPersistentOwner,newPersistentRootCustody,closePersistentRootPart,persistentStatus,
  requestSessionStop,tryPersistentStopDeadline,tryPersistentCleanupDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaRootCommitHook,qaRootCommitState,qaRootGateBusy,qaRootPhaseSnapshot)
import Warlock.Platform.Resolver (Identity(..),RootCustody,RootPart(..),RootStepResult(..),withRetainedRoot)
import Warlock.Platform.Resolver.Internal (QaRootSlot(..),qaRootSlots)

data Mode = NormalBoth | PhasePublishFault | PhaseAndDemoteFault | GateBeforeInsert | GateAfterInsert deriving (Eq,Show)
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool) (IORef [String])
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False <*> newIORef []
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("root-commit: " ++ label)))
-- Bound observation by already selected absolute deadlines; do not mint a D.
withinBounds :: [AdmissionDeadline] -> String -> IO a -> IO a
withinBounds deadlines label action = do
 left <- minimum <$> mapM remainingMicros deadlines
 if left<=0 then ioError (userError (label ++ ": existing D expired; retain Case and guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": existing D expired; retain Case and guardian"))) pure result
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
runCase :: Case -> Mode -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runCase (Case owner slot used seen) mode startD stopBudget drive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 remainingMicros startD >>= check "real startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 acquired <- restore $ withinBounds [startD] "real root and lifecycle" $ withRetainedRoot root "/" ident $ \_ -> do
  withinBounds [startD] "actual owner lifecycle" (drive owner)
  phase <- withinBounds [startD] "actual owner status" (persistentStatus owner)
  check "real owner retired" (phase == PersistentRetired)
 check "actual root pair acquired" (acquired==Right ())
 stop <- withinBounds [startD] "first same-owner stop" (requestSessionStop owner stopBudget)
 first <- tryPersistentStopDeadline owner
 check "stop selected for unresolved root" $
  stop==StopUncertain CleanupUncertain && case first of StopDeadlineLatched _ -> True; _ -> False
 selectedStopD <- case first of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "no selected first stop D")
 qaRootCommitHook $ \stage -> do
  atomicModifyIORef' seen (\xs -> (stage:xs,()))
  let inject = case mode of
       NormalBoth -> False
       PhasePublishFault -> stage=="phase-publish"
       PhaseAndDemoteFault -> stage=="phase-publish" || stage=="demote"
       GateBeforeInsert -> stage=="gate-before"
       GateAfterInsert -> stage=="gate-after"
  if inject then ioError (userError ("injected " ++ stage)) else pure ()
 rootReceipt <- restore $ withinBounds [startD,selectedStopD] "actual selected root close" (closePersistentRootPart owner RootAnchor)
 marker <- qaRootCommitState owner RootAnchor
 busy <- qaRootGateBusy owner
 slots <- qaRootSlots root
 phase <- qaRootPhaseSnapshot owner
 events <- reverse <$> readIORef seen
 case mode of
  NormalBoth -> do
   check "first actual close committed" $
    rootReceipt==Right RootStepClosed && marker==Just (2,False) && not busy &&
    events==["phase-publish","gate-before","gate-after"] && slots==(QaSlotClosed,QaSlotOpen)
   procReceipt <- restore $ withinBounds [startD,selectedStopD] "actual selected proc close" (closePersistentRootPart owner ProcAnchor)
   procMarker <- qaRootCommitState owner ProcAnchor
   closed <- qaRootSlots root
   check "positive other-part receipt" $
    procReceipt==Right RootStepClosed && procMarker==Just (2,False) && closed==(QaSlotClosed,QaSlotClosed)
  _ | mode==PhasePublishFault || mode==PhaseAndDemoteFault -> do
   let expectedMark = if mode==PhasePublishFault then 1 else 2
   check "armed marker survives publish failure regardless of demotion" $
    rootReceipt==Left CleanupUncertain && marker==Just (expectedMark,True) && not busy &&
    events==["phase-publish","demote"] && slots==(QaSlotClosed,QaSlotOpen) &&
    phase==Nothing
   firstRetry <- restore $ withinBounds [startD,selectedStopD] "failed part cannot retry" (closePersistentRootPart owner RootAnchor)
   otherPart <- restore $ withinBounds [startD,selectedStopD] "other part cannot use stale confirmation" (closePersistentRootPart owner ProcAnchor)
   closed <- qaRootSlots root
   check "sticky uncertainty blocks both physical close entries" $
    firstRetry==Left OwnerBusy && otherPart==Left OwnerBusy && closed==(QaSlotClosed,QaSlotOpen)
  GateBeforeInsert -> do
   check "unpublished final gate blocks both parts" $
    rootReceipt==Left CleanupUncertain && marker==Just (2,False) && busy && phase==Just False &&
    events==["phase-publish","gate-before"] && slots==(QaSlotClosed,QaSlotOpen)
   rootRetry <- restore $ withinBounds [startD,selectedStopD] "busy gate refuses root" (closePersistentRootPart owner RootAnchor)
   procRetry <- restore $ withinBounds [startD,selectedStopD] "busy gate refuses proc" (closePersistentRootPart owner ProcAnchor)
   check "no false close while gate withheld" (rootRetry==Left OwnerBusy && procRetry==Left OwnerBusy)
  GateAfterInsert -> do
   -- Explicit injection after actual putMVar is a fault-model premise. A lost
   -- return must not silently appear fully confirmed to future authority.
   check "post-insert lost receipt stays conservatively fenced" $
    rootReceipt==Left CleanupUncertain && slots==(QaSlotClosed,QaSlotOpen) &&
    events==["phase-publish","gate-before","gate-after"] && (busy || marker==Just (2,True))
  _ -> ioError (userError "unhandled case")
 after <- tryPersistentStopDeadline owner
 check "first StopD preserved or gate unavailable" (if mode==GateBeforeInsert then after==StopDeadlineBusy else after==first)
 case mode of
  NormalBoth -> do
   repeatedStop <- restore $ withinBounds [startD,selectedStopD] "same owner stop observation" (requestSessionStop owner stopBudget)
   check "no false no-live" (repeatedStop==StopAlreadyRequested || case repeatedStop of StopUncertain _ -> True; _ -> False)
  _ -> pure () -- phase is genuinely unavailable: separate rooted stop observer remains Unknown

-- Distinct Sol first-stop witness host: no explicit StopD is minted here. The
-- real lifecycle driver must have selected a still-live implicit containment D
-- by actual owner code and retired without any explicit stop. If no such real
-- path exists, the selected root-close hook is never reached and the case fails.
-- The continuation receives the SAME strongly retained owner after the exact
-- gate-before insertion fault; it must root its own worker and never fill gate.
runImplicitBeforeFirstStop :: Case -> AdmissionDeadline -> (PersistentOwner -> IO ()) -> (PersistentOwner -> IO ()) -> IO ()
runImplicitBeforeFirstStop (Case owner slot used seen) startD drive continuation = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single implicit case" fresh
 remainingMicros startD >>= check "original startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 acquired <- restore $ withinBounds [startD] "actual root and owner lifecycle" $ withRetainedRoot root "/" ident $ \_ -> do
  withinBounds [startD] "real implicit lifecycle" (drive owner)
  phase <- withinBounds [startD] "real retired phase" (persistentStatus owner)
  check "actual owner retired" (phase==PersistentRetired)
 check "actual root pair acquired" (acquired==Right ())
 firstBefore <- tryPersistentStopDeadline owner
 check "no explicit first stop D before injected fault" (firstBefore==StopDeadlineNotLatched)
 selected <- tryPersistentCleanupDeadline owner
 implicitD <- case selected of
  CleanupDeadlineSelected d -> pure d
  _ -> ioError (userError "real lifecycle did not select an implicit cleanup D")
 remainingMicros implicitD >>= check "selected implicit D live" . (>0)
 qaRootCommitHook $ \stage -> do
  atomicModifyIORef' seen (\xs -> (stage:xs,()))
  if stage=="gate-before" then ioError (userError "injected before final gate put") else pure ()
 receipt <- restore $ withinBounds [startD,implicitD] "actual containment-bound root close" (closePersistentRootPart owner RootAnchor)
 events <- reverse <$> readIORef seen
 busy <- qaRootGateBusy owner
 slots <- qaRootSlots root
 phase <- qaRootPhaseSnapshot owner
 check "actual close reached injected final gate boundary" $
  receipt==Left CleanupUncertain && events==["phase-publish","gate-before"] && busy &&
  phase==Just False && slots==(QaSlotClosed,QaSlotOpen)
 stopAfter <- tryPersistentStopDeadline owner
 check "first-stop D remains unobservable on actual unavailable gate" (stopAfter==StopDeadlineBusy)
 restore (withinBounds [startD,implicitD] "same owner first-stop continuation" (continuation owner))
