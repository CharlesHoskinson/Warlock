{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Passive-observation successor of r12; one actual same-owner
-- root pair per guardian-owned host. A physically completed close never
-- becomes authority merely because its internal part marker says Confirmed.
module QHttpRootFaultRetained016 (Mode(..),Case,newCase,runCase,runImplicitBeforeFirstStop,retainedWorkers,retainedResults) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),StopBudget,StopReceipt(..),StopDeadlineObservation(..),CleanupDeadlineObservation(..),
  newPersistentOwner,newPersistentRootCustody,closePersistentRootPart,persistentStatus,
  requestSessionStop,tryPersistentStopDeadline,tryPersistentCleanupDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaRootCommitHook,qaRootCommitState,qaRootGateBusy,qaRootPhaseSnapshot)
import Warlock.Platform.Resolver (Identity(..),RootCustody,RootPart(..),RootStepResult(..),withRetainedRoot)
import Warlock.Platform.Resolver.Internal (QaRootSlot(..),qaRootSlots)

data Mode = NormalBoth | PhasePublishFault | PhaseAndDemoteFault | GateBeforeInsert | GateAfterInsert deriving (Eq,Show)
-- Case and all result cells remain reachable by the host guardian after any
-- timeout.  Waiting never throws an exception into a product-action worker.
type Outcome a = Either SomeException a
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool) (IORef [String])
 (IORef [ThreadId]) (MVar (Outcome ())) (MVar (Outcome StopReceipt))
 (MVar (Outcome (Either ToolError RootStepResult))) (MVar (Outcome (Either ToolError RootStepResult)))
 (MVar (Outcome (Either ToolError RootStepResult))) (MVar (Outcome StopReceipt)) (MVar (Outcome ()))
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False <*> newIORef []
 <*> newIORef [] <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ _ workers _ _ _ _ _ _ _) = readIORef workers
retainedResults :: Case -> IO (Maybe (Outcome ()),Maybe (Outcome StopReceipt),
 Maybe (Outcome (Either ToolError RootStepResult)),Maybe (Outcome (Either ToolError RootStepResult)),
 Maybe (Outcome (Either ToolError RootStepResult)),Maybe (Outcome StopReceipt),Maybe (Outcome ()))
retainedResults (Case _ _ _ _ _ lifecycle stop root part retry repeated continuation) = do
 (,,,,,,) <$> tryReadMVar lifecycle <*> tryReadMVar stop <*> tryReadMVar root <*> tryReadMVar part <*> tryReadMVar retry <*> tryReadMVar repeated <*> tryReadMVar continuation
-- Publish worker identity before allowing any actual operation to enter.
startWorker :: IORef [ThreadId] -> MVar (Outcome a) -> [AdmissionDeadline] -> IO a -> IO ()
startWorker workers done bounds action = mask $ \_ -> do
 start <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try $ unmask $ do
   readMVar start
   left <- minimum <$> mapM remainingMicros bounds
   check "same D live before action entry" (left>0)
   action
  putMVar done outcome
  case outcome of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of
    Just _ -> throwIO ex
    Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()
awaitResult :: [AdmissionDeadline] -> String -> MVar (Outcome a) -> IO a
awaitResult ds label done = do
 left <- minimum <$> mapM remainingMicros ds
 if left<=0 then ioError (userError (label ++ ": Unknown; retain Case/guardian")) else do
  observed <- timeout left (readMVar done)
  case observed of
   Nothing -> ioError (userError (label ++ ": Unknown; retain Case/guardian"))
   Just outcome -> do
    leftAfter <- minimum <$> mapM remainingMicros ds
    check (label ++ ": receipt before existing D") (leftAfter>0)
    either throwIO pure outcome
-- Stop may latch a stricter firstStopD while its action is still in flight.
-- Recheck that real observation until either it appears or the result arrives.
awaitFirstStop :: AdmissionDeadline -> PersistentOwner -> MVar (Outcome StopReceipt) -> IO StopReceipt
awaitFirstStop original owner done = do
 left <- remainingMicros original
 check "original D live while observing first stop" (left>0)
 selected <- tryPersistentStopDeadline owner
 case selected of
  StopDeadlineLatched d -> awaitResult [original,d] "first stop" done
  StopDeadlineFailed _ -> ioError (userError "actual first stop D failed")
  _ -> do
   result <- tryReadMVar done
   case result of
    Just (Left ex) -> throwIO ex
    Just (Right value) -> pure value
    Nothing -> threadDelay (min left 1000) >> awaitFirstStop original owner done
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("root-commit: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
runCase :: Case -> Mode -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runCase (Case owner slot used seen workers lifecycle stopDone rootDone partDone retryDone repeatDone _) mode startD stopBudget drive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 remainingMicros startD >>= check "real startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 startWorker workers lifecycle [startD] $ do
  acquired <- withRetainedRoot root "/" ident $ \_ -> do
   drive owner
   phase <- persistentStatus owner
   check "real owner retired" (phase == PersistentRetired)
  check "actual root pair acquired" (acquired==Right ())
 restore $ awaitResult [startD] "real root and lifecycle" lifecycle
 startWorker workers stopDone [startD] (requestSessionStop owner stopBudget)
 stop <- restore $ awaitFirstStop startD owner stopDone
 first <- tryPersistentStopDeadline owner
 check "stop selected for unresolved root" $
  stop==StopUncertain CleanupUncertain && case first of StopDeadlineLatched _ -> True; _ -> False
 selectedStopD <- case first of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "no selected first stop D")
 remainingMicros selectedStopD >>= check "selected first stop D still live" . (>0)
 qaRootCommitHook $ \stage -> do
  atomicModifyIORef' seen (\xs -> (stage:xs,()))
  let inject = case mode of
       NormalBoth -> False
       PhasePublishFault -> stage=="phase-publish"
       PhaseAndDemoteFault -> stage=="phase-publish" || stage=="demote"
       GateBeforeInsert -> stage=="gate-before"
       GateAfterInsert -> stage=="gate-after"
  if inject then ioError (userError ("injected " ++ stage)) else pure ()
 startWorker workers rootDone [startD,selectedStopD] (closePersistentRootPart owner RootAnchor)
 rootReceipt <- restore $ awaitResult [startD,selectedStopD] "actual selected root close" rootDone
 marker <- qaRootCommitState owner RootAnchor
 busy <- qaRootGateBusy owner
 slots <- qaRootSlots root
 phase <- qaRootPhaseSnapshot owner
 events <- reverse <$> readIORef seen
 case mode of
  NormalBoth -> do
   check "first actual close committed" $
    rootReceipt==Right RootStepClosed && marker==Just (2,False) && not busy &&
    events==["phase-publish","gate-before","gate-after"] && slots==(QaSlotClosed,QaSlotOpen)
   startWorker workers partDone [startD,selectedStopD] (closePersistentRootPart owner ProcAnchor)
   procReceipt <- restore $ awaitResult [startD,selectedStopD] "actual selected proc close" partDone
   procMarker <- qaRootCommitState owner ProcAnchor
   closed <- qaRootSlots root
   check "positive other-part receipt" $
    procReceipt==Right RootStepClosed && procMarker==Just (2,False) && closed==(QaSlotClosed,QaSlotClosed)
  _ | mode==PhasePublishFault || mode==PhaseAndDemoteFault -> do
   let expectedMark = if mode==PhasePublishFault then 1 else 2
   check "armed marker survives publish failure regardless of demotion" $
    rootReceipt==Left CleanupUncertain && marker==Just (expectedMark,True) && not busy &&
    events==["phase-publish","demote"] && slots==(QaSlotClosed,QaSlotOpen) &&
    phase==Nothing
   startWorker workers partDone [startD,selectedStopD] (closePersistentRootPart owner RootAnchor)
   firstRetry <- restore $ awaitResult [startD,selectedStopD] "failed part cannot retry" partDone
   check "failed root retry refused before other request" (firstRetry==Left OwnerBusy)
   startWorker workers retryDone [startD,selectedStopD] (closePersistentRootPart owner ProcAnchor)
   otherPart <- restore $ awaitResult [startD,selectedStopD] "other part cannot use stale confirmation" retryDone
   closed <- qaRootSlots root
   check "sticky uncertainty blocks both physical close entries" $
    firstRetry==Left OwnerBusy && otherPart==Left OwnerBusy && closed==(QaSlotClosed,QaSlotOpen)
  GateBeforeInsert -> do
   check "unpublished final gate blocks both parts" $
    rootReceipt==Left CleanupUncertain && marker==Just (2,False) && busy && phase==Just False &&
    events==["phase-publish","gate-before"] && slots==(QaSlotClosed,QaSlotOpen)
   startWorker workers partDone [startD,selectedStopD] (closePersistentRootPart owner RootAnchor)
   rootRetry <- restore $ awaitResult [startD,selectedStopD] "busy gate refuses root" partDone
   check "busy root refused before other request" (rootRetry==Left OwnerBusy)
   startWorker workers retryDone [startD,selectedStopD] (closePersistentRootPart owner ProcAnchor)
   procRetry <- restore $ awaitResult [startD,selectedStopD] "busy gate refuses proc" retryDone
   check "no false close while gate withheld" (rootRetry==Left OwnerBusy && procRetry==Left OwnerBusy)
  GateAfterInsert -> do
   -- Explicit injection after actual putMVar is a fault-model premise. A lost
   -- return must not silently appear fully confirmed to future authority.
   check "post-insert lost receipt stays conservatively fenced" $
    rootReceipt==Left CleanupUncertain && slots==(QaSlotClosed,QaSlotOpen) &&
    events==["phase-publish","gate-before","gate-after"] && (busy || marker==Just (2,True))
  _ -> ioError (userError "unhandled case")
 after <- tryPersistentStopDeadline owner
 check "first StopD preserved or gate unavailable" (if mode==GateBeforeInsert then after==StopDeadlineBusy else after==first)
 case mode of
  NormalBoth -> do
   startWorker workers repeatDone [startD,selectedStopD] (requestSessionStop owner stopBudget)
   repeatedStop <- restore $ awaitResult [startD,selectedStopD] "same owner stop observation" repeatDone
   check "no false no-live" (repeatedStop==StopAlreadyRequested || case repeatedStop of StopUncertain _ -> True; _ -> False)
  _ -> pure () -- phase is genuinely unavailable: separate rooted stop observer remains Unknown

-- Distinct Sol first-stop witness host: no explicit StopD is minted here. The
-- real lifecycle driver must have selected a still-live implicit containment D
-- by actual owner code and retired without any explicit stop. If no such real
-- path exists, the selected root-close hook is never reached and the case fails.
-- The continuation receives the SAME strongly retained owner after the exact
-- gate-before insertion fault; it must root its own worker and never fill gate.
runImplicitBeforeFirstStop :: Case -> AdmissionDeadline -> (PersistentOwner -> IO ()) -> (PersistentOwner -> IO ()) -> IO ()
runImplicitBeforeFirstStop (Case owner slot used seen workers lifecycle _ rootDone _ _ _ continuationDone) startD drive continuation = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single implicit case" fresh
 remainingMicros startD >>= check "original startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 startWorker workers lifecycle [startD] $ do
  acquired <- withRetainedRoot root "/" ident $ \_ -> do
   drive owner
   phase <- persistentStatus owner
   check "actual owner retired" (phase==PersistentRetired)
  check "actual root pair acquired" (acquired==Right ())
 restore $ awaitResult [startD] "actual root and owner lifecycle" lifecycle
 firstBefore <- tryPersistentStopDeadline owner
 check "no explicit first stop D before injected fault" (firstBefore==StopDeadlineNotLatched)
 selected <- tryPersistentCleanupDeadline owner
 implicitD <- case selected of
  CleanupDeadlineSelected d -> pure d
  _ -> ioError (userError "real lifecycle did not select an implicit cleanup D")
 remainingMicros implicitD >>= check "selected implicit D live" . (>0)
 qaRootCommitHook $ \stage -> do
  atomicModifyIORef' seen (\xs -> (stage:xs,()))
  if stage=="gate-before" then ioError (userError "injected before final gate put") else pure ()
 startWorker workers rootDone [startD,implicitD] (closePersistentRootPart owner RootAnchor)
 receipt <- restore $ awaitResult [startD,implicitD] "actual containment-bound root close" rootDone
 events <- reverse <$> readIORef seen
 busy <- qaRootGateBusy owner
 slots <- qaRootSlots root
 phase <- qaRootPhaseSnapshot owner
 check "actual close reached injected final gate boundary" $
  receipt==Left CleanupUncertain && events==["phase-publish","gate-before"] && busy &&
  phase==Just False && slots==(QaSlotClosed,QaSlotOpen)
 stopAfter <- tryPersistentStopDeadline owner
 check "first-stop D remains unobservable on actual unavailable gate" (stopAfter==StopDeadlineBusy)
 startWorker workers continuationDone [startD,implicitD] (continuation owner)
 restore $ awaitResult [startD,implicitD] "same owner first-stop continuation" continuationDone
