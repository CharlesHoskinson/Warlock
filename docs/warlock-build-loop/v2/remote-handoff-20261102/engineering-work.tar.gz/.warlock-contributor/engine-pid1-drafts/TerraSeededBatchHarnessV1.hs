-- Private QA adapter only. Root supplies registered owners, pinned child,
-- marker lifecycle, current original budgets and external process guardian.
-- It is not a backend/native acceptance test or a cleanup-success receipt.
module TerraSeededBatchHarnessV1 (runAll) where

import Control.Exception (finally, mask)
import Control.Monad (forM_, unless)
import Foreign.StablePtr (newStablePtr)
import System.IO (IOMode(ReadMode), openFile)
import Warlock.Capture.Process (SessionObservation, ToolError)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline)
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, StartBudget, StopBudget, SessionExit(..), withPersistentOwner )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture)
import qualified TerraSeededBatchLifecycleV1 as Seeded

-- Each allocator invocation is a fresh registered owner and a distinct owned
-- marker. removeMarker must be idempotent. suppliedFrameD mints the test frame's one original bound; it is never
-- renewed inside the generated sequence. verifyReady is Root's real fixture
-- check; this adapter cannot certify selected-executable or namespace identity.
runAll :: FilePath -> IO PersistentOwner -> IO FilePath -> (FilePath -> IO ())
       -> (FilePath -> SessionObservation -> IO (Either ToolError ()))
       -> IO StartBudget -> IO AdmissionDeadline -> StopBudget -> IO ()
runAll child allocOwner newMarker removeMarker verifyReady suppliedStart suppliedFrameD stopBudget =
 forM_ Seeded.seeds $ \seed -> mask $ \restore -> do
  owner <- allocOwner
  marker <- newMarker
  childInput <- openFile "/dev/null" ReadMode
  _ <- newStablePtr (owner,marker,childInput)
  start <- suppliedStart
  let cleanup = removeMarker marker
  result <- restore (withPersistentOwner owner (persistentFixture child [marker,"exit-when-removed"] childInput)
   4096 start stopBudget (verifyReady marker) (\live -> do
    frameD <- suppliedFrameD
    Seeded.runSeed owner live frameD stopBudget seed
    removeMarker marker)) `finally` cleanup
  unless (case result of Right ((), LeaderReaped _) -> True; _ -> False)
   (ioError (userError ("seed " ++ show seed ++ " owner outcome unconfirmed: " ++ show result)))
