#!/usr/bin/env node
/**
 * Literal responsive, keyboard/focus, strict-IME, d6becb72c MVP-availability matrix,
 * 16-scenario launchpad, and WCAG 2.1 contrast QA oracle for compiled
 * HEAD-based site/src/SiteMain.elm (SiteMainHeadProd2325.patch).
 *
 * Usage (Root executor):
 *   node .warlock-contributor/engine-pid1-drafts/site-head-mvp-usability-qa-2325.cjs \
 *     <compiled-site-or-index.html> <tokens.css> [report-out.json]
 */
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const EXPECTED_SCENARIOS = Object.freeze([
  'taskbar',
  'launcher',
  'switcher',
  'task-view',
  'transfer',
  'picker',
  'preview-states',
  'snap',
  'notifications',
  'settings',
  'files',
  'system',
  'window-menu',
  'confirmation',
  'application-actions',
  'status-recovery',
]);

function parseHexColor(hex) {
  const clean = String(hex).trim().replace(/^#/, '');
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) {
    throw new Error(`Expected 6-digit hex color, got ${hex}`);
  }
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
}

function relativeLuminance([r8, g8, b8]) {
  const chan = (v) => {
    const s = v / 255;
    return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * chan(r8) + 0.7152 * chan(g8) + 0.0722 * chan(b8);
}

function wcagContrastRatio(fgHex, bgHex) {
  const l1 = relativeLuminance(parseHexColor(fgHex));
  const l2 = relativeLuminance(parseHexColor(bgHex));
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return Number(((lighter + 0.05) / (darker + 0.05)).toFixed(2));
}

function parseThemeTokens(tokensCss) {
  const themes = {};
  for (const theme of ['night', 'dawn', 'high-contrast']) {
    const blockRe = new RegExp(`\\[data-theme="${theme}"\\][^{]*\\{([\\s\\S]*?)\\}`, 'm');
    const match = tokensCss.match(blockRe);
    if (!match) {
      throw new Error(`Missing [data-theme="${theme}"] block in tokens.css`);
    }
    const vars = {};
    for (const m of match[1].matchAll(/(--wl-[a-z0-9-]+)\s*:\s*([^;]+);/gi)) {
      vars[m[1]] = m[2].trim();
    }
    themes[theme] = vars;
  }
  return themes;
}

function evaluateContrastOracle(themes) {
  const checks = [];
  for (const theme of ['night', 'dawn', 'high-contrast']) {
    const t = themes[theme];
    const pressedIndicator =
      theme === 'high-contrast' ? t['--wl-sys-color-focus'] : t['--wl-sys-color-brand-text'];
    const activePillOuterBorder =
      theme === 'night'
        ? t['--wl-sys-color-on-action']
        : theme === 'dawn'
          ? t['--wl-sys-color-brand-text']
          : t['--wl-sys-color-action-fill'];
    const pairs = [
      ['text-on-canvas', t['--wl-sys-color-text'], t['--wl-sys-color-canvas'], 4.5],
      ['text-on-surface', t['--wl-sys-color-text'], t['--wl-sys-color-surface'], 4.5],
      ['secondary-on-canvas', t['--wl-sys-color-text-secondary'], t['--wl-sys-color-canvas'], 4.5],
      ['secondary-on-surface', t['--wl-sys-color-text-secondary'], t['--wl-sys-color-surface'], 4.5],
      ['brand-on-surface', t['--wl-sys-color-brand-text'], t['--wl-sys-color-surface'], 4.5],
      ['brand-on-recessed', t['--wl-sys-color-brand-text'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['badge-positive-on-recessed', t['--wl-sys-color-positive'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['badge-info-on-recessed', t['--wl-sys-color-info'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['badge-warning-on-recessed', t['--wl-sys-color-warning'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['badge-neutral-on-recessed', t['--wl-sys-color-text'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['primary-cta', t['--wl-sys-color-on-action'], t['--wl-sys-color-action-fill'], 4.5],
      ['active-pill-outer-border', activePillOuterBorder, t['--wl-sys-color-surface-recessed'], 3.0],
      ['pressed-chip-text', t['--wl-sys-color-text'], t['--wl-sys-color-surface-selected'], 4.5],
      ['pressed-chip-indicator', pressedIndicator, t['--wl-sys-color-surface'], 3.0],
      ['focus-ring-on-gap', t['--wl-sys-color-focus'], t['--wl-sys-color-focus-gap'], 3.0],
      ['focus-ring-on-canvas', t['--wl-sys-color-focus'], t['--wl-sys-color-canvas'], 3.0],
    ];
    for (const [label, fg, bg, minRatio] of pairs) {
      const ratio = wcagContrastRatio(fg, bg);
      checks.push({
        theme,
        pair: label,
        fg,
        bg,
        ratio,
        minRatio,
        passed: ratio >= minRatio,
      });
    }
  }
  return checks;
}

function evaluateResponsiveAndTargetCssOracle(cssText) {
  return [
    {
      name: 'rootOverflowClip',
      passed: /\.wl-home-root\s*\{[\s\S]*?overflow-x:\s*clip;/m.test(cssText),
    },
    {
      name: 'heroOverflowClip',
      passed: /\.wl-home-root\s+\.wl-hero\s*\{\s*overflow-x:\s*clip;\s*\}/m.test(cssText),
    },
    {
      name: 'matrixWrapScrollableRegion',
      passed: /\.wl-home-matrix-wrap\s*\{[^}]*overflow-x:\s*auto;[^}]*max-width:\s*100%;/m.test(cssText),
    },
    {
      name: 'pageIndexLinksUnderlined44px',
      passed: /\.wl-home-index-list\s+a\s*\{[^}]*min-height:\s*2\.75rem;[^}]*text-decoration:\s*underline;/m.test(
        cssText
      ),
    },
    {
      name: 'scenarioLinkChipsUnderlined44px',
      passed: /a\.wl-home-scenario-chip\s*\{[\s\S]*?min-height:\s*2\.75rem;[\s\S]*?text-decoration:\s*underline;\s*\}/m.test(
        cssText
      ),
    },
    {
      name: 'chipTouchTargetMin44px',
      passed: /\.wl-home-chip\s*\{[^}]*min-height:\s*2\.75rem;/m.test(cssText),
    },
    {
      name: 'mobileActionsTouchTargetMin44px',
      passed: /\.wl-home-mobile-actions\s+\.wl-doc-button\s*\{[^}]*min-height:\s*2\.75rem;/m.test(cssText),
    },
    {
      name: 'navLinksTouchTargetMin44px',
      passed: /\.wl-home-nav\s+a\s*\{[^}]*min-height:\s*2\.75rem;/m.test(cssText),
    },
    {
      name: 'dawnAndHcActivePillOuterBoundaryRules',
      passed:
        /\.wl-home-root\[data-theme="dawn"\]\s+\.wl-home-pill\.is-active\s*\{[^}]*--wl-sys-color-brand-text/m.test(
          cssText
        ) &&
        /\.wl-home-root\[data-theme="high-contrast"\]\s+\.wl-home-pill\.is-active\s*\{[^}]*--wl-sys-color-action-fill/m.test(
          cssText
        ),
    },
    {
      name: 'tablet1180HeroImageContainment',
      passed: /@media\s*\(max-width:\s*1180px\)\s*\{[\s\S]*?\.wl-hero-shot\s+img\s*\{[^}]*width:\s*100%;[^}]*transform:\s*none;/m.test(
        cssText
      ),
    },
    {
      name: 'mobile900DrawerHiddenWhenClosed',
      passed: /@media\s*\(max-width:\s*900px\)\s*\{[\s\S]*?\.wl-home-root\[data-nav-open="false"\]\s+\.wl-home-drawer\s*\{\s*display:\s*none;\s*\}/m.test(
        cssText
      ),
    },
    {
      name: 'highContrastPressedChipNonColorAndFocusBorder',
      passed:
        /\.wl-home-root\[data-theme="high-contrast"\]\s+\.wl-home-chip\.is-pressed\s*\{[^}]*--wl-sys-color-focus[^}]*text-decoration:\s*underline;/m.test(
          cssText
        ),
    },
    {
      name: 'reducedMotionZeroDuration',
      passed:
        /\.wl-home-root\[data-motion="reduced"\]\s*\*[\s\S]*?transition-duration:\s*0ms\s*!important;[\s\S]*?animation-duration:\s*0ms\s*!important;/m.test(
          cssText
        ),
    },
  ];
}

function createControlledDom() {
  const focusCalls = [];
  let activeElement = null;
  const rafQueue = [];

  class NodeBase {
    constructor(nodeType, tagName) {
      this.nodeType = nodeType;
      this.tagName = tagName ? tagName.toUpperCase() : '';
      this.nodeName = this.tagName || '#text';
      this.namespaceURI = 'http://www.w3.org/1999/xhtml';
      this.parentNode = null;
      this.childNodes = [];
      this.attributes = new Map();
      this.listeners = new Map();
      this.style = {};
      this._id = '';
      this._className = '';
      this.tabIndex = 0;
    }
    get id() {
      return this._id;
    }
    set id(v) {
      this._id = String(v);
      this.attributes.set('id', this._id);
    }
    get className() {
      return this._className;
    }
    set className(v) {
      this._className = String(v);
      this.attributes.set('class', this._className);
    }
    setAttribute(name, value) {
      const k = String(name);
      const v = String(value);
      this.attributes.set(k, v);
      if (k === 'id') this._id = v;
      if (k === 'class') this._className = v;
      if (k === 'tabindex') this.tabIndex = Number(v);
    }
    getAttribute(name) {
      const k = String(name);
      return this.attributes.has(k) ? this.attributes.get(k) : null;
    }
    removeAttribute(name) {
      const k = String(name);
      this.attributes.delete(k);
      if (k === 'id') this._id = '';
      if (k === 'class') this._className = '';
    }
    appendChild(child) {
      if (child.nodeType === 11) {
        for (const c of [...child.childNodes]) this.appendChild(c);
        return child;
      }
      if (child.parentNode) child.parentNode.removeChild(child);
      child.parentNode = this;
      this.childNodes.push(child);
      return child;
    }
    insertBefore(newNode, refNode) {
      if (!refNode) return this.appendChild(newNode);
      const idx = this.childNodes.indexOf(refNode);
      if (idx === -1) return this.appendChild(newNode);
      if (newNode.parentNode) newNode.parentNode.removeChild(newNode);
      newNode.parentNode = this;
      this.childNodes.splice(idx, 0, newNode);
      return newNode;
    }
    removeChild(child) {
      const idx = this.childNodes.indexOf(child);
      if (idx !== -1) {
        this.childNodes.splice(idx, 1);
        child.parentNode = null;
      }
      return child;
    }
    replaceChild(newChild, oldChild) {
      const idx = this.childNodes.indexOf(oldChild);
      if (idx === -1) return this.appendChild(newChild);
      if (newChild.parentNode) newChild.parentNode.removeChild(newChild);
      newChild.parentNode = this;
      oldChild.parentNode = null;
      this.childNodes[idx] = newChild;
      return oldChild;
    }
    addEventListener(type, handler) {
      if (!this.listeners.has(type)) this.listeners.set(type, new Set());
      this.listeners.get(type).add(handler);
    }
    removeEventListener(type, handler) {
      if (this.listeners.has(type)) this.listeners.get(type).delete(handler);
    }
    focus() {
      activeElement = this;
      focusCalls.push(this.id || this.tagName);
    }
    get textContent() {
      if (this.nodeType === 3) return this.data || '';
      return this.childNodes.map((c) => c.textContent).join('');
    }
    set textContent(v) {
      this.childNodes = [];
      if (v !== '' && v !== null && v !== undefined) {
        const t = new TextNode(String(v));
        this.appendChild(t);
      }
    }
    dispatchEvent(rawEvent) {
      const event = Object.assign(
        {
          target: this,
          currentTarget: this,
          bubbles: true,
          cancelable: true,
          defaultPrevented: false,
          propagationStopped: false,
          preventDefault() {
            if (this.cancelable) this.defaultPrevented = true;
          },
          stopPropagation() {
            this.propagationStopped = true;
          },
        },
        rawEvent
      );
      let cur = this;
      while (cur) {
        event.currentTarget = cur;
        const set = cur.listeners.get(event.type);
        if (set) {
          for (const fn of [...set]) {
            if (typeof fn === 'function') fn.call(cur, event);
            else if (fn && typeof fn.handleEvent === 'function') fn.handleEvent(event);
          }
        }
        if (!event.bubbles || event.propagationStopped) break;
        cur = cur.parentNode;
      }
      return !event.defaultPrevented;
    }
  }

  class TextNode extends NodeBase {
    constructor(data) {
      super(3, '');
      this.data = String(data);
    }
    get nodeValue() {
      return this.data;
    }
    set nodeValue(v) {
      this.data = String(v);
    }
  }

  const documentElement = new NodeBase(1, 'html');
  const head = new NodeBase(1, 'head');
  const body = new NodeBase(1, 'body');
  const mountNode = new NodeBase(1, 'pre');
  mountNode.id = 'elm';
  documentElement.appendChild(head);
  documentElement.appendChild(body);
  body.appendChild(mountNode);

  function walk(root, pred, acc = []) {
    if (root.nodeType === 1 && pred(root)) acc.push(root);
    for (const c of root.childNodes) walk(c, pred, acc);
    return acc;
  }

  const document = {
    documentElement,
    head,
    body,
    walk,
    get activeElement() {
      return activeElement || body;
    },
    createElement(tag) {
      return new NodeBase(1, tag);
    },
    createElementNS(_ns, tag) {
      return new NodeBase(1, tag);
    },
    createTextNode(text) {
      return new TextNode(text);
    },
    createDocumentFragment() {
      return new NodeBase(11, '');
    },
    getElementById(id) {
      return walk(documentElement, (el) => el.id === id)[0] || null;
    },
    querySelectorAll(pred) {
      return walk(documentElement, pred);
    },
    addEventListener(type, fn) {
      documentElement.addEventListener(type, fn);
    },
    removeEventListener(type, fn) {
      documentElement.removeEventListener(type, fn);
    },
  };

  function flushFrames() {
    while (rafQueue.length > 0) {
      const batch = rafQueue.splice(0, rafQueue.length);
      for (const cb of batch) cb(16.67);
    }
  }

  const windowObj = {
    document,
    navigator: { userAgent: 'WarlockHeadMvpSiteQA/2221' },
    location: { href: 'http://127.0.0.1/Warlock/index.html' },
    requestAnimationFrame(cb) {
      rafQueue.push(cb);
      return rafQueue.length;
    },
    cancelAnimationFrame() {},
    setTimeout,
    clearTimeout,
  };

  return { windowObj, document, focusCalls, flushFrames };
}

function validateRenderedDomSnapshot(document) {
  const root = document.querySelectorAll((el) =>
    (el.getAttribute('class') || '').includes('wl-home-root')
  )[0];
  if (!root) return { ok: false, reason: 'Missing .wl-home-root' };

  // Zero duplicate IDs anywhere in DOM
  const allIdNodes = document.querySelectorAll((el) => Boolean(el.id));
  const seenIds = new Set();
  for (const node of allIdNodes) {
    if (seenIds.has(node.id)) {
      return { ok: false, reason: `Duplicate DOM id #${node.id}` };
    }
    seenIds.add(node.id);
  }

  // Page index (#wl-page-index) with 8 live fragment links
  const pageIndex = document.getElementById('wl-page-index');
  if (!pageIndex || pageIndex.getAttribute('aria-label') !== 'On this page') {
    return { ok: false, reason: 'Missing #wl-page-index nav[aria-label="On this page"]' };
  }
  const indexAnchors = document.walk(pageIndex, (el) => el.tagName === 'A');
  if (indexAnchors.length !== 8) {
    return { ok: false, reason: `Expected 8 page index links, got ${indexAnchors.length}` };
  }
  for (const a of indexAnchors) {
    const href = a.getAttribute('href') || '';
    if (!href.startsWith('#') || !document.getElementById(href.slice(1))) {
      return { ok: false, reason: `Broken page index fragment ${href}` };
    }
  }

  // Roving 1-of-8 workbench tabs
  const tabs = document.querySelectorAll((el) => el.getAttribute('role') === 'tab');
  const zeroTabs = tabs.filter((t) => t.getAttribute('tabindex') === '0');
  const minusOneTabs = tabs.filter((t) => t.getAttribute('tabindex') === '-1');
  const selectedTabs = tabs.filter((t) => t.getAttribute('aria-selected') === 'true');
  if (tabs.length !== 8 || zeroTabs.length !== 1 || minusOneTabs.length !== 7 || selectedTabs.length !== 1) {
    return { ok: false, reason: 'Roving tabindex 1-of-8 invariant violated' };
  }
  if (zeroTabs[0].id !== selectedTabs[0].id) {
    return { ok: false, reason: 'tabindex=0 tab does not match aria-selected=true tab' };
  }

  // Hero quick-scenarios strip (7 scenario chips + 1 #scenarios chip = 8)
  const quickStrip = document.getElementById('wl-quick-scenarios');
  if (!quickStrip) return { ok: false, reason: 'Missing #wl-quick-scenarios conversion strip' };
  const quickLinks = document.walk(quickStrip, (el) => el.tagName === 'A');
  if (quickLinks.length !== 8) {
    return { ok: false, reason: `Expected 8 hero quick scenario links, got ${quickLinks.length}` };
  }

  // 4-tier d6becb72c MVP availability & acceptance-limits matrix
  const matrixRegion = document.getElementById('wl-mvp-matrix-region');
  const matrix = document.getElementById('wl-mvp-matrix');
  if (!matrixRegion || matrixRegion.getAttribute('role') !== 'region' || matrixRegion.getAttribute('tabindex') !== '0' || !matrix) {
    return { ok: false, reason: 'Missing keyboard-scrollable #wl-mvp-matrix-region / #wl-mvp-matrix' };
  }
  for (const rowId of [
    'wl-mvp-row-browser',
    'wl-mvp-row-contracts',
    'wl-mvp-row-omarchy-vm',
    'wl-mvp-row-native-release',
  ]) {
    if (!document.getElementById(rowId)) {
      return { ok: false, reason: `Missing MVP matrix row #${rowId}` };
    }
  }

  const fullText = root.textContent;
  if (/15\s+whole\s+original/i.test(fullText) || /fifteen\s+whole\s+original/i.test(fullText)) {
    return { ok: false, reason: 'Stale 15 whole requirements text still present' };
  }
  if (/live applications -> search and refresh input journeys have not completed/i.test(fullText)) {
    return { ok: false, reason: 'Stale pre-d6becb72c search journey absence claim still present' };
  }
  for (const requiredNodeId of [
    'mvp-evidence',
    'wl-mvp-tiled-layout',
    'wl-mvp-pane-foot',
    'wl-mvp-pane-warlock',
    'wl-mvp-evidence-grid',
    'wl-evidence-foot',
    'wl-evidence-footz',
    'wl-evidence-lifecycle',
    'wl-evidence-no-restart',
    'run-beta',
    'wl-run-browser',
    'wl-run-no-download',
    'wl-run-source-check',
    'wl-run-omarchy-trial',
  ]) {
    if (!document.getElementById(requiredNodeId)) {
      return { ok: false, reason: `Missing MVP evidence or beta boundary node #${requiredNodeId}` };
    }
  }
  if (/durable pin writes, physical escape, and read-only draft retention on http failure work/i.test(fullText)) {
    return { ok: false, reason: 'Overclaiming beta capability copy still present' };
  }
  for (const literal of [
    'No desktop binary · Design tokens only',
    'docs/warlock/how-to/run-omarchy-mvp.md',
    'D <= 28s',
    'nativeOperations = []',
    'bdeac7349',
    '137 typed controls',
    '61 complete policy histories',
    '7,293 HTTP/DOM checks',
    '17 / 242',
    '41 / 417',
    '225 of 242',
    '376 of 417',
    '--application-only',
    'not a replacement window manager',
    'Read-only application catalog search only',
    'footz',
    '17 acknowledged',
    'exit -9',
    'exited 1 (passed=false)',
    'no automatic reconnect',
    'HOSTSTOP2',
    'Unaccepted · Not released',
  ]) {
    if (!fullText.includes(literal)) {
      return { ok: false, reason: `Missing required d6becb72c MVP truth literal: ${literal}` };
    }
  }

  return { ok: true, activeTabId: zeroTabs[0].id };
}

function runMutationSensitivitySelfTest() {
  const lowRatio = wcagContrastRatio('#777777', '#FFFFFF');
  assert.equal(lowRatio < 4.5, true, 'Contrast oracle must reject #777777 on #FFFFFF (4.48:1 < 4.5:1)');

  const unpatchedDawnBorderRatio = wcagContrastRatio('#FFF8F5', '#F2EAE3');
  assert.equal(
    unpatchedDawnBorderRatio < 3.0,
    true,
    'Contrast oracle must reject white #FFF8F5 border on Dawn surface-recessed #F2EAE3'
  );

  const regressedCss = '.wl-home-chip { min-height: 2.25rem; }';
  const cssChecks = evaluateResponsiveAndTargetCssOracle(regressedCss);
  const chipCheck = cssChecks.find((c) => c.name === 'chipTouchTargetMin44px');
  assert.equal(chipCheck.passed, false, 'Target-size oracle must reject 2.25rem chip min-height');

  return {
    passed: true,
    rejectedContrastSample: lowRatio,
    rejectedUnpatchedDawnPillBorderRatio: unpatchedDawnBorderRatio,
    rejected36pxTargetSample: true,
  };
}

function main() {
  const htmlPath = path.resolve(process.argv[2] || path.join(__dirname, '../../site/index.html'));
  const tokensPath = path.resolve(
    process.argv[3] || path.join(__dirname, '../../site/assets/shared/tokens.css')
  );
  const reportOut = process.argv[4] ? path.resolve(process.argv[4]) : null;

  const htmlSource = fs.readFileSync(htmlPath, 'utf8');
  const tokensCss = fs.readFileSync(tokensPath, 'utf8');

  const scriptMatch = htmlSource.match(/<script>\s*(try\s*\{[\s\S]*?)\s*<\/script>/);
  assert.ok(scriptMatch, `Could not locate compiled Elm <script> block in ${htmlPath}`);

  const { windowObj, document, focusCalls, flushFrames } = createControlledDom();
  const sandbox = Object.assign(windowObj, {
    window: windowObj,
    self: windowObj,
    globalThis: windowObj,
    console,
  });
  vm.createContext(sandbox);
  vm.runInContext(scriptMatch[1], sandbox, { filename: htmlPath });
  flushFrames();

  // 1. Initial rendered DOM, page index, 4-row d6becb72c MVP matrix, and 16-scenario launchpad
  const initialSnap = validateRenderedDomSnapshot(document);
  assert.equal(initialSnap.ok, true, initialSnap.reason);
  assert.equal(initialSnap.activeTabId, 'wl-tab-taskbar');

  const scenarioGrid = document.getElementById('wl-scenario-grid');
  assert.ok(scenarioGrid, 'Missing #wl-scenario-grid');
  for (const slug of EXPECTED_SCENARIOS) {
    const card = document.getElementById(`wl-scenario-card-${slug}`);
    assert.ok(card, `Missing scenario launch card #wl-scenario-card-${slug}`);
    const launchLink = document.walk(
      card,
      (el) => el.tagName === 'A' && el.getAttribute('href') === `./test-drive/index.html?scenario=${slug}`
    )[0];
    assert.ok(launchLink, `Missing scenario href for ${slug}`);
  }

  // Verify independent scenario filter buttons (8 / 3 / 5 / 16) do not alter #features (8 articles)
  const scenariosSection = document.getElementById('scenarios');
  const scenarioButtons = document.walk(scenariosSection, (el) => el.tagName === 'BUTTON');
  assert.equal(scenarioButtons.length, 4, 'Expected 4 scenario filter buttons');
  const expectedCounts = [16, 8, 3, 5];
  for (const idx of [1, 2, 3, 0]) {
    scenarioButtons[idx].dispatchEvent({ type: 'click' });
    flushFrames();
    const gridNode = document.getElementById('wl-scenario-grid');
    const renderedCards = document.walk(gridNode, (el) => el.tagName === 'ARTICLE');
    assert.equal(renderedCards.length, expectedCounts[idx], `Scenario filter ${idx} count mismatch`);
    const featureArticles = document.querySelectorAll(
      (el) => el.tagName === 'ARTICLE' && (el.getAttribute('class') || '').includes('wl-feature')
    );
    assert.equal(featureArticles.length, 8, 'Scenario filter must not mutate #features articles');
  }

  // 2. Responsive / target-size / underline / Dawn+HC pill / reduced-motion CSS oracle
  const styleNodes = document.querySelectorAll((el) => el.tagName === 'STYLE');
  assert.ok(styleNodes.length >= 1, 'Expected rendered <style> node from SiteMain.view');
  const supplementalCss = styleNodes.map((s) => s.textContent).join('\n');
  const responsiveChecks = evaluateResponsiveAndTargetCssOracle(supplementalCss);
  for (const rc of responsiveChecks) {
    assert.equal(rc.passed, true, `Responsive/CSS oracle failed: ${rc.name}`);
  }

  // 3. Literal WCAG 2.1 luminance contrast oracle (48 pairs across Night, Dawn, High Contrast)
  const themes = parseThemeTokens(tokensCss);
  const contrastChecks = evaluateContrastOracle(themes);
  for (const cc of contrastChecks) {
    assert.equal(
      cc.passed,
      true,
      `Contrast oracle failed on ${cc.theme}/${cc.pair} (${cc.fg} vs ${cc.bg}): ${cc.ratio}:1 < ${cc.minRatio}:1`
    );
  }

  // 4. Roving tabindex + Dom.focus + untrapped Tab + strict IME/null/wrong-type rejection
  const tabTaskbar = document.getElementById('wl-tab-taskbar');
  assert.ok(tabTaskbar);
  assert.equal(
    tabTaskbar.dispatchEvent({ type: 'keydown', key: 'Tab', isComposing: false, keyCode: 9 }),
    true
  );
  flushFrames();
  assert.equal(focusCalls.length, 0);

  for (const rejectedEvent of [
    { type: 'keydown', key: 'ArrowRight', isComposing: true, keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: 229 },
    { type: 'keydown', key: 'Process', isComposing: false, keyCode: 0 },
    { type: 'keydown', key: 'ArrowRight', isComposing: null, keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: null },
    { type: 'keydown', key: 'ArrowRight', isComposing: 'false', keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: '39' },
  ]) {
    const allowedDefault = tabTaskbar.dispatchEvent(rejectedEvent);
    flushFrames();
    assert.equal(allowedDefault, true, 'Rejected event must not call preventDefault');
    assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-taskbar');
    assert.equal(focusCalls.length, 0);
  }

  const arrowPrevented = !tabTaskbar.dispatchEvent({
    type: 'keydown',
    key: 'ArrowRight',
    isComposing: false,
    keyCode: 39,
  });
  flushFrames();
  assert.equal(arrowPrevented, true);
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-launcher');
  assert.equal(focusCalls.at(-1), 'wl-tab-launcher');

  const tabLauncher = document.getElementById('wl-tab-launcher');
  tabLauncher.dispatchEvent({ type: 'keydown', key: 'End', isComposing: false, keyCode: 35 });
  flushFrames();
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-files');
  assert.equal(focusCalls.at(-1), 'wl-tab-files');

  const tabFiles = document.getElementById('wl-tab-files');
  tabFiles.dispatchEvent({ type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: 39 });
  flushFrames();
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-taskbar');
  assert.equal(focusCalls.at(-1), 'wl-tab-taskbar');

  // 5. Mobile drawer Escape focus return to #wl-home-nav-toggle + IME/null rejection
  const navToggle = document.getElementById('wl-home-nav-toggle');
  const drawer = document.getElementById('wl-home-nav-drawer');
  assert.ok(navToggle && drawer);
  const focusCountBeforeDrawer = focusCalls.length;
  navToggle.dispatchEvent({ type: 'click' });
  flushFrames();
  assert.equal(navToggle.getAttribute('aria-expanded'), 'true');

  for (const badEsc of [
    { type: 'keydown', key: 'Escape', isComposing: true, keyCode: 27 },
    { type: 'keydown', key: 'Escape', isComposing: false, keyCode: 229 },
    { type: 'keydown', key: 'Escape', isComposing: null, keyCode: 27 },
    { type: 'keydown', key: 'Escape', isComposing: 'false', keyCode: 27 },
  ]) {
    drawer.dispatchEvent(badEsc);
    flushFrames();
    assert.equal(navToggle.getAttribute('aria-expanded'), 'true');
    assert.equal(focusCalls.length, focusCountBeforeDrawer);
  }

  drawer.dispatchEvent({ type: 'keydown', key: 'Escape', isComposing: false, keyCode: 27 });
  flushFrames();
  assert.equal(navToggle.getAttribute('aria-expanded'), 'false');
  assert.equal(focusCalls.at(-1), 'wl-home-nav-toggle');

  const focusCountAfterClose = focusCalls.length;
  drawer.dispatchEvent({ type: 'keydown', key: 'Escape', isComposing: false, keyCode: 27 });
  flushFrames();
  assert.equal(focusCalls.length, focusCountAfterClose);

  // 6. Mutation sensitivity self-test
  const sensitivity = runMutationSensitivitySelfTest();

  const report = {
    suite: 'site-head-mvp-usability-qa-0004',
    htmlInput: htmlPath,
    tokensInput: tokensPath,
    allPassed: true,
    focusSequenceObserved: focusCalls,
    responsiveChecks,
    contrastChecksCount: contrastChecks.length,
    minObservedContrastRatio: Math.min(...contrastChecks.map((c) => c.ratio)),
    contrastChecks,
    mutationSensitivitySelfTest: sensitivity,
  };

  if (reportOut) {
    fs.writeFileSync(reportOut, JSON.stringify(report, null, 2) + '\n', 'utf8');
  }
  process.stdout.write(
    JSON.stringify({
      ok: true,
      suite: report.suite,
      focusCalls,
      contrastPairs: report.contrastChecksCount,
      minContrast: report.minObservedContrastRatio,
    }) + '\n'
  );
}

main();
