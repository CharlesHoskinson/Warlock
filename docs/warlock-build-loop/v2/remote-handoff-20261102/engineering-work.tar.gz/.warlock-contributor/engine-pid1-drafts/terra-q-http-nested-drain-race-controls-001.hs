{-# LANGUAGE OverloadedStrings #-}
-- SOURCE ONLY; ROOT EXECUTES. One private, guardian-owned process per Case.
-- The hook is QA-only: it never supplies an owner, token, descriptor or D.
-- QA explicitly invokes the real drain primitive; production interleaving is unproven.
module QHttpNestedDrainRace001 (Case,newCase,runCase,retainedWorkers,retainedResults) where
import Control.Concurrent (ThreadId,forkIOWithUnmask,threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..),StartupAdmissionFailure(..),NestedCleanup(..),
  newPersistentOwner,startBudgetFromDeadline,requestSessionStop,tryPersistentStopDeadline,
  withPersistentBoundNestedStartup,runPersistentBoundImage,closeNextPersistentNested)
import Warlock.Capture.Process.Persistent.Internal (qaNestedDrain,qaNestedGateCounts)
import Warlock.Platform.Executable (LeaseRole(..))
import Warlock.Platform.Resolver (Identity,Pin,Link,qaNestedLeaseHook)

type Outcome a = Either SomeException a
type Cleanup = Either ToolError NestedCleanup
data Case = Case PersistentOwner (IORef Bool) (IORef [ThreadId]) (IORef [String])
 (MVar (Outcome ())) (MVar (Outcome StopReceipt)) (MVar (Outcome Cleanup))
 (MVar (Outcome Cleanup)) (MVar (Outcome Cleanup)) (MVar (Outcome Cleanup))
 (MVar (Outcome ())) (MVar ()) (MVar ())
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef False <*> newIORef [] <*> newIORef []
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ xs _ _ _ _ _ _ _ _ _ _) = readIORef xs
retainedResults :: Case -> IO (Maybe (Outcome ()),Maybe (Outcome StopReceipt),Maybe (Outcome Cleanup),Maybe (Outcome Cleanup),Maybe (Outcome Cleanup),Maybe (Outcome Cleanup),Maybe (Outcome ()))
retainedResults (Case _ _ _ _ setup stop first bad second final drain _ _) = (,,,,,,)
 <$> tryReadMVar setup <*> tryReadMVar stop <*> tryReadMVar first <*> tryReadMVar bad <*> tryReadMVar second <*> tryReadMVar final <*> tryReadMVar drain
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("nested close fixture: " ++ label)))
start :: IORef [ThreadId] -> MVar (Outcome a) -> [AdmissionDeadline] -> IO a -> IO ()
start workers done bounds action = mask $ \_ -> do
 gate <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar gate
   left <- minimum <$> mapM remainingMicros bounds
   check "same D live before action entry" (left>0)
   action
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar gate ()
await :: [AdmissionDeadline] -> String -> MVar (Outcome a) -> IO a
await ds label done = do
 left <- minimum <$> mapM remainingMicros ds
 check (label ++ ": original deadline live") (left>0)
 observed <- timeout left (readMVar done)
 case observed of
  Nothing -> ioError (userError (label ++ ": Unknown; retain Case and guardian"))
  Just result -> do
   after <- minimum <$> mapM remainingMicros ds
   check (label ++ ": receipt before selected D") (after>0)
   either throwIO pure result
awaitStop :: AdmissionDeadline -> PersistentOwner -> MVar (Outcome StopReceipt) -> IO StopReceipt
awaitStop originalD owner done = do
 left <- remainingMicros originalD
 check "original D while awaiting actual first StopD" (left>0)
 selected <- tryPersistentStopDeadline owner
 case selected of
  StopDeadlineLatched d -> await [originalD,d] "first stop" done
  StopDeadlineFailed _ -> ioError (userError "first StopD failed")
  _ -> do
   result <- tryReadMVar done
   case result of
    Just value -> either throwIO pure value
    Nothing -> threadDelay (min left 1000) >> awaitStop originalD owner done
waitSignal :: [AdmissionDeadline] -> String -> MVar () -> IO ()
waitSignal ds label cell = do
 left <- minimum <$> mapM remainingMicros ds
 check (label ++ ": selected deadline live") (left>0)
 result <- timeout left (readMVar cell)
 case result of Nothing -> ioError (userError (label ++ ": Unknown; retain guardian")); Just () -> pure ()
awaitRegistered :: [AdmissionDeadline] -> PersistentOwner -> IO ()
awaitRegistered ds owner = do
 left <- minimum <$> mapM remainingMicros ds
 check "same D live while awaiting actual drain registration" (left>0)
 snap <- qaNestedGateCounts owner
 case snap of
  Just (active,waiters) | active==1 && waiters>0 -> pure ()
  _ -> threadDelay (min left 1000) >> awaitRegistered ds owner
-- The host supplies real root identity/pins and validated image inputs; no fake
-- root or mutable scope. It must keep the Case and an external guardian alive
-- after any unconfirmed result. If both actual lease duplicates cannot be
-- published on this route, the fixture stays HOLD instead of inventing slots.
runCase :: Case -> AdmissionDeadline -> StopBudget -> B.ByteString -> Identity -> [Pin] -> B.ByteString -> [Link] -> Integer -> B.ByteString -> IO ()
runCase (Case owner used workers events setup stopDone firstDone badDone secondDone finalDone drainDone closeEntered closeRelease)
 originalD stopBudget rootPath identity pins imagePath links size digest = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 remainingMicros originalD >>= check "original startup D live" . (>0)
 qaNestedLeaseHook $ \stage -> do
  atomicModifyIORef' events (\xs -> (stage:xs,()))
  if stage == "published-proc" then ioError (userError "QA scope abort after actual published duplicates")
  else if stage == "closed-root" then putMVar closeEntered () >> readMVar closeRelease
  else pure ()
 start workers setup [originalD] $ do
  result <- withPersistentBoundNestedStartup owner (startBudgetFromDeadline originalD) $ \_ _ scope -> do
   attempted <- runPersistentBoundImage scope rootPath identity pins imagePath links size digest UiImage
   case attempted of
    Left _ -> pure (Left StartupAdmissionUnknown :: Either StartupAdmissionFailure ())
    Right (Left _) -> pure (Left StartupAdmissionUnknown :: Either StartupAdmissionFailure ())
    Right (Right _) -> ioError (userError "unexpected preparation past controlled abort")
  check "no session retirement receipt from aborted preparation" (result==Left StartupAdmissionUnknown)
 restore $ await [originalD] "real private scope unwound" setup
 published <- reverse <$> readIORef events
 check "both actual duplicate slots published once inside admitted steps before abort" (published==["published-root","published-proc"])
 start workers stopDone [originalD] (requestSessionStop owner stopBudget)
 stopped <- restore $ awaitStop originalD owner stopDone
 check "quarantined owner stop remains uncertain" (stopped==StopUncertain CleanupUncertain)
 selected <- tryPersistentStopDeadline owner
 stopD <- case selected of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "first StopD unavailable; retain guardian")
 remainingMicros stopD >>= check "actual first StopD still live" . (>0)
 start workers firstDone [originalD,stopD] (closeNextPersistentNested owner Nothing)
 -- QA requests the actual same-owner drain primitive while the actual
 -- close reservation is active; source has not yet proved this schedule can
 -- arise from a production lifecycle. No grant or synthetic waiter is made.
 waitSignal [originalD,stopD] "real root close after syscall" closeEntered
 start workers drainDone [originalD,stopD] (qaNestedDrain owner)
 awaitRegistered [originalD,stopD] owner
 pending <- tryReadMVar firstDone
 check "physical close receipt remains pending while drain waits" (case pending of Nothing -> True; _ -> False)
 putMVar closeRelease ()
 first <- restore $ await [originalD,stopD] "first actual nested close" firstDone
 receipt <- case first of
  Right (NestedPartClosed token) -> pure token
  _ -> ioError (userError "first selected physical close did not return successful receipt")
 restore $ await [originalD,stopD] "actual registered drain waiter" drainDone
 firstEvents <- reverse <$> readIORef events
 check "only real root-lease close entered" (firstEvents==["published-root","published-proc","closed-root"])
 -- Missing receipt must refuse before touching the other actual slot.
 start workers badDone [originalD,stopD] (closeNextPersistentNested owner Nothing)
 bad <- restore $ await [originalD,stopD] "missing receipt refusal" badDone
 badEvents <- reverse <$> readIORef events
 check "no receipt, no new physical close" (case bad of Left CleanupUncertain -> badEvents==firstEvents; _ -> False)
 start workers secondDone [originalD,stopD] (closeNextPersistentNested owner (Just receipt))
 second <- restore $ await [originalD,stopD] "other known-open lease close" secondDone
 next <- case second of
  Right (NestedPartClosed token) -> pure token
  _ -> ioError (userError "separate proc-lease did not return close receipt")
 secondEvents <- reverse <$> readIORef events
 check "different known-open part entered exactly once" (secondEvents==["published-root","published-proc","closed-root","closed-proc"])
 start workers finalDone [originalD,stopD] (closeNextPersistentNested owner (Just next))
 final <- restore $ await [originalD,stopD] "terminal nested observation" finalDone
 -- Setup abort retains the executable lease Building/Unknown even when both
 -- physical lease-close receipts are confirmed; this is not whole cleanup.
 check "retained executable cannot become successful cleanup" $ case final of
  Left CleanupUncertain -> True
  _ -> False
 after <- tryPersistentStopDeadline owner
 check "original first StopD remains latched" (after==selected)
 finalEvents <- reverse <$> readIORef events
 check "no uncertain part replay" (finalEvents==secondEvents)
-- This does not accept whole owner, native, provider or GUI cleanup.
