-- PREPARATION DRAFT. Root may compile only after independently integrating
-- the reviewed EngineCutoff helper and importing that exact source in test.
-- Deterministic clock seam tests the post-RPC crossing, not kernel timing,
-- real authentication, cleanup, or native window behavior. Never run here.
module Main (main) where

import Control.Exception (IOException, try)
import Control.Monad (unless)
import Data.IORef (newIORef, readIORef, writeIORef, modifyIORef')
import Warlock.Ui.EngineCutoff (localStop, localRemaining)

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))

main :: IO ()
main = do
  left <- newIORef 1100000
  calls <- newIORef (0 :: Int)
  let sample = readIORef left
      crossesStop = do modifyIORef' calls (+1); writeIORef left 750000; pure False
      crossesRemaining = do modifyIORef' calls (+1); writeIORef left 750000; pure 1100000
  stopped <- localStop sample crossesStop
  check "remote false across 1s must stop" stopped
  c1 <- readIORef calls
  check "crossing really performed one RPC" (c1 == 1)
  writeIORef left 1100000
  value <- localRemaining sample crossesRemaining
  check "crossing returns post-RPC upper bound" (value == 750000)
  c2 <- readIORef calls
  check "remaining crossing performed one RPC" (c2 == 2)

  writeIORef left 1000000
  noCall <- localStop sample (ioError (userError "RPC at cutoff"))
  check "exact 1s stops locally" noCall
  low <- localRemaining sample (ioError (userError "RPC below cutoff"))
  check "exact 1s remaining stays local" (low == 1000000)

  writeIORef left 1500000
  fast <- localStop sample (pure False)
  check "valid fast remote false proceeds" (not fast)
  quickValue <- localRemaining sample (pure 1200000)
  check "valid remote smaller bound retained" (quickValue == 1200000)
  externalStop <- localStop sample (pure True)
  check "remote stop still respected" externalStop

  -- Witness an outstanding caller-level gap: WebKit reads stop first, then
  -- remaining. Even with the helper, remaining can cross D-1s after the stop
  -- sample, and WebKit's present 500ms threshold would allow an iteration.
  writeIORef left 1500000
  firstStop <- localStop sample (pure False)
  afterRemaining <- localRemaining sample (writeIORef left 750000 >> pure 1500000)
  check "separate stop/remaining exposes caller race" (not firstStop && afterRemaining > 500000)
  rechecked <- localStop sample (pure False)
  check "local recheck observes crossed boundary" rechecked

  writeIORef left 1500000
  failure <- try (localStop sample (ioError (userError "RPC uncertain"))) :: IO (Either IOException Bool)
  check "RPC failure is not rewritten into success" (case failure of Left _ -> True; Right _ -> False)

-- Root must additionally exercise actual EngineEntrypoint/remote RPC using a
-- synchronized peer that sends a valid response after the local 1s crossing
-- but before the broker 500ms cutoff; compare valid fast response, D unchanged,
-- remote failure and a separate external watchdog. No synthetic fixture is a
-- receipt for real peer identity, native cleanup, or original scenario success.
