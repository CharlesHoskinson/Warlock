{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY, UNEXECUTED. Exercises the new preowned caller, not the old
-- unborrowed route. Caller roots Probe and exact resolver-supplied HeldExecutable
-- before return and provides an independent guardian for every possible child.
-- Requires held-document BORROW_QA, process OWNER_QA/BORROW_QA, the held-gate
-- contention hook and qaHoldPersistentStopGate. Never ship these seams.
module PreownedStopGateBusyControls (Probe, newProbe, runStopGateBusy) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, SessionExit(..), newPersistentOwner, persistentHeldNoInput,
  startBudgetAfter, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook, qaHoldPersistentStopGate)
import Warlock.Platform.Executable (HeldExecutable, qaHoldHeldGate, qaHeldBorrowCount)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe HeldExecutable))
 (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException ())) (MVar (Either SomeException ())) (MVar Result)
 (IORef Int) (IORef Bool)

newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("preowned stop gate: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 3000000 action >>= maybe (ioError (userError (label ++ ": keep Probe and guardian"))) pure
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure

runStopGateBusy :: Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runStopGateBusy (Probe owner held heldTid stopTid ownerTid heldEntered heldUnlock stopEntered stopUnlock busy heldDone stopDone ownerDone spawnCount used) supply = mask $ \restore -> do
 first <- atomicModifyIORef' used (\old -> (True,not old))
 check "single-use probe" first
 let hook stage = case stage of
      "qa-held-borrow-gate-blocked" -> void (tryPutMVar busy ())
      "persistent-before-spawn" -> atomicModifyIORef' spawnCount (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar heldUnlock ())
      void (tryPutMVar stopUnlock ())
      let waitOne ref done = do
           tid <- readIORef ref
           case tid of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
      waitOne heldTid heldDone
      waitOne stopTid stopDone
      waitOne ownerTid ownerDone
     run = do
      executable <- restore (supply owner)
      writeIORef held (Just executable)
      selection <- need (persistentHeldNoInput executable [] [("LANG","C"),("LC_ALL","C")])
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldHeldGate executable (putMVar heldEntered ()) (readMVar heldUnlock))) (putMVar heldDone)
       writeIORef heldTid (Just tid)
       pure tid
      within "held gate actually locked" (readMVar heldEntered)
      start <- startBudgetAfter 1000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop
         (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar ownerDone)
       writeIORef ownerTid (Just tid)
       pure tid
      within "preowned activation observed held gate busy" (readMVar busy)
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldPersistentStopGate owner (putMVar stopEntered ()) (readMVar stopUnlock))) (putMVar stopDone)
       writeIORef stopTid (Just tid)
       pure tid
      within "same owner stop gate actually locked" (readMVar stopEntered)
      result <- within "owner returns while both gates remain held" (readMVar ownerDone)
      attempts <- readIORef spawnCount
      check "busy gate cannot yield clean no-borrow retirement or spawn" $
       attempts == 0 && case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False
      void (tryPutMVar stopUnlock ())
      void (tryPutMVar heldUnlock ())
      st <- within "stop holder completion" (readMVar stopDone)
      ht <- within "held holder completion" (readMVar heldDone)
      count <- qaHeldBorrowCount executable
      check "real holders return and no borrow committed" $
       (case (st,ht) of (Right (),Right ()) -> True; _ -> False) && count == Just 0
 restore run `finally` finish
