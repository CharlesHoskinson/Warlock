{-# LANGUAGE ForeignFunctionInterface #-}
-- PREPARATION DRAFT ONLY, UNCOMPILED AND UNEXECUTED; not a product module.
-- Concrete acquisition fragment for integration INSIDE EngineCustody's owned
-- package. This is not an arbitrary descriptor executor or an acceptance.
-- EngineCustody remains the only child pidfd/signal/reaper. No GTK here.
--
-- Entry is after Owner adopted fd0, verified actual peer and bound three owned
-- origins, before Owner creates native/listener workers. Call while masked and
-- with actual one-OS-thread/SIGCHLD guard checked, preserving the absolute D.
-- This file does NOT implement fork, child-mode dispatch, framed SCM validation,
-- readiness, postexec capabilities, engine event forwarding or final reaping.
-- In particular, there is no fabricated ReadyEvidence in the return value.
module Warlock.Ui.PrepareEngineOwnedDraft
  ( Prepared, ImageFacts(..), prepareEngineOwned, releasePrepared ) where

#define _GNU_SOURCE
#include <fcntl.h>
#include <sys/socket.h>
#include <unistd.h>

import Control.Exception (SomeException, mask_, onException, try, throwIO)
import Control.Monad (unless, when)
import qualified Crypto.Hash.SHA256 as SHA256
import qualified Data.ByteString as B
import Data.IORef (IORef, newIORef, atomicModifyIORef', readIORef)
import Foreign (Ptr, alloca, mallocBytes, free, peekByteOff, pokeByteOff, poke)
import Foreign.C (CInt(..), CUInt(..))
import qualified Network.Socket as S
import System.IO (hClose)
import System.Posix.Files (FileStatus, getFdStatus, isRegularFile, deviceID, fileID, fileSize)
import System.Posix.IO (FdOption(CloseOnExec), OpenMode(ReadOnly), closeFd, createPipe,
                        defaultFileFlags, fdToHandle, openFd, setFdOption)
import System.Posix.Types (Fd(..))
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)

foreign import ccall unsafe "fcntl" c_fcntl :: CInt -> CInt -> CInt -> IO CInt
foreign import ccall unsafe "setsockopt" c_setsockopt :: CInt -> CInt -> CInt -> Ptr CInt -> CUInt -> IO CInt

-- Three raw slots are preallocated by this owner. -1 means not owned. Every
-- acquired descriptor is written to its designated slot immediately; it is
-- NEVER wrapped in a managed Socket, Handle or ForeignPtr. Its eventual close
-- is exactly once, by withdrawing the slot before the close. On close error it
-- is permanently uncertain and must not be retried by numeric fd.
data ImageFacts = ImageFacts !Integer !Integer !Integer !B.ByteString deriving (Eq,Show)
data Prepared = Prepared
  { pendingSlots :: !(Ptr ())
  , heldSelf :: !(IORef (Maybe Fd))
  , brokerSocket :: !(IORef (Maybe S.Socket))
  , childSocket :: !(IORef (Maybe S.Socket))
  , lifeRead :: !(IORef (Maybe Fd))
  , lifeWrite :: !(IORef (Maybe Fd))
  , heldImageFacts :: !ImageFacts
  , originalDeadline :: !AdmissionDeadline
  }

slotSize :: Int
slotSize = #{size int}

-- Only this fixed set of roles is representable; no caller-provided FD map.
slotCount :: Int
slotCount = 3

putSlot :: Ptr () -> Int -> CInt -> IO ()
putSlot slots index fd = pokeByteOff slots (index * slotSize) fd
getSlot :: Ptr () -> Int -> IO CInt
getSlot slots index = peekByteOff slots (index * slotSize)

require :: Bool -> String -> IO ()
require b message = unless b (ioError (userError message))

-- A close attempt irrevocably withdraws a cell even if close reports an error.
-- This prevents unsafe numeric-FD retry; the caller must mark custody unknown.
withdraw :: IORef (Maybe a) -> IO (Maybe a)
withdraw cell = atomicModifyIORef' cell (\old -> (Nothing,old))

closeCell :: (a -> IO ()) -> IORef (Maybe a) -> IO (Either SomeException ())
closeCell close cell = do
  owned <- withdraw cell
  case owned of Nothing -> pure (Right ()); Just value -> try (close value)

closeRawSlot :: Ptr () -> Int -> IO (Either SomeException ())
closeRawSlot slots index = do
  fd <- getSlot slots index
  if fd < 0 then pure (Right ()) else do
    putSlot slots index (-1)
    try (closeFd (Fd fd))

-- This routine NEVER calls waitpid or sends signals: it cleans only the
-- acquisition phase or descriptors whose sole custody has been settled by
-- EngineCustody. It is NOT safe to call while fork child ownership is unknown.
-- Repeated calls on already released/free slots are forbidden; EngineCustody
-- owns the Prepared once. Failure retains a failed/unknown cleanup result.
releasePrepared :: Prepared -> IO (Either SomeException ())
releasePrepared p = mask_ $ do
  raw <- mapM (closeRawSlot (pendingSlots p)) [0..slotCount-1]
  cc <- closeCell S.close (childSocket p)
  bc <- closeCell S.close (brokerSocket p)
  lr <- closeCell closeFd (lifeRead p)
  lw <- closeCell closeFd (lifeWrite p)
  held <- closeCell closeFd (heldSelf p)
  free (pendingSlots p)
  case [err | Left err <- raw ++ [cc,bc,lr,lw,held]] of
    [] -> pure (Right ())
    err:_ -> pure (Left err)

-- Verify a *held* self descriptor's device/inode/size and SHA256 from its own
-- duplicate, NOT from a child assertion. A finite ELF image limit bounds memory.
-- Concurrent writes/in-place mutation, proc mount identity and source/build
-- provenance still require independent verification at ready and retirement.
sameFile :: FileStatus -> FileStatus -> Bool
sameFile a b = deviceID a == deviceID b && fileID a == fileID b && fileSize a == fileSize b

hashHeld :: Fd -> IO ImageFacts
hashHeld fd@(Fd number) = do
  before <- getFdStatus fd
  let size = toInteger (fileSize before)
  require (isRegularFile before && size > 0 && size <= 268435456) "held ELF size/type refused"
  duplicate <- c_fcntl number #{const F_DUPFD_CLOEXEC} 3
  require (duplicate >= 3) "hash duplicate failed"
  -- Ownership transfers exactly once from the duplicate fd to Handle. The
  -- Handle is CLOSED BEFORE FORK; it does not own any raw child role duplicate.
  handle <- fdToHandle (Fd duplicate) `onException` closeFd (Fd duplicate)
  bytes <- B.hGet handle (fromInteger size + 1) `onException` hClose handle
  hClose handle
  after <- getFdStatus fd
  require (sameFile before after && toInteger (B.length bytes) == size) "held ELF changed/short read"
  require (B.take 4 bytes == B.pack [0x7f,0x45,0x4c,0x46]) "held image is not ELF"
  pure (ImageFacts (toInteger (deviceID before)) (toInteger (fileID before)) size (SHA256.hash bytes))

-- Record F_DUPFD_CLOEXEC result before any fstat, allocation or subsequent
-- duplicate. The mask plus unsafe FFI narrows the acquisition/publication gap;
-- actual Haskell synchronous exceptions, RTS behavior, preexisting stale
-- finalizers and no foreign concurrent close remain mandatory review gates.
duplicateRole :: Ptr () -> Int -> CInt -> IO ()
duplicateRole slots index source = do
  duplicate <- c_fcntl source #{const F_DUPFD_CLOEXEC} 3
  require (duplicate >= 3) "engine fixed-role duplicate failed"
  putSlot slots index duplicate

enableCredentials :: S.Socket -> IO ()
enableCredentials socket = S.withFdSocket socket $ \fd -> alloca $ \value -> do
  poke value (1 :: CInt)
  rc <- c_setsockopt fd #{const SOL_SOCKET} #{const SO_PASSCRED} value (fromIntegral #{size int})
  require (rc == 0) "engine SO_PASSCRED unavailable"

-- Both socket endpoints and both pipe endpoints are ordinary parent-owned
-- resources. All get CLOEXEC before fork. A copied child holds the lifeline
-- writer UNTIL exec: the child pre-exec poll therefore cannot prove the
-- parent survived the fork/PDEATHSIG race. Engine FIRST postexec admission must
-- rearm/check PDEATHSIG and poll the lifeline, then monitor it continuously.
--
-- IMPORTANT: EngineCustody must allocate `slots` and publish all EMPTY resource
-- cells into its existing pending ledger BEFORE calling this, rather than use
-- this illustrative standalone constructor without that outer owner. Socket and
-- createPipe acquisition also need actual exception-publication review. A raw
-- fd returned by the kernel but not yet registered cannot be safely forgotten.
prepareEngineOwned :: AdmissionDeadline -> IO Prepared
prepareEngineOwned deadline = mask_ $ do
  left <- remainingMicros deadline
  require (left > 500000) "engine preparation deadline"
  slots <- mallocBytes (slotCount * slotSize)
  mapM_ (\i -> putSlot slots i (-1)) [0..slotCount-1]
  selfCell <- newIORef Nothing
  brokerCell <- newIORef Nothing
  childCell <- newIORef Nothing
  lifeReadCell <- newIORef Nothing
  lifeWriteCell <- newIORef Nothing
  -- Temporary initial facts cannot be published as a valid Prepared; only
  -- constructing the final record after real hash succeeds permits return.
  let cleanup = do
        raw <- mapM (closeRawSlot slots) [0..slotCount-1]
        cc <- closeCell S.close childCell
        bc <- closeCell S.close brokerCell
        lr <- closeCell closeFd lifeReadCell
        lw <- closeCell closeFd lifeWriteCell
        self <- closeCell closeFd selfCell
        free slots
        case [err | Left err <- raw ++ [cc,bc,lr,lw,self]] of
          [] -> pure ()
          err:_ -> throwIO err
      register cell value = atomicModifyIORef' cell (\_ -> (Just value,()))
  (do
    -- /proc/self/exe is a kernel magic link, so O_NOFOLLOW must NOT be applied
    -- to this final component. Verify trusted procfs and held inode separately;
    -- retain the open file through fork and compare to the real owner image.
    image <- openFd "/proc/self/exe" ReadOnly defaultFileFlags
    register selfCell image
    setFdOption image CloseOnExec True
    facts <- hashHeld image
    (broker,child) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
    register brokerCell broker
    register childCell child
    S.withFdSocket broker (\fd -> setFdOption (Fd fd) CloseOnExec True)
    S.withFdSocket child (\fd -> setFdOption (Fd fd) CloseOnExec True)
    enableCredentials broker
    (reader,writer) <- createPipe
    register lifeReadCell reader
    register lifeWriteCell writer
    setFdOption reader CloseOnExec True
    setFdOption writer CloseOnExec True
    let Fd imageNumber = image
        Fd lifeNumber = reader
    duplicateRole slots 0 imageNumber
    S.withFdSocket child (duplicateRole slots 1)
    duplicateRole slots 2 lifeNumber
    values <- mapM (getSlot slots) [0..slotCount-1]
    require (all (>=3) values && length values == 3 && length (unique values) == 3) "engine roles invalid"
    -- Validate raw duplicates against held source stat/identity and verify
    -- socket type and pipe read-end here in the production adaptation. That
    -- actual check is MISSING in this fragment, so do not integrate as-is.
    remaining <- remainingMicros deadline
    require (remaining > 0) "engine preparation deadline"
    pure (Prepared slots selfCell brokerCell childCell lifeReadCell lifeWriteCell facts deadline))
    `onException` cleanup
  where
    unique [] = []
    unique (x:xs) = x : unique (filter (/= x) xs)

-- Remaining mandatory work: real EngineCustody pending publication before ALL
-- acquisitions; verify procfs and selected-image identity/hash against backend;
-- validate duplicates with fstat/socket and pipe access modes; allocate and pin
-- engine-only argv/envp, empty/proc/root strings, poll and capability buffers,
-- validated cap_last_cap; implement phase-state transfer on fork, pidfd and
-- exactly-once cleanup; strong per-fragment SCM credential and PID/birth/image/
-- namespace readiness; postexec lifeline and cap proofs under unchanged D.
-- No tests, compiler, VM, native or model execution performed for this draft.
