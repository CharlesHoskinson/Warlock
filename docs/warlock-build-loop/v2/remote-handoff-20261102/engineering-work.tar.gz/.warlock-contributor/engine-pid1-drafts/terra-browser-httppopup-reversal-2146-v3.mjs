// Proposed UNRUN regression for the actual compiled HttpPopup / UiHttp route.
// Root must use a fresh isolated real-browser page, bind the full source and
// artifact tuple, and intercept every /events and /actions request with no
// network/native-host passthrough. The browser inputs below are synthetic;
// this is not physical input, real IME/AT, compositor presentation or latency.
//
// Harness: assertSourceIdentity(hashes); assertNetworkIsolation();
// deliverPresentation(frame) fulfills the actual pending GET /events with the
// valid presentation gateway; actions() returns captured POST JSON bodies;
// waitForActionCount(n) waits for actual intercepted POST; respondAction(i,204,'')
// fulfills that POST; settleElm() drains bounded browser/Elm scheduling only;
// evaluate/until/check provide bounded DOM controls/assertions and raw evidence.
// A controlled injected frame is not proof that the backend produced it.
// Candidate-specific literal event sequence for Sol patch 7793cb2e.
// Popup baseline ebb12fa8 is expected RED; postimage 7126b495 is proposed.
// An explicit predeclared hash is required; full closure/artifact must be bound.
export async function httpPopupLatestInputReversal2146({assertSourceIdentity,assertNetworkIsolation,deliverPresentation,actions,waitForActionCount,respondAction,settleElm,evaluate,until,check,expectedPopupSha256}) {
  const permitted=['ebb12fa83349dcfbdc4e7f67f63daf3738d25f25960d6541c0f432abacad85b1','7126b4950eaf8dbebf1aeb72169ea54b35f54fdec2364aa81cc2de42a239cb9e'];
  if(!permitted.includes(expectedPopupSha256)) throw Error('Explicit pinned baseline or reviewed candidate Popup hash required');
  await assertSourceIdentity({
    'implementation/warlock/src/HttpPopup.elm':'4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354',
    'implementation/warlock/src/UiHttp.elm':'3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419',
    'implementation/warlock/src/Presentation.elm':'745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396',
    'implementation/warlock/src/Popup.elm':expectedPopupSha256,
    'implementation/warlock/src/SurfaceSnapshot.elm':'9c85362ec27496438eb5a159e2c162704ef2922ba41df172a17e81787203913a',
    'implementation/warlock/src/SurfaceRenderer.elm':'58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e'
  });
  await assertNetworkIsolation();
  const control=(id,domId,label,ariaLabel)=>({id,domId,label,ariaLabel,detail:'',enabled:true});
  const frame=(publication,query,status)=>({surfaceProtocol:2,publication,lease:'7',mode:'applications',status,bar:[],popup:[
    control('control:search','launcher-search',query,'Search applications'),
    control('control:refresh','refresh-applications','Refresh','Refresh applications'),
    control('entry:org.example.Foot','entry-foot','Foot','Open Foot')
  ]});
  const field=()=>evaluate(`(() => {const root=document.querySelector('.surface-popup'),f=root?.querySelector('[data-surface-field="control:search"]');return {publication:root?.dataset.publication,lease:root?.dataset.lease,value:f?.value,focus:document.hasFocus()&&document.activeElement===f,sameField:f===window.heldSearch,status:root?.querySelector('[role="status"]')?.textContent};})()`);
  const query=(publication,value)=>({surfaceProtocol:2,kind:'surface-query',surface:'popup',publication,lease:'7',id:'control:search',query:value});
  const same=(left,right)=>JSON.stringify(left)===JSON.stringify(right);
  await deliverPresentation(frame('1','','Type to search applications.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='1'`);
  await evaluate(`(() => {window.heldSearch=document.querySelector('[data-surface-field="control:search"]');window.heldSearch.focus();})()`);
  await evaluate(`(() => {const f=window.heldSearch;f.value='f';f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'f'}));})()`);
  await waitForActionCount(1);
  check('first edit sends exact f query',same((await actions())[0],query('1','f')),await actions());
  await respondAction(0,204,''); // Delivery is not authoritative presentation.
  await evaluate(`(() => {const f=window.heldSearch;f.value='';f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'deleteContentBackward',data:null}));})()`);
  await settleElm();
  let seen=await field();
  check('reversal retains latest empty draft as unresolved while f may arrive',seen.value===''&&seen.focus&&seen.sameField&&seen.status==='Results may not match current input. Previous: Type to search applications.',seen);
  await waitForActionCount(2);
  check('reversal emits exact empty query at publication one',same(await actions(),[query('1','f'),query('1','')]),await actions());
  await deliverPresentation(frame('2','f','Choose a matching application.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='2'`);
  await settleElm();
  seen=await field();
  check('older f projection cannot overwrite the later empty edit',seen.publication==='2'&&seen.lease==='7'&&seen.value===''&&seen.focus&&seen.sameField&&seen.status==='Results may not match current input. Previous: Choose a matching application.',seen);
  // The old-scope empty POST is still active: its 204 is transport completion
  // only, not a policy receipt. It permits the queued rebase to leave UiHttp.
  await respondAction(1,204,'');
  await waitForActionCount(3);
  const expectedWires=[query('1','f'),query('1',''),query('2','')];
  check('exact FIFO carries current-scope empty query once',same(await actions(),expectedWires),await actions());
  await respondAction(2,204,'');
  await deliverPresentation(frame('3','','Type to search applications.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='3'`);
  await settleElm();
  seen=await field();
  check('matching empty projection restores current status without replay',seen.publication==='3'&&seen.lease==='7'&&seen.value===''&&seen.focus&&seen.sameField&&seen.status==='Type to search applications.'&&same(await actions(),expectedWires),seen);
}
