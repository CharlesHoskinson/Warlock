module SiteMain exposing
    ( AppearanceTheme(..)
    , BetaRunSpec
    , BetaWalkthroughStep(..)
    , CueFacts
    , FocusTarget(..)
    , Model
    , MotionMode(..)
    , Msg(..)
    , MvpEvidenceSpec
    , MvpMatrixRow
    , OutcomeSample(..)
    , ScenarioSpec
    , SurfaceCategory(..)
    , SurfaceId(..)
    , SurfaceSpec
    , WalkthroughStepSpec
    , allScenarios
    , allSurfaces
    , betaRunTracks
    , decodeEscapeKey
    , decodeWalkthroughTabKey
    , decodeWorkbenchTabKey
    , init
    , initialModel
    , main
    , mvpEvidenceCards
    , mvpMatrixRows
    , scopeCards
    , stepSurface
    , stepWalkthrough
    , surfaceTabDomId
    , transition
    , update
    , view
    , viewDocument
    , walkthroughSteps
    , walkthroughTabDomId
    )

import Browser
import Browser.Dom as Dom
import Html exposing (Html)
import Html.Attributes as Attr
import Html.Events as Events
import Json.Decode as Decode
import Task


main : Program () Model Msg
main =
    Browser.element
        { init = init
        , view = view
        , update = update
        , subscriptions = \_ -> Sub.none
        }



-- MODEL (CSS-FREE ELM: PRESENTATION LIVES IN site/assets/shared/landing.css)


type AppearanceTheme
    = ThemeNight
    | ThemeDawn
    | ThemeHighContrast


type MotionMode
    = MotionStandard
    | MotionReduced


type SurfaceId
    = SurfaceTaskbar
    | SurfaceLauncher
    | SurfaceSwitcher
    | SurfaceTaskView
    | SurfaceSnap
    | SurfaceNotifications
    | SurfaceSettings
    | SurfaceFiles


type BetaWalkthroughStep
    = WalkSimulatedStage
    | WalkLivePositiveFoot
    | WalkLiveNegativeRefresh
    | WalkLifecycleAndBackendDiag


type SurfaceCategory
    = CategoryAll
    | CategoryWindows
    | CategoryAppsFiles
    | CategorySystem


type OutcomeSample
    = SampleObserved
    | SamplePending
    | SampleUnknown
    | SampleRefused


type FocusTarget
    = FocusWorkbenchTab SurfaceId
    | FocusWalkthroughTab BetaWalkthroughStep
    | FocusMobileMenuToggle


type alias CueFacts =
    { windowFocused : Bool
    , activeApplication : Bool
    , switcherCandidate : Bool
    }


type alias Model =
    { theme : AppearanceTheme
    , motion : MotionMode
    , mobileNavOpen : Bool
    , spotlight : SurfaceId
    , walkthroughStep : BetaWalkthroughStep
    , tabFocusSeq : Int
    , lastTabFocusMiss : Maybe String
    , category : SurfaceCategory
    , scenarioCategory : SurfaceCategory
    , cues : CueFacts
    , outcomeSample : OutcomeSample
    }


type Msg
    = SelectTheme AppearanceTheme
    | ToggleMotion
    | ToggleMobileNav
    | CloseMobileNav
    | EscapeMobileNav
    | SelectSpotlight SurfaceId
    | StepSpotlight Int
    | KeyboardStepSpotlight Int
    | KeyboardJumpSpotlight SurfaceId
    | SelectWalkthroughStep BetaWalkthroughStep
    | StepWalkthrough Int
    | KeyboardStepWalkthrough Int
    | KeyboardJumpWalkthrough BetaWalkthroughStep
    | FocusSettled Int FocusTarget (Result Dom.Error ())
    | SelectCategory SurfaceCategory
    | SelectScenarioCategory SurfaceCategory
    | ToggleWindowFocused
    | ToggleActiveApplication
    | ToggleSwitcherCandidate
    | SelectOutcomeSample OutcomeSample


initialModel : Model
initialModel =
    { theme = ThemeNight
    , motion = MotionStandard
    , mobileNavOpen = False
    , spotlight = SurfaceTaskbar
    , walkthroughStep = WalkSimulatedStage
    , tabFocusSeq = 0
    , lastTabFocusMiss = Nothing
    , category = CategoryAll
    , scenarioCategory = CategoryAll
    , cues =
        { windowFocused = True
        , activeApplication = True
        , switcherCandidate = False
        }
    , outcomeSample = SampleObserved
    }


init : () -> ( Model, Cmd Msg )
init _ =
    ( initialModel, Cmd.none )


update : Msg -> Model -> ( Model, Cmd Msg )
update msg currentModel =
    let
        ( nextModel, focusTargets ) =
            transition msg currentModel
    in
    ( nextModel
    , Cmd.batch
        (List.map
            (\target ->
                Task.attempt
                    (FocusSettled nextModel.tabFocusSeq target)
                    (Dom.focus (focusDomId target))
            )
            focusTargets
        )
    )


focusDomId : FocusTarget -> String
focusDomId target =
    case target of
        FocusWorkbenchTab surfaceId ->
            surfaceTabDomId surfaceId

        FocusWalkthroughTab stepId ->
            walkthroughTabDomId stepId

        FocusMobileMenuToggle ->
            "wl-home-nav-toggle"


focusExpectedInModel : FocusTarget -> Model -> Bool
focusExpectedInModel target currentModel =
    case target of
        FocusWorkbenchTab surfaceId ->
            currentModel.spotlight == surfaceId

        FocusWalkthroughTab stepId ->
            currentModel.walkthroughStep == stepId

        FocusMobileMenuToggle ->
            not currentModel.mobileNavOpen


transition : Msg -> Model -> ( Model, List FocusTarget )
transition msg currentModel =
    case msg of
        SelectTheme chosenTheme ->
            ( { currentModel | theme = chosenTheme }, [] )

        ToggleMotion ->
            let
                nextMotion =
                    case currentModel.motion of
                        MotionStandard ->
                            MotionReduced

                        MotionReduced ->
                            MotionStandard
            in
            ( { currentModel | motion = nextMotion }, [] )

        ToggleMobileNav ->
            ( { currentModel
                | mobileNavOpen = not currentModel.mobileNavOpen
                , tabFocusSeq = currentModel.tabFocusSeq + 1
              }
            , []
            )

        CloseMobileNav ->
            ( { currentModel
                | mobileNavOpen = False
                , tabFocusSeq = currentModel.tabFocusSeq + 1
              }
            , []
            )

        EscapeMobileNav ->
            if currentModel.mobileNavOpen then
                let
                    nextSeq =
                        currentModel.tabFocusSeq + 1
                in
                ( { currentModel
                    | mobileNavOpen = False
                    , tabFocusSeq = nextSeq
                    , lastTabFocusMiss = Nothing
                  }
                , [ FocusMobileMenuToggle ]
                )

            else
                ( currentModel, [] )

        SelectSpotlight surfaceId ->
            ( { currentModel
                | spotlight = surfaceId
                , tabFocusSeq = currentModel.tabFocusSeq + 1
                , lastTabFocusMiss = Nothing
              }
            , []
            )

        StepSpotlight delta ->
            ( { currentModel
                | spotlight = stepSurface delta currentModel.spotlight
                , tabFocusSeq = currentModel.tabFocusSeq + 1
                , lastTabFocusMiss = Nothing
              }
            , []
            )

        KeyboardStepSpotlight delta ->
            let
                targetSurface =
                    stepSurface delta currentModel.spotlight

                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | spotlight = targetSurface
                , tabFocusSeq = nextSeq
                , lastTabFocusMiss = Nothing
              }
            , [ FocusWorkbenchTab targetSurface ]
            )

        KeyboardJumpSpotlight targetSurface ->
            let
                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | spotlight = targetSurface
                , tabFocusSeq = nextSeq
                , lastTabFocusMiss = Nothing
              }
            , [ FocusWorkbenchTab targetSurface ]
            )

        SelectWalkthroughStep stepId ->
            ( { currentModel
                | walkthroughStep = stepId
                , tabFocusSeq = currentModel.tabFocusSeq + 1
                , lastTabFocusMiss = Nothing
              }
            , []
            )

        StepWalkthrough delta ->
            ( { currentModel
                | walkthroughStep = stepWalkthrough delta currentModel.walkthroughStep
                , tabFocusSeq = currentModel.tabFocusSeq + 1
                , lastTabFocusMiss = Nothing
              }
            , []
            )

        KeyboardStepWalkthrough delta ->
            let
                targetStep =
                    stepWalkthrough delta currentModel.walkthroughStep

                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | walkthroughStep = targetStep
                , tabFocusSeq = nextSeq
                , lastTabFocusMiss = Nothing
              }
            , [ FocusWalkthroughTab targetStep ]
            )

        KeyboardJumpWalkthrough targetStep ->
            let
                nextSeq =
                    currentModel.tabFocusSeq + 1
            in
            ( { currentModel
                | walkthroughStep = targetStep
                , tabFocusSeq = nextSeq
                , lastTabFocusMiss = Nothing
              }
            , [ FocusWalkthroughTab targetStep ]
            )

        FocusSettled seq target focusOutcome ->
            if seq /= currentModel.tabFocusSeq || not (focusExpectedInModel target currentModel) then
                ( currentModel, [] )

            else
                case focusOutcome of
                    Ok () ->
                        ( { currentModel | lastTabFocusMiss = Nothing }, [] )

                    Err (Dom.NotFound missingDomId) ->
                        ( { currentModel | lastTabFocusMiss = Just missingDomId }, [] )

        SelectCategory chosenCategory ->
            ( { currentModel | category = chosenCategory }, [] )

        SelectScenarioCategory chosenCategory ->
            ( { currentModel | scenarioCategory = chosenCategory }, [] )

        ToggleWindowFocused ->
            let
                prior =
                    currentModel.cues
            in
            ( { currentModel | cues = { prior | windowFocused = not prior.windowFocused } }
            , []
            )

        ToggleActiveApplication ->
            let
                prior =
                    currentModel.cues
            in
            ( { currentModel | cues = { prior | activeApplication = not prior.activeApplication } }
            , []
            )

        ToggleSwitcherCandidate ->
            let
                prior =
                    currentModel.cues
            in
            ( { currentModel | cues = { prior | switcherCandidate = not prior.switcherCandidate } }
            , []
            )

        SelectOutcomeSample sample ->
            ( { currentModel | outcomeSample = sample }, [] )



-- STRUCTURED CATALOG, WALKTHROUGH & SITE DATA


type alias SurfaceSpec =
    { surfaceId : SurfaceId
    , anchorId : String
    , label : String
    , heading : String
    , chord : String
    , category : SurfaceCategory
    , imageSrc : String
    , imageWidth : Int
    , imageHeight : Int
    , imageAlt : String
    , summary : String
    , elmAuthority : String
    , hostObservation : String
    , scenarioHref : String
    , scenarioCta : String
    , specHref : String
    }


type alias WalkthroughStepSpec =
    { step : BetaWalkthroughStep
    , slug : String
    , tabLabel : String
    , stepEyebrow : String
    , statusBadge : String
    , statusTone : String
    , heading : String
    , summary : String
    , enabledControls : List String
    , unavailableOperations : List String
    , evidenceNote : String
    , ctaLabel : String
    , ctaHref : String
    , secondaryLabel : String
    , secondaryHref : String
    }


type alias CardSpec =
    { eyebrow : String
    , title : String
    , body : String
    , detail : String
    }


type alias NavCardSpec =
    { title : String
    , body : String
    , href : String
    }


type alias DirectoryGroup =
    { heading : String
    , links : List ( String, String )
    }


walkSimulatedStageSpec : WalkthroughStepSpec
walkSimulatedStageSpec =
    { step = WalkSimulatedStage
    , slug = "simulated-stage"
    , tabLabel = "1 · Simulated stage (16)"
    , stepEyebrow = "Step 1 of 4 · Browser test drive vs live guest boundary"
    , statusBadge = "Runnable in browser · Simulated"
    , statusTone = "simulated"
    , heading = "Try all 16 Elm desktop scenarios on a deterministic simulated stage"
    , summary = "The browser test drive and its 22-step guided tour run Warlock's compiled Elm Main, Bar, and Popup bundles over seeded fixture windows. Use it to explore target taskbar, launcher, Alt-Tab, Task View, snap, Files, notifications, Settings, and recovery flows before touching a Linux VM."
    , enabledControls =
        [ "All 16 seeded scenarios (?scenario=taskbar through ?scenario=status-recovery) and the 22-step tour"
        , "Simulated taskbar grouping, window picker, Alt-Tab candidate ring, Task View transfer, and snap Apply"
        , "Simulated appearance draft + Save, Do Not Disturb toggles, Files quick access, and Refused/Unknown recovery specimen"
        ]
    , unavailableOperations =
        [ "Zero Wayland compositor, Hyprland IPC, layer-shell bar attachment, or Linux process launch"
        , "Window interiors are browser stage fixtures—never real client windows, OS IME composition, or assistive-technology proof"
        , "No desktop binary, AppImage, or Omarchy installer download exists (Get started distributes design tokens, fonts, and SVG marks only)"
        ]
    , evidenceNote = "Route: ./test-drive/index.html · Tour: ./test-drive/tour/steps.json (simulated browser fixtures never qualify native behavior)."
    , ctaLabel = "Open simulated test drive"
    , ctaHref = "./test-drive/index.html"
    , secondaryLabel = "Jump to 16 scenario cards"
    , secondaryHref = "#scenarios"
    }


walkthroughSteps : List WalkthroughStepSpec
walkthroughSteps =
    [ walkSimulatedStageSpec
    , { step = WalkLivePositiveFoot
      , slug = "live-positive-foot"
      , tabLabel = "2 · Live positive-foot capture"
      , stepEyebrow = "Step 2 of 4 · Actual Omarchy --application-only positive match"
      , statusBadge = "Observed UI · Read-only search only"
      , statusTone = "scoped"
      , heading = "What positive-foot.png actually enables vs disables in GTK4 / WebKitGTK 6"
      , summary = "Root-inspected Omarchy captures record two layouts of the same --application-only surface: fullscreen 1280x800 (typed-model-live-20261102, all 7 top-bar controls visible in frame) and 50/50 Hyprland-tiled 621x750 alongside preserved Foot pid 2095 (backend-private-diagnostics-20261102, where .surface-actions overflow-x:auto visibly shows Applications, Task View, and Switch windows before the separate status box without a static scroll cue while the 4 off-screen utilities remain disabled)."
      , enabledControls =
            [ "bar:applications (Applications top-bar button — active lacquer contour)"
            , "control:search (Search applications input — typed foot across 63 regular .desktop entries; 8 symlinks skipped)"
            , "control:close (labelled Windows — closes the Applications popup view only) and control:refresh (Refresh)"
            , "pin:foot.desktop (Pin Foot · Add to taskbar — solid enabled border in Surface.elm:317, unclicked in the 17-QMP search sequence)"
            ]
      , unavailableOperations =
            [ "6 top-bar openers disabled with dashed borders (Surface.elm:424): Task View (bar:overview), Switch windows (bar:switcher), Notifications (bar:notifications), Files (bar:files), System (bar:system), Settings (bar:settings)"
            , "4 popup launch/action controls disabled with dashed borders (Surface.elm:310-324, nativeOperations = [], HOSTSTOP2): Actions for Foot (jump:open:foot.desktop), Open Foot, Open Foot Server, Open Foot Client"
            , "Known UX/source gaps retained for review: Surface.elm:483 still displays 'Choose a matching application.' while Open Foot* is disabled; Bar and Popup duplicate status text; static 621px still proves neither off-screen reachability nor pointer/AT scroll"
            ]
      , evidenceNote = "Captures: typed-model-live-20261102/positive-foot.png (58313ebc, 1280x800) & backend-private-diagnostics-20261102/positive-foot.png (f4592ae9, 621x750 tiled)."
      , ctaLabel = "Inspect MVP evidence cards"
      , ctaHref = "#mvp-evidence"
      , secondaryLabel = "Try simulated Launcher"
      , secondaryHref = "./test-drive/index.html?scenario=launcher"
      }
    , { step = WalkLiveNegativeRefresh
      , slug = "live-negative-refresh"
      , tabLabel = "3 · Negative footz & Refresh"
      , stepEyebrow = "Step 3 of 4 · Query retention, Refresh click & transport-loss bounds"
      , statusBadge = "17 QMP inputs · No catalog receipt"
      , statusTone = "scoped"
      , heading = "Extending to footz clears stale rows and retains query text across Refresh"
      , summary = "Across 17 acknowledged guarded QMP inputs, appending z transitions the popup to 'No matching applications. Change your search or Refresh.' and preserves footz in the search field before and after clicking Refresh—without claiming a correlated backend catalog receipt, physical OS IME, or automatic HTTP reconnect."
      , enabledControls =
            [ "control:search retains visible 'footz' before and after acknowledged Refresh pointer click (negative-footz.png -> after-refresh-footz.png)"
            , "Popup.elm composition-cancel fix (a9f188f9) restores prior pending query intent on CPU/DOM replay"
            , "HttpPopup.elm (e814d56f) renders a labelled read-only #http-popup-retained-query field if HTTP transport stops"
            ]
      , unavailableOperations =
            [ "No correlated backend catalog-generation receipt is observed on live Refresh (catalogGenerationReceiptObserved = false)"
            , "No physical OS IME composition/cancel or screen-reader / assistive-technology verification in VM runs (physicalImeObserved = false)"
            , "No automatic reconnect, retry, or reload bootstrap: reloading GET /index.html resets Popup.initial over a drained /events queue (HTTP 204)"
            ]
      , evidenceNote = "Captures: negative-footz.png (4d7adf58 / 45fdb5bf) & after-refresh-footz.png (95b6524f / c99c360e)."
      , ctaLabel = "Try simulated Status & recovery"
      , ctaHref = "./test-drive/index.html?scenario=status-recovery"
      , secondaryLabel = "Read Status & recovery spec"
      , secondaryHref = "./components/status-recovery/index.html"
      }
    , { step = WalkLifecycleAndBackendDiag
      , slug = "lifecycle-backend-diagnostics"
      , tabLabel = "4 · Closed diagnostics & 28s bounds"
      , stepEyebrow = "Step 4 of 4 · Warlock/Backend.hs privacy diagnostics & open gates"
      , statusBadge = "18 / 242 EARS · Native unaccepted"
      , statusTone = "open"
      , heading = "Closed Backend diagnostics isolate selectedOperationSucceeded=false (exitCode 1) without leaking stderr"
      , summary = "Root's Backend privacy/diagnostics slice (ELM-DEL-017 partial on af1bf0efe: 345 reviewed inputs, 217 complete Haskell inputs, 10 suites, 64 normal commands, child exit 23 fixture, 32 ordinary logs clean of synthetic credential/draft/pixels markers, guest build 0) now reports closed attempt/retirement tags in live Omarchy without flipping failed lifecycles into acceptance."
      , enabledControls =
            [ "backend-diagnostics.json (130d1831): 6 of 7 Backend checks true (bootstrapExecuted, selectedCustodyAvailable, selectedLeaderExited, processCleanup, catalogCleanup, pinCleanup) & 3/3 retirements confirmed"
            , "Single Backend failure stage isolated: failureStages = [\"selectedOperationSucceeded\"], closed selectedOperationError = {code: \"unsuccessful\", exitCode: 1} on selectedPid 164093"
            , "Canonical source-bound ledger: 18 / 242 whole EARS (ELM-TEA-001 on bdeac7349, ELM-TEA-002, ELM-TEA-005) and 42 / 417 scenarios"
            ]
      , unavailableOperations =
            [ "Launcher still exits 1 at 28s (passed=false) and strict controller hits qaCleanupError = FileNotFoundError on retired cgroup (qaScopeInventoryConfirmedEmpty = false)"
            , "Historical typed-model-live-20261102 unforced launcherExit=1 (28.05s), cancel-query-20261101 forced pinned-guard exit -9 (27.88s), and warlock-ui-backend exited 1 remain retained"
            , "224 of 242 whole requirements and 375 of 417 scenarios remain OPEN (persistent Backend/trusted-pump deadlines, whole ELM-DEL-017, ELM-ARC-002, ELM-ARC-024, ELM-DEL-011, ELM-DEL-014, native/GUI/AT/IME/release)"
            ]
      , evidenceNote = "Evidence: docs/warlock-build-loop/v2/backend-private-diagnostics-20261102.json · backend-diagnostics.json (130d1831)."
      , ctaLabel = "Inspect genuine run & beta paths"
      , ctaHref = "#run-beta"
      , secondaryLabel = "Explore Elm + Haskell architecture"
      , secondaryHref = "./architecture/index.html"
      }
    ]


taskbarSurface : SurfaceSpec
taskbarSurface =
    { surfaceId = SurfaceTaskbar
    , anchorId = "taskbar"
    , label = "Taskbar"
    , heading = "Your apps, one bar away"
    , chord = "Super + 1-9"
    , category = CategoryWindows
    , imageSrc = "./assets/site/feature-taskbar.png"
    , imageWidth = 1600
    , imageHeight = 330
    , imageAlt = "The Warlock taskbar across the top of the desktop with pinned applications, Start, Task View and the tray"
    , summary = "Pinned and running applications share the top bar. A neutral pill marks running apps and turns lacquer red for the active application alongside Start, Task View, Alt-Tab, notifications, Files, System, and Settings."
    , elmAuthority = "Group ordering, primary action routing (activate, minimize, restore, or picker), active indicator projection, and accessible status text."
    , hostObservation = "Observed window families, per-output focus and minimized state, CAS pin-store revisions, and effect completion receipts."
    , scenarioHref = "./test-drive/index.html?scenario=taskbar"
    , scenarioCta = "Try the taskbar"
    , specHref = "./components/taskbar/index.html"
    }


allSurfaces : List SurfaceSpec
allSurfaces =
    [ taskbarSurface
    , { surfaceId = SurfaceLauncher
      , anchorId = "launcher"
      , label = "Launcher"
      , heading = "Search, then launch"
      , chord = "Super + Alt + Space"
      , category = CategoryAppsFiles
      , imageSrc = "./assets/site/feature-launcher.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "The Start-style launcher with its search field, application actions and launch tiles"
      , summary = "Open Applications, type a query with IME composition safety, and launch the matching entry. The top result exposes application actions and recent items while pinned apps reorder cleanly."
      , elmAuthority = "IME-safe search composition, deterministic ranking, bounded paging, compact metadata disclosure, and pin causality guards."
      , hostObservation = "Haskell catalog snapshots, durable pin-store revisions, and Submitted, Refused, or Unknown launch receipts distinct from window mapping."
      , scenarioHref = "./test-drive/index.html?scenario=launcher"
      , scenarioCta = "Try the launcher"
      , specHref = "./components/launcher/index.html"
      }
    , { surfaceId = SurfaceSwitcher
      , anchorId = "switcher"
      , label = "Alt-Tab"
      , heading = "Switch windows the way you expect"
      , chord = "Alt + Tab"
      , category = CategoryWindows
      , imageSrc = "./assets/site/feature-switcher.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "The Alt-Tab window switcher with the selected window highlighted"
      , summary = "Hold Alt and tap Tab to step through open windows. Corner candidate brackets mark the prospective window before you commit, and Escape leaves focus untouched."
      , elmAuthority = "Candidate traversal order, ARIA selection state, commit vs cancel transitions, and steady card geometry across live or fallback previews."
      , hostObservation = "Window incarnation identities, preview stream grants or fallbacks, and verified Hyprland focus change after commit."
      , scenarioHref = "./test-drive/index.html?scenario=switcher"
      , scenarioCta = "Try Alt-Tab"
      , specHref = "./components/window-switcher/index.html"
      }
    , { surfaceId = SurfaceTaskView
      , anchorId = "task-view"
      , label = "Task View"
      , heading = "Every desktop at a glance"
      , chord = "Task View"
      , category = CategoryWindows
      , imageSrc = "./assets/site/feature-task-view.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "Task View showing workspaces with their windows"
      , summary = "Inspect workspaces and their windows side by side, transfer a window to another desktop, or switch straight to an empty or populated workspace."
      , elmAuthority = "Workspace filter toggles, transfer destination selection, and generation-bound navigation intents."
      , hostObservation = "Observed workspace topology, monitor ownership, and post-command workspace or transfer verification."
      , scenarioHref = "./test-drive/index.html?scenario=task-view"
      , scenarioCta = "Try Task View"
      , specHref = "./components/task-view/index.html"
      }
    , { surfaceId = SurfaceSnap
      , anchorId = "snap"
      , label = "Snap layouts"
      , heading = "Snap into place"
      , chord = "Snap chooser"
      , category = CategoryWindows
      , imageSrc = "./assets/site/feature-snap.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "The snap layout chooser with half and quarter screen regions"
      , summary = "Choose a half or quarter of the screen from the snap chooser and apply deliberately. Warlock asks Hyprland to place the window and retains pre-snap bounds for clean restore."
      , elmAuthority = "Region selection state, explicit Apply confirmation, and separation of snapped state from maximized restore."
      , hostObservation = "Floating window eligibility checks, observed work-area geometry, and post-placement bounds confirmation."
      , scenarioHref = "./test-drive/index.html?scenario=snap"
      , scenarioCta = "Try snap layouts"
      , specHref = "./components/snap-layouts/index.html"
      }
    , { surfaceId = SurfaceNotifications
      , anchorId = "notifications"
      , label = "Notifications"
      , heading = "Stay in the loop"
      , chord = "Tray · Bell"
      , category = CategorySystem
      , imageSrc = "./assets/site/feature-notifications.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "The notification center with live notifications, their actions and do not disturb"
      , summary = "Live notifications preserve their producer actions, bounded history keeps what you missed, and Do Not Disturb holds interruptions while you focus."
      , elmAuthority = "History presentation, Do Not Disturb toggle state, and single-surface accessible announcement routing."
      , hostObservation = "Desktop notification service snapshots, action invocation receipts, and dismissal settlements."
      , scenarioHref = "./test-drive/index.html?scenario=notifications"
      , scenarioCta = "Try notifications"
      , specHref = "./components/notifications/index.html"
      }
    , { surfaceId = SurfaceSettings
      , anchorId = "settings"
      , label = "Settings"
      , heading = "Make it yours"
      , chord = "Explicit Save"
      , category = CategorySystem
      , imageSrc = "./assets/site/feature-settings.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "Warlock Settings with theme, text size, motion and effects choices"
      , summary = "Review Night, Dawn, or High contrast, 100-200% text size, reduced motion, and portal effect tiers as a draft, then commit atomically with Save."
      , elmAuthority = "Draft vs committed appearance state, revision-bound Save proposals, and immediate reduced-motion precedence."
      , hostObservation = "Atomic preference writes, storage revision receipts, and system reduced-motion observations."
      , scenarioHref = "./test-drive/index.html?scenario=settings"
      , scenarioCta = "Try Settings"
      , specHref = "./components/appearance-settings/index.html"
      }
    , { surfaceId = SurfaceFiles
      , anchorId = "files"
      , label = "Files"
      , heading = "Your folders, one click away"
      , chord = "Tray · Files"
      , category = CategoryAppsFiles
      , imageSrc = "./assets/site/feature-files.png"
      , imageWidth = 1000
      , imageHeight = 620
      , imageAlt = "Files with quick-access tiles for Home, Recent and the collections"
      , summary = "Open Home, Recent, Downloads, Documents, or collections from quick-access tiles, or submit a folder path for checked handoff to Omarchy's Files application."
      , elmAuthority = "Quick-access tile controls, path input state, and non-replaying outcome feedback when a path is refused or unconfirmed."
      , hostObservation = "Quint-specified file operation checks, validated path resolution, and peer launch receipts."
      , scenarioHref = "./test-drive/index.html?scenario=files"
      , scenarioCta = "Try Files"
      , specHref = "./components/files/index.html"
      }
    ]


type alias ScenarioSpec =
    { slug : String
    , title : String
    , chord : String
    , category : SurfaceCategory
    , summary : String
    , specHref : String
    }


type alias MvpMatrixRow =
    { rowId : String
    , track : String
    , statusBadge : String
    , statusTone : String
    , provenToday : String
    , openOrExcluded : String
    }


type alias MvpEvidenceSpec =
    { cardId : String
    , eyebrow : String
    , badge : String
    , badgeTone : String
    , title : String
    , observed : String
    , nonClaim : String
    , artifactRef : String
    }


type alias BetaRunSpec =
    { cardId : String
    , eyebrow : String
    , badge : String
    , badgeTone : String
    , title : String
    , summary : String
    , commandOrRef : String
    , limits : String
    , linkLabel : String
    , linkHref : String
    }


scopeCards : List CardSpec
scopeCards =
    [ { eyebrow = "Browser test drive · Simulated stage"
      , title = "16 interactive Elm scenarios on fixture desktop state"
      , body = "The browser test drive runs Warlock's compiled Elm surfaces (Main, Bar, and Popup) over a deterministic simulated stage. It is not a Wayland compositor or window manager; window interiors are browser fixtures—never Linux processes, OS IME, assistive technology, or native acceptance proof."
      , detail = "Route: ./test-drive/index.html (16 seeded scenarios · simulated)"
      }
    , { eyebrow = "No desktop binary download · Source-only beta"
      , title = "Design tokens download here; beta builds from source"
      , body = "No Omarchy package, binary archive, AppImage, or desktop installer is published yet. The Get started downloads section distributes Lacquer CSS/JSON tokens, licensed fonts, and brand SVG marks only; packaging and reversible rollback (ELM-DEL-011) remain OPEN."
      , detail = "Tokens/fonts only: ./get-started/index.html#downloads"
      }
    , { eyebrow = "Bounded read-only app search · Closed Backend diagnostics"
      , title = "Foot / Footz / Refresh UI & 6/7 Backend checks observed; exitCode 1, cgroup & exit -9 open"
      , body = "In guarded --application-only Omarchy trials (nativeOperations = []), 17 acknowledged QMP inputs typed foot, footz, and clicked Refresh across 63 regular desktop entries (8 symlinks skipped) while Task View, Switch windows, Notifications, Files, System, Settings, and Open Foot* launches stayed disabled. Root's Backend privacy/diagnostics run (backend-private-diagnostics-20261102, 345 reviewed inputs / 10 suites / 64 commands GREEN, 32 ordinary logs clean) confirmed 6/7 Backend checks and 3/3 retirements while isolating selectedOperationSucceeded=false (selectedOperationError code=unsuccessful, exitCode=1 on selectedPid 164093) alongside qaCleanupError=FileNotFoundError (qaScopeInventoryConfirmedEmpty=false), typed-model-live-20261102 unforced launcherExit=1 (28.05s), and historical cancel-query-20261101 forced exit -9 (27.88s)."
      , detail = "Evidence: backend-private-diagnostics-20261102 & typed-model-live-20261102 · HOSTSTOP2 & nativeOperations = []"
      }
    , { eyebrow = "Canonical ledger · 18 / 242 whole EARS · 42 / 417 scenarios"
      , title = "ELM-TEA-001 accepted; persistent native shell & release remain unaccepted"
      , body = "Eighteen whole original requirements (including ELM-TEA-001 typed model on immutable source bdeac7349, ELM-TEA-002 pure update, and ELM-TEA-005 narrow validated interop) and 42 scenarios hold source-bound acceptance at HEAD af1bf0efe (345 Haskell-profile inputs / 7,293 HTTP/DOM checks / 137 typed controls / 61 policy histories / 57 Quint runs). Exactly 224 whole requirements and 375 scenarios—including whole ELM-DEL-017, ELM-ARC-002, ELM-ARC-024, and ELM-DEL-014—remain OPEN."
      , detail = "Component, CPU, and Quint checks never imply native compositor or release acceptance"
      }
    ]


mvpMatrixRows : List MvpMatrixRow
mvpMatrixRows =
    [ { rowId = "wl-mvp-row-browser"
      , track = "Browser test drive (./test-drive/index.html)"
      , statusBadge = "Runnable now · Simulated"
      , statusTone = "simulated"
      , provenToday = "16 seeded interactive Elm scenarios (Main, Bar, and Popup) and 22-step guided tour over a deterministic simulated desktop stage."
      , openOrExcluded = "Simulated client fixtures only; never replaces a window manager or proves Wayland/Hyprland IPC, Linux processes, OS IME, assistive tech, or native latency."
      }
    , { rowId = "wl-mvp-row-contracts"
      , track = "CPU, Haskell privacy & Quint suites (HEAD af1bf0efe · source bdeac7349)"
      , statusBadge = "18 / 242 whole EARS · 42 / 417 scenarios"
      , statusTone = "scoped"
      , provenToday = "Source-bound whole-EARS verdicts (ELM-TEA-001 on bdeac7349; ELM-TEA-002; ELM-TEA-005), Backend closed failure/retirement diagnostics (345 reviewed inputs, 217 complete Haskell inputs, 10 suites, 64 normal commands, child exit 23 fixture, 32 ordinary logs clean of synthetic credential/draft/pixels markers), Popup composition-cancel restoration, and HttpPopup read-only transport-loss draft display (7,293 HTTP/DOM checks, 137 typed controls, 61 complete policy histories, 57 named Quint runs, 10,000 seed=20261101 traces)."
      , openOrExcluded = "Component, reducer, socket, and formal invariants only; whole ELM-DEL-017 credential-service scope, ELM-UI-005 whole closure, persistent Backend/trusted-pump deadlines, live WebKit reload bootstrap (GET /index.html leaves drained /events at 204), physical IME/AT, and native compositor acceptance remain open."
      }
    , { rowId = "wl-mvp-row-omarchy-vm"
      , track = "Guarded Omarchy --application-only read-only search trials"
      , statusBadge = "Failed 28s lifecycles retained (exitCode 1 / cgroup / exit -9)"
      , statusTone = "open"
      , provenToday = "17 acknowledged guarded QMP inputs completed Applications -> Search, typed foot then footz (No matching applications. Change your search or Refresh.), and clicked Refresh in GTK4 / WebKitGTK 6 alongside preserved Foot over 63 regular desktop entries (8 symlinks skipped) in fullscreen 1280x800 (typed-model-live-20261102) and 50/50 tiled 621x750 (backend-private-diagnostics-20261102, 6/7 Backend checks true & 3/3 retirements confirmed)."
      , openOrExcluded = "Not a complete window manager (6 top-bar openers and 4 Open Foot* / Actions controls disabled under nativeOperations = [] and HOSTSTOP2); no correlated catalog refresh receipt or physical IME; live Backend isolated selectedOperationSucceeded=false (code=unsuccessful, exitCode=1 on selectedPid 164093), launcherExit=1, qaCleanupError=FileNotFoundError (qaScopeInventoryConfirmedEmpty=false), historical forced exit -9 (27.88s / 28s), and warlock-ui-backend exited 1 retained; provider cleanup unqualified."
      }
    , { rowId = "wl-mvp-row-native-release"
      , track = "Persistent native Hyprland shell & packaged release"
      , statusBadge = "Unaccepted · Not released"
      , statusTone = "open"
      , provenToday = "Preserves all 242 original EARS requirements, 417 scenarios, literal latency deadlines, and stopped failure histories; homepage authored in CSS-free Elm (SiteMain.elm + landing.css)."
      , openOrExcluded = "No desktop binary download exists; 224 of 242 whole requirements and 375 of 417 scenarios remain OPEN, including persistent Haskell host lifecycle, ELM-ARC-002, ELM-ARC-024, ELM-DEL-011, ELM-DEL-014, native live previews, AT/IME, and hardware budgets."
      }
    ]


mvpEvidenceCards : List MvpEvidenceSpec
mvpEvidenceCards =
    [ { cardId = "wl-evidence-foot"
      , eyebrow = "Capture 1 · Positive catalog match (1280x800 & 621x750)"
      , badge = "Observed UI · Read-only"
      , badgeTone = "scoped"
      , title = "Typing foot lists Foot catalog entries while disabling launch & 6 top-bar openers"
      , observed = "Opening Applications -> Search and typing foot via guarded QMP renders active Applications alongside dashed disabled top-bar utilities (all 6 visible in 1280x800 fullscreen; Task View and Switch windows visible before separate status over overflow-x:auto in 621x750 tiled still), enabled Windows, Refresh, and Pin Foot (unclicked), plus dashed disabled Actions for Foot, Open Foot, Open Foot Server, and Open Foot Client across 63 regular .desktop files (8 symlinks skipped)."
      , nonClaim = "Not a window manager, app launcher, or verified pin write: Surface.elm:483 still displays 'Choose a matching application.' despite disabled Open Foot* rows, Pin Foot was not clicked, static 621px stills neither prove off-screen controls unreachable nor qualify pointer/AT scrolling, and nativeOperations = [] with HOSTSTOP2 excludes backend launch or window mutations."
      , artifactRef = "Evidence: backend-private-diagnostics-20261102/positive-foot.png (f4592ae9) · typed-model-live-20261102 (58313ebc)"
      }
    , { cardId = "wl-evidence-footz"
      , eyebrow = "Captures 2 & 3 · Negative match & Refresh click"
      , badge = "17 QMP inputs · No catalog receipt"
      , badgeTone = "scoped"
      , title = "Extending to footz and clicking Refresh preserves visible query text"
      , observed = "Typing z clears stale Foot rows to show 'No matching applications. Change your search or Refresh.' and retains footz in the search input before and after an acknowledged pointer click on Refresh."
      , nonClaim = "Unchanged visible text after Refresh proves UI non-loss on screen only—never a correlated backend catalog-generation receipt, physical OS IME composition/cancel, or assistive-technology output."
      , artifactRef = "Evidence: negative-footz.png (45fdb5bf / 4d7adf58) · after-refresh-footz.png (c99c360e / 95b6524f)"
      }
    , { cardId = "wl-evidence-lifecycle"
      , eyebrow = "Guest lifecycle & closed Backend diagnostics · 28s bound"
      , badge = "Failed lifecycles retained · exitCode 1, cgroup & exit -9"
      , badgeTone = "open"
      , title = "Closed Backend JSON isolates selectedOperationSucceeded=false (exitCode 1) alongside cgroup & exit -9 bounds"
      , observed = "In backend-private-diagnostics-20261102 (guestBuildExit=0, 32 ordinary logs clean of synthetic markers), backend-diagnostics.json (130d1831) confirmed 6/7 Backend checks true and 3/3 retirements confirmed while isolating failureStages=[\"selectedOperationSucceeded\"] and selectedOperationError={code:\"unsuccessful\", exitCode:1} on selectedPid 164093, alongside launcherExit=1, qaCleanupError=FileNotFoundError (qaScopeInventoryConfirmedEmpty=false), typed-model-live-20261102 (28.05s), and cancel-query-20261101 forced exit -9 at 27.88s (plus warlock-ui-backend exited 1)."
      , nonClaim = "Viewed screenshots and closed diagnostic isolation never flip passed=false, launcherExit=1, retired-cgroup FileNotFoundError, or historical exit -9 into a passing backend lifecycle, confirmed empty scope inventory, or native acceptance."
      , artifactRef = "Evidence: backend-diagnostics.json (130d1831) · live-journey.json (fecfe0f3) · typed-model-live-20261102 (4c2883e6)"
      }
    , { cardId = "wl-evidence-no-restart"
      , eyebrow = "Transport loss & reload · CPU/socket only"
      , badge = "No automatic reconnect or restart"
      , badgeTone = "open"
      , title = "Read-only draft retention is neither live restart nor reload recovery"
      , observed = "In CPU/DOM/Quint checks at HEAD af1bf0efe / source bdeac7349 (7,293 HTTP/DOM, 137 typed controls, 61 policy histories, 57 Quint runs), ELM-TEA-001 typed model is accepted, Popup cancellation restores prior pending intent, UiHttp retains typed Failure values, and HttpPopup renders a labelled read-only input preserving the last displayed or local draft query on HTTP failure."
      , nonClaim = "HttpPopup adds no automatic reconnect, action replay, or restart/reload button; normal VM search did not exercise transport loss, and reloading /index.html resets Popup.initial against a drained /events queue (204) without projection bootstrap."
      , artifactRef = "Source: Popup.elm (a9f188f9) · HttpPopup.elm (e814d56f) · Warlock/Backend.hs (641e06dc)"
      }
    ]


betaRunTracks : List BetaRunSpec
betaRunTracks =
    [ { cardId = "wl-run-browser"
      , eyebrow = "1 · Instant browser preview"
      , badge = "Runnable in browser · Simulated"
      , badgeTone = "simulated"
      , title = "Explore all 16 Elm scenarios without installing anything"
      , summary = "Runs Warlock's compiled Elm Main, Bar, and Popup bundles directly in your browser against deterministic seeded desktop state, including taskbar grouping, launcher search, Alt-Tab, Task View, snap chooser, notifications, Files, Settings, and status recovery."
      , commandOrRef = "Route: ./test-drive/index.html?scenario=launcher"
      , limits = "Simulated desktop stage and fixture client interiors only; zero Hyprland IPC, Linux process launch, Wayland layer-shell, or native window-manager qualification."
      , linkLabel = "Open simulated test drive"
      , linkHref = "./test-drive/index.html"
      }
    , { cardId = "wl-run-no-download"
      , eyebrow = "2 · Downloads & install truth"
      , badge = "No desktop binary · Design tokens only"
      , badgeTone = "open"
      , title = "No Omarchy package, installer, or prebuilt desktop binary exists yet"
      , summary = "Do not expect a downloadable desktop shell or window manager today. The Get started downloads section provides Lacquer CSS/JSON design tokens, Inter / Space Grotesk / JetBrains Mono web fonts, and Warlock SVG marks for documentation and styling integration only."
      , commandOrRef = "Assets: ./get-started/index.html#downloads (tokens, fonts, SVG marks)"
      , limits = "Omarchy packaging, reversible installation/rollback (ELM-DEL-011), reproducible release artifacts (ELM-DEL-014), and persistent main-desktop deployment remain unaccepted."
      , linkLabel = "Inspect token & font downloads"
      , linkHref = "./get-started/index.html#downloads"
      }
    , { cardId = "wl-run-source-check"
      , eyebrow = "3 · Repository checker & offline build"
      , badge = "Source checkout · Protected toolchain"
      , badgeTone = "scoped"
      , title = "Inspect the 242 / 417 ledger offline and build through Root custody"
      , summary = "From a Git checkout at HEAD af1bf0efe / source bdeac7349 (Python 3.9+ for offline contributor checks only; zero Python ships in product), inspect requirement dispositions with warlock.py. Optimized Elm 0.19.2 roots (7 JS roots / 3 HTML documents across 76 active modules) and the 6 GHC 9.6.7 / Cabal 3.12.1.0 Haskell packages compile offline under Root's serialized qa_run.py launcher."
      , commandOrRef = "python3 -B plugins/warlock-contributor/scripts/warlock.py status && docs/warlock/how-to/build-current-frontend.md"
      , limits = "Requires the pinned offline Elm package cache, local Haskell dependency closure, and serialized qa_run.py custody; frontend build custody is not GUI or native acceptance."
      , linkLabel = "Read contributor workflow"
      , linkHref = "./get-started/contributing/index.html"
      }
    , { cardId = "wl-run-omarchy-trial"
      , eyebrow = "4 · Bounded Omarchy read-only search trial"
      , badge = "Bounded D <= 28s --application-only trial"
      , badgeTone = "scoped"
      , title = "Run the bounded read-only application-search GTK4 / WebKitGTK 6 window on stock Omarchy"
      , summary = "Follow docs/warlock/how-to/run-omarchy-mvp.md: compile warlock-ui-owner and warlock-ui-backend offline (--offline, active-repositories: :none, dynamic GHC ABI) inside stock Omarchy against guest gtk4 and webkitgtk-6.0 (never copy host ELFs across ABIs), stage HttpMain/HttpBar/HttpPopup HTML into a fresh 0700 directory (O_DIRECTORY | O_NOFOLLOW, applicationAttachment: true, no WEBKIT_* or proxy env vars), and launch as a Hyprland-tiled client within the non-renewable D <= 28s (CLOCK_MONOTONIC <= 30s) bound."
      , commandOrRef = "Procedure: docs/warlock/how-to/run-omarchy-mvp.md (warlock-ui-backend + warlock-ui-owner)"
      , limits = "Read-only application catalog search only (not a complete window manager, verified native shell, or restartable daemon): nativeOperations = [] and HOSTSTOP2 keep 6 top-bar openers and 4 Open Foot* / Actions controls disabled; live 17-input QMP search proved neither a catalog receipt nor physical IME/restart recovery, and selectedOperationSucceeded=false (exitCode=1), launcherExit=1, retired-cgroup FileNotFoundError, historical forced guard stop exit -9 (27.88s), and warlock-ui-backend exited 1 remain open."
      , linkLabel = "Explore Elm + Haskell architecture"
      , linkHref = "./architecture/index.html"
      }
    ]


allScenarios : List ScenarioSpec
allScenarios =
    [ { slug = "taskbar", title = "Taskbar", chord = "Super + 1-9", category = CategoryWindows, summary = "Activate, minimize, or restore running application groups and inspect active vs running pills.", specHref = "./components/taskbar/index.html" }
    , { slug = "launcher", title = "Launcher", chord = "Super + Alt + Space", category = CategoryAppsFiles, summary = "Search applications with IME-safe input, inspect top actions, and submit launch intents.", specHref = "./components/launcher/index.html" }
    , { slug = "switcher", title = "Alt-Tab switcher", chord = "Alt + Tab", category = CategoryWindows, summary = "Step candidate brackets across open windows and commit focus or cancel cleanly with Escape.", specHref = "./components/window-switcher/index.html" }
    , { slug = "task-view", title = "Task View", chord = "Task View", category = CategoryWindows, summary = "Browse populated and empty workspaces side by side and reveal windows by desktop.", specHref = "./components/task-view/index.html" }
    , { slug = "transfer", title = "Workspace transfer", chord = "Move to desktop", category = CategoryWindows, summary = "Select a destination workspace for a window and verify observed transfer settlement.", specHref = "./components/workspace-transfer/index.html" }
    , { slug = "picker", title = "Window picker", chord = "Group flyout", category = CategoryWindows, summary = "Choose among multiple open windows belonging to the same taskbar application group.", specHref = "./components/window-picker/index.html" }
    , { slug = "preview-states", title = "Preview states", chord = "Live & fallback", category = CategoryWindows, summary = "Compare steady card geometry across live fixture thumbnails and honest fallback captions.", specHref = "./components/previews/index.html" }
    , { slug = "snap", title = "Snap layouts", chord = "Snap chooser", category = CategoryWindows, summary = "Select half or quarter regions, apply deliberately, and retain pre-snap restore geometry.", specHref = "./components/snap-layouts/index.html" }
    , { slug = "notifications", title = "Notifications", chord = "Tray · Bell", category = CategorySystem, summary = "Invoke producer actions, dismiss alerts, or hold interruptions with Do Not Disturb.", specHref = "./components/notifications/index.html" }
    , { slug = "settings", title = "Appearance settings", chord = "Explicit Save", category = CategorySystem, summary = "Draft Night, Dawn, or High contrast, 100-200% text scale, and reduced motion, then Save.", specHref = "./components/appearance-settings/index.html" }
    , { slug = "files", title = "Files quick access", chord = "Tray · Files", category = CategoryAppsFiles, summary = "Open Home, Recent, or collections and inspect validated folder-path handoff feedback.", specHref = "./components/files/index.html" }
    , { slug = "system", title = "System menu", chord = "Tray · System", category = CategorySystem, summary = "Adjust volume and quick toggles with admitted batch receipts and keyboard navigation.", specHref = "./components/system-menu/index.html" }
    , { slug = "window-menu", title = "Window menu", chord = "Title / bar menu", category = CategoryWindows, summary = "Run minimize, maximize, snap, or close window actions without conflating snapped restore.", specHref = "./components/window-menu/index.html" }
    , { slug = "confirmation", title = "Session confirmation", chord = "Confirm / Cancel", category = CategorySystem, summary = "Guard session-ending power or logout requests behind explicit confirmation dialogs.", specHref = "./components/dialogs/index.html" }
    , { slug = "application-actions", title = "Application actions", chord = "Jump list", category = CategoryAppsFiles, summary = "Launch a new window instance or recent item from an application's action menu.", specHref = "./components/application-actions/index.html" }
    , { slug = "status-recovery", title = "Status & recovery", chord = "Refresh facts", category = CategorySystem, summary = "Inspect Unknown or Refused receipts and refresh observed host status without blind retry.", specHref = "./components/status-recovery/index.html" }
    ]


quickScenarioSlugs : List String
quickScenarioSlugs =
    [ "taskbar", "launcher", "switcher", "task-view", "snap", "settings", "status-recovery" ]


principleCards : List ( String, String )
principleCards =
    [ ( "Show what is known", "Keep intent, host receipt, and observed window state distinct." )
    , ( "Keep targets steady", "Preserve control identity and geometry while asynchronous facts arrive." )
    , ( "Separate attention", "Give window focus, active app, and switcher candidate distinct cues." )
    , ( "Use color economically", "Let neutral lacquer surfaces carry content and purposeful color carry meaning." )
    , ( "Preserve access", "Keep every action reachable by keyboard, 200% enlarged text, and reduced motion." )
    ]


guideCards : List NavCardSpec
guideCards =
    [ { title = "Foundations", body = "Principles, accessibility, keyboard interaction, and layered windows.", href = "./foundations/index.html" }
    , { title = "Styles", body = "Lacquer color, typography, shape, elevation, motion, icons, and portal effects.", href = "./styles/index.html" }
    , { title = "Components", body = "Specifications, anatomy, states, and specimens for all 19 desktop surfaces.", href = "./components/index.html" }
    , { title = "Architecture", body = "Follow Elm policy authority, Haskell services, and compositor boundaries.", href = "./architecture/index.html" }
    , { title = "Get started", body = "Design tokens, Elm + Haskell workflow, contributor rules, and licenses.", href = "./get-started/index.html" }
    , { title = "Search & frozen catalog", body = "Search documentation routes or inspect the frozen v6 reference catalog.", href = "./search/index.html" }
    ]


directoryGroups : List DirectoryGroup
directoryGroups =
    [ { heading = "Foundations & styles"
      , links =
            [ ( "Design principles", "./foundations/principles/index.html" )
            , ( "Accessibility", "./foundations/accessibility/index.html" )
            , ( "Interaction", "./foundations/interaction/index.html" )
            , ( "Layered windows", "./foundations/layered-windows/index.html" )
            , ( "Color", "./styles/color/index.html" )
            , ( "Typography", "./styles/typography/index.html" )
            , ( "Shape & elevation", "./styles/shape/index.html" )
            , ( "Elevation & glow", "./styles/elevation-glow/index.html" )
            , ( "Motion", "./styles/motion/index.html" )
            , ( "Effects", "./styles/effects/index.html" )
            , ( "Iconography", "./styles/iconography/index.html" )
            , ( "CSS architecture", "./styles/css-architecture/index.html" )
            ]
      }
    , { heading = "Core desktop components"
      , links =
            [ ( "Taskbar", "./components/taskbar/index.html" )
            , ( "Application groups", "./components/application-groups/index.html" )
            , ( "Launcher", "./components/launcher/index.html" )
            , ( "Window picker", "./components/window-picker/index.html" )
            , ( "Window switcher", "./components/window-switcher/index.html" )
            , ( "Task View", "./components/task-view/index.html" )
            , ( "Workspace transfer", "./components/workspace-transfer/index.html" )
            , ( "Previews", "./components/previews/index.html" )
            , ( "Popup surfaces", "./components/popup-surfaces/index.html" )
            , ( "Window menu", "./components/window-menu/index.html" )
            ]
      }
    , { heading = "System, files & reference"
      , links =
            [ ( "Snap layouts", "./components/snap-layouts/index.html" )
            , ( "Application actions", "./components/application-actions/index.html" )
            , ( "Notifications", "./components/notifications/index.html" )
            , ( "Appearance settings", "./components/appearance-settings/index.html" )
            , ( "Motion & shortcuts help", "./components/motion-shortcuts-help/index.html" )
            , ( "Files", "./components/files/index.html" )
            , ( "System menu", "./components/system-menu/index.html" )
            , ( "Dialogs", "./components/dialogs/index.html" )
            , ( "Status & recovery", "./components/status-recovery/index.html" )
            , ( "Contributing", "./get-started/contributing/index.html" )
            , ( "Licenses & attribution", "./get-started/licenses/index.html" )
            , ( "Frozen catalog v6", "./reference/catalog/v6/index.html" )
            ]
      }
    ]


primaryNavLinks : List ( String, String )
primaryNavLinks =
    [ ( "Test drive (simulated)", "./test-drive/index.html" )
    , ( "Beta walkthrough", "#beta-walkthrough" )
    , ( "Run & beta status", "#run-beta" )
    , ( "Components", "./components/index.html" )
    , ( "Foundations", "./foundations/index.html" )
    , ( "Styles", "./styles/index.html" )
    , ( "Architecture", "./architecture/index.html" )
    , ( "Get started", "./get-started/index.html" )
    , ( "Search", "./search/index.html" )
    ]



-- PURE HELPERS & KEYBOARD DECODERS


orderedSurfaceIds : List SurfaceId
orderedSurfaceIds =
    List.map .surfaceId allSurfaces


orderedWalkthroughSteps : List BetaWalkthroughStep
orderedWalkthroughSteps =
    List.map .step walkthroughSteps


stepSurface : Int -> SurfaceId -> SurfaceId
stepSurface delta currentId =
    let
        total =
            List.length orderedSurfaceIds

        currentIdx =
            findIndex 0 currentId orderedSurfaceIds

        nextIdx =
            modBy (Basics.max 1 total) (currentIdx + delta)
    in
    itemAt SurfaceTaskbar nextIdx orderedSurfaceIds


stepWalkthrough : Int -> BetaWalkthroughStep -> BetaWalkthroughStep
stepWalkthrough delta currentStep =
    let
        total =
            List.length orderedWalkthroughSteps

        currentIdx =
            findIndex 0 currentStep orderedWalkthroughSteps

        nextIdx =
            modBy (Basics.max 1 total) (currentIdx + delta)
    in
    itemAt WalkSimulatedStage nextIdx orderedWalkthroughSteps


findIndex : Int -> a -> List a -> Int
findIndex idx target remaining =
    case remaining of
        [] ->
            0

        first :: rest ->
            if first == target then
                idx

            else
                findIndex (idx + 1) target rest


itemAt : a -> Int -> List a -> a
itemAt fallback idx remaining =
    case remaining of
        [] ->
            fallback

        first :: rest ->
            if idx <= 0 then
                first

            else
                itemAt fallback (idx - 1) rest


findSurfaceSpec : SurfaceId -> SurfaceSpec
findSurfaceSpec target =
    let
        pick items =
            case items of
                [] ->
                    taskbarSurface

                first :: rest ->
                    if first.surfaceId == target then
                        first

                    else
                        pick rest
    in
    pick allSurfaces


findWalkthroughSpec : BetaWalkthroughStep -> WalkthroughStepSpec
findWalkthroughSpec target =
    let
        pick items =
            case items of
                [] ->
                    walkSimulatedStageSpec

                first :: rest ->
                    if first.step == target then
                        first

                    else
                        pick rest
    in
    pick walkthroughSteps


matchesCategory : SurfaceCategory -> SurfaceSpec -> Bool
matchesCategory chosenCategory spec =
    case chosenCategory of
        CategoryAll ->
            True

        _ ->
            spec.category == chosenCategory


countInCategory : SurfaceCategory -> Int
countInCategory chosenCategory =
    List.length (List.filter (matchesCategory chosenCategory) allSurfaces)


themeSlug : AppearanceTheme -> String
themeSlug chosenTheme =
    case chosenTheme of
        ThemeNight ->
            "night"

        ThemeDawn ->
            "dawn"

        ThemeHighContrast ->
            "high-contrast"


motionSlug : MotionMode -> String
motionSlug chosenMotion =
    case chosenMotion of
        MotionStandard ->
            "standard"

        MotionReduced ->
            "reduced"


boolToken : Bool -> String
boolToken flag =
    if flag then
        "true"

    else
        "false"


matchesScenarioCategory : SurfaceCategory -> ScenarioSpec -> Bool
matchesScenarioCategory chosenCategory spec =
    case chosenCategory of
        CategoryAll ->
            True

        _ ->
            spec.category == chosenCategory


countScenariosInCategory : SurfaceCategory -> Int
countScenariosInCategory chosenCategory =
    List.length (List.filter (matchesScenarioCategory chosenCategory) allScenarios)


findScenarioBySlug : String -> Maybe ScenarioSpec
findScenarioBySlug targetSlug =
    let
        pick remaining =
            case remaining of
                [] ->
                    Nothing

                first :: rest ->
                    if first.slug == targetSlug then
                        Just first

                    else
                        pick rest
    in
    pick allScenarios


decodeMissingDefaultField : String -> Decode.Decoder a -> a -> Decode.Decoder a
decodeMissingDefaultField fieldName valueDecoder defaultValue =
    Decode.maybe (Decode.field fieldName Decode.value)
        |> Decode.andThen
            (\maybeRaw ->
                case maybeRaw of
                    Nothing ->
                        Decode.succeed defaultValue

                    Just rawVal ->
                        case Decode.decodeValue valueDecoder rawVal of
                            Ok typed ->
                                Decode.succeed typed

                            Err _ ->
                                Decode.fail ("invalid field " ++ fieldName)
            )


decodeNonComposingKey : Decode.Decoder String
decodeNonComposingKey =
    Decode.map3
        (\keyName composing code -> ( keyName, composing, code ))
        (Decode.field "key" Decode.string)
        (decodeMissingDefaultField "isComposing" Decode.bool False)
        (decodeMissingDefaultField "keyCode" Decode.int 0)
        |> Decode.andThen
            (\( keyName, composing, code ) ->
                if composing || code == 229 || keyName == "Process" then
                    Decode.fail "ime composition active"

                else
                    Decode.succeed keyName
            )


decodeEscapeKey : Msg -> Decode.Decoder Msg
decodeEscapeKey escapeMsg =
    decodeNonComposingKey
        |> Decode.andThen
            (\keyName ->
                if keyName == "Escape" || keyName == "Esc" then
                    Decode.succeed escapeMsg

                else
                    Decode.fail "not escape"
            )


surfaceTabDomId : SurfaceId -> String
surfaceTabDomId target =
    "wl-tab-" ++ (findSurfaceSpec target).anchorId


walkthroughTabDomId : BetaWalkthroughStep -> String
walkthroughTabDomId target =
    "wl-walk-tab-" ++ (findWalkthroughSpec target).slug


decodeWorkbenchTabKey : Decode.Decoder ( Msg, Bool )
decodeWorkbenchTabKey =
    decodeNonComposingKey
        |> Decode.andThen
            (\keyName ->
                case keyName of
                    "ArrowRight" ->
                        Decode.succeed ( KeyboardStepSpotlight 1, True )

                    "ArrowDown" ->
                        Decode.succeed ( KeyboardStepSpotlight 1, True )

                    "ArrowLeft" ->
                        Decode.succeed ( KeyboardStepSpotlight -1, True )

                    "ArrowUp" ->
                        Decode.succeed ( KeyboardStepSpotlight -1, True )

                    "Home" ->
                        Decode.succeed ( KeyboardJumpSpotlight SurfaceTaskbar, True )

                    "End" ->
                        Decode.succeed ( KeyboardJumpSpotlight SurfaceFiles, True )

                    _ ->
                        Decode.fail "unhandled tab key"
            )


decodeWalkthroughTabKey : Decode.Decoder ( Msg, Bool )
decodeWalkthroughTabKey =
    decodeNonComposingKey
        |> Decode.andThen
            (\keyName ->
                case keyName of
                    "ArrowRight" ->
                        Decode.succeed ( KeyboardStepWalkthrough 1, True )

                    "ArrowDown" ->
                        Decode.succeed ( KeyboardStepWalkthrough 1, True )

                    "ArrowLeft" ->
                        Decode.succeed ( KeyboardStepWalkthrough -1, True )

                    "ArrowUp" ->
                        Decode.succeed ( KeyboardStepWalkthrough -1, True )

                    "Home" ->
                        Decode.succeed ( KeyboardJumpWalkthrough WalkSimulatedStage, True )

                    "End" ->
                        Decode.succeed ( KeyboardJumpWalkthrough WalkLifecycleAndBackendDiag, True )

                    _ ->
                        Decode.fail "unhandled walkthrough tab key"
            )



-- DOCUMENT & VIEW (CSS-FREE ELM: ALL PRESENTATION LIVES IN landing.css)


viewDocument : Model -> Browser.Document Msg
viewDocument currentModel =
    { title = "Warlock · Elm + Haskell desktop shell for Omarchy & Hyprland (beta MVP)"
    , body = [ view currentModel ]
    }


view : Model -> Html Msg
view currentModel =
    Html.div
        [ Attr.class "wl-home-root"
        , Attr.attribute "data-theme" (themeSlug currentModel.theme)
        , Attr.attribute "data-motion" (motionSlug currentModel.motion)
        , Attr.attribute "data-nav-open" (boolToken currentModel.mobileNavOpen)
        ]
        (sharedHeadLinks
            ++ [ Html.a [ Attr.class "wl-doc-skip", Attr.href "#main" ] [ Html.text "Skip to content" ]
               , viewHeader currentModel
               , Html.main_
                    [ Attr.id "main"
                    , Attr.tabindex -1
                    , Attr.class "wl-landing"
                    ]
                    [ viewHero
                    , viewPageIndex
                    , viewBetaWalkthroughSection currentModel
                    , viewScopeSection
                    , viewMvpEvidenceSection
                    , viewBetaRunSection
                    , viewWorkbenchSection currentModel
                    , viewScenarioLaunchpadSection currentModel
                    , viewFeaturesSection currentModel
                    , viewPrinciplesSection currentModel
                    , viewArchitectureSection
                    , viewGuideSection
                    ]
               , viewFooter
               ]
        )


sharedHeadLinks : List (Html msg)
sharedHeadLinks =
    let
        stylesheet path =
            Html.node "link"
                [ Attr.attribute "rel" "stylesheet"
                , Attr.href path
                ]
                []
    in
    [ Html.node "link"
        [ Attr.attribute "rel" "icon"
        , Attr.href "./assets/brand/identity/warlock-mark-mono.svg"
        ]
        []
    , stylesheet "./assets/shared/layers.css"
    , stylesheet "./assets/shared/tokens.css"
    , stylesheet "./assets/shared/fonts.css"
    , stylesheet "./assets/shared/site.css"
    , stylesheet "./assets/shared/glyphs.css"
    , stylesheet "./assets/shared/landing.css"
    , stylesheet "./assets/shared/effects.css"
    ]



-- HEADER & RESPONSIVE NAVIGATION


viewHeader : Model -> Html Msg
viewHeader currentModel =
    Html.header
        [ Attr.class "wl-doc-header wl-home-header"
        , Events.on "keydown" (decodeEscapeKey EscapeMobileNav)
        ]
        [ Html.div [ Attr.class "wl-home-bar" ]
            [ Html.a
                [ Attr.class "wl-doc-brand"
                , Attr.href "./index.html"
                , Attr.attribute "aria-current" "page"
                , Attr.attribute "aria-label" "Warlock home"
                ]
                [ Html.img
                    [ Attr.src "./assets/brand/identity/warlock-mark.svg"
                    , Attr.alt ""
                    , Attr.width 32
                    , Attr.height 32
                    ]
                    []
                , Html.span [] [ Html.text "WARLOCK" ]
                ]
            , Html.div [ Attr.class "wl-home-mobile-actions" ]
                [ Html.a
                    [ Attr.class "wl-doc-button wl-doc-button-primary wl-home-mobile-cta"
                    , Attr.href "./test-drive/index.html"
                    ]
                    [ Html.text "Test drive (sim)" ]
                , Html.button
                    [ Attr.id "wl-home-nav-toggle"
                    , Attr.type_ "button"
                    , Attr.class "wl-doc-button wl-home-nav-toggle"
                    , Attr.attribute "aria-expanded" (boolToken currentModel.mobileNavOpen)
                    , Attr.attribute "aria-controls" "wl-home-nav-drawer"
                    , Events.onClick ToggleMobileNav
                    ]
                    [ Html.text
                        (if currentModel.mobileNavOpen then
                            "Close menu"

                         else
                            "Menu"
                        )
                    ]
                ]
            ]
        , Html.div
            [ Attr.id "wl-home-nav-drawer"
            , Attr.class "wl-home-drawer"
            ]
            [ Html.nav
                [ Attr.class "wl-home-nav"
                , Attr.attribute "aria-label" "Primary"
                ]
                (List.map
                    (\( linkLabel, linkHref ) ->
                        Html.a
                            [ Attr.href linkHref
                            , Events.onClick CloseMobileNav
                            ]
                            [ Html.text linkLabel ]
                    )
                    primaryNavLinks
                )
            , Html.div
                [ Attr.class "wl-home-appearance"
                , Attr.attribute "role" "group"
                , Attr.attribute "aria-label" "Page preview appearance"
                ]
                [ viewToggleChip (currentModel.theme == ThemeNight) (SelectTheme ThemeNight) "Night"
                , viewToggleChip (currentModel.theme == ThemeDawn) (SelectTheme ThemeDawn) "Dawn"
                , viewToggleChip (currentModel.theme == ThemeHighContrast) (SelectTheme ThemeHighContrast) "High contrast"
                , viewToggleChip (currentModel.motion == MotionReduced) ToggleMotion "Reduced motion"
                ]
            ]
        ]


viewToggleChip : Bool -> Msg -> String -> Html Msg
viewToggleChip isPressed clickMsg chipLabel =
    Html.button
        [ Attr.type_ "button"
        , Attr.class
            (if isPressed then
                "wl-doc-button wl-home-chip is-pressed"

             else
                "wl-doc-button wl-home-chip"
            )
        , Attr.attribute "aria-pressed" (boolToken isPressed)
        , Events.onClick clickMsg
        ]
        [ Html.text chipLabel ]



-- HERO


viewHero : Html Msg
viewHero =
    Html.section
        [ Attr.class "wl-hero"
        , Attr.attribute "aria-labelledby" "hero-title"
        ]
        [ Html.div [ Attr.class "wl-hero-copy" ]
            [ Html.p [ Attr.class "wl-hero-eyebrow" ]
                [ Html.img
                    [ Attr.src "./assets/brand/identity/warlock-mark.svg"
                    , Attr.width 28
                    , Attr.height 22
                    , Attr.alt ""
                    ]
                    []
                , Html.text "Warlock for Omarchy · Beta MVP · Simulated shell & bounded read-only search trial"
                ]
            , Html.h1 [ Attr.id "hero-title" ]
                [ Html.text "A Windows-style desktop shell for Hyprland" ]
            , Html.p [ Attr.class "wl-hero-lead" ]
                [ Html.text "Warlock designs a taskbar, Start-style launcher, Alt-Tab, Task View, snap chooser, notifications, Files quick access, and Settings in Elm + Haskell atop Hyprland—not a replacement window manager. All 16 scenarios run interactively in your browser today on a simulated stage, while the live Omarchy beta (--application-only) exercises bounded read-only application catalog search inside a GTK4 / WebKitGTK 6 window without verified native window management, catalog receipts, or restart recovery." ]
            , Html.div [ Attr.class "wl-hero-actions" ]
                [ Html.a
                    [ Attr.class "wl-doc-button wl-doc-button-primary"
                    , Attr.href "./test-drive/index.html"
                    ]
                    [ Html.text "Open browser test drive (simulated)" ]
                , Html.a
                    [ Attr.class "wl-doc-button"
                    , Attr.href "#beta-walkthrough"
                    ]
                    [ Html.text "4-step beta walkthrough" ]
                , Html.a
                    [ Attr.class "wl-doc-button"
                    , Attr.href "#mvp-evidence"
                    ]
                    [ Html.text "Observed MVP evidence (af1bf0efe)" ]
                , Html.a
                    [ Attr.class "wl-doc-button"
                    , Attr.href "#run-beta"
                    ]
                    [ Html.text "How to run & beta limits" ]
                ]
            , Html.div
                [ Attr.id "wl-quick-scenarios"
                , Attr.class "wl-home-quick-strip"
                , Attr.attribute "role" "group"
                , Attr.attribute "aria-label" "Quick simulated scenario launchers"
                ]
                (Html.span [ Attr.class "wl-home-quick-label" ] [ Html.text "Jump into a simulated scenario:" ]
                    :: List.filterMap
                        (\slug ->
                            Maybe.map
                                (\spec ->
                                    Html.a
                                        [ Attr.class "wl-home-scenario-chip"
                                        , Attr.href ("./test-drive/index.html?scenario=" ++ spec.slug)
                                        ]
                                        [ Html.text spec.title ]
                                )
                                (findScenarioBySlug slug)
                        )
                        quickScenarioSlugs
                    ++ [ Html.a
                            [ Attr.class "wl-home-scenario-chip"
                            , Attr.href "#scenarios"
                            ]
                            [ Html.text "All 16 scenarios" ]
                       ]
                )
            , Html.p [ Attr.class "wl-hero-note" ]
                [ Html.text "Honest MVP scope (commit af1bf0efe · source bdeac7349): Warlock is not a complete window manager, verified native shell, or restartable daemon yet, and no desktop binary download exists (Get started downloads provide design tokens, fonts, and SVG marks only). Canonical ledger acceptance is 18 / 242 whole EARS requirements (ELM-TEA-001 typed model accepted on bdeac7349) and 42 / 417 scenarios (224 whole / 375 scenarios OPEN); CPU/Haskell/Quint checks pass 345 Haskell-profile inputs (10 suites / 64 commands, 32 ordinary logs clean of synthetic markers), 7,293 HTTP/DOM checks, 137 typed controls, 61 policy histories, 57 named Quint runs, and 10,000 seed=20261101 traces. Guarded 28s Omarchy --application-only trials alongside preserved Foot completed 17 QMP inputs (foot -> footz -> Refresh across 63 regular entries, 8 symlinks skipped), with backend-private-diagnostics-20261102 confirming 6/7 Backend checks and 3/3 retirements while isolating selectedOperationSucceeded=false (exitCode=1) alongside launcherExit=1, retired-cgroup FileNotFoundError, historical cancel-query-20261101 forced exit -9 at 27.88s, warlock-ui-backend exited 1, HOSTSTOP2, nativeOperations = [], ELM-ARC-024, and ELM-DEL-014 OPEN." ]
            ]
        , Html.figure [ Attr.class "wl-hero-shot" ]
            [ Html.img
                [ Attr.src "./assets/site/hero-desktop.png"
                , Attr.width 1600
                , Attr.height 903
                , Attr.alt "Capture from the simulated Warlock browser test drive: a frosted taskbar across the top and Task View open with three workspace columns over a black and red lacquer wallpaper"
                ]
                []
            ]
        ]


viewPageIndex : Html msg
viewPageIndex =
    let
        items =
            [ ( "4-step beta walkthrough", "#beta-walkthrough" )
            , ( "MVP & native status", "#scope" )
            , ( "Availability matrix", "#wl-mvp-matrix" )
            , ( "Observed MVP evidence", "#mvp-evidence" )
            , ( "Genuine run & beta guide", "#run-beta" )
            , ( "Surface workbench", "#workbench" )
            , ( "16 scenarios", "#scenarios" )
            , ( "8 desktop surfaces", "#features" )
            , ( "Attention & receipts", "#principles" )
            , ( "Elm + Haskell", "#architecture" )
            , ( "Lacquer guide", "#guide" )
            ]
    in
    Html.nav
        [ Attr.id "wl-page-index"
        , Attr.class "wl-home-index-bar"
        , Attr.attribute "aria-label" "On this page"
        ]
        [ Html.span [ Attr.class "wl-home-quick-label" ] [ Html.text "On this page:" ]
        , Html.ul [ Attr.class "wl-home-index-list" ]
            (List.map
                (\( labelText, targetHref ) ->
                    Html.li [] [ Html.a [ Attr.href targetHref ] [ Html.text labelText ] ]
                )
                items
            )
        ]



-- INTERACTIVE 4-STEP TRUTHFUL BETA WALKTHROUGH (ROVING ARIA TABLIST)


viewBetaWalkthroughSection : Model -> Html Msg
viewBetaWalkthroughSection currentModel =
    let
        activeWalk =
            findWalkthroughSpec currentModel.walkthroughStep
    in
    Html.section
        [ Attr.id "beta-walkthrough"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "beta-walkthrough-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Interactive truthful beta walkthrough · CSS-free Elm policy" ]
            , Html.h2 [ Attr.id "beta-walkthrough-title" ] [ Html.text "Step through simulated scenarios, live MVP captures, and unavailable operations" ]
            , Html.p []
                [ Html.text "Use the four walkthrough tabs (or Left, Right, Home, and End keys) to inspect exact enabled controls vs dashed disabled operations across the simulated browser stage, the 1280x800 and 621x750 Omarchy --application-only captures, and Root's closed Warlock/Backend.hs diagnostics." ]
            ]
        , Html.div [ Attr.class "wl-doc-card wl-home-walkthrough" ]
            [ Html.div [ Attr.class "wl-home-walkthrough-bar" ]
                [ Html.div
                    [ Attr.class "wl-home-tabs"
                    , Attr.attribute "role" "tablist"
                    , Attr.attribute "aria-label" "Beta walkthrough steps"
                    ]
                    (List.map (viewWalkthroughTab currentModel.walkthroughStep) walkthroughSteps)
                , Html.div [ Attr.class "wl-home-step-group" ]
                    [ Html.button
                        [ Attr.type_ "button"
                        , Attr.id "wl-walk-prev"
                        , Attr.class "wl-doc-button wl-home-chip"
                        , Events.onClick (StepWalkthrough -1)
                        ]
                        [ Html.text "Previous step" ]
                    , Html.button
                        [ Attr.type_ "button"
                        , Attr.id "wl-walk-next"
                        , Attr.class "wl-doc-button wl-home-chip"
                        , Events.onClick (StepWalkthrough 1)
                        ]
                        [ Html.text "Next step" ]
                    ]
                ]
            , Html.div
                [ Attr.id "wl-walkthrough-panel"
                , Attr.class "wl-home-walkthrough-panel"
                , Attr.attribute "role" "tabpanel"
                , Attr.attribute "aria-labelledby" (walkthroughTabDomId activeWalk.step)
                , Attr.tabindex 0
                ]
                [ Html.div [ Attr.class "wl-home-card-stack" ]
                    [ Html.div [ Attr.class "wl-home-badges" ]
                        [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text activeWalk.stepEyebrow ]
                        , Html.span [ Attr.class ("wl-home-status-pill is-" ++ activeWalk.statusTone) ] [ Html.text activeWalk.statusBadge ]
                        ]
                    , Html.h3 [ Attr.id "wl-walkthrough-step-heading" ] [ Html.text activeWalk.heading ]
                    , Html.p [] [ Html.text activeWalk.summary ]
                    ]
                , Html.div [ Attr.class "wl-home-walkthrough-columns" ]
                    [ Html.div [ Attr.id "wl-walkthrough-enabled", Attr.class "wl-home-walkthrough-box" ]
                        [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Available / verified in this step" ]
                        , Html.ul [ Attr.class "wl-home-control-list" ]
                            (List.map
                                (\line ->
                                    Html.li [ Attr.class "wl-home-control-item is-enabled" ] [ Html.text line ]
                                )
                                activeWalk.enabledControls
                            )
                        ]
                    , Html.div [ Attr.id "wl-walkthrough-unavailable", Attr.class "wl-home-walkthrough-box" ]
                        [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Unavailable / disabled or unaccepted" ]
                        , Html.ul [ Attr.class "wl-home-control-list" ]
                            (List.map
                                (\line ->
                                    Html.li [ Attr.class "wl-home-control-item is-unavailable" ] [ Html.text line ]
                                )
                                activeWalk.unavailableOperations
                            )
                        ]
                    ]
                , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text activeWalk.evidenceNote ] ]
                , Html.div [ Attr.class "wl-home-actions-row" ]
                    [ Html.a
                        [ Attr.class "wl-doc-button wl-doc-button-primary"
                        , Attr.href activeWalk.ctaHref
                        ]
                        [ Html.text activeWalk.ctaLabel ]
                    , Html.a
                        [ Attr.class "wl-doc-button"
                        , Attr.href activeWalk.secondaryHref
                        ]
                        [ Html.text activeWalk.secondaryLabel ]
                    ]
                ]
            ]
        ]


viewWalkthroughTab : BetaWalkthroughStep -> WalkthroughStepSpec -> Html Msg
viewWalkthroughTab activeStep spec =
    let
        isSelected =
            activeStep == spec.step
    in
    Html.button
        [ Attr.type_ "button"
        , Attr.id (walkthroughTabDomId spec.step)
        , Attr.class
            (if isSelected then
                "wl-doc-button wl-home-chip is-pressed"

             else
                "wl-doc-button wl-home-chip"
            )
        , Attr.attribute "role" "tab"
        , Attr.attribute "aria-selected" (boolToken isSelected)
        , Attr.attribute "aria-controls" "wl-walkthrough-panel"
        , Attr.tabindex
            (if isSelected then
                0

             else
                -1
            )
        , Events.onClick (SelectWalkthroughStep spec.step)
        , Events.preventDefaultOn "keydown" decodeWalkthroughTabKey
        ]
        [ Html.text spec.tabLabel ]



-- HONEST SCOPE & DELIVERY STATUS


viewScopeSection : Html msg
viewScopeSection =
    Html.section
        [ Attr.id "scope"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "scope-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Honest delivery boundaries" ]
            , Html.h2 [ Attr.id "scope-title" ] [ Html.text "What runs in the browser today vs what remains open natively" ]
            , Html.p []
                [ Html.text "Warlock keeps simulated browser demonstrations, CPU/replay contract checks, Quint formal models, bounded VM component observations, and persistent native compositor acceptance strictly separate. Header appearance buttons preview Lacquer tokens on this page only." ]
            ]
        , Html.div [ Attr.class "wl-doc-grid wl-home-scope-grid" ]
            (List.map viewScopeCard scopeCards)
        , Html.div
            [ Attr.id "wl-mvp-matrix-region"
            , Attr.class "wl-doc-card wl-home-matrix-wrap"
            , Attr.attribute "role" "region"
            , Attr.attribute "aria-labelledby" "wl-mvp-matrix-caption"
            , Attr.tabindex 0
            ]
            [ Html.table
                [ Attr.id "wl-mvp-matrix"
                , Attr.class "wl-home-matrix"
                ]
                [ Html.caption [ Attr.id "wl-mvp-matrix-caption", Attr.class "wl-home-matrix-caption" ]
                    [ Html.text "Current verification & release status by execution track (commit af1bf0efe · source bdeac7349 · 18 / 242 requirements & 42 / 417 scenarios)" ]
                , Html.thead []
                    [ Html.tr []
                        [ Html.th [ Attr.scope "col" ] [ Html.text "Execution track" ]
                        , Html.th [ Attr.scope "col" ] [ Html.text "Current status" ]
                        , Html.th [ Attr.scope "col" ] [ Html.text "Verified scope today" ]
                        , Html.th [ Attr.scope "col" ] [ Html.text "Explicit exclusions & open gates" ]
                        ]
                    ]
                , Html.tbody []
                    (List.map viewMvpMatrixRow mvpMatrixRows)
                ]
            ]
        ]


viewMvpMatrixRow : MvpMatrixRow -> Html msg
viewMvpMatrixRow row =
    Html.tr [ Attr.id row.rowId ]
        [ Html.th [ Attr.scope "row" ] [ Html.text row.track ]
        , Html.td []
            [ Html.span
                [ Attr.class ("wl-home-status-pill is-" ++ row.statusTone) ]
                [ Html.text row.statusBadge ]
            ]
        , Html.td [] [ Html.text row.provenToday ]
        , Html.td [] [ Html.text row.openOrExcluded ]
        ]



-- ACTUAL MVP EVIDENCE LAYOUT (TILED 621x750 & FULLSCREEN 1280x800 CAPTURES VS OPEN GATES)


viewMvpEvidenceSection : Html msg
viewMvpEvidenceSection =
    Html.section
        [ Attr.id "mvp-evidence"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "mvp-evidence-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Actual MVP evidence layout · Commit af1bf0efe (backend-private-diagnostics-20261102 & typed-model-live-20261102)" ]
            , Html.h2 [ Attr.id "mvp-evidence-title" ] [ Html.text "What the guarded Omarchy trials actually render (bounded read-only app search)" ]
            , Html.p []
                [ Html.text "Root-inspected Omarchy guest captures record Warlock's standalone GTK4 / WebKitGTK 6 --application-only window both tiled 50/50 (621x750) beside Foot in backend-private-diagnostics-20261102 and fullscreen (1280x800) in typed-model-live-20261102—never a replacement window manager, layer-shell bar, verified native launch path, or restartable daemon." ]
            ]
        , Html.div
            [ Attr.id "wl-mvp-tiled-layout"
            , Attr.class "wl-doc-card wl-home-tiled-wrap"
            , Attr.attribute "role" "region"
            , Attr.attribute "aria-labelledby" "wl-mvp-tiled-heading"
            ]
            [ Html.div [ Attr.class "wl-home-badges" ]
                [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Observed 1280x800 & 621x750 Omarchy guest geometries" ]
                , Html.span [ Attr.class "wl-home-status-pill is-scoped" ] [ Html.text "GTK4 client · Not a window manager" ]
                ]
            , Html.h3 [ Attr.id "wl-mvp-tiled-heading" ] [ Html.text "Hyprland & Omarchy retain top-bar and window custody while Warlock runs read-only search" ]
            , Html.div [ Attr.class "wl-home-tiled-topbar" ]
                [ Html.code [] [ Html.text "Top layer: Stock Omarchy Waybar (26px, workspaces 1–5, clock) + Hyprland compositor — owns tiling, focus & layer-shell" ] ]
            , Html.div [ Attr.class "wl-home-tiled-panes" ]
                [ Html.div [ Attr.id "wl-mvp-pane-foot", Attr.class "wl-home-tiled-pane wl-home-card-stack" ]
                    [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Left tiled pane (621x750) · Stock guest window" ]
                    , Html.h4 [] [ Html.text "Preserved Foot terminal (pid 2095)" ]
                    , Html.p [] [ Html.text "Original Foot session remains open and untouched before, during, and after the 28-second trial. Warlock neither reparents nor manages client windows." ]
                    , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text "Client custody: Hyprland · footPreserved = true · idleEnabledRestored = true" ] ]
                    ]
                , Html.div [ Attr.id "wl-mvp-pane-warlock", Attr.class "wl-home-tiled-pane wl-home-card-stack" ]
                    [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Right tiled pane (621x750) / 1280x800 fullscreen · Warlock --application-only" ]
                    , Html.h4 [] [ Html.text "Stacked HttpBar + HttpPopup read-only Applications surface" ]
                    , Html.p [] [ Html.text "Active Applications button sits beside 6 dashed disabled bar openers (Task View, Switch windows, Notifications, Files, System, Settings; in the 621px tiled still, overflow-x:auto visibly displays the first three before the separate status region without a static scroll cue). Popup shows Search applications (foot -> footz), Windows, Refresh, enabled Pin Foot (unclicked), and dashed disabled Actions for Foot, Open Foot, Open Foot Server, and Open Foot Client." ]
                    , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text "Backend 6/7 checks true & 3/3 retirements confirmed · selectedOperationSucceeded=false (exitCode=1) · cgroup FileNotFoundError & prior exit -9 retained" ] ]
                    ]
                ]
            ]
        , Html.div [ Attr.id "wl-mvp-evidence-grid", Attr.class "wl-doc-grid wl-home-run-grid" ]
            (List.map viewMvpEvidenceCard mvpEvidenceCards)
        ]


viewMvpEvidenceCard : MvpEvidenceSpec -> Html msg
viewMvpEvidenceCard item =
    Html.article [ Attr.id item.cardId, Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.div [ Attr.class "wl-home-badges" ]
            [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text item.eyebrow ]
            , Html.span [ Attr.class ("wl-home-status-pill is-" ++ item.badgeTone) ] [ Html.text item.badge ]
            ]
        , Html.h3 [] [ Html.text item.title ]
        , Html.p [] [ Html.text item.observed ]
        , Html.p [ Attr.class "wl-home-detail" ] [ Html.text ("Non-claim: " ++ item.nonClaim) ]
        , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text item.artifactRef ] ]
        ]



-- GENUINE BETA CAPABILITIES & RUN PATHS


viewBetaRunSection : Html msg
viewBetaRunSection =
    Html.section
        [ Attr.id "run-beta"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "run-beta-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Beta capabilities & genuine run paths" ]
            , Html.h2 [ Attr.id "run-beta-title" ] [ Html.text "How to try Warlock honestly today (no mock installer)" ]
            , Html.p []
                [ Html.text "Every runnable path below states its exact execution boundary. Simulated browser scenarios run immediately; the standalone Omarchy beta builds offline against matching guest GTK4 / WebKitGTK 6 ABIs for bounded 28-second read-only application search only—not a window manager or restartable desktop shell." ]
            ]
        , Html.div [ Attr.id "wl-beta-run-grid", Attr.class "wl-doc-grid wl-home-run-grid" ]
            (List.map viewBetaRunCard betaRunTracks)
        ]


viewBetaRunCard : BetaRunSpec -> Html msg
viewBetaRunCard item =
    Html.article [ Attr.id item.cardId, Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.div [ Attr.class "wl-home-badges" ]
            [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text item.eyebrow ]
            , Html.span [ Attr.class ("wl-home-status-pill is-" ++ item.badgeTone) ] [ Html.text item.badge ]
            ]
        , Html.h3 [] [ Html.text item.title ]
        , Html.p [] [ Html.text item.summary ]
        , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text item.commandOrRef ] ]
        , Html.p [ Attr.class "wl-home-detail" ] [ Html.text ("Boundary: " ++ item.limits) ]
        , Html.div [ Attr.class "wl-home-actions-row" ]
            [ Html.a
                [ Attr.class "wl-feature-link"
                , Attr.href item.linkHref
                ]
                [ Html.text item.linkLabel ]
            ]
        ]


viewScopeCard : CardSpec -> Html msg
viewScopeCard item =
    Html.article [ Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text item.eyebrow ]
        , Html.h3 [] [ Html.text item.title ]
        , Html.p [] [ Html.text item.body ]
        , Html.p [ Attr.class "wl-home-detail" ] [ Html.code [] [ Html.text item.detail ] ]
        ]



-- INTERACTIVE 8-SURFACE WORKBENCH (ARIA TABLIST + ARROW KEYS)


viewWorkbenchSection : Model -> Html Msg
viewWorkbenchSection currentModel =
    let
        activeSpec =
            findSurfaceSpec currentModel.spotlight
    in
    Html.section
        [ Attr.id "workbench"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "workbench-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Interactive surface workbench" ]
            , Html.h2 [ Attr.id "workbench-title" ] [ Html.text "Inspect Elm policy authority vs observed host facts" ]
            , Html.p []
                [ Html.text "Select any desktop surface below (or press Left and Right arrow keys on the tab strip) to inspect Elm's local policy authority vs target host observations. All eight surfaces run interactively in the simulated browser test drive today; in the standalone Omarchy trial (--application-only, nativeOperations = []), only bounded read-only application catalog search is exercised live while Task View, Switch windows, Notifications, Files, System, Settings, app launch, and compositor mutations remain disabled." ]
            ]
        , Html.div [ Attr.class "wl-doc-card wl-home-workbench" ]
            [ Html.div [ Attr.class "wl-home-workbench-bar" ]
                [ Html.div
                    [ Attr.class "wl-home-tabs"
                    , Attr.attribute "role" "tablist"
                    , Attr.attribute "aria-label" "Desktop surfaces"
                    ]
                    (List.map (viewWorkbenchTab currentModel.spotlight) allSurfaces)
                , Html.div [ Attr.class "wl-home-step-group" ]
                    [ Html.button
                        [ Attr.type_ "button"
                        , Attr.class "wl-doc-button wl-home-chip"
                        , Events.onClick (StepSpotlight -1)
                        ]
                        [ Html.text "Previous" ]
                    , Html.button
                        [ Attr.type_ "button"
                        , Attr.class "wl-doc-button wl-home-chip"
                        , Events.onClick (StepSpotlight 1)
                        ]
                        [ Html.text "Next" ]
                    ]
                ]
            , Html.div
                [ Attr.id "wl-workbench-panel"
                , Attr.class "wl-home-split"
                , Attr.attribute "role" "tabpanel"
                , Attr.attribute "aria-labelledby" (surfaceTabDomId activeSpec.surfaceId)
                , Attr.tabindex 0
                ]
                [ Html.figure [ Attr.class "wl-feature-shot" ]
                    [ Html.img
                        [ Attr.src activeSpec.imageSrc
                        , Attr.width activeSpec.imageWidth
                        , Attr.height activeSpec.imageHeight
                        , Attr.alt activeSpec.imageAlt
                        ]
                        []
                    ]
                , Html.div [ Attr.class "wl-home-card-stack" ]
                    [ Html.div [ Attr.class "wl-home-badges" ]
                        [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text activeSpec.label ]
                        , Html.kbd [ Attr.class "wl-home-kbd" ] [ Html.text activeSpec.chord ]
                        ]
                    , Html.h3 [] [ Html.text activeSpec.heading ]
                    , Html.p [] [ Html.text activeSpec.summary ]
                    , Html.dl [ Attr.class "wl-home-dl" ]
                        [ Html.div []
                            [ Html.dt [] [ Html.text "Elm GUI policy authority" ]
                            , Html.dd [] [ Html.text activeSpec.elmAuthority ]
                            ]
                        , Html.div []
                            [ Html.dt [] [ Html.text "Haskell / compositor observations" ]
                            , Html.dd [] [ Html.text activeSpec.hostObservation ]
                            ]
                        ]
                    , Html.div [ Attr.class "wl-home-actions-row" ]
                        [ Html.a
                            [ Attr.class "wl-doc-button wl-doc-button-primary"
                            , Attr.href activeSpec.scenarioHref
                            ]
                            [ Html.text (activeSpec.scenarioCta ++ " (simulated)") ]
                        , Html.a
                            [ Attr.class "wl-doc-button"
                            , Attr.href activeSpec.specHref
                            ]
                            [ Html.text ("Read " ++ activeSpec.label ++ " spec") ]
                        ]
                    ]
                ]
            ]
        ]


viewWorkbenchTab : SurfaceId -> SurfaceSpec -> Html Msg
viewWorkbenchTab activeId spec =
    let
        isSelected =
            activeId == spec.surfaceId
    in
    Html.button
        [ Attr.type_ "button"
        , Attr.id (surfaceTabDomId spec.surfaceId)
        , Attr.class
            (if isSelected then
                "wl-doc-button wl-home-chip is-pressed"

             else
                "wl-doc-button wl-home-chip"
            )
        , Attr.attribute "role" "tab"
        , Attr.attribute "aria-selected" (boolToken isSelected)
        , Attr.attribute "aria-controls" "wl-workbench-panel"
        , Attr.tabindex
            (if isSelected then
                0

             else
                -1
            )
        , Events.onClick (SelectSpotlight spec.surfaceId)
        , Events.preventDefaultOn "keydown" decodeWorkbenchTabKey
        ]
        [ Html.text spec.label ]



-- 16-SCENARIO SIMULATED LAUNCHPAD


viewScenarioLaunchpadSection : Model -> Html Msg
viewScenarioLaunchpadSection currentModel =
    let
        visibleScenarios =
            List.filter (matchesScenarioCategory currentModel.scenarioCategory) allScenarios

        shownCount =
            List.length visibleScenarios

        totalCount =
            List.length allScenarios
    in
    Html.section
        [ Attr.id "scenarios"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "scenarios-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Simulated browser test drive · 16 seeded scenarios" ]
            , Html.h2 [ Attr.id "scenarios-title" ] [ Html.text "Launch any desktop scenario directly" ]
            , Html.p []
                [ Html.text "Every scenario opens Warlock's compiled Elm Main, Bar, and Popup bundles on deterministic seeded desktop state. Client window interiors remain simulated browser fixtures." ]
            ]
        , Html.div [ Attr.class "wl-home-filter-bar" ]
            [ Html.div
                [ Attr.class "wl-home-tabs"
                , Attr.attribute "role" "group"
                , Attr.attribute "aria-label" "Filter simulated scenarios by workflow area"
                ]
                [ viewScenarioCategoryButton currentModel.scenarioCategory CategoryAll "All scenarios"
                , viewScenarioCategoryButton currentModel.scenarioCategory CategoryWindows "Windows & workspaces"
                , viewScenarioCategoryButton currentModel.scenarioCategory CategoryAppsFiles "Apps & files"
                , viewScenarioCategoryButton currentModel.scenarioCategory CategorySystem "System & recovery"
                ]
            , Html.p
                [ Attr.class "wl-home-detail"
                , Attr.attribute "aria-live" "polite"
                ]
                [ Html.text
                    ("Showing "
                        ++ String.fromInt shownCount
                        ++ " of "
                        ++ String.fromInt totalCount
                        ++ " simulated scenarios."
                    )
                ]
            ]
        , Html.div [ Attr.id "wl-scenario-grid", Attr.class "wl-doc-grid wl-home-scenario-grid" ]
            (List.map viewScenarioCard visibleScenarios)
        ]


viewScenarioCategoryButton : SurfaceCategory -> SurfaceCategory -> String -> Html Msg
viewScenarioCategoryButton activeCategory targetCategory labelText =
    let
        countLabel =
            labelText ++ " (" ++ String.fromInt (countScenariosInCategory targetCategory) ++ ")"
    in
    viewToggleChip (activeCategory == targetCategory) (SelectScenarioCategory targetCategory) countLabel


viewScenarioCard : ScenarioSpec -> Html msg
viewScenarioCard spec =
    Html.article [ Attr.id ("wl-scenario-card-" ++ spec.slug), Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.div [ Attr.class "wl-home-badges" ]
            [ Html.span [ Attr.class "wl-doc-eyebrow" ] [ Html.text spec.slug ]
            , Html.kbd [ Attr.class "wl-home-kbd" ] [ Html.text spec.chord ]
            ]
        , Html.h3 [] [ Html.text spec.title ]
        , Html.p [] [ Html.text spec.summary ]
        , Html.div [ Attr.class "wl-home-actions-row" ]
            [ Html.a
                [ Attr.class "wl-doc-button wl-doc-button-primary"
                , Attr.href ("./test-drive/index.html?scenario=" ++ spec.slug)
                ]
                [ Html.text ("Run " ++ spec.title ++ " (simulated)") ]
            , Html.a
                [ Attr.class "wl-feature-link"
                , Attr.href spec.specHref
                ]
                [ Html.text "Component spec" ]
            ]
        ]



-- EDITORIAL FEATURES SECTION WITH AREA FILTER


viewFeaturesSection : Model -> Html Msg
viewFeaturesSection currentModel =
    let
        visibleSurfaces =
            List.filter (matchesCategory currentModel.category) allSurfaces

        shownCount =
            List.length visibleSurfaces

        totalCount =
            List.length allSurfaces
    in
    Html.section
        [ Attr.id "features"
        , Attr.class "wl-features"
        , Attr.attribute "aria-labelledby" "features-title"
        ]
        ([ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Interface design & target shell scope" ]
            , Html.h2 [ Attr.id "features-title" ] [ Html.text "The desktop you know, designed for the compositor you love" ]
            , Html.p []
                [ Html.text "Filter by workflow area to inspect each compiled Elm surface, its simulated test-drive scenario, and its specification (screenshots below are captured from the simulated test drive; persistent native Hyprland parity remains in active beta verification)." ]
            ]
         , Html.div [ Attr.class "wl-home-filter-bar" ]
            [ Html.div
                [ Attr.class "wl-home-tabs"
                , Attr.attribute "role" "group"
                , Attr.attribute "aria-label" "Filter desktop surfaces by area"
                ]
                [ viewCategoryButton currentModel.category CategoryAll "All surfaces"
                , viewCategoryButton currentModel.category CategoryWindows "Windows & workspaces"
                , viewCategoryButton currentModel.category CategoryAppsFiles "Apps & files"
                , viewCategoryButton currentModel.category CategorySystem "System & tray"
                ]
            , Html.p
                [ Attr.class "wl-home-detail"
                , Attr.attribute "aria-live" "polite"
                ]
                [ Html.text
                    ("Showing "
                        ++ String.fromInt shownCount
                        ++ " of "
                        ++ String.fromInt totalCount
                        ++ " desktop surfaces."
                    )
                ]
            ]
         ]
            ++ List.map viewFeatureArticle visibleSurfaces
        )


viewCategoryButton : SurfaceCategory -> SurfaceCategory -> String -> Html Msg
viewCategoryButton activeCategory targetCategory labelText =
    let
        countLabel =
            labelText ++ " (" ++ String.fromInt (countInCategory targetCategory) ++ ")"
    in
    viewToggleChip (activeCategory == targetCategory) (SelectCategory targetCategory) countLabel


viewFeatureArticle : SurfaceSpec -> Html msg
viewFeatureArticle spec =
    Html.article
        [ Attr.class "wl-feature"
        , Attr.id spec.anchorId
        ]
        [ Html.figure [ Attr.class "wl-feature-shot" ]
            [ Html.img
                [ Attr.src spec.imageSrc
                , Attr.width spec.imageWidth
                , Attr.height spec.imageHeight
                , Attr.attribute "loading" "lazy"
                , Attr.alt spec.imageAlt
                ]
                []
            ]
        , Html.div [ Attr.class "wl-feature-copy" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text spec.label ]
            , Html.h3 [] [ Html.text spec.heading ]
            , Html.p [] [ Html.text spec.summary ]
            , Html.div [ Attr.class "wl-home-actions-row" ]
                [ Html.a
                    [ Attr.class "wl-feature-link"
                    , Attr.href spec.scenarioHref
                    ]
                    [ Html.text (spec.scenarioCta ++ " (simulated)") ]
                , Html.a
                    [ Attr.class "wl-feature-link"
                    , Attr.href spec.specHref
                    ]
                    [ Html.text (spec.label ++ " specification") ]
                ]
            ]
        ]



-- PRINCIPLES + INTERACTIVE ATTENTION & CAUSALITY SPECIMEN


viewPrinciplesSection : Model -> Html Msg
viewPrinciplesSection currentModel =
    Html.section
        [ Attr.id "principles"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "principles-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Built on Elm" ]
            , Html.h2 [ Attr.id "principles-title" ] [ Html.text "Honest about every window" ]
            , Html.p []
                [ Html.text "In Warlock's target shell architecture (simulated in the browser today while native compositor integration remains open), Elm asks Hyprland to act and shows only what Hyprland reports. One Elm policy authority drives every surface so the taskbar, launcher, and switcher never contradict one another." ]
            ]
        , Html.div [ Attr.class "wl-doc-grid" ]
            (List.map
                (\( titleText, bodyText ) ->
                    Html.div [ Attr.class "wl-doc-card wl-home-card-stack" ]
                        [ Html.h3 [] [ Html.text titleText ]
                        , Html.p [] [ Html.text bodyText ]
                        ]
                )
                principleCards
            )
        , Html.div [ Attr.class "wl-home-split wl-home-specimen-grid" ]
            [ viewCueLabCard currentModel.cues
            , viewOutcomeLabCard currentModel.outcomeSample
            ]
        ]


viewCueLabCard : CueFacts -> Html Msg
viewCueLabCard cueState =
    Html.div [ Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Interactive cue check · Separate attention" ]
        , Html.h3 [] [ Html.text "Window focus, active app, and switcher candidate stay distinct" ]
        , Html.p []
            [ Html.text "Toggle each independent fact below to verify how Lacquer separates compositor window focus (bright border), active taskbar group (lacquer pill), and uncommitted Alt-Tab candidate selection (corner brackets)." ]
        , Html.div
            [ Attr.class "wl-home-tabs"
            , Attr.attribute "role" "group"
            , Attr.attribute "aria-label" "Toggle attention cues"
            ]
            [ viewToggleChip cueState.windowFocused ToggleWindowFocused "Window focused"
            , viewToggleChip cueState.activeApplication ToggleActiveApplication "Active app on bar"
            , viewToggleChip cueState.switcherCandidate ToggleSwitcherCandidate "Alt-Tab candidate"
            ]
        , Html.div
            [ Attr.class
                ("wl-home-window"
                    ++ (if cueState.windowFocused then
                            " is-focused"

                        else
                            ""
                       )
                    ++ (if cueState.switcherCandidate then
                            " is-candidate"

                        else
                            ""
                       )
                )
            , Attr.attribute "aria-live" "polite"
            ]
            [ Html.div [ Attr.class "wl-home-badges" ]
                [ Html.span
                    [ Attr.class
                        (if cueState.activeApplication then
                            "wl-home-pill is-active"

                         else
                            "wl-home-pill"
                        )
                    ]
                    [ Html.text
                        (if cueState.activeApplication then
                            "Taskbar: active lacquer pill"

                         else
                            "Taskbar: neutral running pill"
                        )
                    ]
                , Html.code []
                    [ Html.text
                        ("Focus: "
                            ++ (if cueState.windowFocused then
                                    "focused edge"

                                else
                                    "unfocused edge"
                               )
                            ++ " · Candidate: "
                            ++ (if cueState.switcherCandidate then
                                    "selected (uncommitted)"

                                else
                                    "none"
                               )
                        )
                    ]
                ]
            ]
        ]


viewOutcomeLabCard : OutcomeSample -> Html Msg
viewOutcomeLabCard currentSample =
    let
        ( statusTitle, statusExplanation, statusHref ) =
            case currentSample of
                SampleObserved ->
                    ( "Observed result: Hyprland reported window mapped on Workspace 2"
                    , "Only after an observed compositor snapshot arrives does Elm advance active window and workspace indicators."
                    , "./test-drive/index.html?scenario=taskbar"
                    )

                SamplePending ->
                    ( "Submitted receipt: launch accepted, awaiting observed window"
                    , "Elm shows non-blocking pending feedback without fabricating a focused window or reordering taskbar groups early."
                    , "./test-drive/index.html?scenario=launcher"
                    )

                SampleUnknown ->
                    ( "Unknown outcome: bridge timed out without confirming failure"
                    , "Ambiguous outcomes are never silently retried when side effects could duplicate launches or move the wrong window."
                    , "./test-drive/index.html?scenario=status-recovery"
                    )

                SampleRefused ->
                    ( "Refused receipt: validation or compositor check rejected request"
                    , "Explicit refusal preserves user draft input in place and explains why the action did not run."
                    , "./components/status-recovery/index.html"
                    )
    in
    Html.div [ Attr.class "wl-doc-card wl-home-card-stack" ]
        [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Interactive causality check · Show what is known" ]
        , Html.h3 [] [ Html.text "Intent, receipt, and observed outcome never collapse into one boolean" ]
        , Html.div
            [ Attr.class "wl-home-tabs"
            , Attr.attribute "role" "group"
            , Attr.attribute "aria-label" "Select host receipt state"
            ]
            [ viewToggleChip (currentSample == SampleObserved) (SelectOutcomeSample SampleObserved) "Observed"
            , viewToggleChip (currentSample == SamplePending) (SelectOutcomeSample SamplePending) "Submitted"
            , viewToggleChip (currentSample == SampleUnknown) (SelectOutcomeSample SampleUnknown) "Unknown"
            , viewToggleChip (currentSample == SampleRefused) (SelectOutcomeSample SampleRefused) "Refused"
            ]
        , Html.div
            [ Attr.class "wl-home-window is-focused"
            , Attr.attribute "aria-live" "polite"
            ]
            [ Html.p [] [ Html.strong [] [ Html.text statusTitle ] ]
            , Html.p [ Attr.class "wl-home-detail" ] [ Html.text statusExplanation ]
            , Html.a [ Attr.class "wl-feature-link", Attr.href statusHref ]
                [ Html.text "Inspect status & recovery behavior" ]
            ]
        ]



-- PRODUCTION ARCHITECTURE SECTION


viewArchitectureSection : Html msg
viewArchitectureSection =
    Html.section
        [ Attr.id "architecture"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "architecture-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Elm + Haskell architecture" ]
            , Html.h2 [ Attr.id "architecture-title" ] [ Html.text "One policy authority per decision" ]
            , Html.p []
                [ Html.text "Warlock-authored production code uses Elm and Haskell only. Elm owns every GUI element and interaction transition (with CSS owning presentation); Haskell owns system integration, Hyprland IPC, atomic storage, closed privacy-preserving failure diagnostics, and reviewed native WebKit custody." ]
            ]
        , Html.div [ Attr.class "wl-home-split" ]
            [ Html.figure [ Attr.class "wl-feature-shot" ]
                [ Html.img
                    [ Attr.src "./assets/brand/readme/elm-architecture.png"
                    , Attr.width 1200
                    , Attr.height 800
                    , Attr.attribute "loading" "lazy"
                    , Attr.alt "Diagram of Warlock's Elm policy engine connected through typed message contracts to Haskell runtime services and Hyprland observations"
                    ]
                    []
                ]
            , Html.div [ Attr.class "wl-doc-card wl-home-card-stack" ]
                [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "Verified 35-node / 68-edge model" ]
                , Html.h3 [] [ Html.text "Strict boundary between UI intent and compositor truth" ]
                , Html.p []
                    [ Html.text "Quint specifications model workspace navigation, file operations, settings CAS revisions, and effect lifecycles. Fuzz and property checks test opaque boundary contracts while ELM-ARC-024, ELM-DEL-014, and ELM-DEL-017 govern private UI origin, WebKit engine isolation, and secret-free ordinary diagnostics." ]
                , Html.div [ Attr.class "wl-home-actions-row" ]
                    [ Html.a [ Attr.class "wl-doc-button wl-doc-button-primary", Attr.href "./architecture/index.html" ]
                        [ Html.text "Explore interactive architecture" ]
                    , Html.a [ Attr.class "wl-doc-button", Attr.href "./get-started/index.html" ]
                        [ Html.text "Read Elm + Haskell guide" ]
                    ]
                ]
            ]
        ]



-- DESIGN LANGUAGE & FULL SITE DIRECTORY


viewGuideSection : Html msg
viewGuideSection =
    Html.section
        [ Attr.id "guide"
        , Attr.class "wl-band"
        , Attr.attribute "aria-labelledby" "guide-title"
        ]
        [ Html.div [ Attr.class "wl-section-head" ]
            [ Html.p [ Attr.class "wl-doc-eyebrow" ] [ Html.text "The design language" ]
            , Html.h2 [ Attr.id "guide-title" ] [ Html.text "Lacquer, in detail" ]
            , Html.p []
                [ Html.text "Explore foundations, token-driven styles, all 19 component specifications, and the preserved v6 reference catalog." ]
            ]
        , Html.div [ Attr.class "wl-doc-grid" ]
            (List.map
                (\card ->
                    Html.a [ Attr.class "wl-doc-card wl-home-card-stack", Attr.href card.href ]
                        [ Html.h3 [] [ Html.text card.title ]
                        , Html.p [] [ Html.text card.body ]
                        ]
                )
                guideCards
            )
        , Html.div [ Attr.class "wl-home-directory" ]
            (List.map viewDirectoryGroup directoryGroups)
        ]


viewDirectoryGroup : DirectoryGroup -> Html msg
viewDirectoryGroup grp =
    Html.nav
        [ Attr.class "wl-home-card-stack"
        , Attr.attribute "aria-label" grp.heading
        ]
        [ Html.h3 [] [ Html.text grp.heading ]
        , Html.ul [ Attr.class "wl-home-links" ]
            (List.map
                (\( linkText, linkHref ) ->
                    Html.li [] [ Html.a [ Attr.href linkHref ] [ Html.text linkText ] ]
                )
                grp.links
            )
        ]



-- FOOTER


viewFooter : Html msg
viewFooter =
    Html.footer [ Attr.class "wl-doc-footer wl-home-footer" ]
        [ Html.p [] [ Html.text "Warlock · Windows-style Elm + Haskell desktop for Omarchy and Hyprland." ]
        , Html.a [ Attr.href "./test-drive/index.html" ] [ Html.text "Browser test drive (simulated)" ]
        , Html.a [ Attr.href "./reference/catalog/v6/index.html" ] [ Html.text "Frozen catalog v6" ]
        , Html.a [ Attr.href "./get-started/contributing/index.html" ] [ Html.text "Contribute" ]
        , Html.a [ Attr.href "./get-started/licenses/index.html" ] [ Html.text "Licenses and attribution" ]
        , Html.p [] [ Html.text "Apache License 2.0" ]
        ]
