{-# LANGUAGE OverloadedStrings #-}
-- Source-bound component fixture only; Root compiles/runs. No clock, native
-- provider, authenticated issuer, process owner, or cleanup is asserted here.
module Main (main) where

import Control.Monad (forM_, unless)
import Data.Either (isLeft)
import Data.Text (Text)
import qualified Data.Text as T
import Warlock.Persistent.ActionDeadline
import Warlock.Protocol.Identity (Counter, parseCounter, renderCounter)
import Warlock.Protocol.StrictJson (Json(..))

check :: String -> Bool -> IO ()
check label condition = unless condition (fail label)

number :: Integer -> Counter
number value = case parseCounter True (T.pack (show value)) of
  Right counter -> counter
  Left reason -> error (show reason)

stringNumber :: Integer -> Json
stringNumber = JString . T.pack . show

selection :: Integer -> Integer -> Json
selection accepted end = JObject
  [ ("selectionId",JString "0123456789abcdef0123456789abcdef")
  , ("scope",JObject [("id",JString "1"),("generation",JString "1")])
  , ("publication",JString "1"), ("lease",JString "1")
  , ("controlId",JString "bar:applications"), ("clock",JString "CLOCK_MONOTONIC")
  , ("acceptedMonotonicNs",stringNumber accepted), ("deadlineMonotonicNs",stringNumber end)
  ]

replace :: Text -> Json -> Json -> Json
replace name value (JObject entries) = JObject [(key, if key == name then value else old) | (key,old) <- entries]
replace _ _ input = input

main :: IO ()
main = do
  -- Each deterministic case drives the existing Wire.parseSelection path.
  -- All expected deadlines are literal arithmetic independent of the reducer.
  forM_ [1..128 :: Integer] $ \seed -> do
    let accepted = 1000000000 + seed * 7919
        end = accepted + 2000000000
        label = "seed " ++ show seed ++ ": "
    ticket <- either (fail . T.unpack) pure (fromSelection (selection accepted end))
    check (label ++ "complete selection retained") (selectionData ticket == selection accepted end)
    check (label ++ "selection identity") (selectionIdentity ticket == "0123456789abcdef0123456789abcdef")
    check (label ++ "original D unchanged") (renderCounter (originalDeadline ticket) == T.pack (show end))
    check (label ++ "strictly before") (inspectAt (number (end-1)) ticket == Right BeforeDeadline)
    check (label ++ "at original D") (inspectAt (number end) ticket == Right AtOrAfterDeadline)
    check (label ++ "after original D") (inspectAt (number (end+1)) ticket == Right AtOrAfterDeadline)
    check (label ++ "observation cannot renew D") (renderCounter (originalDeadline ticket) == T.pack (show end))
    check (label ++ "mismatched D rejected") (isLeft (fromSelection (selection accepted (end+1))))
  let acceptedMax = 18446744071709551615
      deadlineMax = 18446744073709551615
      atLimit = selection acceptedMax deadlineMax
  top <- either (fail . T.unpack) pure (fromSelection atLimit)
  check "full-width deadline retained" (renderCounter (originalDeadline top) == "18446744073709551615")
  check "full-width just before" (inspectAt (number (deadlineMax-1)) top == Right BeforeDeadline)
  check "full-width equality" (inspectAt (number deadlineMax) top == Right AtOrAfterDeadline)
  check "zero observation refused" (inspectAt (number 0) top == Left InvalidClockObservation)
  check "overflow rejected" (isLeft (fromSelection (selection (acceptedMax+1) deadlineMax)))
  check "zero accepted rejected" (isLeft (fromSelection (selection 0 2000000000)))
  check "wrong clock rejected" (isLeft (fromSelection (replace "clock" (JString "CLOCK_REALTIME") atLimit)))
  check "noncanonical accepted rejected" (isLeft (fromSelection (replace "acceptedMonotonicNs" (JString "01") atLimit)))
  check "wrong field rejected" (isLeft (fromSelection (case atLimit of JObject xs -> JObject (("extra",JBool True):xs); x -> x)))
  putStrLn "action deadline source controls passed"
