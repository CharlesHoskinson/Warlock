# Direct `live-01.png` Visual Review, Canonical Website Status Patch & `EngineDesktopIdle.patch` Peer Check (`idle-delivery-1700`)

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`, run `warlock-20261031-setup`)
- **Timestamp (UTC)**: `2026-11-01T17:04:00Z` (governing cutoff `2026-11-01T17:25:00Z`)
- **Scope & Gate Discipline**:
  - Preparation draft and source-bound visual/peer review only — **not** production integration, native GUI acceptance, original-scenario acceptance, or release acceptance (`nativeAccepted: false`, `releaseAccepted: false`, `originalAcceptance: false`).
  - Preserves all `242` original requirements, `417` scenarios, `15 / 242` whole and `39 / 417` scenario historical source-scoped counts, original `28s` deadline `D`, `HOSTSTOP2`, `nativeOperations = []`, and all retained failure records (`haskell-cpu-1793549996721738691`, `engine-pid1-20261101T155313Z/run-01`, `run-02-trace`, and the `7.445s` `CredentialTransport TimedOut` idle exit in `engine-display-20261101T163508Z`).

---

## 1. Explicit Visual Inspection of `live-01.png` (Multimodal Tool Verification)

- **Explicit Tool Statement**: **YES — `live-01.png` (`324,023` bytes, `1280×800`, `sha256:0a9e25a720deb71751c9958bcbe810cbf760bc1ea6dcc6459c0e9c57fd3483ef`, captured at `61521.9489s`) was directly opened and visually inspected pixel-by-pixel in this session via multimodal `read_file`**, alongside `trial-result.json` (`sha256:c0bb0f804e545082d0c07adf570cbf829b783f5ea6a8a03584d5349e7624ab1a`), `backend.stdout` (`sha256:a4f4352bfe313caaf8ea626e0de8d13222d6d5fedae7211eafc2b0e4e9dac775`), `observations.json`, and `implementation/warlock/qa/evidence/engine-pid1-20261101/component-observation.json`.

### What Is Actually Visible in `live-01.png` (and How It Reconciles with `callbacks: 3, operations: 1`)
1. **Desktop & `Foot` Preservation (`1280×800` Omarchy Workspace 1)**:
   - Top Omarchy Waybar (`Sunday 09:39`, workspace `1` active) is intact.
   - Left half (`[12, 38]`..`[633, 788]`): pre-existing `foot` terminal (`PID 2095`) is completely undisturbed (`SETUP-DONE`, `sudo ufw allow 22/tcp`, `Rule added`, `Rule added (v6)`, prompt `~ ) []`).
   - Right half (`[647, 38]`, `size: [621, 750]`): undecorated Wayland window owned by same-ELF `warlock-ui-owner --engine-only` (`PID 100517`, `NSpid: [100517, 1]`, `xwayland: false`) with Hyprland's active cyan-blue focus border and **zero** GTK headerbar, titlebar, or native widget chrome.
2. **Top `HttpBar` Strip (`bView`, `621×72` slot; `.surface-bar` `56px` tall)**:
   - Rendered in Lacquer Night tokens (`#191516` / `#100E0E` surface, `#F6EFE8` text, coral/salmon accent):
     - **`Applications`**: **Enabled** (solid rounded coral-red border, crisp `#F6EFE8` bold label).
     - **`Task View`**: **Disabled** (dashed `#706562` border, muted `#BDB2AF` label).
     - **`Switch windows`**: **Disabled** (dashed `#706562` border, muted `#BDB2AF` label).
     - **Right status callout**: vertical coral left accent bar + wrapped 2-line notice `"Applications connected. Window controls unavailable."` (`Shell.elm:187` `applicationOnly = True`, `nativeOperations: []`).
3. **Lower `HttpPopup` Region (`pView`, `621×677`px) — Crucial Truthfulness Distinction**:
   - Separated from `.surface-bar`'s `56px` bottom border by a visible `16–17px` unstyled dark slot gap (`bView` `72px` height request + `1px` `cView` in `Mvp.hsc`).
   - Shows `<h1>` **`Choose a window`** (coral left accent bar) directly above status card **`Applications connected. Window controls unavailable.`**, followed by ~`560px` of blank `#100E0E` Lacquer canvas.
   - **Why no `.desktop` application rows appear on screen yet despite `operations: 1`**:
     - `backend.stdout` (`callbacks: 3, operations: 1`) confirms `HttpMain` completed `application-attached`, issued `CatalogRead` (`operations: 1`), and ingested the catalog snapshot into Elm policy state.
     - Because `physicalInputs: []` (no click on `Applications` yet), `snapshot.mode` remained `"closed"` (`popup = []`), which hits the final `else "Choose a window"` fallback in `implementation/warlock/src/SurfaceRenderer.elm:145`.
     - **Website Honesty Consequence**: Website status copy must state accurately that the VM diagnostic rendered the **Elm `Applications` bar, connected catalog status (`callbacks: 3, operations: 1`), disabled unavailable window controls, and popup heading (`physicalInputs: []`)**, rather than implying an open interactive launcher list or physical launch journey was already exercised.

---

## 2. Canonical Minimal Elm-Only Website Improvement (`SiteMainIdleDeliveryStatus.diff`)

- **Draft Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainIdleDeliveryStatus.diff`
- **SHA-256**: `3132bf6f1e3b6999cdd191a0743f92385c64e203516a8e6a1a16ab09bcafcea5` (`13,698` bytes, `144` lines)
- **Target File (Untouched on Disk)**: `/home/charl/code/Warlock/site/src/SiteMain.elm`
  - Pre-apply SHA-256: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (`1,663` lines)
  - Simulated post-apply SHA-256: `a50efc42103a1b2a63e99435bb0a3be6ee09f51fd27266083fb0e24d56dc9196` (`70,479` bytes, `1,663` lines — **exact 1:1 line-count preservation**)
- **Verification**:
  - `git -C /home/charl/code/Warlock apply --check .warlock-contributor/engine-pid1-drafts/SiteMainIdleDeliveryStatus.diff` -> **`exit 0` (zero fuzz)**; simulated forward + `-R` reverse apply round-trips to exact `f05a3768...`.
  - **Strictly minimal Elm-only scope**: updates **only** Elm string literals across `scopeCards`, `viewHero`, `readinessTiers`, `viewScopeSection`, `viewFeaturesSection`, `viewPrinciplesSection`, `viewOutcomeLabCard`, and `viewArchitectureSection`. Zero edits to `site/elm.json`, module exports, `Model`, `Msg`, `update`, DOM tag hierarchy, roving-tabindex focus wiring, or `supplementalCss`.
  - **1-to-1 Alignment with `component-observation.json`**:
    - Records `ELM-ARC-002` (`ownership-presentation`) as `partial` (component + app-only VM diagnostic; `nativeAccepted: false`, `releaseAccepted: false`).
    - Cites green report `1793550462035880723` (`10` Haskell suites including pre-namespace `DisplayEnvironment` capture, `5` held-exec cases, and SCM broker controls; `248` named Quint model tests with broad zeros and focused schedules kept separate).
    - Cites `engine-display-20261101T163508Z` (`same-ELF PID-1` `warlock-ui-owner` mapped Wayland window beside intact `Foot`, Elm `Applications` bar + connected catalog status, `callbacks: 3`, `operations: 1`, `physicalInputs: []`, `exit: 1` at `7.445s` `CredentialTransport TimedOut` after `5s` idle inside `28s` `D`, `providerCleanupQualified: false`, `nativeOperations: []`, desktop-only inter-frame idle readiness under immutable `D` pending).
    - Preserves `242` requirements, `417` scenarios, `15 / 242` whole and `39 / 417` scenario source-hash-bound historical counts, `HOSTSTOP2`, and retained failures (`1793549996721738691`, `run-01`, `run-02-trace`, and `7.445s` idle `TimedOut`).

---

## 3. Bounded Peer Check of `EngineDesktopIdle.patch` (`terra-engine` — Scoped to Specific Properties Only, Not Full Patch Approval)

Reviewed `.warlock-contributor/engine-pid1-drafts/EngineDesktopIdle.patch` (`181` lines) against `Channel.hs`, `Ingress/Internal.hs`, `Boundary/Internal.hs`, `Aggregate.hs`, and `Process/Internal.hsc` (**scoped strictly to the four narrow properties below — NOT full patch, security, close/fd-reuse, or retirement approval**):

1. **Coalesced-Frame Non-Overread Check (Scoped)**: `Channel.hs:152` (`pieces`) calls `P.receiveCredentialChunk reader sock (min remaining 65536)` with exact `remaining` bytes (`4` header, `size` body), never over-reading past a frame boundary into an application buffer. Any coalesced second frame remains unread in the kernel `AF_UNIX` `SOCK_STREAM` buffer for `threadWaitRead`.
2. **Reader-versus-Reader Gate Hold Check (Scoped)**: `receiveCredentialIngressWithIdle` holds `IngressOwner`'s `serial` `MVar` and `receiveCredentialFrameAfterIdle` holds `Channel`'s `readGate` `MVar` continuously across `waitDesktopReadable` and `receiveCredentialFrameHeld` (avoiding reader-versus-reader races and `MSG_PEEK` ancillary-data consumption).
   - **CRITICAL OPEN CONCURRENCY / LIFETIME CAVEAT (Not Qualified)**: `closeChannel` does **not** acquire `readGate`, and pinned `network-3.2.0.0` `Types.hsc:168-183` explicitly permits `close` concurrently with `S.withFdSocket`; therefore, concurrent `closeChannel` / numeric fd-reuse during `threadWaitRead` and retirement/API `D`-provenance remain **unqualified** pending security/lifetime and Root review.
3. **`desktopProfile` Branch & `min frameDeadline end` Arithmetic Check (Scoped)**:
   - First frame (`delivered == False`) uses unchanged `receiveCredentialIngress`.
   - Subsequent frames (`delivered == True`) only enter `waitDesktopReadable` when `profile == desktopProfile` (checked in both `Ingress/Internal.hs` and `Channel.hs`), preserving native-profile call behavior unchanged.
   - Once `waitDesktopReadable` wakes before `end`, `receiveCredentialFrameHeld (Just end)` stamps `start <- getMonotonicTimeNSec` and sets `deadline = min (toInteger start + 5000000000) end`, passing `min end deadline` into `G.dispatchUntil` — without heartbeats or synthetic frames.
4. **Design-by-Contract Defect Note (`Aggregate.hs:177` + `D` Provenance)**:
   - Line 177 calls partial `Prelude.read (deadlineAbsoluteNs deadline)` (`String -> Integer`) inside `pump` on every delivered frame (`Process/Internal.hsc:70-71`). In addition to resolving the API/`D` provenance boundary noted by `terra-engine`, avoid partial `Prelude.read` in production runtime code (`FUZZING-CONTRACTS.md`) via `Text.Read.readMaybe` (failing closed on `Nothing`) or a typed accessor.
