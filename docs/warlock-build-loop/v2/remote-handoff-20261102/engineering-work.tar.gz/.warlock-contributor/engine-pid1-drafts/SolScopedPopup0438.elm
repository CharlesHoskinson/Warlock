port module SolScopedPopup0438 exposing (main)

-- QA ONLY. The worker calls the actual Popup transition and retains its
-- COMPLETE model and EVERY typed effect for the source-pinned observer.
-- It does not observe or qualify actual Browser subscriptions/native delivery.
import Json.Decode as D
import Json.Encode as E
import Platform
import Popup
import PreviewPaintGate as Gate

port incoming : (D.Value -> msg) -> Sub msg
port outgoing : E.Value -> Cmd msg

type Msg = Input D.Value
type alias Model = { popup : Popup.Model, gate : Gate.Model }

initial : Model
initial = {popup=Popup.initial,gate=Gate.initial}

observe : String -> Model -> List Popup.Effect -> (Model,Cmd Msg)
observe name next effects =
    let (observedModel,observedEffects) = Debug.log "SOL_SCOPED_POPUP_COMPLETE_V1" (next,effects)
    in (observedModel,outgoing (E.object [("name",E.string name),("effects",E.int (List.length observedEffects))]))

update : Msg -> Model -> (Model,Cmd Msg)
update (Input raw) model =
    let decoder = D.map3 (\name kind value -> {name=name,kind=kind,value=value})
            (D.field "name" D.string) (D.field "kind" D.string) (D.field "value" D.value)
    in case D.decodeValue decoder raw of
        Err _ -> (model,outgoing (E.object [("error",E.string "unsupported QA request")]))
        Ok request ->
            if request.kind=="reset" then observe request.name initial []
            else if request.kind=="gate-near-exhaustion" then
                -- Fixed named QA GIVEN from an isolated, hashed fixture
                -- overlay; no arbitrary production constructor or mutator.
                observe request.name {model | gate=Gate.qaNearCounterExhaustion} []
            else if request.kind=="gate-queue" then
                let (gate,commands,requests) = Gate.queue request.value model.gate
                in observe request.name {model | gate=gate} [Popup.PreviewCommand commands,Popup.PaintRequest requests]
            else if request.kind=="gate-painted" then
                let (gate,commands) = Gate.painted request.value model.gate
                in observe request.name {model | gate=gate} [Popup.PreviewCommand commands]
            else
                let message = case request.kind of
                        "grant" -> Just (Popup.NativeGrant request.value)
                        "quarantine" -> Just (Popup.NativeQuarantine request.value)
                        "issued" -> Just (Popup.NativeIssued request.value)
                        "retry" -> Just (Popup.NativeRetry request.value)
                        _ -> Nothing
                in case message of
                    Nothing -> (model,outgoing (E.object [("error",E.string "unsupported QA transition")]))
                    Just actual ->
                        let (next,effects) = Popup.transition actual model.popup
                        in observe request.name {model | popup=next} effects

main : Program () Model Msg
main = Platform.worker
    { init=\_ -> (initial,Cmd.none)
    , update=update
    , subscriptions=\_ -> incoming Input
    }
