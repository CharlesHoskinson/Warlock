{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. One actual owner/root/scope and a separate guardian
-- per case. No source-level fake owner binding or successful native grant.
module QHttpExecutablePreparation026 (Mode(..),Case,newCase,runAcquire,finishCase,releaseBarrier) where
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try)
import Control.Monad (unless,void,when)
import qualified Data.ByteString as B
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..),requestSessionStop,tryPersistentStopDeadline)
import Warlock.Platform.Descriptor (ReadCustody,newReadCustody,QaReadState(..),qaReadState,qaReadChunkHook)
import Warlock.Platform.Executable.Internal
 (ExecutableLease,LeaseRole(..),LeaseState(..),RetainedPreparation(..),newExecutableLease,
  executableLeaseState,acquireExecutableLeaseRetained,issueReadyExecutable)
import Warlock.Platform.Resolver.Internal
 (Root,Pin,Link,ResolveError,RootAdmission,RootAdmissionFailure(..),
  LeaseCustody,ProbeCustody,newLeaseCustody,newProbeCustody)

data Mode = Positive | StopAfterFirstChunk deriving (Eq,Show)
type Acquire = Either RootAdmissionFailure (Either ResolveError RetainedPreparation)
data Case = Case PersistentOwner StopBudget LeaseCustody ProbeCustody ReadCustody ExecutableLease
 (IORef Bool) (IORef Int) (IORef [String]) (IORef Bool) (IORef Bool) (MVar ()) (MVar ()) (MVar (Either SomeException Acquire))
newCase :: PersistentOwner -> StopBudget -> IO Case
newCase owner budget = Case owner budget <$> newLeaseCustody <*> newProbeCustody <*> newReadCustody
 <*> newExecutableLease <*> newIORef False <*> newIORef 0 <*> newIORef [] <*> newIORef False <*> newIORef False
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ _ _ _ _ _ _ _ release _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("executable-preparation: " ++ label)))
within :: [AdmissionDeadline] -> String -> IO a -> IO a
within ds label action = do
 left <- minimum <$> mapM remainingMicros ds
 if left<=0 then ioError (userError (label ++ ": retain owner and guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure result

-- The host supplies actual validated image/root/pins/links/digest, an honest
-- same-owner Engine step and externally pre-rooted scope worker/guardian.
-- The monitoring wrapper delegates the unchanged action/result; it does not
-- manufacture permission, authority, error or an executable. The candidate
-- itself does not yet authenticate these three supplied custody objects.
runAcquire :: Case -> AdmissionDeadline -> RootAdmission -> Root -> [Pin] -> B.ByteString -> [Link] -> Integer -> B.ByteString -> IO ()
runAcquire (Case _ _ leaseOwner probeOwner readOwner executable denied afterDenied events parked used first release done)
 originalD admit root pins path links size digest = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case with nonempty actual image" (fresh && size>0)
 let monitored :: RootAdmission
     monitored action = do
      wasDenied <- readIORef denied
      when wasDenied (atomicModifyIORef' afterDenied (\n -> (n+1,())))
      result <- admit action
      case result of Left _ -> writeIORef denied True; Right _ -> pure ()
      pure result
     hook name = do
      atomicModifyIORef' events (\xs -> (name:xs,()))
      if name=="after" then do
       firstTime <- atomicModifyIORef' parked (\old -> (True,not old))
       if firstTime then putMVar first () >> readMVar release else pure ()
      else pure ()
 qaReadChunkHook hook
 result <- try $ restore $ within [originalD] "actual retained acquisition" $
  acquireExecutableLeaseRetained monitored leaseOwner probeOwner readOwner executable root pins path links size digest UiImage
 putMVar done result

-- First actual chunk has returned; stop is selected between actions. Positive
-- reaches Confirming yet legacy issueReadyExecutable cannot produce a grant.
-- Negative demands zero further admitted actions after the first refusal;
-- no automatic discard/close is allowed on that uncertainty path.
finishCase :: Case -> AdmissionDeadline -> Mode -> IO ()
finishCase c@(Case owner budget _ _ readOwner executable denied afterDenied events _ _ first _ done) originalD mode = do
 within [originalD] "first real returned image chunk" (readMVar first)
 before <- reverse <$> readIORef events
 reading <- qaReadState readOwner
 check "actual first chunk boundary" (before==["before","after"] && reading==QaReadReading)
 selected <- case mode of
  Positive -> pure Nothing
  StopAfterFirstChunk -> do
   stop <- within [originalD] "same owner real stop" (requestSessionStop owner budget)
   d <- tryPersistentStopDeadline owner
   check "first stop latched" (stop==StopLatchedBeforeLive)
   case d of StopDeadlineLatched deadline -> pure (Just deadline); _ -> ioError (userError "first StopD unavailable")
 releaseBarrier c
 result <- within (originalD : maybe [] pure selected) "actual acquisition return" (readMVar done)
 state <- executableLeaseState executable
 stopped <- readIORef denied
 count <- readIORef afterDenied
 observed <- reverse <$> readIORef events
 later <- tryPersistentStopDeadline owner
 case mode of
  Positive -> do
   check "actual prepared state, no denied action" $
    (case result of Right (Right (Right RetainedPrepared)) -> True; _ -> False) &&
    state==UncertainLease && not stopped && count==0
   legacy <- within [originalD] "legacy issuance must refuse Confirming" (issueReadyExecutable executable)
   after <- executableLeaseState executable
   check "legacy API cannot issue retained preparation" $
    (case legacy of Nothing -> True; Just _ -> False) && after==UncertainLease
  StopAfterFirstChunk -> do
   afterRead <- qaReadState readOwner
   check "unknown after entered read; no discard/close admitted" $
    (case result of Right (Left RootAdmissionUnknown) -> True; _ -> False) &&
    stopped && count==0 && observed==["before","after"] && afterRead==QaReadReading &&
    state==BuildingLease && later==maybe StopDeadlineNotLatched StopDeadlineLatched selected
-- Case retains all opaque custodians and any physically held descriptor; no
-- synthetic cleanup, fd-number guessing, native grant or retirement claim.
