# Sol next-journey handoff — physical Applications/search

2026-11-01 17:11 UTC continuation, inherited `sol-docs` session
`01a1947b-90dd-7ac0-9b96-477ca1e32bc2`. Root alone integrates and executes.
Claim hold `01M6C1G124DY2M4WQKD7A2BJ62` (120 minutes). Advisory source review;
no production input or protected execution. Root's frozen session 96285/report
1793552951595244964 was running at assignment, not a reported pass.

## Recommended smallest next observation

Use the frozen qualified tuple when root has its actual results. Retain the
original 28-second D. Observe a measured >5-second interval without physical
input or synthetic bridge activity, then:

1. Revalidate the actual owned engine/window, positive remaining D, foreground
   address, current monitor mapping and current Applications control hitbox.
   Physically click the enabled **Applications** control once.
2. Observe the actual Applications heading, loaded matching catalog response and
   enabled search field. Revalidate the fresh search hitbox and owning window;
   normally click **Search applications** in the popup widget.
3. Type a short ASCII token independently known to be absent from the pinned
   catalog fixture. Do not press Enter. Observe both the exact retained query
   and **“No matching applications. Change your search or Refresh.”** together.
   Recovery/search remain reachable; no application launches. Preserve screenshots
   and physical-event receipts. Stop at an ownership/deadline/occlusion failure.

Defer pins, Refresh, Escape and disabled-button tests until this short route is
observed; they are optional further observations, not prerequisites to this one.
Do not spend the 28-second window on a long sequence with assumed callback counts.
Use a successfully received current binding/request catalog snapshot, no pending
catalog read, and stable launch/pins state. Loading, failure or a pin/launch notice
may legitimately supersede no-match status. A short 4–8-character ASCII token
verified absent under actual Catalog.search reduces physical-event/fence cost.
Stored pin/unpin/reorder controls may remain visible despite zero search matches;
do not require an empty popup or use absence of visible entry rows as the oracle.

## Exact source facts and focus boundary

Current inspected GUI hashes (same published base392d1838fa042059361b589f8bbf9b657125026c;
later protected runtime inputs remain frozen separately):

| File under implementation/warlock/ | SHA-256 |
| --- | --- |
| src/HttpBar.elm | 74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8 |
| src/HttpPopup.elm | 4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354 |
| src/SurfaceRenderer.elm | d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98 |
| src/Surface.elm | c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb |
| src/Desktop.elm | 273622ad7a83a5538896b43831ffc705e3c38df9c1419ee0ec43cd5f81bec2c8 |
| src/Popup.elm | fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58 |
| haskell/runtime/ui/Warlock/Ui/Mvp.hsc | 57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6 |

| Current source | Relevant behavior |
| --- | --- |
| `HttpBar.elm:40-45` | Validated bar focus event invokes Browser.Dom.focus; Task.attempt discards success/error into Focused. It supplies no physical focus receipt. |
| `HttpPopup.elm:53-59` | Popup DOM focus is attempted only while composition is Idle; target is current presentation/publication/lease. |
| `Owner.hs:383-394` | Resolves exactly one enabled/focusOnly control and routes focus to its one matching role; this is not GTK seat-focus transfer. |
| `Mvp.hsc:816-862` | Window capture observes Escape and returns 0; ordinary typing propagates. Distinct bView/pView widgets; controller cView is untargetable/unfocusable. No gtk_widget_grab_focus for bar/popup is present. |
| `SurfaceRenderer.elm:124-132` | Search is an enabled input with id launcher-search, data-surface-field control:search, keyed by control identity; input/composition events are separate. |
| `Desktop.elm:1334-1337` | Search requires current stamp/open state, <=256 characters and no control characters. It updates query/page with no launch effect. |
| `Surface.elm:483` | Empty loaded query says “Type to search applications.”; zero matches selects the exact no-match text above, subject to earlier error/loading/notice branches. |

DOM focus is source-present; GTK keyboard focus after an Applications click is
unobserved. Do not assert it necessarily stayed in the bar as a measured failure.
A physical search-field click is an ordinary user action; visible typed query
and no-match response demonstrate useful delivery. That does not establish IME,
AT or keyboard-only transfer. Do not add a focus workaround or production change
before observing the actual route.

## Owning window and coordinates

**There is no current trial hitbox or live engine identity in this review.**
The prior actual window was outer engine PID100517, birth6151806,
NSpid[100517,1], ELF dev58/inode36472, address0x55fad1594fe0, at[647,38],
size[621,750]. Those are retained history, never next-trial authority. Use the
engine's outer PID reported by Hyprland, not broker selectedPid or inner PID1.

Before a new press/key, require a fresh unique owned mapped client matched to
current PID+birth+ELF identity+scope, and activewindow address/PID. Confirm actual
supported monitor extent/origin/scale/transform and unlocked state. Locate each
visible control from the current screenshot/current role geometry, inside the
current engine client. Historical centers (715,65), (820,252), (1106,306) and QMP
absolute values are illustrations only; never replay them. A point inside the
window is insufficient without the actual control hitbox. Recheck after pointer
motion and before button press if geometry changed. Release held buttons/keys
under the reviewed helper's finally path; do not leave an input held on abort.
Preserve current Foot identity and drafts; abort/wait on occlusion rather than
dismissing unrelated notifications or changing the desktop.

## Existing controller: concrete missing implementation

Captured controller:
`/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-display-20261101T163508Z/live-controller-display-01.py`
(SHA256 580e720e3d2510069f51d646b1c6c77465ae5c3301b4dce65d879982d80242a3).
It launches the owned scope, samples process/client identity, and captures images.
It has **no QMP input path, activewindow observation or per-event input fence**;
its result explicitly uses physicalInputs=[]. The plan is not implemented input.

Prior `live-09-source/vm-live-driver.py:125-163` provides a reusable QMP pattern:
gate -> move -> gate/unchanged geometry -> press -> release in finally. Its
fixture-specific observationCurrent.controls/hasFocus and IDs
physical-applications/physical-query, Chromium class/title, browserIdentity and
13-second reserve are not the actual three-WebKit-widget product. Reuse only
reviewed transport/ownership patterns adapted to real product evidence; do not
present those fixture focus fields as product observations.

The captured controller lacks a trusted last-complete-frame timestamp. Thus a
measured >5s **no-input/stable-window** interval is a narrower observation than
proven silence on the authenticated stream. Do not infer callback3 at2.45s merely
by subtracting five seconds from the old7.445s exit. If no actual stream boundary
is available, state this limit; do not fabricate telemetry or require a new
architecture. Component SCM tests and actual-window observation remain distinct.

## Screenshot-linked styling only

Directly viewed retained live-01.png (0a9e25a720deb71751c9958bcbe810cbf760bc1ea6dcc6459c0e9c57fd3483ef).
The app-only closed view says “Choose a window” above an otherwise empty body
while status says window controls unavailable. A later narrow Elm heading/guidance
change addresses that visible mismatch. Applications/status are readable and
unsupported buttons visibly disabled. This image does not prove transient white
flash, GTK overlay necessity or a provider defect.

Do not fold MvpLayout.patch's GTK packing/bar-height/min-size/overlay changes into
the pending frozen idle tuple or derive next coordinates from its uncompiled
layout. The newer AppOnlyHierarchyEmptyState.patch remains an unapplied draft.
Keep original keyed search/IME handling and source-bound regression scope when
root later chooses a styling change; this journey can proceed on current layout.

Concrete new defect in that unapplied styling draft: its applications-empty
fallback calls the page no-match whenever snapshot.popup has no entry:* row.
Surface.elm:325-342 paginates pin/jump/reorder prefix controls before entries, so
a page can contain no visible entry row while the catalog has matches. Its
fallback can also conflict with canonical pin/launch failure notices. Render
supplied no-match state/status; do not derive a second search policy from a
truncated visible page. This finding was sent to Gemini-GUI and root as
01M6C1RCTZZAEB4KM1Z98W8TP8 / 01M6C1RCYESHPXESCZNEDDC9H9.

## EARS and result limits

ELM-UI-005 search-no-match has the exact oracle: **“no-match message and query
remain reachable without launch”**, given a query/catalog fixture. The original
requirement also covers generation/ranking, initial/loading/unavailable/refusal
recovery. One named physical no-match observation does not close the whole
requirement, AT or IME. Active ELM-ARC-002 ownership-presentation still requires
created **and retired** surface ownership; seeing the window/input cannot certify
provider/backing retirement. UX003/UX029 require real launch evidence; UX004
needs two identities, reorder and retained order after restart, not one pin.

EngineEntrypoint.hs:323-329 requests local stop at remaining<=1second. That is
implemented intent, not guaranteed exit0, passed:true, cleanup:true, auth:Nothing
or observed empty cgroup. Record actual values and unknown membership faithfully.
Keep original 242/417, historical15whole/39scenarios, failures, original D,
HOSTSTOP2, nativeOperations=[] and unqualified provider cleanup intact.

## Peer coordination

terra-vm responded with exact controller and revised draft c8fd8489 to distinguish
no-input observation from unproven stream silence. q-front provided exact query,
composition and no-match semantics, and warned against fixed callback totals.
Gemini-GUI confirmed source-only GTK/DOM focus distinction, exact source text and
no-match-first priority. Omarchy draft03e56 initially supplied historical fixed
coordinates/timestamps, notification dismissal and presumed cleanup success;
those specific claims were challenged to its owner and root before use. Await
the owner's correction rather than silently accepting them.

No protected compiler/model/native/GPU/VM or agent/service/key action was run.
Only this claimed ignored draft is authored. Doctor ran once with six checks
passing; recv/claims used inherited identity. No forbidden checker or credentials
were read. Recurring role remains required; terminal status will be handed to
root explicitly before ending the bounded turn.

Root response at 17:14:19 confirms the guidance is adopted: no fixed click
coordinates, invented callback totals or presumed cleanup success; current
window/PID/birth/D checked per event; no-input idle is kept separate from the
real-SCM component's measured sender silence. Current 345 production/test inputs
had compiled, models were still running. Integrated idle model has 25 named
tests, correcting earlier draft counts. Existing retire fixture encourages
reuse and preserves an unrelated sentinel; root will not claim actual FD reuse
without a descriptor witness. None of these statements is a full protected pass.

### 17:18 priority change: final-frame fixture fence

Root reports protected1793552951595244964 RED: nine other suites including idle
SCM controls passed; 273 named model cases passed. Public-library ui-origin
observed4frames/1op; production CLI child passed92checks/four owner commits but
backend observed3callbacks/1op and final-frame EndpointChanged after retirement.
No full check pass or VM readiness follows from those partial results.

At root's request, inspected actual fixture change in
`runtime/test-ui-origin/Main.hs` SHA256
9ea25d4d20a7cc6c63f865b4bafd20f1356d021d1f3ca58ef5b9d78df7a72bed.
Move existing request7 from second commit to fourth newerCommit and move its
unchanged authenticated application-catalog binding/request7 poll immediately
after fourth HTTP204. Four accepted commits and one operation remain unchanged;
topology/current/stale event checks depend on projection/scope/lease, not earlier
catalog content. Invalid-suffix request7 cases still refuse before dispatch.
RetireThrows adds its separate request97, preserving5frames/2ops. QueueBound is
unchanged. Backend.hs188 increments callback before request handling, and153
increments operation before its checked reply, so correlated response7 witnesses
fourth callback admission and operation rather than only HTTP transport success.
This supports the minimal source correction; actual root rerun remains required.
It proves no provider cleanup. Review sent as01M6C1XZHYWP0ZBRD0QSXRSQXH and
counter-order follow-up01M6C1YKZ37HC1WRRQ06JTJ9BR.
Root17:21:51 confirms the move is implemented and protected rerun22834/report
1793553496966127943 is in model stages. No extra D/frame/op or production guard
change. Previous RED remains retained; no new full GREEN claim follows.

Website peer1713 request was answered narrowly on evidence/tester copy: 248 named
model **tests**, not248models; ten-suite green belongs to published392d tuple;
current idle correction was RED. Link wording should read current status rather
than promise verification; HOSTSTOP2 is preserved, not an OPEN acceptance gate.
No general website design approval or production edit was performed.

At17:22, the original problematic drafts still hashed exactly as reviewed:
AppOnlyHierarchyEmptyState a5bb1f057587109ad97715de8f82aee483936f8e50e8518af0c5a1773ee21a49;
Omarchy1700 03e56cb5e797567c89278b882befbe509a9e2347d0a8694b86464fcc78f31038;
SiteMain1713 101921045b1890fb2033c98e99a47762daa6dfcee23bab04ccf2835e0293bc33.
Omarchy now claims distinct1719 driver/revised-journey drafts. A claim is not a
handoff or executable readiness; exact completed content/hash has been requested
for read-only review. No peer draft is changed by this advisor.

At17:24:42, gemini-site responded with corrected v2 patch
1ac2f9d6ed991783ea58d0df21d5f86bbcebecd5ce332f549e99c3c96175a77c.
Direct source inspection verified all six requested copy corrections and the
rationale's unexecuted-CSS/static-token-math scope. The specific copy critique is
addressed; no compiler/browser/accessibility/style acceptance is implied. Root
was notified as01M6C2959R6FRNJXF8D77NRB2J.

### 17:27 revised physical driver review

Omarchy completed a new skeleton083c4db2322ed1c683eb7444bdc11e22ac430d7cacdca12767e29fb1c552fa0f
and corrigendum48c53bd0e63693b47ac4da0088a497aa69ca148e06787a443c0d6175a6546c1f.
The skeleton uses fresh screenshot/operator hitbox, required engine PID/birth/
window address, real monitor state, motion/re-gate and button release in finally;
it removes presumed green cleanup and notification dismissal. Source-only review
of probe, verify_fence, click and key paths found these remaining concrete limits:

* Default minimum remaining3.5s is shorter than QMP subprocess timeout5s, while
  localStop can begin at D-1s. A successful pre-fence does not guarantee a queued
  command arrives before the owned window disappears. Recheck host elapsed time
  immediately before dispatch, reserve command/release/local-stop time and validate
  finite bounded duration arguments. Do not claim hard scheduler/arrival bounds.
* send-keys invokes verify_fence without hitbox; the top/overlay occlusion branch
  is therefore skipped. activewindow alone is not an observed search-field or
  layer-free keyboard-seat focus receipt. First journey should use the freshly
  clicked search target, current screenshot/layer evidence and visible query,
  with printable keys only. Return/Tab/Escape are unnecessary for no-match.
* proc_display_env reads the complete `/proc/PID/environ` before filtering display
  variables. Under the user's no-environment-read constraint, use explicit reviewed
  display configuration instead; this advisor read source only, no environment.

Findings sent to owner01M6C2CYNWTA8434RM4P8G02GC and
root01M6C2CYS3DKR0WTMNZZBZZDJ6. No execution or full driver approval follows.
The retained launcherPID100509 is the actual backend after exec, as confirmed
against controller-state/observations; no launcher/broker lineage defect is
claimed. Further owner fixes require a new exact source review, not silent
promotion of this skeleton.

terra-vm's final source-only response adds concrete083c4 issues: os.walk lacks
onerror and unreadable proc rows are skipped while cgroupKnown may become true;
missing original baseline process record skips birth comparison; pgrep errors
above1 are treated as absent; missing/unknown layer schema or geometry can be
treated as clear; expected fresh scope/ControlGroup should bind to the launch
receipt. Root and owner received these specific findings. Its no-input duration
also uses caller-supplied first-map time/two snapshots, not a continuous witness.
These are unexecuted source findings, not new acceptance councils. Optional
Refresh/Escape are outside this recommended minimal route; no new general user
authorization restriction is inferred. Retain release-in-finally rather than
leaving a held input on failure; root must review the actual delivery bounds.

Terminal17:28UTC: concrete draft and received peer responses handed to root;
final own claim release/presence-down follows. No new full protected GREEN or
physical-input result received by this advisor. Recurring role remains required;
root must revalidate actual CLI/terminal status before resuming this same session.
No permanent liveness is asserted. Gemini-GUI's false-no-match correction remains
unreceived; do not promote its old draft. Root remains sole coordinator/executor.

Bounded AgentBus wait returned75/connection lost again at17:16; no service/key
changes or wait retry loop. Independent source review continued and found the
styling no-match inference defect above. Authenticated sends/recv remain the
coordination route; silence is not proof that a peer is active or terminal.
