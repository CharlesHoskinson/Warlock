# DesktopPolicy complete-state review and initial GIVEN partition

Source-only preparation; no compiler/test execution, no acceptance. Graph lookup warned stale contributor records/STATE; source controls. Initial tree below is independently transcribed from Elm initial definitions, not a captured reducer result. It is source-level notation, not a claim that an observer serializes constructors correctly. Coordinate encoding with q-origin. `Counter("0")` denotes the opaque `UInt64.Counter` constructor holding the string `"0"`; do not use JS number for counters.

## Initial Desktop.Model

Source: `implementation/warlock/src/Desktop.elm:38` and `:207`. The `windows` and `launch` subtrees are the terra-engine partition. Every other field follows exactly:

```text
choice=Nothing, choiceNotice="", popupOrigin=KeyboardEntry, returnFocus=Nothing,
menuOrigin=Nothing, ownerScope=Nothing, ownerExhausted=False,
launchFromApplications=False, applications=Nothing, applicationPage=0,
presentationCapacity=False, query="",
pins={snapshot=Nothing,pending=Nothing,notice=""},
pointer={observation=Nothing}, shortcuts={binding=Nothing,seen=Counter("0")},
jumpList={snapshot=Nothing,pending=Nothing,spent=[],notice="Reading application actions…"},
jumpEntry=Nothing,jumpOpening=False,jumpExpected=Nothing,jumpBack=False,
files={snapshot=Nothing,draft="",pending=Nothing,spent=[],notice="Loading Files…"},
filesOpen=False,filesOpening=False,filesExpected=Nothing,
systemMenu={snapshot=Nothing,pending=Nothing,spent=[],notice="Loading system state…"},
systemMenuOpen=False,systemMenuOpening=False,systemMenuExpected=Nothing,
systemMenuConfirmation=Nothing,
notifications={focused=Nothing,outcome=Nothing,policy={doNotDisturb=False,interruptCritical=False},snapshot=Nothing,pending=Nothing,spent=[],notice="Loading notifications…"},
notificationsOpen=False,notificationsOpening=False,notificationsExpected=Nothing,
motionExpected=Nothing,
motion={preferences={snapshot=Nothing,draft=System,pending=Nothing,notice="Reading motion preference…"},observation=Nothing,pending=Nothing,applied=Nothing},
settings={outcome=Nothing,snapshot=Nothing,draft={theme=Night,textScale=100,effectsOff=False,reducedTransparency=False},pending=Nothing,notice="Loading settings…"},
settingsOpen=False,settingsOpening=False,settingsExpected=Nothing,settingsHelp=True,
shortcutPreferences={snapshot=Nothing,inventory=Nothing,draft={applications=Undecided,system=Undecided,notifications=Undecided},pending=Nothing,conflicts=[],notice="Loading shortcut choices…"},
shortcutExpected=Nothing,open=False,overview=False,overviewWorkspace=Nothing,
overviewRecovery=Idle,workspaceInventory=Nothing,
workspaceNavigation={binding=Nothing,ready=False,request=Counter("0"),generation=Counter("0"),record=Nothing,recovering=False,origin=Nothing,returning=False},
overviewTransfer=Nothing,snap=Nothing,
switcher=Switcher.Model {generation=Counter("0"),phase=Idle,steps=Dict.empty,released=Nothing,ready=False,entries=[],ring=[],origin=Nothing,selected=0,baseline=Nothing},
nativeSwitcher=Nothing,switcherOrigin=Nothing,switcherExpected=Nothing,switcherHistory=Nothing,
request=Counter("0"),presentation=Just Counter("0"),expected=Nothing,adapterNotice=Nothing,
catalogFailure=Nothing,catalogOpening=False
```

Distinguish identically named constructors by their Elm module/type, including `Idle`. `…` is the literal U+2026 character. `Dict.empty` is an empty Elm dictionary, not a missing field. Constructor representation remains observer-schema-dependent. Sources for defaults: Pins.elm:11, PointerOwnership.elm:8, Shortcuts.elm:9, JumpList.elm:11, Files.elm:13, SystemMenu.elm:18, Notifications.elm:16, Motion.elm:16, MotionPreferences.elm:12, Settings.elm:14-16, ShortcutPreferences.elm:13-14, OverviewRecovery.elm:12, WorkspaceNavigation.elm:15, Switcher.elm:23, UInt64.elm:9-13. Never use this given as a post-transition expected value without independently specifying every actual change.

## Full reachable state and effect boundaries

- `DesktopPolicy.Model` is `{controller:OutputController.Model}`. `OutputController.elm:12-39`: opaque wrapper contains announcements, controller, revision, highest, views, locations, selected, batches, batchExhausted, capacityRefused. Scope is two counters. Each batch carries scope, revision, publication, lease, binding, wire (exact string), observations, operations, catalogs. Preserve list order and exact wire string.
- `SurfaceController.elm:18` opaque wrapper: recovery, desktop, publication, lease, exhausted. Recovery has slots, legacy, informational; slots have record, proof, actionRequest, geometryRequest, action, geometry, released. See `ReconciliationTracking.elm` and `ReconciliationFrame.elm` for full nested records, bindings, protocol and original request values. A projected frame is not a full-state observer.
- `Desktop.elm:38-102` is the complete record of top-level fields, including choice, ownerScope, launch, applications, pins, pointer, shortcuts, jumpList, files, systemMenu, notifications, motion, settings, shortcutPreferences, overview, workspaceInventory/navigation/recovery/transfer, snap, switcher, request/presentation/expected and notices. Capture all of each nested model, not just rendering fields. Observation and intended/pending state are separate.
- `TaskbarShell.elm:9-15`: shell, picker, generation, menus. `Shell.elm:20-50`: applicationOnly, decoderRefusal, reconciliationFull, effects, binding, request, expected, phase, reconnecting, notice, geometry, geometryCaps, geometryExpected, geometryAttachExpected, attachNeeded, recoveryFailure, issued, notificationQueued, projectionRetryQueued, transportRefused, deferNotifications. `Effects.elm:10-22`: connected, observed, request, generation, transaction, unresolved. Transactions retain full intent, status and effectProtocol. `ActionProjection.Admitted` contains hidden Dict of highest counters as well as admitted windows; extracting only displayed windows loses authority state.
- `MenuBridge.elm:38-64`: opaque Model has menu, router, provider, prepared, preparedSerial. Prepared includes dispatch, local, originalBinding, menuId, action, captured, legacyWindows, geometryCaps, token, legacyRequest, geometryRequest, legacyReady, geometryReady. `preparedSnapshot` is a strict projection. `Menu.elm` contains private typed IDs, binding/target, menu, next IDs, outstanding, releasedUnknown, lastOutcome, invalidated, retiredOutputs, exhausted. `ReceiptRouter` retains complete entries and original native intents, not only count. `Provider.Snapshot` retains binding, items, title, providerId, capabilityGeneration, context, incarnation, geometry.
- `Launch.elm`: opaque Model host/snapshot/revision/request/phase; phase distinguishes Idle, Pending String Intent, Settled Intent ResultState; Intent includes request/lifetime/generation/entry; selection, pending token and acknowledgement are distinct opaque constructors. Catalog snapshot has lifetime/generation and Dict of full entries, including identity/name/iconHint/wmclass/genericName/keywords. Pins tracks snapshot, pending confirmation and notice.
- `Switcher.elm`: opaque model generation, phase, Dict steps, released, ready, entries, ring, origin, selected, baseline. WorkspaceNavigation keeps binding/ready/request/generation/record/recovering/origin/returning and full intent/status; OverviewRecovery has distinct Idle/Choosing/Issued/Returning constructors and full origin/intent. Snap, GeometryProjection and GeometrySizePolicy retain actual Float geometry and policy, not merely region labels. Treat finite values and signed zero deliberately; reject unsupported representations instead of rounding or omitting.
- Other embedded records must retain all fields: PointerOwnership observation; Shortcuts binding/seen; JumpList snapshot/pending/spent/notice; Files snapshot/draft/pending/spent/notice; SystemMenu snapshot/pending/spent/notice; Notifications focused/outcome/policy/snapshot/pending/spent/notice; Motion preferences/observation/pending/applied; Settings outcome/snapshot/draft/pending/notice; ShortcutPreferences snapshot/inventory/draft/pending/conflicts/notice. Their source type declarations define complete nested snapshots/intents and variants. Counters are strings, binding is an opaque triple of counters, and IDs/tokens have explicit constructor identity. Dict contents, Nothing versus Just, constructors, list order, full-width values and exact strings matter.
- `DesktopPolicy.elm:13-15`: `Msg = Incoming D.Value | Deadline Desktop.Msg | TransportLost`; `Effect = Publish E.Value | Delay Float Desktop.Msg`. `Publish` is full packet JSON including whole commits, request, focus and data, not a tag. `Delay` needs exact duration and complete message including private token/intent. `effectsFor` maps prepared/choice/workspace timers to 2000 ms, launch deadline to 10000 ms. Inspect actual reachable constructors at `Desktop.elm:120-205`; nested `Desktop.Msg` can itself contain raw JSON and recursively `SurfaceEntry`. Controller/internal Desktop effects are filtered/transformed; compare actual public policy effects, ordered and complete.
- `Json.Decode.Value`/`Json.Encode.Value` are opaque runtime values in messages/effects, so `Debug.toString`, tag-only views and selected public projections do not prove full fidelity. JSON comparison must preserve all values and types, reject unsupported/unobserved values, and not silently coerce full-width counters to JS numbers. No GPU data or function-valued field was identified in the inspected state declarations; this is not a completed proof over all transitive reachable payloads. A compiled fixture observer requires source/artifact hash binding and explicit coverage/rejection of unknown values, with no reducer mutation.

## Selected source hashes (SHA-256)
018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e  implementation/warlock/src/DesktopPolicy.elm
fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae  implementation/warlock/src/OutputController.elm
2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998  implementation/warlock/src/SurfaceController.elm
273622ad7a83a5538896b43831ffc705e3c38df9c1419ee0ec43cd5f81bec2c8  implementation/warlock/src/Desktop.elm
eeb91d15cab97c94bf12ef3d1e25f513ac6c037774bef5150867eb01c6f86c26  implementation/warlock/src/TaskbarShell.elm
6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094  implementation/warlock/src/Shell.elm
80c574e8c564c28a1fb11f1f89bb5bfa7ac97a92474bbf027a737324bb2a82cd  implementation/warlock/src/Effects.elm
ec8f531b9437e493f9b29fe1e16d678cd388f560a83ca873448630bbde459b25  implementation/warlock/src/MenuBridge.elm
c40fcfa24bf9d48044ccbe2c08df0abb7d8b94ee04111776234ecd88792ff4f0  implementation/warlock/src/Menu.elm
c6c5bc025cddd2bb7a0e8daa22ee3ff0cddff36e37131095130215d5e85825d0  implementation/warlock/src/ReceiptRouter.elm
dcd7260248ccb0b5bc6001c49319dd51af8c2fae98888919a308ac025ed273a2  implementation/warlock/src/Launch.elm
ea57b2c448f5f510ceef256bc0670bd464fc997d29d144741ab1ce3fd004d709  implementation/warlock/src/OutcomeAnnouncements.elm
84482d1bb84160e3bd9e026b2043635c35b76422d6e9066f703411f784b29bf9  implementation/warlock/src/ReconciliationTracking.elm
d13f4d63327eae4a80052252c8ba1f1e40db0f69954b46470ccff248e5ba0e7c  implementation/warlock/src/Settings.elm
d8c1a63f199612161e078e0f6c7f75cbbfa190953e19325e50169debc425dcec  implementation/warlock/src/ShortcutPreferences.elm
7523cc13bf794c126cee2d39541d9fbae062ec3b420d5898eed6380792ec3061  implementation/warlock/src/Switcher.elm
0c32ee015c1882d9d754d9dcda5a454e8a1d71f85d3bbd60d9280dd564531baa  implementation/warlock/src/UInt64.elm

## Nested payload detail for observer review

Names below are source record fields, not a prescribed JSON encoding; all enclosing constructors and Maybe/List/Dict structure remain required.

- `Effects` snapshot: context, scene. Transaction: intent, status, effectProtocol. Intent: request, generation, incarnation, operation, context. Status Pending/Committed/Refused/Cancelled/Unknown; operation Minimize/Restore/Activate/Maximize/RestoreGeometry/ExitFullscreen/SnapPlacement proposal/TransferWorkspace proposal/Pin/Unpin. ActionProjection window: incarnation, label, minimized, owner, application, available, attention. Admitted scene also carries counters and hidden highest-counter Dict.
- `Desktop` focus target: binding, destination, output; destination TaskbarGroup String or OverviewOpener. Native chord: generation, roots, history, origin, steps, released, cancelled, consumed. Choice: chord, binding, output, root, application, token, placement, transfer. ChoiceToken and ViewStamp have private constructors; don't flatten to display strings.
- `JumpList`: snapshot service/revision/entry/name/available/reason/actions, with action id/label/kind; pending request/intent, where intent service/revision/entry/action; spent is full intent list. `Files`: snapshot service/revision/available/reason/peer; peer pid/start/instance/target/visible; pending request/intent, intent service/revision/target; spent stores full intents. `SystemMenu`: snapshot service/revision/volume/network/power/session; intent service/revision/operation/value; operations Volume/Mute/Network/Suspend/Reboot/PowerOff/Lock/Logout.
- `Notifications`: policy doNotDisturb/interruptCritical; entry urgency/id/incarnation/producer/app/summary/body/state/actions, each action key/label; snapshot service/revision/available/reason/entries; target service/id/incarnation/producer/action/verb. Urgency Low/Normal/Critical; focused/outcome/pending/spent and notice remain observable.
- `Motion`: observation serial/profile/source; pending binding/request/profile; profile Reduced/Full. MotionPreferences override System/Reduce/Full, snapshots and pending. `Settings` values theme/textScale/effectsOff/reducedTransparency; theme Night/Dawn/HighContrast; snapshot schema/revision/values; outcome Saved/Refused/Unconfirmed. ShortcutPreferences choices applications/system/notifications with Undecided/Keep/Default/Alternate; inventory fingerprint and three rows; each row defaultChord/alternateChord/defaultAvailable/alternateAvailable/active. Do not collapse desired draft into observed snapshot.
- `WorkspaceNavigation` record binding/intent/status/reason; intent request/generation/source/destination/context, context lifetime/epoch/output/revision; rows identity/generation/monitor/outputOwnershipGeneration. Snapshot binding/request/sequence/revision/output/active/rows. Navigation status Pending/Unknown/Committed/Refused. OverviewRecovery origin binding/root/workspace. Transfer proposal source/sourceGeneration/destination.
- `Snap` choice snapshot/target/selected; proposal region/geometry/monitor/outputOwnershipGeneration/workAreaRevision/workspaceGeneration/context; region LeftHalf/RightHalf/TopLeft/TopRight/BottomLeft/BottomRight. GeometryProjection window incarnation/owner/workspace/workspaceGeneration/monitor/outputOwnershipGeneration/workAreaRevision/workArea/logicalGeometry/visualGeometry/nativeMode/clientMode/minimized/floating/grouped/fixedSize/constrainedSize/eligible/placementKnown/maximize/restoreGeometry/sizePolicy/pin. GeometrySizePolicy inputs rawMinimum/rawMaximum/layoutMinimum/layoutMaximum/origin/topLeft/bottomRight/scale; projection logical/visual/real/configure. These are not captured by a title or display-only rectangle.
- Reconciliation frame context lifetime/epoch/output/revision; record schema/effectProtocol/binding/intent/status; proof protocolVersion/kind/retirementProtocol/operation/binding/requestId/queriedBinding/sequence/grantState. ReceiptRouter entries retain local, binding and key; key includes native binding, intent and protocol. UnsentOperation key binding/protocol/intent. AdapterNotice source/binding/request/service/revision, source Applications/Notifications/Files/ApplicationActions/System/Settings/Motion/Shortcuts/Windows.

The complete raw compiled-object strategy is provisional: developer-facing debug representations (including Dict and runtime JSON) depend on compiler build. The proposed observer must reject unrecognized functions, opaque/non-data runtime values and unsupported representations; independently validate representation and source/artifact hashes before claiming full-state fidelity. No raw-value capture may supply expected oracle state.
