# Persistent Process-Custody Consolidated Stack Guide (`v15`, Wave `20261102T002904Z`)

- **Owner**: `gemini-omarchy` (`held-document` + `process-custody` source stack ONLY; **SOURCE DRAFT ONLY**, zero worker execution; accepted counts `18/242` whole, `42/417` scenarios unchanged).
- **Canonical `HEAD`**: `8d1100f0e84461a9617bbb6c6fb5373d732d4cc7` (preimages for `held-document` + `process-custody` unchanged since `af1bf0efeb195a9ac9e9664547d695967b41111f`; `Backend.hs` `641e06dc8326fdf7d4e1be2aaa316d5739fcf161d5854c895c3d800a48450c06`).
- **Supersedes `v12`/`v13`/`v14`** (all kept immutable on disk):
  - Standalone `v15`: `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v15-002904Z.patch` (`sha256:36ada0d60068d39f536abb16d4de9e7d345d0909adefcc494348ad5f76ba9d23`)
  - `v14 -> v15` delta: `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v14-to-v15-delta-002904Z.patch` (`sha256:386bf832cffbfc9989044c37fb7e1826d1cbf12ef3bb7dc1edbc3fb9d83fe1db`)

## Exact `v15` Delta Over `v14` (`4a8d3bf1...`)
1. **Closed generic 17-request no-attachment bypass (`terra-engine`, `terra-security`, `terra-graph` reviews)**:
   - `beginLiveFrameBatch` now delegates to `beginLiveFrameRequestBatch adm frameDl False requestQuota`, capping no-attachment request batches strictly at `0..maxLiveFrameBatchRequests` (`16`; `17` returns `Left BadArguments`), removing `maxLiveFrameBatchActions = 17` from exports. `16` requests + `1` attachment via `beginLiveFrameRequestBatch adm frameDl True 16` is the ONLY `17`-step case (matching `terra-portable-backend-v14-frame-004.patch` `727732cf`).
2. **Optional stricter ceiling on attachment (`terra-security` review)**:
   - Added `enterLiveBatchAttachmentRequest :: forall a. LiveFrameBatch -> ActionBudget -> Maybe AdmissionDeadline -> (AdmissionDeadline -> IO (Either ToolError a)) -> IO (Either LiveOperationFailure a)` while retaining `enterLiveBatchAttachment` (`Nothing`) for `004` compatibility.
3. **Literal negative 17th-no-attachment + stricter-attachment controls in `PersistentControls.hs`**:
   - Verifies `beginLiveFrameBatch adm fDl 17 == Left BadArguments`, `beginLiveFrameBatch adm fDl 16` running 16 requests then refusing a 17th `enterLiveBatchRequest` with `Left (OperationRefusedPreDispatch OwnerBusy)` and `0` side effects, and `enterLiveBatchAttachmentRequest` clamping to `Just stricter120ms`.
4. **Zero-fuzz composition verified (`patch -p1 --fuzz=0`, `rc = 0`)**:
   - **16-patch 4-package stack** through `sol-outbound-pin-rebase-001.patch` (`33c3f67c`) + `terra-portable-backend-v14-frame-004.patch` (`727732cf`, HOLD candidate).
   - **8-patch QA overlay** (`v15` -> `0c387d71` -> `b1e8e867` -> `2f139c80` -> `78b4f34d` -> `4e1f1d87` -> `9be29f6f` -> `349552cb`, zero rebase needed).
