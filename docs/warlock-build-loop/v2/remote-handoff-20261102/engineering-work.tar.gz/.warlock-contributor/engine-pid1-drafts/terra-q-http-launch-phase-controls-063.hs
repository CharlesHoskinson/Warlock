{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. One actual isolated Backend/guardian per mode.
-- Product calls run only on Case-retained workers and Case-retained result
-- cells; timeouts watch readMVar, never cancel a product action.
module QHttpLaunchPhase063 (Mode(..),Case,newCase,runCase,retainedWorkers,retainedResults) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled),IOException,SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef
import Data.Text (Text)
import System.Directory (doesFileExist)
import System.FilePath (isAbsolute)
import System.IO.Error (ioeGetErrorString)
import System.Timeout (timeout)
import Warlock.Backend
 (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,loadPersistentBackendConfig,
  runPersistentBackend,requestPersistentBackendStop,retirePersistentBackend,
  qaSetConfigOwnerHook,qaSetConfigReadHook,qaSetActorBeforeCAS,qaSetActorAfterCAS,
  QaLaunch(..),qaLaunch,qaBootstrapReadiness,qaStopDeadline)
import Warlock.Bootstrap (newCurrentSessions,PersistentBootstrapReadiness(..))
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = NoConfigStop | ConfigStop | ConfigReadingStop | ActorCASAfterStop | ConfigInterrupted deriving (Eq,Show)
type ConfigResult = Either SomeException (Either Text ())
type ActorResult = Either SomeException PersistentBackendRun
type StopResult = Either SomeException P.StopReceipt
type RetireResult = Either SomeException Bool
data Case = Case PersistentBackendOwner (IORef Bool) (IORef [ThreadId])
 (MVar ConfigResult) (MVar ActorResult) (MVar StopResult) (MVar RetireResult)
 (MVar ()) (MVar ()) (MVar ()) (MVar ()) (IORef Int) (IORef Int)
newCase :: P.StopBudget -> IO Case
newCase budget = do
 sessions <- newCurrentSessions
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newIORef False <*> newIORef [] <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
  <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef 0
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ workers _ _ _ _ _ _ _ _ _ _) = readIORef workers
retainedResults :: Case -> IO (Maybe ConfigResult,Maybe ActorResult,Maybe StopResult,Maybe RetireResult)
retainedResults (Case _ _ _ config actor stop retire _ _ _ _ _ _) =
 (,,,) <$> tryReadMVar config <*> tryReadMVar actor <*> tryReadMVar stop <*> tryReadMVar retire
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("launch-phase: " ++ label)))
wait :: [AdmissionDeadline] -> String -> MVar a -> IO a
wait ds label cell = do
 left <- minimum <$> mapM remainingMicros ds
 if left<=0 then ioError (userError (label ++ ": Unknown; retain owner and guardian")) else do
  result <- timeout left (readMVar cell)
  maybe (ioError (userError (label ++ ": Unknown; retain owner and guardian"))) pure result
launch :: IORef [ThreadId] -> MVar (Either SomeException a) -> [AdmissionDeadline] -> IO a -> IO ()
launch workers done bounds action = mask $ \_ -> do
 start <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar start
   left <- minimum <$> mapM remainingMicros bounds
   check "existing D live before dispatch" (left>0)
   action
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()

-- The host provides one real validated config file for this same owner, a
-- genuine existing absolute original D and StopBudget, private resources and
-- an independent guardian. No fake bootstrap state, selected D or cleanup.
-- A QA hook signals after actual StoreOwner publication but before config read;
-- the separate actor hook signals immediately before the real LaunchReady CAS.
runCase :: Case -> AdmissionDeadline -> FilePath -> Mode -> IO ()
runCase (Case owner used workers configDone actorDone stopDone retireDone configEntered configRelease actorEntered actorRelease reads actors)
 originalD configPath mode = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "one isolated case" fresh
 case mode of
  NoConfigStop -> pure ()
  _ -> do exists <- doesFileExist configPath; check "real absolute config" (isAbsolute configPath && exists)
 start <- qaLaunch owner
 readiness <- qaBootstrapReadiness owner
 firstBefore <- qaStopDeadline owner
 check "fresh unready owner has no stop" (start==QaFresh && readiness==BootstrapNotReady && firstBefore==P.StopDeadlineNotLatched)
 qaSetConfigReadHook (atomicModifyIORef' reads (\n -> (n+1,())))
 qaSetActorAfterCAS (atomicModifyIORef' actors (\n -> (n+1,())))
 qaSetConfigOwnerHook $ case mode of
  ConfigReadingStop -> putMVar configEntered () >> readMVar configRelease
  ConfigInterrupted -> throwIO ThreadKilled
  _ -> pure ()
 qaSetActorBeforeCAS $ if mode==ActorCASAfterStop
  then putMVar actorEntered () >> readMVar actorRelease else pure ()
 case mode of
  NoConfigStop -> pure ()
  _ -> launch workers configDone [originalD] (loadPersistentBackendConfig owner configPath)
 case mode of
  ConfigReadingStop -> do
   wait [originalD] "actual StoreOwner published" configEntered
   reading <- qaLaunch owner
   pending <- qaBootstrapReadiness owner
   count <- readIORef reads
   check "actual reading phase is not ready and read not entered" (reading==QaReading && pending==BootstrapNotReady && count==0)
  ConfigInterrupted -> do
   failed <- wait [originalD] "actual config interruption" configDone
   case failed of
    Left e -> check "original async preserved" (case fromException e of Just ThreadKilled -> True; _ -> False)
    Right _ -> ioError (userError "injected config interruption swallowed")
   phase <- qaLaunch owner
   count <- readIORef reads
   check "unusable config and no physical read entry" (phase==QaUnusable && count==0)
  NoConfigStop -> pure ()
  _ -> do
   loaded <- wait [originalD] "actual config publication" configDone >>= either throwIO pure
   phase <- qaLaunch owner
   count <- readIORef reads
   check "real config published before stop" (loaded==Right () && phase==QaReady && count==1)
 case mode of
  ActorCASAfterStop -> do
   launch workers actorDone [originalD] (runPersistentBackend owner)
   wait [originalD] "actual actor before CAS" actorEntered
   phase <- qaLaunch owner
   check "actor has not acquired launch phase" (phase==QaReady)
  _ -> pure ()
 -- ConfigInterrupted itself already requested the same sticky first stop;
 -- all other cases invoke the actual first stop exactly once here.
 case mode of
  ConfigInterrupted -> pure ()
  _ -> do
   launch workers stopDone [originalD] (requestPersistentBackendStop owner)
   receipt <- wait [originalD] "actual first stop" stopDone >>= either throwIO pure
   check "first prelive stop latched" (receipt==P.StopLatchedBeforeLive)
 selected <- qaStopDeadline owner
 stopD <- case selected of P.StopDeadlineLatched d -> pure d; _ -> ioError (userError "actual first StopD unavailable")
 let bounds = [originalD,stopD]
 launch workers retireDone bounds (retirePersistentBackend owner)
 retired <- wait bounds "actual owner retirement observation" retireDone >>= either throwIO pure
 phaseAfter <- qaLaunch owner
 case mode of
  ConfigReadingStop -> do
   check "no retirement or seal while real config work pending" (not retired && phaseAfter==QaReading)
   putMVar configRelease ()
   outcome <- wait bounds "actual stopped config return" configDone >>= either throwIO pure
   count <- readIORef reads
   final <- qaLaunch owner
   check "stop before config admission refuses before any read" $
    outcome==Left "persistent config admission refused" && count==0 && final==QaUnusable
  ConfigInterrupted -> do
   count <- readIORef reads
   check "interrupted config never yields clean retirement" (not retired && phaseAfter==QaUnusable && count==0)
  _ -> do
   check "same owner prelive seal and actual settled retirement" (retired && phaseAfter==QaSealed)
   case mode of
    ActorCASAfterStop -> putMVar actorRelease ()
    _ -> launch workers actorDone bounds (runPersistentBackend owner)
   actor <- wait bounds "actual attempted actor after seal" actorDone
   case actor of
    Left ex -> case fromException ex :: Maybe IOException of
     Just io -> check "actual actor rejected before entry" $
      ioeGetErrorString io == (if mode==NoConfigStop then "persistent owner has no verified config" else "persistent backend owner already used")
     Nothing -> throwIO ex
    Right _ -> ioError (userError "sealed actor unexpectedly entered")
   entered <- readIORef actors
   check "no actual actor CAS succeeds after seal" (entered==0)
 after <- qaStopDeadline owner
 check "same original first StopD retained" (after==P.StopDeadlineLatched stopD)
-- Returned True concerns only this owner-level readiness/retirement test; it
-- is not selected child, provider, native, AT, IME or whole-product acceptance.
