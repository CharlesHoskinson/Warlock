port module UiHttpStateReplay exposing (main)

{-| Proposed unrun QA-only state observer replay. Requires the combined ignored
observer patch, applied to a source-hashed QA-only copy of UiHttp. No production
reducer mutation, no native authority, no command or scheduler interpretation.
Inputs here are JSON-only Elm values; arbitrary JS objects/functions are not
qualified. Existing protected XHR/fake-clock tests remain mandatory.
-}

import Http
import Json.Encode as E
import Platform
import UiHttp

port outgoing : E.Value -> Cmd msg

snapshot : UiHttp.Model -> String
snapshot = UiHttp.qaSnapshot >> E.encode 0

step : UiHttp.Msg -> UiHttp.Model -> UiHttp.Model
step message current =
    let (next,_,_) = UiHttp.update message current
    in next

queue : E.Value -> UiHttp.Model -> UiHttp.Model
queue value current =
    let (next,_,_) = UiHttp.enqueue value current
    in next

stop : String -> UiHttp.Model -> UiHttp.Model
stop reason current =
    let (next,_,_) = UiHttp.stop reason current
    in next

expectedRole : String -> List E.Value -> Maybe E.Value -> Bool -> E.Value -> String
expectedRole role pending active polling failure =
    E.object
        [ ("role",E.string role)
        , ("pending",E.list identity pending)
        , ("active",active |> Maybe.map (\value -> E.object [("present",E.bool True),("value",value)]) |> Maybe.withDefault (E.object [("present",E.bool False)]))
        , ("polling",E.bool polling)
        , ("failure",failure)
        ] |> E.encode 0

expected : List E.Value -> Maybe E.Value -> Bool -> E.Value -> String
expected = expectedRole "renderer"

-- Independent literal inputs/expectations, not copied from reducer output.
requestA : E.Value
requestA = E.object [("kind",E.string "A"),("id",E.string "9007199254740993")]

requestB : E.Value
requestB = E.object [("kind",E.string "B"),("flag",E.bool False)]

deliveryFailure : E.Value
deliveryFailure = E.object
    [("kind",E.string "delivery-unconfirmed"),("text",E.string "UI delivery is unconfirmed. The action will not be repeated.")]

emptyStop : E.Value
emptyStop = E.object [("kind",E.string "explicit-stop"),("text",E.string "")]

checks : List (String,Bool)
checks =
    let
        initial = Tuple.first UiHttp.renderer
        controller = Tuple.first UiHttp.controller
        controllerQueued = queue requestA controller
        controllerFailed = step (UiHttp.Polled (Err Http.Timeout)) controllerQueued
        nullActive = queue E.null initial
        nullDelivered = step (UiHttp.Posted (Ok "")) nullActive
        a = queue requestA initial
        ab = queue requestB a
        next = step (UiHttp.Posted (Ok "")) ab
        idle = step (UiHttp.Polled (Ok "")) next
        polling = step UiHttp.Poll idle
        failed = step (UiHttp.Posted (Err Http.Timeout)) ab
        afterPoll = step UiHttp.Poll failed
        afterEnqueue = queue (E.string "must-not-retry") afterPoll
        explicit = stop "" ab
        secondStop = stop "later" explicit
    in
    [ ("controller-initial-complete",snapshot controller == expectedRole "controller" [] Nothing True E.null)
    , ("controller-queue-complete",snapshot controllerQueued == expectedRole "controller" [] (Just requestA) True E.null)
    , ("controller-poll-failure-retains-active",snapshot controllerFailed == expectedRole "controller" [] (Just requestA) True (E.object [("kind",E.string "event-transport-unavailable"),("text",E.string "UI event transport unavailable. Actions were not retried.")]))
    , ("initial-complete",snapshot initial == expected [] Nothing True E.null)
    , ("null-active-is-not-absence",snapshot nullActive == expected [] (Just E.null) True E.null)
    , ("null-dequeue-is-absence",snapshot nullDelivered == expected [] Nothing True E.null)
    , ("first-active-complete",snapshot a == expected [] (Just requestA) True E.null)
    , ("second-retained-in-order",snapshot ab == expected [requestB] (Just requestA) True E.null)
    , ("successful-delivery-advances-only-one",snapshot next == expected [] (Just requestB) True E.null)
    , ("empty-poll-clears-polling-only",snapshot idle == expected [] (Just requestB) False E.null)
    , ("poll-restarts-flag-not-model-queue",snapshot polling == expected [] (Just requestB) True E.null)
    , ("ambiguous-failure-retains-complete-queue",snapshot failed == expected [requestB] (Just requestA) True deliveryFailure)
    , ("failed-poll-and-enqueue-do-not-change-retained-state",snapshot afterEnqueue == expected [requestB] (Just requestA) True deliveryFailure)
    , ("empty-explicit-stop-retains-complete-queue",snapshot explicit == expected [requestB] (Just requestA) True emptyStop)
    , ("later-stop-cannot-replace-first",snapshot secondStop == expected [requestB] (Just requestA) True emptyStop)
    ]

main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing (E.object [("checks",E.list (\(name,ok) -> E.object [("name",E.string name),("passed",E.bool ok)]) checks)]) )
        , update = \_ model -> (model,Cmd.none)
        , subscriptions = \_ -> Sub.none
        }
