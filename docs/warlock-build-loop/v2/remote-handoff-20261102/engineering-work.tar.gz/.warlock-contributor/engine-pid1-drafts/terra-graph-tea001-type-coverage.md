# ELM-TEA-001 source/type coverage map

Source review and proposed patch only; no compiler, fixture or native execution. Original EARS requires lifecycle, receipt **and** operation state with custom types, observed native state separate from desired UI state, projections derived from one authoritative snapshot, and no duplicated native authority (`docs/elm-roadmap/requirements.json:4843`). Verification requires typed compiler checks, deterministic replay, independent boundary fixtures and source hashes; native qualification is separate. This matrix identifies positive evidence and concrete outstanding audit surfaces; it is not a complete proof of absence of every other untyped field or of one-authority semantics. In particular, inspect all six actual root dependency closures and ownership interfaces before calling the audit complete.

## Routes and ownership to cover

- `Main.elm:11-25` owns `DesktopPolicy.Model` and interprets `Publish` and `Delay`; `HttpMain.elm:13-49` uses the same policy and `UiHttp`, including transport loss. `DesktopPolicy.elm:11-15,52-65` -> `OutputController` -> `SurfaceController` -> `Desktop`. The controller's complete nested state and effects are separately enumerated in `tea-policy-source-inventory-terra-graph.md` SHA256 f4fe7cce21a6b6172c63cccd059d8acf542180e426616802e48872c9ae3e70d2.
- Also audit the actual renderer roots `Bar`, `Popup`, `HttpBar`, `HttpPopup`, their `Presentation`/`SurfaceSnapshot`/`SurfaceRenderer`, `UiHttp`, `StatusScroll`, and Popup's retained preview path. Separate `Protocol/Session`, `Protocol/Wire`, and `Protocol/Authority` modules have no import from those session modules outside their own protocol group in the current source search; confirm actual six-root compiler import graph before treating them as in or out of original EARS scope. Native preview paths are not part of DesktopPolicy.Model but may be reachable from Popup.
- `Surface.packet` derives rendered data from `Desktop.Model`; `OutputController.frame/commit` packages it. `Effects.Model.observed` is native observation while `transaction`/`unresolved` represent desired operation and uncertain outcomes; `Settings` and `MotionPreferences` separately retain snapshot/draft/pending; `Motion` has observation/pending/applied. `Launch` keeps catalog, phase and uncertain operation separately. These structures support separation but their mere existence does not prove no duplicate authority or all mutation/receipt paths.

## Typed state already present (source presence, not acceptance)

- `Effects.elm:12-19`: `Operation` and `Status` ADTs; `Shell.elm:12,31-35`: `RecoveryFailure`, `Phase`, `Stamp`, typed effects. `Launch.elm:13-43`: phase/result/pending token/selection/acknowledgement. `Menu.elm:47-82,122-155` types authority IDs, target, operation and outcome/status. `WorkspaceNavigation.elm:10-14` types pending/unknown/committed/refused; `Pins.elm:8` types Saving versus Unconfirmed. `Settings.elm:7-11` typed theme and saved/refused/unconfirmed result; `Motion.elm:9-13` profile and independent observation/pending/applied; `MotionPreferences.elm:7-9` override; `ShortcutPreferences.elm:7-12` choice; `SystemMenu.elm:7-8` operation. `PointerOwnership.elm:5-7`, `Switcher.elm:7-9`, `Desktop.elm:104-122` and `Popup.elm:32-37` type additional lifecycle states, origins and messages. `PreviewLifecycle.elm:20-30` types preview capture, connection, status, fidelity, commands and events.
- Current `Desktop.elm:120-150,919,1059,1075` decodes finite custom save/shortcut receipt variants and converts back to legacy strings when calling domain reducers. It rejects other input at that boundary, but the receiving APIs still accept Strings and this boundary conversion does not itself make every receipt state typed. Report elm-cpu-1793559549930167342 is a component result with the scope supplied by Root, not whole-TEA acceptance.

## Explicit type/authority gaps and scopes requiring adjudication

- `JumpList.elm:6,15,21`: stored action `kind : String` is decoder-restricted to `desktop`/`recent`, reused for authority prefix; `Surface.elm:117-118` turns it into user-facing description. Proposed complete cross-file patch `terra-graph-tea001-jumplist-kind.patch`, SHA256 b5f741bfa507734e1d879a7378da163b2e17f198dfbc67d85f4bac820e2d3647, defines `ActionKind`, keeps exact wire strings and prefix test, updates Surface and adds QA cases. Current `JumpList.receive` takes `Submitted|Refused|Unknown` as String (`:30-35`): separate receipt gap, deliberately not covered by that patch.
- `Notifications.elm:10-13,27,59,70-76`: stored lifecycle `Entry.state`, action `Target.verb`, and `outcome.status` remain Strings despite finite checks. `Surface.elm:181` and `OutcomeAnnouncements` consume those; coordinate terra-security. `reason` at Desktop :1043 is a finite refusal reason, transient until model use is audited.
- `ReconciliationFrame.elm:10,28-35` stores Proof.kind, Proof.operation, Proof.grantState as Strings; kind and grant state are exact constants, operation accepts observe/retire. This proof carries binding and request correlation into `ReconciliationTracking.Model`; coordinate gemini-site. Do not conflate converting the type with proving retirement authority or semantic equivalence.
- `SystemMenu.elm:9-15,21-32,59-79` stores bounded native network/session state Strings and closed network permission (`yes/no/auth`) and power capabilities (`yes/no/na/challenge`) as Strings; receipt status accepted as String. State strings are merely bounded here, so do not invent a finite enum without checking upstream contracts. `Files.elm:54-65` receipt `Opened/Refused/Unknown` and `JumpList.receive` likewise admit String arguments; inspect all direct callers and whole frontend expectation before assigning scope. `Motion.elm:10,42-45` stores source String restricted to portal/gtk; Profile is already typed.
- `Settings.elm:56-65`, `MotionPreferences.elm:62-71`, `ShortcutPreferences.elm:105-117` receive status Strings even though current Desktop ingress validates a finite custom type first. Audit direct consumers and invalid value behavior, including pending states; do not label the earlier malformed-status bug fixed end-to-end until source-hashed replay and boundary fixtures run.
- `Provider.elm:62-74` uses Entry.kind/capabilities as Strings in an intermediate raw decoder, then derives `Menu.Action` and validates capability membership at :275; confirm whether raw survives in authoritative model before classifying as a stored gap. `SurfaceSnapshot.elm:9-11,35` stores projection mode/motion/status Strings. `status` is user-facing prose, not automatically an enum; `mode`/`motion` are finite projection values and must be adjudicated as renderer presentation versus lifecycle authority. `UiHttp.elm:11-20` types Role/Msg/Event; inspect all fields and delivery/loss transitions for remaining finite states and authority duplication.
- `Protocol/Authority.elm:17` `Intent.operation : String`, `Protocol/Wire.elm:12` `Historical.ackState : String` and String members exist in the protocol group; `Wire.Status` and `Session.Status` are typed. Their reachability from the six production roots and actual role in the original requirement must be proven, not guessed. Keep out-of-route code visible in whole-repository audit rather than asserting it is production authority.
- `Desktop.elm` intentionally retains bounded labels, user text, IDs, arbitrary surface/native JSON payloads and notices. String alone does not prove an enum defect; audit actual finite wire vocabulary, storage, state-dependent branches and authority rather than recoding arbitrary data. Similarly a Boolean or `Maybe` may encode meaningful lifecycle state: review invalid combinations and their constructors, not only fields literally named status or kind.

## Verification still required

Exact source tuple and six-root typed compilation; independent fixture positives/negatives for each converted boundary and its unchanged wire/labels, unknown/malformed variants, stale/foreign and uncertain receipts; deterministic full-state/effect replay (including no-replay and full-width counters); explicit single-authority and observed/desired-state review across owning and renderer paths; all original scenario obligations, review and native qualification as applicable. Historical partial component reports remain retained and do not promote 001/002.

## Source hashes at review
a63de0a105e1a13edc5eb67359b665032acba662650659b3a24d4f1999058b66  implementation/warlock/src/Main.elm
58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9  implementation/warlock/src/HttpMain.elm
018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e  implementation/warlock/src/DesktopPolicy.elm
fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae  implementation/warlock/src/OutputController.elm
2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998  implementation/warlock/src/SurfaceController.elm
91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4  implementation/warlock/src/Desktop.elm
80c574e8c564c28a1fb11f1f89bb5bfa7ac97a92474bbf027a737324bb2a82cd  implementation/warlock/src/Effects.elm
dcd7260248ccb0b5bc6001c49319dd51af8c2fae98888919a308ac025ed273a2  implementation/warlock/src/Launch.elm
6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094  implementation/warlock/src/Shell.elm
059841cc0669fdc7fd699498ee72d4211a2aa5d69c466d4aade7558e03b0f68c  implementation/warlock/src/JumpList.elm
c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb  implementation/warlock/src/Surface.elm
b37bff9f104d80eb1d1ea99f297c4d859b9d5744d7b0c05f6c89fa51581bc244  implementation/warlock/src/Notifications.elm
c44fa50ac86d528b35959d50fc4d85bd9d8983c1e866fdda01ad1854f465004e  implementation/warlock/src/ReconciliationFrame.elm
cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054  implementation/warlock/src/SystemMenu.elm
e101862bae874426f0cf9aaf02340c6582abdeea21dec38c32003da7f94e8a69  implementation/warlock/src/Motion.elm
d3130d74c3172cb1808df38efd7a2cc267ba5ae346b564544661d3d539f5c560  implementation/warlock/src/MotionPreferences.elm
d13f4d63327eae4a80052252c8ba1f1e40db0f69954b46470ccff248e5ba0e7c  implementation/warlock/src/Settings.elm
d8c1a63f199612161e078e0f6c7f75cbbfa190953e19325e50169debc425dcec  implementation/warlock/src/ShortcutPreferences.elm
c44da7aa32a193fc998d4efc39af25067998adc37d67da6d0c5b834f073635a4  implementation/warlock/src/Pins.elm
8313a23008abfa6157324472db852b087b4af09dd3696a33f273d7010634e7f6  implementation/warlock/src/WorkspaceNavigation.elm
2ef450a364d23d334e2ba7dfafdc56bbf51649dfb8f2e9f2e0ab1ca600157727  implementation/warlock/src/Provider.elm
58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7  implementation/warlock/src/SurfaceSnapshot.elm
fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58  implementation/warlock/src/Popup.elm
232ebe2e823a4f9b07444f9afaccd98cdc3de9a592ff220d9975a64952dacf24  implementation/warlock/src/PreviewLifecycle.elm
3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419  implementation/warlock/src/UiHttp.elm
1a566bff746f573c895a39a1c6e6413fb7ee4ca020826c16a063dae2b6d12bad  implementation/warlock/qa/JumpListReplay.elm

## Six-root lexical inventory follow-up

The separately generated `terra-graph-tea001-six-root-type-index.md` SHA256 `3e4e5423aaaf8692c93fe38b052b1c3951b61d147820b4ccc06ce31d1375d613` enumerates top-level type declarations and exact source hashes for 73 locally imported modules. Lexical imports are not a compiled reachability or authority proof. Additional retained finite String review targets identified in this closure:

- `Snap.elm:9-12,66-109`: `Choice.selected` is `Region`, but `Proposal.region` is String restricted to the six region names; `Effects.SnapPlacement Proposal` retains it as operation state. This is distinct from free-form workspace names. Preserve decoder, equality, generated geometry and wire values when adjudicating a typed conversion.
- `GeometryProjection.elm:12,42` stores negotiated operations as `List String`, with membership used for eligibility. Check closed capability vocabulary, legacy compatibility and protocol before concluding whether/custom-typing is required.
- `PreviewPresenter.elm:21,216-217,452-456,534` stores `iconKind` in Popup's preview model, restricted to application/generic/unavailable and used to validate icon absence; inspect actual preview lifecycle and native ownership separately.
- `CapturedAction.elm:8-20` retains decoder-validated bar/popup surface and optional pointer/keyboard trigger as String inside an opaque envelope; it expressly is not an authenticated origin capability. Preserve that distinction when classifying its type obligation.
- `NativePreviewProposalIngress.elm:9-13,45-53,80-94` transient proposal/ticket/packet kind Strings are exact protocol discriminators, while the persistent Model is a grant plus queue of identity/raw command. Determine lifecycle relevance without confusing wire parsing with native authority. `SurfaceTheme.elm:61-74` control spec has String presentation kind/windowState/surfaceMode/motion; renderer style projections are not evidence of another native authority, but their finite vocabularies remain part of six-root review.
