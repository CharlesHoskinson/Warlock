'use strict';
// Root-only unexecuted HTTP controller fixture.  The complete policy states
// and published JSON are independently transcribed TEA-002 literals, never
// harvested from this wrapper or its compiled reducer.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const baselineSHA = '41e3ccabc5843153b604205dd937c56890f659e294929788a959951d39b7bcb7';
const C = (tag, ...args) => Object.fromEntries([['$', tag], ...args.map((v,i) => [String.fromCharCode(97+i),v])]);
const L = xs => xs.reduceRight((tail,x) => C('::',x,tail),C('[]'));
const N = () => C('Nothing');
const J = x => C('Just',x);
const http = (active=N(), pending=L([]), failure=N()) => C('Model', {role:C('Controller'),pending,active,polling:true,failed:failure});
const desc = (module,effects) => ({module,effects});
const ret = (h,effects,event=N()) => ({kind:'transition',value:C('#3',h,L(effects),event)});
const subscriptions = () => ({$:2,m:C('[]')});
const expect = (policy,h,descriptions,transportReturns) => ({state:{policy,http:h},subscriptions:subscriptions(),descriptions,transportReturns});
function build(repository) {
  const baseline=path.join(repository,'implementation/warlock/qa/tea-contract-cases.cjs');
  if (crypto.createHash('sha256').update(fs.readFileSync(baseline)).digest('hex') !== baselineSHA)
    throw Error('independent TEA-002 literals changed; re-review and rebind');
  const contract=require(baseline);
  const matches=contract.cases.filter(c=>c.name==='catalog-pending-disconnect-rejects-late-receipt');
  if (matches.length!==1) throw Error('expected unique source-bound TEA-002 case');
  const steps=contract.materialize(matches[0]).steps;
  if (steps.length<4 || steps[0].input.kind!=='reset' || steps[1].input.kind!=='incoming' ||
      steps[2].input.kind!=='incoming' || steps[3].input.kind!=='transportLost') throw Error('unexpected literal prelude');
  const [initial,topology,attached,disconnected]=steps;
  const topologyEffect=topology.expected.effects, attachedEffect=attached.expected.effects;
  if (topologyEffect.$!=='::' || topologyEffect.a.$!=='Publish' || topologyEffect.b.$!=='[]' ||
      attachedEffect.$!=='::' || attachedEffect.a.$!=='Publish' || attachedEffect.b.$!=='[]')
    throw Error('expected exact single-publish source literals');
  const packet1=topologyEffect.a.a, packet2=attachedEffect.a.a;
  const start=http(), sent=http(J(packet1)), queued=http(J(packet1),L([packet2]));
  const failed=http(J(packet1),L([packet2]),J(C('EventTransportUnavailable')));
  const incoming = raw => J(C('Incoming',{$:0,a:raw}));
  const read=C('ReadEvents'), send=C('SendController',packet1);
  const cancel=[C('CancelEvents'),C('CancelPost')];
  const lost=J(C('Lost','UI event transport unavailable. Actions were not retried.'));
  return {cases:[{name:'HttpMain-queued-policy-delivery-loss-remains-unknown-no-replay',root:'HttpMain',steps:[
    {input:{kind:'init'},expected:expect(initial.expected.state,start,[desc('UiHttp',L([read]))],[{kind:'startup',value:C('#2',start,L([read]))}])},
    {input:{kind:'polledOk',body:JSON.stringify(topology.input.value)},expected:expect(topology.expected.state,sent,
      [desc('UiHttp',L([read])),desc('DesktopPolicy',topologyEffect),desc('HttpMain.effects',topologyEffect),desc('UiHttp',L([send]))],
      [ret(start,[read],incoming(topology.input.value)),ret(sent,[send])])},
    {input:{kind:'polledOk',body:JSON.stringify(attached.input.value)},expected:expect(attached.expected.state,queued,
      [desc('UiHttp',L([read])),desc('DesktopPolicy',attachedEffect),desc('HttpMain.effects',attachedEffect),desc('UiHttp',L([]))],
      [ret(sent,[read],incoming(attached.input.value)),ret(queued,[])])},
    // HttpMain.lost invokes the real policy reducer and intentionally ignores
    // its returned effects after the transport has become permanently failed.
    {input:{kind:'polledNetworkError'},expected:expect(disconnected.expected.state,failed,
      [desc('UiHttp',L(cancel)),desc('DesktopPolicy',disconnected.expected.effects)],
      [ret(failed,cancel,lost)])},
    {input:{kind:'postedOk',body:''},expected:expect(disconnected.expected.state,failed,[desc('UiHttp',L([]))],[ret(failed,[])])},
    {input:{kind:'poll'},expected:expect(disconnected.expected.state,failed,[desc('UiHttp',L([]))],[ret(failed,[])])},
  ]}]};
}
module.exports={build};
