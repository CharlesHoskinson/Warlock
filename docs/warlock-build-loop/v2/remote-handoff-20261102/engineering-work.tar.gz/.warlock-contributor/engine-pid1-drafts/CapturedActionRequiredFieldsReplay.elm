port module CapturedActionRequiredFieldsReplay exposing (main)

{-| Source-only companion to CapturedActionBoundaryReplay. Every field mutation
is applied to the same independently stated valid bar action and is passed to
all three actual Elm boundaries. The desktop prelude is synthetic and does not
assert native origin, user input, or owner-issued publication/lease authority.
Root must add a result-consuming QA entry and execute the protected checks.
-}

import CapturedAction
import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Presentation
import Surface
import UInt64

port outgoing : E.Value -> Cmd msg

counter value = D.decodeValue UInt64.decoder (E.string value) |> Result.withDefault UInt64.zero
bound = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]
native wire model = NativePointerFixture.incoming wire model |> Tuple.first
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",bound)]
window id = E.object [("incarnation",E.string id),("label",E.string ("Document "++id)),("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]
projection = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",bound),("requestId",E.string "1"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")]),("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),("windows",E.list identity [window "1",window "2"])])]
ready = Desktop.initial |> native attached |> native projection

fields publication =
    [("surface",E.string "bar"),("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),
     ("publication",E.string publication),("lease",E.string "0"),("id",E.string "bar:settings")]

required = ["surface","surfaceProtocol","kind","publication","lease","id"]
remove key pairs = List.filter (Tuple.first >> (/=) key) pairs
replace key value pairs = List.map (\(name,old) -> (name,if name==key then value else old)) pairs
wrongType key = if key=="surfaceProtocol" then E.string "2" else E.int 0

rejected publication presentation raw =
    (case CapturedAction.decode raw of
        Err _ -> True
        Ok _ -> False)
        && Presentation.dispatch False raw presentation == Nothing
        && Surface.resolve (counter publication) UInt64.zero raw ready == Nothing

sequence seed =
    let
        publication = String.fromInt seed
        rawFields = fields publication
        valid = E.object rawFields
        frame = Surface.packet (counter publication) UInt64.zero ready
        presentation = Presentation.accept frame Presentation.initial
        expected = "{\"surface\":\"bar\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\"" ++ publication ++ "\",\"lease\":\"0\",\"id\":\"bar:settings\"}"
        encoded = CapturedAction.decode valid |> Result.map (CapturedAction.encode >> E.encode 0 >> (==) expected) |> Result.withDefault False
        dispatch = Presentation.dispatch False valid presentation |> Maybe.map (E.encode 0 >> (==) expected) |> Maybe.withDefault False
        admit = Surface.resolve (counter publication) UInt64.zero valid ready /= Nothing
        variants key =
            [ ("missing:"++key,rejected publication presentation (E.object (remove key rawFields)))
            , ("null:"++key,rejected publication presentation (E.object (replace key E.null rawFields)))
            , ("wrong-type:"++key,rejected publication presentation (E.object (replace key (wrongType key) rawFields)))
            ]
        checks =
            [ ("positive_literal_wire_and_both_routes",encoded && dispatch && admit)
            , ("wrong_kind",rejected publication presentation (E.object (replace "kind" (E.string "surface-query") rawFields)))
            , ("wrong_version",rejected publication presentation (E.object (replace "surfaceProtocol" (E.int 3) rawFields)))
            , ("unknown_surface",rejected publication presentation (E.object (replace "surface" (E.string "foreign") rawFields)))
            , ("extra_field",rejected publication presentation (E.object (rawFields++[("extra",E.bool True)])))
            , ("present_null_trigger",rejected publication presentation (E.object (rawFields++[("trigger",E.null)])))
            , ("unknown_trigger",rejected publication presentation (E.object (rawFields++[("trigger",E.string "touch")])))
            ] ++ List.concatMap variants required
    in E.object [("seed",E.int seed),("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]

result = E.object [("scope",E.string "Synthetic Elm decode and current-frame dispatch; not native authentication"),("sequences",E.list sequence (List.range 1 32))]
main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\message model -> never message,subscriptions=\_ -> Sub.none}
