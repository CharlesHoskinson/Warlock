{-# LANGUAGE OverloadedStrings #-}
-- SOURCE-ONLY TEST FIXTURE, not production, not compiled or executed.
--
-- Intended insertion: ui-engine-controls test Main.hs dispatches its own exact
-- engine-only argv before parent setup, calls engineProbe and terminates the
-- child. EngineCustody.startUnreadyEngine execs the held /proc/self/exe, so the
-- parent and child must be the SAME test executable: an unrelated helper path
-- or a new test-only production mode would not exercise the manifest.
--
-- This fixture calls the actual EngineEntrypoint.classifyMode/prepareEngine,
-- never GTK and never emits a TrustedOwnerEvent. It then runs the real broker
-- ready/startup exchange and two ordinary reads; a real broker callback may
-- count those two requests. The returned Bool is ONLY this child-side exchange
-- result; it is not proof the parent reaped it, GUI readiness or acceptance.
-- It does not exercise Entry.runEngineOnly or continuous child lifeline monitoring.
-- Parent must use the held child/pidfd guard, single existing EngineCustody
-- reaper, original D and its own recorded actual outcome. No fake cleanup.
--
-- Wiring note: ui-engine-controls must list the real ui/EngineEntrypoint and
-- its WebKit module closure plus the target's existing pinned GTK link inputs;
-- simply importing Entrypoint currently links WebKit although this fixture
-- never initializes GTK. This is a test dependency, not a GTK-free broker proof.
module EngineProbeGraph (engineProbe) where

import Control.Exception (bracket)
import Control.Monad (unless, when)
import qualified Data.ByteString as B
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import qualified Network.Socket as Socket
import qualified Network.Socket.ByteString as SocketBytes
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import qualified Warlock.Protocol.EngineTransport as Transport
import qualified Warlock.Protocol.PeerCredential as Credential
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.EngineEntrypoint as Entry
import qualified Warlock.Ui.EngineProtocol as Protocol

ensure :: Bool -> IO ()
ensure ok = unless ok (ioError (userError "engine probe refused"))

bounded :: AdmissionDeadline -> IO a -> IO a
bounded deadline action = do
 before <- remainingMicros deadline
 ensure (before > 0)
 result <- timeout before action
 after <- remainingMicros deadline
 case result of
  Just value | after > 0 -> pure value
  _ -> ioError (userError "engine probe transport uncertain")

-- The public recvmsg reader rejects unexpected ancillary rights/truncation.
-- PID0, UID/GID and per-fragment consistency are observations, not authority;
-- they require the separately verified held-exec/socketpair/lifeline lineage.
readFrame :: Transport.CredentialReader -> Socket.Socket -> AdmissionDeadline
 -> (B.ByteString -> Either e Int) -> Integer -> Integer
 -> Maybe Credential.PeerCredential -> IO (B.ByteString, Credential.PeerCredential)
readFrame reader socket deadline parseLength uid gid original = do
 (prefix, peer) <- pieces 4 original []
 size <- either (const (ioError (userError "engine probe frame size"))) pure (parseLength prefix)
 pieces size (Just peer) []
 where
  pieces 0 Nothing _ = ioError (userError "engine probe missing credential")
  pieces 0 (Just peer) fragments = pure (B.concat (reverse fragments), peer)
  pieces left previous fragments = do
   remaining <- remainingMicros deadline
   ensure (remaining > 0)
   let requested = min left 65536
   chunk <- Transport.receiveCredentialChunk reader socket requested
   case chunk of
    Right (Transport.CredentialChunk bytes peer) -> do
     ensure (not (B.null bytes) && B.length bytes <= requested)
     ensure (Credential.credentialPid peer == 0 && Credential.credentialUid peer == uid
       && Credential.credentialGid peer == gid && maybe True (== peer) previous)
     pieces (left - B.length bytes) (Just peer) (bytes:fragments)
    _ -> ioError (userError "engine probe bad fragment")

-- Requests are strictly sequential: a completed, correlated reply is required
-- before the next request. On any error the caller stops; no retry/replay.
request :: Transport.CredentialReader -> Socket.Socket -> AdmissionDeadline
 -> Integer -> Integer -> Credential.PeerCredential -> Protocol.Session
 -> Protocol.Request -> IO (Protocol.Session, Protocol.Reply)
request reader socket deadline uid gid peer session operation = bounded deadline $ do
 let (pending, encoded) = Protocol.beginRequest session operation
 raw <- either (const (ioError (userError "engine probe request"))) pure encoded
 framed <- either (const (ioError (userError "engine probe request size"))) pure (Transport.enginePrefix raw)
 SocketBytes.sendAll socket framed
 (answer, _) <- readFrame reader socket deadline Transport.engineHeaderLength uid gid (Just peer)
 let (next, decoded) = Protocol.acceptReply pending answer
 reply <- either (const (ioError (userError "engine probe reply"))) pure decoded
 pure (next, reply)

-- Caller supplies getArgs verbatim; no independent test-only CLI flag is added.
-- It must dispatch this branch before entering withPeerNetwork or calling the
-- parent test body. Exceptions signal failure and do not become probe success.
engineProbe :: [String] -> IO Bool
engineProbe argv = case (Entry.classifyMode argv, argv) of
 (Entry.EngineOnly args, ["--engine-only", rpcText, _, originalD, incarnation, uidText, gidText]) -> do
  rpc <- maybe (ioError (userError "engine probe rpc")) pure (readMaybe rpcText :: Maybe Int)
  uid <- maybe (ioError (userError "engine probe uid")) pure (readMaybe uidText :: Maybe Integer)
  gid <- maybe (ioError (userError "engine probe gid")) pure (readMaybe gidText :: Maybe Integer)
  result <- Entry.prepareEngine args
  deadline <- either (const (ioError (userError "engine probe local admission"))) pure result
  -- mkSocket adopts only this fixed RPC descriptor; no copy or extra owner.
  bracket (Socket.mkSocket (fromIntegral rpc)) Socket.close $ \socket -> do
   Transport.configureSocketFlags socket
   Transport.enablePassCredentials socket
   reader <- Transport.newCredentialReader
   let ready = TE.encodeUtf8 $ J.renderJson $ J.JObject
        [("engineReady", J.JNumber "1"), ("deadline", J.JString (T.pack originalD)),
         ("incarnation", J.JString (T.pack incarnation))]
   frame <- either (const (ioError (userError "engine probe ready size"))) pure (Transport.startupPrefix ready)
   (startupBytes, peer) <- bounded deadline $ do
    SocketBytes.sendAll socket frame
    readFrame reader socket deadline Transport.startupHeaderLength uid gid Nothing
   startup <- either (const (ioError (userError "engine probe startup"))) pure (Protocol.decodeStartup startupBytes)
   sessionId <- either (const (ioError (userError "engine probe session"))) pure (Protocol.sessionId (T.pack incarnation))
   ensure (Protocol.startupDeadline startup == T.pack originalD && Protocol.startupIncarnation startup == sessionId)
   remaining <- remainingMicros deadline
   ensure (remaining > 0)
   (session1, stopped) <- request reader socket deadline uid gid peer (Protocol.newSession startup) Protocol.GetStop
   ensure (stopped == Protocol.StopReply False)
   (_, remainingReply) <- request reader socket deadline uid gid peer session1 Protocol.GetRemaining
   case remainingReply of
    Protocol.RemainingReply micros -> when (micros <= 0) (ioError (userError "engine probe deadline response"))
    _ -> ioError (userError "engine probe wrong response")
   pure True
 _ -> ioError (userError "engine probe expected fixed argv")
