port module SiteMainHeadFixture2325 exposing (main)

{-| Pure-Elm deterministic replay & source-contract fixture for
`SiteMainHeadProd2325.elm` (against `e5ce2487c:site/src/SiteMain.elm`).
Worker executes zero compiler/Node/browser/VM commands; Root compiles and runs
in an isolated staging directory alongside `SiteMain.elm`.
-}

import Browser.Dom as Dom
import Json.Decode as Decode
import Json.Encode as Encode
import Platform
import SiteMain
    exposing
        ( AppearanceTheme(..)
        , FocusTarget(..)
        , Model
        , MotionMode(..)
        , Msg(..)
        , OutcomeSample(..)
        , SurfaceCategory(..)
        , SurfaceId(..)
        )


port outgoing : Encode.Value -> Cmd msg


initialModel : Model
initialModel =
    SiteMain.initialModel


expectedScenarioSlugs : List String
expectedScenarioSlugs =
    [ "taskbar"
    , "launcher"
    , "switcher"
    , "task-view"
    , "transfer"
    , "picker"
    , "preview-states"
    , "snap"
    , "notifications"
    , "settings"
    , "files"
    , "system"
    , "window-menu"
    , "confirmation"
    , "application-actions"
    , "status-recovery"
    ]


keyEvent : List ( String, Encode.Value ) -> Encode.Value
keyEvent pairs =
    Encode.object pairs


decodesOk : Decode.Decoder a -> Encode.Value -> Bool
decodesOk decoder raw =
    case Decode.decodeValue decoder raw of
        Ok _ ->
            True

        Err _ ->
            False


decodesErr : Decode.Decoder a -> Encode.Value -> Bool
decodesErr decoder raw =
    not (decodesOk decoder raw)


checks : List ( String, Bool )
checks =
    let
        -- 1. Initial model contract
        initCheck =
            initialModel.theme
                == ThemeNight
                && initialModel.motion
                == MotionStandard
                && initialModel.mobileNavOpen
                == False
                && initialModel.spotlight
                == SurfaceTaskbar
                && initialModel.tabFocusSeq
                == 0
                && initialModel.lastTabFocusMiss
                == Nothing
                && initialModel.scenarioCategory
                == CategoryAll
                && initialModel.category
                == CategoryAll

        -- 2. d6becb72c MVP Availability & Acceptance-Limits Matrix invariants
        rows =
            SiteMain.mvpMatrixRows

        rowIdsOk =
            List.map .rowId rows
                == [ "wl-mvp-row-browser"
                   , "wl-mvp-row-contracts"
                   , "wl-mvp-row-omarchy-vm"
                   , "wl-mvp-row-native-release"
                   ]

        ledgerAndVmFactsOk =
            case rows of
                [ browserRow, contractsRow, vmRow, nativeRow ] ->
                    browserRow.statusBadge
                        == "Runnable now · Simulated"
                        && contractsRow.statusBadge
                        == "17 / 242 whole EARS · 41 / 417 scenarios"
                        && String.contains "ELM-TEA-002" contractsRow.provenToday
                        && String.contains "ELM-TEA-005" contractsRow.provenToday
                        && String.contains "7,293" contractsRow.provenToday
                        && String.contains "57 named Quint runs" contractsRow.provenToday
                        && vmRow.statusBadge
                        == "Failed 28s lifecycle retained (exit -9 / exit 1)"
                        && String.contains "17 acknowledged guarded QMP inputs" vmRow.provenToday
                        && String.contains "footz" vmRow.provenToday
                        && String.contains "63 regular desktop entries" vmRow.provenToday
                        && nativeRow.statusBadge
                        == "Unaccepted · Not released"
                        && List.map .cardId SiteMain.mvpEvidenceCards
                        == [ "wl-evidence-foot", "wl-evidence-footz", "wl-evidence-lifecycle", "wl-evidence-no-restart" ]

                _ ->
                    False

        acceptanceLimitsOk =
            case rows of
                [ browserRow, contractsRow, vmRow, nativeRow ] ->
                    String.contains "window manager" browserRow.openOrExcluded
                        && String.contains "204" contractsRow.openOrExcluded
                        && List.map .cardId SiteMain.betaRunTracks == [ "wl-run-browser", "wl-run-no-download", "wl-run-source-check", "wl-run-omarchy-trial" ]
                        && List.any (\c -> String.contains "No desktop binary" c.badge && String.contains "./get-started/index.html#downloads" c.linkHref) SiteMain.betaRunTracks
                        && List.any (\c -> String.contains "run-omarchy-mvp.md" c.summary && String.contains "D <= 28s" c.badge && String.contains "Read-only application catalog search only" c.limits && String.contains "exit -9" c.limits) SiteMain.betaRunTracks
                        && List.any (\e -> e.cardId == "wl-evidence-no-restart" && String.contains "no automatic reconnect" e.nonClaim) SiteMain.mvpEvidenceCards
                        && String.contains "exit -9" vmRow.openOrExcluded
                        && String.contains "exited 1 (passed=false)" vmRow.openOrExcluded
                        && String.contains "HOSTSTOP2" vmRow.openOrExcluded
                        && String.contains "nativeOperations = []" vmRow.openOrExcluded
                        && String.contains "225 of 242" nativeRow.openOrExcluded
                        && String.contains "376 of 417" nativeRow.openOrExcluded
                        && String.contains "ELM-ARC-024" nativeRow.openOrExcluded
                        && String.contains "ELM-DEL-014" nativeRow.openOrExcluded

                _ ->
                    False

        -- 3. All 16 canonical scenarios & independent category filter (8 + 3 + 5 = 16)
        scenarioSlugsOk =
            List.map .slug SiteMain.allScenarios == expectedScenarioSlugs

        scenarioPartitionOk =
            let
                countCat cat =
                    List.length (List.filter (\s -> s.category == cat) SiteMain.allScenarios)
            in
            countCat CategoryWindows
                == 8
                && countCat CategoryAppsFiles
                == 3
                && countCat CategorySystem
                == 5
                && List.length SiteMain.allScenarios
                == 16

        ( afterScenarioFilter, scenarioFilterFocus ) =
            SiteMain.transition (SelectScenarioCategory CategorySystem) initialModel

        ( afterBothFilters, featureFilterFocus ) =
            SiteMain.transition (SelectCategory CategoryWindows) afterScenarioFilter

        independentFiltersOk =
            afterScenarioFilter.scenarioCategory
                == CategorySystem
                && afterScenarioFilter.category
                == CategoryAll
                && scenarioFilterFocus
                == []
                && afterBothFilters.scenarioCategory
                == CategorySystem
                && afterBothFilters.category
                == CategoryWindows
                && featureFilterFocus
                == []

        -- 4. Mobile drawer Escape focus return vs CloseMobileNav
        ( openedDrawer, openFocus ) =
            SiteMain.transition ToggleMobileNav initialModel

        ( escapedOpen, escapeOpenFocus ) =
            SiteMain.transition EscapeMobileNav openedDrawer

        ( escapedClosed, escapeClosedFocus ) =
            SiteMain.transition EscapeMobileNav initialModel

        ( linkClosed, linkCloseFocus ) =
            SiteMain.transition CloseMobileNav openedDrawer

        mobileEscapeOk =
            openedDrawer.mobileNavOpen
                == True
                && openFocus
                == []
                && escapedOpen.mobileNavOpen
                == False
                && escapedOpen.tabFocusSeq
                == 1
                && escapeOpenFocus
                == [ FocusMobileMenuToggle ]
                && escapedClosed
                == initialModel
                && escapeClosedFocus
                == []
                && linkClosed.mobileNavOpen
                == False
                && linkCloseFocus
                == []

        -- 5. 8-tab roving wrap, Home, End, and stale FocusSettled guards
        ( wrappedLeft, wrappedLeftFocus ) =
            SiteMain.transition (KeyboardStepSpotlight -1) initialModel

        ( wrappedBackRight, wrappedBackRightFocus ) =
            SiteMain.transition (KeyboardStepSpotlight 1) wrappedLeft

        ( jumpedEnd, jumpedEndFocus ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceFiles) initialModel

        ( jumpedHome, jumpedHomeFocus ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceTaskbar) jumpedEnd

        rovingTabsOk =
            wrappedLeft.spotlight
                == SurfaceFiles
                && wrappedLeft.tabFocusSeq
                == 1
                && wrappedLeftFocus
                == [ FocusWorkbenchTab SurfaceFiles ]
                && wrappedBackRight.spotlight
                == SurfaceTaskbar
                && wrappedBackRight.tabFocusSeq
                == 2
                && wrappedBackRightFocus
                == [ FocusWorkbenchTab SurfaceTaskbar ]
                && jumpedEnd.spotlight
                == SurfaceFiles
                && jumpedEndFocus
                == [ FocusWorkbenchTab SurfaceFiles ]
                && jumpedHome.spotlight
                == SurfaceTaskbar
                && jumpedHomeFocus
                == [ FocusWorkbenchTab SurfaceTaskbar ]

        ( currentMiss, _ ) =
            SiteMain.transition
                (FocusSettled 1 (FocusWorkbenchTab SurfaceFiles) (Err (Dom.NotFound "wl-tab-files")))
                wrappedLeft

        ( staleMissIgnored, _ ) =
            SiteMain.transition
                (FocusSettled 1 (FocusWorkbenchTab SurfaceFiles) (Err (Dom.NotFound "wl-tab-files")))
                wrappedBackRight

        ( wrongTargetIgnored, _ ) =
            SiteMain.transition
                (FocusSettled 2 (FocusWorkbenchTab SurfaceFiles) (Err (Dom.NotFound "wl-tab-files")))
                wrappedBackRight

        focusSettledGuardsOk =
            currentMiss.lastTabFocusMiss
                == Just "wl-tab-files"
                && staleMissIgnored.lastTabFocusMiss
                == Nothing
                && wrongTargetIgnored.lastTabFocusMiss
                == Nothing

        -- 6. Strict missing-only optional field decoding & IME composition safety
        missingOptionalDefaultsOk =
            Decode.decodeValue
                SiteMain.decodeWorkbenchTabKey
                (keyEvent [ ( "key", Encode.string "ArrowRight" ) ])
                == Ok ( KeyboardStepSpotlight 1, True )
                && Decode.decodeValue
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent [ ( "key", Encode.string "Escape" ) ])
                == Ok EscapeMobileNav

        explicitNullRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.null )
                    ]
                )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent
                        [ ( "key", Encode.string "ArrowRight" )
                        , ( "keyCode", Encode.null )
                        ]
                    )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "isComposing", Encode.null )
                        ]
                    )

        wrongTypeRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.string "false" )
                    ]
                )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "keyCode", Encode.string "27" )
                        ]
                    )

        imeRejectedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent
                    [ ( "key", Encode.string "ArrowRight" )
                    , ( "isComposing", Encode.bool True )
                    ]
                )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent
                        [ ( "key", Encode.string "ArrowLeft" )
                        , ( "keyCode", Encode.int 229 )
                        ]
                    )
                && decodesErr
                    SiteMain.decodeWorkbenchTabKey
                    (keyEvent [ ( "key", Encode.string "Process" ) ])
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "isComposing", Encode.bool True )
                        ]
                    )
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent
                        [ ( "key", Encode.string "Escape" )
                        , ( "keyCode", Encode.int 229 )
                        ]
                    )

        tabNeverTrappedOk =
            decodesErr
                SiteMain.decodeWorkbenchTabKey
                (keyEvent [ ( "key", Encode.string "Tab" ) ])
                && decodesErr
                    (SiteMain.decodeEscapeKey EscapeMobileNav)
                    (keyEvent [ ( "key", Encode.string "Tab" ) ])

        -- 7. Theme, motion, cues, and outcome state transitions
        ( dawnModel, _ ) =
            SiteMain.transition (SelectTheme ThemeDawn) initialModel

        ( hcModel, _ ) =
            SiteMain.transition (SelectTheme ThemeHighContrast) dawnModel

        ( reducedModel, _ ) =
            SiteMain.transition ToggleMotion hcModel

        ( cueToggled, _ ) =
            initialModel
                |> SiteMain.transition ToggleWindowFocused
                |> Tuple.first
                |> SiteMain.transition ToggleActiveApplication
                |> Tuple.first
                |> SiteMain.transition ToggleSwitcherCandidate

        ( refusedModel, _ ) =
            SiteMain.transition (SelectOutcomeSample SampleRefused) cueToggled

        appearanceAndLabsOk =
            dawnModel.theme
                == ThemeDawn
                && hcModel.theme
                == ThemeHighContrast
                && reducedModel.motion
                == MotionReduced
                && cueToggled.cues
                == { windowFocused = False, activeApplication = False, switcherCandidate = True }
                && refusedModel.outcomeSample
                == SampleRefused
    in
    [ ( "initialModelDefaults", initCheck )
    , ( "mvpMatrixHasFourDistinctTiers", rowIdsOk )
    , ( "mvpMatrixRecordsD6becb72LedgerAndVmSearchFacts", ledgerAndVmFactsOk )
    , ( "mvpMatrixSeparatesSimulatedVmExit1AndNativeLimits", acceptanceLimitsOk )
    , ( "allSixteenCanonicalScenarioSlugsPresent", scenarioSlugsOk )
    , ( "scenarioCategoryPartitionSumsToSixteen", scenarioPartitionOk )
    , ( "scenarioFilterIndependentOfFeatureFilter", independentFiltersOk )
    , ( "mobileNavEscapeClosesAndRestoresToggleFocus", mobileEscapeOk )
    , ( "eightSurfaceRovingTabWrapHomeAndEnd", rovingTabsOk )
    , ( "focusSettledRejectsStaleSeqAndWrongTarget", focusSettledGuardsOk )
    , ( "genuinelyMissingOptionalEventFieldsDefaultCleanly", missingOptionalDefaultsOk )
    , ( "explicitNullOptionalEventFieldsStrictlyRejected", explicitNullRejectedOk )
    , ( "wrongTypedOptionalEventFieldsStrictlyRejected", wrongTypeRejectedOk )
    , ( "imeComposing229AndProcessStrictlyIgnored", imeRejectedOk )
    , ( "tabKeyNeverTrappedByWorkbenchOrHeader", tabNeverTrappedOk )
    , ( "appearanceCuesAndOutcomeTransitionsPure", appearanceAndLabsOk )
    ]


payload : Encode.Value
payload =
    let
        allPassed =
            List.all Tuple.second checks
    in
    Encode.object
        [ ( "fixture", Encode.string "SiteMainHeadFixture2325" )
        , ( "passed", Encode.bool allPassed )
        , ( "checkCount", Encode.int (List.length checks) )
        , ( "checks"
          , Encode.object
                (List.map (\( name, ok ) -> ( name, Encode.bool ok )) checks)
          )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing payload )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
