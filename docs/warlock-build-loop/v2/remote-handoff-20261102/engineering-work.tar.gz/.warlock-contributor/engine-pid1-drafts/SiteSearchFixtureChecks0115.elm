port module SiteSearchFixtureChecks0115 exposing (main)

{-| Pure-Elm deterministic replay & contract fixture for
`SiteSearchCssFree0105.elm` (`site/src/SiteSearch.elm`).
Worker executes zero compiler/Node/browser/VM commands; Root compiles and runs
in an isolated staging directory alongside `SiteSearch.elm`.
-}

import Browser.Dom as Dom
import Json.Decode as Decode
import Json.Encode as Encode
import Platform
import SiteSearch
    exposing
        ( AppearanceTheme(..)
        , CategoryFilter(..)
        , Model
        , MotionMode(..)
        , Msg(..)
        , allRoutes
        , decodeEscapeClear
        , decodeEscapeMenu
        , filteredRoutes
        , initialModel
        , update
        )


port outgoing : Encode.Value -> Cmd msg


keyEvent : List ( String, Encode.Value ) -> Encode.Value
keyEvent pairs =
    Encode.object pairs


decodesOk : Decode.Decoder a -> Encode.Value -> Bool
decodesOk decoder raw =
    case Decode.decodeValue decoder raw of
        Ok _ ->
            True

        Err _ ->
            False


decodesErr : Decode.Decoder a -> Encode.Value -> Bool
decodesErr decoder raw =
    not (decodesOk decoder raw)


hasPath : String -> List SiteSearch.RouteEntry -> Bool
hasPath target entries =
    List.any (\r -> r.path == target) entries


checks : List ( String, Bool )
checks =
    let
        -- 1. Complete 42-route registry and exact 3+4+14+20+1 partition
        partitionOk =
            List.length allRoutes
                == 42
                && List.length (filteredRoutes "" FilterAll)
                == 42
                && List.length (filteredRoutes "" FilterDesktopAndHome)
                == 3
                && List.length (filteredRoutes "" FilterArchitectureAndStart)
                == 4
                && List.length (filteredRoutes "" FilterFoundationsAndStyles)
                == 14
                && List.length (filteredRoutes "" FilterComponents)
                == 20
                && List.length (filteredRoutes "" FilterReference)
                == 1

        -- 2. Beta walkthrough, application-only, tokens, and Backend diagnostics queries resolve
        queriesResolveOk =
            hasPath "index.html" (filteredRoutes "beta walkthrough" FilterAll)
                && hasPath "index.html" (filteredRoutes "application-only" FilterAll)
                && hasPath "get-started/index.html" (filteredRoutes "application-only" FilterAll)
                && hasPath "get-started/index.html" (filteredRoutes "download tokens" FilterAll)
                && hasPath "architecture/index.html" (filteredRoutes "backend diagnostics" FilterAll)
                && hasPath "test-drive/index.html" (filteredRoutes "simulated fixtures" FilterAll)
                && List.isEmpty (filteredRoutes "zzzz-nonexistent-query" FilterAll)

        -- 3. Three-theme (Night / Dawn / HighContrast) & motion transitions (parity with SiteMain)
        ( dawnModel, _ ) =
            update (SelectTheme ThemeDawn) initialModel

        ( hcModel, _ ) =
            update (SelectTheme ThemeHighContrast) dawnModel

        ( redMotionModel, _ ) =
            update (SelectMotion MotionReduced) hcModel

        appearanceParityOk =
            initialModel.theme
                == ThemeNight
                && dawnModel.theme
                == ThemeDawn
                && hcModel.theme
                == ThemeHighContrast
                && redMotionModel.motion
                == MotionReduced

        -- 4. IME composition Escape (isComposing = True or keyCode = 229) strictly ignored
        activeSearchModel =
            { initialModel | query = "footz", mobileNavOpen = True }

        imeSafeOk =
            decodesErr (decodeEscapeClear activeSearchModel)
                (keyEvent [ ( "key", Encode.string "Escape" ), ( "isComposing", Encode.bool True ) ])
                && decodesErr (decodeEscapeClear activeSearchModel)
                    (keyEvent [ ( "key", Encode.string "Escape" ), ( "keyCode", Encode.int 229 ) ])
                && decodesErr decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ), ( "isComposing", Encode.bool True ) ])
                && decodesErr decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ), ( "keyCode", Encode.int 229 ) ])
                && decodesErr (decodeEscapeClear initialModel)
                    (keyEvent [ ( "key", Encode.string "Escape" ) ])

        -- 5. Non-composing Escape clears active query and closes mobile drawer
        ( clearedModel, _ ) =
            update EscapeClearQuery activeSearchModel

        ( closedDrawerModel, _ ) =
            update EscapeMobileNav clearedModel

        escapeActionsOk =
            decodesOk (decodeEscapeClear activeSearchModel)
                (keyEvent [ ( "key", Encode.string "Escape" ) ])
                && decodesOk decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ) ])
                && clearedModel.query
                == ""
                && closedDrawerModel.mobileNavOpen
                == False

        -- 6. Explicit null / wrong-type optional event fields rejected
        strictDecoderOk =
            decodesErr decodeEscapeMenu
                (keyEvent [ ( "key", Encode.string "Escape" ), ( "isComposing", Encode.null ) ])
                && decodesErr decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ), ( "keyCode", Encode.string "0" ) ])

        -- 7. FocusSettled records missing DOM id cleanly without crashing
        ( missModel, _ ) =
            update (FocusSettled (Err (Dom.NotFound "query"))) initialModel

        ( okFocusModel, _ ) =
            update (FocusSettled (Ok ())) missModel

        focusErrorTrackingOk =
            missModel.lastFocusError
                == Just "query"
                && okFocusModel.lastFocusError
                == Nothing
    in
    [ ( "fortyTwoRoutesExactCategoryPartition", partitionOk )
    , ( "betaWalkthroughAppOnlyTokensAndDiagnosticsQueriesResolve", queriesResolveOk )
    , ( "threeThemeHighContrastAndReducedMotionParity", appearanceParityOk )
    , ( "imeComposingAnd229EscapeStrictlyIgnored", imeSafeOk )
    , ( "nonComposingEscapeClearsQueryAndClosesDrawer", escapeActionsOk )
    , ( "explicitNullOrWrongTypeEventFieldsRejected", strictDecoderOk )
    , ( "focusSettledTracksDomNotFoundCleanly", focusErrorTrackingOk )
    ]


payload : Encode.Value
payload =
    let
        allPassed =
            List.all Tuple.second checks
    in
    Encode.object
        [ ( "fixture", Encode.string "SiteSearchFixtureChecks0115" )
        , ( "passed", Encode.bool allPassed )
        , ( "checkCount", Encode.int (List.length checks) )
        , ( "checks"
          , Encode.object
                (List.map (\( name, ok ) -> ( name, Encode.bool ok )) checks)
          )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing payload )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
