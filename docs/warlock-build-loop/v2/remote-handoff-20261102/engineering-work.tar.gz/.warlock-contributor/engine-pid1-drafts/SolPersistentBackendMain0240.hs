-- Host integration, deliberately NO standalone process main. Root supplies an
-- already live same-process QA host and owns its termination/disposition.
module SolPersistentBackendMain0240 (runHosted) where

import Control.Exception (SomeAsyncException, SomeException, fromException, mask, throwIO, try)
import Data.IORef (IORef, atomicModifyIORef')
import Foreign.StablePtr (StablePtr, newStablePtr)
import Warlock.Backend (BackendConfig)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline)
import SolPersistentBackendLifecycle0240

-- Concrete existing-host wiring:
--   roots <- newIORef []              -- once in Root's persistent QA host
--   result <- runHosted roots mode trustedConfig originalQaD receiptPath
-- Keep that SAME host alive and roots retained after BOTH Right and Left.
-- Root alone disposes a case; freeStablePtr is never inferred from assertion
-- success, timeout, Bool False, or an external guardian ACK. StablePtr protects
-- only while THIS Haskell process lives; it cannot survive process termination.
-- Root's guardian/namespace/artifact ownership is a separate obligation.
runHosted :: IORef [StablePtr Retained] -> Mode -> BackendConfig
  -> AdmissionDeadline -> FilePath -> IO (Either SomeException ())
runHosted roots mode config original receiptPath = mask $ \restore -> do
  retained <- newRetained
  root <- newStablePtr retained
  -- A failed publication may leak a StablePtr but cannot release the retained
  -- case. No Backend worker/acquisition exists before this publication.
  atomicModifyIORef' roots (\old -> (root:old,()))
  result <- try (restore (runCase mode retained config original receiptPath))
  -- Honor host cancellation while leaving the strong root installed. An async
  -- interruption is neither a clean refusal nor permission to dispose a case.
  case result of
    Left problem -> case fromException problem :: Maybe SomeAsyncException of
      Just _ -> throwIO problem
      Nothing -> pure result
    Right () -> pure result
