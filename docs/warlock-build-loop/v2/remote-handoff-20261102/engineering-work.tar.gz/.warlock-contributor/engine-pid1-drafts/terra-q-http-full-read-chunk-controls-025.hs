{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY, UNEXECUTED. Distinct process/Case per mode, with the real
-- same-owner Engine scope, root and independent guardian strongly retained.
-- QA hook records before INSIDE each admitted physical hGetSome, and parks
-- after its first nonempty returned chunk, OUTSIDE that step's admission.
module QHttpFullReadChunk025 (Mode(..),Case,newCase,runResolution,finishCase,releaseBarrier) where
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try)
import Control.Monad (unless,void)
import qualified Data.ByteString as B
import Data.IORef
import System.Posix.Types (Fd)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..),requestSessionStop,tryPersistentStopDeadline)
import Warlock.Platform.Descriptor (ReadCustody,newReadCustody,QaReadState(..),qaReadState,qaReadChunkHook)
import Warlock.Platform.Resolver.Internal
 (Root,Pin,Link,Resolution,ResolveError,Hooks,RootAdmission,RootAdmissionFailure(..),
  RootStepResult(..),LeaseCustody,LeasePart(..),LeaseObservation(..),newLeaseCustody,
  observeLeaseCustody,closeLeasePart,ProbeCustody,ProbeObservation(..),newProbeCustody,
  observeProbeCustody,resolveSnapshotViaRetainedFull)

data Mode = Positive | StopAfterFirstChunk deriving (Eq,Show)
type Attempt = Either SomeException (Either RootAdmissionFailure (Either ResolveError (Resolution,())))
type LeaseReceipts = (Either RootAdmissionFailure RootStepResult,Either RootAdmissionFailure RootStepResult)
data Case = Case PersistentOwner StopBudget LeaseCustody ProbeCustody ReadCustody
 (IORef [String]) (IORef Bool) (IORef Bool) (MVar ()) (MVar ()) (MVar (Attempt,Maybe LeaseReceipts))
newCase :: PersistentOwner -> StopBudget -> IO Case
newCase owner budget = Case owner budget <$> newLeaseCustody <*> newProbeCustody <*> newReadCustody
 <*> newIORef [] <*> newIORef False <*> newIORef False <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ _ _ _ _ release _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("full-read: " ++ label)))
withinBounds :: [AdmissionDeadline] -> String -> IO a -> IO a
withinBounds ds label action = do
 remaining <- mapM remainingMicros ds
 let left = minimum remaining
 if left <= 0 then ioError (userError (label ++ ": retain owner and guardian")) else do
  r <- timeout left action
  maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure r

-- The host supplies the genuine SAME owner Engine rank-2 startup step, its
-- actual lexical admitted Root and real pin/identity path. It creates a real
-- regular 131073-byte file consisting entirely of ASCII a, and supplies the
-- actual correct pins/links for that file. It does not fake the admission,
-- result, binding, scope or close receipts. Root/lease/probe/read ownership
-- equivalence is a HOST PRECONDITION; 024 does not authenticate that binding.
runResolution :: Case -> AdmissionDeadline -> RootAdmission -> Root -> [Pin] -> B.ByteString -> [Link] -> Hooks -> IO ()
runResolution (Case _ _ leaseOwner probeOwner readOwner events parked used first release done)
 originalD admit root pins path links hooks = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\was -> (True,not was))
 check "single case" fresh
 let hook name = do
      atomicModifyIORef' events (\xs -> (name:xs,()))
      if name == "after" then do
       firstTime <- atomicModifyIORef' parked (\old -> (True,not old))
       if firstTime then putMVar first () >> readMVar release else pure ()
      else pure ()
     consume :: Fd -> B.ByteString -> IO ()
     consume _ bytes = check "complete independently literal file content" (bytes == B.replicate 131073 97)
     digest = "7e009ea4ef882e385b3c0bcbbfa8d009bb0a633bdd764415c09182ee0e75da73"
 qaReadChunkHook hook
 result <- try $ restore $ withinBounds [originalD] "real full resolver" $
  resolveSnapshotViaRetainedFull admit leaseOwner probeOwner readOwner root pins path links 131073 131073 digest hooks consume
 -- Close the actual retained lease parts only on the positive path, through
 -- the SAME lexical admission. No physical close is attempted after refusal.
 leases <- case result of
  Right (Right (Right _)) -> do
   a <- admit (closeLeasePart leaseOwner LeaseRoot)
   b <- admit (closeLeasePart leaseOwner LeaseProc)
   pure (Just (a,b))
  _ -> pure Nothing
 putMVar done (result,leases)

-- Supervisor is distinct and retained. The owner scope thread is parked
-- after one real chunk, not inside hGetSome. This tests refusal of the NEXT
-- subaction; it makes no claim that an already-entered syscall is canceled.
finishCase :: Case -> AdmissionDeadline -> Mode -> IO ()
finishCase c@(Case owner budget leaseOwner probeOwner readOwner events _ _ first _ done) originalD mode = do
 withinBounds [originalD] "actual first returned chunk" (readMVar first)
 before <- reverse <$> readIORef events
 state <- qaReadState readOwner
 check "first actual chunk precedes barrier" (before==["before","after"] && state==QaReadReading)
 stopD <- case mode of
  Positive -> pure Nothing
  StopAfterFirstChunk -> do
   receipt <- withinBounds [originalD] "actual same-owner stop" (requestSessionStop owner budget)
   selected <- tryPersistentStopDeadline owner
   check "prelive first stop latched" (receipt==StopLatchedBeforeLive)
   case selected of
    StopDeadlineLatched d -> pure (Just d)
    _ -> ioError (userError "actual first StopD unavailable")
 releaseBarrier c
 let bounds = originalD : maybe [] pure stopD
 (result,leases) <- withinBounds bounds "actual resolution return" (readMVar done)
 seen <- reverse <$> readIORef events
 readState <- qaReadState readOwner
 probe <- observeProbeCustody probeOwner
 lease <- observeLeaseCustody leaseOwner
 case mode of
  Positive -> check "literal bytes, multiple actual reads and separately admitted closes" $
   (case result of Right (Right (Right _)) -> True; _ -> False) &&
   length (filter (=="before") seen) >= 3 && readState==QaReadClosed &&
   probe==ProbeRetired && lease==LeaseRetired && leases==Just (Right RootStepClosed,Right RootStepClosed)
  StopAfterFirstChunk -> do
   later <- tryPersistentStopDeadline owner
   check "next physical chunk never entered and uncertain read is not retried" $
    seen==["before","after"] && readState==QaReadReading && leases==Nothing &&
    later==maybe StopDeadlineNotLatched StopDeadlineLatched stopD &&
    case result of Right (Left RootAdmissionUnknown) -> True; _ -> False
-- Raw historical ProbeRetired/LeaseRetired/ReadClosed are local physical
-- observations only. Current original D, owner binding and whole cleanup
-- require separate same-owner authority and cannot be inferred here.
