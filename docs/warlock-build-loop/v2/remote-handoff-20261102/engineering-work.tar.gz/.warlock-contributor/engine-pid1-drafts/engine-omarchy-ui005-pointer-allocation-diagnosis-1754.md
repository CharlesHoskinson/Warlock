# UI005 (`search-no-match`) GTK4 Allocation, `run-03..08` Pointer Hit-Test & Query-Route Diagnosis (`1754` Wave)

- **Author / Bus Identity**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Active Slice**: `.warlock-contributor/ui005-haskell-search.json` (`ELM-UI-005` / `search-no-match`)
- **Source Revision Inspected**: `3f88ed9b498cf07d7c944cdcb3cb27163358b310`
- **Declared Slice Paths Verified**:
  - `implementation/warlock/src/Main.elm` (`a63de0a105e1a13edc5eb67359b665032acba662650659b3a2d4f1999058b66`)
  - `implementation/warlock/src/Surface.elm` (`c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb`)
  - `implementation/warlock/src/HttpPopup.elm` (`4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354`)
  - `implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc` (`57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6`)
- **Provenance & Execution Honesty**:
  - Root executed its own outside-repository helpers (`manual-physical-07.py` / `physical-journey-07.py` and `manual-physical-08.py` / `physical-journey-08.py`) under `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-idle-20261101T172728Z/`.
  - `gemini-omarchy`'s preparation skeleton (`engine-omarchy-host-qmp-driver-1719.py`) was **not** executed.
  - All `242` requirements, `417` scenarios, `15/242` whole, `39/417` scenarios, `HOSTSTOP2`, `nativeOperations = []`, `EngineResult False False` (`providerCleanupQualified = False`), `nativeAccepted = False`, and `releaseAccepted = False` remain unchanged.

---

## 1. Executive Conclusion: Zero Demonstrated Product Source Defect

1. **Screenshot-observed rendered bounds show neither `pView` nor `cView` visually overlapped `(715, 77)` in `run-07` (with explicit `observeGtkWindow` epistemic boundary)**: `Mvp.hsc:838-859` requests `gtk_widget_set_size_request(-1, 72)` on `bView`, `(640, 480)` on `pView` (`vexpand=1`), and `(1, 1)` `can_target=0` on `cView`, while `observeGtkWindow` (`Mvp.hsc:879-915`) observes only the outer `GdkSurface` dimensions/active state/monitor and never inspects runtime child `GtkWidget` allocations or hit targets. Screenshot scanlines (`run-07-ready.png`) confirm `bView` visually paints `y = 38..109` (`72px`) and `pView` visually begins at `y = 110`, placing `(715, 77)` (`rel_y = 39` when `at = [647, 38]`) `13px` above `<button id="bar:applications">`'s painted bottom border (`y = 90`).
2. **Cross-run `physical-inputs.jsonl` comparison disproves a deterministic `y = 65` vs `y = 77` DOM split**: In `run-04` (`pid = 109220`, `at = [647, 38]`, `physical-inputs.jsonl` rows `5..6`), the identical single-packet `0.04s` helper clicked `box = [660, 45, 770, 85]` -> center **`(715, 65)`** (the exact coordinate that succeeded in `run-03`) and **also** failed to open (`callbacks = 3, operations = 1`).
3. **`run-07` arrow cursor & no-open are retained as observed facts with candidate QA pointer-entry/timing explanations (not an established internal GTK/WebKit mechanism)**:
   - RGB pixel diff between `run-07-ready.png` and `run-07-applications-open.png` shows the hardware cursor jumped in a single QMP `abs` packet from outside the Warlock window (`I-beam` at `x = 634..646, y = 389..411` over the left half of the desktop) directly to `(715, 77)` (`arrow` cursor at `x = 713..725, y = 77..99`), slept `0.04s` (+ SSH `gate`), and clicked without any subsequent intra-surface `wl_pointer.motion`.
   - Candidate QA-side mechanisms (unproven internally without GTK/WebKit event tracing) include: (a) single-packet QMP `abs` surface entry + `0.04s` hold lacking a subsequent intra-surface `wl_pointer.motion` / post-map `WebKitWebProcess` hit-test readiness, and (b) in narrow `621px` tiles (`< 640px` `pView` size request), `.surface-actions` (`overflow-x: auto`) rendering a horizontal overlay scrollbar (`y = 87..90`) whose GTK hover/grab zone can extend upward toward `y ≈ 77`.
4. **Verified by `run-08` on unchanged product binaries (`3f88ed9b4`)**:
   - In `physical-journey-08.py` / `manual-physical-08.py`, Root added `time.sleep(3)` after initial `ready` match plus a **second intra-surface QMP `abs` motion** (`(x, y)` -> `sleep(0.12)` -> `(x - 3, y)` -> `sleep(0.12)` -> `gate` -> `down` -> `sleep(0.12)` -> `up`).
   - With zero Elm/Haskell edits, `run-08` switched the cursor to the WebKit hand pointer (`run-08-applications-open.png`), opened the `62`-entry catalog, focused `#launcher-search`, typed `qvxz9`, and retained both `"qvxz9"` in the input and `"No matching applications. Change your search or Refresh."` in popup and bar status (`run-08-query.png`, `completedPhysicalSequence: true`).

---

## 2. Exact GTK4 Allocation (`Mvp.hsc`) & CSS Hit-Box Geometry (`SurfaceTheme.elm`)

### 2.1 Vertical `GtkBox` Packing (`Mvp.hsc:799-861`)

`createMvpWindow` packs three `WebKitWebView` widgets into a vertical `GtkBox` (`spacing = 0`) inside an undecorated `GtkWindow` (`gtkWindowSetDecorated window 0`, `Mvp.hsc:806`):

| Child Widget | Elm Entry | GTK4 Properties (`Mvp.hsc`) | Window-Relative `rel_y` | Screen `y` at Tiled `at = [647, 38], size = [621, 750]` | Screen `y` at `at = [0, 0], size = [1280, 800]` |
|---|---|---|---|---|---|
| `bView` (`mvpBarView`) | `HttpBar.elm` | `hexpand=1, vexpand=0, size_request=(-1, 72), visible=1` (`838-842`) | `0 .. 71` (`72px`) | `38 .. 109` | `0 .. 71` |
| `pView` (`mvpPopupView`) | `HttpPopup.elm` | `hexpand=1, vexpand=1, size_request=(640, 480), visible=1` (`845-849`) | `72 .. H - 2` | `110 .. 786` (`677px`) | `72 .. 798` (`727px`) |
| `cView` (`mvpControllerView`) | `HttpMain.elm` | `hexpand=0, vexpand=0, size_request=(1, 1), opacity=0, focusable=0, can_target=0` (`852-859`) | `H - 1` (`1px`) | `787` (untargetable) | `799` (untargetable) |

### 2.2 DOM Layout Inside `bView` (`HttpBar.html` + `SurfaceTheme.elm`) and Two Real Geometry Boundaries to Respect in QA Hitboxes

`HttpBar.html` sets `body { padding: 0; margin: 0; }` (`16px` root font size):

1. **`.surface-bar` (`SurfaceTheme.elm:284`) vs `bView` `72px` Size-Request (`16px` Unpopulated Strip at `rel_y = 56..71`)**:
   - `.surface-bar` has `height: calc(3em + 8px)` = **`56px`** (`rel_y = 0..55`), with `box-shadow: 0 100vh 0 100vh var(--surface-bg)` painting the remaining `16px` of `bView` (`rel_y = 56..71`, `screen y = 94..109` when `at = [647, 38]`) solid `#100e0e` (`RGB (16, 14, 14)`).
   - **QA rule**: Never target `rel_y = 56..71` (`screen y = 94..109` at `at = [647, 38]`); it is inside `bView`'s `72px` GTK allocation, looks visually continuous with the bar background, and contains no DOM controls.
   - This is **not** why `run-07` missed: `run-07` clicked `(715, 77)` -> `rel_y = 39`, which is `17px` above `rel_y = 56`.
2. **Narrow Tiled Width (`621px`) `.surface-actions` Horizontal Overlay Scrollbar (`rel_y = 49..52`)**:
   - `<button id="bar:applications">` (`SurfaceTheme.elm:825-828`) has `height: calc(100% - 6px)` = `50px`, `margin: 3px`, spanning **`rel_y = 3..52`** (`screen y = 41..90` at `at = [647, 38]`; active pill fill `RGB (54, 29, 33)`, `"Applications"` text glyphs at `rel_y = 22..33` / `screen y = 60..71`).
   - At tiled width `621px` (`run-03..07`), `.surface-status` (`clamp(180px, 40vw, 360px)` = `248.4px`) leaves `372.6px` for `.surface-actions` (`overflow-x: auto`, `SurfaceTheme.elm:287`), which overflows horizontally across the 7 bar buttons (`Applications`, `Task View`, `Switch windows`, `Notifications`, `Files`, `System`, `Settings`).
   - Direct RGB scan of `run-07-ready.png` confirms a GTK/WebKit horizontal overlay scrollbar thumb (`RGB (94, 73, 77)`) painted across `x = 653..833, y = 87..90` (`rel_y = 49..52`), which faded back to button fill `RGB (54, 29, 33)` in `run-07-applications-open.png`. In GTK4/WebKitGTK, horizontal overlay scrollbars on `.surface-actions` (`y = 38..93`) maintain a wider interactive hover/grab hit-zone (`~14–16px` tall above the bottom edge `y = 93`, i.e., `y ≈ 77..93`) so pointer hover can expand the scrollbar thumb — an additional unproven candidate (alongside single-`abs` `0.04s` warp and `pView`'s `640px` `gtk_widget_set_size_request` exceeding the `621px` tiled Wayland configure width) for why `y = 77` specifically kept an arrow cursor in narrow `621px` tiles. At `1280px` width (`run-08-ready.png`), all 7 buttons fit without overflow and no scrollbar exists.
   - **QA rule**: Keep bar button hitboxes in the upper/glyph band **`rel_y = 22..34`** (e.g. `rel_y = 26..30` used in `physical-journey-08.py:53`), avoiding both the `rel_y = 39..55` lower overlay-scrollbar hit-slop/thumb band in narrow tiles and the `rel_y = 56..71` unpopulated `bView` size-request strip.

---

## 3. Pixel & Input-Log Proof Across `run-03`, `run-04`, `run-07`, and `run-08`

| Run | Engine PID | Window `at` / `size` / `fullscreen` | `Applications` Click Box -> Center (`rel_y`) | Pointer Motion Sequence | Observed Outcome |
|---|---|---|---|---|---|
| `run-03` | `108512` | `[647, 38]` / `[621, 750]` / `0` | `[660, 45, 770, 85]` -> `(715, 65)` (`rel_y = 27`) | Single `abs` + `0.04s` | Opened `62` matching apps (`run-03-apps-settled.png`); subsequent search step did not focus `#launcher-search` (`run-03-query.png`) |
| `run-04` | `109220` | `[647, 38]` / `[621, 750]` / `0` | `[660, 45, 770, 85]` -> **`(715, 65)` (`rel_y = 27`)** | Single `abs` + `0.04s` | **Did not open** (`callbacks = 3, operations = 1` — identical coordinate to `run-03`) |
| `run-07` | `113418` | `[647, 38]` / `[621, 750]` / `0` | `[660, 68, 770, 86]` -> `(715, 77)` (`rel_y = 39`) | Single `abs` from outside window (`x=634..646, y=389..411`) + `0.04s` | **Did not open**; pixel diff (`1292` px) shows cursor at `(713..725, 77..99)` stayed **arrow**, never WebKit hand (`run-07-applications-open.png`) |
| `run-08` | `114722` | `[0, 0]` / `[1280, 800]` / `2` | `[13, 26, 123, 30]` -> `(68, 28)` (`rel_y = 28`) | `3s` post-ready settle + **two `abs` steps** (`(x,y)` -> `0.12s` -> `(x-3,y)` -> `0.12s`) + `0.12s` hold | **Opened `62` apps** (hand cursor visible in `run-08-applications-open.png`), focused `#launcher-search` (`[33, 202, 543, 227]`), typed `qvxz9`, retained query + no-match notice (`run-08-query.png`) |

### Important Operational Note on `run-08` `fullscreen = 2` (`idle-before-run-08.json`)

Between `run-07` (`17:52Z`) and `run-08` (`17:56Z`), `>150s` elapsed with idle re-enabled, firing Omarchy's screensaver cycle (`idle-before-run-08.json`: `"inIdleCycle": true, "screensaverStarted": true, "screensaverWindows": 1, "lastEvent": "process-exit: screensaver exitCode=0 status=0"` at `2026-11-01T17:55:19.521Z`). When `run-08` launched `warlock-ui-owner` (`pid = 114722`), Hyprland mapped it on workspace `1` with `'fullscreen': 2, 'fullscreenClient': 2` (`at = [0, 0], size = [1280, 800]`, hiding `omarchy-bar` with `alpha = 0`), while `Foot` (`pid = 2095`) remained intact and mapped in `clients` (`at = [12, 38], size = [621, 750], visible = False`).

Because `physical-journey-08.py` translated both hitboxes from current `identity['at']`:
- At `at = [0, 0]` (`fullscreen = 2`), `#launcher-search` spans `y = 192..235` (`rel_y = 192..235`), and `Search` click `[33, 202, 543, 227]` (`rel_y = 202..227`) landed dead center.
- At normal tiled `at = [647, 38]` (`fullscreen = 0` alongside visible `Foot`), `run-03-apps-settled.png` pixel scan shows `#launcher-search` spans `y = 232..273` (`rel_y = 194..235`), so the same relative box `(x+33, y+202, x+543, y+227)` = `[680, 240, 1190, 265]` (`rel_y = 202..227`) **also** lands dead center inside `#launcher-search` (`621px` window right edge is `647 + 621 = 1268 > 1190`). If Root wants an explicit tiled (`fullscreen == 0`, visible side-by-side `Foot`) physical search run, clearing `inIdleCycle` / workspace fullscreen state before controller launch preserves `at = [647, 38], size = [621, 750]`.

---

## 4. Verification of Declared `UI005/search-no-match` Source Route

Inspection of all four declared slice paths in `3f88ed9b498cf07d7c944cdcb3cb27163358b310` confirms the compiled Elm/Haskell search-no-match path is coherent and needs no speculative source edit:

1. **`Mvp.hsc:816-835` (`createMvpWindow`)**: Window-level `GtkEventControllerKey` (`GTK_PHASE_CAPTURE`) records physical `Escape` (`gdkKeyEscape`) into `escapeRef` and unconditionally returns `0` (`GDK_EVENT_PROPAGATE`), delivering printable key events untouched to the focused `pView` (`WebKitWebView`).
2. **`HttpPopup.elm` + `Popup.elm:54, 71-118`**:
   - `<input id="launcher-search">` (`Surface.elm:343`) emits `LocalAction` with `surfaceProtocol`, `kind = "surface-query"`, `surface = "popup"`, `publication`, `lease`, `id = "control:search"`, and `query`.
   - `Popup.elm:80-83, 106-116` retains `pendingQuery = Just query` across `Present` snapshots on the same `(lease, mode, fieldIdentity)` so user typing is never overwritten by concurrent surface publications while in flight over `UiHttp`, and guards `entry:*` launches (`Popup.elm:101`) while `pendingQuery /= Nothing` or IME composition is active (`isComposing`).
3. **`HttpMain.elm:20-50` & `Main.elm:15-29`**: Both share the single `DesktopPolicy` authority (`Policy.update`). `Mvp.hsc` routes `popup` HTTP action frames to `HttpMain`, which feeds `Policy.Incoming` -> `Desktop.update`.
4. **`Surface.elm:309, 343, 483, 559, 575` & `Desktop.elm:1334-1336`**:
   - `Surface.decode` (`559, 575`) strictly validates `["surfaceProtocol","kind","surface","publication","lease","id","query"]` with `role == "popup"`, `model.open == True`, and `id == "control:search"`, producing `Desktop.SearchQuery stamp value`.
   - `Desktop.update` (`1334-1336`) checks `capture model == Just stamp`, `model.open`, `String.length query <= 256`, and absence of control characters (`< 32` or `127`), then advances `{ model | query = query, applicationPage = 0 }` with `[]` effects (zero `application-launch` intent).
   - When `Catalog.search model.query` is empty (`"qvxz9"`), `Surface.elm:309, 483` renders zero `entry:*` launch buttons, retains `label = model.query` in `#launcher-search`, and sets status/notice to `"No matching applications. Change your search or Refresh."` — matching `run-08-query.png` verbatim.
   - **Authoritative Status vs `Popup.pendingQuery` Precision Note**: Because `HttpBar.elm` (`bView`) has **no** local `pendingQuery` overlay (`Bar.elm` renders accepted `Present` snapshots from `HttpMain` only), the appearance of `"No matching applications. Change your search or Refresh."` in `bView`'s `.surface-status` in `run-08-query.png` (`0.4s` after typing completed) proves `HttpMain` / `Desktop.SearchQuery` authoritatively received and published at least one non-matching query over `UiHttp`, whereas the exact trailing character(s) of `"qvxz9"` inside `pView`'s `#launcher-search` could in principle reflect either `snapshot.query` or `Popup.pendingQuery` (`Popup.elm:54`) without an explicit final-snapshot `queryValue` receipt.

---

## 5. Targeted Updates Applied to Unexecuted `engine-omarchy-host-qmp-driver-1719.py`

Per Root's instruction (fix concrete gaps only in our own unexecuted draft; no new orchestrator rewrite or approval gate):
1. **`sol-docs` `01M6C38KJ81FHET3TFE2EBNGA1` Caveat Fixed**: Reworded `assert_pre_dispatch_budget` docstring and module header so it states accurately that it checks **pre-dispatch remaining budget under stated timeout/clock assumptions**; host OS scheduling, Python `subprocess(..., timeout=...)`, and QMP socket delivery are not hard real-time guarantees, and any timeout or late/uncertain completion fails closed.
2. **`D8sreserve` Floor Alignment**: Raised `min_remaining_seconds` floor and CLI default for `click-hitbox` and `send-keys` to `8.0s` (matching Root's `8s` `D` reserve on the `28s` trial budget).
3. **Two-Step Intra-Hitbox QMP Motion**: Updated `cmd_click_hitbox` Phase 2 to send initial `abs` motion to `(tx, ty)`, settle `0.12s`, send a second intra-hitbox `abs` motion to `(tx_settle, ty)` clamped strictly inside `[x0 + 2, x1 - 2]`, and settle `0.12s` before `postMotionRegate` and `btn down=True`, ensuring `wl_pointer.motion` after `wl_pointer.enter` updates `WebKitWebProcess` hover hit-testing.
4. **Explicit `fullscreen` Recording & Tiled Default Check**: Recorded `win.get("fullscreen")` in `verified["window"]` and defaulted `verify_fence` to require `int(win.get("fullscreen", 0)) == 0` unless `--allow-fullscreen` is explicitly passed, preventing a post-screensaver `fullscreen = 2` workspace state from silently occluding `Foot` during tiled desktop runs.
