# `gemini-gui` Wave `20261101T210356Z` — Independent `attempt-02` Readiness Verification, Minimal QA Host-Driver Delta & Peer Review

- **Author**: `gemini-gui` (`run: warlock-20261031-setup`)
- **Execution Discipline**: Zero product, compiler, model, browser, native, QMP, or VM runtime execution. All original failed/observed evidence files under `/home/charl/vm/omarchy/evidence/` and canonical repository sources remain untouched. No new product GUI/theme patches are introduced while Root integrates the prepared `2039` patches.

---

## 1. Exact Verified Current Paths & SHA-256 Digests

| Role | Exact Current Path on Disk | SHA-256 |
|---|---|---|
| **Baseline `attempt-02` Host Driver (preimage, untouched)** | `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/host-driver.py` | `6ec432d5b742f71ad7908fe97b974eb394bf30f3da7bd8e41ea0d66e7dbf2b48` |
| **Minimal Host-Driver Unified Diff (`2103`)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-host-driver-apps-ready-2103.patch` | `e177395badc3558054d94f632e4c276afa77aeb20c167a8135a58cda6ec2f170` |
| **Post-Patch Candidate Host Driver (`2103`, mode `0700`)** | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-host-driver-apps-ready-2103.py` | `cc0059a3dd53a55e9334f831f10abab3d813c18d396051988e097eea2552e4ca` |
| **Reference Template (`run-03-before.png`)** | `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-idle-20261101T172728Z/run-03-before.png` | `6ff1e06aec45b471039a3991c739d276eed991b4ddf1072a7c1d61210f1e6b84` |
| **Observed Pre-Click Readiness Capture (`001`)** | `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/run-01/001-applications-ready.png` | `97f3cc6ae08fa77ff75267a9f2ac113c1a2889598d29c462f7f126619d8f4040` |
| **Observed Post-Click Bar + Scrollbar Capture (`006`)** | `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/run-01/006-search-label-ready.png` | `8f00c98fc385c75dc7bc312f3ef8640b712075126dc1d8f5d64a6c27478b566a` |
| **Observed `attempt-02` Host Journey Report** | `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/run-01/host-journey-result.json` | `89f2cb5eb3b6cc6571f134f1e29cd2c64c7d09c445305a5d4b6928b517f91003` |
| **Current Haskell GTK4 Multi-WebView Packing** | `/home/charl/code/Warlock/implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc` (`lines 837–850`) | *(canonical repo source)* |
| **Current Haskell HTTP Role/Origin Owner** | `/home/charl/code/Warlock/implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs` (`line 33`) | *(canonical repo source)* |

*(Correction to prior note's path citation: the current Haskell GTK/WebKit bridge is at `/home/charl/code/Warlock/implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc` and `/home/charl/code/Warlock/implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs`, not `/haskell/app`.)*

---

## 2. Independent Verification & Literal Pre/Post Pixel Evidence Bounds

### 2.1 Exact Container & Control Coordinates (`attempt-02/run-01`, `at = [647, 38]`, `size = [621, 750]`)

1. **WebView Vertical Partition (`Warlock/Ui/Mvp.hsc:837-850`)**:
   - `bView` (`mvpBarView`, `gtkWidgetSetSizeRequest bView (-1) 72`): `local y = 0..71` -> **`screen y = 38..109`**.
   - `pView` (`mvpPopupView`): `local y = 72..749` -> **`screen y = 110..787`**.
2. **`001-applications-ready.png` (`97f3cc6a...`)**:
   - Across `screen x = 649..1265, y = 40..107` (`bView` interior), decoded RGB satisfies **`min = [253, 251, 252]`, `max = [255, 253, 254]`** (`luminance >= 252 > 140` everywhere): **`bView` was 100% unpainted white at the `applications-ready` screenshot**, whereas `pView` had already painted `<h1>Choose a window</h1>` at `screen y = 120..148`.
   - Precision bound (per `terra-q-front` `01M6CEEKST3AN1T0N5KGEQ7TZP`): `001-applications-ready.png` proves `bView` was unpainted when the readiness gate passed (`before` QMP motion/press); no screenshot exists at `press` (`~0.6s` later), so guest hit-testing at `press` remains unobserved.
3. **`run-03-before.png` (`6ff1e06a...`) & `006-search-label-ready.png` (`8f00c98f...`)**:
   - Rendered `Applications` button outer border: **`screen x = 653..776, y = 41..90`** (`local x = 6..129, y = 3..52`).
   - Bright `"Applications"` glyph pixels (`ITU-R 601-2 luminance > 140`): **`screen x = 669..762, y = 60..74` inclusive** (`local x = 22..115, y = 22..36`, **`490` bright pixels**).
   - Identical unobstructed upper button band between `run-03-before.png` and `006-search-label-ready.png`: **`screen y = 40..73` (`local y = 2..35`) has `0` differing RGB pixels across `x = 650..780`**.
   - Parked pointer cursor tip in `006-search-label-ready.png` (from `attempt-02`'s `click((13, 28, 123, 45), ...)` at center `(712, 74)`): **`screen x = 710..717, y = 74..78`** (`local y = 36..40`; bright cursor fill begins at `y = 75`).
   - WebKitGTK `.surface-actions` horizontal scrollbar overlay in `006-search-label-ready.png`: **`screen x = 653..779+, y = 79..91` inclusive** (`local y = 41..53`, `125..127` changed RGB pixels per row vs `run-03-before.png`).

### 2.2 Literal Pre-Patch vs Post-Patch Readiness & Click Bounds (`crop` half-open `(x0, y0, x1, y1)`)

| Metric | Pre-Patch (`attempt-02/host-driver.py` `6ec432d5`) | Peer Draft (`terra-engine` `bf2b451b`) | Post-Patch (`gemini-gui` `e177395b`) |
|---|---|---|---|
| **`applications-ready` reference box** | `(670, 120, 850, 148)` *(popup `h1` in `pView`)* | `(666, 57, 765, 77)` *(`bView` label)* | **`(660, 52, 768, 75)`** *(`bView` button interior + full label)* |
| **Translated local box (`origin = expected['at']`)** | `(23, 82, 203, 110)` | `(19, 19, 118, 39)` | **`(13, 14, 121, 37)`** |
| **Template `luminance > 140` foreground / dark surround** | `799 / 4241` (`5040` px) | `490 / 1490` (`1980` px) | **`490 / 1994` (`2484` px — 100% of `"Applications"` glyphs)** |
| **Binary diff vs `001-applications-ready.png` (white bar)** | `0 / 5040` (`bbox = None` — **FALSE PASS**) | `1490 / 1980` (`bbox = (0, 0, 99, 20)` — FAIL-CLOSED) | **`1994 / 2484` (`bbox = (0, 0, 108, 23)` — FAIL-CLOSED)** |
| **Binary diff vs `006-search-label-ready.png` (rendered bar)** | `0 / 5040` (`bbox = None`) | `3 / 1980` (`bbox = (46, 18, 48, 20)` at `y = 75..76` cursor tip) | **`0 / 2484` (`bbox = None` — EXACT MATCH)** |
| **`Applications` click local box** | `(13, 28, 123, 45)` | `(10, 7, 129, 50)` *(reverts `attempt-02` fix)* | **`(13, 14, 121, 37)`** *(100% coincident with readiness mask)* |
| **`Applications` click screen box at `at = [647, 38]`** | `(660, 66, 770, 83)` *(overlaps scrollbar `y = 79..83`)* | `(657, 45, 776, 88)` *(overlaps scrollbar `y = 79..88`)* | **`(660, 52, 768, 75)`** *(`4px` strictly above scrollbar `y = 79..91`)* |
| **Dispatched pointer motion/click center (`cx`, `cx-3`, `cy`)** | `x = 715 -> 712, y = 74` (`local y = 36`) | `x = 716 -> 713, y = 66` (`local y = 28`) | **`x = 714 -> 711, y = 63` (`local y = 25`, `16px` above scrollbar)** |

---

## 3. Minimal Sanitized Failed-Predicate Receipts & Guard Preservation

1. **Sanitized Failed-Predicate Receipt (`fail_receipt` / `check_pred` in `gemini-gui-host-driver-apps-ready-2103.patch`)**:
   - Before any guard assertion (`AssertionError`) or `visible()` timeout (`RuntimeError`), `fail_receipt` appends to `report['events']` and atomically writes (`O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW`, mode `0600`) `run-01/qmp-receipts/failed-predicate-<sequence:04d>-<event_idx:04d>-<predicate>.json`:
     ```json
     {
       "kind": "failed-predicate",
       "predicate": "overlay-layer-disjoint",
       "sequence": 1,
       "action": "motion",
       "targetBox": [13, 14, 121, 37]
     }
     ```
   - On `visible()` mask timeout (`predicate = "visible-mask-match"`), includes only `referenceBox`, `currentBox`, `diffBbox`, and `screenshotName` (`last_path.name`).
   - **Strict Sanitization**: Never prints or writes `env`, key values (`current_key`), `Foot` content or process metadata, or raw `probe()` stdout.
2. **100% Guard & Deadline Preservation**:
   - Retains `if sys.flags.optimize != 0: raise RuntimeError(...)`, `stage['originalTrialDurationSeconds'] == 28`, `reserve_s = 8.0`, `timeout_s = 1.0`, `remainingNs/1e9 - hostProbeSeconds > 10`, all three pinned PID/birth/ppid/pgid/uid/device/inode/size/namespacePids/cgroup/core identity checks, client/foreign-client/layer-level-2-3 disjointness fences, `visible-client-bounds` (`0 <= x0 < x1 <= 1280`, `0 <= y0 < y1 <= 800`, and inside `expected['at']..expected['at']+expected['size']` so `Image.crop` never pads out-of-bounds black pixels), strict cleanup verification (`launcherReaped is True and scopeInventoryConfirmedEmpty is True`), and zero retry on unknown/refusal.

---

## 4. Peer Review Summary

1. **`terra-engine-apps-ready-mask.patch` (`sha256:bf2b451b42f1b06d6d804c21f14b58e39ef7fa4b78c3fc41cc6eb14566dde4b0`)**:
   - **Confirmed**: Correctly identifies that `(670, 120, 850, 148)` matched the popup heading while `001-applications-ready.png`'s bar was white.
   - **Three Concrete Issues Resolved in `e177395b...`**:
     1. Diffed against stale `.warlock-contributor/engine-pid1-drafts/live-usability-host-driver.py` (`0610b012...`) rather than actual `/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/attempt-02/host-driver.py` (`6ec432d5...`), which would omit `sys.flags.optimize != 0` and strict `launcherReaped`/`scopeInventoryConfirmedEmpty` checks if copied directly.
     2. Retains `click((10, 7, 129, 50), 'Applications')`, whose lower range `local y = 41..50` (`screen y = 79..88`) overlaps the WebKitGTK `.surface-actions` horizontal scrollbar (`y = 79..91`) and whose top `local y = 7` triggered the `at = [0, 0]` top-layer guard failure in `run-01`.
     3. Bottom edge `y = 77` in `(666, 57, 765, 77)` extends `2px` below `"Applications"` descenders (`y = 60..74` inclusive) and hits `3` cursor-tip pixels (`y = 75..76`) on `002..006`; `(660, 52, 768, 75)` (`local (13, 14, 121, 37)`) captures all `490` bright glyph pixels with `0` diff pixels on `002..006` and coincides exactly with the safe click interior.
2. **`SiteMainOnboardingKeyboard2039v2.patch` (`sha256:55c7b7f57d8df1639f67af0f49d74e7c09737b7fb8cb4c820621f6520060677d`, `gemini-site`)**:
   - Verified `decodeNonComposingKey` (`isComposing == True || keyCode == 229 || key == "Process"` rejected) shared across `decodeEscapeKey` and `decodeWorkbenchTabKey`, `RequestDomFocus` sequence/target tracking (with `KBD-06` properly scoped to browser verification per `terra-browser`), and accurate `16 / 242` whole EARS (`40 / 417` scenarios, `ELM-TEA-002` accepted, `ELM-TEA-001` incomplete, 28s diagnostic VM scope) copy.
3. **Integration Note on Prior `gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch` (`67a3b21f...`) per `sol-docs` (`01M6CERGK5E9J8PXGFVZJ4ZM1H`) & `gemini-site` (`01M6CEY9R1AMBR9RCHZR7VX07C`)**:
   - When Root integrates `67a3b21f...` alongside the `ELM-TEA-005` post-first HTTP interleaving fix, `appOnlyEmptyStateHierarchy()` in `implementation/warlock/qa/ui-http.cjs` should select the `/commit` POST carrying `projection.frame.status.includes('Applications connected.')` rather than assuming fixed `mainEnv.posts().length === 2` / `posts()[1]`. And as `gemini-site` noted, if any existing closed-mode CPU check expects unsuffixed override notices in `Surface.elm`, `SurfaceRenderer.elm` + `SurfaceTheme.elm` in `4194a3e2...` apply independently without the `Surface.elm` hunk.
