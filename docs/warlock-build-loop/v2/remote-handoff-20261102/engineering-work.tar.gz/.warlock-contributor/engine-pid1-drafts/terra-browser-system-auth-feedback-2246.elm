port module SystemAuthFeedbackReplay2246 exposing (main)

{-| UNRUN prospective ELM-TEA-001 UX regression. Root must compile this in
the existing Elm QA source profile against the reviewed atomic bundle, bind the
complete source/artifact tuple, and retain actual outcomes. The snapshot and
pointer are synthetic fixtures, not native permission or desktop observation.

Source preimages: SystemMenuReplay.elm 88701417539ba76f89796461aea8fa79b5b4835b7f14cd7db0d12dc79102baec,
Surface.elm 91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca,
Desktop.elm 91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4,
SystemMenu.elm cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054.
Candidate atomic diff 23e26a42a161460d44c0aab3a5999b805387a7b06b5630d587d320d9d8296e10;
profile, shared Surface/Snap merge and current closure must be selected by Root.

Expected auth wording is a proposed independent literal, not current behavior:
NetworkAuth permits requesting a change but may require authorization. It is
not evidence that authorization was granted or a network change occurred.
The existing typed bundle is predicted RED on the explicit auth label only.
-}

import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Surface
import SystemMenu
import UInt64

port outgoing : E.Value -> Cmd msg

counter value = D.decodeValue UInt64.decoder (E.string value) |> Result.withDefault UInt64.zero
binding = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",binding)]
networkSnapshot permission = E.object
    [("service",E.string "9"),("revision",E.string "1"),("volume",E.null)
    ,("network",E.object [("enabled",E.bool False),("state",E.string "disconnected"),("permission",E.string permission)])
    ,("power",E.null),("session",E.null)]
loaded request snapshot = E.object
    [("protocolVersion",E.int 3),("kind",E.string "system-menu-snapshot"),("binding",binding)
    ,("requestId",E.string (UInt64.string request)),("snapshot",snapshot)]
outcome request snapshot = E.object
    [("protocolVersion",E.int 3),("kind",E.string "system-menu-outcome"),("binding",binding)
    ,("requestId",E.string (UInt64.string request)),("status",E.string "Unknown"),("snapshot",snapshot)]
native raw model = NativePointerFixture.incoming raw model |> Tuple.first
dispatch make model = Desktop.capture model |> Maybe.map (\stamp -> Desktop.update (make stamp) model) |> Maybe.withDefault (model,[])
setup permission =
    let ready = native attached Desktop.initial
        (opened,_) = dispatch Desktop.OpenSystemMenu ready
        request = opened.systemMenuExpected |> Maybe.withDefault UInt64.zero
    in Desktop.update (Desktop.Incoming (loaded request (networkSnapshot permission))) opened |> Tuple.first

control identity model = Surface.controls model |> List.filter (\item -> item.id==identity) |> List.head
stateLabel model = control "system:network:state" model |> Maybe.map .label
isEnabled identity model = control identity model |> Maybe.map .enabled |> Maybe.withDefault False
effectCount effects = effects |> List.filter (\effect -> case effect of
    Desktop.Send wire -> D.decodeValue (D.field "kind" D.string) wire==Ok "system-menu-effect"
    _ -> False) |> List.length

results =
    let auth = setup "auth"
        denied = setup "no"
        allowed = setup "yes"
        current = auth.systemMenu.snapshot
        target = current |> Maybe.map (\snapshot -> SystemMenu.intent snapshot SystemMenu.Network 1)
        (pending,effects) = target |> Maybe.map (\intent -> dispatch (\stamp -> Desktop.SystemChange stamp intent) auth) |> Maybe.withDefault (auth,[])
        request = pending.systemMenu.pending |> Maybe.map .request |> Maybe.withDefault UInt64.zero
        (unknown,unknownEffects) = Desktop.update (Desktop.Incoming (outcome request (networkSnapshot "auth"))) pending
        (_,repeatEffects) = target |> Maybe.map (\intent -> dispatch (\stamp -> Desktop.SystemChange stamp intent) unknown) |> Maybe.withDefault (unknown,[])
        networkUnchanged model = model.systemMenu.snapshot |> Maybe.andThen .network |> Maybe.map (\network -> not network.enabled && network.state=="disconnected" && network.permission==SystemMenu.NetworkAuth) |> Maybe.withDefault False
        check name value = (name,E.bool value)
        checks =
            [ check "authPreconditionsReallyLoaded" (auth.systemMenuOpen && current/=Nothing && request/=UInt64.zero)
            , check "authAdvisoryVisibleWithoutClaimingPermission" (stateLabel auth==Just "Network disabled · disconnected; authorization may be required for changes")
            , check "authRequestAvailableButObservedStateUnchanged" (isEnabled "system:network-enable:1" auth && networkUnchanged auth)
            , check "deniedPermissionClearlyUnavailable" (stateLabel denied==Just "Network disabled · disconnected; changes unavailable" && not (isEnabled "system:network-enable:1" denied))
            , check "allowedPermissionKeepsNormalLabel" (stateLabel allowed==Just "Network disabled · disconnected" && isEnabled "system:network-enable:1" allowed)
            , check "requestDoesNotOptimisticallyChangeObservedNetwork" (effectCount effects==1 && networkUnchanged pending && pending.systemMenu.pending/=Nothing)
            , check "unknownIsVisibleAndDoesNotOptimisticallyGrant" (networkUnchanged unknown && unknown.systemMenu.notice=="Network: not confirmed. Refresh only reads state; the request will not be repeated." && unknown.systemMenu.pending/=Nothing && List.isEmpty unknownEffects)
            , check "unknownBlocksRepeatButKeepsReadRecovery" (effectCount repeatEffects==0 && not (isEnabled "system:network-enable:1" unknown) && isEnabled "system:refresh" unknown)
            ]
    in E.object [("checks",E.object checks),("authFrame",Surface.packet (counter "1") (counter "1") auth),("unknownFrame",Surface.packet (counter "2") (counter "1") unknown)]

main : Program () () Never
main = Platform.worker {init=\() -> ((),outgoing results),update=\_ model -> (model,Cmd.none),subscriptions=\_ -> Sub.none}
