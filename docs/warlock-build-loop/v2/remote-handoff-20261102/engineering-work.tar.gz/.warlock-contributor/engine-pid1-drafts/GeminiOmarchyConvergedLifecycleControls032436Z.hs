{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}

-- Direct source-bound lifecycle controls for the converged v19 persistent
-- runtime and Backend stack. Unexecuted by worker; Root executes protected
-- compiler and test runs. Retains a single-use StablePtr host root and
-- pre-allocated worker publication barriers so no worker or owner outlives
-- a failure or timeout unjoined.
module GeminiOmarchyConvergedLifecycleControls032436Z
  ( ControlHost
  , newControlHost
  , freeControlHost
  , runAllConvergedLifecycleControls
  , controlTwoObserverBackendRetireContention
  , controlExpiredStopStickyBackendUncertain
  , controlTicketStopGateRefusalBeforeClaim
  , controlSameOwnerConfigGuards
  ) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
  ( MVar
  , newEmptyMVar
  , putMVar
  , readMVar
  , tryPutMVar
  )
import Control.Exception
  ( SomeException
  , bracket
  , finally
  , mask
  , mask_
  , try
  )
import Control.Monad (unless, void)
import qualified Crypto.Hash.SHA256 as SHA256
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as BC
import Data.IORef
  ( IORef
  , atomicModifyIORef'
  , modifyIORef'
  , newIORef
  , readIORef
  )
import Data.List (isInfixOf)
import Foreign.StablePtr (StablePtr, freeStablePtr, newStablePtr)
import GHC.Clock (getMonotonicTimeNSec)
import Numeric (showHex)
import System.Directory (createDirectoryIfMissing)
import System.Environment (lookupEnv, setEnv, unsetEnv)
import System.FilePath (splitDirectories, (</>))
import System.IO (hClose)
import System.Posix.Files
  ( deviceID
  , fileID
  , fileSize
  , getSymbolicLinkStatus
  , setFileMode
  )
import System.Posix.IO (createPipe, fdToHandle)
import System.Timeout (timeout)
import Warlock.Backend
  ( PersistentBackendOwner
  , PersistentBackendRun
  , loadPersistentBackendConfig
  , newPersistentBackendOwner
  , persistentBackendOutcome
  , requestPersistentBackendStop
  , retirePersistentBackend
  , runPersistentBackend
  )
import Warlock.Bootstrap
  ( CurrentSessions
  , PersistentBootstrapResult(..)
  , newCurrentSessions
  )
import Warlock.Capture.Process.Bootstrap
  ( OwnerStatus(..)
  , ToolError(..)
  , TransferDisposition(..)
  , closeCallerTransfer
  , newTransferTicket
  , transferDisposition
  )
import Warlock.Capture.Process.Persistent
  ( PersistentOwner
  , PersistentStatus(..)
  , SessionExit(..)
  , StopDeadlineObservation(..)
  , StopReceipt(..)
  , newPersistentOwner
  , persistentHeld
  , persistentStatus
  , persistentUnderlyingStatus
  , requestSessionStop
  , startBudgetAfter
  , stopBudgetMicros
  , tryPersistentStopDeadline
  , withPersistentOwner
  )
import Warlock.Platform.Executable
  ( ExecutableLease
  , HeldExecutable
  , LeaseRole(..)
  , acquireExecutableLease
  , issueReadyExecutable
  , newExecutableLease
  , retireExecutableLease
  , retireHeld
  )
import Warlock.Platform.Resolver
  ( Identity(..)
  , Kind(..)
  , Pin(..)
  , withRoot
  )

data ControlState = ControlState
  { csUsed :: !(IORef Bool)
  , csBackendOwners :: !(IORef [PersistentBackendOwner])
  , csBackendRuns :: !(IORef [PersistentBackendRun])
  , csProcessOwners :: !(IORef [PersistentOwner])
  , csLeases :: !(IORef [ExecutableLease])
  , csHeldImages :: !(IORef [HeldExecutable])
  , csWorkers :: !(IORef [(ThreadId, MVar Bool, MVar (Either SomeException Bool))])
  }

newtype ControlHost = ControlHost (StablePtr ControlState, ControlState)

newControlHost :: IO ControlHost
newControlHost = do
  st <-
    ControlState
      <$> newIORef False
      <*> newIORef []
      <*> newIORef []
      <*> newIORef []
      <*> newIORef []
      <*> newIORef []
      <*> newIORef []
  sp <- newStablePtr st
  pure (ControlHost (sp, st))

freeControlHost :: ControlHost -> IO ()
freeControlHost (ControlHost (sp, _)) = freeStablePtr sp

claimSingleUseHost :: ControlHost -> IO ControlState
claimSingleUseHost (ControlHost (_, st)) = do
  fresh <- atomicModifyIORef' (csUsed st) (\wasUsed -> (True, not wasUsed))
  expect "ControlHost must be single-use" fresh
  pure st

expect :: String -> Bool -> IO ()
expect label ok =
  unless ok (ioError (userError ("converged-lifecycle-control failed: " ++ label)))

requireRight :: Show e => String -> Either e a -> IO a
requireRight label =
  either (\err -> ioError (userError (label ++ ": " ++ show err))) pure

withinBounded :: String -> IO a -> IO a
withinBounded label action = do
  res <- timeout 5000000 action
  maybe (ioError (userError (label ++ ": timed out (retain ControlHost)"))) pure res

withoutDisplayTransportEnv :: IO a -> IO a
withoutDisplayTransportEnv body =
  bracket capture restore (const body)
 where
  capture = do
    oldXdg <- lookupEnv "XDG_RUNTIME_DIR"
    oldWayland <- lookupEnv "WAYLAND_DISPLAY"
    unsetEnv "XDG_RUNTIME_DIR"
    unsetEnv "WAYLAND_DISPLAY"
    pure (oldXdg, oldWayland)
  restore (oldXdg, oldWayland) = do
    maybe (unsetEnv "XDG_RUNTIME_DIR") (setEnv "XDG_RUNTIME_DIR") oldXdg
    maybe (unsetEnv "WAYLAND_DISPLAY") (setEnv "WAYLAND_DISPLAY") oldWayland

hexSha256 :: B.ByteString -> String
hexSha256 bytes = concatMap byteHex (B.unpack (SHA256.hash bytes))
 where
  byteHex w =
    let s = showHex w ""
    in if length s == 1 then '0' : s else s

ancestorPaths :: FilePath -> [FilePath]
ancestorPaths target =
  let parts = filter (/= "/") (splitDirectories target)
      dropLast [] = []
      dropLast [_] = []
      dropLast (x : xs) = x : dropLast xs
      prefixes = scanl (</>) "/" (dropLast parts)
  in drop 1 prefixes

dirPinJson :: FilePath -> IO String
dirPinJson path = do
  st <- getSymbolicLinkStatus path
  let dev = toInteger (deviceID st)
      ino = toInteger (fileID st)
  pure $
    "{\"path\":\""
      ++ path
      ++ "\",\"device\":\""
      ++ show dev
      ++ "\",\"inode\":\""
      ++ show ino
      ++ "\"}"

writeValidMissingImageConfig :: FilePath -> IO FilePath
writeValidMissingImageConfig baseDir = do
  let catDir = baseDir </> "catalog"
      pinsDir = baseDir </> "pins"
      uiDir = baseDir </> "ui"
      missingUi = uiDir </> "missing-ui-binary"
      cfgPath = baseDir </> "backend-config.json"
  createDirectoryIfMissing True catDir
  createDirectoryIfMissing True pinsDir
  createDirectoryIfMissing True uiDir
  catJson <- dirPinJson catDir
  pinsJson <- dirPinJson pinsDir
  ancJsons <- mapM dirPinJson (ancestorPaths missingUi)
  nowNs <- getMonotonicTimeNSec
  let deadlineNs = toInteger nowNs + 10000000000
      zeroDigest = replicate 64 '0'
      ancList = "[" ++ commaSep ancJsons ++ "]"
      payload =
        "{"
          ++ "\"schema\":1,"
          ++ "\"binding\":{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"},"
          ++ "\"deadlineMonotonicNs\":\"" ++ show deadlineNs ++ "\","
          ++ "\"ui\":{"
          ++ "\"path\":\"" ++ missingUi ++ "\","
          ++ "\"device\":\"1\",\"inode\":\"1\",\"size\":\"1\","
          ++ "\"sha256\":\"" ++ zeroDigest ++ "\","
          ++ "\"arguments\":[],"
          ++ "\"ancestors\":" ++ ancList
          ++ "},"
          ++ "\"catalogRoots\":[" ++ catJson ++ "],"
          ++ "\"pinsRoot\":" ++ pinsJson ++ ","
          ++ "\"locale\":\"C\""
          ++ "}"
  B.writeFile cfgPath (BC.pack payload)
  pure cfgPath
 where
  commaSep [] = ""
  commaSep [x] = x
  commaSep (x : xs) = x ++ "," ++ commaSep xs

spawnRetainedBoolWorker
  :: ControlState
  -> MVar ()
  -> IO Bool
  -> IO (MVar (Either SomeException Bool))
spawnRetainedBoolWorker st gate action = mask_ $ do
  decision <- newEmptyMVar
  done <- newEmptyMVar
  tid <-
    forkFinally
      (do
        admitted <- readMVar decision
        if admitted
          then readMVar gate >> action
          else pure False)
      (putMVar done)
  modifyIORef' (csWorkers st) ((tid, decision, done) :)
  putMVar decision True
  pure done

drainRetainedWorkers :: ControlState -> IO ()
drainRetainedWorkers st = do
  workers <- readIORef (csWorkers st)
  mapM_
    (\(_, decision, done) -> do
      void (tryPutMVar decision False)
      void (timeout 3000000 (readMVar done)))
    workers

-- Control 1: Two concurrent observers racing retirePersistentBackend after
-- State Finished + StopLatchedBeforeLive. Proves that cleanup-cell contention
-- reports BootstrapNotReady rather than BootstrapUncertain, so the racing
-- observer never poisons BackendRetireActive to BackendRetireUnknown and the
-- post-join settled state is BackendRetireDone (True).
controlTwoObserverBackendRetireContention :: ControlHost -> FilePath -> IO ()
controlTwoObserverBackendRetireContention host workDir = mask $ \restore -> do
  st <- claimSingleUseHost host
  startGate <- newEmptyMVar
  let body = withoutDisplayTransportEnv $ do
        cfgPath <- writeValidMissingImageConfig (workDir </> "two-observer")
        sessions <- newCurrentSessions
        stopBudget <- requireRight "stopBudget" (stopBudgetMicros 4000000)
        owner <- newPersistentBackendOwner sessions stopBudget
        modifyIORef' (csBackendOwners st) (owner :)
        loaded <- loadPersistentBackendConfig owner cfgPath
        expect "valid config loads cleanly" (loaded == Right ())
        runOut <- runPersistentBackend owner
        modifyIORef' (csBackendRuns st) (runOut :)
        expect
          "missing image finishes bootstrap cleanly with PersistentBootstrapRefused"
          (persistentBackendOutcome runOut == Right PersistentBootstrapRefused)
        stopReceipt <- requestPersistentBackendStop owner
        expect "stop latches before live" (stopReceipt == StopLatchedBeforeLive)
        doneA <- spawnRetainedBoolWorker st startGate (restore (retirePersistentBackend owner))
        doneB <- spawnRetainedBoolWorker st startGate (restore (retirePersistentBackend owner))
        putMVar startGate ()
        outA <- withinBounded "observer A" (readMVar doneA) >>= requireRight "observer A ex"
        outB <- withinBounded "observer B" (readMVar doneB) >>= requireRight "observer B ex"
        expect "at least one observer observes settled retirement" (outA || outB)
        settledAfter <- retirePersistentBackend owner
        expect
          "post-race retirePersistentBackend remains BackendRetireDone (never poisoned)"
          settledAfter
  restore body `finally` (void (tryPutMVar startGate ()) >> drainRetainedWorkers st)

-- Control 2: Expired StopD before retirePersistentBackend latches sticky
-- BackendRetireUnknown and subsequent retirePersistentBackend calls continue
-- returning False without retrying closes.
controlExpiredStopStickyBackendUncertain :: ControlHost -> FilePath -> IO ()
controlExpiredStopStickyBackendUncertain host workDir = withoutDisplayTransportEnv $ do
  st <- claimSingleUseHost host
  cfgPath <- writeValidMissingImageConfig (workDir </> "expired-stop")
  sessions <- newCurrentSessions :: IO CurrentSessions
  stopBudget <- requireRight "short stopBudget" (stopBudgetMicros 20000)
  owner <- newPersistentBackendOwner sessions stopBudget
  modifyIORef' (csBackendOwners st) (owner :)
  loaded <- loadPersistentBackendConfig owner cfgPath
  expect "valid config loads cleanly" (loaded == Right ())
  runOut <- runPersistentBackend owner
  modifyIORef' (csBackendRuns st) (runOut :)
  expect
    "missing image finishes bootstrap cleanly"
    (persistentBackendOutcome runOut == Right PersistentBootstrapRefused)
  stopReceipt <- requestPersistentBackendStop owner
  expect "short stop latches before live" (stopReceipt == StopLatchedBeforeLive)
  threadDelay 40000
  firstRetire <- retirePersistentBackend owner
  expect "expired StopD refuses backend retirement" (not firstRetire)
  secondRetire <- retirePersistentBackend owner
  expect "sticky BackendRetireUnknown stays False on repeat" (not secondRetire)

-- Control 3: Pre-spawn TransferTicket + latched StopD on PersistentOwner
-- refuses inside claimStartupInput under cbGate BEFORE ticket ownership moves
-- to CoreLive, leaving transferDisposition == CallerOwned and raw custody clean.
controlTicketStopGateRefusalBeforeClaim :: ControlHost -> FilePath -> IO ()
controlTicketStopGateRefusalBeforeClaim host workDir = do
  st <- claimSingleUseHost host
  let subDir = workDir </> "ticket-stop"
      exePath = subDir </> "stub-ui"
      stubBytes = "#!/bin/sh\nexit 0\n"
  createDirectoryIfMissing True subDir
  B.writeFile exePath stubBytes
  setFileMode exePath 0o500
  rootStat <- getSymbolicLinkStatus "/"
  exeStat <- getSymbolicLinkStatus exePath
  ancPins <-
    mapM
      (\p -> do
        ps <- getSymbolicLinkStatus p
        pure (Pin (BC.pack p) (Identity (toInteger (deviceID ps)) (toInteger (fileID ps))) Directory))
      (ancestorPaths exePath)
  let exePin =
        Pin
          (BC.pack exePath)
          (Identity (toInteger (deviceID exeStat)) (toInteger (fileID exeStat)))
          Regular
      allPins = ancPins ++ [exePin]
      digestBytes = BC.pack (hexSha256 stubBytes)
      sizeVal = toInteger (fileSize exeStat)
  lease <- newExecutableLease
  modifyIORef' (csLeases st) (lease :)
  acquired <-
    withRoot
      "/"
      (Identity (toInteger (deviceID rootStat)) (toInteger (fileID rootStat)))
      (\root ->
        acquireExecutableLease
          lease
          root
          allPins
          (BC.pack (drop 1 exePath))
          []
          sizeVal
          digestBytes
          UiImage)
  innerAcq <- requireRight "withRoot" acquired
  _ <- requireRight "acquireExecutableLease" innerAcq
  issued <- issueReadyExecutable lease
  held <- case issued of
    Just (h, _, _) -> pure h
    Nothing -> ioError (userError "issueReadyExecutable returned Nothing")
  modifyIORef' (csHeldImages st) (held :)
  (readFd, writeFd) <- createPipe
  readHandle <- fdToHandle readFd
  writeHandle <- fdToHandle writeFd
  let cleanupWrite = hClose writeHandle
  (do
    ticket <- newTransferTicket readHandle
    owner <- newPersistentOwner
    modifyIORef' (csProcessOwners st) (owner :)
    stopBudget <- requireRight "stopBudget" (stopBudgetMicros 2000000)
    receipt <- requestSessionStop owner stopBudget
    expect "stop latched on fresh owner" (receipt == StopLatchedBeforeLive)
    obsDl <- tryPersistentStopDeadline owner
    case obsDl of
      StopDeadlineLatched _ -> pure ()
      other -> ioError (userError ("expected latched StopD, got " ++ show other))
    plan <- requireRight "persistentHeld" (persistentHeld held [] ticket [("LANG", "C")])
    startBudget <- startBudgetAfter 4000000 >>= requireRight "startBudget"
    outcome <-
      withPersistentOwner
        owner
        plan
        4096
        startBudget
        stopBudget
        (\_ -> pure (Left SpawnOrIO))
        (\_ -> pure ())
    expect
      "claimStartupInput refuses under latched StopD with StartupRefused SessionClosed"
      (outcome == Left (StartupRefused SessionClosed))
    disp <- transferDisposition ticket
    expect "ticket was never claimed into CoreOwned after StopD" (disp == CallerOwned)
    closedCaller <- closeCallerTransfer ticket
    expect "caller retains close right on un-claimed ticket" (closedCaller == Right ())
    pStatus <- persistentStatus owner
    rawStatus <- persistentUnderlyingStatus owner
    expect "persistent owner retired cleanly" (pStatus == PersistentRetired && rawStatus == Available)
    retiredHeld <- retireHeld held
    expect "held executable retires cleanly after borrow release" (retiredHeld == Right ())
    retiredLease <- retireExecutableLease lease
    expect "moved executable lease closes cleanly" (retiredLease == Right ()))
    `finally` cleanupWrite

-- Control 4: Same-owner loadPersistentBackendConfig settled missing-file
-- refusal, duplicate-use refusal, and runPersistentBackend configConfirmed guard.
controlSameOwnerConfigGuards :: ControlHost -> FilePath -> IO ()
controlSameOwnerConfigGuards host workDir = do
  st <- claimSingleUseHost host
  sessions <- newCurrentSessions
  stopBudget <- requireRight "stopBudget" (stopBudgetMicros 2000000)

  ownerUnconfigured <- newPersistentBackendOwner sessions stopBudget
  modifyIORef' (csBackendOwners st) (ownerUnconfigured :)
  unconfiguredAttempt <- try (runPersistentBackend ownerUnconfigured) :: IO (Either SomeException PersistentBackendRun)
  case unconfiguredAttempt of
    Left ex -> expect "unconfigured owner rejects runPersistentBackend" ("no verified config" `isInfixOf` show ex)
    Right r -> do
      modifyIORef' (csBackendRuns st) (r :)
      ioError (userError "unconfigured owner unexpectedly ran")

  ownerMissing <- newPersistentBackendOwner sessions stopBudget
  modifyIORef' (csBackendOwners st) (ownerMissing :)
  firstLoad <- loadPersistentBackendConfig ownerMissing (workDir </> "does-not-exist.json")
  expect "missing config settles with unavailable refusal" (firstLoad == Left "persistent config unavailable")
  secondLoad <- loadPersistentBackendConfig ownerMissing (workDir </> "does-not-exist.json")
  expect "duplicate loadPersistentBackendConfig refused on same owner" (secondLoad == Left "persistent config owner already used")
  afterFailedAttempt <- try (runPersistentBackend ownerMissing) :: IO (Either SomeException PersistentBackendRun)
  case afterFailedAttempt of
    Left ex -> expect "failed config load never sets configConfirmed" ("no verified config" `isInfixOf` show ex)
    Right r -> do
      modifyIORef' (csBackendRuns st) (r :)
      ioError (userError "failed config owner unexpectedly ran")

runAllConvergedLifecycleControls :: FilePath -> IO ()
runAllConvergedLifecycleControls rootDir = do
  let runOne sub act = bracket newControlHost freeControlHost (\h -> act h (rootDir </> sub))
  runOne "c1" controlTwoObserverBackendRetireContention
  runOne "c2" controlExpiredStopStickyBackendUncertain
  runOne "c3" controlTicketStopGateRefusalBeforeClaim
  runOne "c4" controlSameOwnerConfigGuards
