# `gemini-gui` 2016 Source Review: Live-Usability Driver Oracles & Refined `UI005` `Popup` Recovery Patch

- **Reviewer / Author**: `gemini-gui` (`warlock-20261031-setup`, wave `live-continuity-2016`)
- **Canonical Baseline**: `HEAD` `59a2f38ab` (immutable Elm source `889e9458d`; `16` whole EARS / `40` scenarios; `nativeAcceptance: false`; `nativeOperations = []`; `HOSTSTOP2` preserved; zero canonical edits or VM/compiler/Node runs)
- **Reviewed Driver Files (`elm-impl`)**:
  - `.warlock-contributor/engine-pid1-drafts/live-usability-controller.py` (`sha256:382aa2e9bd9f6ce37dab49d488a3a440f0afcc4841447857ce4137e17fe3d661`)
  - `.warlock-contributor/engine-pid1-drafts/live-usability-host-driver.py` (`sha256:0610b012e843c9d6913e0be0743bb85d9e747fdd12a89075da40d7f96db81159`)
- **Delivered `2016` Ignored Drafts (`git apply --check` clean)**:
  - `gemini-gui-popup-pending-query-mvp-2016.patch` (`sha256:1c7393cd6b9f6574f01b69426bb65b70b84846a8a7f3aa584da450d7ad6de86f`)
  - `gemini-gui-popup-pending-query-qa-2016.patch` (`sha256:d826814e4a0238299df25a4d453f1683afd0099bfea5451a772c585d66fb33a2`)
  - `gemini-gui-live-usability-driver-fixes-2016.patch` (`sha256:1637aca58fb2a01829578938340093ce022bacd664bc029a68c8ce7bf27d690f`)

---

## Part 1 — Concrete Defects & Usability-Oracle Gaps in `live-usability-controller.py` + `live-usability-host-driver.py`

All five findings below are fixed directly in `gemini-gui-live-usability-driver-fixes-2016.patch` (`1637aca5`).

### 1. CRITICAL: Guaranteed Premature `RuntimeError('Observation bound')` + `SIGKILL` Before `28s` (`live-usability-controller.py:125–128`)
- **Defect**: `run()` configures `durationSeconds = 28` and loops with `time.sleep(.15)`. `28.0 / 0.15 = 186.7` samples (~`170` samples with `sample()` overhead). Line `128` (`if len(observations)>160: raise RuntimeError('Observation bound')`) deterministically fires around `t ≈ 26.5–27.5s` on a healthy run, aborting into `finally:`, `SIGKILL`ing the unit (`forced = True`), and failing `run()` (`return 1`).
- **Fix**: Raise `len(observations)` cap from `160` to `256` (`27.55 / 0.15 = 183.7 <= 256`).

### 2. CRITICAL: Zero-Grace `SIGKILL` at `28.000s` Truncates `backend.stdout` Receipt & Races `deadlineMonotonicNs` GTK4 Unmap (`live-usability-controller.py:125–135, 164`)
- **Defect**:
  1. `tools/omarchy_ui_mvp.py:618,626,647` writes the **same** `deadlineMonotonicNs` (`+28s`) into `ui.json` and `backend.json` (`--application-attachment` defaults to `True` at line `979`, which is good). `warlock-ui-owner` and `warlock-ui-backend` (`Warlock/Backend.hs:203-235`, `app/Main.hs:16-18`) only **begin** orderly retirement *at* `deadlineMonotonicNs`, taking ~`0.30s` (`elapsed: 28.303s` in `run-08`, `observation.json:37`) to retire `owner`/`catalog`/`pins` and write single-line `backendResultJson` to `backend.stdout`.
  2. Sampling `assert len(candidates)==1` right up to `deadline` races `warlock-ui-owner` unmapping its GTK4 window at `deadlineMonotonicNs`, raising `Pinned live attempt guard failed: AssertionError`.
  3. Worse, when `time.monotonic() >= deadline` exits the `while` loop at `28.000s`, lines `133–135` **immediately execute `systemctl --user kill --signal=KILL`** with zero post-deadline retirement wait, killing `warlock-ui-backend` before `B.putStr (backendResultJson result)`, leaving `backend.stdout` empty (`0` bytes), setting `forcedAtOriginalDeadlineOrRefusal: True` on every run, and losing `callbacks`, `operations`, `cleanup`, `auth`, and `credentialRows`.
- **Fix**:
  - Stop the active window-mapped `sample()` loop at `deadline - 0.45` (host `dispatch_checked` enforces `reserve_s = 8.0`, so zero physical input occurs in the last `8.0s`; `deadline - 0.45` preserves live guard sampling for `+7.55s` past the final allowed key while avoiding the `28.000s` GTK4 unmap race).
  - Wait boundedly via `p.wait(timeout=max(0.5, deadline + 2.0 - time.monotonic()))` so `warlock-ui-backend` completes natural `deadlineMonotonicNs` retirement (`forced = False`, `exit = 1`) and flushes `backend.stdout`; issue `SIGKILL` (`forced = True`) only on `subprocess.TimeoutExpired`.
  - Parse `run-01/backend.stdout` in `finally:`, store `backendDiagnostic` inside `trial-result.json`, and require `not forced` and `backend_diag.get('cleanup') is True` in `run()`'s exit status.

### 3. CRITICAL: Host Driver Exit Status Masks Guest Mid-Run Failures (`live-usability-host-driver.py:185–186`)
- **Defect**: Because `launch` runs detached under `nohup ... &`, line `186` only checks `report['completedPhysicalSequence']` and `cleanup.*` fields (`footPreserved`, `exactEnabledRestored`, `originalOwnedBirthsRemain`, `remaining`). When `live-usability-controller.py` fails at `t ≈ 26.5s` (`Observation bound` or `Pinned live attempt guard failed`), its `finally:` block still cleans up the scope and restores `idle`/`foot`, causing `live-usability-host-driver.py` to return **`0` (PASS)** despite `guestTrialResult['failure'] != None` and `forcedAtOriginalDeadlineOrRefusal == True`!
- **Fix**: Require `report.get('failure') is None`, `guest.get('failure') is None`, `guest.get('forcedAtOriginalDeadlineOrRefusal') is False`, and `backendDiagnostic` (`cleanup is True`, `operations == 1`, `callbacks >= 8`).

### 4. USABILITY ORACLE GAP: Unchecked `changed` Pixel Diff, Missing Search-Field Focus/Echo Proof, & Missing `UI005` Recovery Step (`live-usability-host-driver.py:73, 120–123, 156–166`)
- **Defects**:
  1. `visible(..., 'search-label-ready')` discards the pre-typing settled screenshot path, so `settled -> positive-foot` (`"" -> "foot"`) is never compared.
  2. Lines `162–165` compute `changed = ImageChops.difference(positive, negative).getbbox()` on `resultsRegion` (`y=240..600`) **without asserting `changed is not None`** — if `Search` click missed focus or keys were dropped (`changed is None`), `completedPhysicalSequence = True` still passes!
  3. Neither `inputRegion` (`(x+18, y+194, min(x+580, x+w), min(y+235, y+h))`) nor `statusRegion` (`(x+10, y+55, min(x+595, x+w), min(y+190, y+h))`, where `[role="status"]` renders `"No matching applications. Change your search or Refresh."` and the `"Windows"` / `"Refresh"` recovery controls) is checked.
  4. The sequence stops at `negative-footz`, never exercising live post-no-match query reachability (`ELM-UI-005`: *"no-match message and query remain reachable without launch"*).
- **Fix**:
  - Return `path` from `visible()` (`settled`), extend `fence()` key allowlist to `{'f','o','t','z','backspace'}`, and append one checked `send_key('backspace')` -> `recovered-foot` (`~1.2s` extra; total physical sequence finishes around `t ≈ 12s`, well inside `28s - 8s = 20s`).
  - Assert `not None` pixel diffs in **both** `input_region` and `results_region` across all three transitions:
    1. `settled ("") -> positive-foot ("foot")`
    2. `positive-foot ("foot") -> negative-footz ("footz")` (plus record `status_region` diff)
    3. `negative-footz ("footz") -> recovered-foot ("foot")` **without re-clicking `Search`** — directly proving `<input data-surface-field="control:search">` retained live keyboard focus across the no-match `Present` re-render and recovered query/results without launch (`operations == 1` `CatalogRead` only).
  - Retain explicit honesty boundary: `backendResultJson` counts commits (`callbacks >= 8`), not query strings; `acceptedFinalQueryCorrelation` still requires controller/trace correlation + Root visual review of the complete screenshots.

### 5. Geometry Precondition Before First Click (`live-usability-host-driver.py:151`)
- **Defect**: `click((18,194,580,235), 'Search')` and `results_region` (`y+240..y+600`) assume tiled client size `>= (580, 241)` before checking `expected['size']`.
- **Fix**: Assert `expected['size'][0] >= 590 and expected['size'][1] >= 420` immediately after pinning `expected`.

---

## Part 2 — Refined `UI005` `Popup` / `SurfaceSnapshot` Patch (`mvp-2016` + `qa-2016`) & Merge Recipe with `terra-browser` (`d38d4d64`)

### 1. Recovery Escape-Hatch Refinement (`terra-browser` `01M6CB5Y...` / `01M6CBDD...` + `gemini-site` `01M6CCCA...`)
- In `HttpPopup`, repeated HTTP `204` empty polls (`UiHttp.elm:61-70`) reschedule `Poll` every `100ms` without clearing `Popup.pendingQuery` if no matching `presentation` arrives, while `Surface.elm:137,344-345` explicitly instructs `"No matching applications. Change your search or Refresh."` and renders `control:close` (`"Windows"`) + `control:refresh` (`"Refresh"`).
- `gemini-gui-popup-pending-query-mvp-2016.patch` (`1c7393cd`) narrows `SurfaceSnapshot.pendingQueryBlocked` to stale-target / side-effecting / paging controls only (`entry:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `jump:open:*`, `control:page-previous`, `control:page-next`, `files:open-path`, `files:collection:*`, `files:home`), keeping **`control:close`, `control:refresh`, `control:acknowledge`, and `files:refresh` enabled** when `isComposing == False` (and disabling all non-field popup buttons via `SurfaceSnapshot.composing` only during local IME preedit `isComposing == True`, which settles locally on `compositionend`).
- `gemini-gui-popup-pending-query-qa-2016.patch` (`d826814e`) verifies in `qa/LocalFieldReplay.elm` and `qa/ui-http.cjs` (`pendingQueryControls()`):
  1. Active IME preedit (`data-input-composing="true"`): preserves `<input>` node + `document.activeElement` + draft + literal canonical `status`, sends `0` POSTs, and disables all non-field popup buttons.
  2. `pendingQuery` across **3 consecutive empty HTTP `204` polls** (`respond(204)` + `tick(100)` x3): preserves `<input>` focus + draft + literal `status` with zero duplicate query POST, keeps `staleBlockedIds` disabled, AND keeps `control:close` / `control:refresh` / `control:acknowledge` enabled and actionable (`control:refresh` click dispatches `surface-action` cleanly).
  3. Transport timeout during `pendingQuery` (`fail('timeout')`): cancels active `GET /events`, renders terminal `[role="alert"]` (`"...unconfirmed... Restart this view to reconnect."`), and performs zero replay across `tick(10000)`.
  4. Lease change (`lease: '2'`, `mode: 'files'`): retires prior draft/composition, disables `files:open-path` / `files:home` / `files:collection:*` during pending path edit, and keeps `files:refresh` + `control:close` enabled.

### 2. Clean 1-Hunk Merge Recipe for `Popup.view` with `terra-browser-pending-query-feedback.patch` (`d38d4d64`)
`gemini-gui-popup-pending-query-mvp-2016.patch` (`Popup.elm` + `SurfaceSnapshot.elm`) and `terra-browser-pending-query-feedback.patch` (`SurfaceRenderer.elm` + `Popup.elm`) overlap only at `Popup.view` (`Popup.elm:54`). If Root integrates both together, use `SurfaceRenderer.viewWithPreviewPending` with `(overlay snapshot)`:

```elm
view : Model -> Html.Html Msg
view model =
    let overlay current =
            let withQuery = model.pendingQuery |> Maybe.map (\query -> SurfaceRenderer.pendingQuery query current) |> Maybe.withDefault current
            in if isComposing model then SurfaceSnapshot.composing withQuery else withQuery
    in div [attribute "data-input-composing" (if isComposing model then "true" else "false")] [Presentation.current model.presentation |> Maybe.map (\snapshot -> SurfaceRenderer.viewWithPreviewPending (\identity -> Preview.visual snapshot identity model.previews) (model.pendingQuery /= Nothing) True LocalAction (overlay snapshot)) |> Maybe.withDefault (text ""),Presentation.current model.presentation |> Maybe.map (\_ -> Announcement.view model.announcements) |> Maybe.withDefault (text "")]
```
