# Website `SiteMain.elm` (`2110`) Patch, Provenance Custody Handoff, Production-Entry Integration & Peer GUI `2039` Source-Inventory Precision Audit

- **Author Identity**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Coordinator / Integrator**: `lead` (`did:key:z6MkekUXa7zKxD9qzEAbGEa545d4EsfYtxVVL44RR9z7mACW`)
- **Turn / Cutoff**: `20261101T211028Z` / `2026-11-01T21:38:28.323238+00:00`
- **Published `HEAD`**: `45ba9ad19bade1187c07690aa8c8245990e0fb6c` (immutable accepted `ELM-TEA-002` source `889e9458d1707c456f5bb6e9af560383b066229e`)
- **Canonical Ledger Alignment**: `16 / 242` whole EARS requirements accepted, `40 / 417` scenarios accepted (`ELM-TEA-001` incomplete, independent whole `ELM-TEA-005` pending, `UI-005` live trial ended at `20:49 UTC` under the 45-minute stop rule; partial snapshots and bounded preparations do not close originals).
- **Worker Execution Attestation**: Zero compiler (`elm`, `ghc`, `cabal`), `node`, Quint, Playwright/browser, VM, native, or `warlock-ctx update` executions performed by `gemini-site`. Zero canonical repository files mutated. `tools/check_auth_cpu.py` and `tools/check_tea_cpu.py` never read or touched.

---

## 1. `2110` Ignored Draft Deliverables & Verified SHA-256s

| Artifact | Path | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| Concrete Root-Applicable Elm Patch | `.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteBeautyA11y2110.patch` | 49,698 | `c695cc1c931f9b89c627e645743551c25b974dca73677fc4fad1514ecd46bb36` |
| Pure-Elm Model/Decoder/Invariant Replay (`Platform.worker`, 21 checks) | `.warlock-contributor/engine-pid1-drafts/SiteMainKeyboardFocusReplay2110.elm` | 17,605 | `819a4f8933c154a09e09231d35296763fc2927bf2b7698fb9f420573beb705a6` |
| Rendered `SiteMain.view` + Keyboard/Focus/IME Positive Controls & Mutation Self-Test | `.warlock-contributor/engine-pid1-drafts/site-view-keyboard-positive-controls-2110.cjs` | 21,940 | `74f27a9c9a41d442354b39c63422c83e1eb543fd58becf4d86649c4736756f3a` |
| Structured Provenance, Review Packet & Peer GUI Inventory Audit | `.warlock-contributor/engine-pid1-drafts/SiteMainProvenanceAndInventoryAudit2110.json` | 9,532 | `89f930af4c836872a6975c4eaed32f636f9ed0f65fa6a2eb9a0d182c0bcf067f` |

### Target File Preimage & Postimage Hashes

- **Canonical Preimage (`site/src/SiteMain.elm`, untouched on disk)**:
  - SHA-256: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (`68,121` bytes, `1,663` lines, git blob `f10e6cdade8b945605d1ba5a3d6ff1404cd4e233`)
- **Patched Postimage (`site/src/SiteMain.elm` + `SiteMainWebsiteBeautyA11y2110.patch`)**:
  - SHA-256: `a15ca394565c7529b96d348c37cd3d1d09537d1620baa7c4ecac38de7e17dc45` (git blob `65b9d6b7b69e689d0bed9e85b4baa351b1d8da4e`)
  - Verified cleanly via `git apply --check -v` (`0` line offset) and isolated temp-directory forward/reverse `patch -p1` round-trip.

### What `SiteMainWebsiteBeautyA11y2110.patch` Adds Over `f05a3768...`

1. **Pure TEA Effect Representation & Programmatic Focus (`Dom.focus`)**:
   - Exposes `Effect(..)` (`NoEffect | FocusDomElement String`), `workbenchTabElementId`, `mobileNavToggleId`, `decodeOptionalField`, `decodeNonComposingKey`, and pure `transition : Msg -> Model -> ( Model, List Effect )`.
   - `update` maps `List Effect` to `Cmd Msg` via `Task.attempt (\_ -> FocusCompleted) (Dom.focus domId)` while keeping `transition` 100% pure for deterministic replay.
2. **Strict IME-Safe Event Decoding (`terra-browser` `01M6CEYVVPNP09ASRTS6MQJMEA`)**:
   - `decodeOptionalField` accepts absent fields or explicit JSON `null` (`Decode.oneOf [ Decode.null defaultValue, decoder ]`) while **strictly failing** malformed non-boolean `isComposing` or non-integer `keyCode` payloads (never masking type mismatches via `Decode.maybe`).
   - `decodeNonComposingKey` rejects `isComposing == True`, `keyCode == 229`, and `key == "Process"` on both `Escape` mobile-drawer dismissal and workbench `ArrowRight`/`ArrowLeft`/`Home`/`End` roving-tab navigation; `Tab` and `Shift+Tab` always fail `decodeWorkbenchKey` so browser tab traversal exits the tablist untrapped.
3. **ARIA APG Roving `tabindex` + Mobile Drawer Focus Restoration**:
   - Exactly 1 of 8 `#wl-tab-<id>` buttons has `tabindex="0"` and `aria-selected="true"`; the remaining 7 have `tabindex="-1"` and `aria-selected="false"`.
   - Keyboard navigation (`SelectSurfaceByKeyboard`) updates `selectedSurface` AND emits `FocusDomElement ("wl-tab-" ++ surfaceId target)` (`KBD-02`/`KBD-03`).
   - Pressing `Escape` while `mobileNavOpen == True` closes `#wl-mobile-nav-drawer` AND emits `FocusDomElement "wl-mobile-nav-toggle"` (`KBD-05`); pressing `Escape` when closed is a pure no-op (`[]` effects).
4. **Runnable-MVP Onboarding Hierarchy & Honest `16 / 242` (`40 / 417`) Ledger Copy**:
   - Adds a 3-step runnable-MVP onboarding strip (`#wl-onboarding-steps`: Inspect Component Bounds -> Replay Pure TEA -> Verify Protected Gates) and updates hero/metric/ledger/component-matrix copy to `16 / 242` whole EARS (`40 / 417` scenarios, `ELM-TEA-002` accepted at `889e9458d`, `ELM-TEA-001` incomplete, `ELM-TEA-005` pending independent whole review, 28s live VM app-only catalog with 62 visible rows and window/credential boundaries explicit).

---

## 2. Verified `SiteMain.elm` Foreign-Dirty Provenance & Explicit Custody Handoff to Root

`site/src/SiteMain.elm` is currently modified in the working tree (` M site/src/SiteMain.elm`) and listed in `foreignDirty` of `.warlock-contributor/*.json` (`ui005-live-query-refresh.json`, `tea005-validated-interop.json`). Verified directly from the session audit log (`transcript_full.jsonl` steps `792..839, 997..998`):

- **Authored By**: THIS exact persistent identity `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`) on run `warlock-20261031-setup`.
- **Committed `HEAD` Preimage (`87029e7e8:site/src/SiteMain.elm`)**: `9c432ddf2b7e4d35fae4197c52c4b97cb41fbfa16b45082d2143ea4d6b2d3ba1`
- **Working-Tree Dirty Postimage (`site/src/SiteMain.elm`)**: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (`68,121` bytes, `mtime` `2026-11-01T10:35:18.149439597Z`)
- **Live AgentBus Custody Receipts**:
  - Claim grant (`file:/home/charl/code/Warlock/site/src/SiteMain.elm`): `01M6BAJRGEDQQC7E9D8FQM7ZCX` (`2026-11-01T10:30:45Z`)
  - Live claim ACK to `lead`: `01M6BAJRMERZ70P8G29BXM6K3F`
  - Claim release: `01M6BAWW5C9RHJPAR32TQA5RXG` (`2026-11-01T10:36:17Z`)
  - Frozen-bytes handoff to `lead`: `01M6BAWW9RTQJ6WEJN4M2PKCRZ` & closeout confirmation `01M6BC0EEY0PRPJK17RS1VXMEX`
- **Explicit Ownership Handoff Rule**:
  - `gemini-site` explicitly hands full integration custody of `site/src/SiteMain.elm` (`f05a3768...`) and `SiteMainWebsiteBeautyA11y2110.patch` (`c695cc1c...` -> `a15ca394...`) to Root (`lead`).
  - Because `plugins/warlock-contributor/scripts/warlock.py` (`normalize_slice`, `L1056-1059`) restricts participant slices to `implementation/warlock/`, `site/src/SiteMain.elm` (`f05a3768...`) sits in `foreignDirty` of active product slices. Root should keep `f05a3768...` untouched while an active product record pins `foreignDirty["site/src/SiteMain.elm"] == "f05a3768..."`, and apply `SiteMainWebsiteBeautyA11y2110.patch` in its dedicated website integration/publication batch.

---

## 3. Exact Root Production-Entry Build, Wrapper-Splice & Verification Sequence

### Critical `site/src/` Input-Inventory Rule (`tools/qa_cpu.py:50-62`)

`qa_cpu.haskell_inputs(ROOT, False, site=True)` hashes **every** regular file under `(root / "site/src").rglob("*")` alongside `site/elm.json` (`ffe9bc4f...`), `tools/check_haskell_cpu.py` (`db36d076...`), `tools/haskell-toolchain.json` (`7a2c7706...`), `tools/haskell_build.py` (`9b97bbcf...`), `tools/qa_cpu.py` (`35d7a99a...`), `window-integration-qa/qa_launch.py` (`6ef35104...`), and `implementation/warlock-preview-provider-v143/qa/toolchain.{json,py}`. Keep **only** `site/src/SiteMain.elm` inside `site/src/` during `--site` builds; compile `SiteMainKeyboardFocusReplay2110.elm` in an isolated temp staging directory.

### Step-by-Step Root Commands

1. **Apply Patch & Verify Postimage SHA-256**:
   ```bash
   git -C /home/charl/code/Warlock apply --check -v .warlock-contributor/engine-pid1-drafts/SiteMainWebsiteBeautyA11y2110.patch
   git -C /home/charl/code/Warlock apply .warlock-contributor/engine-pid1-drafts/SiteMainWebsiteBeautyA11y2110.patch
   sha256sum /home/charl/code/Warlock/site/src/SiteMain.elm
   # Expected: a15ca394565c7529b96d348c37cd3d1d09537d1620baa7c4ecac38de7e17dc45
   ```

2. **Compile Production Elm Bundle via Protected `qa_cpu.py` (`check_haskell_cpu.py --site`)**:
   - Use `qaCpuSiteReviewPacketTemplate` from `.warlock-contributor/engine-pid1-drafts/SiteMainProvenanceAndInventoryAudit2110.json` (`L68-L85`) as `--review <packet.json>` and run:
   ```bash
   python3 -B /home/charl/code/Warlock/tools/qa_cpu.py \
     --review "$SITE_REVIEW_PACKET" \
     --output "$SITE_QA_OUT" \
     --runner /home/charl/code/Warlock/tools/check_haskell_cpu.py \
     -- --site
   ```
   - Produces `$SITE_QA_OUT/site-build/site.html` via `elm make src/SiteMain.elm --optimize --output=<output>/site-build/site.html` (`tools/haskell_build.py:316-365`).

3. **Splice Compiled `<script>` Block Into `site/index.html` Wrapper (`2e5730d2...`)**:
   - Raw `site.html` contains a bare `<html>/<title>Main</title>/<body>` shell without Warlock's HTML5 metadata, `data-warlock-design="v1" data-theme="night"`, `class="wl-landing-page"`, or `<pre id="elm"></pre>`. Splice **only** the compiled `<script>\ntry {[\s\S]*?</script>` block into `site/index.html`:
   ```bash
   python3 -B - "$SITE_QA_OUT/site-build/site.html" "/home/charl/code/Warlock/site/index.html" <<'PY'
   import pathlib, re, sys
   built = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
   index_path = pathlib.Path(sys.argv[2])
   index_html = index_path.read_text(encoding="utf-8")
   pat = re.compile(r"<script>\s*try\s*\{[\s\S]*?</script>")
   m_built = pat.search(built)
   assert m_built, "Compiled <script> block missing in site-build/site.html"
   updated, count = pat.subn(lambda _: m_built.group(0), index_html, count=1)
   assert count == 1, f"Expected exactly 1 <script> replacement in site/index.html, got {count}"
   index_path.write_text(updated, encoding="utf-8")
   PY
   ```

4. **Run Static Contract Gates, View/Keyboard Positive Controls & Isolated Pure-Elm Replay**:
   ```bash
   python3 -B /home/charl/code/Warlock/site/tools/check-site.py --root /home/charl/code/Warlock/site
   python3 -B /home/charl/code/Warlock/site/tools/check-contracts.py --root /home/charl/code/Warlock/site
   node /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-view-keyboard-positive-controls-2110.cjs \
     /home/charl/code/Warlock/site/index.html "$SITE_QA_OUT/site-view-keyboard-positive-controls-2110.json"
   ```
   - Also compile & run `SiteMainKeyboardFocusReplay2110.elm` (`819a4f89...`) in an isolated temp directory (`cp site/elm.json $TMP/ && mkdir $TMP/src && cp site/src/SiteMain.elm .warlock-contributor/engine-pid1-drafts/SiteMainKeyboardFocusReplay2110.elm $TMP/src/`), then run Playwright browser acceptance (`site/tools/browser-acceptance.py` + `terra-browser` `KBD-01..KBD-07`).

---

## 4. Independent Source-Inventory Path Precision Audit of Peer GUI `2039` Empty-State Patches

Reviewed artifacts:
- Source patch: `.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.patch` (`sha256:4194a3e206aecf31cd2987d803167ed0d904b1a33b6369b7223c907b40347869`)
- QA patch: `.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-qa-2039.patch` (`sha256:67a3b21fdb49ee0e789b6c710ad5fa79ba6f725fffb6c4edfa96d370542149af`)
- Rationale note: `.warlock-contributor/engine-pid1-drafts/gemini-gui-app-only-hierarchy-empty-state-2039.md` (`sha256:d1ccfbc27c9eed1cfeec60f27f2096d649ab08886e534f6f90df264c183cd78e`)

### Exact `HEAD` (`45ba9ad19`) Preimage / Postimage SHA-256 & Inventory Mapping Table

| Path | Patch `index` Header | Actual `HEAD` Git Blob | Preimage SHA-256 (`45ba9ad19`) | Postimage SHA-256 | In `ui005-live-query-refresh`? | In `tea005-validated-interop`? | `warlock.py verify-plan` Class |
| --- | --- | --- | --- | --- | :---: | :---: | --- |
| `implementation/warlock/src/Surface.elm` | `38bf676ea..e2279221d` | `002486320` | `91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca` | `488fb5c434b5b973b39db880c0e38b2b522025da60ce9b574cf3b57c7689c399` | No | No | Mapped (`check_elm_cpu`, `check_haskell_cpu --ui-origin`) |
| `implementation/warlock/src/SurfaceRenderer.elm` | `af9e73f9f..410378678` | `6d91d157f` | `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98` | `7eafeda39c44ddde8255afa3c48eac280c93a9408068f7b775e901cedda9b8e6` | No | No | Mapped (`check_elm_cpu`, `check_haskell_cpu --ui-origin`) |
| `implementation/warlock/src/SurfaceTheme.elm` | `3db44ef3d..5ebcf7ca3` | `e946c4b0e` | `be9d20b763275987d0706ec6edadea3853162bb28731a3da642b50fce0529d4c` | `d20202efeb73a1b76c87ef7b5da33fb108dd9bc49ce503be0eccf7483202ce65` | No | No | **`unmappedProductPaths`** |
| `implementation/warlock/qa/StandaloneMvpReplay.elm` | `59b9da2ab..f8a77da76` | `ebd711377` | `0e1bb70d72cab45abadcb065e7c31b201c718b462df53e9768e509c0864ef036` | `bcc9db06d7ca8bf257c1eeaee53067bc664d0aa61a1372ee10b114d3a6643fc2` | No | No | `supportPaths` (product QA) |
| `implementation/warlock/qa/standalone-mvp.cjs` | `8fc146ba3..ef63be276` | `78cd5967a` | `a43d171e23fa94499756dcd390e5074d2d4f1779fd5d180336ac3447500428f3` | `9112b65dc98ffe9c9d82adba2a4b462216239310a915b4815583342c4fa4126c` | No | No | `supportPaths` (product QA) |
| `implementation/warlock/qa/ui-http.cjs` | `a66b51bf7..2fb002a98` | `b7b5cfc97` | `33891cb1822933680115f1a10d0c3b7f3071a63f12c7f3561aafd49c6a9ec009` | `38090ed50c5a09f97e8ab46a69ab853353bbcaabb57e8f86029fc1b17b79ceb5` | No | **Yes** | `supportPaths` (product QA) |

### Five Concrete Source-Inventory Findings

1. **Contributor Slice Inventory Mismatch (`0/6` in Cited `ui005-live-query-refresh`, `1/6` in Active `tea005-validated-interop`)**:
   - `gemini-gui-app-only-hierarchy-empty-state-2039.md` (`L4`) references active slice `ui005-live-query-refresh`. That record ended at `20:49 UTC` under the 45-minute stop rule (`docs/HANDOFF.md:440`) and declared only `haskell/app/Main.hs`, `haskell/src/Warlock/HttpPopup.hs`, `haskell/test/Main.hs`, and `src/Mvp.elm` (**0/6** overlap).
   - Active `tea005-validated-interop.json` declares **0/3** product Elm paths (`Surface.elm`, `SurfaceRenderer.elm`, `SurfaceTheme.elm`) and only **1/3** QA paths (`implementation/warlock/qa/ui-http.cjs`, freshly modified in `45ba9ad19`). Root must either open a dedicated contributor slice or `warlock.py extend --path ...` all 6 paths before applying, otherwise `loop.py check` refuses undeclared dirty product/QA files.
2. **`warlock.py verify-plan` `unmappedProductPaths` Gap on `SurfaceTheme.elm`**:
   - `plugins/warlock-contributor/scripts/warlock.py:1898-1921` maps `implementation/warlock/src/Surface.elm` and `implementation/warlock/src/SurfaceRenderer.elm` to `check_elm_cpu.py` + `check_haskell_cpu.py --ui-origin`, **not** `implementation/warlock/src/SurfaceTheme.elm`.
   - Touching `SurfaceTheme.elm` surfaces it in `unmappedProductPaths` (`warlock.py:1945-1953`), requiring explicit proportional runner arguments (`--standalone-mvp` and `--browser` on `tools/check_elm_cpu.py`).
3. **Synthesized Diff `index` Headers & `patch -p1` / `git apply --3way` Failure (`git apply` Required)**:
   - All 6 `index <src>..<dst>` lines in `4194a3e2` and `67a3b21f` carry synthesized non-existent git blob hashes rather than actual `HEAD` blobs, and unprefixed blank context lines cause GNU `patch -p1` to fail on `Surface.elm` Hunk #1 and `SurfaceTheme.elm` Hunk #4 and `git apply --3way` to fail on missing repository blobs.
   - Plain `git apply` (without `--3way`) applies both patches cleanly (`rc = 0`, `-1` line offset on `SurfaceTheme.elm`, `+6` line offset on `ui-http.cjs` after `45ba9ad19`). Regenerating via `git diff --binary` against real `HEAD` blobs eliminates tool sensitivity.
4. **Wide `qa_cpu.py` Hash-Input & Module Import Fanout**:
   - `tools/qa_cpu.py:50-95, 122` includes every `implementation/warlock/src/*.elm` file in the review-packet input set for `check_elm_cpu.py`, `check_haskell_cpu.py` (`--build` / `--ui-origin`), and `check_tea_cpu.py`; `Surface.elm` is imported by **39** Elm modules and `SurfaceRenderer.elm` by **31** Elm modules (`warlock-ctx`).
5. **`Surface.elm:440-445` Closed `applicationOnly` Override Suffix Precaution**:
   - Appending `" · Applications connected. Window controls unavailable."` when `surface.applicationOnly && not surface.open && state.feedbackOverride /= Nothing` alters closed feedback-override strings; verify `FeedbackContextReplay.elm` / `feedback-context.cjs` before adopting that hunk.
