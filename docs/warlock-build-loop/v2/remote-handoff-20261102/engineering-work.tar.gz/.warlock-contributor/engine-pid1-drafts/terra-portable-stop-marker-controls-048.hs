{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, source only. One case per guarded process. Actual Backend owner,
-- config and scope; injected hooks are QA-only, never a production interface.
module PortableStopMarkerControls (Case, newCase, runCase) where
import Control.Exception (AsyncException(ThreadKilled), SomeException, fromException, throwIO, try)
import Control.Monad (unless)
import Data.IORef (IORef, atomicModifyIORef', newIORef, readIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner, PersistentBackendRun, newPersistentBackendOwner, loadPersistentBackendConfig,
 runPersistentBackend, retirePersistentBackend, qaBeforeFirstScopeStep, qaAfterStopAttempt,
 qaStopCallCount, qaBackendStopDeadline)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

data Case = Case PersistentBackendOwner (IORef Int) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 stop <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions stop
 Case owner <$> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: AdmissionDeadline -> String -> IO a -> IO a
within deadline label action = do
 left <- remainingMicros deadline
 if left <= 0 then ioError (userError (label ++ ": original D expired; retain owner and guardian"))
 else timeout left action >>= maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure
runCase :: AdmissionDeadline -> Case -> FilePath -> IO ()
runCase deadline (Case owner marked used) path = do
 first <- atomicModifyIORef' used (\prior -> (True,not prior))
 check "case used once" first
 exists <- doesPathExist path
 check "absolute real config" (isAbsolute path && exists)
 loaded <- within deadline "actual config" (loadPersistentBackendConfig owner path)
 check "same owner config" (loaded == Right ())
 initial <- qaStopCallCount
 check "isolated actual stop counter" (initial == 0)
 -- Force an exception after real scope entry. The subsequent first stop is
 -- interrupted AFTER its once marker but BEFORE physical stop invocation.
 qaBeforeFirstScopeStep (ioError (userError "QA scope exception"))
 qaAfterStopAttempt $ do
  atomicModifyIORef' marked (\n -> (n+1,()))
  throwIO ThreadKilled
 result <- try (within deadline "actual actor" (runPersistentBackend owner)) :: IO (Either SomeException PersistentBackendRun)
 case result of
  Left problem -> check "stop interruption remains async" (case fromException problem of Just ThreadKilled -> True; _ -> False)
  Right _ -> ioError (userError "injected async interruption swallowed")
 hooks <- readIORef marked
 stops <- qaStopCallCount
 observation <- within deadline "actual first stop observation" (qaBackendStopDeadline owner)
 check "one marker, zero physical stop calls, no invented StopD" (hooks == 1 && stops == 0 && observation == P.StopDeadlineNotLatched)
 retired <- within deadline "uncertain retained owner" (retirePersistentBackend owner)
 check "marked but unattempted stop is never clean retirement" (not retired)
