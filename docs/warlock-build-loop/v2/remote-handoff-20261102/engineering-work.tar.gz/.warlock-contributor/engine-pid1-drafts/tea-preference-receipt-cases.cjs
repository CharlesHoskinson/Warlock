'use strict';

/*
 * Independent source-literal full-model and every-effect regression factory for
 * Desktop.elm finite receipt decoding (d6fa51ec) across reachable pending
 * Settings, MotionPreferences, and ShortcutPreferences save flows.
 *
 * DRAFT ONLY — NOT EXECUTED, NOT A CANONICAL EDIT, NOT EARS ACCEPTANCE.
 * Every GIVEN, intermediate state delta, Publish frame, retained batch wire,
 * and OutcomeAnnouncements record below is transcribed directly from the actual
 * Elm source contracts at:
 *   - Desktop.elm (sha256:91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4)
 *   - DesktopPolicy.elm (sha256:018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e)
 *   - OutputController.elm (sha256:fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae)
 *   - SurfaceController.elm (sha256:2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998)
 *   - Surface.elm (sha256:91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca)
 *   - Settings.elm, MotionPreferences.elm, Motion.elm, ShortcutPreferences.elm,
 *     PointerOwnership.elm, OutcomeAnnouncements.elm, AnnouncementMessage.elm.
 *
 * Zero reducer capture, zero oracle harvesting, zero host globals (sandbox-safe
 * for qa/tea-contract.cjs loadOracle).
 *
 * Exports:
 *   - buildPreferenceReceiptCases(c): returns 7 complete { name, steps } cases
 *     (26 non-prelude tested transitions) exercising malformed save-status
 *     complete no-ops (contrasted against pre-d6fa51ec else-branch
 *     notice/outcome/publication mutations) followed by valid Unknown (retaining
 *     pending reservation without replay), Refused (including
 *     OutcomeAnnouncements settings-refused), Stored (shortcut-only), and Saved
 *     (including Motion.propose syncMotion profile-set emission).
 *     If c.preferenceSeedsOnly === true, returns { pendingSettings,
 *     pendingMotion, pendingShortcut } seed descriptors compatible with
 *     terra-browser-tea-preference-feedback.cjs.
 *   - buildPreferenceSeeds(c): convenience wrapper returning those 3 seeds
 *     (each exposing { prelude, setupTimers, given, givenEffects, requestId,
 *     unknown, refused, saved[, stored] }).
 */

function buildPreferenceSeeds(c) {
  if (!c || typeof c !== 'object') {
    throw new Error('independent full GIVEN context required');
  }
  const {
    cloneLiteral: copy,
    literalPatches: patch,
    initial,
    topologyChanges,
    oneViewChanges,
    oneScope,
    oneScopeJson,
    binding,
    bindingJson,
    host,
    empty,
    none,
    zero,
    NIL,
  } = c;
  if ([copy, patch, initial, topologyChanges, oneViewChanges, oneScope,
       oneScopeJson, binding, bindingJson, host, empty, none, zero, NIL]
        .some(value => value === undefined)) {
    throw new Error('independent full GIVEN dependencies required');
  }

  const counter = text => ({ $: 'Counter', a: text });
  const just = value => ({ $: 'Just', a: value });
  const list = values => values.reduceRight((tail, value) => ({ $: '::', a: value, b: tail }), empty());
  const tuple2 = (a, b) => ({ $: '#2', a, b });
  const publish = packet => ({ $: '::', a: { $: 'Publish', a: { $: 0, a: packet } }, b: empty() });

  // Exact Elm E.object key insertion orders for byte-exact batch.wire strings.
  const wireScope = { id: String(oneScopeJson.id), generation: String(oneScopeJson.generation) };
  const wireBinding = {
    lifetime: String(bindingJson.lifetime),
    session: String(bindingJson.session),
    frontend: String(bindingJson.frontend),
  };

  const controlRow = (id, domId, label, ariaLabel, detail, enabled) => ({
    id,
    domId,
    label,
    ariaLabel,
    detail,
    enabled,
    focusOnly: false,
  });

  const keyPrefix = presentation => 'applications:' + host + ':' + presentation + ':';

  // Surface.barControls when phase == Reconciling, applicationOnly == False,
  // pinIds == [], ordinaryGroups == [], recoveryNeeded == False.
  const shellBarRows = presentation => {
    const p = keyPrefix(presentation);
    return [
      controlRow('bar:applications', p + 'control:opener', 'Applications', 'Open applications', '', true),
      controlRow('bar:overview', p + 'control:overview-opener', 'Task View', 'Open Task View', '', false),
      controlRow('bar:switcher', p + 'control:switcher-opener', 'Switch windows', 'Open window switcher', '', false),
      controlRow('bar:notifications', p + 'notifications:opener', 'Notifications', 'Open notifications', '', true),
      controlRow('bar:files', p + 'files:opener', 'Files', 'Open Files menu', '', true),
      controlRow('bar:system', p + 'system:opener', 'System', 'Open system menu', '', true),
      controlRow('bar:settings', p + 'settings:opener', 'Settings', 'Open settings', '', true),
    ];
  };

  const motionLabel = override => (
    override === 'System' ? 'Follow system'
      : override === 'Reduce' ? 'Reduced motion'
        : 'Full motion'
  );

  const shortcutRoutes = [
    ['applications', 'Apps menu'],
    ['system', 'System menu'],
    ['notifications', 'Notification history'],
  ];

  // Surface.controls for model.settingsOpen == True, model.settingsHelp == True
  // (Surface.elm:192-238). Every popup control in settings mode sets ariaLabel === label.
  const settingsPopupRows = spec => {
    const p = keyPrefix(spec.presentation);
    const ctl = (id, label, detail, enabled) => controlRow(
      id,
      p + (id === 'control:close' ? 'settings:close' : id),
      label,
      label,
      detail,
      enabled
    );
    const settingsReady = spec.settingsSnapshot !== null && !spec.settingsPending && spec.settingsExpectedEmpty;
    const settingsChanged = spec.settingsSnapshot !== null && (
      spec.settingsSnapshot.theme !== spec.settingsDraft.theme ||
      spec.settingsSnapshot.textScale !== spec.settingsDraft.textScale ||
      spec.settingsSnapshot.effectsOff !== spec.settingsDraft.effectsOff ||
      spec.settingsSnapshot.reducedTransparency !== spec.settingsDraft.reducedTransparency
    );
    const motionReady = spec.motionSnapshot !== null && !spec.motionPending && spec.motionExpectedEmpty;
    const motionSelected = spec.motionSnapshot !== null ? spec.motionSnapshot : 'System';
    const desiredProfile = spec.motionSnapshot === 'Full' ? 'full' : 'reduced';
    const motionHeadline = spec.motionSnapshot === null
      ? spec.motionNotice
      : spec.motionProfilePending
        ? 'Applying motion preference…'
        : (desiredProfile === 'reduced' ? 'Reduced motion: instant transitions' : 'Full motion') +
          ' · ' + motionLabel(motionSelected);

    const shortcutWritable = spec.shortcutSnapshot !== null && spec.shortcutInventory !== null && !spec.shortcutPending;
    const shortcutReady = shortcutWritable && spec.shortcutExpectedEmpty;
    const shortcutAllowed = (choice, row) => (
      choice === 'keep' ? true
        : choice === 'default' ? row.defaultAvailable
          : choice === 'alternate' ? row.alternateAvailable
            : false
    );
    const shortcutReadyToSave = spec.shortcutExpectedEmpty && shortcutWritable &&
      spec.shortcutInventory !== null &&
      shortcutRoutes.every(([route]) => shortcutAllowed(spec.shortcutDraft[route], spec.shortcutInventory[route]));
    const shortcutChanged = (
      spec.shortcutSnapshot !== null &&
      shortcutRoutes.some(([route]) => spec.shortcutSnapshot[route] !== spec.shortcutDraft[route])
    ) || (
      spec.shortcutInventory !== null &&
      shortcutRoutes.some(([route]) => spec.shortcutDraft[route] !== spec.shortcutInventory[route].active)
    );

    const rows = [
      ctl('control:close', 'Close settings', '', true),
      ctl('settings:help', 'Dismiss help', 'Expanded', true),
      ctl('settings:help:text:keyboard', 'Keyboard navigation', 'Tab and Shift+Tab move focus. Arrows move through lists; Home/End reach endpoints. Enter chooses; Escape closes.', false),
      ctl('settings:help:text:preferences', 'Keeping your preferences', 'Save applies appearance preferences. Motion has its own Save. Dismissing help keeps unsaved edits.', false),
      ctl('settings:help:text:recovery', 'When an action is not confirmed', 'Pending is waiting; Refused did not proceed; Unknown is unconfirmed. Refresh reads state without repeating an action.', false),
      ctl('settings:effects-off', 'Disable soft effects', spec.settingsDraft.effectsOff ? 'On' : 'Off', settingsReady),
      ctl('settings:reduced-transparency', 'Reduce transparency', spec.settingsDraft.reducedTransparency ? 'On' : 'Off', settingsReady),
      ctl('settings:motion', motionHeadline, spec.motionNotice, false),
      ctl('settings:motion:system', 'Follow system', spec.motionDraft === 'System' ? 'Selected' : '', motionReady),
      ctl('settings:motion:reduced', 'Reduced motion', spec.motionDraft === 'Reduce' ? 'Selected' : '', motionReady),
      ctl('settings:motion:full', 'Full motion', spec.motionDraft === 'Full' ? 'Selected' : '', motionReady),
      ctl('settings:motion:save', 'Save motion preference', 'Apply and keep across restart', motionReady && spec.motionDraft !== motionSelected),
      ctl('settings:motion:refresh', 'Refresh motion preference', 'Read stored preference; no write is repeated', spec.motionExpectedEmpty),
      ctl('settings:theme:night', 'Night theme', spec.settingsDraft.theme === 'night' ? 'Selected' : '', settingsReady),
      ctl('settings:theme:dawn', 'Dawn theme', spec.settingsDraft.theme === 'dawn' ? 'Selected' : '', settingsReady),
      ctl('settings:theme:high-contrast', 'High contrast theme', spec.settingsDraft.theme === 'high-contrast' ? 'Selected' : '', settingsReady),
      ctl('settings:scale:100', 'Text size 100%', spec.settingsDraft.textScale === 100 ? 'Selected' : '', settingsReady),
      ctl('settings:scale:125', 'Text size 125%', spec.settingsDraft.textScale === 125 ? 'Selected' : '', settingsReady),
      ctl('settings:scale:150', 'Text size 150%', spec.settingsDraft.textScale === 150 ? 'Selected' : '', settingsReady),
      ctl('settings:scale:200', 'Text size 200%', spec.settingsDraft.textScale === 200 ? 'Selected' : '', settingsReady),
      ctl('settings:save', 'Save settings', 'Apply and keep across restart', settingsReady && settingsChanged),
      ctl('settings:refresh', 'Refresh settings', 'Read stored values; discard unsaved changes', spec.settingsExpectedEmpty),
      ctl('settings:shortcuts:notice:state', spec.shortcutNotice, '', false),
    ];

    for (const [route, routeLabel] of shortcutRoutes) {
      const inv = spec.shortcutInventory ? spec.shortcutInventory[route] : null;
      const stateText = inv
        ? routeLabel + ': ' + (inv.active === 'keep' ? 'existing shortcut preserved' : inv.active === 'default' ? inv.defaultChord : inv.alternateChord)
        : routeLabel + ': live bindings unavailable';
      rows.push(
        ctl('settings:shortcuts:' + route + ':state', stateText, '', false),
        ctl('settings:shortcuts:' + route + ':keep', 'Keep existing shortcut for ' + routeLabel, spec.shortcutDraft[route] === 'keep' ? 'Selected' : '', shortcutReady),
        ctl('settings:shortcuts:' + route + ':default', 'Use ' + routeLabel + ' default', spec.shortcutDraft[route] === 'default' ? 'Selected' : '', shortcutReady && inv !== null && inv.defaultAvailable),
        ctl('settings:shortcuts:' + route + ':default:state', inv ? inv.defaultChord + (inv.defaultAvailable ? ' · Available' : ' · Unavailable: existing binding') : 'Default unavailable', '', false),
        ctl('settings:shortcuts:' + route + ':alternate', 'Use ' + routeLabel + ' alternative', spec.shortcutDraft[route] === 'alternate' ? 'Selected' : '', shortcutReady && inv !== null && inv.alternateAvailable),
        ctl('settings:shortcuts:' + route + ':alternate:state', inv ? inv.alternateChord + (inv.alternateAvailable ? ' · Available' : ' · Unavailable: existing binding') : 'Alternative unavailable', '', false)
      );
    }

    rows.push(
      ctl('settings:shortcuts:save', 'Save shortcut choices', 'Apply only the free chosen chords; preserve existing bindings', shortcutReadyToSave && shortcutChanged),
      ctl('settings:shortcuts:refresh', 'Refresh shortcut choices', 'Read stored choices and live bindings without repeating an action', spec.shortcutExpectedEmpty)
    );
    return rows;
  };

  const settingsCommit = spec => {
    const appearanceSource = spec.settingsSnapshot !== null
      ? spec.settingsSnapshot
      : { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false };
    const motionProfile = spec.motionSnapshot === 'Full' ? 'full' : 'reduced';
    const statusText = (spec.settingsExpectedEmpty ? spec.settingsNotice : 'Loading settings…') + ' · ' + spec.shortcutNotice;
    return {
      viewProtocol: 1,
      kind: 'view-commit',
      projection: {
        viewProtocol: 1,
        kind: 'view-frame',
        revision: '1',
        views: [wireScope],
        focusOwner: wireScope,
        popupOwner: wireScope,
        frame: {
          surfaceProtocol: 2,
          keyboardParent: true,
          motion: motionProfile,
          appearance: {
            theme: appearanceSource.theme,
            textScale: appearanceSource.textScale,
            effectsOff: appearanceSource.effectsOff,
            reducedTransparency: appearanceSource.reducedTransparency,
          },
          publication: spec.publication,
          lease: spec.lease,
          mode: 'settings',
          status: statusText,
          bar: shellBarRows(spec.presentation),
          popup: settingsPopupRows(spec),
        },
        announcer: { scope: wireScope, surface: 'popup' },
        announcement: spec.announcement || null,
      },
      requests: spec.requests,
      focus: spec.focus,
    };
  };

  // Event 1: oneView topology (publication 3, lease 0, presentation 2).
  const oneViewBaseChanges = copy(topologyChanges);
  oneViewBaseChanges[1].after = counter('3');
  const oneViewState = patch(initial, oneViewBaseChanges.concat(copy(oneViewChanges)));

  // Event 2: full shell "attached" (applicationOnly == false so bar:settings is enabled).
  // Emits 5 read requests (catalog 1, settings 2, motion 3, shortcuts 4, projection 1).
  const attachRequests = [
    { protocolVersion: 3, kind: 'catalog-request', binding: wireBinding, requestId: '1' },
    { protocolVersion: 3, kind: 'shell-settings-request', binding: wireBinding, requestId: '2' },
    { protocolVersion: 3, kind: 'motion-preferences-request', binding: wireBinding, requestId: '3' },
    { protocolVersion: 3, kind: 'shortcut-preferences-request', binding: wireBinding, requestId: '4' },
    { protocolVersion: 3, kind: 'projection-request', binding: wireBinding, requestId: '1' },
  ];
  const attachCommit = {
    viewProtocol: 1,
    kind: 'view-commit',
    projection: {
      viewProtocol: 1,
      kind: 'view-frame',
      revision: '1',
      views: [wireScope],
      focusOwner: wireScope,
      popupOwner: null,
      frame: {
        surfaceProtocol: 2,
        keyboardParent: true,
        motion: 'reduced',
        appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
        publication: '4',
        lease: '0',
        mode: 'closed',
        status: 'Updating window information…',
        bar: shellBarRows('3'),
        popup: [],
      },
      announcer: { scope: wireScope, surface: 'bar' },
      announcement: null,
    },
    requests: attachRequests,
    focus: [],
  };
  const batchAttach = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('4'),
    lease: zero(),
    binding,
    wire: JSON.stringify(attachCommit),
    observations: list([tuple2('projection-request', counter('1'))]),
    operations: empty(),
    catalogs: list([{ binding, request: counter('1') }]),
  };

  // Event 3: pointer-ownership idle (Desktop.elm:621 requires idle observation
  // for non-applicationOnly gestureAction; SurfaceController.elm:87-94 advances
  // publication 4->5 without advancing Desktop.presentation '3' or adding a batch).

  // Event 4: bar:settings at pub '5' -> OpenSettings (requests settings 5 & shortcuts 6,
  // lease 0->1, pub 5->6, pres 3->6).
  const openSettingsRequests = [
    { protocolVersion: 3, kind: 'shell-settings-request', binding: wireBinding, requestId: '5' },
    { protocolVersion: 3, kind: 'shortcut-preferences-request', binding: wireBinding, requestId: '6' },
  ];
  const openSettingsCommit = settingsCommit({
    publication: '6',
    lease: '1',
    presentation: '6',
    settingsSnapshot: null,
    settingsDraft: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
    settingsPending: false,
    settingsExpectedEmpty: false,
    settingsNotice: 'Loading settings…',
    motionSnapshot: null,
    motionDraft: 'System',
    motionPending: false,
    motionProfilePending: false,
    motionExpectedEmpty: false,
    motionNotice: 'Reading motion preference…',
    shortcutSnapshot: null,
    shortcutInventory: null,
    shortcutDraft: { applications: 'undecided', system: 'undecided', notifications: 'undecided' },
    shortcutPending: false,
    shortcutExpectedEmpty: false,
    shortcutNotice: 'Loading shortcut choices…',
    requests: openSettingsRequests,
    focus: [keyPrefix('6') + 'settings:close'],
  });
  const batchOpenSettings = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('6'),
    lease: counter('1'),
    binding,
    wire: JSON.stringify(openSettingsCommit),
    observations: empty(),
    operations: empty(),
    catalogs: empty(),
  };

  const fingerprint = 'a'.repeat(64);
  const baseShortcutInventoryWire = {
    fingerprint,
    applications: { defaultChord: 'SUPER + ALT + SPACE', alternateChord: 'SUPER + CTRL + ALT + SPACE', defaultAvailable: true, alternateAvailable: true, active: 'keep' },
    system: { defaultChord: 'SUPER + ESCAPE', alternateChord: 'SUPER + CTRL + ESCAPE', defaultAvailable: true, alternateAvailable: true, active: 'default' },
    notifications: { defaultChord: 'SUPER + SHIFT + ALT + comma', alternateChord: 'SUPER + CTRL + ALT + comma', defaultAvailable: true, alternateAvailable: true, active: 'keep' },
  };
  const appliedShortcutInventoryWire = {
    fingerprint,
    applications: { defaultChord: 'SUPER + ALT + SPACE', alternateChord: 'SUPER + CTRL + ALT + SPACE', defaultAvailable: true, alternateAvailable: true, active: 'alternate' },
    system: { defaultChord: 'SUPER + ESCAPE', alternateChord: 'SUPER + CTRL + ESCAPE', defaultAvailable: true, alternateAvailable: true, active: 'default' },
    notifications: { defaultChord: 'SUPER + SHIFT + ALT + comma', alternateChord: 'SUPER + CTRL + ALT + comma', defaultAvailable: true, alternateAvailable: true, active: 'keep' },
  };
  const choiceTag = raw => (
    raw === 'keep' ? { $: 'Keep' }
      : raw === 'default' ? { $: 'Default' }
        : raw === 'alternate' ? { $: 'Alternate' }
          : { $: 'Undecided' }
  );
  const inventoryModel = wire => ({
    fingerprint: wire.fingerprint,
    applications: {
      defaultChord: wire.applications.defaultChord,
      alternateChord: wire.applications.alternateChord,
      defaultAvailable: wire.applications.defaultAvailable,
      alternateAvailable: wire.applications.alternateAvailable,
      active: choiceTag(wire.applications.active),
    },
    system: {
      defaultChord: wire.system.defaultChord,
      alternateChord: wire.system.alternateChord,
      defaultAvailable: wire.system.defaultAvailable,
      alternateAvailable: wire.system.alternateAvailable,
      active: choiceTag(wire.system.active),
    },
    notifications: {
      defaultChord: wire.notifications.defaultChord,
      alternateChord: wire.notifications.alternateChord,
      defaultAvailable: wire.notifications.defaultAvailable,
      alternateAvailable: wire.notifications.alternateAvailable,
      active: choiceTag(wire.notifications.active),
    },
  });

  const nightValuesModel = { theme: { $: 'Night' }, textScale: 100, effectsOff: false, reducedTransparency: false };
  const dawnValuesModel = { theme: { $: 'Dawn' }, textScale: 100, effectsOff: false, reducedTransparency: false };
  const nightValuesWire = { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false };
  const dawnValuesWire = { theme: 'dawn', textScale: 100, effectsOff: false, reducedTransparency: false };

  const baseShortcutChoicesWire = { applications: 'keep', system: 'default', notifications: 'keep' };
  const desiredShortcutChoicesWire = { applications: 'alternate', system: 'default', notifications: 'keep' };
  const baseShortcutChoicesModel = { applications: { $: 'Keep' }, system: { $: 'Default' }, notifications: { $: 'Keep' } };
  const desiredShortcutChoicesModel = { applications: { $: 'Alternate' }, system: { $: 'Default' }, notifications: { $: 'Keep' } };
  const loadedShortcutNotice = 'Shortcut choices loaded. Conflicting bindings are preserved; choose a free chord or keep the existing shortcut.';

  const modelPath = ['controller', 'a', 'controller', 'a', 'desktop'];
  const dpath = (...tail) => modelPath.concat(tail);

  // State after Events 1..7 (loadedSettingsMotionShortcuts: pub 9, lease 1, pres 9, req 6).
  const loadedState = patch(oneViewState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('3'), after: counter('9') },
    { path: ['controller', 'a', 'controller', 'a', 'lease'], before: zero(), after: counter('1') },
    { path: ['controller', 'a', 'batches'], before: empty(), after: list([batchOpenSettings, batchAttach]) },
    { path: dpath('presentation'), before: just(counter('2')), after: just(counter('9')) },
    { path: dpath('request'), before: zero(), after: counter('6') },
    { path: dpath('expected'), before: none(), after: just(counter('1')) },
    { path: dpath('workspaceNavigation', 'binding'), before: none(), after: just(binding) },
    { path: dpath('pointer', 'observation'), before: none(), after: just({ binding, serial: counter('1'), state: { $: 'Idle' }, owner: none() }) },
    { path: dpath('launch', 'a', 'revision'), before: counter('2'), after: counter('4') },
    { path: dpath('launch', 'a', 'host'), before: none(), after: just(host) },
    { path: dpath('windows', 'shell', 'binding'), before: none(), after: just(binding) },
    { path: dpath('windows', 'shell', 'request'), before: zero(), after: counter('1') },
    { path: dpath('windows', 'shell', 'expected'), before: none(), after: just(counter('1')) },
    { path: dpath('windows', 'shell', 'phase'), before: { $: 'Detached' }, after: { $: 'Reconciling' } },
    { path: dpath('windows', 'shell', 'reconnecting'), before: true, after: false },
    { path: dpath('windows', 'shell', 'notice'), before: 'Connecting…', after: 'Updating window information…' },
    { path: dpath('settingsOpen'), before: false, after: true },
    { path: dpath('settings', 'snapshot'), before: none(), after: just({ schema: 2, revision: counter('1'), values: nightValuesModel }) },
    { path: dpath('settings', 'notice'), before: 'Loading settings…', after: 'Settings loaded.' },
    { path: dpath('motion', 'preferences', 'snapshot'), before: none(), after: just({ revision: counter('1'), override: { $: 'System' } }) },
    { path: dpath('motion', 'preferences', 'notice'), before: 'Reading motion preference…', after: 'Motion preference loaded.' },
    { path: dpath('shortcutPreferences', 'snapshot'), before: none(), after: just({ schema: 1, revision: counter('1'), choices: baseShortcutChoicesModel }) },
    { path: dpath('shortcutPreferences', 'inventory'), before: none(), after: just(inventoryModel(baseShortcutInventoryWire)) },
    { path: dpath('shortcutPreferences', 'draft'), before: { applications: { $: 'Undecided' }, system: { $: 'Undecided' }, notifications: { $: 'Undecided' } }, after: baseShortcutChoicesModel },
    { path: dpath('shortcutPreferences', 'notice'), before: 'Loading shortcut choices…', after: loadedShortcutNotice },
  ]);

  const loadedSpec = {
    lease: '1',
    settingsSnapshot: nightValuesWire,
    settingsDraft: nightValuesWire,
    settingsPending: false,
    settingsExpectedEmpty: true,
    settingsNotice: 'Settings loaded.',
    motionSnapshot: 'System',
    motionDraft: 'System',
    motionPending: false,
    motionProfilePending: false,
    motionExpectedEmpty: true,
    motionNotice: 'Motion preference loaded.',
    shortcutSnapshot: baseShortcutChoicesWire,
    shortcutInventory: baseShortcutInventoryWire,
    shortcutDraft: baseShortcutChoicesWire,
    shortcutPending: false,
    shortcutExpectedEmpty: true,
    shortcutNotice: loadedShortcutNotice,
    requests: [],
    focus: [],
  };

  const viewAction = (surface, publication, lease, id) => ({
    bridgeProtocol: 1,
    kind: 'view-action',
    payload: {
      viewProtocol: 1,
      kind: 'view-action',
      scope: wireScope,
      action: {
        surfaceProtocol: 2,
        kind: 'surface-action',
        surface,
        publication,
        lease,
        id,
        trigger: 'keyboard',
      },
    },
  });

  const nativeEvent = payload => ({ bridgeProtocol: 1, kind: 'native-event', payload });

  const basePrelude = [
    { bridgeProtocol: 1, kind: 'view-topology', payload: { viewProtocol: 1, kind: 'view-topology', revision: '1', views: [wireScope] } },
    nativeEvent({ protocolVersion: 3, kind: 'attached', binding: wireBinding }),
    nativeEvent({ protocolVersion: 3, kind: 'pointer-ownership', ownershipProtocol: 1, binding: wireBinding, requestId: '1', serial: '1', state: 'idle', owner: null }),
    viewAction('bar', '5', '0', 'bar:settings'),
    nativeEvent({ protocolVersion: 3, kind: 'shell-settings', binding: wireBinding, requestId: '5', snapshot: { schema: 2, revision: '1', values: nightValuesWire } }),
    nativeEvent({ protocolVersion: 3, kind: 'motion-preferences', binding: wireBinding, requestId: '3', snapshot: { schema: 1, revision: '1', override: null } }),
    nativeEvent({ protocolVersion: 3, kind: 'shortcut-preferences', binding: wireBinding, requestId: '6', snapshot: { schema: 1, revision: '1', choices: baseShortcutChoicesWire }, inventory: baseShortcutInventoryWire }),
  ];

  // =========================================================================
  // Branch 1: Pending Settings Save (requestId '7', Dawn theme)
  // =========================================================================
  const settingsWriteRequest = {
    protocolVersion: 3,
    kind: 'shell-settings-write',
    binding: wireBinding,
    requestId: '7',
    proposal: { schema: 2, revision: '1', values: dawnValuesWire },
  };
  const settingsPendingSpec = {
    ...loadedSpec,
    publication: '11',
    presentation: '11',
    settingsDraft: dawnValuesWire,
    settingsPending: true,
    settingsNotice: 'Saving settings…',
    requests: [settingsWriteRequest],
  };
  const settingsPendingCommit = settingsCommit(settingsPendingSpec);
  const batchSettingsWrite = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('11'),
    lease: counter('1'),
    binding,
    wire: JSON.stringify(settingsPendingCommit),
    observations: empty(),
    operations: empty(),
    catalogs: empty(),
  };
  const settingsPendingState = patch(loadedState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('9'), after: counter('11') },
    { path: ['controller', 'a', 'batches'], before: list([batchOpenSettings, batchAttach]), after: list([batchSettingsWrite, batchOpenSettings, batchAttach]) },
    { path: dpath('presentation'), before: just(counter('9')), after: just(counter('11')) },
    { path: dpath('request'), before: counter('6'), after: counter('7') },
    { path: dpath('settings', 'draft'), before: nightValuesModel, after: dawnValuesModel },
    { path: dpath('settings', 'pending'), before: none(), after: just({ request: counter('7'), values: dawnValuesModel }) },
    { path: dpath('settings', 'notice'), before: 'Settings loaded.', after: 'Saving settings…' },
  ]);
  const settingsPrelude = basePrelude.concat([
    viewAction('popup', '9', '1', 'settings:theme:dawn'),
    viewAction('popup', '10', '1', 'settings:save'),
  ]);

  const settingsUnknownNotice = 'Settings save not confirmed. Refresh to read the stored values; this write will not be repeated.';
  const settingsUnknownState = patch(settingsPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('settings', 'outcome'), before: none(), after: just({ request: counter('7'), result: { $: 'Unconfirmed' } }) },
    { path: dpath('settings', 'notice'), before: 'Saving settings…', after: settingsUnknownNotice },
  ]);
  const settingsUnknownCommit = settingsCommit({
    ...settingsPendingSpec,
    publication: '12',
    presentation: '12',
    settingsNotice: settingsUnknownNotice,
    requests: [],
  });

  const settingsRefusedNotice = 'Settings change refused. Refresh, then choose again.';
  const settingsRefusedCorrelation = '{"outcome":"settings-refused","binding":{"lifetime":"1","session":"1","frontend":"1"},"identity":"7"}';
  const settingsRefusedAnnouncement = {
    interrupt: false,
    sequence: '1',
    correlation: settingsRefusedCorrelation,
    text: settingsRefusedNotice,
  };
  const settingsRefusedState = patch(settingsUnknownState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('12'), after: counter('13') },
    { path: dpath('presentation'), before: just(counter('12')), after: just(counter('13')) },
    { path: dpath('settings', 'pending'), before: just({ request: counter('7'), values: dawnValuesModel }), after: none() },
    { path: dpath('settings', 'outcome'), before: just({ request: counter('7'), result: { $: 'Unconfirmed' } }), after: just({ request: counter('7'), result: { $: 'Refused' } }) },
    { path: dpath('settings', 'notice'), before: settingsUnknownNotice, after: settingsRefusedNotice },
    { path: ['controller', 'a', 'announcements', 'a'], before: zero(), after: counter('1') },
    { path: ['controller', 'a', 'announcements', 'b'], before: none(), after: just({
      interrupt: false,
      sequence: counter('1'),
      correlation: settingsRefusedCorrelation,
      text: settingsRefusedNotice,
    }) },
  ]);
  const settingsRefusedCommit = settingsCommit({
    ...settingsPendingSpec,
    publication: '13',
    presentation: '13',
    settingsPending: false,
    settingsNotice: settingsRefusedNotice,
    requests: [],
    announcement: settingsRefusedAnnouncement,
  });

  const settingsSavedState = patch(settingsPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('settings', 'snapshot'), before: just({ schema: 2, revision: counter('1'), values: nightValuesModel }), after: just({ schema: 2, revision: counter('2'), values: dawnValuesModel }) },
    { path: dpath('settings', 'pending'), before: just({ request: counter('7'), values: dawnValuesModel }), after: none() },
    { path: dpath('settings', 'outcome'), before: none(), after: just({ request: counter('7'), result: { $: 'Saved' } }) },
    { path: dpath('settings', 'notice'), before: 'Saving settings…', after: 'Settings saved.' },
  ]);
  const settingsSavedCommit = settingsCommit({
    ...settingsPendingSpec,
    publication: '12',
    presentation: '12',
    settingsSnapshot: dawnValuesWire,
    settingsPending: false,
    settingsNotice: 'Settings saved.',
    requests: [],
  });

  // =========================================================================
  // Branch 2: Pending MotionPreferences Save (requestId '7', Full override)
  // =========================================================================
  const motionWriteRequest = {
    protocolVersion: 3,
    kind: 'motion-preferences-write',
    binding: wireBinding,
    requestId: '7',
    proposal: { schema: 1, revision: '1', override: 'full' },
  };
  const motionPendingSpec = {
    ...loadedSpec,
    publication: '11',
    presentation: '11',
    motionDraft: 'Full',
    motionPending: true,
    motionNotice: 'Saving motion preference…',
    requests: [motionWriteRequest],
  };
  const motionPendingCommit = settingsCommit(motionPendingSpec);
  const batchMotionWrite = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('11'),
    lease: counter('1'),
    binding,
    wire: JSON.stringify(motionPendingCommit),
    observations: empty(),
    operations: empty(),
    catalogs: empty(),
  };
  const motionPendingState = patch(loadedState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('9'), after: counter('11') },
    { path: ['controller', 'a', 'batches'], before: list([batchOpenSettings, batchAttach]), after: list([batchMotionWrite, batchOpenSettings, batchAttach]) },
    { path: dpath('presentation'), before: just(counter('9')), after: just(counter('11')) },
    { path: dpath('request'), before: counter('6'), after: counter('7') },
    { path: dpath('motion', 'preferences', 'draft'), before: { $: 'System' }, after: { $: 'Full' } },
    { path: dpath('motion', 'preferences', 'pending'), before: none(), after: just({ request: counter('7'), revision: counter('1'), override: { $: 'Full' } }) },
    { path: dpath('motion', 'preferences', 'notice'), before: 'Motion preference loaded.', after: 'Saving motion preference…' },
  ]);
  const motionPrelude = basePrelude.concat([
    viewAction('popup', '9', '1', 'settings:motion:full'),
    viewAction('popup', '10', '1', 'settings:motion:save'),
  ]);

  const motionUnknownNotice = 'Motion preference save not confirmed. Refresh to read stored values; this write will not be repeated.';
  const motionUnknownState = patch(motionPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('motion', 'preferences', 'notice'), before: 'Saving motion preference…', after: motionUnknownNotice },
  ]);
  const motionUnknownCommit = settingsCommit({
    ...motionPendingSpec,
    publication: '12',
    presentation: '12',
    motionNotice: motionUnknownNotice,
    requests: [],
  });

  const motionRefusedNotice = 'Motion preference refused. Refresh, then choose again.';
  const motionRefusedState = patch(motionUnknownState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('12'), after: counter('13') },
    { path: dpath('presentation'), before: just(counter('12')), after: just(counter('13')) },
    { path: dpath('motion', 'preferences', 'pending'), before: just({ request: counter('7'), revision: counter('1'), override: { $: 'Full' } }), after: none() },
    { path: dpath('motion', 'preferences', 'notice'), before: motionUnknownNotice, after: motionRefusedNotice },
  ]);
  const motionRefusedCommit = settingsCommit({
    ...motionPendingSpec,
    publication: '13',
    presentation: '13',
    motionPending: false,
    motionNotice: motionRefusedNotice,
    requests: [],
  });

  // Saved MotionPreferences ('full', rev '2') also triggers Desktop.syncMotion ->
  // Motion.propose (requestId '8', profile 'full'), advancing presentation twice (11->13).
  const motionProfileSetRequest = {
    protocolVersion: 3,
    kind: 'motion-profile-set',
    binding: wireBinding,
    requestId: '8',
    profile: 'full',
  };
  const motionSavedCommit = settingsCommit({
    ...motionPendingSpec,
    publication: '12',
    presentation: '13',
    motionSnapshot: 'Full',
    motionPending: false,
    motionProfilePending: true,
    motionNotice: 'Motion preference saved.',
    requests: [motionProfileSetRequest],
  });
  const batchMotionProfileSet = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('12'),
    lease: counter('1'),
    binding,
    wire: JSON.stringify(motionSavedCommit),
    observations: empty(),
    operations: empty(),
    catalogs: empty(),
  };
  const motionSavedState = patch(motionPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: ['controller', 'a', 'batches'], before: list([batchMotionWrite, batchOpenSettings, batchAttach]), after: list([batchMotionProfileSet, batchMotionWrite, batchOpenSettings, batchAttach]) },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('13')) },
    { path: dpath('request'), before: counter('7'), after: counter('8') },
    { path: dpath('motion', 'preferences', 'snapshot'), before: just({ revision: counter('1'), override: { $: 'System' } }), after: just({ revision: counter('2'), override: { $: 'Full' } }) },
    { path: dpath('motion', 'preferences', 'pending'), before: just({ request: counter('7'), revision: counter('1'), override: { $: 'Full' } }), after: none() },
    { path: dpath('motion', 'preferences', 'notice'), before: 'Saving motion preference…', after: 'Motion preference saved.' },
    { path: dpath('motion', 'pending'), before: none(), after: just({ binding, request: counter('8'), profile: { $: 'Full' } }) },
  ]);

  // =========================================================================
  // Branch 3: Pending ShortcutPreferences Save (requestId '7', apps Alternate)
  // =========================================================================
  const shortcutWriteRequest = {
    protocolVersion: 3,
    kind: 'shortcut-preferences-write',
    binding: wireBinding,
    requestId: '7',
    proposal: {
      preferences: { schema: 1, revision: '1', choices: desiredShortcutChoicesWire },
      fingerprint,
    },
  };
  const shortcutPendingSpec = {
    ...loadedSpec,
    publication: '11',
    presentation: '11',
    shortcutDraft: desiredShortcutChoicesWire,
    shortcutPending: true,
    shortcutNotice: 'Saving and applying shortcut choices…',
    requests: [shortcutWriteRequest],
  };
  const shortcutPendingCommit = settingsCommit(shortcutPendingSpec);
  const batchShortcutWrite = {
    scope: oneScope,
    revision: counter('1'),
    publication: counter('11'),
    lease: counter('1'),
    binding,
    wire: JSON.stringify(shortcutPendingCommit),
    observations: empty(),
    operations: empty(),
    catalogs: empty(),
  };
  const shortcutPendingState = patch(loadedState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('9'), after: counter('11') },
    { path: ['controller', 'a', 'batches'], before: list([batchOpenSettings, batchAttach]), after: list([batchShortcutWrite, batchOpenSettings, batchAttach]) },
    { path: dpath('presentation'), before: just(counter('9')), after: just(counter('11')) },
    { path: dpath('request'), before: counter('6'), after: counter('7') },
    { path: dpath('shortcutPreferences', 'draft'), before: baseShortcutChoicesModel, after: desiredShortcutChoicesModel },
    { path: dpath('shortcutPreferences', 'pending'), before: none(), after: just({ request: counter('7'), choices: desiredShortcutChoicesModel }) },
    { path: dpath('shortcutPreferences', 'notice'), before: loadedShortcutNotice, after: 'Saving and applying shortcut choices…' },
  ]);
  const shortcutPrelude = basePrelude.concat([
    viewAction('popup', '9', '1', 'settings:shortcuts:applications:alternate'),
    viewAction('popup', '10', '1', 'settings:shortcuts:save'),
  ]);

  const shortcutUnknownNotice = 'Shortcut application not confirmed. Refresh reads stored choices and live bindings; this action will not be repeated.';
  const shortcutUnknownState = patch(shortcutPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('shortcutPreferences', 'notice'), before: 'Saving and applying shortcut choices…', after: shortcutUnknownNotice },
  ]);
  const shortcutUnknownCommit = settingsCommit({
    ...shortcutPendingSpec,
    publication: '12',
    presentation: '12',
    shortcutNotice: shortcutUnknownNotice,
    requests: [],
  });

  const shortcutRefusedNotice = 'Shortcut choices refused. Bindings or stored choices changed; refresh and choose again.';
  const shortcutRefusedState = patch(shortcutUnknownState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('12'), after: counter('13') },
    { path: dpath('presentation'), before: just(counter('12')), after: just(counter('13')) },
    { path: dpath('shortcutPreferences', 'pending'), before: just({ request: counter('7'), choices: desiredShortcutChoicesModel }), after: none() },
    { path: dpath('shortcutPreferences', 'notice'), before: shortcutUnknownNotice, after: shortcutRefusedNotice },
  ]);
  const shortcutRefusedCommit = settingsCommit({
    ...shortcutPendingSpec,
    publication: '13',
    presentation: '13',
    shortcutPending: false,
    shortcutNotice: shortcutRefusedNotice,
    requests: [],
  });

  const shortcutStoredNotice = 'Choices saved, but live bindings changed. Refresh and choose a free shortcut before applying.';
  const shortcutStoredState = patch(shortcutPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('shortcutPreferences', 'snapshot'), before: just({ schema: 1, revision: counter('1'), choices: baseShortcutChoicesModel }), after: just({ schema: 1, revision: counter('2'), choices: desiredShortcutChoicesModel }) },
    { path: dpath('shortcutPreferences', 'pending'), before: just({ request: counter('7'), choices: desiredShortcutChoicesModel }), after: none() },
    { path: dpath('shortcutPreferences', 'notice'), before: 'Saving and applying shortcut choices…', after: shortcutStoredNotice },
  ]);
  const shortcutStoredCommit = settingsCommit({
    ...shortcutPendingSpec,
    publication: '12',
    presentation: '12',
    shortcutSnapshot: desiredShortcutChoicesWire,
    shortcutPending: false,
    shortcutNotice: shortcutStoredNotice,
    requests: [],
  });

  const shortcutSavedNotice = 'Shortcut choices saved and active. Existing bindings were preserved.';
  const shortcutSavedState = patch(shortcutPendingState, [
    { path: ['controller', 'a', 'controller', 'a', 'publication'], before: counter('11'), after: counter('12') },
    { path: dpath('presentation'), before: just(counter('11')), after: just(counter('12')) },
    { path: dpath('shortcutPreferences', 'snapshot'), before: just({ schema: 1, revision: counter('1'), choices: baseShortcutChoicesModel }), after: just({ schema: 1, revision: counter('2'), choices: desiredShortcutChoicesModel }) },
    { path: dpath('shortcutPreferences', 'inventory'), before: just(inventoryModel(baseShortcutInventoryWire)), after: just(inventoryModel(appliedShortcutInventoryWire)) },
    { path: dpath('shortcutPreferences', 'pending'), before: just({ request: counter('7'), choices: desiredShortcutChoicesModel }), after: none() },
    { path: dpath('shortcutPreferences', 'notice'), before: 'Saving and applying shortcut choices…', after: shortcutSavedNotice },
  ]);
  const shortcutSavedCommit = settingsCommit({
    ...shortcutPendingSpec,
    publication: '12',
    presentation: '12',
    shortcutSnapshot: desiredShortcutChoicesWire,
    shortcutInventory: appliedShortcutInventoryWire,
    shortcutPending: false,
    shortcutNotice: shortcutSavedNotice,
    requests: [],
  });

  return {
    pendingSettings: {
      prelude: copy(settingsPrelude),
      setupTimers: 0,
      given: copy(settingsPendingState),
      givenEffects: copy(publish(settingsPendingCommit)),
      requestId: '7',
      unknown: { state: copy(settingsUnknownState), effects: copy(publish(settingsUnknownCommit)) },
      refused: { state: copy(settingsRefusedState), effects: copy(publish(settingsRefusedCommit)) },
      saved: { state: copy(settingsSavedState), effects: copy(publish(settingsSavedCommit)) },
    },
    pendingMotion: {
      prelude: copy(motionPrelude),
      setupTimers: 0,
      given: copy(motionPendingState),
      givenEffects: copy(publish(motionPendingCommit)),
      requestId: '7',
      unknown: { state: copy(motionUnknownState), effects: copy(publish(motionUnknownCommit)) },
      refused: { state: copy(motionRefusedState), effects: copy(publish(motionRefusedCommit)) },
      saved: { state: copy(motionSavedState), effects: copy(publish(motionSavedCommit)) },
    },
    pendingShortcut: {
      prelude: copy(shortcutPrelude),
      setupTimers: 0,
      given: copy(shortcutPendingState),
      givenEffects: copy(publish(shortcutPendingCommit)),
      requestId: '7',
      baseInventoryWire: copy(baseShortcutInventoryWire),
      appliedInventoryWire: copy(appliedShortcutInventoryWire),
      desiredChoicesWire: copy(desiredShortcutChoicesWire),
      unknown: { state: copy(shortcutUnknownState), effects: copy(publish(shortcutUnknownCommit)) },
      refused: { state: copy(shortcutRefusedState), effects: copy(publish(shortcutRefusedCommit)) },
      stored: { state: copy(shortcutStoredState), effects: copy(publish(shortcutStoredCommit)) },
      saved: { state: copy(shortcutSavedState), effects: copy(publish(shortcutSavedCommit)) },
    },
    dawnValuesWire: copy(dawnValuesWire),
    viewAction,
  };
}

function buildPreferenceReceiptCases(c) {
  const seeds = buildPreferenceSeeds(c);
  if (c && c.preferenceSeedsOnly === true) {
    return {
      pendingSettings: seeds.pendingSettings,
      pendingMotion: seeds.pendingMotion,
      pendingShortcut: seeds.pendingShortcut,
    };
  }
  const { cloneLiteral: copy, initial, bindingJson, NIL } = c;
  const reset = { input: { kind: 'reset' }, expected: { state: copy(initial), effects: copy(NIL) } };
  const wireBinding = {
    lifetime: String(bindingJson.lifetime),
    session: String(bindingJson.session),
    frontend: String(bindingJson.frontend),
  };

  const settingsOutcome = (requestId, status, snapshot) => ({
    kind: 'incoming',
    value: {
      bridgeProtocol: 1,
      kind: 'native-event',
      payload: {
        protocolVersion: 3,
        kind: 'shell-settings-outcome',
        binding: wireBinding,
        requestId,
        status,
        snapshot,
      },
    },
  });

  const motionOutcome = (requestId, status, snapshot) => ({
    kind: 'incoming',
    value: {
      bridgeProtocol: 1,
      kind: 'native-event',
      payload: {
        protocolVersion: 3,
        kind: 'motion-preferences-outcome',
        binding: wireBinding,
        requestId,
        status,
        snapshot,
      },
    },
  });

  const shortcutOutcome = (requestId, status, snapshot, inventory) => ({
    kind: 'incoming',
    value: {
      bridgeProtocol: 1,
      kind: 'native-event',
      payload: {
        protocolVersion: 3,
        kind: 'shortcut-preferences-outcome',
        binding: wireBinding,
        requestId,
        status,
        snapshot,
        inventory,
      },
    },
  });

  const { pendingSettings: s, pendingMotion: m, pendingShortcut: k, dawnValuesWire, viewAction } = seeds;
  const preludeStep = domain => ({
    input: { kind: 'prelude', values: copy(domain.prelude) },
    setupTimers: domain.setupTimers,
    expected: { state: copy(domain.given), effects: copy(domain.givenEffects) },
  });

  return [
    {
      name: 'settings-pending-malformed-status-noop-then-unknown-and-refused',
      steps: [
        copy(reset),
        preludeStep(s),
        // 'Stored' is valid only for shortcuts; pre-d6fa51ec this mutated settings.outcome/notice.
        { input: settingsOutcome('7', 'Stored', null), expected: { state: copy(s.given), effects: copy(NIL) } },
        { input: settingsOutcome('7', 'bogus', null), expected: { state: copy(s.given), effects: copy(NIL) } },
        { input: settingsOutcome('99', 'Refused', null), expected: { state: copy(s.given), effects: copy(NIL) } },
        { input: settingsOutcome('7', 'Unknown', null), expected: copy(s.unknown) },
        // Duplicate Unknown and attempted re-save while Unknown pending is retained are complete no-ops.
        { input: settingsOutcome('7', 'Unknown', null), expected: { state: copy(s.unknown.state), effects: copy(NIL) } },
        { input: { kind: 'incoming', value: viewAction('popup', '12', '1', 'settings:save') }, expected: { state: copy(s.unknown.state), effects: copy(NIL) } },
        // Correlated Refused clears pending and emits OutcomeAnnouncements settings-refused.
        { input: settingsOutcome('7', 'Refused', null), expected: copy(s.refused) },
      ],
    },
    {
      name: 'settings-pending-malformed-status-noop-then-saved',
      steps: [
        copy(reset),
        preludeStep(s),
        { input: settingsOutcome('7', '', { schema: 2, revision: '2', values: copy(dawnValuesWire) }), expected: { state: copy(s.given), effects: copy(NIL) } },
        { input: settingsOutcome('7', 'Saved', { schema: 2, revision: '2', values: copy(dawnValuesWire) }), expected: copy(s.saved) },
      ],
    },
    {
      name: 'motion-pending-malformed-status-noop-then-unknown-and-refused',
      steps: [
        copy(reset),
        preludeStep(m),
        // 'Stored' is invalid for MotionPreferences; pre-d6fa51ec this mutated motion.preferences.notice.
        { input: motionOutcome('7', 'Stored', null), expected: { state: copy(m.given), effects: copy(NIL) } },
        { input: motionOutcome('7', 'bogus', null), expected: { state: copy(m.given), effects: copy(NIL) } },
        { input: motionOutcome('7', 'Unknown', null), expected: copy(m.unknown) },
        { input: { kind: 'incoming', value: viewAction('popup', '12', '1', 'settings:motion:save') }, expected: { state: copy(m.unknown.state), effects: copy(NIL) } },
        { input: motionOutcome('7', 'Refused', null), expected: copy(m.refused) },
      ],
    },
    {
      name: 'motion-pending-malformed-status-noop-then-saved-syncs-profile',
      steps: [
        copy(reset),
        preludeStep(m),
        { input: motionOutcome('7', 'Pending', { schema: 1, revision: '2', override: 'full' }), expected: { state: copy(m.given), effects: copy(NIL) } },
        { input: motionOutcome('7', 'Saved', { schema: 1, revision: '2', override: 'full' }), expected: copy(m.saved) },
      ],
    },
    {
      name: 'shortcut-pending-malformed-status-noop-then-unknown-and-refused',
      steps: [
        copy(reset),
        preludeStep(k),
        // 'Applied' is an internal adapter status, invalid on shortcut-preferences-outcome wire.
        { input: shortcutOutcome('7', 'Applied', null, copy(k.baseInventoryWire)), expected: { state: copy(k.given), effects: copy(NIL) } },
        { input: shortcutOutcome('7', 'Unknown', null, copy(k.baseInventoryWire)), expected: copy(k.unknown) },
        { input: { kind: 'incoming', value: viewAction('popup', '12', '1', 'settings:shortcuts:save') }, expected: { state: copy(k.unknown.state), effects: copy(NIL) } },
        { input: shortcutOutcome('7', 'Refused', null, copy(k.baseInventoryWire)), expected: copy(k.refused) },
      ],
    },
    {
      name: 'shortcut-pending-malformed-status-noop-then-stored',
      steps: [
        copy(reset),
        preludeStep(k),
        { input: shortcutOutcome('7', 'saved', { schema: 1, revision: '2', choices: copy(k.desiredChoicesWire) }, copy(k.baseInventoryWire)), expected: { state: copy(k.given), effects: copy(NIL) } },
        { input: shortcutOutcome('7', 'Stored', { schema: 1, revision: '2', choices: copy(k.desiredChoicesWire) }, copy(k.baseInventoryWire)), expected: copy(k.stored) },
      ],
    },
    {
      name: 'shortcut-pending-malformed-status-noop-then-saved',
      steps: [
        copy(reset),
        preludeStep(k),
        { input: shortcutOutcome('7', 'UNKNOWN', { schema: 1, revision: '2', choices: copy(k.desiredChoicesWire) }, copy(k.appliedInventoryWire)), expected: { state: copy(k.given), effects: copy(NIL) } },
        { input: shortcutOutcome('7', 'Saved', { schema: 1, revision: '2', choices: copy(k.desiredChoicesWire) }, copy(k.appliedInventoryWire)), expected: copy(k.saved) },
      ],
    },
  ];
}

buildPreferenceReceiptCases.buildPreferenceReceiptCases = buildPreferenceReceiptCases;
buildPreferenceReceiptCases.buildPreferenceSeeds = buildPreferenceSeeds;
buildPreferenceReceiptCases.seeds = buildPreferenceSeeds;

module.exports = buildPreferenceReceiptCases;
