# Corrigendum & Revised Host QMP Physical Input Journey (`1719` v2)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Bus Run**: `warlock-20261031-setup` (`lead` sole coordinator; `sol-docs` advisor; `terra-vm` peer reviewer)
- **Supersedes**: `engine-omarchy-idle-input-journey-1700.md` (`sha256: 03e56cb5e797567c89278b882befbe509a9e2347d0a8694b86464fcc78f31038`) and initial `1719` v1 drafts (`083c4db2...` / `48c53bd0...`)
- **Companion Host QMP Driver Skeleton**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/engine-omarchy-host-qmp-driver-1719.py`
- **Posture**: Source-only preparation & driver skeleton. Zero VM/compiler/test/input execution; `nativeOperations: []`; `providerCleanupQualified: false`; `nativeAccepted: false`; `releaseAccepted: false`; historical `163508Z` evidence and all `242/417` obligations preserved.

---

## 1. Explicit Corrections to `03e56cb5...` (`1700` Draft)

1. **No Hardcoded Historical Click Coordinates or Baseline Constants**:
   - Coordinates `(715, 65)`, `(820, 252)`, `(1106, 306)` and `Foot` `(pid 2095, birth 6930, [12, 38] 621x750)` from `engine-display-20261101T163508Z/live-01.png` are **illustrative historical observations only**, never input authority.
   - Before every event, `engine-omarchy-host-qmp-driver-1719.py` queries fresh live guest state (`controller-state.json`, `backend.json`, `preservation-before.json`, `live-current.json`, `/proc`, `/sys/fs/cgroup`, `hyprctl`) and requires Root to supply the **current visible control hitbox (`--hitbox X0 Y0 X1 Y1`)** read from a freshly captured screenshot (`probe --host-screenshot ...`), with **zero DOM/WebDriver fixture metadata**.
2. **No Inferred `t ~ 2.45s` Callback Timestamp or Stream-Quiescence Claim**:
   - Subtracting `5.0s` from `7.445s` in `163508Z` was arithmetic inference, not a timestamped frame observation.
   - Because `live-controller-display-01.py` holds `observations` in memory and writes `observations.json` only in `finally:` (`line 89`), `probe --watch-no-input-seconds 5.5 --host-evidence-dir <HOST_DIR>` verifies zero prior host QMP receipts and polls continuous `0.5s` live samples across `>= 5.5s` (followed post-run by `summarize-run` checking `0.2s` `observationContinuity` in `observations.json`). Both explicitly state this proves **sampled mapped-window survival without host-driver QMP input**, NOT authenticated-stream inter-frame quiescence (which is established separately by the controlled Haskell ingress fixture) nor absence of non-driver guest events.
3. **No `omarchy-shell notifications dismissAll` Mutation & Schema-Safe `hyprctl` Checks**:
   - Removed `dismissAll`. `verify_fence` inspects read-only `hyprctl layers -j` (`levels["2"]` top and `levels["3"]` overlay) and **fails closed** on layer overlap; window filtering checks `c.get("mapped") is True and not c.get("hidden", False) and c.get("visible", True) is True`.
4. **Actual `EngineResult False False` Source Truth — Never Require `exit 0` / `passed: true` / `cleanup: true` / `auth: "Nothing"` / `unitMembers: []`**:
   - `ui/Main.hs:75` (`pure (EngineResult False False)`) and `WebKit.hs:361-365, 491-498` (retaining 3 `/tmp/warlock-filter-XXXXXX` backings) always return `EngineResult False False`, causing `warlock-ui-owner` (`ui/Main.hs:91`) and `warlock-ui-backend` (`Backend.hs:227`, `app/Main.hs:18`) to exit `1` with `"passed": false` even after clean `EngineEntrypoint.hs:323-325` (`localStop` at `D - 1.0s`) retirement, while socket closure records an actual `AuthObservation` (such as `StreamEOF`), not `"Nothing"`. Post-run `summarize-run` retains all observed fields verbatim without stipulating fixed `callbacks` or `operations` totals.

---

## 2. Fixes Applied From `sol-docs` (`01M6C2CYNWTA8434RM4P8G02GC`) & `terra-vm` (`01M6C2DRWA3P75PKE2VMQNT5AX`) `1719` Reviews

1. **Zero `/proc/<pid>/environ` Reads (`sol-docs` #3)**:
   - Removed `proc_display_env` completely; the probe never opens `/proc/*/environ`. Instead, `GUEST_PROBE_SCRIPT` validates `/run/user/<euid>` (`0700`, owned by `euid`), validates `--wayland-display` (`wayland-1` socket owned by `euid`), and validates `--hyprland-instance-signature` (or the unique euid-owned directory under `/run/user/<euid>/hypr/`).
2. **Bounded QMP Timeout, Finite Timing Validation, Pre-Dispatch Clock Recheck & `qmp.py cmd` Reply Parsing (`sol-docs` #1 & `01M6C31CX...`, `terra-vm` #4–#5)**:
   - All timing arguments are validated finite and bounded (`qmp_timeout_seconds` in `[0.4, 1.25]` default `1.0s`; `hold_seconds` in `[0.02, 0.15]` default `0.06s`; `inter_key_seconds` in `[0.05, 0.25]` default `0.08s`; `min_remaining_seconds >= 4.5s` default `5.0s`).
   - `assert_pre_dispatch_budget` re-reads `time.monotonic()` on the host immediately prior to every QMP call so `qmp_timeout + hold + release_timeout + 1.0s` fits strictly inside `D - 1.0s` (`localStop`), while explicitly documenting that separate SSH/QMP channels bound helper completion rather than locking the guest compositor atomically.
   - `qmp_cmd` always uses `qmp.py cmd <json>` (including `execute: "send-key"` for keystrokes — never `qmp.py keys`, which discards replies) and parses `qmp.py`'s Python `repr(dict)` (or JSON) output via `ast.literal_eval`, requiring `{"return": ...}` and rejecting any `{"error": ...}` dict.
3. **Explicit Press/Release Custody Policy (`preReleaseFence` — Zero Unfenced Release Fallback) (`sol-docs` `01M6C31CX...`, `terra-vm` `01M6C31QV...`)**:
   - `press` runs only after `preMotionFence`, separate `motion`, `postMotionRegate`, and `assert_pre_dispatch_budget`.
   - Before dispatching `down=False` in `finally:`, the driver runs a fresh `preReleaseFence` verifying unchanged `(unit, broker, engine, window.address, window.at, window.size, monitor)`, `activeWindow == engine`, client-disjointness from `Foot`, and remaining budget before `D - 1.0s` `localStop`, followed after release by `postReleaseFence`.
   - If `preReleaseFence` fails after `press` was dispatched, **no unfenced motion or `down=False` event is sent on the desktop**; the driver records `buttonLatchPossiblyHeldRequiresRootRecovery = True` and fails closed (`passed = False`) for explicit Root abort/recovery.
4. **Strict Recognized `hyprctl layers -j` Schema, Printable-Only `SAFE_QMP_KEYS` (`a-z`, `0-9`) & `focus-search-field` Witness (`sol-docs` #2 & #4, `terra-vm` #5, #8 & `01M6C31QV...`)**:
   - Malformed, missing, or non-dict `hyprctl layers -j` output, missing monitor key, missing/non-list levels `"2"`/`"3"`, or missing/non-finite surface `x`/`y`/`w`/`h` fails closed immediately (unknown occlusion is never treated as clear).
   - Restricted `click-hitbox --label` strictly to `("open-applications", "focus-search-field")` and `SAFE_QMP_KEYS` strictly to `abcdefghijklmnopqrstuvwxyz0123456789` (`ret`, `tab`, `esc`, `spc`, `slash`, `backspace` removed).
   - `send-keys` requires `--search-click-receipt` with `label == "focus-search-field"` (matching pinned `unit`, `launcherPID`, `deadlineMonotonicNs`, `engine.pid`, `engine.birth`, `window.address`, and `--focus-hitbox`) and runs `verify_fence(..., hitbox=focus_hitbox, forbid_upper_layer_surfaces=True)` before every key. Explicitly records that neither `activeWindow` nor a prior click receipt proves GTK/WebKit widget or `wl_keyboard` focus; Root must visually confirm the visible search field before and after typing (`03c-search-nomatch.png`) and stop on any uncertainty.
5. **Strict Cgroup/`/proc` Census, `pgrep` Exit Codes, Canonical `ControlGroup` & Mandatory Baseline Process Records (`terra-vm` #1–#3)**:
   - `os.walk(cg_path, onerror=walk_err)` requires `"cgroup.procs"` in every visited cgroup directory + `proc_record_strict(pid)` for 100% of PIDs (`len(liveCgroupProcs) == len(liveCgroupPIDs)`); any `EACCES`/`EPERM`/walk error sets `liveCgroupKnown = False` and fails closed.
   - `pgrep -x hyprlock` treats `0` as locked, `1` as unlocked, and any exit `not in (0, 1)` as a fatal error.
   - Pins exact `--expected-unit` (`^warlock-mvp-app-[0-9a-f]{12}\.scope$`), canonical `ControlGroup == /user.slice/user-<euid>.slice/user@<euid>.service/app.slice/<unit>`, `--expected-launcher-pid`, and `--expected-deadline-ns`.
   - Every client in `preservation-before.json` (especially `Foot`) MUST have both a non-null original `preservationBeforeProcesses` entry AND a matching live process (`pid`, `birth`, `device`, `inode`) plus a mapped client window (`address`, `pid`, `class`).

---

## 3. Revised Root-Driven Physical No-Match Journey Under Original `28s` `D`

1. **Step 1 — Continuous Sampled No-Driver-Input Watch (`>= 5.5s`) & Pinning**:
   - After `live-controller-display-01.py` starts `warlock-ui-backend` under immutable `28s` `D` and maps the window, Root runs:
     `probe <GUEST_RUN_DIR> <HOST_DIR>/01-post-idle-probe.json --host-evidence-dir <HOST_DIR> --watch-no-input-seconds 5.5 --poll-interval-seconds 0.5 --host-screenshot <HOST_DIR>/01-post-idle.png`
   - Pins `(unit, launcherPID, deadlineMonotonicNs, broker.pid, broker.birth, engine.pid, engine.birth, window.address)` from `01-post-idle-probe.json` and reads the current visible `Applications` button rectangle `[ax0, ay0, ax1, ay1]` from `01-post-idle.png`.
2. **Step 2 — Open `Applications` (`click-hitbox --label open-applications`) & Read Current Search Input Rectangle**:
   - Root runs `click-hitbox` with `--label open-applications --hitbox ax0 ay0 ax1 ay1` and all pinned identities (`02a-click-applications.json`), then captures `02b-applications-open.png` via `probe --host-screenshot`.
   - Visually confirms `pView` transitioned from `"Choose a window"` to `"Applications"` and reads the current visible search input rectangle `[sx0, sy0, sx1, sy1]` from `02b-applications-open.png`.
3. **Step 3 — Focus `pView` Search Box (`click-hitbox --label focus-search-field`) & Type Printable No-Match Query (`send-keys`)**:
   - Because `bView` (`HttpBar`) and `pView` (`HttpPopup`) are separate `WebKitWebView` widgets (`Mvp.hsc:838-850`), Root runs `click-hitbox` on `--label focus-search-field --hitbox sx0 sy0 sx1 sy1` (`03a-click-search.json`).
   - Root runs `send-keys` passing `--search-click-receipt <HOST_DIR>/03a-click-search.json --focus-hitbox sx0 sy0 sx1 sy1 --keys z x q v 9` (`03b-send-keys.json`), then captures `03c-search-nomatch.png` via `probe --host-screenshot` to visually confirm `"zxqv9"` in the search input and `"No matching applications. Change your search or Refresh."` (`Surface.elm:483`).
4. **Step 4 — Zero Further Physical Input (Strict No-Match Slice) & Natural `D` Retirement**:
   - No `Refresh`, `Escape`, pin, or launch actions are sent in this physical no-match slice.
   - Stop all QMP input well before `D - 1.0s`, let `live-controller-display-01.py` finish, and run `summarize-run <GUEST_RUN_DIR> <HOST_DIR>/99-summary.json` to collect `0.2s` `observationContinuity`, `trial-result.json`, `backend.stdout` (`passed: false` under `EngineResult False False`), `preservation-after.json`, and `idle-restoration.json`.
