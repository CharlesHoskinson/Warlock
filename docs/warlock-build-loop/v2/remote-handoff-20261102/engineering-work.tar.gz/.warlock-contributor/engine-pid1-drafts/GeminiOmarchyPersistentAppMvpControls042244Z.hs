{-# LANGUAGE OverloadedStrings #-}
-- Candidate persistent application MVP positive & negative controls (unexecuted
-- by worker; Root alone compiles and executes under protected QA).
-- Exercises:
--   1. Legacy single-arg bounded CLI preserved unchanged.
--   2. warlock-ui-backend --persistent <config> with applicationAttachment=true,
--      catalog-request + taskbar-pins-write, closed JSON summary, persisted
--      taskbar.json, and restart persistence without replay.
--   3. Public library PersistentBackendOwner natural child exit (LeaderReaped)
--      retiring once under implicit containment CleanupDeadlineSelected without
--      requiring an explicit requestPersistentBackendStop.
--   4. Hostile shell-command & duplicate requestId whole-frame rejection in
--      --persistent mode before any domain mutation (zero sentinel, taskbar.json
--      bytes unchanged, non-zero exit).
--   5. Synthetic child stderr privacy (exitCode=23 WARLOCK_SYNTHETIC_* markers
--      written to child stderr, verified absent from backend stdout/stderr).
--   6. Settled missing-config refusal and pre-live StopLatchedBeforeLive refusal
--      retiring cleanly once via sealPersistentUnboundRoot (RootNeverBound).
module GeminiOmarchyPersistentAppMvpControls042244Z
 ( runPersistentAppMvpControls ) where

import Control.Monad (forM_, unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.IORef (modifyIORef', newIORef, readIORef)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import GHC.Clock (getMonotonicTimeNSec)
import Numeric (showHex)
import System.Directory (createDirectory, doesPathExist, listDirectory)
import System.Exit (ExitCode(..))
import System.FilePath ((</>), takeDirectory)
import System.Posix.Files (deviceID, fileID, getSymbolicLinkStatus, isRegularFile, setFileMode)
import System.Process (readProcessWithExitCode)
import System.Timeout (timeout)
import Warlock.Backend
 ( DirectoryPin(..)
 , directoryDevice
 , directoryInode
 , directoryPath
 , loadPersistentBackendConfig
 , newPersistentBackendOwner
 , persistentBackendCounts
 , persistentBackendStartupRefusal
 , requestPersistentBackendStop
 , retirePersistentBackend
 , runPersistentBackend
 )
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as Persistent
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (Counter, binding, parseCounter)
import qualified Warlock.Protocol.StrictJson as J

counter :: T.Text -> Counter
counter = either (error . show) id . parseCounter False

sha :: B.ByteString -> String
sha = concatMap (\x -> let s = showHex x "" in replicate (2 - length s) '0' ++ s) . B.unpack . SHA.hash

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

within :: String -> IO a -> IO a
within label action = timeout 10000000 action >>= maybe (ioError (userError (label ++ ": timed out"))) pure

encoded :: J.Json -> B.ByteString
encoded = TE.encodeUtf8 . J.renderJson

obj :: [(T.Text, J.Json)] -> J.Json
obj = J.JObject

txt :: String -> J.Json
txt = J.JString . T.pack

bindingValue :: J.Json
bindingValue = obj
 [ ("lifetime", txt "9007199254740993")
 , ("session", txt "9007199254740995")
 , ("frontend", txt "9007199254740997")
 ]

request :: String -> Int -> [(T.Text, J.Json)] -> J.Json
request kind identity extra = obj
 ( [ ("protocolVersion", J.JNumber "3")
   , ("kind", txt kind)
   , ("binding", bindingValue)
   , ("requestId", txt (show identity))
   ] ++ extra )

commit :: [J.Json] -> B.ByteString
commit requests = encoded $ obj
 [ ("viewProtocol", J.JNumber "1")
 , ("kind", txt "view-commit")
 , ("projection", obj [])
 , ("requests", J.JArray requests)
 , ("focus", J.JArray [])
 ]

proposal :: String -> [String] -> J.Json
proposal revision identities = obj
 [ ("revision", txt revision)
 , ("identities", J.JArray (map txt identities))
 ]

pinDirectory :: FilePath -> IO DirectoryPin
pinDirectory path = do
 s <- getSymbolicLinkStatus path
 pure (DirectoryPin path (toInteger (deviceID s)) (toInteger (fileID s)))

directoryJson :: DirectoryPin -> J.Json
directoryJson p = obj
 [ ("path", txt (directoryPath p))
 , ("device", txt (show (directoryDevice p)))
 , ("inode", txt (show (directoryInode p)))
 ]

fresh :: FilePath -> IO FilePath
fresh path = createDirectory path >> setFileMode path 0o700 >> pure path

writePrivate :: FilePath -> B.ByteString -> IO ()
writePrivate path bytes = B.writeFile path bytes >> setFileMode path 0o600

pinImage :: FilePath -> IO [String]
pinImage path = do
 s <- getSymbolicLinkStatus path
 bytes <- B.readFile path
 unless (isRegularFile s) (ioError (userError "nonregular trusted QA executable"))
 pure [show (deviceID s), show (fileID s), show (B.length bytes), sha bytes]

atField :: T.Text -> J.Json -> J.Json
atField key (J.JObject fields) = maybe J.JNull id (lookup key fields)
atField _ _ = J.JNull

runPersistentAppMvpControls
 :: FilePath -> [String] -> FilePath -> [String] -> FilePath -> IO Int
runPersistentAppMvpControls backend backendPins child childPins root = do
 actualBackend <- pinImage backend
 actualChild <- pinImage child
 unless (actualBackend == backendPins && actualChild == childPins)
  (ioError (userError "independent executable pins differ"))
 checksRun <- newIORef (0 :: Int)
 let check label ok = do
      modifyIORef' checksRun (+ 1)
      unless ok (ioError (userError label))
     make label = fresh (root </> label)
 beforeRoot <- listDirectory root
 check "fresh private persistent MVP root" (null beforeRoot)
 applications <- make "applications"
 pinsRoot <- make "pins"
 let sentinel = root </> "must-not-spawn"
 writePrivate (applications </> "alpha.desktop")
  (C.pack ("[Desktop Entry]\nType=Application\nName=Alpha\nExec=/bin/sh -c 'touch " ++ sentinel ++ "'\n"))
 writePrivate (applications </> "beta.desktop")
  "[Desktop Entry]\nType=Application\nName=Beta\nExec=/bin/true\n"
 catalogPin <- pinDirectory applications
 storagePin <- pinDirectory pinsRoot
 let parents = reverse (takeWhile (/= "/") (iterate takeDirectory (takeDirectory child)))
 ancestorPins <- mapM pinDirectory parents
 let expectedBinding = either (error . show) id
      (binding (counter "9007199254740993") (counter "9007199254740995") (counter "9007199254740997"))
     buildConfig scriptFile repliesFile deadline attachOptIn =
      let baseFields =
           [ ("schema", J.JNumber "1")
           , ("binding", bindingValue)
           , ("deadlineMonotonicNs", txt (show deadline))
           , ("ui", obj
              [ ("path", txt child)
              , ("device", txt (childPins !! 0))
              , ("inode", txt (childPins !! 1))
              , ("size", txt (childPins !! 2))
              , ("sha256", txt (childPins !! 3))
              , ("arguments", J.JArray [txt scriptFile, txt repliesFile])
              , ("ancestors", J.JArray (map directoryJson ancestorPins))
              ])
           , ("catalogRoots", J.JArray [directoryJson catalogPin])
           , ("pinsRoot", directoryJson storagePin)
           , ("locale", txt "C")
           ]
      in obj (if attachOptIn then ("applicationAttachment", J.JBool True) : baseFields else baseFields)
     framesJson exitCodeOpt frames =
      let base =
           [ ("schema", J.JNumber "1")
           , ("frames", J.JArray
              [ obj
                 [ ("wire", J.JString (TE.decodeUtf8 wire))
                 , ("replies", J.JNumber (T.pack (show replyCount)))
                 , ("refused", J.JBool refused)
                 ]
              | (wire, replyCount, refused) <- frames
              ])
           ]
      in obj (case exitCodeOpt of
          Nothing -> base
          Just code -> base ++ [("exitCode", J.JNumber (T.pack (show code)))])
     prepare label attachOptIn exitCodeOpt frames = do
      directory <- make label
      let scriptFile = directory </> "script.json"
          repliesFile = directory </> "replies.json"
          configFile = directory </> "startup.json"
      writePrivate scriptFile (encoded (framesJson exitCodeOpt frames))
      now <- getMonotonicTimeNSec
      writePrivate configFile (encoded (buildConfig scriptFile repliesFile (toInteger now + 5000000000) attachOptIn))
      pure (directory, configFile, repliesFile)
     readReplies path = do
      bytes <- B.readFile path
      limits <- must (J.bounds (8 * 1024 * 1024) 16)
      tree <- must (J.decodeStrict limits bytes)
      case tree of
       J.JArray values -> mapM (\v -> case v of
        J.JString s -> pure (TE.encodeUtf8 s)
        _ -> ioError (userError "reply log typed string")) values
       _ -> ioError (userError "reply log array")
     decodeSummary rawBytes = do
      limits <- must (J.bounds 65536 16)
      must (J.decodeStrict limits rawBytes)
     runCli args directory = do
      (code, out, err) <- readProcessWithExitCode backend args ""
      let outBytes = C.pack out
          errBytes = C.pack err
      writePrivate (directory </> "backend.stdout") outBytes
      writePrivate (directory </> "backend.stderr") errBytes
      pure (code, C.filter (/= '\n') outBytes, errBytes)

 -- 1. Legacy single-arg bounded CLI preserved unchanged.
 (legacyDir, legacyCfg, legacyReplies) <- prepare "legacy-bounded-cli" False Nothing
  [(commit [request "catalog-request" 1 []], 1, False)]
 (legacyCode, legacyOut, _) <- runCli [legacyCfg] legacyDir
 legacyJson <- decodeSummary legacyOut
 check "legacy single-arg CLI exits 0" (legacyCode == ExitSuccess)
 check "legacy single-arg CLI reports passed and cleanup"
  (atField "passed" legacyJson == J.JBool True && atField "cleanup" legacyJson == J.JBool True)
 legacyFrames <- readReplies legacyReplies
 check "legacy single-arg CLI delivers 1 reply" (length legacyFrames == 1)

 -- 2. Persistent CLI positive end-to-end with applicationAttachment=true + pin write + restart.
 (persDir, persCfg, persReplies) <- prepare "persistent-cli-positive" True Nothing
  [ (commit [request "catalog-request" 2 []], 2, False)
  , (commit [request "taskbar-pins-write" 3 [("proposal", proposal "1" ["alpha"])]], 1, False)
  ]
 (persCode, persOut, persErr) <- runCli ["--persistent", persCfg] persDir
 persJson <- decodeSummary persOut
 check "persistent CLI exits 0 on clean session and retirement" (persCode == ExitSuccess && B.null persErr)
 check "persistent CLI reports closed schema and non-acceptance"
  ( atField "schema" persJson == J.JNumber "1"
  && atField "mode" persJson == txt "persistent"
  && atField "passed" persJson == J.JBool True
  && atField "cleanup" persJson == J.JBool True
  && atField "stage" persJson == txt "executed"
  && atField "callbacks" persJson == J.JNumber "2"
  && atField "operations" persJson == J.JNumber "2"
  && atField "nativeAccepted" persJson == J.JBool False
  && atField "releaseAccepted" persJson == J.JBool False
  )
 persFrames <- readReplies persReplies
 check "persistent CLI delivers attachment + catalog + pin-saved frames" (length persFrames == 3)
 attachedReply <- must (D.decodeDesktopGateway (persFrames !! 0))
 check "first gateway frame matches binding" (D.replyBinding attachedReply == expectedBinding)
 attachedTree <- decodeSummary (persFrames !! 0)
 check "first gateway frame is application-attached" (atField "kind" attachedTree == txt "application-attached")
 savedTree <- decodeSummary (persFrames !! 2)
 check "pin write saved revision 2"
  ( atField "status" (atField "payload" savedTree) == txt "Saved"
  && atField "revision" (atField "preferences" (atField "payload" savedTree)) == txt "2"
  )
 persistedPins <- B.readFile (pinsRoot </> "taskbar.json")
 check "persisted taskbar.json matches expected content"
  (persistedPins == "{\"schema\":1,\"revision\":\"2\",\"identities\":[\"alpha\"]}")

 (restartDir, restartCfg, restartReplies) <- prepare "persistent-cli-restart" False Nothing
  [(commit [request "catalog-request" 4 []], 1, False)]
 (restartCode, _, _) <- runCli ["--persistent", restartCfg] restartDir
 restartFrames <- readReplies restartReplies
 restartTree <- decodeSummary (head restartFrames)
 check "persistent CLI restart reads persisted revision 2 without replay"
  ( restartCode == ExitSuccess
  && atField "revision" (atField "preferences" (atField "payload" restartTree)) == txt "2"
  )

 -- 3. Public library PersistentBackendOwner natural child exit retires once without explicit stop.
 (_, libCfg, _) <- prepare "persistent-lib-natural-exit" False Nothing
  [(commit [request "catalog-request" 5 []], 1, False)]
 libSessions <- newCurrentSessions
 libBudget <- must (Persistent.stopBudgetMicros 5000000)
 libOwner <- newPersistentBackendOwner libSessions libBudget
 libLoaded <- within "load lib config" (loadPersistentBackendConfig libOwner libCfg)
 check "lib config loaded" (libLoaded == Right ())
 libRun <- within "run lib persistent backend" (runPersistentBackend libOwner)
 check "lib persistent backend ran 1 callback and 1 operation"
  (persistentBackendCounts libRun == (1, 1) && persistentBackendStartupRefusal libRun == Nothing)
 libRetired1 <- within "retire lib natural exit" (retirePersistentBackend libOwner)
 libRetired2 <- within "retire lib natural exit idempotent" (retirePersistentBackend libOwner)
 check "natural exit retires once and stays idempotent" (libRetired1 && libRetired2)

 -- 4. Negative: hostile shell-command and duplicate requestId rejected before domain mutation.
 forM_
  [ ("persistent-hostile-shell", commit [request "shell-command" 6 [("command", txt ("touch " ++ sentinel))]])
  , ("persistent-duplicate-reqid", commit [request "catalog-request" 7 [], request "catalog-request" 7 []])
  ] $ \(label, badWire) -> do
   (badDir, badCfg, _) <- prepare label False Nothing [(badWire, 0, True)]
   (badCode, badOut, _) <- runCli ["--persistent", badCfg] badDir
   badJson <- decodeSummary badOut
   sentinelExists <- doesPathExist sentinel
   pinsAfterBad <- B.readFile (pinsRoot </> "taskbar.json")
   check (label ++ ": non-zero exit and passed=false")
    (badCode /= ExitSuccess && atField "passed" badJson == J.JBool False)
   check (label ++ ": zero operations, no sentinel, taskbar.json unchanged")
    ( atField "operations" badJson == J.JNumber "0"
    && not sentinelExists
    && pinsAfterBad == persistedPins
    )

 -- 5. Negative: synthetic child stderr markers never leak into persistent CLI stdout/stderr.
 (privDir, privCfg, privReplies) <- prepare "persistent-stderr-privacy" False (Just 23)
  [(commit [request "catalog-request" 8 []], 1, False)]
 (privCode, privOut, privErr) <- runCli ["--persistent", privCfg] privDir
 injectedExists <- doesPathExist (privReplies ++ ".stderr-injected")
 let leaked marker = B.isInfixOf marker privOut || B.isInfixOf marker privErr
 check "child exit 23 fails persistent CLI after writing synthetic stderr receipt"
  (privCode /= ExitSuccess && injectedExists)
 check "zero synthetic stderr markers leaked to persistent CLI output"
  ( not (leaked "WARLOCK_SYNTHETIC_CREDENTIAL_DEL017_8C41A2")
  && not (leaked "WARLOCK_SYNTHETIC_DRAFT_DEL017_9D52B3")
  && not (leaked "WARLOCK_SYNTHETIC_PIXELS_DEL017_AE63C4")
  )

 -- 6. Negative: settled missing-config refusal and pre-live StopLatchedBeforeLive retire cleanly.
 missingSessions <- newCurrentSessions
 missingOwner <- newPersistentBackendOwner missingSessions libBudget
 missingLoaded <- within "missing config load"
  (loadPersistentBackendConfig missingOwner (root </> "does-not-exist-startup.json"))
 check "missing config refused" (missingLoaded /= Right ())
 missingRetired <- within "missing config retire" (retirePersistentBackend missingOwner)
 check "settled missing config retires cleanly via unbound root seal" missingRetired

 (_, preStopCfg, _) <- prepare "persistent-prelive-stop" False Nothing
  [(commit [request "catalog-request" 9 []], 1, False)]
 preStopSessions <- newCurrentSessions
 preStopOwner <- newPersistentBackendOwner preStopSessions libBudget
 preStopLoaded <- within "pre-stop config load" (loadPersistentBackendConfig preStopOwner preStopCfg)
 check "pre-stop config loaded" (preStopLoaded == Right ())
 stopReceipt <- within "pre-stop request" (requestPersistentBackendStop preStopOwner)
 check "stop latched before live" (stopReceipt == Persistent.StopLatchedBeforeLive)
 preStopRun <- within "pre-stop run" (runPersistentBackend preStopOwner)
 check "pre-stop run refuses with SessionClosed and zero counts"
  ( persistentBackendStartupRefusal preStopRun == Just (Persistent.StartupAdmissionRefused SessionClosed)
  && persistentBackendCounts preStopRun == (0, 0)
  )
 preStopRetired1 <- within "pre-stop retire" (retirePersistentBackend preStopOwner)
 preStopRetired2 <- within "pre-stop retire idempotent" (retirePersistentBackend preStopOwner)
 check "pre-live stopped owner retires cleanly and idempotently" (preStopRetired1 && preStopRetired2)

 readIORef checksRun
