'use strict';
// Source-derived, unexecuted QA draft. This is a pure-policy bridge fixture,
// NOT current application-only Haskell native authority or native acceptance.
// The independent window factory dependency is SHA-256
// 149f2f4181b1c23ca1ccdeb2a692e6be6aa812eaee365375852013ec85c22275.
// It must supply its source-literal Pending GIVEN, not captured reducer data.
// Root must review exact compiler tags, all fields and prelude reachability.
module.exports = function buildWindowRebindCases(c) {
  const {cloneLiteral: copy, literalPatches: patch, buildWindowCases,
    oneScope, oneScopeJson, binding, bindingJson, host, empty, none, zero, NIL} = c;
  if ([copy,patch,buildWindowCases,oneScope,oneScopeJson,binding,bindingJson,host,
       empty,none,zero,NIL].some(x => x === undefined) ||
      typeof copy !== 'function' || typeof patch !== 'function' || typeof buildWindowCases !== 'function') {
    throw new Error('independent window GIVEN and complete literal context required');
  }
  const original = buildWindowCases(c);
  if (!Array.isArray(original) || !original[0] || !Array.isArray(original[0].steps) ||
      original[0].steps[0].input.kind !== 'reset' || original[0].steps[1].input.kind !== 'prelude') {
    throw new Error('unexpected source-literal window GIVEN');
  }
  const given = copy(original[0].steps[1]);
  const pending = given.expected.state;
  const C = s => ({$: 'Counter', a:s});
  const J = x => ({$: 'Just', a:x});
  const L = xs => xs.reduceRight((b,a) => ({$:'::',a,b}),empty());
  const dp = (...xs) => ['controller','a','controller','a','desktop',...xs];
  const sp = (...xs) => dp('windows','shell',...xs);
  const cp = (...xs) => ['controller','a',...xs];
  const change = (path,before,after) => ({path,before,after});
  const pair = (a,b) => ({$:'#2',a,b});
  const context = {lifetime:C('1'),epoch:C('1'),output:C('1'),revision:C('1')};
  const intent = {request:C('1'),generation:C('1'),incarnation:C('1'),operation:{$:'Minimize'},context};
  const wireContext = {lifetime:'1',epoch:'1',output:'1',revision:'1'};
  const wireIntent = {request:'1',generation:'1',incarnation:'1',operation:'minimize',context:wireContext};
  const tx = status => ({intent,status:{$:status},effectProtocol:1});
  const issued = {binding,protocol:1,intent};
  const B2 = {$:'Binding',a:C('1'),b:C('1'),c:C('2')};
  const b2 = {lifetime:'1',session:'1',frontend:'2'};
  const host2 = '{"lifetime":"1","session":"1","frontend":"2"}';
  const lostText = 'Window adapter unavailable. Reconnect to read current state. Unconfirmed actions will not be repeated.';
  const correlation = '{"outcome":"adapter-unavailable","binding":{"lifetime":"1","session":"1","frontend":"1"},"identity":{"adapter":"windows","request":"1","service":null,"revision":null}}';
  const announce = {interrupt:false,sequence:'1',correlation,text:lostText};
  const rawAnnounce = {interrupt:false,sequence:C('1'),correlation,text:lostText};
  const row = (id,domId,label,ariaLabel,detail,enabled) =>
    ({id,domId,label,ariaLabel,detail,enabled,focusOnly:false});
  const wrap = packet => L([{$:'Publish',a:{$:0,a:packet}}]);
  const gateway = payload => ({bridgeProtocol:1,kind:'native-event',payload});
  const viewAction = (publication,id) => ({kind:'incoming',value:{bridgeProtocol:1,kind:'view-action',payload:{
    viewProtocol:1,kind:'view-action',scope:oneScopeJson,action:{surfaceProtocol:2,kind:'surface-action',
      surface:'bar',publication,lease:'0',id,trigger:'keyboard'}}}});
  const ordinary = (wireHost,presentation) => {
    const p='applications:'+wireHost+':'+presentation+':';
    return [
      row('bar:overview',p+'control:overview-opener','Task View','Open Task View','',false),
      row('bar:switcher',p+'control:switcher-opener','Switch windows','Open window switcher','',false),
      row('bar:notifications',p+'notifications:opener','Notifications','Open notifications','',true),
      row('bar:files',p+'files:opener','Files','Open Files menu','',true),
      row('bar:system',p+'system:opener','System','Open system menu','',true),
      row('bar:settings',p+'settings:opener','Settings','Open settings','',true),
    ];
  };
  const group = (dom,blocked) => row('bar:group:application:demo',dom,'Window',
    'Minimize Window; Active'+(blocked?'; awaiting native confirmation':''),
    blocked?'Awaiting native confirmation; Active':'Active',false);
  const request = (kind,id) => ({protocolVersion:3,kind,binding:b2,requestId:id});
  const commit = (publication,status,bar,requests) => ({viewProtocol:1,kind:'view-commit',projection:{
    viewProtocol:1,kind:'view-frame',revision:'1',views:[oneScopeJson],focusOwner:oneScopeJson,popupOwner:null,
    frame:{surfaceProtocol:2,keyboardParent:true,motion:'reduced',
      appearance:{theme:'night',textScale:100,effectsOff:false,reducedTransparency:false},
      publication,lease:'0',mode:'closed',status,bar,popup:[]},
    announcer:{scope:oneScopeJson,surface:'bar'},announcement:announce},requests,focus:[]});
  const blockedGroup = group('group:'+host+':1:1:application:demo',true);
  const closedStatus = 'Minimize: not confirmed for Window. Reconnect to read window status; the action will not be repeated.';
  const lostBar = [row('bar:reconnect','reconnect','Reconnect','Reconnect to the window system','',true),
    ...ordinary(host,'4'),blockedGroup];
  const lostPacket = commit('8',closedStatus,lostBar,[]);
  const disconnected = patch(pending,[
    change(cp('controller','a','publication'),C('7'),C('8')),
    change(dp('presentation'),J(C('3')),J(C('4'))),
    change(dp('expected'),J(C('1')),none()),
    change(dp('settingsExpected'),J(C('2')),none()),
    change(dp('motionExpected'),J(C('3')),none()),
    change(dp('shortcutExpected'),J(C('4')),none()),
    change(dp('workspaceNavigation','binding'),J(binding),none()),
    change(dp('launch','a','revision'),C('4'),C('5')),
    change(dp('launch','a','host'),J(host),none()),
    change(sp('phase'),{$:'Ready'},{$:'Detached'}),
    change(sp('notice'),'Connected','Connection lost. Reconnect to continue.'),
    change(sp('effects','connected'),true,false),
    change(sp('effects','transaction'),J(tx('Pending')),J(tx('Unknown'))),
    change(sp('effects','unresolved'),L([tx('Pending')]),L([tx('Unknown')])),
    change(dp('adapterNotice'),none(),J({source:{$:'Windows'},binding,request:C('1'),service:none(),revision:none()})),
    change(cp('announcements','a'),zero(),C('1')),
    change(cp('announcements','b'),none(),J(rawAnnounce)),
  ]);
  const reconnectBar = [row('bar:reconnect','reconnect','Reconnect','Reconnect to the window system','',false),
    ...ordinary(host,'5'),blockedGroup];
  const reconnectPacket = commit('9',closedStatus,reconnectBar,[{protocolVersion:3,kind:'host-reconnect'}]);
  const reconnecting = patch(disconnected,[
    change(cp('controller','a','publication'),C('8'),C('9')),
    change(dp('presentation'),J(C('4')),J(C('5'))),
    change(dp('launch','a','revision'),C('5'),C('6')),
    change(sp('reconnecting'),false,true),
    change(sp('notice'),'Connection lost. Reconnect to continue.','Reconnecting…'),
  ]);
  const refresh = row('bar:recovery-refresh','applications:'+host2+':6:bar:recovery-refresh',
    'Refresh window status','Refresh window status; read observations without retrying actions','Observation only',true);
  const app = row('bar:applications','applications:'+host2+':6:control:opener',
    'Applications','Open applications','',true);
  const pendingRebindStatus = 'Minimize: not confirmed for Window. Check your windows; Refresh only reads status.';
  const requests = [request('catalog-request','5'),request('shell-settings-request','6'),
    request('motion-preferences-request','7'),request('shortcut-preferences-request','8'),
    request('projection-request','2')];
  const reboundBar = [refresh,group('detached-group',true),app,...ordinary(host2,'6')];
  const reboundPacket = commit('10',pendingRebindStatus,reboundBar,requests);
  const batch = {scope:oneScope,revision:C('1'),publication:C('10'),lease:zero(),binding:B2,
    wire:JSON.stringify(reboundPacket),observations:L([pair('projection-request',C('2'))]),
    operations:empty(),catalogs:L([{binding:B2,request:C('5')}])};
  // The two original batches are literal values from the separately authored
  // source-derived GIVEN; neither this code nor the dependency reads runtime output.
  const priorBatches = pending.controller.a.batches;
  const rebound = patch(reconnecting,[
    change(cp('controller','a','publication'),C('9'),C('10')),
    change(dp('presentation'),J(C('5')),J(C('6'))),
    change(dp('request'),C('4'),C('8')),
    change(dp('expected'),none(),J(C('5'))),
    change(dp('settingsExpected'),none(),J(C('6'))),
    change(dp('motionExpected'),none(),J(C('7'))),
    change(dp('shortcutExpected'),none(),J(C('8'))),
    change(dp('workspaceNavigation','binding'),none(),J(B2)),
    change(dp('launch','a','revision'),C('6'),C('8')),
    change(dp('launch','a','host'),none(),J(host2)),
    change(sp('binding'),J(binding),J(B2)),
    change(sp('request'),C('1'),C('2')),
    change(sp('expected'),none(),J(C('2'))),
    change(sp('phase'),{$:'Detached'},{$:'Reconciling'}),
    change(sp('reconnecting'),true,false),
    change(sp('notice'),'Reconnecting…','Updating window information…'),
    change(dp('adapterNotice'),J({source:{$:'Windows'},binding,request:C('1'),service:none(),revision:none()}),none()),
    change(cp('batches'),priorBatches,L([batch])),
  ]);
  const oldReceipt = requestId => ({kind:'incoming',value:gateway({protocolVersion:3,kind:'effect-outcome',
    effectProtocol:1,binding:bindingJson,intent:{...wireIntent,request:requestId},status:'Refused',
    reason:'dependency-mismatch',revision:'2',outputGeneration:'1'})});
  const refusedBar = [refresh,group('detached-group',false),app,...ordinary(host2,'6')];
  const refusedPacket = commit('11','Minimize: refused for Window. Refresh window status, then choose again.',refusedBar,[]);
  const historicalSettled = patch(rebound,[
    change(cp('controller','a','publication'),C('10'),C('11')),
    change(sp('effects','transaction'),J(tx('Unknown')),J(tx('Refused'))),
    change(sp('effects','unresolved'),L([tx('Unknown')]),empty()),
    change(sp('issued'),L([issued]),empty()),
  ]);
  // IMPORTANT: Shell.elm applies an exact retained old-binding receipt BEFORE
  // testing current binding. Thus the final step below describes code-as-built,
  // and contradicts a blanket 'all old receipts rejected' contract. It must not
  // be presented as proof of that contract or as authority to weaken it.
  return [{name:'window-pending-disconnect-rebind-historical-receipt',steps:[
    copy(original[0].steps[0]),given,
    {input:{kind:'transportLost'},expected:{state:copy(disconnected),effects:wrap(lostPacket)}},
    {input:viewAction('8','bar:group:application:demo'),expected:{state:copy(disconnected),effects:copy(NIL)}},
    {input:viewAction('8','bar:reconnect'),expected:{state:copy(reconnecting),effects:wrap(reconnectPacket)}},
    {input:{kind:'incoming',value:gateway({protocolVersion:3,kind:'attached',binding:b2})},
      expected:{state:copy(rebound),effects:wrap(reboundPacket)}},
    {input:oldReceipt('2'),expected:{state:copy(rebound),effects:copy(NIL)}},
    {input:oldReceipt('1'),expected:{state:copy(historicalSettled),effects:wrap(refusedPacket)}},
  ]}];
};
