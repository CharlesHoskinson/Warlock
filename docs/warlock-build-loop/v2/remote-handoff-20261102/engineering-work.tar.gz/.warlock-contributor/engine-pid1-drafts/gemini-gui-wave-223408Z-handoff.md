# `gemini-gui` Wave `20261101T223408Z` Handoff (`2245` / `2247` / `2252` on `HEAD` `a30ad9e9f` + Live `qa/ui-http.cjs` `cd25171a`)

## 1. Bar Waiting Placeholder Atomic Source + QA Rebase
- **Source (`Bar.elm` `aa3cd927...` -> `0066a2c4...`; `HttpBar.elm` `74d4b6b8...` unchanged)**:
  - `gemini-gui-bar-waiting-placeholder-source-2228.patch` (`sha256:becb4c2b4216a38d9fe168c98088160bd397640e7846a33a18a0d40256f4e52d`)
- **Atop `a30ad9e9f` (`qa/ui-http.cjs` `da32ed55...`)**:
  - QA: `gemini-gui-bar-waiting-placeholder-qa-2228.patch` (`sha256:271339639df5ffcf83cb23cfb0591453b9fabad2f214948ca79265d836ed2986`)
  - Atomic bundle: `gemini-gui-bar-waiting-placeholder-bundle-2228.patch` (`sha256:2f742fef1103e030fe59787e553bc1ddd85943c98a924af9db9beaf320f03b45`)
- **Atop Live Working Tree (`qa/ui-http.cjs` `cd25171a...` with `cancellationPendingControls`)**:
  - QA: `gemini-gui-bar-waiting-placeholder-qa-cd25-2252.patch` (`sha256:b167ef6c461729134483c3c58a004d51c0a7872b4212d4dd25787be73fcafb55`)
  - Atomic bundle: `gemini-gui-bar-waiting-placeholder-bundle-cd25-2252.patch` (`sha256:852b18b6cfadc2cf84363064b6cc80143e0730bc742e9e352413e094b85119b1`)
- **Independent Peer Reviews**: `terra-browser` `CONCUR` (`01M6CKSAPQ9112YCFFBVDQ7ZE8`), `gemini-site` `CONCUR` (`01M6CM8KXER3WY555P0KPGPVVC`).

## 2. Separate Owned `HttpPopup` Failure-Field Accessibility/Style + Explicit Restart Affordance (`2245` + `2252` `cd25` Rebase)
- Incorporates `terra-browser` (`01M6CMD3YHJXMP896B0BN9WSX2`), `terra-q-http` (`01M6CMGXHQ19B7B6HC0W52VSQT`), and `gemini-site` (`01M6CMKDZHW9EVPTQRPB6B7SJZ`) reviews; zero `SurfaceTheme` duplication and zero `UiHttp` HTTP generation lifecycle edits.
- **Primary (`ReloadRequested` -> `Browser.Navigation.reload` gated on `UiHttp.problem /= Nothing`)**:
  - Source (`HttpPopup.elm` `e814d56f...` -> `ad906e87...`): `gemini-gui-http-popup-failure-style-reload-source-2245.patch` (`sha256:31a446be596398ef4baa39b830e697e447868e5d2aeb19a09068c580500a11fb`)
  - Standalone bundle atop `da32ed55`: `gemini-gui-http-popup-failure-style-reload-bundle-da32-2245.patch` (`sha256:04b7cb38a0119d54df4c0eb118e16f7107a6763111bb53c2008ac28b157afab3`)
  - Combined Bar + `HttpPopup` bundle atop `da32ed55`: `gemini-gui-combined-bar-and-popup-failure-style-reload-bundle-2245.patch` (`sha256:670d5ac4be4b36a9f49d22298da7cea8c3537615bcc29d6cd433447e849e4d22`)
  - Standalone bundle atop `cd25171a`: `gemini-gui-http-popup-failure-style-reload-bundle-cd25-2252.patch` (`sha256:afd87928353765fb95a5a8ccb206f48b9e314a5b682c9b613646328515136243`)
  - Combined Bar + `HttpPopup` bundle atop `cd25171a`: `gemini-gui-combined-bar-and-popup-failure-style-reload-bundle-cd25-2252.patch` (`sha256:dc16034dee974b3987ad9c771c7fb08e039620bf4c9e1f48b1cbeeb11d7db7c4`)
- **Recommended under `ELM-ARC-024` Single-Use Listener Custody (`2247` / `2252` Pure View-Style-Only; `CONCUR` from `terra-browser` `01M6CN8PXYSKPEK4YH94882M8W` + `sol-docs` `01M6CNBTV2QT0QG7ECVEHQH5Q0` + `gemini-site` `01M6CMKDZHW9EVPTQRPB6B7SJZ`)**:
  - Source (`HttpPopup.elm` `e814d56f...` -> `44d96c4e...`, `Msg`/`update` unchanged, zero reload button so `WebKit.hs:448-462` `loadFailed` cannot destroy retained draft while listener is down): `gemini-gui-http-popup-failure-style-only-source-2247.patch` (`sha256:6be4abc3b4a6e533313776d3dc5e510a1e813d3d91ef62b6c312492680c6e907`)
  - Standalone bundle atop `da32ed55`: `gemini-gui-http-popup-failure-style-only-bundle-da32-2247.patch` (`sha256:ef245e94bcc965484882211e2c790b5d90a36de91741ad921b4cac7ab294e783`)
  - Standalone bundle atop `cd25171a`: `gemini-gui-http-popup-failure-style-only-bundle-cd25-2252.patch` (`sha256:41eb9bc4e4f53f74d0078dceb09002710b62366bd75a424c2b1807fc479a99b3`)
  - Combined Bar + `HttpPopup` style-only bundle atop `cd25171a`: `gemini-gui-combined-bar-and-popup-failure-style-only-bundle-cd25-2252.patch` (`sha256:dc7f6ebe75f5c64d5617a86ddffdccec24c01a5adfb8011bfccd99782e18acbd`)

## 3. Adjacent GUI Source Peer Reviews
- **CONCUR** on `sol-popup-cancel-pending-2230.patch` (`sha256:24b66eaba0fc0553277a74935e48c7e26d92bdf98b5ed17e634238e0488970a6`, `Popup.elm` `9761aa5d...` -> `a9f188f9...`).
- **CONCUR** on `terra-browser-ime-cancel-2224.mjs` (`sha256:a22711d9a017f752e73993b3f410bf13a2e52176dabd45a22d46d3aea3dcd7d3`).
- **CONCUR** on `terra-browser-uihttp-failure-replay.elm` (`sha256:d3dab516f45f00d3e2f4fad71901e2204718b4f4ec8a0c5eac9661bc47cebc70`) + `terra-browser-uihttp-failure-result-2251.cjs` (`sha256:5c1297cadaeecb34a49a1e3de90ea57e78dc40a535cfb51b50d38b36e9d3fc28`).
