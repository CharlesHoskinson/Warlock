# Persistent v9 held-borrow startup acquisition: source proposal (UNEXECUTED)

Preimages: canonical held-document Executable/Internal.hs sha256 `1bd4e87275a0c3b69839a0dd7ef3351405350754afafa57a15ffb738a9af717a`; Executable.hs `4eee3ac9b73b78483a88f15f569c68657374dca3d95f56fe03ec8c5b561a8074`; projected v9 full patch `d9c7d29f78215ea70b444afe399ad3aa9dc85a5461535c919f1ce0b5cb3554e6`; actual-gate QA seam patch `d4b767c20a72a33957acf22011a080e4b525ebfb10d365bba9004058f45c1d5e`. Apply only after reconciling v9, not directly to canonical. No tests or compiler run.

Problem: v9 `borrowHeldInterruptible` still acquires through `transition`, whose `uninterruptibleMask_` means held-gate contention prevents the subsequent StartBudget/stop check indefinitely. A `timeout` around this unchanged function cannot solve that wait.

Revised candidate against v9 **plus security sticky-v2** patch `1b9138c04e4671640ef3925f0f5d0df2a369e9e29f79e6e6e9291fc7a98ff511`, projected held Internal postimage `e14ace50e91327659ac6e5615c12bcd338542c303a43a738d6127668635aa8b9`. This replaces the v9/sticky `borrowHeldInterruptible` definition by a shared release constructor: neither path may paste the obsolete Bool release. Export `borrowHeldWhile` through Executable.hs and process-custody Lease.hs, preserving existing APIs. The caller must remain masked through publishing the release capability. No callback is invoked while the held-state MVar is empty. Stop may race after the pre-acquire snapshot; the caller must retain the release capability and revalidate the original deadline and stop before any spawn.

```haskell
-- Both acquisition paths share security sticky-v2 release state.
borrowHeldWith
 :: (MVar HeldState -> IO (Maybe Bool)) -> HeldExecutable
 -> IO (Maybe (Either LeaseError (FilePath, IO Bool, IO ())))
borrowHeldWith acquire (HeldExecutable (Fd fd) gate) = mask $ \_ -> do
 released <- newMVar BorrowPending
 pid <- getProcessID
 let releaseNow = mask $ \_ -> do
      state <- takeMVar released
      case state of
       BorrowReleased -> putMVar released BorrowReleased >> pure True
       BorrowUnknown -> putMVar released BorrowUnknown >> pure False
       BorrowPending -> do
        ownerState <- takeMVar gate `onException` putMVar released BorrowPending
        uninterruptibleMask_ $ case ownerState of
         Live n | n > 0 -> do
          putMVar gate (Live (n-1))
          putMVar released BorrowReleased
          pure True
         _ -> do
          putMVar gate HeldUnknown
          putMVar released BorrowUnknown
          pure False
     release = uninterruptibleMask_ (releaseNow >> pure ())
     path = "/proc/" ++ show pid ++ "/fd/" ++ show fd
 accepted <- acquire gate
 case accepted of
  Nothing -> pure Nothing
  Just False -> pure (Just (Left LeaseClosed))
  Just True -> pure (Just (Right (path,releaseNow,release))) `onException` release

borrowHeldInterruptible :: HeldExecutable -> IO (Either LeaseError (FilePath,IO Bool,IO ()))
borrowHeldInterruptible held = mask $ \_ -> do
 result <- borrowHeldWith (\gate -> Just <$> transition gate (\s -> case s of
  Live n -> (Live (n+1),True); _ -> (s,False))) held
 case result of Just value -> pure value; Nothing -> pure (Left LeaseClosed)

borrowHeldWhile
 :: HeldExecutable -> IO Bool -> IO ()
 -> IO (Maybe (Either LeaseError (FilePath,IO Bool,IO ())))
borrowHeldWhile held cancelled pause = borrowHeldWith acquire held
 where
  acquire gate = mask $ \_ -> let
   loop = do
    stopped <- cancelled
    if stopped then pure Nothing else do
     slot <- tryTakeMVar gate
     case slot of
      Nothing -> pause >> loop
      Just s -> case s of
       Live n -> putMVar gate (Live (n+1)) >> pure (Just True)
       _ -> putMVar gate s >> pure (Just False)
   in loop
```

The outer `borrowHeld` must retain security sticky-v2's masked wrapper and onException release unchanged. The user-space stop snapshot cannot atomically prevent a stop immediately after it, so the caller must still reserve and recheck before spawn. The acquisition above deliberately does not run clock, STM, or arbitrary callback while the gate is empty.
In projected v9 Persistent.Internal, construct these callbacks from the EXISTING `startDl` and `stopReadyVar`; use `System.Timeout.timeout`, already imported. The short wait parks in STM and wakes immediately on stop; it does not start or extend a product deadline:

```haskell
let borrowCancelled = do
     stopped <- atomically (readTVar stopReadyVar)
     left <- remainingMicros startDl
     pure (stopped || left <= 0)
    borrowPause = do
     left <- remainingMicros startDl
     when (left > 0) $
      void (timeout (min 5000 left) (atomically $ do
       stopped <- readTVar stopReadyVar
       if stopped then pure () else retry))
```

Replace only the existing selected-lease acquisition branch with `borrowHeldWhile lease borrowCancelled borrowPause`. On `Nothing`, no borrow was committed and no input preparation or spawn has happened. Do not call `releaseBorrowBounded` at the expired deadline: even its default `pure True` is skipped by the deadline guard, which would falsely quarantine. Use the no-borrow abort below; inspect the latched stop first and preserve the existing quarantine path for a deadline-mint failure. A `Just (Right _)` return is a different ownership state and must use the retained-release route. On `Just (Left _)` preserve the existing lease-unavailable path. On `Just (Right (path, releaseNow, release))`, retain the v9 masked `O.retainBorrow` / `borrowReleaseCell` ownership transfer and `onException release`, then run the existing latched-stop and remaining-StartBudget checks before preparing input or spawning. If the start deadline has expired after a borrow commits, bound release by that original `startDl`; an incomplete release must quarantine instead of extending the original D. A stop that wins immediately after the precheck may race with a committed borrow: the existing post-borrow branch must release it under that original stop deadline; it must never spawn. Do not turn the `Nothing` case into an exception, silently drop a borrowed token, mint a new product deadline, or call the uninterruptible old release on the contended path.

QA integration required (not supplied as a complete runnable test here): extend the actual-gate seam and call the real `withPersistentOwnerHook` production route. Hold the actual held gate before acquisition. (1) Release it before StartBudget: exactly one acquisition and normal live/reap positive control. (2) Keep it held across original StartBudget: refusal TimedOut before releasing holder; no child/dispatch, no borrow increment. (3) Latch stop while gate is held: refusal SessionClosed before holder release using the one original StopDeadline; duplicate stop does not restart D. (4) Race stop with holder release over deterministic seeds: no post-stop spawn, and any committed borrow is either released exactly once or retained with explicit quarantine when release cannot complete by D. Publish fixture worker outcomes in finally, use bounded waits, release gates even on assertion failure, verify retired/uncertain owner and no raw descriptor escape. Root must integrate actual controls and review timing/ownership before running protected checks. The 5 ms value is a requested wait quantum, not a hard scheduler latency bound; the post-acquisition deadline check is mandatory.

No-borrow abort candidate, called ONLY on `borrowHeldWhile` returning `Nothing` before any input preparation or `O.retainBorrow` (the state proof comes from the result constructor, not a guessed release receipt):

```haskell
abortBeforeBorrow :: O.Pending -> IO (Either SessionExit (a, SessionExit))
abortBeforeBorrow pending = do
 -- Same phaseVar -> cbGate lock order as requestSessionStop. This makes a
 -- concurrent stop either latch before our decision, or observe retirement.
 decision <- modifyMVar phaseVar $ \ph -> case ph of
  PhaseStarting -> do
   latched <- peekGateStop cbGate
   case latched of
    Just (Left _) -> pure (PhaseQuarantined ["persistent-stop-deadline-mint-failed"], Left "persistent-stop-deadline-mint-failed")
    Just (Right _) -> pure (PhaseRetired, Right SessionClosed)
    Nothing -> pure (PhaseRetired, Right TimedOut)
  _ -> pure (PhaseQuarantined ["startup-no-borrow-phase-uncertain"], Left "startup-no-borrow-phase-uncertain")
 case decision of
  Left reason -> do
   O.pendingRecordIssue pending reason
   O.failUnsettled rawOwner reason
   pure (Left (ExitUncertain CleanupUncertain [reason]))
  Right why -> do
   O.clearTickets rawOwner
   O.clearPending rawOwner
   O.abortBegin rawOwner
   pure (Left (StartupRefused why))
```

Before adopting this helper, Root must verify owner entry really cannot retain other borrows/tickets in this branch, the phaseVar-to-cbGate lock ordering, and the intentionally conservative unexpected-phase quarantine. The draft does not claim compiled correctness. This proposal performs no descriptor release, does not call the default release callback, and does not mint a replacement deadline.

A concrete production-route QA fragment for integration beside `HeldGateContentionControls` (not executed; imports needed: `Control.Concurrent.threadDelay`, `Control.Monad.when`, `requestSessionStop`, `StopReceipt(..)`, and `ToolError(..)`). The caller must keep the one-shot Probe rooted, including after timeout; the Probe records the owner, held executable and both worker thread IDs. Unlike the existing release-contention fixture, the gate is held BEFORE starting the owner:

```haskell
-- Run once with False (original StartBudget) and once with True (latched stop).
runAcquireBlocked
 :: Probe -> Bool -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runAcquireBlocked probe latchStop acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selected <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 stop <- must (stopBudgetMicros 300000)
 holderEntered <- newEmptyMVar
 holderRelease <- newEmptyMVar
 spawnCalls <- newIORef (0 :: Int)
 let heldAction = holdHeldGateForTest held (putMVar holderEntered ()) (readMVar holderRelease)
     waitStarting = do
      phase <- persistentStatus owner
      if phase == PersistentStarting then pure () else threadDelay 1000 >> waitStarting
     cleanup = do
      void (tryPutMVar holderRelease ())
      mh <- readIORef (holderThread probe)
      mo <- readIORef (ownerThread probe)
      case mh of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar (holderDone probe)))
      case mo of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar (ownerDone probe)))
     run = do
      _ <- mask_ $ do
       tid <- forkFinally (restore heldAction) (putMVar (holderDone probe))
       writeIORef (holderThread probe) (Just tid)
       pure tid
      within "actual gate held" (readMVar holderEntered)
      start <- startBudgetAfter (if latchStop then 2000000 else 200000) >>= must
      let hook stage = when (stage == "persistent-before-spawn") (modifyIORef' spawnCalls (+1))
      _ <- mask_ $ do
       tid <- forkFinally
        (restore (do result <- withPersistentOwnerHook owner selected 4096 start stop ready (\_ -> pure ()) hook
                     now <- getMonotonicTimeNSec
                     pure (toInteger now, result)))
        (putMVar (ownerDone probe))
       writeIORef (ownerThread probe) (Just tid)
       pure tid
      within "owner entered starting" waitStarting
      if latchStop then do
       first <- requestSessionStop owner stop
       second <- requestSessionStop owner stop
       check "first stop latched during gate contention" (first == StopLatchedBeforeLive)
       check "duplicate stop does not reset deadline" (second == StopAlreadyRequested)
      else pure ()
      -- The holder remains locked until after this observation: timeout is a
      -- test watchdog, not a product deadline or evidence of exact wall time.
      result <- within "owner returned while gate held" (readMVar (ownerDone probe))
      calls <- readIORef spawnCalls
      let expected = if latchStop then SessionClosed else TimedOut
      check "refused before spawn while actual gate still held"
       (case result of Right (_, Left (StartupRefused problem)) -> problem == expected && calls == 0; _ -> False)
 restore run `finally` cleanup
```

The fragment covers two real negative routes; add the normal held-path positive and seeded stop-versus-release race controls before treating the fixture as complete. Stop receipt / phase exactness and fixture-wide owner retention must be checked against Root's current v9 integration. `within` is the existing 3-second fixture watchdog. Test timing is not proof that an external scheduler meets an absolute real-time bound.

**Peer review HOLD (engine/security):** `abortBeforeBorrow` above is NOT safe as written: it publishes `PhaseRetired` before raw owner pending/ticket cleanup and `O.abortBegin` have a receipt. An observer can see retired while raw owner remains Beginning; interruption or blocking can make that false claim permanent. Use a distinct cleanup-in-progress phase (or equivalent truthful representation), preserve phaseVar -> cbGate stop-decision ordering, and publish Retired only after a bounded, confirmed raw-owner cleanup. Failure or interruption must retain pending ownership and quarantine. `O.begin` checks Idle but does not itself prove empty retained borrow/ticket refs, so establish that invariant before treating no-borrow as no other obligations. Original start/latched stop D remains unchanged. Do not integrate this branch until an exact reviewed implementation and production-route race controls exist.
