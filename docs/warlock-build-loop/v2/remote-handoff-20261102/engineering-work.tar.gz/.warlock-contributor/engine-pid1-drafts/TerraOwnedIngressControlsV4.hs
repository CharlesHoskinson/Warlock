{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- Root-owned, unexecuted integration fixture against proposed owned ingress.
-- Child must be the separately built TerraOwnedIngressPeer executable. The
-- marker paths are distinct caller-created files registered in Root's owned
-- cleanup registry before this program starts. No native/GUI acceptance.
module Main (main) where

import Control.Exception (mask)
import Control.Monad (unless)
import Data.IORef
import Foreign.StablePtr (newStablePtr)
import System.Directory (doesFileExist, removeFile)
import System.Environment (getArgs)
import System.IO (Handle, IOMode(ReadWriteMode), hIsClosed)
import qualified Network.Socket as S
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import qualified Warlock.Protocol.CredentialIngress as P
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import Warlock.Protocol.Ingress (Direction(..), OfferResult(..), ActivationResult(..), EndpointState(..), OwnerStatus(..), ChannelError(StreamEOF), ingressBinding)
import qualified Warlock.Protocol.PeerCredential as Peer
import Warlock.Capture.Process (SessionObservation(..))
import Warlock.Capture.Process.Persistent
  ( LiveFrameAdmission, LiveWakeReason(..), PersistentOwner, SessionExit(..), StopReceipt(..)
  , newPersistentOwner, requestSessionStop, startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)

data Refusal = MissingOwner | ForeignPeer deriving (Eq, Show)
type Context = (LiveFrameAdmission, P.FrameDeadline)
data Owned = Owned PersistentOwner
  (IORef (Maybe (P.CredentialIngressT Context)))
  (IORef (Maybe (S.Socket,S.Socket))) (IORef (Maybe Handle)) FilePath

data Mode = NaturalExit | ExplicitStop deriving (Eq, Show)
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- Every IORef is strongly anchored before creating sockets, handles or child.
-- The stable reference is intentionally retained to process exit: it is not a
-- claim that reaping, descriptor closure or external cleanup was confirmed.
runOne :: FilePath -> FilePath -> Mode -> IO ()
runOne child marker mode = mask $ \restore -> do
 owner <- newPersistentOwner
 ingressCell <- newIORef Nothing
 socketsCell <- newIORef Nothing
 handleCell <- newIORef Nothing
 _ <- newStablePtr (Owned owner ingressCell socketsCell handleCell marker)
 markerExists <- doesFileExist marker
 check "root marker exists" markerExists
 bound <- must (ingressBinding "1" "2" "3")
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 observed <- newIORef Nothing
 callbacks <- newIORef (0 :: Int)
 deadlines <- newIORef ([] :: [Integer])
 let callback (_, frame) _ = do
      modifyIORef' deadlines (P.frameDeadlineNs frame :)
      modifyIORef' callbacks (+1)
     accept credential = do
      current <- readIORef observed
      pure $ case current of
       Nothing -> Left MissingOwner
       Just obs | Peer.credentialPid credential == toInteger (observedPid obs)
               && Peer.credentialUid credential == uid && Peer.credentialGid credential == gid -> Right ()
       _ -> Left ForeignPeer
     guardFor _ frame = CredentialGuard
      (\credential -> modifyIORef' deadlines (P.frameDeadlineNs frame :) >> accept credential)
      (\credential action -> do
       modifyIORef' deadlines (P.frameDeadlineNs frame :)
       allowed <- accept credential
       case allowed of Left reason -> pure (Left reason); Right () -> Right <$> action)
 ingress <- P.newDesktopCredentialIngressWithContext bound FromElm callback (\_ _ -> ioError (userError "unexpected server callback"))
 writeIORef ingressCell (Just ingress)
 (host,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 writeIORef socketsCell (Just (host,peer))
 offer <- P.transferCredentialSocket ingress host
 check "host socket accepted" (offer == OfferAccepted)
 active <- P.activateCredentialIngress ingress
 check "host socket activated" (active == ActivationLive)
 -- socketToHandle transfers this owned peer endpoint to the fixture handle;
 -- the cells remain retained on all failures and are never blindly reclosed.
 peerHandle <- S.socketToHandle peer ReadWriteMode
 writeIORef handleCell (Just peerHandle)
 start <- startBudgetAfter 2000000 >>= must
 stop <- must (stopBudgetMicros 2000000)
 let verify obs = writeIORef observed (Just obs) >> pure (Right ())
     body session = do
      first <- P.receivePersistentCredentialIngressOwned False session ingress guardFor
      n <- readIORef callbacks
      ds <- readIORef deadlines
      check "actual child credential frame delivered once" (first == Right (P.PersistentOutcome P.CredentialDelivered) && n == 1 && length ds >= 4 && all (== head ds) ds && head ds > 0)
      case mode of
       NaturalExit -> removeFile marker
       ExplicitStop -> do
        receipt <- requestSessionStop owner stop
        putStrLn ("stop receipt: " ++ show receipt)
        -- Natural child exit cannot stand in for the requested stop; retain
        -- the owner and marker if the owned one-shot signal was not sent.
        check "explicit stop signal actually sent" (receipt == StopSignalSent)
        removeFile marker
      terminal <- P.receivePersistentCredentialIngressOwned True session ingress guardFor
      n2 <- readIORef callbacks
      -- Require literal source-level outcomes; print the actual variant and
      -- never treat generic refusal/uncertainty as a stop or death observation.
      putStrLn (show mode ++ " terminal: " ++ show terminal)
      let expected = case mode of
           ExplicitStop -> terminal == Right (P.PersistentOwnerWake LiveWakeStopRequested)
           NaturalExit -> case terminal of
            Right (P.PersistentOwnerWake LiveWakeLeaderExited) -> True
            Right (P.PersistentOutcome (P.CredentialFrameRejected (P.CredentialTransport StreamEOF))) -> True
            _ -> False
      check "actual stop wake or death wake/EOF with no duplicate" (n2 == 1 && expected)
 result <- restore (withPersistentOwnerHook owner (persistentFixture child [marker] peerHandle)
   4096 start stop verify body (\_ -> pure ()))
 -- On exception or uncertainty no closure or registry retirement is inferred.
 case result of
  Right ((), LeaderReaped _) -> do
   closedHandle <- hIsClosed peerHandle
   check "transferred peer handle closed" closedHandle
   status <- P.retireCredentialIngress ingress
   check "owned host close confirmed" (endpoint status == Just EndpointConfirmed)
  other -> ioError (userError ("owner outcome retained as failure/unknown: " ++ show other))

main :: IO ()
main = do
 args <- getArgs
 case args of
  [child,deathMarker,stopMarker]
   | all (\p -> not (null p) && head p == '/') [child,deathMarker,stopMarker]
      && deathMarker /= stopMarker -> do
       runOne child deathMarker NaturalExit
       runOne child stopMarker ExplicitStop
  _ -> ioError (userError "expected absolute child, distinct owned death marker and stop marker")
