{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY QA SOURCE DRAFT. Not compiled or run. No raw descriptor issuer.
-- Allocate and root the FixtureGuard (e.g. in Root's outer fixture registry)
-- BEFORE calling the supplier and retain it through every failure/timeout.
-- A held capability in this guard is NOT a child/process/pipe/reap receipt.
-- Root must independently establish trusted fixture-directory ancestors and
-- install the actual child guardian before spawning. Syntax and last-root
-- identity checks are not an ancestor-custody proof.
-- Never retire a HeldUnknown capability or retry uncertain descriptor closure.
module TerraGraphRetainedFixture0026
 ( FixtureGuard, FixtureDisposition(..), newFixtureGuard, fixtureDisposition
 , validFixtureInputs, validatedRetainedFixture, validatedRetainedFixtureWithHook, retainedSupplier ) where

import Control.Exception (mask)
import Control.Monad (unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.Char (ord)
import Data.IORef (IORef, atomicModifyIORef', newIORef, readIORef, writeIORef)
import Numeric (showHex)
import System.FilePath ((</>), isAbsolute)
import System.Posix.Files (deviceID, fileID, getFileStatus)
import Warlock.Capture.Process.Persistent (PersistentOwner)
import Warlock.Platform.Executable
 ( ExecutableLease, HeldExecutable, LeaseRole(..), newExecutableLease
 , acquireExecutableLease, issueReadyExecutable )
import Warlock.Platform.Resolver (Identity(..), Kind(..), Pin(..), withRoot)

-- Lease remains retained alongside the moved HeldExecutable. The cell holds
-- no raw descriptor and has no recovery/close API. An exception during
-- validation or root cleanup never clears a capability already published.
data GuardState = Fresh | Preparing | LeaseRetained ExecutableLease
                | HeldRetained ExecutableLease HeldExecutable
newtype FixtureGuard = FixtureGuard (IORef GuardState)

data FixtureDisposition = GuardFresh | GuardPreparing | GuardHasLease | GuardHasHeld
 deriving (Eq, Show)

newFixtureGuard :: IO FixtureGuard
newFixtureGuard = FixtureGuard <$> newIORef Fresh

-- Observes retention state only; never returns the capability or performs IO
-- against its descriptor. GuardHasHeld is not a root-close/child/reap receipt.
fixtureDisposition :: FixtureGuard -> IO FixtureDisposition
fixtureDisposition (FixtureGuard cell) = do
 current <- readIORef cell
 pure $ case current of
  Fresh -> GuardFresh
  Preparing -> GuardPreparing
  LeaseRetained _ -> GuardHasLease
  HeldRetained _ _ -> GuardHasHeld

-- C.pack is byte-preserving only for the deliberately restricted ASCII
-- input. A single relative component matches the sole terminal pin; nested
-- paths need their own fully pinned parent-chain fixture, not this helper.
validFixtureInputs :: FilePath -> FilePath -> Bool
validFixtureInputs rootDir name =
 isAbsolute rootDir && not (null rootDir) && all asciiNonNul rootDir
  && not (null name) && name /= "." && name /= ".."
  && all (\c -> asciiNonNul c && c /= '/') name
 where
  asciiNonNul c = ord c > 0 && ord c < 128

-- Single-use. In particular, do not reuse after any exception or Left from
-- withRoot: its root/descriptor close disposition may be uncertain.
validatedRetainedFixture :: FixtureGuard -> FilePath -> FilePath -> IO HeldExecutable
validatedRetainedFixture guard rootDir name =
 validatedRetainedFixtureWithHook guard rootDir name (pure ())

-- Test-only fault/interruption seam. Hook runs unmasked only after the held
-- capability has been retained; the actual withRoot bracket then unwinds.
-- It exercises exceptional cleanup, not a closeFd fault or cleanup receipt.
validatedRetainedFixtureWithHook :: FixtureGuard -> FilePath -> FilePath -> IO () -> IO HeldExecutable
validatedRetainedFixtureWithHook (FixtureGuard cell) rootDir name postIssued = mask $ \restore -> do
 admitted <- atomicModifyIORef' cell $ \s -> case s of
  Fresh -> (Preparing, True)
  _ -> (s, False)
 unless admitted (ioError (userError "fixture guard already used"))
 unless (validFixtureInputs rootDir name) (ioError (userError "invalid fixture root or component"))
 rootStat <- restore (getFileStatus rootDir)
 fileStat <- restore (getFileStatus (rootDir </> name))
 bytes <- restore (B.readFile (rootDir </> name))
 let ident st = Identity (toInteger (deviceID st)) (toInteger (fileID st))
     pins = [Pin (C.pack ('/':name)) (ident fileStat) Regular]
     hex n = let s = showHex n "" in if length s == 1 then '0':s else s
     digest = C.pack (concatMap hex (B.unpack (SHA.hash bytes)))
 result <- restore $ withRoot (C.pack rootDir) (ident rootStat) $ \root -> mask $ \restoreAcquire -> do
  -- There is no asynchronous exception window between creation and publication.
  lease <- newExecutableLease
  writeIORef cell (LeaseRetained lease)
  validated <- restoreAcquire $
   acquireExecutableLease lease root pins (C.pack name) [] (toInteger (B.length bytes)) digest UiImage
  case validated of
   Left e -> ioError (userError (show e))
   Right () -> do
    -- Both issue and publication run masked. withRoot's closing bracket has
    -- not run yet; if it later throws or returns Left, cell still owns held.
    issued <- issueReadyExecutable lease
    case issued of
     Nothing -> ioError (userError "validated fixture issuance failed")
     Just (held,_,_) -> do
      writeIORef cell (HeldRetained lease held)
      restoreAcquire postIssued
      pure held
 case result of
  Left e -> ioError (userError ("fixture root or cleanup unconfirmed: " ++ show e))
  Right held -> pure held

-- Adapter matching owner-route fixtures. The PersistentOwner is retained by
-- their separate Probe; it does not confer raw Owner or process authority here.
retainedSupplier :: FixtureGuard -> FilePath -> FilePath -> PersistentOwner -> IO HeldExecutable
retainedSupplier guard rootDir name _ = validatedRetainedFixture guard rootDir name
