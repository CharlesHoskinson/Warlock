'use strict';

// Independent source-derived UX companion, NOT RUN. Root must inline this
// function into the existing literal-oracle sandbox after another author has
// supplied the named, independently transcribed reachable pending-settings
// GIVEN and prelude. None of these inputs may be captured reducer output.
// The existing runner must compare every field of each expected Model and
// each ordered Effect; the extra assertions here are not that comparison.
function buildPreferenceFeedbackCases(c) {
  const { cloneLiteral: copy, initial, NIL, bindingJson, pendingSettings } = c;
  const must = (condition, why) => { if (!condition) throw new Error('preference UX fixture: ' + why); };
  must(typeof copy === 'function' && initial && NIL && bindingJson && pendingSettings,
    'independent full pendingSettings GIVEN and prelude required');
  const f = pendingSettings;
  must(Array.isArray(f.prelude) && f.prelude.length > 0 && f.given && f.givenEffects,
    'independent nonempty prelude and full given/effects required');
  must(typeof f.requestId === 'string' && /^[1-9][0-9]*$/.test(f.requestId),
    'fixed canonical positive request identity required');
  must(f.unknown && f.unknown.state && f.unknown.effects,
    'independently authored full Unknown state and effects required');
  const desktop = f.given.controller.a.controller.a.desktop;
  const setting = desktop.settings;
  must(desktop.settingsOpen === true && desktop.settingsExpected.$ === 'Nothing', 'open loaded settings required');
  must(setting.pending.$ === 'Just' && setting.pending.a.request.a === f.requestId,
    'exact pending write request required');
  must(setting.outcome.$ === 'Nothing' && setting.notice === 'Saving settings…',
    'literal pending feedback required');
  const packetOf = effects => {
    must(effects.$ === '::' && effects.a.$ === 'Publish' && effects.b.$ === '[]',
      'exact sole full Publish effect required');
    return effects.a.a.a;
  };
  const pendingPacket = packetOf(f.givenEffects);
  const pendingFrame = pendingPacket.projection.frame;
  must(pendingFrame.mode === 'settings' && pendingFrame.status ===
    'Saving settings… · ' + desktop.shortcutPreferences.notice, 'literal current pending status required');
  const one = (rows, id) => {
    const matches = rows.filter(row => row.id === id);
    must(matches.length === 1, 'unique control ' + id + ' required');
    return matches[0];
  };
  const save = one(pendingFrame.popup, 'settings:save');
  const refresh = one(pendingFrame.popup, 'settings:refresh');
  must(save.label === 'Save settings' && save.ariaLabel === 'Save settings' && !save.enabled,
    'pending save disabled and named');
  must(refresh.label === 'Refresh settings' && refresh.ariaLabel === 'Refresh settings' && refresh.enabled,
    'read-only recovery remains reachable');
  must(Array.isArray(pendingPacket.focus), 'complete focus list required');
  const unknownDesktop = f.unknown.state.controller.a.controller.a.desktop;
  const unknownSettings = unknownDesktop.settings;
  must(unknownSettings.pending.$ === 'Just' && unknownSettings.pending.a.request.a === f.requestId,
    'Unknown retains exact pending write');
  must(unknownSettings.outcome.$ === 'Just' && unknownSettings.outcome.a.result.$ === 'Unconfirmed',
    'Unknown outcome remains explicitly unconfirmed');
  must(unknownSettings.notice === 'Settings save not confirmed. Refresh to read the stored values; this write will not be repeated.',
    'literal Unknown guidance');
  const unknownPacket = packetOf(f.unknown.effects);
  must(unknownPacket.projection.frame.status === unknownSettings.notice + ' · ' + unknownDesktop.shortcutPreferences.notice,
    'Unknown visible status matches retained guidance');
  must(one(unknownPacket.projection.frame.popup, 'settings:save').enabled === false,
    'Unknown does not re-enable repeat write');
  must(Array.isArray(unknownPacket.requests) && unknownPacket.requests.length === 0 &&
    Array.isArray(unknownPacket.focus) && unknownPacket.focus.length === 0,
    'Unknown emits no write and does not move focus');
  const input = status => ({ kind: 'incoming', value: { bridgeProtocol: 1, kind: 'native-event', payload: {
    protocolVersion: 3, kind: 'shell-settings-outcome', binding: copy(bindingJson),
    requestId: f.requestId, status, snapshot: null,
  } } });
  const reset = { input: { kind: 'reset' }, expected: { state: copy(initial), effects: copy(NIL) } };
  const setup = { input: { kind: 'prelude', values: copy(f.prelude) }, setupTimers: f.setupTimers,
    expected: { state: copy(f.given), effects: copy(f.givenEffects) } };
  must(Number.isInteger(f.setupTimers) && f.setupTimers >= 0, 'setup timer count required');
  const cases = [
    ['unsupported-name', 'Bogus'], ['wrong-case', 'saved'], ['empty-status', ''],
    ['wrong-domain-stored', 'Stored'], ['null-status', null], ['numeric-status', 1],
  ].map(([suffix, status]) => ({ name: 'ux-pending-settings-malformed-' + suffix,
    steps: [copy(reset), copy(setup), { input: input(status),
      expected: { state: copy(f.given), effects: copy(NIL) } }] }));
  const missing = input('Unknown');
  delete missing.value.payload.status;
  const extra = input('Unknown');
  extra.value.payload.unexpected = true;
  for (const [suffix, malformed] of [['missing-status', missing], ['extra-field', extra]]) {
    cases.push({ name: 'ux-pending-settings-malformed-' + suffix, steps: [copy(reset), copy(setup),
      { input: malformed, expected: { state: copy(f.given), effects: copy(NIL) } }] });
  }
  cases.push({ name: 'ux-pending-settings-valid-unknown-is-distinct', steps: [copy(reset), copy(setup),
    { input: input('Unknown'), expected: { state: copy(f.unknown.state), effects: copy(f.unknown.effects) } }] });
  return cases;
}

module.exports = buildPreferenceFeedbackCases;
