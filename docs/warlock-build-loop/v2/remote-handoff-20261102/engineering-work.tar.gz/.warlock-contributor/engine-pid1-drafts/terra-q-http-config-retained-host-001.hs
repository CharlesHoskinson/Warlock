-- QA ONLY; compile in the isolated normal config-stop overlay build.
-- Root owns the process, the external guardian and the original QA deadline.
-- RetainedCase roots must stay in this SAME process after every outcome; do not
-- exit, freeStablePtr, kill a worker or clear global hooks on Unknown.
module QHttpConfigRetainedHost (Roots,newRoots,runHosted) where

import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Data.IORef (IORef,atomicModifyIORef',newIORef)
import Foreign.StablePtr (StablePtr,newStablePtr)
import qualified QHttpConfigStopControls as Control

newtype Roots = Roots (IORef [StablePtr Control.Case])
newRoots :: IO Roots
newRoots = Roots <$> newIORef []

-- A distinct Case is created per campaign and is strongly rooted BEFORE the
-- first Store action or test worker can start. Modes are serialized: the QA
-- source overlay intentionally has one process-global injection hook.
runHosted :: Roots -> Control.Mode -> FilePath -> IO (Either SomeException ())
runHosted (Roots roots) mode path = mask $ \restore -> do
  retained <- Control.newCase
  root <- newStablePtr retained
  -- If publishing fails the StablePtr remains allocated, and no test work has
  -- begun. No cleanup authority is inferred from an allocation exception.
  atomicModifyIORef' roots (\old -> (root:old,()))
  outcome <- try (restore (Control.runCase retained mode path))
  case outcome of
    Left problem -> case fromException problem :: Maybe SomeAsyncException of
      Just _ -> throwIO problem
      Nothing -> pure (Left problem)
    Right () -> pure (Right ())
