# Wave `20261101T234839Z` Source-Bound Verification: `Owner`/`WebKit`/`Mvp` Reload Non-Recovery & Post-`ELM-TEA-001` GUI State-Feedback Review (`gemini-gui`)

- **Role / Identity**: `gemini-gui` (`did:key:z6Mkrcc8RjEN24HqB6sSQoRcsSxfHrM8RWjMbAURibZF1Erc`)
- **Run / Wave / Cutoff**: `warlock-20261031-setup` · wave `20261101T234839Z` · cutoff `2026-11-02T00:44:39.475587+00:00`
- **Repository Baseline**: `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f` (whole original `ELM-TEA-001` `tea-typed-model` independently accepted on immutable source `bdeac73491a05d6c61932642b184c20b44f0e80e`; canonical counts **`18/242` whole requirements** and **`42/417` scenarios**; `nativeAcceptance: false`, `guiAcceptance: false`, `releaseAccepted: false`, `nativeOperations: []`, `HOSTSTOP2` preserved; both `typed-model-live-20261102.json` unforced `launcherExit: 1` / retired-cgroup `FileNotFoundError` at `28.05s` and historical `cancel-query-20261101` forced `-9` at `27.88s` preserved; zero canonical edits, zero compiler/Quint/Node/browser/VM/native execution by worker).

---

## 1. Two-Seam `Owner`/`/events` + `WebKit`/`Mvp` Reload-Bootstrap Route Verification

An in-place reload of `HttpPopup` (or `HttpBar`) while `HttpMain` and `Warlock.Ui.Owner` remain alive crosses **two** distinct Haskell/Elm boundaries. Both halves fail to bootstrap `presentation` (`Nothing`):

### Seam A — HTTP / Unix-Socket `Owner` Queue (`Owner.hs:372-415`, `Policy.hs:33-53`)
- `GET /` on `Popup` or `Bar` (`Owner.hs:372-377`) increments `requests` and serves static HTML without touching `popupEvents`, `barEvents`, `controllerEvents`, `lastProjection`, or `native`.
- `GET /events` on `Popup` or `Bar` (`Owner.hs:381-383`) drains only incremental `popupEvents` / `barEvents` (`Policy.hs:46-52`); `lastProjection` (`Owner.hs:314, 396`) is write-only for `uiLastProjection` (`Mvp.readProjectedLease`) and is never re-seeded into `popupEvents` or `barEvents` on `204` or `GET /`.
- **Frozen Independent Witnesses**:
  1. `gemini-gui-ui-origin-popup-reload-gap-witness-2323.patch` (`sha256:a2b578374d9483d7b9b50bb6a8c8fc90e3d6426431f495b91a1522d1f6def14f`, `4761` bytes; `test-ui-origin/Main.hs` `0b0f1780…` -> `9cc08557…`).
  2. `sol-ui-document-no-bootstrap-2324.patch` (`sha256:0134e6b174069f93152b1eda07d84ea72f7f581521bfe25c13d865202a0a3070`, `3973` bytes; layers cleanly `9cc08557…` -> `f37e9447…`).
  - *Execution-budget note for Root*: Stacking `a2b57837…` + `0134e6b1…` adds `18 + 20 = 38` local Unix/loopback HTTP round-trips per `exerciseOwner` call (`76` total across `Ordinary` + `RetireThrows`) inside `test-ui-origin/Main.hs:664`'s `5_000_000 µs` (`5s`) monotonic deadline.

### Seam B — GTK / WebKit `loadReady` Gate -> Pure `Mvp.advanceMvpState` (`WebKit.hs:442-467`, `Mvp.hsc:414-491`)
- Previously, `Warlock.Ui.Mvp.advanceMvpState` (`Mvp.hsc:29, 414`) had **zero** unit tests in `implementation/warlock/haskell/`.
- On a subview `load-changed` cycle (`WebKit.hs:442-447`), `startedEvent` sets `loadReady = False` with **zero** `ownerEvent` callback, and `finishedEvent` restores `loadReady = True` (if `navigationAllowed origin uri`) with **zero** `ownerEvent` callback.
- When `WebKit.hs:465-467` resumes `stepMvpWindow mvp (readMvpLease (uiLastProjection endpoints)) ownerEvent` on the next `1 ms` main-context tick, `Mvp.hsc:433-491` enters `(TopologyMapped scopeId gen prevMon, ViewMapped surf _ curMon)`:
  - With unchanged monitor (`curMon == prevMon`), unchanged surface size (`surf == prevSurf`), `closeNow == False`, and `escapePressed == False`, `advanceMvpState` returns `Right (st, [])` whether the committed lease is `Nothing`, closed (`popupOpen == False`), or open (`popupOpen == True`)!
  - Because zero `TrustedOwnerEvent`s (`OwnerTopology`, `OwnerReflow`, `OwnerEscape`, `OwnerDismiss`) enter `controllerEvents`, `HttpMain` receives `204` and never issues a fresh `POST /commit`.
- **Frozen Minimal Pure Fixture Draft**:
  - `.warlock-contributor/engine-pid1-drafts/gemini-gui-webkit-mvp-reload-steady-state-2352.patch` (`sha256:e76981b3484a4148f52fc28e2ecd2edb899f1517a9cd454d04a1d1255a0f4a09`, `7404` bytes)
  - Target: `implementation/warlock/haskell/runtime/test-ui-webkit/Main.hs` (`03f6e7e341690b68b174db411182cbb5fa4ae0e099ec38f8c3a32f473998b2f2` -> `d0e8c8ab16fe2ab3308f7e1a40532e9edb94032247d531ce5a1a20651bcc3536`, verified `git apply --check --verbose` zero-offset at `HEAD af1bf0efe`).
  - Pure, zero-GTK, zero-fork, `-Wall -Werror -Wcompat -Wincomplete-uni-patterns -Wincomplete-record-updates` clean: verifies initial map `OwnerTopology` (`scope = (1,1)`), zero-event steady-state post-reload ticks across `Nothing` / closed / open `SurfaceLease`, and positive contrast controls (`OwnerReflow` + dedupe, `OwnerEscape` + dedupe, monitor-shift `OwnerTopology`, GTK `ViewUnmapped` `OwnerDismiss` + empty `OwnerTopology`, and fresh remap `scope = (2,1)`).
  - *Peer byte review (`terra-q-http` `01M6CS61TQCMHKRWS8HXHDZAVW` & `01M6CS6P06116Y3A3K8SPCVR5B`)*: Concurred on all `Mvp.hsc` branches and scope/lease/revision encoders, and confirmed that `terra-q-http-explicit-reload-2244.qnt` (`sha256:1c02726535732377dd676e94486bebf0f8b8388a0c1689a510cc70c27fdd4f2c`) assumes a valid `LiveFresh` field as an environmental premise rather than proving single-popup reload bootstrap. Scope restriction: `e76981b3…` is an unrun pure state-transition control over synthetic `ViewObservation` values proving no new `Mvp`-derived `TrustedOwnerEvent` under those conditions (not a live WebKit `load-changed` execution or universal zero-`POST` proof under concurrent controller activity); Root owns execution.

### Stopped-Alert Copy & Recovery CTA Boundary (`HttpPopup.elm:96`, `HttpBar.elm:60`, `ui-http.cjs:605`)
- `HttpPopup.elm:96` (`e814d56f…`) and `HttpBar.elm:60` (`74d4b6b8…`) currently render `<div role="alert">... ++ " Restart this view to reconnect."</div>` (asserted literally at `implementation/warlock/qa/ui-http.cjs:605`).
- Under current `Owner.hs` + `WebKit.hs` + `Mvp.hsc`, restarting/reloading a single view (`window.location.reload()`) clears the alert but leaves `presentation == Nothing` (blank `<div></div>` on `HttpPopup`, placeholder on `HttpBar` if `2f742fef…`/`852b18b6…` is adopted) until a fresh `POST /commit` occurs or the whole UI session restarts.
- **Disposition**: Keep `gemini-gui-http-popup-failure-style-reload-bundle-da32-2245.patch` (`04b7cb38…`) **unadopted**; keep zero automatic `POST` replay; if Root later adopts style-only `gemini-gui-http-popup-failure-style-only-bundle-cd25-2252.patch` (`41eb9bc4…`) or updates stopped-alert copy (`"Restart Warlock UI to reconnect."` + corresponding `ui-http.cjs:605` expectation), gate any `Reload view` CTA on a reviewed host-supervised `Owner` reload-reseed mechanism.

---

## 2. Accepted `ELM-TEA-001` 3-Clause Verification & Post-`af1bf0efe` GUI State-Feedback Slices

### 2.1 Committed `ELM-TEA-001` (`bdeac7349` / `af1bf0efe`) 3-Clause GUI Verification (`CONCUR`)
Verified committed `HEAD af1bf0efeb195a9ac9e9664547d695967b41111f` (`sourceRevision` `bdeac73491a05d6c61932642b184c20b44f0e80e`):
- `implementation/warlock/src/SystemMenu.elm`: `070e619f3088a1c051581066ce949fb1cd64b75f5df0ebd9efb18ab589c993c5`
- `implementation/warlock/src/Surface.elm`: `a6c9f976b4705142e88f010d8e3c0fa9338004b74878392179d75d01117b639e`
- `implementation/warlock/src/SurfaceRenderer.elm`: `58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e`
- `implementation/warlock/src/UiHttp.elm`: `a41b32a054031bf5f99cc920450cffe01ad82362729a4af1450b05aa99507172`
- `implementation/warlock/qa/SystemMenuReplay.elm`: `9ffa00c0d0a2b4a86be91ad7aa988b46f8e2efc91b57a95900095dee97f5ba03`
- `implementation/warlock/qa/SolSystemMenuIntegratedReplay2114.elm`: `7b448580857a1dca22c0addd9e009a2da2af9c87b0fa78fff5fc79caa079ad5a`
- `implementation/warlock/qa/system-menu-typed-state.cjs`: `5bc6f3c784bbd5a6dc80a9e8c40bfc37975b2bbdd4bc853dc288e9cda5c5e158`

**3-Clause Coherence Across GUI Modules**:
1. **Clause 1 (Custom types for lifecycle, receipt, and operation state)**: `SystemMenu.SessionState = SessionClosing | OtherSessionState String`, `Launch.Phase` (`Idle | Pending String Intent | Settled Intent ResultState`), `MotionPreferences.PendingState`, `Files`/`JumpList`/`Settings`/`ShortcutPreferences` typed states, and `UiHttp` typed `Phase`/`RequestKind` leave zero raw `String` lifecycle/receipt/operation model fields.
2. **Clause 2 (Single authoritative `Desktop.Model` / `OutputController.Model` state)**: `Presentation.Model`, `Popup.Model`, and `Bar.Model` hold only monotonic `SurfaceSnapshot` projections plus local query/composition/scroll viewport state; `OutputController` + `Surface.resolve` re-verify `(publication, lease, surface, enabled)` on every action.
3. **Clause 3 (Explicit effect descriptions & single-snapshot projections)**: `HttpMain.elm` interprets `Policy.Publish` / `Policy.Delay`; `Popup.elm` interprets `Dispatch | PreviewCommand | PaintRequest`; `Bar.elm` interprets `Dispatch | ResetStatusViewport`.

### 2.2 Ready Post-`ELM-TEA-001` GUI State-Feedback Candidates (Coordinated with `terra-browser` & `terra-portable`, Zero Duplicate Style Prototype)

With `ELM-TEA-001` now independently accepted at `af1bf0efe`, all three reviewed narrow GUI state-feedback slices apply cleanly at zero offset on disjoint files (`git apply --check --verbose` verified standalone and stacked):

1. **Option A `settings:motion` Detail `aria-describedby` Association (`fc369a0f…` + Optional Chromium-AX Coexistence Supplement `ce4e0609…`)**:
   - *Gap*: In `Settings` mode, `Surface.elm:454` omits `model.motion.preferences.notice` from `contextNotice`, and `Surface.elm:196, 230` renders `settings:motion` as a `<button disabled>` (skipped by `Tab`/`ArrowDown` in `settings-browser.mjs:36-39`) whose `aria-label` omits `.detail`. When `preferences.snapshot /= Nothing` (`Motion.elm:87-89`) and `MotionPreferences.receive` transitions `Awaiting -> Unconfirmed`, the `101`-char unconfirmed-save warning appears only in `.control-detail` on disabled `settings:motion`.
   - *Primary Atomic Patch (`fc369a0f…`)*: `.warlock-contributor/engine-pid1-drafts/gemini-gui-settings-motion-describedby-0007.patch` (`sha256:fc369a0f007b4b1db14f293bda7b2664a36a9c5ccf48f036704e646a6af674cf`, `16090` bytes; `SurfaceRenderer.elm` `58119053…` -> `b187377a…`, `qa/ui-http.cjs` `cd25171a…` -> `ce9c8eab…`). Leaves `Surface.elm` / `tea-contract-cases.cjs:1590` / `settings-browser.mjs:31` untouched; allocates injective `settings-motion-detail-` DOM ID (disjoint from controls, `preview-description-*`, `settings-save-caption-*`, and `warlock-bar-status-scroll-*`) on `settings:motion`'s `.control-detail` only when `popup && snapshot.mode == "settings"` and non-empty `.detail`, and appends that token to `aria-describedby` on `settings:motion` and focusable `settings:motion:refresh`. Concurred by `terra-browser` (`01M6CSEM7HT2M9VPJNFSJQ7JX9`) and `terra-portable` (`01M6CSEJS3QYC00RSDTW5XJYVW`).
   - *Optional Chromium-AX Multi-Prefix Coexistence Supplement (`ce4e0609…`)*: `.warlock-contributor/engine-pid1-drafts/gemini-gui-settings-motion-preview-ax-coexistence-0016.patch` (`sha256:ce4e0609ced09bf204e705c29ded0edcef3fcddd056e1f8b5a0b1e368b4f5853`, `5657` bytes; `qa/preview-description-browser.mjs` `05d19ad7…` -> `c19343ce…`). Exercises `NativePreviewRenderer` + Chromium `Accessibility.getFullAXTree` on `mode: 'settings'` with `{kind: 'fallback'}` (`"Preview unavailable"`) on `settings:motion` and `settings:motion:refresh` plus simultaneous collisions across `warlock-bar-status-scroll-*`, `settings-save-caption-*`, `preview-description-*`, `settings-motion-detail-*`, and `surface-control-*`. Concurred by `terra-browser` (`01M6CSXEP3QD1SCWZ3PZQ7MQ54`). Static `aria-describedby` / AX description only; does not prove live announcement (`aria-live="off"`) or AT operation.
2. **Application-Only Disabled Launch Guidance (`terra-browser-app-only-guidance-0015.patch`, `cf567213…` — Peer Reviewed `CONCUR` in `01M6CT3BS1873ZNAVJV3G4M749`)**:
   - `.warlock-contributor/engine-pid1-drafts/terra-browser-app-only-guidance-0015.patch` (`sha256:cf56721316e93584b128bf71c24cb6ab732c4c449716ce07a81bc7f1ec370723`, `4680` bytes; `Surface.elm` `a6c9f976…` -> `e1849421…`, `StandaloneMvpReplay.elm` `0e1bb70d…` -> `8e10fc40…`, `standalone-mvp.cjs` `a43d171e…` -> `55a5595c…`).
   - Verified `model.windows.shell.applicationOnly` is the exact sole predicate disabling `entry:<id>` and `jump:open:<id>` while keeping `pin:<id>` enabled when `applications /= Nothing` and `Launch.status` is not `Pending`/`Unknown` (`Surface.elm:310-324`, `Desktop.elm:484`). Zero conflicts with `tea-contract-cases.cjs`, `FeedbackContextReplay.elm`, `ui-http.cjs`, or `fc369a0f…`/`ce4e0609…`, and live QMP `journey.json` (`Search` click on empty query, `Refresh` click after `footz` no-match) preserves mask/click coordinates on `1920x1080` fullscreen (note: `76`-char copy wraps one extra line vs `30` chars if a narrow `320px` fixed-coordinate test ever clicks below `.surface-status` on a matching `applicationOnly` query).
3. **`SystemMenu.NetworkAuth` Feedback (`terra-browser-system-auth-feedback-2246-v2.elm`, `2ed59f66…` — `CONCUR`)**:
   - Zero conflicts with the 61 policy histories (`tea-contract-cases.cjs`) or `SystemMenuReplay.elm`; ready if Root selects a `SystemMenu` copy slice.

---

## 3. Website Peer Review (`gemini-site` `2343`, `0004`, & `0011` Drafts — `CONCUR`)
- Verified `0011` bundle re-anchored to `HEAD af1bf0efeb195a9ac9e9664547d695967b41111f` (`01M6CSRHF0K78ZGRWPSXSKJ409` -> `CONCUR` in `01M6CT3BWBJT7EWSG6KCWY4CJ5`):
  - `SiteMainHeadProd0011.patch` (`sha256:d625be42f5656dd91e6d34a16fee2ef047973f69ecf19729bcd19094395dee43`, `69517` bytes vs `HEAD:site/src/SiteMain.elm` `9c432ddf…`), `SiteMainHeadProd0011.elm` (`sha256:df5d79c426ec41e132e27a911217fbb68156bfca50494e36dcec7d4b9350b3bb`, `107778` bytes), `SiteMainProd0004To0011HeadAf1bfDelta.patch` (`sha256:958cd921f26fb8eb3ce4d453ae6767588cb3e73be14bbd019daeca75a2d9735e`, `21965` bytes), `site-browser-acceptance-homepage-0011.patch` (`sha256:3af01ddb8e1d6150f3d34d7be2a52e9dd114b3a24007f67edb85b2a37797fad5`, `8204` bytes), `SiteMainHeadFixture0011.elm` (`sha256:b262fba276218530e743462c71522099d88845016aa4ab446baebbe5c4fde3d5`, `17953` bytes), `site-head-mvp-usability-qa-0011.cjs` (`sha256:96586609b386060f4972eb8e7b755188c90522afcc7a6424ed98554e32764c99`, `28220` bytes), and `gemini-site-frozen-website-manifest-0011.json` (`sha256:16e0d78b93c66b8b6e2aeaa91402cfc2050ab46aa5bab3e3bb59b5c5528bd976`, `28983` bytes).
  - Accurately reports `18/242` whole requirements and `42/417` scenarios (`ELM-TEA-001` accepted on `bdeac7349`), preserves both the `28.05s` unforced `launcherExit: 1` (`FileNotFoundError` retired-cgroup stamp) and `27.88s` forced `-9` histories, and leaves foreign dirty `site/src/SiteMain.elm` (`f05a3768…`) untouched.

---

## 4. Late-Wave Backend Diagnostic Literals (`sol-docs` `1ebee0ff`) & `00:35:20Z` Tiled-Bar Geometry Sync (`CONCUR`)
- **`sol-backend-diagnostic-literals-001.patch` (`CONCUR` in `01M6CTBP4P8SKPP74BNMGWE05S`)**:
  - Verified `.warlock-contributor/engine-pid1-drafts/sol-backend-diagnostic-literals-001.patch` (`sha256:1ebee0ff52bb0d0df5867264d12c19e6a3f585480a3b927581cbcdccdfc6cf4f`, `10762` bytes) + `.json` (`sha256:a2e8f88eaf46bc4d74fa20ee842510a7bb8755f4b0c601ca4eae1b4b1c3d4f0d`, `3548` bytes) zero-offset against `test-ui-mvp/Main.hs` (`7368f881…` -> `f9351931…`) and `Warlock/Backend.hs` (`641e06dc…`): `Warlock.Bootstrap` `BootstrapResult(..)` export, `-Wall -Werror` cleanliness, and all 11 complete JSON literals (`4` non-executed `null`-selected stages + `6` per-owner retirement tags + `ordered-independent-failures` preserving `checks` array order and redacting synthetic `Left` text).
- **`00:35:20Z` `backend-private-diagnostics-20261102.json` & `621x750` Tiled Bar Clip Sync (`01M6CV2WD50Y9V4QP6RPCHJEBM`)**:
  - Verified `backend-diagnostics.json` (`sha256:130d183111011d6d8de3bb72863b980372b52c2c497329aa42c35e71757d5181`) isolates `selectedOperationSucceeded = false` (`{"code":"unsuccessful","exitCode":1}` on `selectedPid: 164093`, with 6 other checks `true` and 3/3 retirements `"confirmed"`), while `EngineResult` `false/false` fence and `qaCleanupError: "FileNotFoundError"` (`qaScopeInventoryConfirmedEmpty: false`) remain distinct (`18/242` whole, `42/417` scenarios unchanged).
  - Verified `SurfaceTheme.elm:301-353` on `621x750` 50/50 tiled captures (`f4592ae9…` / `45fdb5bf…` / `c99c360e…`): `barStatusStyles` (`flex: 0 0 clamp(180px, 40vw, 360px)` = `248.4px` when non-idle) leaves `~372.6px` for `barActionsStyles` (`overflow-x: auto; flex-wrap: nowrap`), clipping `bar:notifications`, `bar:files`, `bar:system`, and `bar:settings` visually at rest without an overflow scroll cue (though keyboard `Home`/`End`/arrow reveal remains covered in `dense-taskbar-browser.mjs`).
