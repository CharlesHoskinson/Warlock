{-# LANGUAGE OverloadedStrings #-}
-- Candidate persistent application MVP positive & negative controls (r3,
-- unexecuted by worker; Root alone compiles and executes under protected QA).
-- Exercises Warlock.Backend (055..058 + 062 + 063 + 066 + 067) +
-- Warlock.Bootstrap (r8) + Warlock.Capture.Process.Persistent (r17-postwait +
-- exit-on-owner-origin) directly against the real independently-pinned
-- ui-stream-child executable without inventing a CLI host StopBudget policy:
--   1. Positive multi-frame persistent session: attachment once + catalog +
--      pin write across 4 commits, verifying LeaderExitUnobserved pre-run,
--      (4, 2) counts, DeliveryCompleted WrittenLocally, LeaderReaped,
--      persistentBackendLeaderExit == LeaderExitObserved ExitSuccess,
--      natural-exit retirement (once + idempotent) without explicit stop,
--      and persisted taskbar.json.
--   2. Restart persistence: fresh PersistentBackendOwner reads persisted
--      revision "2" without replay, observes LeaderExitObserved ExitSuccess,
--      and retires cleanly.
--   3. LaunchReady unstarted direct retirement (Portable 062+063+066):
--      load config -> requestPersistentBackendStop twice (StopLatchedBeforeLive)
--      -> retirePersistentBackend directly without runPersistentBackend returns
--      True (once + idempotent), LeaderExitUnobserved, and subsequent
--      runPersistentBackend throws IOException "persistent backend owner already used".
--   4. LaunchFresh unstarted direct retirement: fresh owner, no config ->
--      requestPersistentBackendStop (StopLatchedBeforeLive) ->
--      retirePersistentBackend == True -> subsequent loadPersistentBackendConfig
--      returns Left "persistent config owner already used" and subsequent
--      runPersistentBackend throws IOException "persistent owner has no verified config".
--   5. Pre-live stop + runPersistentBackend startup refusal: load config ->
--      requestPersistentBackendStop -> runPersistentBackend returns
--      StartupAdmissionRefused SessionClosed, (0, 0), DeliveryNotAttempted,
--      LeaderExitUnobserved -> retirePersistentBackend == True.
--   6. Expired StopBudget before unstarted retirement (Portable 066
--      invalidateUnstarted): 15ms StopBudget, load config, StopLatchedBeforeLive,
--      30ms delay -> retirePersistentBackend == False (sticky False on repeat),
--      and subsequent runPersistentBackend throws IOException
--      "persistent backend owner already used".
--   7. Settled missing-config refusal retiring cleanly via unbound root seal
--      with LeaderExitUnobserved.
--   8. 21 deterministic hostile codec/boundary whole-frame rejection cases
--      (3 each across 7 classes: shell-command, window-effect, mismatched
--      binding, bad protocolVersion, trailing field, proposal path escape,
--      duplicate JSON key) refusing before ANY domain callback ((0, 0) counts,
--      DeliveryNotAttempted, retire == True, sentinel absent, pins unchanged).
--   9. Callback-level duplicate requestId rejection: handler rejects whole
--      frame before attachment/domain IO ((1, 0) counts, DeliveryNotAttempted,
--      PersistentBootstrapUncertain, fail-closed retire == False, sentinel
--      absent, pins unchanged).
--  10. Nonzero child exit (exitCode = 23) synthetic stderr injection control:
--      verifies child flushed all three WARLOCK_SYNTHETIC_* markers to
--      .stderr-injected, observed LeaderReaped, observed exact same-handle
--      persistentBackendLeaderExit == LeaderExitObserved (ExitFailure 23),
--      and retired cleanly.
module GeminiOmarchyPersistentAppMvpControlsR3_052418Z
 ( runPersistentAppMvpControls ) where

import Control.Concurrent (threadDelay)
import Control.Exception (IOException, try)
import Control.Monad (forM_, unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.IORef (modifyIORef', newIORef, readIORef)
import Data.List (sortOn)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import GHC.Clock (getMonotonicTimeNSec)
import Numeric (showHex)
import System.Directory (createDirectory, doesPathExist, listDirectory)
import System.Exit (ExitCode(..))
import System.FilePath ((</>), takeDirectory)
import System.IO.Error (ioeGetErrorString)
import System.Posix.Files (deviceID, fileID, getSymbolicLinkStatus, isRegularFile, setFileMode)
import System.Timeout (timeout)
import Warlock.Backend
 ( DirectoryPin(..)
 , PersistentBackendRun
 , PersistentDelivery(..)
 , loadPersistentBackendConfig
 , newPersistentBackendOwner
 , persistentBackendCounts
 , persistentBackendDelivery
 , persistentBackendLeaderExit
 , persistentBackendOutcome
 , persistentBackendStartupRefusal
 , requestPersistentBackendStop
 , retirePersistentBackend
 , runPersistentBackend
 )
import Warlock.Bootstrap (PersistentBootstrapResult(..), newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as Persistent
import Warlock.Protocol.CredentialIngress (PersistentSendResult(..))
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (Counter, binding, parseCounter)
import qualified Warlock.Protocol.StrictJson as J

counter :: T.Text -> Counter
counter = either (error . show) id . parseCounter False

shaHex :: B.ByteString -> String
shaHex = concatMap (\byteVal -> let hexDigits = showHex byteVal "" in replicate (2 - length hexDigits) '0' ++ hexDigits) . B.unpack . SHA.hash

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

within :: String -> IO a -> IO a
within label action = timeout 10000000 action >>= maybe (ioError (userError (label ++ ": timed out"))) pure

encoded :: J.Json -> B.ByteString
encoded = TE.encodeUtf8 . J.renderJson

obj :: [(T.Text, J.Json)] -> J.Json
obj = J.JObject

txt :: String -> J.Json
txt = J.JString . T.pack

canonicalJson :: J.Json -> J.Json
canonicalJson (J.JObject pairs) = J.JObject (sortOn fst [(k, canonicalJson v) | (k, v) <- pairs])
canonicalJson (J.JArray items) = J.JArray (map canonicalJson items)
canonicalJson atomVal = atomVal

bindingValue :: J.Json
bindingValue = obj
 [ ("lifetime", txt "9007199254740993")
 , ("session", txt "9007199254740995")
 , ("frontend", txt "9007199254740997")
 ]

closedProjection :: J.Json
closedProjection = obj
 [ ("viewProtocol", J.JNumber "1")
 , ("kind", txt "view-frame")
 , ("revision", txt "1")
 , ("views", J.JArray [])
 , ("focusOwner", J.JNull)
 , ("popupOwner", J.JNull)
 , ("frame", obj
    [ ("surfaceProtocol", J.JNumber "2")
    , ("publication", txt "1")
    , ("lease", txt "0")
    , ("mode", txt "closed")
    , ("status", txt "")
    , ("bar", J.JArray [])
    , ("popup", J.JArray [])
    ])
 , ("announcer", J.JNull)
 , ("announcement", J.JNull)
 ]

requestJson :: String -> Int -> [(T.Text, J.Json)] -> J.Json
requestJson kindName reqIdentity extraFields = obj
 ( [ ("protocolVersion", J.JNumber "3")
   , ("kind", txt kindName)
   , ("binding", bindingValue)
   , ("requestId", txt (show reqIdentity))
   ] ++ extraFields )

commitBytes :: [J.Json] -> B.ByteString
commitBytes reqList = encoded $ obj
 [ ("viewProtocol", J.JNumber "1")
 , ("kind", txt "view-commit")
 , ("projection", closedProjection)
 , ("requests", J.JArray reqList)
 , ("focus", J.JArray [])
 ]

proposalJson :: String -> [String] -> J.Json
proposalJson revText identList = obj
 [ ("revision", txt revText)
 , ("identities", J.JArray (map txt identList))
 ]

pinDirectory :: FilePath -> IO DirectoryPin
pinDirectory dirPath = do
 statVal <- getSymbolicLinkStatus dirPath
 pure (DirectoryPin dirPath (toInteger (deviceID statVal)) (toInteger (fileID statVal)))

directoryJson :: DirectoryPin -> J.Json
directoryJson pinVal = obj
 [ ("path", txt (directoryPath pinVal))
 , ("device", txt (show (directoryDevice pinVal)))
 , ("inode", txt (show (directoryInode pinVal)))
 ]

freshDir :: FilePath -> IO FilePath
freshDir dirPath = createDirectory dirPath >> setFileMode dirPath 0o700 >> pure dirPath

writePrivate :: FilePath -> B.ByteString -> IO ()
writePrivate filePath rawBytes = B.writeFile filePath rawBytes >> setFileMode filePath 0o600

pinImage :: FilePath -> IO [String]
pinImage exePath = do
 statVal <- getSymbolicLinkStatus exePath
 rawBytes <- B.readFile exePath
 unless (isRegularFile statVal) (ioError (userError "nonregular trusted QA executable"))
 pure [show (deviceID statVal), show (fileID statVal), show (B.length rawBytes), shaHex rawBytes]

atField :: T.Text -> J.Json -> J.Json
atField fieldName (J.JObject pairs) = maybe J.JNull id (lookup fieldName pairs)
atField _ _ = J.JNull

expectIoErrorMessage :: String -> IO PersistentBackendRun -> IO Bool
expectIoErrorMessage expectedMsg action = do
 outcome <- try action :: IO (Either IOException PersistentBackendRun)
 pure $ case outcome of
  Left ioErr -> ioeGetErrorString ioErr == expectedMsg
  Right _ -> False

runPersistentAppMvpControls
 :: FilePath -> [String] -> FilePath -> [String] -> FilePath -> IO Int
runPersistentAppMvpControls backendExe backendPins childExe childPins suiteRoot = do
 actualBackend <- pinImage backendExe
 actualChild <- pinImage childExe
 unless (actualBackend == backendPins && actualChild == childPins)
  (ioError (userError "independent executable pins differ"))
 (cDev, cIno, cSize, cSha) <- case childPins of
  [d0, d1, d2, d3] -> pure (d0, d1, d2, d3)
  _ -> ioError (userError "expected 4 child pin components")
 checksRun <- newIORef (0 :: Int)
 let check label good = do
      modifyIORef' checksRun (+ 1)
      unless good (ioError (userError label))
     makeSub subName = freshDir (suiteRoot </> subName)
 existingEntries <- listDirectory suiteRoot
 check "fresh private persistent MVP root" (null existingEntries)
 applicationsDir <- makeSub "applications"
 pinsDir <- makeSub "pins"
 let sentinelPath = suiteRoot </> "must-not-spawn"
 writePrivate (applicationsDir </> "alpha.desktop")
  (C.pack ("[Desktop Entry]\nType=Application\nName=Alpha\nExec=/bin/sh -c 'touch " ++ sentinelPath ++ "'\n"))
 writePrivate (applicationsDir </> "beta.desktop")
  "[Desktop Entry]\nType=Application\nName=Beta\nExec=/bin/true\n"
 catalogPin <- pinDirectory applicationsDir
 storagePin <- pinDirectory pinsDir
 let parentDirs = reverse (takeWhile (/= "/") (iterate takeDirectory (takeDirectory childExe)))
 ancestorPins <- mapM pinDirectory parentDirs
 testStopBudget <- must (Persistent.stopBudgetMicros 5000000)
 let expectedBinding = either (error . show) id
      (binding (counter "9007199254740993") (counter "9007199254740995") (counter "9007199254740997"))
     expectedAttachmentEnvelope = obj
      [ ("bridgeProtocol", J.JNumber "1")
      , ("kind", txt "native-event")
      , ("payload", obj
         [ ("protocolVersion", J.JNumber "3")
         , ("kind", txt "application-attached")
         , ("binding", bindingValue)
         , ("nativeOperations", J.JArray [])
         ])
      ]
     buildConfig scriptFile repliesFile deadlineNs attachOptIn =
      let baseFields =
           [ ("schema", J.JNumber "1")
           , ("binding", bindingValue)
           , ("deadlineMonotonicNs", txt (show deadlineNs))
           , ("ui", obj
              [ ("path", txt childExe)
              , ("device", txt cDev)
              , ("inode", txt cIno)
              , ("size", txt cSize)
              , ("sha256", txt cSha)
              , ("arguments", J.JArray [txt scriptFile, txt repliesFile])
              , ("ancestors", J.JArray (map directoryJson ancestorPins))
              ])
           , ("catalogRoots", J.JArray [directoryJson catalogPin])
           , ("pinsRoot", directoryJson storagePin)
           , ("locale", txt "C")
           ]
      in obj (if attachOptIn then ("applicationAttachment", J.JBool True) : baseFields else baseFields)
     framesJson exitCodeOpt frameRows =
      let baseRows =
           [ ("schema", J.JNumber "1")
           , ("frames", J.JArray
              [ obj
                 [ ("wire", J.JString (TE.decodeUtf8 wireBytes))
                 , ("replies", J.JNumber (T.pack (show replyCnt)))
                 , ("refused", J.JBool isRefused)
                 ]
              | (wireBytes, replyCnt, isRefused) <- frameRows
              ])
           ]
      in obj (case exitCodeOpt of
          Nothing -> baseRows
          Just ec -> baseRows ++ [("exitCode", J.JNumber (T.pack (show ec)))])
     prepareCase caseLabel attachOptIn exitCodeOpt frameRows = do
      caseDir <- makeSub caseLabel
      let scriptFile = caseDir </> "script.json"
          repliesFile = caseDir </> "replies.json"
          configFile = caseDir </> "startup.json"
      writePrivate scriptFile (encoded (framesJson exitCodeOpt frameRows))
      nowNs <- getMonotonicTimeNSec
      writePrivate configFile (encoded (buildConfig scriptFile repliesFile (toInteger nowNs + 5000000000) attachOptIn))
      pure (configFile, repliesFile)
     readReplyFrames repliesFile = do
      rawBytes <- B.readFile repliesFile
      limits <- must (J.bounds (8 * 1024 * 1024) 16)
      decodedTree <- must (J.decodeStrict limits rawBytes)
      case decodedTree of
       J.JArray items -> mapM (\itemVal -> case itemVal of
        J.JString frameText -> pure (TE.encodeUtf8 frameText)
        _ -> ioError (userError "reply log entry must be string")) items
       _ -> ioError (userError "reply log must be JSON array")
     decodeJson rawBytes = do
      limits <- must (J.bounds 65536 16)
      must (J.decodeStrict limits rawBytes)

 -- 1. Positive persistent session: attachment once + catalog + pin write + natural exit + ExitSuccess.
 (posCfg, posReplies) <- prepareCase "persistent-positive" True Nothing
  [ (commitBytes [], 1 :: Int, False)
  , (commitBytes [], 0 :: Int, False)
  , (commitBytes [requestJson "catalog-request" 2 []], 1 :: Int, False)
  , (commitBytes [requestJson "taskbar-pins-write" 3 [("proposal", proposalJson "1" ["alpha"])]], 1 :: Int, False)
  ]
 posSessions <- newCurrentSessions
 posOwner <- newPersistentBackendOwner posSessions testStopBudget
 posExitBefore <- persistentBackendLeaderExit posOwner
 check "positive persistent leader exit unobserved before run"
  (posExitBefore == Persistent.LeaderExitUnobserved)
 posLoaded <- within "positive config load" (loadPersistentBackendConfig posOwner posCfg)
 check "positive persistent config loaded" (posLoaded == Right ())
 posRun <- within "positive persistent run" (runPersistentBackend posOwner)
 posDelivery <- persistentBackendDelivery posOwner
 posExitAfter <- persistentBackendLeaderExit posOwner
 check "positive persistent counts, delivery, and ExitSuccess observation"
  ( persistentBackendCounts posRun == (4, 2)
  && persistentBackendStartupRefusal posRun == Nothing
  && posDelivery == DeliveryCompleted WrittenLocally
  && posExitAfter == Persistent.LeaderExitObserved ExitSuccess
  )
 check "positive persistent observed LeaderReaped"
  (case persistentBackendOutcome posRun of
    Right (PersistentBootstrapObserved (Right (_, Persistent.LeaderReaped _))) -> True
    _ -> False)
 posRetired1 <- within "positive natural-exit retire" (retirePersistentBackend posOwner)
 posRetired2 <- within "positive natural-exit retire idempotent" (retirePersistentBackend posOwner)
 posExitPostRetire <- persistentBackendLeaderExit posOwner
 check "natural exit retires once, stays idempotent, and retains ExitSuccess"
  ( posRetired1
  && posRetired2
  && posExitPostRetire == Persistent.LeaderExitObserved ExitSuccess
  )
 posFrames <- readReplyFrames posReplies
 case posFrames of
  [attBytes, catBytes, pinBytes] -> do
   attGateway <- must (D.decodeDesktopGateway attBytes)
   attTree <- decodeJson attBytes
   catTree <- decodeJson catBytes
   pinTree <- decodeJson pinBytes
   check "first frame is authenticated application-attached"
    ( D.replyBinding attGateway == expectedBinding
    && canonicalJson attTree == canonicalJson expectedAttachmentEnvelope
    )
   check "second frame is catalog reply for requestId 2"
    ( atField "kind" (atField "payload" catTree) == txt "application-catalog"
    && atField "requestId" (atField "payload" catTree) == txt "2"
    )
   check "third frame saves taskbar pin revision 2"
    ( atField "status" (atField "payload" pinTree) == txt "Saved"
    && atField "revision" (atField "preferences" (atField "payload" pinTree)) == txt "2"
    )
  _ -> check "expected exactly 3 reply frames" False
 persistedPins <- B.readFile (pinsDir </> "taskbar.json")
 check "persisted taskbar.json matches expected content"
  (persistedPins == "{\"schema\":1,\"revision\":\"2\",\"identities\":[\"alpha\"]}")

 -- 2. Restart persistence without replay + ExitSuccess.
 (restartCfg, restartReplies) <- prepareCase "persistent-restart" False Nothing
  [(commitBytes [requestJson "catalog-request" 4 []], 1 :: Int, False)]
 restartSessions <- newCurrentSessions
 restartOwner <- newPersistentBackendOwner restartSessions testStopBudget
 restartLoaded <- within "restart config load" (loadPersistentBackendConfig restartOwner restartCfg)
 check "restart config loaded" (restartLoaded == Right ())
 restartRun <- within "restart persistent run" (runPersistentBackend restartOwner)
 restartExit <- persistentBackendLeaderExit restartOwner
 restartRetired <- within "restart retire" (retirePersistentBackend restartOwner)
 restartFrames <- readReplyFrames restartReplies
 case restartFrames of
  [firstRestartFrame] -> do
   restartTree <- decodeJson firstRestartFrame
   check "restart owner reads persisted revision 2, observes ExitSuccess, and retires cleanly"
    ( persistentBackendCounts restartRun == (1, 1)
    && restartExit == Persistent.LeaderExitObserved ExitSuccess
    && restartRetired
    && atField "revision" (atField "preferences" (atField "payload" restartTree)) == txt "2"
    )
  _ -> check "expected 1 restart frame" False

 -- 3. LaunchReady unstarted direct retirement without runPersistentBackend (Portable 062+063+066).
 (readySealCfg, _) <- prepareCase "persistent-ready-seal" False Nothing
  [(commitBytes [requestJson "catalog-request" 5 []], 1 :: Int, False)]
 readySealSessions <- newCurrentSessions
 readySealOwner <- newPersistentBackendOwner readySealSessions testStopBudget
 readySealLoaded <- within "ready-seal config load" (loadPersistentBackendConfig readySealOwner readySealCfg)
 check "ready-seal config loaded" (readySealLoaded == Right ())
 readyStop1 <- within "ready-seal first stop" (requestPersistentBackendStop readySealOwner)
 readyStop2 <- within "ready-seal duplicate stop" (requestPersistentBackendStop readySealOwner)
 check "ready-seal stop latches StopLatchedBeforeLive once"
  ( readyStop1 == Persistent.StopLatchedBeforeLive
  && readyStop2 == Persistent.StopLatchedBeforeLive
  )
 readySealRetired1 <- within "ready-seal direct retire" (retirePersistentBackend readySealOwner)
 readySealRetired2 <- within "ready-seal idempotent retire" (retirePersistentBackend readySealOwner)
 readySealExit <- persistentBackendLeaderExit readySealOwner
 readyRunRejected <- within "ready-seal post-retire run"
  (expectIoErrorMessage "persistent backend owner already used" (runPersistentBackend readySealOwner))
 check "LaunchReady unstarted owner retires directly, stays idempotent, and blocks subsequent run"
  ( readySealRetired1
  && readySealRetired2
  && readySealExit == Persistent.LeaderExitUnobserved
  && readyRunRejected
  )

 -- 4. LaunchFresh unstarted direct retirement before any config read.
 freshSealSessions <- newCurrentSessions
 freshSealOwner <- newPersistentBackendOwner freshSealSessions testStopBudget
 freshStop <- within "fresh-seal stop" (requestPersistentBackendStop freshSealOwner)
 check "fresh-seal stop latches StopLatchedBeforeLive"
  (freshStop == Persistent.StopLatchedBeforeLive)
 freshSealRetired <- within "fresh-seal direct retire" (retirePersistentBackend freshSealOwner)
 freshSealExit <- persistentBackendLeaderExit freshSealOwner
 freshLoadAfter <- within "fresh-seal load after retire"
  (loadPersistentBackendConfig freshSealOwner posCfg)
 freshRunAfter <- within "fresh-seal run after retire"
  (expectIoErrorMessage "persistent owner has no verified config" (runPersistentBackend freshSealOwner))
 check "LaunchFresh unstarted owner retires directly and refuses subsequent config load and run"
  ( freshSealRetired
  && freshSealExit == Persistent.LeaderExitUnobserved
  && freshLoadAfter == Left "persistent config owner already used"
  && freshRunAfter
  )

 -- 5. Pre-live StopLatchedBeforeLive + runPersistentBackend startup refusal.
 (preStopCfg, _) <- prepareCase "persistent-prelive-stop" False Nothing
  [(commitBytes [requestJson "catalog-request" 6 []], 1 :: Int, False)]
 preStopSessions <- newCurrentSessions
 preStopOwner <- newPersistentBackendOwner preStopSessions testStopBudget
 preStopLoaded <- within "pre-stop config load" (loadPersistentBackendConfig preStopOwner preStopCfg)
 check "pre-stop config loaded" (preStopLoaded == Right ())
 stopReceipt1 <- within "pre-stop first stop" (requestPersistentBackendStop preStopOwner)
 stopReceipt2 <- within "pre-stop duplicate stop" (requestPersistentBackendStop preStopOwner)
 check "central stop state latches once and reuses StopLatchedBeforeLive"
  ( stopReceipt1 == Persistent.StopLatchedBeforeLive
  && stopReceipt2 == Persistent.StopLatchedBeforeLive
  )
 preStopRun <- within "pre-stop run" (runPersistentBackend preStopOwner)
 preStopDelivery <- persistentBackendDelivery preStopOwner
 preStopExit <- persistentBackendLeaderExit preStopOwner
 check "pre-stop run refuses with SessionClosed, DeliveryNotAttempted, and LeaderExitUnobserved"
  ( persistentBackendStartupRefusal preStopRun == Just (Persistent.StartupAdmissionRefused SessionClosed)
  && persistentBackendCounts preStopRun == (0, 0)
  && preStopDelivery == DeliveryNotAttempted
  && preStopExit == Persistent.LeaderExitUnobserved
  )
 preStopRetired <- within "pre-stop retire" (retirePersistentBackend preStopOwner)
 check "pre-stop owner retires cleanly via sealUnusedRootCustody + finishPersistentBootstrapPreLive" preStopRetired

 -- 6. Expired StopBudget before unstarted retirement (Portable 066 invalidateUnstarted).
 (expiredCfg, _) <- prepareCase "persistent-expired-stop" False Nothing
  [(commitBytes [requestJson "catalog-request" 7 []], 1 :: Int, False)]
 shortStopBudget <- must (Persistent.stopBudgetMicros 15000)
 expiredSessions <- newCurrentSessions
 expiredOwner <- newPersistentBackendOwner expiredSessions shortStopBudget
 expiredLoaded <- within "expired-stop config load" (loadPersistentBackendConfig expiredOwner expiredCfg)
 check "expired-stop config loaded" (expiredLoaded == Right ())
 expiredStopReceipt <- within "expired-stop latch" (requestPersistentBackendStop expiredOwner)
 check "expired-stop latched StopLatchedBeforeLive"
  (expiredStopReceipt == Persistent.StopLatchedBeforeLive)
 threadDelay 30000
 expiredRetired1 <- within "expired-stop retire 1" (retirePersistentBackend expiredOwner)
 expiredRetired2 <- within "expired-stop retire 2" (retirePersistentBackend expiredOwner)
 expiredExit <- persistentBackendLeaderExit expiredOwner
 expiredRunRejected <- within "expired-stop post-invalidate run"
  (expectIoErrorMessage "persistent backend owner already used" (runPersistentBackend expiredOwner))
 check "expired pre-live StopD invalidates unstarted launch and keeps retirement sticky False"
  ( not expiredRetired1
  && not expiredRetired2
  && expiredExit == Persistent.LeaderExitUnobserved
  && expiredRunRejected
  )

 -- 7. Settled missing-config refusal retiring cleanly via unbound root seal.
 missingSessions <- newCurrentSessions
 missingOwner <- newPersistentBackendOwner missingSessions testStopBudget
 missingLoaded <- within "missing config load"
  (loadPersistentBackendConfig missingOwner (suiteRoot </> "does-not-exist-startup.json"))
 check "missing config refused" (missingLoaded == Left "persistent config unavailable")
 missingExit <- persistentBackendLeaderExit missingOwner
 missingRetired <- within "missing config retire" (retirePersistentBackend missingOwner)
 check "settled missing config keeps LeaderExitUnobserved and retires cleanly"
  (missingExit == Persistent.LeaderExitUnobserved && missingRetired)

 -- 8. Negative: 21 deterministic hostile codec/boundary whole-frame rejection cases (3 per class across 7 classes).
 let hostileFrame caseIdx = case caseIdx `mod` (7 :: Int) of
      0 -> commitBytes [requestJson "shell-command" (100 + caseIdx) [("command", txt ("touch " ++ sentinelPath))]]
      1 -> commitBytes [requestJson "window-effect" (100 + caseIdx) []]
      2 -> commitBytes
            [ requestJson "catalog-request" (100 + caseIdx) []
            , obj
               [ ("protocolVersion", J.JNumber "3")
               , ("kind", txt "catalog-request")
               , ("binding", obj
                  [ ("lifetime", txt "9007199254740993")
                  , ("session", txt (show (9007199254741100 + toInteger caseIdx)))
                  , ("frontend", txt "9007199254740997")
                  ])
               , ("requestId", txt (show (200 + caseIdx)))
               ]
            ]
      3 -> commitBytes
            [ obj
               [ ("protocolVersion", J.JNumber "2")
               , ("kind", txt "catalog-request")
               , ("binding", bindingValue)
               , ("requestId", txt (show (100 + caseIdx)))
               ]
            ]
      4 -> commitBytes [requestJson "catalog-request" (100 + caseIdx) [("path", txt "/etc/passwd")]]
      5 -> commitBytes [requestJson "taskbar-pins-write" (100 + caseIdx) [("proposal", proposalJson "2" ["../outside-" ++ show caseIdx])]]
      _ -> "{\"viewProtocol\":1,\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{},\"requests\":[],\"focus\":[]}"
 forM_ [0 .. 20 :: Int] $ \caseIdx -> do
  let badLabel = "persistent-hostile-" ++ show caseIdx
  (badCfg, _) <- prepareCase badLabel True Nothing [(hostileFrame caseIdx, 0 :: Int, True)]
  badSessions <- newCurrentSessions
  badOwner <- newPersistentBackendOwner badSessions testStopBudget
  badLoaded <- within (badLabel ++ " load") (loadPersistentBackendConfig badOwner badCfg)
  check (badLabel ++ " config loaded") (badLoaded == Right ())
  badRun <- within (badLabel ++ " run") (runPersistentBackend badOwner)
  badDelivery <- persistentBackendDelivery badOwner
  badExit <- persistentBackendLeaderExit badOwner
  badRetired <- within (badLabel ++ " retire") (retirePersistentBackend badOwner)
  sentinelExists <- doesPathExist sentinelPath
  currentPins <- B.readFile (pinsDir </> "taskbar.json")
  check (badLabel ++ " refuses before ANY domain callback and retires cleanly")
   ( persistentBackendCounts badRun == (0, 0)
   && badDelivery == DeliveryNotAttempted
   && (case badExit of Persistent.LeaderExitObserved _ -> True; _ -> False)
   && badRetired
   && not sentinelExists
   && currentPins == persistedPins
   )

 -- 9. Negative: Callback-level in-frame duplicate requestId rejects whole frame before attachment/domain IO and fail-closes owner.
 (dupCfg, _) <- prepareCase "persistent-duplicate-reqid" True Nothing
  [(commitBytes [requestJson "catalog-request" 300 [], requestJson "catalog-request" 300 []], 0 :: Int, True)]
 dupSessions <- newCurrentSessions
 dupOwner <- newPersistentBackendOwner dupSessions testStopBudget
 dupLoaded <- within "duplicate-reqid load" (loadPersistentBackendConfig dupOwner dupCfg)
 check "duplicate-reqid config loaded" (dupLoaded == Right ())
 dupRun <- within "duplicate-reqid run" (runPersistentBackend dupOwner)
 dupDelivery <- persistentBackendDelivery dupOwner
 dupExit <- persistentBackendLeaderExit dupOwner
 dupRetired <- within "duplicate-reqid retire" (retirePersistentBackend dupOwner)
 dupSentinelExists <- doesPathExist sentinelPath
 dupCurrentPins <- B.readFile (pinsDir </> "taskbar.json")
 check "duplicate requestId rejects before attachment/domain IO and fail-closes owner"
  ( persistentBackendCounts dupRun == (1, 0)
  && persistentBackendOutcome dupRun == Right PersistentBootstrapUncertain
  && dupDelivery == DeliveryNotAttempted
  && (case dupExit of Persistent.LeaderExitObserved _ -> True; _ -> False)
  && not dupRetired
  && not dupSentinelExists
  && dupCurrentPins == persistedPins
  )

 -- 10. Child nonzero exit (exitCode = 23) synthetic stderr injection + exact ExitFailure 23 observation.
 (privCfg, privReplies) <- prepareCase "persistent-stderr-23" False (Just (23 :: Int))
  [(commitBytes [requestJson "catalog-request" 500 []], 1 :: Int, False)]
 privSessions <- newCurrentSessions
 privOwner <- newPersistentBackendOwner privSessions testStopBudget
 privLoaded <- within "stderr-23 load" (loadPersistentBackendConfig privOwner privCfg)
 check "stderr-23 config loaded" (privLoaded == Right ())
 privRun <- within "stderr-23 run" (runPersistentBackend privOwner)
 privExit <- persistentBackendLeaderExit privOwner
 privRetired <- within "stderr-23 retire" (retirePersistentBackend privOwner)
 injectedExists <- doesPathExist (privReplies ++ ".stderr-injected")
 let syntheticMarkers =
      [ "WARLOCK_SYNTHETIC_CREDENTIAL_DEL017_8C41A2"
      , "WARLOCK_SYNTHETIC_DRAFT_DEL017_9D52B3"
      , "WARLOCK_SYNTHETIC_PIXELS_DEL017_AE63C4"
      ]
 injectedBytes <- if injectedExists then B.readFile (privReplies ++ ".stderr-injected") else pure B.empty
 check "child exit 23 flushed synthetic stderr markers, recorded ExitFailure 23, and retired cleanly"
  ( injectedExists
  && injectedBytes == B.intercalate "\n" syntheticMarkers <> "\n"
  && persistentBackendCounts privRun == (1, 1)
  && privExit == Persistent.LeaderExitObserved (ExitFailure 23)
  && privRetired
  )
 readIORef checksRun
