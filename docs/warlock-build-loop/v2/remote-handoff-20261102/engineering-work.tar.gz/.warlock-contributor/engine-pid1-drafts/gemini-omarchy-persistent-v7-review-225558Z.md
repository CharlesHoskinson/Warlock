# Persistent Custody Prerequisite `v7` Source Review & Boundary Handoff (`225558Z`)

- **Owner**: `gemini-omarchy` (`warlock-20261031-setup`)
- **Canonical Base (`HEAD`)**: `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70` (canonical tree untouched; zero worker compiler/model/VM/native runs)
- **Preserved Prior `v6` Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v6-220528Z.patch` (`sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`)
- **Minimal `v6 -> v7` Delta Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v6-to-v7-delta-225558Z.patch` (`sha256:f06aac4e4e5b207ad35e90bbd068413cacef79624462b46b01c7206c0f05d5d1`, `71,345` bytes)
- **Full `HEAD -> v7` Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v7-225558Z.patch` (`sha256:5aba617d4adbce8db604beefff8f9260ee2108a8c2c4b4b7795e5aaf892fd1b0`, `132,274` bytes)
- **Manifest**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-v7-manifest-225558Z.json`

## 1. Exact Refinements Closed in `v7` (Over Preserved `v6` `2614f60e`)

### Refinement 1: Inner-Bracket Wake Tombstone Ordering + Sticky Unregister-Fault Containment (`Persistent/Internal.hs`)
1. **Eliminated post-`wakeBody` / pre-`finally` escape window**:
   - Inside `runWakeScope`, `bracket (threadWaitReadSTM (fromIntegral rawPidfd))` now commits `atomically (writeTVar scopeExitedVar True)` **first** inside its masked release handler, invokes `hook "persistent-wake-tombstoned-before-unregister"`, runs GHC's `unregister`, and writes `registrationSafe = True` **only after** `unregister` returns normally.
   - Any escaped `STM LiveWakeReason` sampled after `wakeBody` exits—even while GHC `unregister` is still in progress—deterministically returns `LiveWakeScopeExited` (never stale readiness or `retry`).
2. **Sticky unregister-fault pin + synchronous admission closure (`5c60` + `c324` audit resolved)**:
   - Audited lexical scope, lock order, and stop-deadline semantics for `terra-security` (`01M6CN8VGVB04WA0W5S85VCBHZ`, `01M6CNAFH61VSQA5AD1K3FV65B`, `01M6CNBAJ85T84B90TWAQT4DKD`) and `terra-q-lifetime` (`01M6CN9ATVT8BZDCE5AM9D2QW4`):
     - When `registrationSafe == False` (`threadWaitReadSTM`, pre-unregister hook, or `unregister` threw), outer `finally` **retains** the `WakeGate` pin (`activeCount >= 1`), calls `closeWakeGate wg`, and calls `void (beginStopGateAndDeadline cbGate stopReadyVar stopBell stopMicros) \`onException\` closeCallbackGate cbGate stopReadyVar stopBell`.
     - **Zero lock cycle**: no `phaseVar`, `frameStateVar`, `gateVar`, or `wgVar` is held on entry to `runWakeScope`'s `finally`; `wgVar` and `gateVar` are acquired sequentially and independently.
     - **Single immutable `StopDeadline` preserved**: `beginStopGateAndDeadline` mints (or reuses) the single `stopMicros`-capped `AdmissionDeadline` while preserving `attempted == False`, so a subsequent explicit `requestSessionStop` reuses that exact deadline and still sends one-shot verified `SIGTERM` rather than falsely reporting `StopAlreadyRequested`, while subsequent `withLiveSessionWakeSTM` and `withLiveFrameAdmission` immediately refuse with `Left SessionClosed`.
   - When `registrationSafe == True` and `wakeBody` itself threw a synchronous caller exception, `v7` rethrows the caller exception cleanly after releasing `WakeGate` (consistent with the `stoppedNow` and `deadNow` branches), returning `Left SpawnOrIO` strictly for registration/unregistration faults.
   - Natively compatible with `TerraSecurityWakeScopeRace.hs` (`sha256:3eb06e230f260a1070aa07440bb70415a2d4ed00a87d84b87dbfeee05035aee4`) without requiring separate hook patch `4a82`.

### Refinement 2: Owner-Retained Sticky `PidfdCustody` + `Owner.Pending` Retention + `O.settle` Fix (`Persistent.hs`, `Persistent/Internal.hs`)
1. **Sticky owner-retained descriptor state without raw `Fd` export**:
   - Moved `IORef InternalPidfdState` onto `PersistentOwner` itself and exposed raw-`Fd`-free `PidfdCustody` (`PidfdUnopened | PidfdKnownOpen !ProcessID !(Maybe O.FDIdentity) | PidfdClosing !ProcessID !(Maybe O.FDIdentity) | PidfdClosed | PidfdCloseUncertain !ProcessID !(Maybe O.FDIdentity) !Text`) via `persistentPidfdCustody :: PersistentOwner -> IO PidfdCustody`.
   - On `c_pidfd_open`, `openSessionPidfd` records `InternalPidfdKnownOpen pfd pid (Just (FDIdentity dev ino))` (via `getFdStatus`) inside `mask_` and mirrors `pendingRecordFD` + `pendingIdentityFD` into `O.Owner`'s retained `O.Pending` slot (`newPending` + `retainPending`).
2. **Pre-close known-open vs in-close uncertain distinction (`closeOwnedPidfdDl`)**:
   - If `hook "persistent-before-pidfd-close-precheck"` aborts or `remainingMicros closeDl <= 0` **before** entering `closeFd`, `closeFd` is never called, `O.pendingRecordIssue` logs the pre-close abort/expiry, and custody remains `PidfdKnownOpen pid ident` (known-unclosed).
   - Once `closeOwnedPidfdDl` claims the descriptor for closing, it atomically transitions `InternalPidfdKnownOpen -> InternalPidfdClosing`, marks `O.pendingMarkFD pending pfd False`, and executes `closeFd pfd` at most once:
     - `Right (Just ())` -> `InternalPidfdClosed` + `O.pendingMarkFD pending pfd True`
     - `Right Nothing` / `Left ex` -> sticky `InternalPidfdCloseUncertain pid ident detail` + `O.pendingRecordIssue` (never retried or signaled again by `requestSessionStop` or `terminateLeaderDl`).
3. **Compile-blocking `O.settle` arity & borrow-release fix in `finishContainment`**:
   - Fixed `v6`'s 2-argument `O.settle rawOwner child` typo to match `Owner.hs:42` (`settle :: Owner -> IO ()`, 1 argument) preceded by `O.releaseBorrows rawOwner >> O.clearTransfers rawOwner >> O.clearCore rawOwner >> O.clearTickets rawOwner >> O.clearPending rawOwner >> O.settle rawOwner` on clean containment (`null allFailures`), while preserving all retained resources and `O.Pending` on `O.quarantine rawOwner (Just child) allFailures`.

### Literal Race Controls Added in `test/PersistentControls.hs`
- **Updated #4, #7, #9**: Assert `PidfdKnownOpen` on expired-startup-stop and hung-wake quarantines, `PidfdClosed` on clean post-open startup timeout retirement, and bounded `awaitLeaderExited` in fixture cleanup.
- **Control #12**: Pauses `"persistent-wake-tombstoned-before-unregister"` while holding an escaped `STM LiveWakeReason`; proves `atomically escSTM == LiveWakeScopeExited` *before* `unregister` executes, then retires cleanly with `PidfdClosed`.
- **Control #13**: Injects synchronous error at `"persistent-wake-tombstoned-before-unregister"`; proves `Left SpawnOrIO`, `liveSessionStopRequestedSTM == True`, subsequent wake/frame admissions refused with `Left SessionClosed`, `WakeGate` pin retained so `retireLive` quarantines `["persistent-wake-not-drained"]` under `stop60ms`, and `persistentPidfdCustody == PidfdKnownOpen pid (Just _)`.
- **Control #14**: Expires `stop60ms` inside `"persistent-before-pidfd-close-precheck"`; proves `closeFd` is never entered (`0` attempts), owner quarantines `["pidfd-close"]`, and custody remains `PidfdKnownOpen pid (Just _)`.
- **Control #15**: Throws synchronous error inside `"persistent-before-pidfd-close-precheck"`; proves `closeFd` is never entered (`0` attempts), owner quarantines `["pidfd-close"]`, and custody remains `PidfdKnownOpen pid (Just _)`.
- **Control #16**: Throws synchronous error inside `"persistent-in-pidfd-close"`; proves `1` attempt (never retried), post-quarantine `requestSessionStop == StopNoLiveSession`, owner quarantines `["pidfd-close"]`, and custody is `PidfdCloseUncertain pid (Just _) _`.

## 2. Coordination on Persistent Ingress Self-Pin & `Gate.Draining` Deferred Close (`d575ce95` / `74b07921d42d` / `5795989c40f5`)

- **Historical `d575ce95` self-pin**: `Channel.failFrame` invoked `closeChannel` while still inside `withPinnedSocket`, observing its own `SharedClose` pin (`canClose == False`) and latching `EndpointUncertain` on every frame fault.
- **Current `terra-engine` `74b07921d42d` + `terra-graph` `5795989c40f5` boundary**:
  - Deferring `closeChannel` until after `withPinnedSocket` exits resolves single-thread self-pinning, **but private `Gate.Gate` or `SharedClose` `SocketPins` borrowing alone does NOT confirm socket cleanup**:
    1. In `74b07921d42d` (`Ingress/Internal.hs:336, 337-350`), when `G.retire gateValue` returns `G.Draining` because another callback holds the private gate, `failAndRetire`/`retireOnWake` return `PersistentGateDraining`/`PersistentFrameDraining`/`PersistentOwnerWakeDraining` without calling `C.closeChannel channel` and without transitioning `state` out of `Running shared channel`.
    2. As `terra-graph`'s race fixture `5795989c40f5` demonstrates, an external `retireCredentialIngress` racing an active `waitPinnedSocket` borrow sets `pins = (True, n)` (`n > 0`) and latches `EndpointUncertain` without closing the socket; when the waiter later unregisters (`n -> 0`), nothing performs a deferred `S.close`.
  - **Required boundary**: Either perform a bounded same-owner drain of `G.Gate` + `SocketPins` followed by a single post-drain `closeChannel`, or treat `Draining`/`PersistentCloseUncertain` as sticky quarantine under the unchanged `StopDeadline`. Never report socket cleanup from pin release alone.

## 3. Unimplemented Production Call Chain (Honest Readiness Status)

1. **`Warlock.Capture.Process.Persistent` (`v7`, `5aba617d`)**: Source-complete prerequisite slice + 16 literal controls; **not yet compiled or executed by Root**.
2. **`credential-ingress` (`terra-engine` `74b07921d42d`)**: Draft source; still requires bounded post-drain close / sticky quarantine on `Gate.Draining` and concurrent `retireCredentialIngress`.
3. **`PersistentAggregate` / `TrustedPump` (`terra-engine` `aggregate-route-v2`)**: **Unimplemented production pump** (`TrustedPump` has no public constructor or production loop yet; must map `Left` from `withLiveSessionWakeSTM` and any ingress close uncertainty to mandatory owner retirement).
4. **Canonical Daemon / Provider / Elm Route**: **Zero canonical callsites wired** (`nativeOperations = []`; `17/242` whole EARS, `41/417` scenarios unchanged).

## 4. Peer Source Review Log (`v7`)
- Solicited independent source reviews on `v7` (`f06aac4e` delta / `5aba617d` full) from `terra-engine`, `terra-q-lifetime`, `terra-security`, `sol-docs`, and `terra-graph` (pending incoming verdicts before `23:23:58Z` cutoff).
