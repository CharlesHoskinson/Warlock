# Root-only verification of guest engine artifacts, 155313Z

**Source drift, observed 16:22 UTC:** this recipe and the retained receipt apply only to the 155313Z guest build. Its manifest pins `runtime/ui/Main.hs` to `5df812de63c32881bf50b5e2109e06c6259192b0f9188a0f84a22efc1d7209b0`; the then-current host file had changed to `50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7`. The earlier host 214/214 comparison is therefore stale. Root must source-bind and independently verify a new build before using it; do not transfer this old receipt to that build.

Preparation draft; **not executed or tested by this worker**. Root's existing `guest-artifacts.json` receipt has SHA-256 `5980020aa85b64ec9dee49f6e75a93f6e7cb740ca32b970f52933b23553012cd` and reports 214 matching source inputs, three documents and 186 owner / 36 backend hashed dependencies. Its verifier hashes sources once before ELF enumeration, despite the receipt field `sourceInputsStable`; it does not prove they remained unchanged throughout or until launch. Its DSO observations likewise lack a post-read identity check. It records that the original detached build exit status was not collected. Review that receipt first; root decides whether a fresh targeted recheck is warranted. Root alone runs guest, compiler, model and native work. Use only after the source-bound component gates and guest build have been reviewed. Do not start a GUI, send QMP input, modify the main desktop, inspect terminal drafts, or alter existing evidence. Failure or uncertainty stops the trial; never reset the original deadline or infer native, original-scenario, AT/IME or release acceptance.

The retained host evidence says the staged source manifest was SHA-256 `1da56afb6359f5c1233bd1988035fb8bc46ef59d18da10564b6bf599f00d9b50`, and its staging receipt reported 214 matching Haskell-tree inputs at staging time. The guest build log recorded these binary hashes:

- `/home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-owner`: `804d2f77b55f395af93b96eb0edb6d52c3d960f56b8e2725126f62b36ba4d5ed`.
- `/home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z/assets/warlock-ui-backend`: `00e5755942c29ad53295fd0f3e2071533ecf4b851d1e0cef29e2ff341b530b7d`.

Those are historical build-log observations, not a current integrity check. The captured `readelf`/`ldd` output contains resolved paths but does not itself provide hashes for every DSO. The owner and its held `--engine-only` role use the same executable; do not invent a separate engine binary. Build inputs and old evidence stay intact.

Root can run the following **on the guest** in its own protected session, with the session left locked and Foot undisturbed. It creates a fresh evidence directory under the existing guest run directory. Review the Python and tool paths first. The locally built ELF files are the only files passed to `ldd`; do not use `ldd` on untrusted executables. The commands do not launch the GUI or execute tests. Save the resulting directory and console status outside the repository.

```bash
set -eu
umask 077
WARLOCK_GUEST_RUN=/home/charl/warlock-mvp-20261101T1058Z/engine-pid1-20261101T155313Z
WARLOCK_VERIFY_DIR=$(mktemp -d "/home/charl/warlock-mvp-20261101T1058Z/artifact-verification-155313Z-XXXXXXXX")
export WARLOCK_GUEST_RUN WARLOCK_VERIFY_DIR
printf 'evidence=%s\n' "$WARLOCK_VERIFY_DIR"
python3 -B - <<'PY'
import hashlib, json, os, re, stat, subprocess, sys, time
from pathlib import Path

run = Path(os.environ['WARLOCK_GUEST_RUN'])
out = Path(os.environ['WARLOCK_VERIFY_DIR'])
source = Path('/home/charl/warlock-mvp-20261101T1058Z/source')
manifest_path = run / 'source-manifest.json'
expected_manifest = '1da56afb6359f5c1233bd1988035fb8bc46ef59d18da10564b6bf599f00d9b50'
expected_assets = {
    run / 'assets/warlock-ui-owner': '804d2f77b55f395af93b96eb0edb6d52c3d960f56b8e2725126f62b36ba4d5ed',
    run / 'assets/warlock-ui-backend': '00e5755942c29ad53295fd0f3e2071533ecf4b851d1e0cef29e2ff341b530b7d',
}
expected_documents = {
    Path('/home/charl/warlock-mvp-20261101T1058Z/assets/HttpMain.html'): '60aa950faa9b405ea71267487e906eef11f614e1beda69a8ad09f7fb4b1f13f1',
    Path('/home/charl/warlock-mvp-20261101T1058Z/assets/HttpBar.html'): 'a79e3fecc5d741dbba926f780f206d3fad658c689c978718a564837db1e8be98',
    Path('/home/charl/warlock-mvp-20261101T1058Z/assets/HttpPopup.html'): '4713fbf12dcc597af389b2800f9fc69b30718fafe7fd421e3446ff722b9e1f30',
}
result = {'schema': 1, 'stage': 'verification-only', 'manifest': str(manifest_path),
          'sourcesBefore': {}, 'sourcesAfter': {}, 'assets': {}, 'documents': {}, 'dependencies': {},
          'commands': [], 'errors': [], 'nativeAccepted': False, 'releaseAccepted': False}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def identity(path):
    # Follow a library symlink deliberately, recording both alias and target.
    alias = path.lstat()
    resolved = path.resolve(strict=True)
    fd = os.open(resolved, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode), 'not a regular ELF file: ' + str(path))
        h = hashlib.sha256()
        while True:
            block = os.read(fd, 1048576)
            if not block:
                break
            h.update(block)
        after = os.fstat(fd)
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
                'file changed while hashing: ' + str(path))
    finally:
        os.close(fd)
    alias_after = path.lstat()
    require((alias.st_dev, alias.st_ino, alias.st_mtime_ns) ==
            (alias_after.st_dev, alias_after.st_ino, alias_after.st_mtime_ns),
            'path changed while hashing: ' + str(path))
    return {'path': str(path), 'resolved': str(resolved), 'aliasDevice': alias.st_dev,
            'aliasInode': alias.st_ino, 'device': before.st_dev, 'inode': before.st_ino,
            'size': before.st_size, 'sha256': h.hexdigest()}

def run_tool(argv, name):
    # Clean resolution environment; record it. Root must compare it with the
    # reviewed launch environment before accepting this as launch provenance.
    env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'LANG': 'C'}
    completed = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, env=env, timeout=60, check=False)
    (out / (name + '.stdout')).write_bytes(completed.stdout)
    (out / (name + '.stderr')).write_bytes(completed.stderr)
    result['commands'].append({'argv': argv, 'exit': completed.returncode,
                               'environment': env, 'stdout': name + '.stdout',
                               'stderr': name + '.stderr'})
    require(completed.returncode == 0, 'tool failed: ' + name)
    return completed.stdout.decode('utf-8', errors='strict')

def check_sources(expected, target):
    require(len(expected) == 214, 'unexpected source count')
    require(not source.is_symlink(), 'staged source root is a symlink')
    root = source.resolve(strict=True)
    for name, expected_hash in sorted(expected.items()):
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts and
                rel.parts[:3] == ('implementation', 'warlock', 'haskell'), 'invalid source path')
        path = source / rel
        cursor = source
        for part in rel.parts:
            cursor = cursor / part
            require(not cursor.is_symlink(), 'symlink in staged source path: ' + name)
        require(path.resolve(strict=True).is_relative_to(root), 'source escaped stage: ' + name)
        facts = identity(path)
        target[name] = facts
        require(facts['sha256'] == expected_hash, 'source hash mismatch: ' + name)

try:
    result['startedMonotonicNs'] = time.monotonic_ns()
    require(digest(manifest_path) == expected_manifest, 'manifest hash mismatch')
    manifest = json.loads(manifest_path.read_text())
    expected_sources = manifest['completeHaskellSources']
    require(isinstance(expected_sources, dict), 'invalid source manifest')
    check_sources(expected_sources, result['sourcesBefore'])
    for document, expected in expected_documents.items():
        info = identity(document)
        result['documents'][str(document)] = info
        require(info['sha256'] == expected, 'document hash mismatch: ' + str(document))
    all_libraries = set()
    for number, (asset, expected) in enumerate(expected_assets.items()):
        info = identity(asset)
        result['assets'][str(asset)] = info
        require(info['sha256'] == expected, 'asset hash mismatch: ' + str(asset))
        run_tool(['/usr/bin/readelf', '-h', '-l', '-d', str(asset)], 'elf-%d' % number)
        listing = run_tool(['/usr/bin/ldd', str(asset)], 'ldd-%d' % number)
        require('not found' not in listing, 'unresolved dependency: ' + str(asset))
        found = []
        for raw in listing.splitlines():
            line = raw.strip()
            if not line or line.startswith('linux-vdso.so'):
                continue
            # Typical forms: lib.so => /absolute/path (0x...) and /loader (0x...).
            match = re.match(r'^\S+\s+=>\s+(/\S+)\s+\(0x[0-9a-fA-F]+\)$', line)
            if match is None:
                match = re.match(r'^(/\S+)\s+\(0x[0-9a-fA-F]+\)$', line)
            require(match is not None, 'unrecognized ldd line: ' + line)
            found.append(match.group(1))
            all_libraries.add(match.group(1))
        require(found, 'no resolved dynamic dependencies: ' + str(asset))
        result['assets'][str(asset)]['resolvedDependencies'] = found
        for package in ('cryptohash-sha256', 'network', 'warlock-held-document-proposal',
                        'warlock-process-custody', 'warlock-protocol', 'warlock-runtime'):
            matches = [Path(name) for name in found if Path(name).name.startswith('libHS' + package + '-')
                       and '-inplace-' in Path(name).name]
            require(len(matches) == 1 and matches[0].resolve(strict=True).is_relative_to((run / 'dist/build').resolve(strict=True)),
                    'missing or foreign inplace DSO: ' + package)
    for number, name in enumerate(sorted(all_libraries)):
        path = Path(name)
        require(path.is_absolute(), 'nonabsolute DSO')
        result['dependencies'][name] = identity(path)
        run_tool(['/usr/bin/readelf', '-h', '-l', '-d', str(path)], 'dso-%04d' % number)
    # Re-hash all inputs, binaries and resolved DSOs to detect drift during inventory.
    check_sources(expected_sources, result['sourcesAfter'])
    for asset, expected in expected_assets.items():
        again = identity(asset)
        before = result['assets'][str(asset)]
        require((again['device'], again['inode'], again['size'], again['sha256']) ==
                (before['device'], before['inode'], before['size'], expected),
                'asset changed during inventory: ' + str(asset))
    for document, expected in expected_documents.items():
        again = identity(document)
        before = result['documents'][str(document)]
        require((again['device'], again['inode'], again['size'], again['sha256']) ==
                (before['device'], before['inode'], before['size'], expected),
                'document changed during inventory: ' + str(document))
    for name, facts in result['dependencies'].items():
        again = identity(Path(name))
        require((again['device'], again['inode'], again['size'], again['sha256']) ==
                (facts['device'], facts['inode'], facts['size'], facts['sha256']),
                'DSO changed during inventory: ' + name)
    require(digest(manifest_path) == expected_manifest, 'manifest changed during inventory')
    result['resolvedDependencyCount'] = len(all_libraries)
    result['sourceCount'] = len(expected_sources)
    result['inventoryCompleteForLddOutput'] = True
except Exception as exc:
    result['errors'].append(type(exc).__name__ + ': ' + str(exc))
finally:
    result['finishedMonotonicNs'] = time.monotonic_ns()
    (out / 'inventory.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'evidence': str(out), 'sources': len(result['sourcesAfter']),
                      'resolvedDependencies': len(result['dependencies']), 'errors': result['errors'],
                      'nativeAccepted': False, 'releaseAccepted': False}))
if result['errors']:
    sys.exit(1)
PY
find "$WARLOCK_VERIFY_DIR" -maxdepth 1 -type f ! -name files.sha256 -print0 | sort -z | xargs -0 sha256sum > "$WARLOCK_VERIFY_DIR/files.sha256"
sha256sum "$WARLOCK_VERIFY_DIR/files.sha256"
```

Root should hash `inventory.json`, every saved `readelf`/`ldd` output and the evidence directory manifest; bind them to the qualified source manifest, component report and executable hashes. Examine each owner and backend `PT_INTERP`, `DT_NEEDED`, RPATH/RUNPATH and every dependency; a missing/unrecognized dependency, changing file, source mismatch, failure or timeout is not a pass. Check that the resolved in-place protocol, runtime, process-custody and held-document DSOs come from this new build, not the older build directory; record the system loader, GTK4, WebKitGTK, GLib, GObject, GIO, Soup and all transitive paths and hashes.

`ldd` reports the loader-resolved dependency closure for these binaries in the **recorded clean environment**. It does not prove the set of libraries opened later with `dlopen`, WebKit subprocess/helper binaries, sandbox behavior, held-image `execveat` behavior, live GTK mapping, or actual callback retirement. Root must separately review actual launch environment and any provider/helper or dynamic-load inventory. Keep the original 28-second deadline, `nativeOperations: []`, prior failures, Foot/idle state and HOSTSTOP2 intact; this recipe provides artifact provenance only.
