{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE CPP #-}
-- Draft internal prerequisite, not wired to Channel. The trusted channel owner
-- must create exactly one gate for its socket, use its existing owned closer at
-- construction, and route EVERY socket close through that same gate. A bypass,
-- a second gate, or exposing socket/closer to a caller invalidates the proof.
module Warlock.Transport.IdleSocketLifetime
  ( IdleSocketLifetime, DrainPermit, DrainResult(..), CloseReceipt(..), IdleWake(..)
  , newIdleSocketLifetime, waitIdle, retiringSTM
  , retireIdleSocket, closeAfterDrain
#ifdef WARLOCK_IDLE_TEST
  , IdleTestProbe, newIdleTestProbe, waitIdleWithProbe, probeRegisteredSTM, releaseTestProbe
#endif
  ) where

import Control.Concurrent.STM
import Control.Exception (SomeAsyncException, SomeException, bracket, finally, fromException, mask, throwIO, try)
import Data.IORef
import GHC.Clock (getMonotonicTimeNSec)
import GHC.Conc (threadWaitReadSTM)
import qualified Network.Socket as S
import System.Timeout (timeout)

data Phase = Open | Retiring deriving Eq
data IdleSocketLifetime = IdleSocketLifetime !(TVar (Phase, Int)) !S.Socket !(IO ())
-- A permit closes only the closer fixed in the owning gate, not an arbitrary IO.
data DrainPermit = DrainPermit !(IORef Bool) !Integer !(IO ())
data IdleTestProbe = IdleTestProbe !(TVar Bool) !(TVar Bool)
data DrainResult = Drained DrainPermit | DrainTimedOut | DrainAlreadyStarted
data CloseReceipt = CloseCompleted | CloseUncertain | ClosePermitUsed | CloseDeadlineExpired
  deriving (Eq, Show)
data IdleWake reason = SocketReadable | OwnerWake reason | IdleRetiring
  deriving (Eq, Show)

newIdleSocketLifetime :: S.Socket -> IO () -> IO IdleSocketLifetime
newIdleSocketLifetime sock ownedCloser = do
  state <- newTVarIO (Open, 0)
  pure (IdleSocketLifetime state sock ownedCloser)

-- Probe provides only STM observation/scheduling. It never exports a socket,
-- FD, registration action or arbitrary callback. Keep probe APIs internal to
-- fixture builds; production callers only receive waitIdle.
newIdleTestProbe :: IO IdleTestProbe
newIdleTestProbe = IdleTestProbe <$> newTVarIO False <*> newTVarIO False
probeRegisteredSTM :: IdleTestProbe -> STM ()
probeRegisteredSTM (IdleTestProbe registered _) = readTVar registered >>= check
releaseTestProbe :: IdleTestProbe -> IO ()
releaseTestProbe (IdleTestProbe _ released) = atomically (writeTVar released True)

waitIdle :: IdleSocketLifetime -> STM reason -> IO (Maybe (IdleWake reason))
waitIdle gate = waitIdleInternal gate Nothing

waitIdleWithProbe :: IdleSocketLifetime -> IdleTestProbe -> STM reason -> IO (Maybe (IdleWake reason))
waitIdleWithProbe gate probe = waitIdleInternal gate (Just probe)

-- No socket, fd or registration callback escapes. Unregister runs before the
-- borrow count is decremented. Readiness consumes no bytes.
waitIdleInternal :: IdleSocketLifetime -> Maybe IdleTestProbe -> STM reason -> IO (Maybe (IdleWake reason))
waitIdleInternal (IdleSocketLifetime state sock _) probe ownerWake = mask $ \restore -> do
  acquired <- atomically $ do
    (phase, n) <- readTVar state
    if phase /= Open then pure False else writeTVar state (phase, n + 1) >> pure True
  if not acquired then pure Nothing else
    (Just <$> restore (S.withFdSocket sock $ \fd ->
      bracket (threadWaitReadSTM (fromIntegral fd)) snd $ \(readable, _) -> do
        case probe of
          Nothing -> pure ()
          Just (IdleTestProbe registered released) -> do
            atomically (writeTVar registered True)
            atomically (readTVar released >>= check)
        atomically ((do (phase, _) <- readTVar state
                        check (phase == Retiring)
                        pure IdleRetiring)
                    `orElse` (OwnerWake <$> ownerWake)
                    `orElse` (readable >> pure SocketReadable))))
    `finally` atomically (modifyTVar' state (\(phase, n) -> (phase, n - 1)))

retiringSTM :: IdleSocketLifetime -> STM ()
retiringSTM (IdleSocketLifetime state _ _) = do
  (phase, _) <- readTVar state
  if phase == Retiring then pure () else retry

-- 'absoluteD' is the established monotonic stop D, never renewed. First retire
-- latches wake before waiting. Timeout/exception leaves Retiring latched and the
-- caller must quarantine socket/owner/backing. Never retry with a new D.
retireIdleSocket :: IdleSocketLifetime -> Integer -> IO DrainResult
retireIdleSocket (IdleSocketLifetime state _ closer) absoluteD = mask $ \restore -> do
  first <- atomically $ do
    (phase, n) <- readTVar state
    if phase /= Open then pure False else writeTVar state (Retiring, n) >> pure True
  if not first then pure DrainAlreadyStarted else do
    before <- toInteger <$> getMonotonicTimeNSec
    if before >= absoluteD then pure DrainTimedOut else do
      let us = fromInteger (min (toInteger (maxBound :: Int)) ((absoluteD - before + 999) `div` 1000))
      drained <- restore $ timeout us $ atomically $ do
        (_, n) <- readTVar state
        check (n == 0)
      after <- toInteger <$> getMonotonicTimeNSec
      case drained of
        Just () | after < absoluteD -> do
          used <- newIORef False
          pure (Drained (DrainPermit used absoluteD closer))
        _ -> pure DrainTimedOut

-- Socket-close receipt only: no process-exit or provider-cleanup claim. Action
-- was fixed by the trusted owner; exceptions/timeout mean uncertain. A blocking
-- noninterruptible closer may exceed D, so a hard bound remains unproved.
closeAfterDrain :: DrainPermit -> IO CloseReceipt
closeAfterDrain (DrainPermit used absoluteD closer) = mask $ \restore -> do
  already <- atomicModifyIORef' used (\v -> (True, v))
  if already then pure ClosePermitUsed else do
    before <- toInteger <$> getMonotonicTimeNSec
    if before >= absoluteD then pure CloseDeadlineExpired else do
      let us = fromInteger (min (toInteger (maxBound :: Int)) ((absoluteD - before + 999) `div` 1000))
      result <- try (restore (timeout us closer)) :: IO (Either SomeException (Maybe ()))
      after <- toInteger <$> getMonotonicTimeNSec
      case result of
        Left ex -> case fromException ex :: Maybe SomeAsyncException of
          Just _ -> throwIO ex
          Nothing -> pure CloseUncertain
        Right (Just ()) | after < absoluteD -> pure CloseCompleted
        _ -> pure CloseUncertain
