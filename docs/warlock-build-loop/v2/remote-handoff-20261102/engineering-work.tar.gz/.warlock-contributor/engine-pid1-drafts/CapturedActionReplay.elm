port module CapturedActionReplay exposing (main)

-- QA-only boundary and Presentation.dispatch fixture for CapturedAction.Surface
-- and CapturedAction.Trigger custom types. Synthetic JSON inputs exercise Elm
-- decoding, wire encoding, Presentation.dispatch role gating, and Surface.resolve
-- relay semantics only; they are NOT authenticated input-origin capabilities or
-- native/release acceptance evidence.

import CapturedAction as Action
import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Presentation
import Surface
import TaskbarShell
import UInt64


port outgoing : E.Value -> Cmd msg


counter : String -> UInt64.Counter
counter rawText =
    D.decodeValue UInt64.decoder (E.string rawText) |> Result.withDefault UInt64.zero


boundWire : E.Value
boundWire =
    E.object
        [ ( "lifetime", E.string "1" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "1" )
        ]


nativeStep : E.Value -> Desktop.Model -> Desktop.Model
nativeStep wire model =
    NativePointerFixture.incoming wire model |> Tuple.first


attachedWire : E.Value
attachedWire =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "attached" )
        , ( "binding", boundWire )
        ]


windowRow : String -> E.Value
windowRow rowId =
    E.object
        [ ( "incarnation", E.string rowId )
        , ( "label", E.string ("Document " ++ rowId) )
        , ( "owner", E.null )
        , ( "application", E.string "documents" )
        , ( "minimized", E.bool False )
        , ( "available", E.bool True )
        ]


projectionWire : E.Value
projectionWire =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "action-projection" )
        , ( "binding", boundWire )
        , ( "requestId", E.string "1" )
        , ( "context"
          , E.object
                [ ( "lifetime", E.string "1" )
                , ( "epoch", E.string "1" )
                , ( "output", E.string "1" )
                , ( "revision", E.string "1" )
                ]
          )
        , ( "scene"
          , E.object
                [ ( "revision", E.string "1" )
                , ( "focused", E.string "1" )
                , ( "windows", E.list (\item -> item) [ windowRow "1", windowRow "2" ] )
                ]
          )
        ]


readyDesktop : Desktop.Model
readyDesktop =
    Desktop.initial |> nativeStep attachedWire |> nativeStep projectionWire


groupControlId : String
groupControlId =
    "bar:group:"
        ++ (TaskbarShell.groups readyDesktop.windows
                |> List.head
                |> Maybe.map .key
                |> Maybe.withDefault "missing"
           )


wireAction : String -> String -> String -> String -> Maybe String -> E.Value
wireAction surfaceRole pubText leaseText controlId maybeTrigger =
    E.object
        ([ ( "surface", E.string surfaceRole )
         , ( "surfaceProtocol", E.int 2 )
         , ( "kind", E.string "surface-action" )
         , ( "publication", E.string pubText )
         , ( "lease", E.string leaseText )
         , ( "id", E.string controlId )
         ]
            ++ (maybeTrigger
                    |> Maybe.map (\triggerText -> [ ( "trigger", E.string triggerText ) ])
                    |> Maybe.withDefault []
               )
        )


failsWith : String -> E.Value -> Bool
failsWith expectedSubstring rawWire =
    case Action.decode rawWire of
        Ok _ ->
            False

        Err decodeErr ->
            String.contains expectedSubstring (D.errorToString decodeErr)


relayedDesktop : E.Value -> Desktop.Model -> Maybe Desktop.Model
relayedDesktop rawWire baseModel =
    Action.decode rawWire
        |> Result.toMaybe
        |> Maybe.map Action.encode
        |> Maybe.andThen (\encodedWire -> Surface.resolve (counter "1") UInt64.zero encodedWire baseModel)
        |> Maybe.map (\msg -> Desktop.update msg baseModel |> Tuple.first)


checks : E.Value
checks =
    let
        barPointerWire =
            wireAction "bar" "2" "1" "bar:applications" (Just "pointer")

        barKeyboardWire =
            wireAction "bar" "2" "1" "bar:applications" (Just "keyboard")

        barNoTriggerWire =
            wireAction "bar" "1" "0" groupControlId Nothing

        popupPointerWire =
            wireAction "popup" "2" "1" "control:close" (Just "pointer")

        popupKeyboardWire =
            wireAction "popup" "2" "1" "control:close" (Just "keyboard")

        popupNoTriggerWire =
            wireAction "popup" "2" "1" "control:close" Nothing

        groupPointerWire =
            wireAction "bar" "1" "0" groupControlId (Just "pointer")

        groupKeyboardWire =
            wireAction "bar" "1" "0" groupControlId (Just "keyboard")

        pointerOpenedMaybe =
            relayedDesktop groupPointerWire readyDesktop

        keyboardOpenedMaybe =
            relayedDesktop groupKeyboardWire readyDesktop

        omittedOpenedMaybe =
            relayedDesktop barNoTriggerWire readyDesktop

        pickerOpenDesktop =
            pointerOpenedMaybe |> Maybe.withDefault readyDesktop

        openPacket =
            Surface.packet (counter "2") (counter "1") pickerOpenDesktop

        acceptedPresentation =
            Presentation.accept openPacket Presentation.initial

        barPointerCheck =
            case Action.decode barPointerWire of
                Ok decoded ->
                    Action.surface decoded == Action.Bar
                        && Action.surfaceName (Action.surface decoded) == "bar"
                        && Action.trigger decoded == Just Action.Pointer
                        && (Action.trigger decoded |> Maybe.map Action.triggerName) == Just "pointer"
                        && Action.publication decoded == counter "2"
                        && Action.lease decoded == counter "1"
                        && Action.identity decoded == "bar:applications"
                        && E.encode 0 (Action.encode decoded) == E.encode 0 barPointerWire

                Err _ ->
                    False

        barKeyboardCheck =
            case Action.decode barKeyboardWire of
                Ok decoded ->
                    Action.surface decoded == Action.Bar
                        && Action.surfaceName (Action.surface decoded) == "bar"
                        && Action.trigger decoded == Just Action.Keyboard
                        && (Action.trigger decoded |> Maybe.map Action.triggerName) == Just "keyboard"
                        && E.encode 0 (Action.encode decoded) == E.encode 0 barKeyboardWire

                Err _ ->
                    False

        barOmittedTriggerCheck =
            case Action.decode barNoTriggerWire of
                Ok decoded ->
                    let
                        reencoded =
                            Action.encode decoded
                    in
                    Action.surface decoded == Action.Bar
                        && Action.trigger decoded == Nothing
                        && E.encode 0 reencoded == E.encode 0 barNoTriggerWire
                        && (D.decodeValue (D.field "trigger" D.value) reencoded |> Result.toMaybe) == Nothing

                Err _ ->
                    False

        popupPointerCheck =
            case Action.decode popupPointerWire of
                Ok decoded ->
                    Action.surface decoded == Action.Popup
                        && Action.surfaceName (Action.surface decoded) == "popup"
                        && Action.trigger decoded == Just Action.Pointer
                        && (Action.trigger decoded |> Maybe.map Action.triggerName) == Just "pointer"
                        && E.encode 0 (Action.encode decoded) == E.encode 0 popupPointerWire

                Err _ ->
                    False

        popupKeyboardCheck =
            case Action.decode popupKeyboardWire of
                Ok decoded ->
                    Action.surface decoded == Action.Popup
                        && Action.surfaceName (Action.surface decoded) == "popup"
                        && Action.trigger decoded == Just Action.Keyboard
                        && (Action.trigger decoded |> Maybe.map Action.triggerName) == Just "keyboard"
                        && E.encode 0 (Action.encode decoded) == E.encode 0 popupKeyboardWire

                Err _ ->
                    False

        popupOmittedTriggerCheck =
            case Action.decode popupNoTriggerWire of
                Ok decoded ->
                    let
                        reencoded =
                            Action.encode decoded
                    in
                    Action.surface decoded == Action.Popup
                        && Action.trigger decoded == Nothing
                        && E.encode 0 reencoded == E.encode 0 popupNoTriggerWire
                        && (D.decodeValue (D.field "trigger" D.value) reencoded |> Result.toMaybe) == Nothing

                Err _ ->
                    False

        dispatchAcceptsMatchingRoles =
            (Presentation.dispatch False barPointerWire acceptedPresentation |> Maybe.map (E.encode 0)) == Just (E.encode 0 barPointerWire)
                && (Presentation.dispatch True popupKeyboardWire acceptedPresentation |> Maybe.map (E.encode 0)) == Just (E.encode 0 popupKeyboardWire)
                && (Presentation.dispatch True popupNoTriggerWire acceptedPresentation |> Maybe.map (E.encode 0)) == Just (E.encode 0 popupNoTriggerWire)

        dispatchRefusesCrossSurface =
            Presentation.dispatch True barPointerWire acceptedPresentation == Nothing
                && Presentation.dispatch False popupKeyboardWire acceptedPresentation == Nothing

        relayedPopupCloseClosesPicker =
            Presentation.dispatch True popupNoTriggerWire acceptedPresentation
                |> Maybe.andThen (\relayedWire -> Surface.resolve (counter "2") (counter "1") relayedWire pickerOpenDesktop)
                |> Maybe.map (\closeMsg -> (Desktop.update closeMsg pickerOpenDesktop |> Tuple.first).windows.picker == Nothing)
                |> Maybe.withDefault False

        surfaceResolveRelayCheck =
            (pointerOpenedMaybe |> Maybe.map (\m -> m.windows.picker /= Nothing && m.popupOrigin == Desktop.PointerEntry) |> Maybe.withDefault False)
                && (keyboardOpenedMaybe |> Maybe.map (\m -> m.windows.picker /= Nothing && m.popupOrigin == Desktop.KeyboardEntry) |> Maybe.withDefault False)
                && (omittedOpenedMaybe |> Maybe.map (\m -> m.windows.picker /= Nothing && m.popupOrigin == Desktop.KeyboardEntry) |> Maybe.withDefault False)
                && relayedPopupCloseClosesPicker

        max512IdentityCheck =
            let
                maxId =
                    String.repeat 512 "x"
            in
            case Action.decode (wireAction "bar" "1" "0" maxId Nothing) of
                Ok decoded ->
                    String.length (Action.identity decoded) == 512

                Err _ ->
                    False

        invalidSurfaceWire =
            wireAction "desktop" "2" "1" "bar:applications" (Just "pointer")

        nullTriggerWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 2 )
                , ( "kind", E.string "surface-action" )
                , ( "publication", E.string "2" )
                , ( "lease", E.string "1" )
                , ( "id", E.string "bar:applications" )
                , ( "trigger", E.null )
                ]

        extraFieldWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 2 )
                , ( "kind", E.string "surface-action" )
                , ( "publication", E.string "2" )
                , ( "lease", E.string "1" )
                , ( "id", E.string "bar:applications" )
                , ( "nativeAuthority", E.bool True )
                ]

        missingFieldWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 2 )
                , ( "kind", E.string "surface-action" )
                , ( "publication", E.string "2" )
                , ( "id", E.string "bar:applications" )
                ]

        duplicateKeyWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 2 )
                , ( "kind", E.string "surface-action" )
                , ( "publication", E.string "2" )
                , ( "lease", E.string "1" )
                , ( "id", E.string "bar:applications" )
                , ( "id", E.string "control:close" )
                ]

        wrongProtocolWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 1 )
                , ( "kind", E.string "surface-action" )
                , ( "publication", E.string "2" )
                , ( "lease", E.string "1" )
                , ( "id", E.string "bar:applications" )
                ]

        wrongKindWire =
            E.object
                [ ( "surface", E.string "bar" )
                , ( "surfaceProtocol", E.int 2 )
                , ( "kind", E.string "surface-query" )
                , ( "publication", E.string "2" )
                , ( "lease", E.string "1" )
                , ( "id", E.string "bar:applications" )
                ]

        checkPairs =
            List.map (\( checkName, passed ) -> ( checkName, E.bool passed ))
                [ ( "barPointerDecodesTypedAndEncodesExactWire", barPointerCheck )
                , ( "barKeyboardDecodesTypedAndEncodesExactWire", barKeyboardCheck )
                , ( "barOmittedTriggerDecodesNothingAndOmitsWireTrigger", barOmittedTriggerCheck )
                , ( "popupPointerDecodesTypedAndEncodesExactWire", popupPointerCheck )
                , ( "popupKeyboardDecodesTypedAndEncodesExactWire", popupKeyboardCheck )
                , ( "popupOmittedTriggerDecodesNothingAndOmitsWireTrigger", popupOmittedTriggerCheck )
                , ( "presentationDispatchAcceptsMatchingBarAndPopupRoles", dispatchAcceptsMatchingRoles )
                , ( "presentationDispatchRefusesCrossSurfaceMismatch", dispatchRefusesCrossSurface )
                , ( "surfaceResolveAcceptsRelayedTriggersAndPopupClose", surfaceResolveRelayCheck )
                , ( "max512IdentityBoundaryAccepted", max512IdentityCheck )
                , ( "invalidSurfaceRefused"
                  , failsWith "Action scope" invalidSurfaceWire
                        && Presentation.dispatch False invalidSurfaceWire acceptedPresentation == Nothing
                        && Presentation.dispatch True invalidSurfaceWire acceptedPresentation == Nothing
                  )
                , ( "invalidTriggerRefused", failsWith "Action origin" (wireAction "bar" "2" "1" "bar:applications" (Just "touch")) )
                , ( "nullTriggerRefused", (Action.decode nullTriggerWire |> Result.toMaybe) == Nothing )
                , ( "extraFieldRefused", failsWith "Action fields" extraFieldWire )
                , ( "missingFieldRefused", failsWith "Action fields" missingFieldWire )
                , ( "duplicateKeyRefused", failsWith "Action fields" duplicateKeyWire )
                , ( "wrongProtocolRefused", failsWith "Action scope" wrongProtocolWire )
                , ( "wrongKindRefused", failsWith "Action scope" wrongKindWire )
                , ( "zeroPublicationRefused", failsWith "Action scope" (wireAction "bar" "0" "1" "bar:applications" Nothing) )
                , ( "emptyIdentityRefused", failsWith "Action scope" (wireAction "bar" "2" "1" "" Nothing) )
                , ( "overlongIdentityRefused", failsWith "Action scope" (wireAction "bar" "2" "1" (String.repeat 513 "x") Nothing) )
                , ( "c0ControlIdentityRefused", failsWith "Action scope" (wireAction "bar" "2" "1" "bar:apps\n" Nothing) )
                ]
    in
    E.object
        [ ( "checks", E.object checkPairs )
        , ( "barPointerEncoded", Action.decode barPointerWire |> Result.map Action.encode |> Result.withDefault E.null )
        , ( "barNoTriggerEncoded", Action.decode barNoTriggerWire |> Result.map Action.encode |> Result.withDefault E.null )
        , ( "popupKeyboardEncoded", Action.decode popupKeyboardWire |> Result.map Action.encode |> Result.withDefault E.null )
        , ( "popupNoTriggerEncoded", Action.decode popupNoTriggerWire |> Result.map Action.encode |> Result.withDefault E.null )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \() -> ( (), outgoing checks )
        , update = \_ model -> ( model, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
