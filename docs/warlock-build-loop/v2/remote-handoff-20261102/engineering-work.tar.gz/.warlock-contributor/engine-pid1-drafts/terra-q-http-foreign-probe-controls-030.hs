{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY, UNEXECUTED. A Case and two actual owners/root ledgers are
-- retained by an independent guardian before any physical test action.
-- The host owns the source-bound cleanup thread and original deadlines.
module QHttpForeignProbe030 (Case,newCase,runOnOwnerA,observe) where
import Control.Concurrent.MVar
import Control.Exception (SomeException,throwIO,try)
import Control.Monad (unless)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Platform.Resolver.Internal
 (ProbeCustody,RootAdmission,RootAdmissionFailure(..),RootStepResult(..),
  NestedPartObservation(..),probeParts,observeProbePart,closeProbePart)

data Case = Case ProbeCustody ProbeCustody (IORef Bool) (IORef Int) (MVar (Either SomeException ()))
newCase :: ProbeCustody -> ProbeCustody -> IO Case
newCase a b = Case a b <$> newIORef False <*> newIORef 0 <*> newEmptyMVar
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("foreign-probe: " ++ label)))

-- Call only ON the real owner A's authorized cleanup/admission thread,
-- bound to THIS exact A ledger and existing selected cleanup D. Both ledger
-- values must come from distinct real owners, each with its first actual
-- opened probe still retained after a real source resolution; a synthetic
-- ledger/adapter or a previously closed probe cannot satisfy this case.
-- This wrapper transparently counts entry of A's actual delegated action.
runOnOwnerA :: Case -> RootAdmission -> IO ()
runOnOwnerA (Case a b used entered done) admit = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 result <- try $ do
  check "single case" fresh
  aa <- probeParts a
  bb <- probeParts b
  (partA,partB) <- case (aa,bb) of
   ([x],[y]) -> pure (x,y)
   _ -> ioError (userError "need one actual retained probe in each independent ledger")
  check "actual private slot tokens differ" (partA/=partB)
  aBefore <- observeProbePart a partA
  bBefore <- observeProbePart b partB
  check "both genuine probes sealed and known-open" (aBefore==NestedKnownOpen && bBefore==NestedKnownOpen)
  let tracked :: RootAdmission
      tracked action = admit $ do
       atomicModifyIORef' entered (\n -> (n+1,()))
       action
  foreignObs <- observeProbePart a partB
  foreignClose <- closeProbePart tracked a partB
  callsAfterForeign <- readIORef entered
  aAfterForeign <- observeProbePart a partA
  bAfterForeign <- observeProbePart b partB
  check "foreign ledger token cannot observe or start a close" $
   foreignObs==NestedUnknown && foreignClose==Left RootAdmissionUnknown && callsAfterForeign==0 &&
   aAfterForeign==NestedKnownOpen && bAfterForeign==NestedKnownOpen
  ownClose <- closeProbePart tracked a partA
  callsAfterOwn <- readIORef entered
  aAfter <- observeProbePart a partA
  bAfter <- observeProbePart b partB
  check "positive real A-owned physical close; B remains untouched" $
   ownClose==Right RootStepClosed && callsAfterOwn==1 && aAfter==NestedClosedHistorical && bAfter==NestedKnownOpen
 putMVar done result
 either throwIO pure result

-- Only reads a completion MVar; timeout cannot cancel the product close or
-- fabricate an answer. On timeout keep owners, worker and guardian retained.
observe :: Case -> AdmissionDeadline -> AdmissionDeadline -> IO ()
observe (Case _ _ _ _ done) originalD selectedCleanupD = do
 a <- remainingMicros originalD
 b <- remainingMicros selectedCleanupD
 let left = min a b
 if left<=0 then ioError (userError "foreign-probe: existing D elapsed; retain guardian") else do
  result <- timeout left (readMVar done)
  case result of
   Nothing -> ioError (userError "foreign-probe: outcome Unknown; retain guardian")
   Just outcome -> either throwIO pure outcome
-- Positive physical receipt is historical only; exact owner's guarded current
-- D and remaining cleanup obligations still determine retirement. Nothing here
-- closes the foreign probe or represents native/product acceptance.
