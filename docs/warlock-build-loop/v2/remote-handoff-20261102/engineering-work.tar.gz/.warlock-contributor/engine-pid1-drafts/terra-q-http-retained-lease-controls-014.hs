{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Same-unit isolated QA: the host must root this Case,
-- actual Root, real PersistentOwner/StartD and an independent descriptor
-- guardian before entering. AfterProc fault deliberately strands an unknown
-- duplicate fd; never infer its numeric identity, close it, or claim cleanup.
module QHttpRetainedLease014 (Mode(..),Case,newCase,runCase) where
import Control.Exception (mask)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Posix.Types (Fd)
import System.Timeout (timeout)
import Warlock.Platform.Resolver.Internal
 (Root,Pin,Link,Resolution,ResolveError(..),Hooks,RootAdmission,RootAdmissionFailure(..),
  LeaseCustody,LeaseObservation(..),newLeaseCustody,observeLeaseCustody,
  QaLeaseSlot(..),qaLeaseSlots,qaLeaseCloneHook,resolveSnapshotVia,resolveSnapshotViaRetainedLease)

data Mode = LegacyPositive | LegacyBeforeSecond | LegacyAfterSecond
          | RetainedPositive | RetainedBeforeSecond | RetainedAfterSecond deriving (Eq,Show)
data Case = Case LeaseCustody (IORef [String]) (IORef Bool)
newCase :: IO Case
newCase = Case <$> newLeaseCustody <*> newIORef [] <*> newIORef False
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("retained lease: " ++ label)))
within :: String -> IO a -> IO a
within label act = timeout 5000000 act >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure

-- `admit` MUST be the rank-2 Engine step from the actual same-owner lexical
-- startup scope, adapted only to RootAdmission's typed error. A caller-supplied
-- fake Right adapter is not this test. `root` MUST be the same owner's actual
-- admitted, validated lexical root. Fixture arguments name a real validated
-- executable/digest whose complete route succeeds, as provided by Root's host.
runCase :: Case -> Mode -> RootAdmission -> Root -> [Pin] -> B.ByteString -> [Link]
 -> Integer -> Integer -> B.ByteString -> Hooks -> IO ()
runCase (Case owner events used) mode admit root pins path links size limit digest hooks = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "isolated single use" fresh
 let failBefore = mode==LegacyBeforeSecond || mode==RetainedBeforeSecond
     failAfter = mode==LegacyAfterSecond || mode==RetainedAfterSecond
     event label = do
      atomicModifyIORef' events (\xs -> (label:xs,()))
      if (failBefore && label=="before-proc-dup") || (failAfter && label=="after-proc-dup")
       then ioError (userError ("QA injection at " ++ label)) else pure ()
     consume :: Fd -> B.ByteString -> IO ()
     consume _ _ = pure ()
 qaLeaseCloneHook event
 case mode of
  LegacyPositive -> do
   result <- restore $ within "legacy real path positive" $
    resolveSnapshotVia root pins path links size limit digest hooks consume
   recorded <- reverse <$> readIORef events
   check "legacy actual two clones and full route" $
    (case result of Right (_ :: Resolution,()) -> True; _ -> False) &&
    recorded==["before-proc-dup","after-proc-dup"]
  LegacyBeforeSecond -> legacyFault restore owner events root pins path links size limit digest hooks consume ["before-proc-dup","legacy-root-closed"]
  LegacyAfterSecond -> legacyFault restore owner events root pins path links size limit digest hooks consume ["before-proc-dup","after-proc-dup","legacy-root-closed"]
  _ -> do
   result <- restore $ within "retained real path" $
    resolveSnapshotViaRetainedLease admit owner root pins path links size limit digest hooks consume
   recorded <- reverse <$> readIORef events
   observed <- observeLeaseCustody owner
   slots <- qaLeaseSlots owner
   case mode of
    RetainedPositive -> check "real retained pair and callback" $
     (case result of Right (Right (_ :: Resolution,())) -> True; _ -> False) &&
     recorded==["before-root-dup","after-root-dup","before-proc-dup","after-proc-dup"] &&
     observed==LeaseUnconfirmed && slots==(QaLeaseOpen,QaLeaseOpen)
    RetainedBeforeSecond -> check "first actual duplicate retained, second failure unknown" $
     result==Left RootAdmissionUnknown && recorded==["before-root-dup","after-root-dup","before-proc-dup"] &&
     observed==LeaseUnconfirmed && slots==(QaLeaseOpen,QaLeaseUnknown)
    RetainedAfterSecond -> check "first retained; physically duplicated second unpublished/unknown" $
     result==Left RootAdmissionUnknown && recorded==["before-root-dup","after-root-dup","before-proc-dup","after-proc-dup"] &&
     observed==LeaseUnconfirmed && slots==(QaLeaseOpen,QaLeaseUnknown)
    _ -> ioError (userError "invalid retained case")

-- This observes only the legacy bracket's real first-close completion and the
-- absence of its connection to the separate QA LeaseCustody. It cannot prove
-- disposition of the second, unpublished duplicate after an after-clone fault.
legacyFault :: (forall a. IO a -> IO a) -> LeaseCustody -> IORef [String] -> Root -> [Pin] -> B.ByteString -> [Link]
 -> Integer -> Integer -> B.ByteString -> Hooks -> (Fd -> B.ByteString -> IO ()) -> [String] -> IO ()
legacyFault restore owner events root pins path links size limit digest hooks consume expected = do
 result <- restore $ within "legacy real clone fault" $
  resolveSnapshotVia root pins path links size limit digest hooks consume
 recorded <- reverse <$> readIORef events
 observed <- observeLeaseCustody owner
 slots <- qaLeaseSlots owner
 check "legacy does not retain its clone pair in this owner" $
  result==Left OsFailure && recorded==expected && observed==LeaseNotStarted && slots==(QaLeaseUnused,QaLeaseUnused)
