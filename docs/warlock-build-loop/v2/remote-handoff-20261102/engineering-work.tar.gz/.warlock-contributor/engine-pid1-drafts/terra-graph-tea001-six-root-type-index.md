# TEA001 six-root local lexical type index

Source-only inventory; this enumerates top-level `type` and `type alias` declarations in the local lexical import closure of Main, Bar, Popup, HttpMain, HttpBar, HttpPopup. It is not the compiler dependency graph, runtime reachability, semantic authority review, acceptance or a test. External package types, multiline alias formatting errors, generated/runtime state, dynamic host authority and semantic invariants require separate review. Full source files and exact hashes govern. Each declaration retains its full source text and line number.

Local modules: 73. 

## ActionProjection

Source: `implementation/warlock/src/ActionProjection.elm`; SHA256 `911faed965465fac4e32f404d75a4d130b4e560cda191c7773eb96749be1d062`. Local imports: UInt64.

Line 8:

```elm
type Admitted = Admitted Counter (Maybe Counter) (List Window) (Dict String Counter)
```

Line 9:

```elm
type alias Window = { incarnation : Counter, label : String, minimized : Bool, owner : Maybe Counter, application : String, available : Bool, attention : Bool }
```

## AdapterNotice

Source: `implementation/warlock/src/AdapterNotice.elm`; SHA256 `32c4c13e599e843aa6da4a2302cb44da233226eb79d2561f551d0640fe9dd409`. Local imports: Binding, UInt64.

Line 9:

```elm
type Source = Applications | Notifications | Files | ApplicationActions | System | Settings | Motion | Shortcuts | Windows
```

Line 10:

```elm
type alias Notice = {source:Source,binding:Binding.Binding,request:Counter,service:Maybe Counter,revision:Maybe Counter}
```

## Announcement

Source: `implementation/warlock/src/Announcement.elm`; SHA256 `a1e6660c082c7c68657e356c2e4742cd8fd60e843192b88fa0609fb696a40f9f`. Local imports: AnnouncementMessage, SurfaceRenderer, UInt64.

Line 11:

```elm
type alias Message = AnnouncementMessage.Message
```

Line 12:

```elm
type Model = Model { last : Counter, active : Bool, message : Maybe Message }
```

## AnnouncementMessage

Source: `implementation/warlock/src/AnnouncementMessage.elm`; SHA256 `fb0f5231bff5beffe0a877046d38bba1bb87bd3d8e786449800093ae38ab2075`. Local imports: UInt64.

Line 6:

```elm
type alias Message = { interrupt : Bool, sequence : Counter, correlation : String, text : String }
```

## Bar

Source: `implementation/warlock/src/Bar.elm`; SHA256 `aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7`. Local imports: Announcement, Presentation, StatusScroll, SurfaceRenderer.

Line 19:

```elm
type Msg
    = Present D.Value
    | Action E.Value
    | Announce D.Value
    | ViewportSettled

-- Pure effect descriptions shared by port Bar, HttpBar, and StatusScrollReplay.
```

Line 26:

```elm
type Effect
    = Dispatch E.Value
    | ResetStatusViewport StatusScroll.Epoch String
```

Line 30:

```elm
type alias Model =
    { presentation : Presentation.Model
    , announcements : Announcement.Model
    , statusScroll : StatusScroll.Model
    }
```

## Binding

Source: `implementation/warlock/src/Binding.elm`; SHA256 `0cc99c46ec41da3433304cb14d8e0b324e71f476c8ca6b4a7fec79d359fab36b`. Local imports: UInt64.

Line 7:

```elm
type Binding = Binding Counter Counter Counter
```

## CapturedAction

Source: `implementation/warlock/src/CapturedAction.elm`; SHA256 `5c820d0c2f5167c42953b564d422429215e21ddf0a6dc955b3d3fe52b07d93cc`. Local imports: UInt64.

Line 8:

```elm
type CapturedAction = CapturedAction { publication : Counter, lease : Counter, surface : String, identity : String, trigger : Maybe String }
```

## Catalog

Source: `implementation/warlock/src/Catalog.elm`; SHA256 `3eadb76212a66986ef2d76292a2f33595f7cd7d47dc90c8982435195f9ea3f02`. Local imports: SearchFold, UInt64.

Line 7:

```elm
type EntryId = EntryId String
```

Line 8:

```elm
type alias Entry = { identity : EntryId, name : String, iconHint : String, wmclass : String, genericName : String, keywords : List String }
```

Line 9:

```elm
type Snapshot = Snapshot Counter Counter (Dict String Entry)
```

## Desktop

Source: `implementation/warlock/src/Desktop.elm`; SHA256 `91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4`. Local imports: ActionProjection, AdapterNotice, Binding, Catalog, Effects, Files, JumpList, Launch, Menu, MenuBridge, Motion, MotionPreferences, NativeProvider, Notifications, OverviewRecovery, Pins, PointerOwnership, Provider, Settings, Shell, ShortcutPreferences, Shortcuts, Snap, Switcher, SystemMenu, TaskView, Taskbar, TaskbarShell, Transfer, UInt64, WorkspaceInventory, WorkspaceNavigation.

Line 38:

```elm
type alias Model =
    { windows : TaskbarShell.Model
    , choice : Maybe Choice
    , choiceNotice : String
    , popupOrigin : PopupOrigin
    , returnFocus : Maybe FocusTarget
    , menuOrigin : Maybe FocusTarget
    , ownerScope : Maybe {outputId : Counter, providerId : Counter}
    , ownerExhausted : Bool
    , launch : Launch.Model
    , launchFromApplications : Bool
    , applications : Maybe Catalog.Snapshot
    , applicationPage : Int
    , presentationCapacity : Bool
    , pins : Pins.Model
    , pointer : PointerOwnership.Model
    , shortcuts : Shortcuts.Model
    , jumpList : JumpList.Model
    , jumpEntry : Maybe String
    , jumpOpening : Bool
    , jumpExpected : Maybe Counter
    , jumpBack : Bool
    , files : Files.Model
    , filesOpen : Bool
    , filesOpening : Bool
    , filesExpected : Maybe Counter
    , systemMenu : SystemMenu.Model
    , systemMenuOpen : Bool
    , systemMenuOpening : Bool
    , systemMenuExpected : Maybe Counter
    , systemMenuConfirmation : Maybe SystemMenu.Intent
    , notifications : Notifications.Model
    , notificationsOpen : Bool
    , notificationsOpening : Bool
    , notificationsExpected : Maybe Counter
    , motionExpected : Maybe Counter
    , motion : Motion.Model
    , settings : Settings.Model
    , settingsOpen : Bool
    , settingsOpening : Bool
    , settingsExpected : Maybe Counter
    , shortcutPreferences : ShortcutPreferences.Model
    , shortcutExpected : Maybe Counter
    , settingsHelp : Bool
    , query : String
    , open : Bool
    , overview : Bool
    , overviewWorkspace : Maybe String
    , workspaceNavigation : WorkspaceNavigation.Model
    , workspaceInventory : Maybe WorkspaceInventory.Snapshot
    , overviewRecovery : OverviewRecovery.Model
    , overviewTransfer : Maybe Counter
    , snap : Maybe Snap.Choice
    , switcher : Switcher.Model
    , nativeSwitcher : Maybe NativeChord
    , switcherOrigin : Maybe Counter
    , switcherExpected : Maybe Counter
    , switcherHistory : Maybe {context : {lifetime : Counter, epoch : Counter, output : Counter, revision : Counter}, roots : List Counter}
    , request : Counter
    , presentation : Maybe Counter
    , expected : Maybe Counter
    , adapterNotice : Maybe AdapterNotice.Notice
    , catalogFailure : Maybe { binding : Binding.Binding, request : Counter }
    , catalogOpening : Bool
    }
```

Line 104:

```elm
type PopupOrigin = PointerEntry | KeyboardEntry
```

Line 106:

```elm
type FocusDestination = TaskbarGroup String | OverviewOpener
```

Line 107:

```elm
type alias FocusTarget = {binding : Binding.Binding, destination : FocusDestination, output : Maybe Counter}
```

Line 109:

```elm
type alias NativeChord = {generation : Counter, roots : List Counter, history : List Counter, origin : Maybe Counter, steps : List Switcher.Direction, released : Bool, cancelled : Bool, consumed : Bool}
```

Line 111:

```elm
type ChoiceToken = ChoiceToken Binding.Binding Counter
```

Line 113:

```elm
type alias Choice = { chord : Maybe Counter, binding : Binding.Binding, output : Counter, root : Counter, application : String, token : ChoiceToken, placement : Maybe Snap.Proposal, transfer : Maybe Transfer.Proposal }
```

Line 118:

```elm
type ViewStamp = ViewStamp (Maybe Binding.Binding) Counter
```

Line 120:

```elm
type SaveReceipt = ReceiptSaved | ReceiptRefused | ReceiptUnknown
```

Line 122:

```elm
type ShortcutSaveReceipt = ShortcutSaved | ShortcutStored | ShortcutRefused | ShortcutUnknown
```

Line 152:

```elm
type Msg
    = SurfaceEntry PopupOrigin Msg
    | Window TaskbarShell.Msg
    | OpenWindowMenu Shell.Stamp Counter
    | OpenSnap ViewStamp Counter
    | SelectSnap ViewStamp Snap.Region
    | ApplySnap ViewStamp
    | CloseSnap ViewStamp
    | InvalidateSnap
    | OwnerScope D.Value
    | ScopedShortcut Shortcuts.Snapshot Bool
    | PresentationOwner (Maybe {outputId : Counter, providerId : Counter})
    | Incoming D.Value
    | OpenApplications ViewStamp
    | RefreshApplications ViewStamp
    | ApplicationsPage ViewStamp Int
    | PresentationCapacity
    | PinsUnsent Binding.Binding Counter
    | OpenJumpList ViewStamp String
    | CloseJumpList ViewStamp
    | RefreshJumpList ViewStamp
    | JumpAction ViewStamp JumpList.Intent
    | OpenFiles ViewStamp
    | CloseFiles ViewStamp
    | RefreshFiles ViewStamp
    | EditFilesPath ViewStamp String
    | OpenFilesTarget ViewStamp Files.Intent
    | OpenFilesPath ViewStamp
    | OpenSystemMenu ViewStamp
    | CloseSystemMenu ViewStamp
    | RefreshSystemMenu ViewStamp
    | SystemChange ViewStamp SystemMenu.Intent
    | ConfirmSystemChange ViewStamp SystemMenu.Intent
    | CancelSystemChange ViewStamp
    | OpenNotifications ViewStamp
    | CloseNotifications ViewStamp
    | NotificationFocus ViewStamp String
    | RefreshNotifications ViewStamp
    | ConfigureNotificationPolicy ViewStamp Notifications.Policy
    | NotificationAction ViewStamp Notifications.Target
    | OpenSettings ViewStamp
    | CloseSettings ViewStamp
    | ToggleSettingsHelp ViewStamp
    | EditShortcutChoice ViewStamp String ShortcutPreferences.Choice
    | SaveShortcutChoices ViewStamp
    | RefreshShortcutChoices ViewStamp
    | EditSettings ViewStamp Settings.Values
    | SaveSettings ViewStamp
    | EditMotionPreference ViewStamp MotionPreferences.Override
    | SaveMotionPreference ViewStamp
    | RefreshMotionPreference ViewStamp
    | RefreshSettings ViewStamp
    | OpenOverview ViewStamp
    | OpenSwitcher ViewStamp Switcher.Direction
    | SwitcherStep ViewStamp Switcher.Direction
    | SwitcherChoose ViewStamp Counter
    | CommitSwitcher ViewStamp
    | CloseSwitcher ViewStamp
    | CloseOverview ViewStamp
    | OverviewNavigateWorkspace ViewStamp String
    | RefreshWorkspaceNavigation ViewStamp
    | WorkspaceNavigationDeadline WorkspaceNavigation.Intent
    | OverviewWorkspace ViewStamp (Maybe String)
    | OverviewChoose ViewStamp Counter
    | OpenOverviewTransfer ViewStamp Counter
    | CancelOverviewTransfer ViewStamp
    | OverviewTransfer ViewStamp Counter String
    | CloseApplications ViewStamp
    | SearchQuery ViewStamp String
    | TogglePin ViewStamp String
    | MovePin ViewStamp String Int
    | CatalogUnsent Binding.Binding Counter
    | NewInstance ViewStamp String
    | Start Launch.Selection
    | Deadline Launch.PendingToken
    | ChoiceDeadline ChoiceToken
    | RetryWindows
    | Acknowledge Launch.Acknowledgement
```

Line 231:

```elm
type Effect
    = WindowEffect Shell.Effect
    | Send E.Value
    | Arm Launch.PendingToken
    | ArmChoice ChoiceToken
    | ArmWorkspaceNavigation WorkspaceNavigation.Intent
    | Focus String
```

## DesktopPolicy

Source: `implementation/warlock/src/DesktopPolicy.elm`; SHA256 `018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e`. Local imports: Desktop, OutputController, Shell, SurfaceController, TaskbarShell.

Line 11:

```elm
type alias Model = {controller : Outputs.Model}
```

Line 13:

```elm
type Msg = Incoming D.Value | Deadline Desktop.Msg | TransportLost
```

Line 15:

```elm
type Effect = Publish E.Value | Delay Float Desktop.Msg
```

## Effects

Source: `implementation/warlock/src/Effects.elm`; SHA256 `80c574e8c564c28a1fb11f1f89bb5bfa7ac97a92474bbf027a737324bb2a82cd`. Local imports: ActionProjection, GeometryProjection, Snap, Transfer, UInt64.

Line 12:

```elm
type Operation = Minimize | Restore | Activate | Maximize | RestoreGeometry | ExitFullscreen | SnapPlacement Snap.Proposal | TransferWorkspace Transfer.Proposal | Pin | Unpin
```

Line 13:

```elm
type Status = Pending | Committed | Refused | Cancelled | Unknown
```

Line 15:

```elm
type alias Context = { lifetime : Counter, epoch : Counter, output : Counter, revision : Counter }
```

Line 16:

```elm
type alias Snapshot = { context : Context, scene : Scene.Admitted }
```

Line 17:

```elm
type alias Intent = { request : Counter, generation : Counter, incarnation : Counter, operation : Operation, context : Context }
```

Line 18:

```elm
type alias Transaction = { intent : Intent, status : Status, effectProtocol : Int }
```

Line 19:

```elm
type alias Model = { connected : Bool, observed : Maybe Snapshot, request : Counter, generation : Counter, transaction : Maybe Transaction, unresolved : List Transaction }
```

## Files

Source: `implementation/warlock/src/Files.elm`; SHA256 `c2099647bca3b325ca21485bb3a246e0b6d7c2a693d0bcfd5f10dedbad7a89f7`. Local imports: UInt64.

Line 7:

```elm
type alias Peer = { pid : Counter, start : Counter, instance : String, target : String, visible : Bool }
```

Line 8:

```elm
type alias Snapshot = { service : Counter, revision : Counter, available : Bool, reason : String, peer : Maybe Peer }
```

Line 9:

```elm
type alias Intent = { service : Counter, revision : Counter, target : String }
```

Line 10:

```elm
type alias Model = { snapshot : Maybe Snapshot, draft : String, pending : Maybe { request : Counter, intent : Intent }, spent : List Intent, notice : String }
```

## GeometryProjection

Source: `implementation/warlock/src/GeometryProjection.elm`; SHA256 `f1b5708b8b4d1c7c02e46542bc041abb9e8cb0524d965ee4b03ab97f586a544c`. Local imports: Binding, GeometrySizePolicy, UInt64, WorkspaceInventory.

Line 10:

```elm
type Mode = Ordinary | Maximized | Fullscreen
```

Line 11:

```elm
type alias Context = { lifetime : Counter, epoch : Counter, output : Counter, revision : Counter }
```

Line 12:

```elm
type alias Capabilities = { effects : Bool, operations : List String }
```

Line 13:

```elm
type alias Window =
    { incarnation : Counter, owner : Maybe Counter, workspace : Maybe String, workspaceGeneration : Maybe Counter
    , monitor : Maybe Counter, outputOwnershipGeneration : Maybe Counter, workAreaRevision : Maybe Counter
    , workArea : Maybe (List Float), logicalGeometry : List Float, visualGeometry : List Float
    , nativeMode : Mode, clientMode : Mode, minimized : Bool, floating : Bool, grouped : Bool
    , fixedSize : Bool, constrainedSize : Bool, eligible : Bool, placementKnown : Bool
    , maximize : Bool, restoreGeometry : Bool, sizePolicy : Maybe GeometrySizePolicy.Policy, pin : Maybe { pinned : Bool, eligible : Bool } }
```

Line 20:

```elm
type alias Snapshot = { binding : Binding.Binding, request : Counter, sequence : Counter, context : Context, focused : Maybe Counter, blocked : Bool, windows : List Window }
```

## GeometrySizePolicy

Source: `implementation/warlock/src/GeometrySizePolicy.elm`; SHA256 `46dda2de43642cd33997382e90813c8eeccde80745d79b7d5cd5fd425b062c43`. Local imports: none.

Line 5:

```elm
type alias Pair = ( Float, Float )
```

Line 6:

```elm
type alias Box = { x : Float, y : Float, width : Float, height : Float }
```

Line 7:

```elm
type alias Inputs =
    { rawMinimum : Pair, rawMaximum : Pair, layoutMinimum : Pair, layoutMaximum : Pair
    , origin : Pair, topLeft : Pair, bottomRight : Pair, scale : Float }
```

Line 10:

```elm
type alias Projection = { logical : Box, visual : Maybe Box, real : Box, configure : Pair }
```

Line 11:

```elm
type alias Policy = { inputs : Maybe Inputs, maximize : Maybe Projection, restoreGeometry : Maybe Projection }
```

## HttpBar

Source: `implementation/warlock/src/HttpBar.elm`; SHA256 `74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8`. Local imports: Bar, Presentation, SurfaceRenderer, UiHttp.

Line 13:

```elm
type alias Model = {bar : Bar.Model,http : UiHttp.Model}
```

Line 14:

```elm
type Msg = View Bar.Msg | Transport UiHttp.Msg | Focused
```

## HttpMain

Source: `implementation/warlock/src/HttpMain.elm`; SHA256 `58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9`. Local imports: DesktopPolicy, UiHttp.

Line 10:

```elm
type alias Model = {policy : Policy.Model,http : UiHttp.Model}
```

Line 11:

```elm
type Msg = PolicyMessage Policy.Msg | Transport UiHttp.Msg

-- A lost delivery changes knowledge through the same policy reducer. It does
-- not rebind, retry a mutation or turn an HTTP response into a native receipt.
```

## HttpPopup

Source: `implementation/warlock/src/HttpPopup.elm`; SHA256 `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354`. Local imports: Popup, Presentation, SurfaceRenderer, UiHttp.

Line 14:

```elm
type alias Model = {popup : Popup.Model,http : UiHttp.Model}
```

Line 15:

```elm
type Msg = View Popup.Msg | Transport UiHttp.Msg | Focused

-- No native preview producer is qualified for this HTTP profile. Empty
-- descriptions are inert; a real command remains unconfirmed and fails closed.
```

## JumpList

Source: `implementation/warlock/src/JumpList.elm`; SHA256 `059841cc0669fdc7fd699498ee72d4211a2aa5d69c466d4aade7558e03b0f68c`. Local imports: UInt64.

Line 6:

```elm
type alias Action = { id : String, label : String, kind : String }
```

Line 7:

```elm
type alias Snapshot = { service : Counter, revision : Counter, entry : String, name : String, available : Bool, reason : String, actions : List Action }
```

Line 8:

```elm
type alias Intent = { service : Counter, revision : Counter, entry : String, action : String }
```

Line 9:

```elm
type alias Model = { snapshot : Maybe Snapshot, pending : Maybe { request : Counter, intent : Intent }, spent : List Intent, notice : String }
```

## Launch

Source: `implementation/warlock/src/Launch.elm`; SHA256 `dcd7260248ccb0b5bc6001c49319dd51af8c2fae98888919a308ac025ed273a2`. Local imports: Catalog, UInt64.

Line 9:

```elm
type alias Intent =
    { request : Counter, lifetime : Counter, generation : Counter, entry : String }
```

Line 13:

```elm
type ResultState
    = Submitted
    | Refused
    | Unknown
```

Line 19:

```elm
type Phase
    = Idle
    | Pending String Intent
    | Settled Intent ResultState
```

Line 25:

```elm
type Model
    = Model
        { host : Maybe String
        , snapshot : Maybe Catalog.Snapshot
        , revision : Counter
        , request : Counter
        , phase : Phase
        }
```

Line 35:

```elm
type PendingToken
    = PendingToken String Intent
```

Line 39:

```elm
type Acknowledgement
    = Acknowledgement Intent
```

Line 43:

```elm
type Selection
    = Selection String Counter Counter Counter Catalog.EntryId
```

## Main

Source: `implementation/warlock/src/Main.elm`; SHA256 `a63de0a105e1a13edc5eb67359b665032acba662650659b3a24d4f1999058b66`. Local imports: DesktopPolicy.

No local top-level type declarations.

## Menu

Source: `implementation/warlock/src/Menu.elm`; SHA256 `c40fcfa24bf9d48044ccbe2c08df0abb7d8b94ee04111776234ecd88792ff4f0`. Local imports: none.

Line 47:

```elm
type WindowId
    = WindowId String String
```

Line 51:

```elm
type AppId
    = AppId String
```

Line 55:

```elm
type ProviderId
    = ProviderId String
```

Line 59:

```elm
type OutputId
    = OutputId String
```

Line 63:

```elm
type DeclaredActionId
    = DeclaredActionId String
```

Line 67:

```elm
type MenuId
    = MenuId Int
```

Line 71:

```elm
type IntentId
    = IntentId Int
```

Line 75:

```elm
type Target
    = Window WindowId
    | Application AppId String
    | ProviderSelection ProviderId String (List String)
    | Background OutputId String
```

Line 82:

```elm
type Binding
    = Binding
        { authority : String
        , revision : String
        , output : OutputId
        , outputGeneration : String
        , target : Target
        }
```

Line 122:

```elm
type Action
    = Restore
    | RestoreGeometry
    | Move
    | Size
    | Minimize
    | Maximize
    | Close
    | ExitFullscreen
    | AlwaysOnTop Bool
    | PinToTaskbar Bool
    | Launch DeclaredActionId
    | ProviderCommand DeclaredActionId
```

Line 137:

```elm
type alias Item =
    { label : String, enabled : Bool, action : Action }
```

Line 141:

```elm
type Navigation
    = Up
    | Down
    | Home
    | End
```

Line 148:

```elm
type Outcome
    = Committed
    | Refusal String
    | Cancellation
    | Uncertain
```

Line 155:

```elm
type Status
    = Ready
    | Pending IntentId
    | Refused String
    | Cancelled
    | Unknown IntentId
```

Line 163:

```elm
type alias MenuSnapshot =
    { id : MenuId
    , binding : Binding
    , items : List Item
    , selected : Maybe Int
    , status : Status
    }
```

Line 172:

```elm
type alias Snapshot =
    { menu : Maybe MenuSnapshot
    , lastOutcome : Maybe ( IntentId, Outcome )
    , outstanding : Int
    , releasedUnknown : Int
    , invalidatedCount : Int
    , retiredOutputCount : Int
    , exhausted : Bool
    }
```

Line 183:

```elm
type alias Outstanding =
    { id : IntentId, binding : Binding, uncertain : Bool }
```

Line 187:

```elm
type Model
    = Model
        { menu : Maybe MenuSnapshot
        , nextMenu : Int
        , nextIntent : Int
        , outstanding : List Outstanding
        , releasedUnknown : List Outstanding
        , lastOutcome : Maybe ( IntentId, Outcome )
        , invalidated : List Binding
        , retiredOutputs : List ( OutputId, String )
        , exhausted : Bool
        }
```

Line 201:

```elm
type Msg
    = Open Binding (List Item)
    | Select MenuId Binding Int
    | Navigate MenuId Navigation
    | Activate MenuId Binding Int
    | ReceiveFor IntentId Binding Outcome
    | Dismiss MenuId
    | Invalidate Binding
    | OutputRetired OutputId String
```

Line 212:

```elm
type Effect
    = Dispatch IntentId Binding Action
```

## MenuBridge

Source: `implementation/warlock/src/MenuBridge.elm`; SHA256 `ec8f531b9437e493f9b29fe1e16d678cd388f560a83ca873448630bbde459b25`. Local imports: ActionProjection, Binding, Effects, GeometryProjection, Menu, NativeProvider, Provider, ReceiptRouter, Shell, UInt64, UnsentOperation.

Line 35:

```elm
type alias CapturedProvider =
    { snapshot : Provider.Snapshot, stamp : Shell.Stamp }
```

Line 39:

```elm
type Model
    = Model
        { menu : Menu.Model
        , router : ReceiptRouter.Model
        , provider : Maybe CapturedProvider
        , prepared : Maybe Prepared
        , preparedSerial : Counter
        }
```

Line 49:

```elm
type alias Prepared =
    { dispatch : Menu.Effect, local : Menu.IntentId, originalBinding : Menu.Binding
    , menuId : Menu.MenuId, action : Menu.Action, captured : CapturedProvider
    , legacyWindows : List ActionProjection.Window
    , geometryCaps : Maybe GeometryProjection.Capabilities
    , token : Counter, legacyRequest : Counter, geometryRequest : Maybe Counter
    , legacyReady : Bool, geometryReady : Bool
    }
```

Line 59:

```elm
type alias PreparedSnapshot =
    { token : Counter, legacyRequest : Counter, geometryRequest : Maybe Counter
    , legacyReady : Bool, geometryReady : Bool }
```

Line 69:

```elm
type alias UpdateResult =
    { bridge : Model
    , shell : Shell.Model
    , effects : List Shell.Effect
    , error : Maybe String
    }
```

## Motion

Source: `implementation/warlock/src/Motion.elm`; SHA256 `e101862bae874426f0cf9aaf02340c6582abdeea21dec38c32003da7f94e8a69`. Local imports: Binding, MotionPreferences, UInt64.

Line 9:

```elm
type Profile = Reduced | Full
```

Line 10:

```elm
type alias Observation = { serial : Counter, profile : Profile, source : String }
```

Line 11:

```elm
type alias Pending = { binding : Binding.Binding, request : Counter, profile : Profile }
```

Line 12:

```elm
type alias Receipt = Pending
```

Line 13:

```elm
type alias Model = { preferences : MotionPreferences.Model, observation : Maybe Observation, pending : Maybe Pending, applied : Maybe { binding : Binding.Binding, profile : Profile } }
```

## MotionPreferences

Source: `implementation/warlock/src/MotionPreferences.elm`; SHA256 `d3130d74c3172cb1808df38efd7a2cc267ba5ae346b564544661d3d539f5c560`. Local imports: UInt64.

Line 7:

```elm
type Override = System | Reduce | Full
```

Line 8:

```elm
type alias Snapshot = { revision : Counter, override : Override }
```

Line 9:

```elm
type alias Model = { snapshot : Maybe Snapshot, draft : Override, pending : Maybe { request : Counter, revision : Counter, override : Override }, notice : String }
```

## NativeActorRetirement

Source: `implementation/warlock/src/NativeActorRetirement.elm`; SHA256 `72302b23ea124f45879b176a959b3a5bbd80edbb986bfec631994051bcae31a6`. Local imports: UInt64.

Line 7:

```elm
type alias Observation =
    { lifetime : Counter, session : Counter, frontend : Counter, subject : Counter
    , request : Counter, sequence : Counter, clock : Counter, now : Counter, issuedThrough : Counter }
```

Line 11:

```elm
type alias Fact =
    { native : Observation, entry : Counter, entryIssuedThrough : Counter, requestFloor : Counter }
```

Line 14:

```elm
type alias Delivery =
    { ordinal : Counter, fact : Fact }
```

Line 17:

```elm
type alias Ledger =
    { observed : Maybe Observation, settled : Maybe Fact, channel : Maybe String, processed : Counter }
```

## NativeFamilyPreviewSource

Source: `implementation/warlock/src/NativeFamilyPreviewSource.elm`; SHA256 `dc93a0698cb1bc13c37f9e56c221d356f1c6aea3d4651b71df7d4f7c178d8321`. Local imports: PreviewLifecycle, UInt64.

Line 9:

```elm
type Plane = Transparent | PickerTransparent | GeneratedOpaque Counter
```

Line 11:

```elm
type Observation = Observation { plane : Plane, native : Preview.Scope, raw : D.Value, crop : Crop, members : List Member, styles : List Style, request : Counter, maximum : Counter }
```

Line 12:

```elm
type alias Crop = { x : String, y : String, width : Int, height : Int, scale : Float }
```

Line 13:

```elm
type alias Member = { incarnation : Counter, parent : Maybe Counter, content : Counter, order : Int, flags : Int, geometry : List Float }
```

Line 14:

```elm
type alias Style = { incarnation : Counter, flags : Int, channels : List Float, gradients : List Gradient }
```

Line 15:

```elm
type alias Gradient = { angle : Float, colors : Int }
```

## NativeOutcome

Source: `implementation/warlock/src/NativeOutcome.elm`; SHA256 `79252d7e3fefa4a4ca93dfe4d6fc18552b710d514ec1cdb4521d1ecea9c8c2e6`. Local imports: Binding, Effects, UInt64.

No local top-level type declarations.

## NativePreviewDetachment

Source: `implementation/warlock/src/NativePreviewDetachment.elm`; SHA256 `39fe1ece48568a5a264d7b018df41322bab97f73cbe0f55a92559ecccb25a47a`. Local imports: NativePreviewRealm, UInt64.

Line 10:

```elm
type alias Seed = { domain : Realm.Domain, subject : Counter, entry : Counter, entryIssuedThrough : Counter, requestFloor : Counter }
```

Line 11:

```elm
type alias Delivery = { ordinal : Counter, seed : Seed }
```

## NativePreviewProposalIngress

Source: `implementation/warlock/src/NativePreviewProposalIngress.elm`; SHA256 `b3fc80b316a9b0f90e107c65f35cb0e136a9ae4acce441e3fdf2b69d4994285d`. Local imports: NativePreviewRealm, UInt64.

Line 9:

```elm
type alias Intent = { identity : String, command : E.Value }
```

Line 10:

```elm
type Model = Model Realm.Grant (List Intent)
```

Line 11:

```elm
type alias Proposal = { protocol : Int, kind : String, domain : Realm.Domain, rows : List Intent }
```

Line 12:

```elm
type alias Ticket = { protocol : Int, kind : String, domain : Realm.Domain, ordinal : UInt64.Counter, advisory : Bool, wire : String }
```

Line 13:

```elm
type alias Packet = { protocol : Int, kind : String, domain : Realm.Domain, ordinal : UInt64.Counter, intents : List Intent }
```

## NativePreviewRealm

Source: `implementation/warlock/src/NativePreviewRealm.elm`; SHA256 `2a3de2f3eacdf5b00489e5c1f5e5cef058e8f36d74fefecb25a5d3d9ea6024cf`. Local imports: UInt64.

Line 7:

```elm
type alias Domain =
    { lifetime : Counter, session : Counter, frontend : Counter, receiverEpoch : Counter }
```

Line 10:

```elm
type alias Grant = { domain : Domain, capacity : Int }
```

Line 11:

```elm
type Envelope = Envelope Domain D.Value
```

## NativePreviewSource

Source: `implementation/warlock/src/NativePreviewSource.elm`; SHA256 `9177298d05a999f3a28660df9a76b8be7cafcda523e7cc20fe73bc471b7c37e9`. Local imports: NativeFamilyPreviewSource, PreviewLifecycle, UInt64.

Line 9:

```elm
type Source = MonitorPlane | ClientMain | StyleCroppedFamily | PickerFamily | GeneratedBackdropFamily Counter
```

Line 10:

```elm
type Observation = Observation { source : Source, native : Preview.Scope, raw : D.Value, request : Counter, maximumTransferBytes : Counter }
```

## NativeProvider

Source: `implementation/warlock/src/NativeProvider.elm`; SHA256 `18aa48711825c7bfd3621fe8566d65f84387805434669591f43d1edaf4766ed9`. Local imports: ActionProjection, Binding, GeometryProjection, Provider, Shell, UInt64.

Line 18:

```elm
type alias Scope =
    { outputId : Counter, providerId : Counter, capabilityGeneration : Counter }
```

## Notifications

Source: `implementation/warlock/src/Notifications.elm`; SHA256 `b37bff9f104d80eb1d1ea99f297c4d859b9d5744d7b0c05f6c89fa51581bc244`. Local imports: UInt64.

Line 8:

```elm
type Urgency = Low | Normal | Critical
```

Line 9:

```elm
type alias Policy = { doNotDisturb : Bool, interruptCritical : Bool }
```

Line 10:

```elm
type alias Entry = { urgency : Urgency, id : Counter, incarnation : Counter, producer : String, app : String, summary : String, body : String, state : String, actions : List { key : String, label : String } }
```

Line 11:

```elm
type alias Snapshot = { service : Counter, revision : Counter, available : Bool, reason : String, entries : List Entry }
```

Line 12:

```elm
type alias Target = { service : Counter, id : Counter, incarnation : Counter, producer : String, action : String, verb : String }
```

Line 13:

```elm
type alias Model = { focused : Maybe {target:Target,label:String}, outcome : Maybe {request:Counter,target:Target,status:String,expired:Bool}, policy : Policy, snapshot : Maybe Snapshot, pending : Maybe { request : Counter, target : Target, expired : Bool }, spent : List Target, notice : String }
```

## OutcomeAnnouncements

Source: `implementation/warlock/src/OutcomeAnnouncements.elm`; SHA256 `ea57b2c448f5f510ceef256bc0670bd464fc997d29d144741ab1ce3fd004d709`. Local imports: AdapterNotice, AnnouncementMessage, Binding, Catalog, Desktop, Effects, Launch, Notifications, Settings, Surface, UInt64.

Line 19:

```elm
type Model = Model Counter (Maybe AnnouncementMessage.Message)
```

## OutputController

Source: `implementation/warlock/src/OutputController.elm`; SHA256 `fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae`. Local imports: Binding, Desktop, MenuBridge, OutcomeAnnouncements, Pins, PointerOwnership, Shell, Shortcuts, Surface, SurfaceController, SurfaceSnapshot, TaskbarShell, UInt64, UnsentOperation.

Line 21:

```elm
type Scope = Scope Counter Counter
```

Line 23:

```elm
type Model = Model
    { announcements : OutcomeAnnouncements.Model
    , controller : Controller.Model
    , revision : Counter
    , highest : Counter
    , views : List Scope
    , locations : List {scope : Scope, box : Shortcuts.Box}
    , selected : Maybe Scope
    , batches : List Batch
    , batchExhausted : Bool
    , capacityRefused : Bool
    }
```

Line 36:

```elm
type alias CatalogRequest = { binding : Binding.Binding, request : Counter }
```

Line 37:

```elm
type alias Batch = { scope : Scope, revision : Counter, publication : Counter, lease : Counter, binding : Binding.Binding, wire : String, observations : List (String,Counter), operations : List UnsentOperation.Key, catalogs : List CatalogRequest }
```

Line 39:

```elm
type Event = Disposition D.Value | Topology D.Value | Renderer D.Value | Interaction Desktop.Msg | Dismiss D.Value | Escape D.Value | Reflow D.Value
```

## OverviewRecovery

Source: `implementation/warlock/src/OverviewRecovery.elm`; SHA256 `df247594319b088baa321ac9b5d4b5f2daeec5780298178ca0724f7ec17d8e0e`. Local imports: Binding, Effects, UInt64.

Line 8:

```elm
type alias Origin = { binding : Binding.Binding, root : Counter, workspace : Maybe String }
```

Line 9:

```elm
type Model = Idle | Choosing Origin Counter | Issued Origin Effects.Intent | Returning Origin Effects.Intent
```

## Pins

Source: `implementation/warlock/src/Pins.elm`; SHA256 `c44da7aa32a193fc998d4efc39af25067998adc37d67da6d0c5b834f073635a4`. Local imports: UInt64.

Line 7:

```elm
type alias Snapshot = { revision : Counter, identities : List String }
```

Line 8:

```elm
type Confirmation = Saving | Unconfirmed (Maybe Counter)
```

Line 9:

```elm
type alias Model = { snapshot : Maybe Snapshot, pending : Maybe {request : Counter, identities : List String, confirmation : Confirmation}, notice : String }
```

## PointerOwnership

Source: `implementation/warlock/src/PointerOwnership.elm`; SHA256 `7e6d9f3e1ad79670383f58502449533d8a0857d38c6b62538eb89855a70b3ef3`. Local imports: Binding, UInt64.

Line 5:

```elm
type State = Idle | Moving | Resizing
```

Line 6:

```elm
type alias Snapshot = { binding : Binding.Binding, serial : Counter, state : State, owner : Maybe Counter }
```

Line 7:

```elm
type alias Model = { observation : Maybe Snapshot }
```

## Popup

Source: `implementation/warlock/src/Popup.elm`; SHA256 `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58`. Local imports: Announcement, NativePreviewRealm, Presentation, PreviewPaintGate, RetainedPreviewPresenter, SurfaceRenderer, UInt64.

Line 32:

```elm
type Msg = Announce D.Value | Present D.Value | Action E.Value | LocalAction E.Value | NativePreview D.Value | PreviewPainted D.Value | NativeGrant D.Value | NativeQuarantine D.Value | NativeClosed D.Value | NativeIssued D.Value | NativeRetry D.Value | NativeRetirement D.Value
```

Line 33:

```elm
type Composition = Idle | Preediting { baseline : String, before : Maybe String }

-- Pure effect descriptions are shared by the statically selected transports.
```

Line 36:

```elm
type Effect = Dispatch E.Value | PreviewCommand E.Value | PaintRequest E.Value
```

Line 37:

```elm
type alias Model = { announcements : Announcement.Model, presentation : Presentation.Model, previews : Preview.Model, paintGate : PreviewPaintGate.Model, pendingQuery : Maybe String, composition : Composition, lastQuery : Maybe (String, UInt64.Counter, UInt64.Counter) }
```

## Presentation

Source: `implementation/warlock/src/Presentation.elm`; SHA256 `745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396`. Local imports: CapturedAction, SurfaceSnapshot, UInt64.

Line 9:

```elm
type Model = Model { last : Counter, lease : Counter, snapshot : Maybe SurfaceSnapshot.Snapshot }
```

## PreviewIdentity

Source: `implementation/warlock/src/PreviewIdentity.elm`; SHA256 `262240e59eed37d362f921a4e7e89d0bb23c8b0f84fb39f0fddc29faaa3de3b5`. Local imports: UInt64.

Line 9:

```elm
type Identity domain = Identity UInt64.Counter
```

Line 10:

```elm
type Lifetime = LifetimeTag
```

Line 11:

```elm
type Session = SessionTag
```

Line 12:

```elm
type Frontend = FrontendTag
```

Line 13:

```elm
type Incarnation = IncarnationTag
```

Line 14:

```elm
type Output = OutputTag
```

Line 15:

```elm
type Privacy = PrivacyTag
```

Line 16:

```elm
type Rendering = RenderingTag
```

Line 17:

```elm
type Scene = SceneTag
```

Line 18:

```elm
type Content = ContentTag
```

Line 19:

```elm
type Observation = ObservationTag
```

Line 20:

```elm
type Receipt = ReceiptTag
```

Line 21:

```elm
type Clock = ClockTag
```

Line 22:

```elm
type Request = RequestTag
```

Line 23:

```elm
type Origin = OriginTag
```

Line 24:

```elm
type MonotonicTime = MonotonicTimeTag
```

## PreviewLifecycle

Source: `implementation/warlock/src/PreviewLifecycle.elm`; SHA256 `232ebe2e823a4f9b07444f9afaccd98cdc3de9a592ff220d9975a64952dacf24`. Local imports: PreviewIdentity, PreviewVisual.

Line 12:

```elm
type alias Binding = { lifetime : I.Identity I.Lifetime, session : I.Identity I.Session, frontend : I.Identity I.Frontend }
```

Line 13:

```elm
type alias Context = { lifetime : I.Identity I.Lifetime, incarnation : I.Identity I.Incarnation, output : I.Identity I.Output, privacy : I.Identity I.Privacy, rendering : I.Identity I.Rendering, scene : I.Identity I.Scene, content : I.Identity I.Content }
```

Line 14:

```elm
type alias NativeScope = { binding : Binding, context : Context, observation : I.Identity I.Observation, clock : I.Identity I.Clock, now : I.Identity I.MonotonicTime, present : Bool, sourceLive : Bool, locked : Bool, gpuReady : Bool }
```

Line 15:

```elm
type Scope = Scope NativeScope
```

Line 16:

```elm
type alias Trigger = { binding : Binding, context : Context, origin : I.Identity I.Origin, clock : I.Identity I.Clock, deadline : I.Identity I.MonotonicTime }
```

Line 17:

```elm
type alias Job = { binding : Binding, context : Context, request : I.Identity I.Request, origin : I.Identity I.Origin, clock : I.Identity I.Clock, deadline : I.Identity I.MonotonicTime }
```

Line 18:

```elm
type LeaseHandle = LeaseHandle String
```

Line 19:

```elm
type IconHandle = IconHandle String
```

Line 20:

```elm
type Fidelity = ClientContent | ComposedFamily
```

Line 21:

```elm
type alias Packet = { job : Job, handle : LeaseHandle, owned : Bool, signaled : Bool, fidelity : Fidelity, coverage : Set String, expires : I.Identity I.MonotonicTime }
```

Line 22:

```elm
type Candidate = Candidate Packet
```

Line 23:

```elm
type Accepted = Accepted Packet
```

Line 24:

```elm
type Capture = Idle | Capturing Job | WaitingFence Candidate
```

Line 25:

```elm
type Connection = Connected | SourceSuspended | NeedsReconciliation
```

Line 26:

```elm
type Status = Live Accepted | Historical Accepted | Loading | Unavailable
```

Line 27:

```elm
type alias State = { metadataHidden : Bool, scope : NativeScope, demand : Bool, connection : Connection, nextRequest : Maybe (I.Identity I.Request), capture : Capture, accepted : Maybe Accepted, known : List Job, cancelling : List Job, retiring : List Packet, lastTerminal : Maybe ( Job, I.Identity I.Receipt ) }
```

Line 28:

```elm
type Model = Model State
```

Line 29:

```elm
type Command = Acquire Job | Cancel Job | Release Packet | Reconcile Binding | Acknowledge Job (I.Identity I.Receipt)
```

Line 30:

```elm
type Event = Open | Close | Request Trigger | Offer Packet | Fence Packet | Observe NativeScope | SourceDenied Job String | Attach Binding NativeScope | Clock Binding (I.Identity I.Clock) (I.Identity I.MonotonicTime) | Cancelled Job | Released Packet | Expired Packet | Exhausted Binding | Refused Job | Receipt (I.Identity I.Receipt) Event
```

Line 31:

```elm
type alias Work = { state : State, effects : List Command }
```

## PreviewPaintGate

Source: `implementation/warlock/src/PreviewPaintGate.elm`; SHA256 `29336cc6d6b21c3d32fd4967911bb189c42b1569ed877ffe79555ed30a7c7d82`. Local imports: UInt64.

Line 10:

```elm
type alias Pending = { identity : String, job : String, command : E.Value }
```

Line 11:

```elm
type Model = Model Counter (Dict String Pending)
```

## PreviewPresenter

Source: `implementation/warlock/src/PreviewPresenter.elm`; SHA256 `10769b8d9a86e5e5b35f1f292d9837a38b20a0ba636d5baa0ee0c3b8fcdac1cc`. Local imports: NativeActorRetirement, NativePreviewDetachment, NativePreviewRealm, NativePreviewSource, PreviewLifecycle, PreviewVisual, SurfaceRenderer, UInt64.

Line 18:

```elm
type alias Stamp = { publication : Counter, lease : Counter }
```

Line 19:

```elm
type LocalOutcome = Capacity | Waiting | Expired | Conflict | Exhausted
```

Line 20:

```elm
type alias LocalFeedback = { owner : String, subject : Counter, clock : Counter, stamp : Stamp, sequence : Counter, deadline : Counter, outcome : LocalOutcome }
```

Line 21:

```elm
type alias Entry = { model : Maybe Preview.Model, binding : String, source : Maybe NativePreviewSource.Source, stamp : Maybe Stamp, title : String, application : String, icon : Maybe Preview.IconHandle, iconKind : String, metadataRevision : Maybe Counter, minimized : Maybe Bool, local : Maybe LocalFeedback, feedbackFloor : Maybe Counter, retirement : Maybe Retirement.Observation, readySent : Bool, detachment : Maybe Detachment.Seed, detachReadySent : Bool }
```

Line 22:

```elm
type alias CatalogStamp = { binding : String, request : Counter, sequence : Counter, revision : Counter }
```

Line 23:

```elm
type alias Window = { subject : Counter, title : String, application : String, minimized : Bool }
```

Line 24:

```elm
type alias Scoped = { grant : Maybe Realm.Grant, closing : Bool, closed : Bool, processed : Counter, completed : Dict String (Counter,Detachment.Seed) }
```

Line 29:

```elm
type Model = Model (Dict String Entry) (Maybe CatalogStamp) Retirement.Ledger Scoped
```

Line 30:

```elm
type Input = Seed Stamp String Preview.Scope D.Value String String String (Maybe NativePreviewSource.Source) Bool (Maybe Counter) | Metadata String String Counter Counter String String (Maybe Preview.IconHandle) String | Event String Preview.Event D.Value | Catalog Stamp CatalogStamp (List Window) | Feedback String LocalFeedback | Retirement Retirement.Observation | Retired Retirement.Fact | RetirementChannel String | RetirementDelivery Retirement.Delivery | DetachSeed Detachment.Seed | Detached Detachment.Delivery
```

Line 31:

```elm
type alias Output = { identity : String, commands : List Preview.Command }
```

## PreviewVisual

Source: `implementation/warlock/src/PreviewVisual.elm`; SHA256 `5c285bd8c6fde00b4e1082edfd10e59e281264a4f45b15cea9b5ce0920dd039a`. Local imports: none.

Line 11:

```elm
type State = Live | Historical | Loading | Unavailable
```

Line 12:

```elm
type LocalState = Capacity | Waiting | Expired | Conflict | Exhausted
```

Line 13:

```elm
type Fidelity = Client | Family
```

Line 14:

```elm
type Visual
    = Hidden
    | Fallback
    | Local LocalState String
    | Lifecycle { state : State, title : Maybe String, icon : Maybe String, frame : Maybe String, fidelity : Maybe Fidelity }
```

## Provider

Source: `implementation/warlock/src/Provider.elm`; SHA256 `2ef450a364d23d334e2ba7dfafdc56bbf51649dfb8f2e9f2e0ab1ca600157727`. Local imports: Binding, GeometryProjection, Menu, UInt64.

Line 30:

```elm
type Snapshot
    = Snapshot
        { binding : Menu.Binding
        , items : List Menu.Item
        , title : String
        , providerId : Counter
        , capabilityGeneration : Counter
        , context : Context
        , incarnation : Counter
        , geometry : Maybe GeometryProjection.Snapshot
        }
```

Line 43:

```elm
type alias Context =
    { native : NativeBinding.Binding
    , lifetime : Counter
    , session : Counter
    , frontend : Counter
    , revision : Counter
    , outputId : Counter
    , outputGeneration : Counter
    }
```

Line 54:

```elm
type alias NativeContext =
    { lifetime : Counter, epoch : Counter, output : Counter, revision : Counter }
```

Line 58:

```elm
type alias Target =
    { lifetime : Counter, session : Counter, incarnation : Counter }
```

Line 62:

```elm
type alias Entry =
    { id : String, item : Menu.Item, kind : String }
```

Line 66:

```elm
type alias Raw =
    { provider : Counter
    , capabilitiesGeneration : Counter
    , context : Context
    , target : Target
    , heading : String
    , capabilities : List String
    , entries : List Entry
    }
```

## ReceiptRouter

Source: `implementation/warlock/src/ReceiptRouter.elm`; SHA256 `c6c5bc025cddd2bb7a0e8daa22ee3ff0cddff36e37131095130215d5e85825d0`. Local imports: Binding, Effects, Menu, Provider, UInt64, UnsentOperation.

Line 18:

```elm
type alias Context = { lifetime : Counter, epoch : Counter, output : Counter, revision : Counter }
```

Line 19:

```elm
type Operation = Minimize | Restore | Maximize | RestoreGeometry | ExitFullscreen | Pin | Unpin
```

Line 20:

```elm
type alias Intent = { request : Counter, generation : Counter, incarnation : Counter, operation : Operation, context : Context }
```

Line 21:

```elm
type alias Key = { native : NativeBinding.Binding, intent : Intent, protocol : Int }
```

Line 22:

```elm
type alias Entry = { local : Menu.IntentId, binding : Menu.Binding, key : Key }
```

Line 23:

```elm
type Model = Model (List Entry)
```

## ReconciliationFrame

Source: `implementation/warlock/src/ReconciliationFrame.elm`; SHA256 `c44fa50ac86d528b35959d50fc4d85bd9d8983c1e866fdda01ad1854f465004e`. Local imports: Binding, Effects, UInt64.

Line 8:

```elm
type alias Context = { lifetime : Counter, epoch : Counter, output : Counter, revision : Counter }
```

Line 9:

```elm
type alias Record = { schema : Int, effectProtocol : Int, binding : Binding, intent : Effects.Intent, status : Effects.Status }
```

Line 10:

```elm
type alias Proof = { protocolVersion : Int, kind : String, retirementProtocol : Int, operation : String, binding : Binding, requestId : Counter, queriedBinding : Binding, sequence : Counter, grantState : String }
```

Line 11:

```elm
type alias Observation = { actionRequestId : Counter, geometryRequestId : Counter, actionContext : Context, geometryContext : Context }
```

Line 12:

```elm
type alias Release = { id : String, proof : Proof, observation : Observation }
```

Line 13:

```elm
type alias Expected = { currentBinding : Binding, record : Record, proofRequestId : Counter, actionRequestId : Counter, geometryRequestId : Counter, actionContext : Context, geometryContext : Context }
```

Line 14:

```elm
type Frame = ReservationUnknown Binding Record | ReservationReleased Binding Record Release
```

## ReconciliationTracking

Source: `implementation/warlock/src/ReconciliationTracking.elm`; SHA256 `84482d1bb84160e3bd9e026b2043635c35b76422d6e9066f703411f784b29bf9`. Local imports: Binding, Effects, ReconciliationFrame, Shell, UInt64.

Line 10:

```elm
type alias Accepted = {request : Counter, context : R.Context}
```

Line 11:

```elm
type alias Slot = {record : R.Record, proof : Maybe R.Proof, actionRequest : Maybe Counter, geometryRequest : Maybe Counter, action : Maybe Accepted, geometry : Maybe Accepted, released : Bool}
```

Line 12:

```elm
type alias Model = {slots : List Slot, legacy : List {intent : Effects.Intent, protocol : Int}, informational : Maybe R.Proof}
```

## RetainedPreviewPresenter

Source: `implementation/warlock/src/RetainedPreviewPresenter.elm`; SHA256 `3446188256b8422ff79fc177c46871a8dc102f4f06522584e252216727f3c4a8`. Local imports: NativePreviewProposalIngress, NativePreviewRealm, PreviewPresenter, PreviewVisual, SurfaceRenderer, UInt64.

Line 19:

```elm
type Model = Model Preview.Model (Maybe Realm.Grant) (Maybe Ingress.Model) (List Ingress.Intent)
```

## SearchFold

Source: `implementation/warlock/src/SearchFold.elm`; SHA256 `31664d665778533dc2c141f433398df5bd37be4b689b7369cd894c89d1459241`. Local imports: none.

No local top-level type declarations.

## Settings

Source: `implementation/warlock/src/Settings.elm`; SHA256 `d13f4d63327eae4a80052252c8ba1f1e40db0f69954b46470ccff248e5ba0e7c`. Local imports: UInt64.

Line 7:

```elm
type Theme = Night | Dawn | HighContrast
```

Line 8:

```elm
type alias Values = { theme : Theme, textScale : Int, effectsOff : Bool, reducedTransparency : Bool }
```

Line 9:

```elm
type alias Snapshot = { schema : Int, revision : Counter, values : Values }
```

Line 10:

```elm
type SaveOutcome = Saved | Refused | Unconfirmed
```

Line 11:

```elm
type alias Model = { outcome : Maybe {request : Counter, result : SaveOutcome}, snapshot : Maybe Snapshot, draft : Values, pending : Maybe { request : Counter, values : Values }, notice : String }
```

## Shell

Source: `implementation/warlock/src/Shell.elm`; SHA256 `6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094`. Local imports: Binding, Effects, GeometryProjection, NativeOutcome, UInt64, UnsentOperation.

Line 12:

```elm
type RecoveryFailure = Unavailable | Full | Busy | Unverified | LegacyOwner
```

Line 31:

```elm
type Phase = Detached | Reconciling | Ready | Exhausted
```

Line 32:

```elm
type Stamp = Stamp Binding Counter Counter
```

Line 33:

```elm
type Msg = ReconciliationFull | RecoveredUnknown Int Effects.Intent | ReservationReleased Bool Binding Int Effects.Intent | Incoming D.Value | Refresh | Reconnect | Ignore | GeometryAttach | GeometryRefresh | Act Stamp Effects.Operation Counter | UnsentObservations (List (String,Counter)) | SupersedeObservations Bool | UnsentOperations (List UnsentOperation.Key) | RegistrationRefused (List UnsentOperation.Key) (List (String,Counter)) | RegistrationAvailable Bool
```

Line 34:

```elm
type Effect = Send E.Value | RestartBackend | ArmPrepared Counter
```

Line 35:

```elm
type alias Model = { applicationOnly : Bool, decoderRefusal : Maybe String, reconciliationFull : Bool, effects : Effects.Model, binding : Maybe Binding, request : Counter, expected : Maybe Counter, phase : Phase, reconnecting : Bool, notice : String, geometry : Maybe GeometryProjection.Snapshot, geometryCaps : Maybe GeometryProjection.Capabilities, geometryExpected : Maybe Counter, geometryAttachExpected : Maybe Counter, attachNeeded : Bool, recoveryFailure : Maybe RecoveryFailure, issued : List { binding : Binding, protocol : Int, intent : Effects.Intent }, notificationQueued : Bool, projectionRetryQueued : Bool, transportRefused : Bool, deferNotifications : Bool }
```

## ShortcutPreferences

Source: `implementation/warlock/src/ShortcutPreferences.elm`; SHA256 `d8c1a63f199612161e078e0f6c7f75cbbfa190953e19325e50169debc425dcec`. Local imports: UInt64.

Line 7:

```elm
type Choice = Undecided | Keep | Default | Alternate
```

Line 8:

```elm
type alias Choices = { applications : Choice, system : Choice, notifications : Choice }
```

Line 9:

```elm
type alias Row = { defaultChord : String, alternateChord : String, defaultAvailable : Bool, alternateAvailable : Bool, active : Choice }
```

Line 10:

```elm
type alias Inventory = { fingerprint : String, applications : Row, system : Row, notifications : Row }
```

Line 11:

```elm
type alias Snapshot = { schema : Int, revision : Counter, choices : Choices }
```

Line 12:

```elm
type alias Model = { snapshot : Maybe Snapshot, inventory : Maybe Inventory, draft : Choices, pending : Maybe {request : Counter, choices : Choices}, conflicts : List String, notice : String }
```

## Shortcuts

Source: `implementation/warlock/src/Shortcuts.elm`; SHA256 `cfa79040387114e79b7a6cf51ca31aa4fbe569372ff1948105265adf90cd97a7`. Local imports: Binding, UInt64.

Line 5:

```elm
type Route = Applications | System | Notifications
```

Line 6:

```elm
type alias Event = { serial : Counter, route : Route, outputGeneration : Maybe Counter }
```

Line 7:

```elm
type alias Snapshot = { binding : Binding.Binding, serial : Counter, blocked : Bool, events : List Event }
```

Line 8:

```elm
type alias Model = { binding : Maybe Binding.Binding, seen : Counter }
```

Line 17:

```elm
type alias Box = List Int
```

## Snap

Source: `implementation/warlock/src/Snap.elm`; SHA256 `8ee61de4cd63557d3f2928893ed35ce93f1e3290128847e66ca388aa5d98ec8e`. Local imports: GeometryProjection, UInt64.

Line 8:

```elm
type Region = LeftHalf | RightHalf | TopLeft | TopRight | BottomLeft | BottomRight
```

Line 9:

```elm
type alias Choice = { snapshot : Geometry.Snapshot, target : Counter, selected : Region }
```

Line 10:

```elm
type alias Proposal =
    { region : String, geometry : List Float, monitor : Counter
    , outputOwnershipGeneration : Counter, workAreaRevision : Counter
    , workspaceGeneration : Counter, context : Geometry.Context }
```

## StatusScroll

Source: `implementation/warlock/src/StatusScroll.elm`; SHA256 `9348a397d03cd7671faad4407fa0951f8765f4c72ccf98913db3ed35857ba034`. Local imports: SurfaceSnapshot, UInt64.

Line 48:

```elm
type Epoch
    = Epoch Counter
```

Line 52:

```elm
type State
    = Unseeded Counter
    | Active Epoch String
    | Exhausted String
```

Line 58:

```elm
type Model
    = Model State
```

## Surface

Source: `implementation/warlock/src/Surface.elm`; SHA256 `c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb`. Local imports: Catalog, Desktop, Effects, Files, GeometryProjection, JumpList, Launch, Menu, MenuBridge, Motion, MotionPreferences, Notifications, Pins, Provider, Settings, Shell, ShortcutPreferences, Snap, Switcher, SystemMenu, TaskView, Taskbar, TaskbarShell, Transfer, UInt64, WorkspaceNavigation.

Line 32:

```elm
type alias Control =
    { id : String, domId : String, label : String, ariaLabel : String, detail : String, enabled : Bool, message : Maybe Desktop.Msg }
```

## SurfaceController

Source: `implementation/warlock/src/SurfaceController.elm`; SHA256 `2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998`. Local imports: Binding, Desktop, Effects, Menu, MenuBridge, ReconciliationFrame, ReconciliationTracking, Shell, Surface, Switcher, TaskbarShell, UInt64.

Line 18:

```elm
type Model = Model { recovery : Recovery.Model, desktop : Desktop.Model, publication : Counter, lease : Counter, exhausted : Bool }
```

Line 19:

```elm
type Event = Interaction Desktop.Msg | Renderer D.Value | NativeDismiss Counter | NativeEscape Counter | NativeReflow Counter | NativeRelocate
```

Line 20:

```elm
type Effect = DesktopEffect Desktop.Effect | Publish E.Value
```

## SurfaceRenderer

Source: `implementation/warlock/src/SurfaceRenderer.elm`; SHA256 `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98`. Local imports: PreviewVisual, Settings, StatusScroll, SurfaceSnapshot, SurfaceTheme, UInt64.

Line 17:

```elm
type alias Snapshot = SurfaceSnapshot.Snapshot
```

## SurfaceSnapshot

Source: `implementation/warlock/src/SurfaceSnapshot.elm`; SHA256 `58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7`. Local imports: Settings, UInt64.

Line 9:

```elm
type alias Control = { identity : String, domId : String, label : String, ariaLabel : String, detail : String, enabled : Bool, focusOnly : Bool, checked : Maybe Bool }
```

Line 10:

```elm
type alias Details = { publication : Counter, lease : Counter, keyboardParent : Maybe Bool, mode : String, status : String, appearance : Settings.Values, motion : String, bar : List Control, popup : List Control }
```

Line 11:

```elm
type Snapshot = Snapshot Details
```

## SurfaceTheme

Source: `implementation/warlock/src/SurfaceTheme.elm`; SHA256 `be9d20b763275987d0706ec6edadea3853162bb28731a3da642b50fce0529d4c`. Local imports: Settings.

Line 30:

```elm
type alias Palette =
    { colorScheme : String
    , canvas : String
    , surfaceRecessed : String
    , surface : String
    , surfaceUtility : String
    , surfaceRaised : String
    , surfaceSelected : String
    , surfaceAttention : String
    , textPrimary : String
    , textSecondary : String
    , textDisabled : String
    , brandAccent : String
    , actionFill : String
    , onAction : String
    , borderSubtle : String
    , borderControl : String
    , borderEssential : String
    , borderDisabled : String
    , focusRing : String
    , activeContour : String
    , warningContour : String
    , dangerAccent : String
    , cardShadow : String
    , snapShadow : String
    , snapSelectedShadow : String
    , inputInsetShadow : String
    , highContrast : Bool
    }
```

Line 61:

```elm
type alias ControlSpec =
    { popup : Bool
    , surfaceMode : String
    , identity : String
    , kind : String
    , windowState : String
    , isEnabled : Bool
    , isFocusOnly : Bool
    , isCurrent : Bool
    , checked : Maybe Bool
    , isMenuCheckbox : Bool
    , appearance : Settings.Values
    , motion : String
    }
```

## Switcher

Source: `implementation/warlock/src/Switcher.elm`; SHA256 `7523cc13bf794c126cee2d39541d9fbae062ec3b420d5898eed6380792ec3061`. Local imports: Taskbar, UInt64.

Line 7:

```elm
type Direction = Forward | Reverse
```

Line 8:

```elm
type Phase = Idle | Waiting | Browsing | Resolved | Cancelled
```

Line 9:

```elm
type Model = Model
    { generation : Counter
    , phase : Phase
    , steps : Dict Int Direction
    , released : Maybe Int
    , ready : Bool
    , entries : List Family
    , ring : List Counter
    , origin : Maybe Counter
    , selected : Int
    , baseline : Maybe { root : Counter, through : Int }
    }
```

## SystemMenu

Source: `implementation/warlock/src/SystemMenu.elm`; SHA256 `cf44c66fe51a5d86f14e33a8235e04f178553261229fd51e0d81cbc35c944054`. Local imports: UInt64.

Line 7:

```elm
type Operation = Volume | Mute | Network | Suspend | Reboot | PowerOff | Lock | Logout
```

Line 8:

```elm
type alias Intent = { service : Counter, revision : Counter, operation : Operation, value : Int }
```

Line 9:

```elm
type alias Snapshot =
    { service : Counter, revision : Counter
    , volume : Maybe { percent : Int, muted : Bool, label : String }
    , network : Maybe { enabled : Bool, state : String, permission : String }
    , power : Maybe { suspend : String, reboot : String, poweroff : String }
    , session : Maybe { name : String, state : String, locked : Bool }
    }
```

Line 16:

```elm
type alias Model = { snapshot : Maybe Snapshot, pending : Maybe { request : Counter, intent : Intent }, spent : List Intent, notice : String }
```

## TaskView

Source: `implementation/warlock/src/TaskView.elm`; SHA256 `7665dd48cae39ecdc71f85990eaefc0115fb79fe0462e41199b10ec4ccbfcdbe`. Local imports: ActionProjection, Effects, GeometryProjection, Shell, Taskbar, WorkspaceInventory.

Line 10:

```elm
type alias Workspace = { identity : String, active : Bool, windows : List Taskbar.Family }

-- Geometry supplies membership; the action projection supplies family identity
-- and action eligibility. Enumeration never grants live paint/input authority.
```

## Taskbar

Source: `implementation/warlock/src/Taskbar.elm`; SHA256 `31ed9ce6b37e5b35065f8833e31412657800d894b6d9e9544f380bc16e7aa519`. Local imports: ActionProjection, Effects, UInt64.

Line 8:

```elm
type alias Family = { root : Counter, label : String, application : String, minimized : Bool, available : Bool, active : Bool, attention : Bool }
```

Line 9:

```elm
type alias Group = { key : String, families : List Family }
```

Line 10:

```elm
type Decision = Launch | Picker | Apply Effects.Operation Counter | Unavailable

-- Application hints group roots; transient children never add family entries.
-- Catalog identity matching and persisted pins remain a separate native contract.
```

## TaskbarShell

Source: `implementation/warlock/src/TaskbarShell.elm`; SHA256 `eeb91d15cab97c94bf12ef3d1e25f513ac6c037774bef5150867eb01c6f86c26`. Local imports: Menu, MenuBridge, NativeOutcome, Provider, Shell, Taskbar, UInt64.

Line 11:

```elm
type alias Picker = { scope : Shell.Stamp, key : String, generation : Counter }
```

Line 12:

```elm
type alias Model = { shell : Shell.Model, picker : Maybe Picker, generation : Counter, menus : MenuBridge.Model }
```

Line 13:

```elm
type Msg = Native Shell.Msg | Primary Shell.Stamp String | Choose Shell.Stamp Counter Counter | Close Shell.Stamp Counter | OpenMenu Provider.Snapshot | MenuEvent Menu.Msg | ExpirePrepared Counter | CancelPrepared Counter
```

## Transfer

Source: `implementation/warlock/src/Transfer.elm`; SHA256 `357a68e70977184ced8be8b8a4c0db6209730e6fe6ad2f4718087a6d6a2c32be`. Local imports: GeometryProjection, UInt64.

Line 9:

```elm
type alias Proposal = { source : String, sourceGeneration : Counter, destination : String }
```

## UInt64

Source: `implementation/warlock/src/UInt64.elm`; SHA256 `0c32ee015c1882d9d754d9dcda5a454e8a1d71f85d3bbd60d9280dd564531baa`. Local imports: none.

Line 7:

```elm
type Counter
    = Counter String
```

## UiHttp

Source: `implementation/warlock/src/UiHttp.elm`; SHA256 `3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419`. Local imports: none.

Line 11:

```elm
type Role = Controller | Renderer
```

Line 12:

```elm
type Model = Model
    { role : Role
    , pending : List E.Value
    , active : Maybe E.Value
    , polling : Bool
    , failed : Maybe String
    }
```

Line 19:

```elm
type Msg = Poll | Polled (Result Http.Error String) | Posted (Result Http.Error String)
```

Line 20:

```elm
type Event = Incoming D.Value | Lost String
```

## UnsentOperation

Source: `implementation/warlock/src/UnsentOperation.elm`; SHA256 `46e315cc739e097805af3c9358f9ca27a807ef1119c733aa296687342c8238ea`. Local imports: Binding, Effects.

Line 8:

```elm
type alias Key = { binding : Binding.Binding, protocol : Int, intent : Effects.Intent }
```

## WorkspaceInventory

Source: `implementation/warlock/src/WorkspaceInventory.elm`; SHA256 `583692398a5038bf17a87c09a7019ddae4059f3f200489342ca89dab50eb3b2e`. Local imports: Binding, UInt64.

Line 8:

```elm
type alias Row = { identity : String, generation : Counter, monitor : Counter, outputOwnershipGeneration : Counter }
```

Line 9:

```elm
type alias Snapshot = { binding : Binding.Binding, request : Counter, sequence : Counter, revision : Counter, output : Counter, active : Maybe String, rows : List Row }
```

## WorkspaceNavigation

Source: `implementation/warlock/src/WorkspaceNavigation.elm`; SHA256 `8313a23008abfa6157324472db852b087b4af09dd3696a33f273d7010634e7f6`. Local imports: Binding, GeometryProjection, UInt64, WorkspaceInventory.

Line 10:

```elm
type Status = Pending | Unknown | Committed | Refused
```

Line 11:

```elm
type alias Context = {lifetime:Counter,epoch:Counter,output:Counter,revision:Counter}
```

Line 12:

```elm
type alias Intent = {request:Counter,generation:Counter,source:WorkspaceInventory.Row,destination:WorkspaceInventory.Row,context:Context}
```

Line 13:

```elm
type alias Record = {binding:Binding.Binding,intent:Intent,status:Status,reason:String}
```

Line 14:

```elm
type alias Model = {binding:Maybe Binding.Binding,ready:Bool,request:Counter,generation:Counter,record:Maybe Record,recovering:Bool,origin:Maybe String,returning:Bool}
```

