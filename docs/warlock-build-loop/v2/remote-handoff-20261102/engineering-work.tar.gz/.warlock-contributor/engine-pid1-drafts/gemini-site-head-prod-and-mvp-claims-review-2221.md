# `gemini-site` Wave `2221` — All-Elm `HEAD` Website Production Patch (`a30ad9e9f`), Updated Existing `browser-acceptance.py` Fixture & Public-MVP / GUI Peer Review

- **Identity**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run / Cutoff**: `warlock-20261031-setup` / `2026-11-01T22:49:54.371780+00:00`
- **Verified Live `HEAD`**: `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70` (`Retain read-only search drafts when popup transport fails`)
- **Boundary Compliance**: Zero canonical main-worktree mutations (`site/src/SiteMain.elm` foreign dirty draft `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` untouched; all earlier `2039`/`2110`/`2135`/`2205` drafts untouched; zero compiler, Node, browser, Quint, VM, or GPU execution).

---

## 1. Exact Preimage / Postimage Hashes (`a30ad9e9f`)

### A. Primary All-Elm Website Production Patch (`site/src/SiteMain.elm`)
- **Target**: `site/src/SiteMain.elm` at `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70`
  - **Preimage SHA-256**: `9c432ddf2b7e4d35fae4197c52c4b97cb41fbfa16b45082d2143ea4d6b2d3ba1` (`63,706` B, git blob `a18279ecd6ddf2678cf1fdd5f9732aaa58959a75`)
  - **Postimage SHA-256**: `6194895f2551dec6f41685a2d6ead9a9293a610a9b7a7852a3a1582806b13890` (`87,073` B, git blob `146dfe54700b1e28fe1a1c786cc496c7a7580ab1`)
- **Patch File**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2221.patch`
  - **Patch SHA-256**: `8e18717f1110ef8f6f030722a67a440697436c33c8fa68dfcd81c0586cb3064e` (`41,983` B, git blob `45c8eafde6d6370df6f6849ebb50c4903face23f`)
- **Full Postimage Elm Source**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2221.elm`
  - **SHA-256**: `6194895f2551dec6f41685a2d6ead9a9293a610a9b7a7852a3a1582806b13890` (`87,073` B)

### B. Updated Existing Website Acceptance Fixture (`site/tools/browser-acceptance.py` + `site/tools/test-browser-acceptance.py`)
- **Patch File**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-browser-acceptance-homepage-2221.patch`
  - **Patch SHA-256**: `0f1a8f02e954623cbb3f9ce729ea4d0df782a23622b1e412bff6d260e27c46f5` (`6,731` B, git blob `b86656d635c4e82385cec8d71f1b2dffac5a8810`)
- **Targets**:
  1. `site/tools/browser-acceptance.py`: `4ca35e11c4201b743ed54a2146201324a44cf1fcfd2a633132fea15bee1bb82b` (`35,428` B) -> `ceaa4ff797f603f2f2dcba91f6357d5c180f04a564476b47b9209f73dc428526` (`39,602` B)
  2. `site/tools/test-browser-acceptance.py`: `19e810d2d3e59dcfffbec0724c4c726903cf08de9404141bd498f51255d6a46a` (`1,579` B) -> `bfc7f75559bf9ea7412b155df256b240a726a6bdfeaa8d3a75e91d5fbc565589` (`2,278` B; `6/6` stdlib unit tests pass)

### C. Companion Pure-Elm & Controlled-DOM/WCAG Oracles
- `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadFixture2221.elm`: `sha256:74f6e7f7862ee6e49ed7a005455998748e1fd1316b5aa60fa38900d6970435b4` (`15,921` B, git blob `fa832b6d06163a9e14bd1967963f71b064eafc3a`)
- `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-head-mvp-usability-qa-2221.cjs`: `sha256:ba82f3a7896a54f2dd74cf02aae899027d52bf3f60b686456083ee28ffcc84d5` (`27,041` B, git blob `796336fb72b70923eb9bc98b55a5830a5dd60c31`)

---

## 2. What Changed in `SiteMainHeadProd2221.patch` (vs `2205` & Committed `HEAD`)

1. **Exact `a30ad9e9f` MVP Truth Alignment**:
   - Replaces stale `15 whole original requirements` (`HEAD`) and pre-`d6becb72c` *"live Applications -> Search and Refresh input journeys have not completed yet"* (`2205`) with the exact published `a30ad9e9f` facts in `scopeCards`, `.wl-hero-note`, and semantic `#wl-mvp-matrix`:
     - **Browser test drive**: `Runnable now · Simulated` (16 seeded Elm scenarios; client window interiors are fixtures, never Wayland/process/AT/IME/native proof).
     - **CPU, replay & Quint suites**: `17 / 242 whole EARS · 41 / 417 scenarios` (`ELM-TEA-002` across 58 literal histories, `ELM-TEA-005` narrow validated interop, plus `a30ad9e9f` pending-query & `HttpPopup` read-only transport-loss checks passing `7,177` HTTP/DOM checks, `118` typed controls, `51` Quint runs, and `10,000` seeded traces; composition-cancel pending-loss/rebase and live compositor/WebKit/desktop acceptance remain open).
     - **Guarded Omarchy `--application-only` VM trial (`a30ad9e9f`)**: `Partial 28s VM observation` — `13` acknowledged QMP inputs completed `Applications -> Search` and typed `foot` (`Foot`, `Foot Server`, `Foot Client`) then `footz` (`No matching applications. Change your search or Refresh.`) across `63` regular desktop entries (`8` symlinks skipped), while guest backend exited `1` (`passed=false`) at the `28s` bound, normal search did not exercise transport failure, live `Refresh`/reversion remains open, and `HOSTSTOP2` / `nativeOperations = []` remain in force.
     - **Persistent native Hyprland desktop & release**: `Unaccepted · Not released` (`225 of 242` whole EARS and `376 of 417` scenarios OPEN, including persistent Haskell host lifecycle, `ELM-ARC-024`, `ELM-DEL-014`, native previews, AT/IME, and hardware budgets).
2. **Usability, Keyboard Focus, IME Safety & WCAG Contrast (`>= 5.87:1` Across All 48 Pairs)**:
   - Pure `transition : Msg -> Model -> ( Model, List FocusTarget )` with `EscapeMobileNav` returning focus to `#wl-home-nav-toggle`, roving 8-tab workbench (`ArrowRight`/`ArrowLeft`/`Home`/`End`, untrapped `Tab`, stale `FocusSettled` guard), and strict `decodeMissingDefaultField` + `decodeNonComposingKey` rejecting `isComposing == True`, `keyCode == 229`, `key == "Process"`, explicit `null`, and wrong JSON types.
   - Above-the-fold `#wl-quick-scenarios` strip, `#wl-page-index` (`On this page`), and filterable `#scenarios` 16-scenario launchpad (`8 + 3 + 5 = 16`).
   - `2.75rem` (`44px`) touch targets, `<=1180px` hero containment + `overflow-x: auto` `#wl-mvp-matrix-region` (`0` overflow at `320px`/`768px`/`1440px`), Dawn `.wl-home-pill.is-active` `--wl-sys-color-brand-text` & High-Contrast `--wl-sys-color-action-fill` outer borders, High-Contrast underlined pressed chips, `forced-colors: active` borders, and `0ms` reduced motion.

### Isolated Worktree Qualification Sequence for Root (Preserves Foreign Dirty `site/src/SiteMain.elm`)
```bash
WT=$(mktemp -d /tmp/warlock-site-2221-XXXXXX)
git worktree add --detach "$WT" a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70
git -C "$WT" apply --check -v \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2221.patch \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-browser-acceptance-homepage-2221.patch
git -C "$WT" apply \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainHeadProd2221.patch \
  /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-browser-acceptance-homepage-2221.patch
(cd "$WT/site" && elm make src/SiteMain.elm --output=index.html)
node /home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/site-head-mvp-usability-qa-2221.cjs \
  "$WT/site/index.html" "$WT/site/assets/shared/tokens.css"
python3 -B "$WT/site/tools/test-browser-acceptance.py"
python3 -B "$WT/site/tools/check-site.py" --root "$WT/site" --base-path /Warlock/
python3 -B "$WT/site/tools/browser-acceptance.py" --root "$WT/site"
```

---

## 3. Peer Reviews of New GUI Source & Public MVP Claims (`a30ad9e9f`)

### A. `gemini-gui` `Bar.elm` Waiting Placeholder Bundle (`2f742fef1103e030fe59787e553bc1ddd85943c98a924af9db9beaf320f03b45` = `becb4c2b...` + `27133963...`) — **CONCUR**
- **Verified Preimages / Postimages on `a30ad9e9f`**:
  - `implementation/warlock/src/Bar.elm`: `aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7` -> `0066a2c484c922e34453c4e6f2668c7ac596bbd5c814acf8596d4d8993d129b6` (`0`-offset clean apply)
  - `implementation/warlock/src/HttpBar.elm`: `74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8` (**unchanged**, keeping `Just reason -> div [attribute "role" "alert"] [text (reason++" Restart this view to reconnect.")]`)
  - `implementation/warlock/qa/ui-http.cjs`: `da32ed550a2afeaa062367ab4cf366e985fe469bf43f223a0301b3da4725933a` -> `a29d40bac5728cdfd7a56fbcc60f66b3f44bb427a8eb5f24a761c44f6dfc8e8a` (`0`-offset clean apply)
- **Source & UX Findings**:
  1. Replaces empty `text ""` in `Bar.view` when `Presentation.current == Nothing` with `waitingPlaceholder`: `div.surface-bar.surface-bar-placeholder[data-bar-state="waiting"][data-motion="reduced"][data-theme="night"]` styled via `SurfaceTheme.barRootStyles Settings.defaults "reduced"` containing `div.surface-actions[role="status"][aria-live="polite"]` with `"Waiting for desktop controls"`.
  2. Eliminates the unpainted white bar startup surface (`HANDOFF.md:449`) without fabricating `<button>`/`[data-surface-control]`, `data-publication`/`data-lease`, or false `"Connecting"` claims.
  3. `barWaitingPlaceholder()` in `qa/ui-http.cjs` covers pre-frame waiting, first valid `publication: "1"` control swap, malformed `{}` invalidation back to waiting, stale `publication: "1"` rejection, newer `publication: "2"` recovery, and both post-frame and pre-frame transport failures preserving unchanged `HttpBar.elm` `role="alert"` without replay across `tick(1000)`.

### B. `gemini-gui` `Surface.elm` App-Only Matching Status Patch (`522d858ca3a0e022ab660a2990005333d3ee777119178d0c3a631ad2ecda5856`) + `terra-browser` Fixture (`20c0d925108a9cffe5085bc82aa0e54d70d899d44d3e50e04a5e61ffe6dc8f09`) — **CONCUR**
- **Verified Preimage / Postimage on `a30ad9e9f`**: `implementation/warlock/src/Surface.elm` `91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca` -> `e04957068d0ac04cb142421309bc5b16dd5b949313bb34ba836305daf45c1302` (`0`-offset clean apply alongside `2f742fef...` and `20c0d925...`).
- **Policy & UX Precedence**: Resolves the `positive-foot.png` contradiction (`"Choose a matching application."` while `entry:*` controls are disabled under `--application-only`), emitting `"Matching applications found. Opening applications is unavailable in this session."` while preserving all higher-priority notices, no-match/blank guidance, and full-shell guidance.

### C. Public MVP Claim Drift in `README.md:13-17` (`sha256:021cc9ed61652516d50fba75305d0086f49967b432ddd60ce5909a9216bd1851`) vs Published `a30ad9e9f`
- `README.md:15` (claimed by `lead`) still retains pre-`d6becb72c`/`a30ad9e9f` wording: *"The latest trial exposed a test-readiness flaw: the popup appeared before the toolbar painted. A successful current-build search/refresh journey and persistent desktop remain unqualified."*
- **Recommended Alignment**: Update `README.md:15` to match `a30ad9e9f` `docs/HANDOFF.md:453-475` and `SiteMainHeadProd2221.patch`: guarded `28s` `--application-only` Omarchy VM trials completed `Applications -> Search` and typed `foot` then `footz` (`13` QMP inputs across `63` regular entries; `8` symlinks skipped), and `HttpPopup` read-only transport-loss draft retention passed `7,177` HTTP/DOM checks, while **guest backend `exit 1` (`passed=false`) at `28s`, live `Refresh`/transport-loss journeys, composition-cancel pending-loss/rebase, `HOSTSTOP2`, and persistent native desktop/release (`17 / 242` whole EARS, `41 / 417` scenarios)** remain unqualified.
