{-# LANGUAGE ScopedTypeVariables #-}
-- QA ONLY, UNEXECUTED. Link the same isolated custody unit with the exact
-- existing-hook overlay. Root supplies an issued HeldExecutable, an exclusively
-- owned open input handle, a fresh private marker and the ORIGINAL absolute D.
-- No PID adoption, synthetic stop flag, deadline mint or fixture-only child is
-- used. The selected artifact is the actual graceful-stop-child [marker].
module SolTransferStopClaim0340
  (Mode(..), Probe, Roots, newProbe, newRoots, runHosted, probeOwner, probeTicket) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException, SomeException, fromException, mask, throwIO, try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import Foreign.StablePtr (StablePtr, newStablePtr)
import System.Directory (doesFileExist)
import System.FilePath (isAbsolute)
import System.IO (Handle, IOMode(ReadMode), hClose, hIsClosed, withBinaryFile)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap
  (AdmissionDeadline, OwnerStatus(..), SessionObservation(..), ToolError(..), remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)
import Warlock.Capture.Process.Transfer.Internal
  (TransferTicket, TransferDisposition(..), fixtureTicketWithClose, transferDisposition)
import Warlock.Platform.Executable (HeldExecutable)

data Mode = NoStop | StopBeforeClaim deriving (Eq, Show)
type Outcome = Either SomeException (Either P.SessionExit ((),P.SessionExit))
data Probe = Probe
  { owner :: P.PersistentOwner
  , used :: IORef Bool
  , heldRoot :: IORef (Maybe HeldExecutable)
  , inputRoot :: IORef (Maybe Handle)
  , ticketRoot :: IORef (Maybe TransferTicket)
  , workerRoot :: IORef (Maybe ThreadId)
  , startBarrier :: MVar ()
  , beforeClaim :: MVar ()
  , allowClaim :: MVar ()
  , finished :: MVar Outcome
  , beforeVisits :: IORef Int
  , afterVisits :: IORef Int
  , afterDisposition :: IORef (Maybe TransferDisposition)
  , closeAttempts :: IORef Int
  , verified :: IORef Int
  , bodies :: IORef Int
  , reserved :: IORef Int
  , selectedObservation :: IORef (Maybe SessionObservation)
  }
-- Keep caller-issued resources rooted even if cancellation arrives at the
-- restore/runCase boundary before its per-Probe fields have been populated.
newtype Roots = Roots (IORef [StablePtr (Probe,HeldExecutable,Handle)])

newRoots :: IO Roots
newRoots = Roots <$> newIORef []

newProbe :: IO Probe
newProbe = Probe <$> P.newPersistentOwner <*> newIORef False
  <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
  <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
  <*> newIORef 0 <*> newIORef 0 <*> newIORef Nothing <*> newIORef 0
  <*> newIORef 0 <*> newIORef 0 <*> newIORef 0 <*> newIORef Nothing

-- These return only the SAME issued opaque capabilities for Root disposition;
-- neither exposes production constructors, replaces an owner, nor mutates it.
probeOwner :: Probe -> P.PersistentOwner
probeOwner = owner
probeTicket :: Probe -> IO (Maybe TransferTicket)
probeTicket = readIORef . ticketRoot

check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("ticket-stop-claim: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- Observations never renew StartD or StopD. A busy/failed deadline observation
-- is an unconfirmed case retained by Root, never permission to use a fresh D.
budget :: Probe -> AdmissionDeadline -> IO Int
budget probe original = do
  originalLeft <- remainingMicros original
  stop <- P.tryPersistentStopDeadline (owner probe)
  case stop of
    P.StopDeadlineNotLatched -> pure originalLeft
    P.StopDeadlineLatched actual -> min originalLeft <$> remainingMicros actual
    _ -> ioError (userError "same-owner StopD observation unconfirmed; retain Probe")

within :: Probe -> AdmissionDeadline -> String -> IO a -> IO a
within probe original label action = do
  left <- budget probe original
  check (label ++ ": original stricter D remains") (left > 0)
  result <- timeout left action
  value <- maybe (ioError (userError (label ++ ": expired; retain Probe/guardian"))) pure result
  final <- budget probe original
  check (label ++ ": completed within original D") (final > 0)
  pure value

once :: String -> IORef Int -> IO ()
once label cell = do
  previous <- atomicModifyIORef' cell (\n -> (n+1,n))
  check (label ++ ": exact single route entry") (previous == 0)

awaitActualMarker :: Probe -> AdmissionDeadline -> FilePath -> IO ()
awaitActualMarker probe original marker = within probe original "real selected child ready marker" loop
 where
  loop = do
    exists <- doesFileExist marker
    if not exists then threadDelay 1000 >> loop else do
      bytes <- withBinaryFile marker ReadMode (\input -> B.hGet input 6)
      -- The real child's writeFile is not atomic. A proper literal prefix is
      -- still in progress; extra/different bytes fail the independent oracle.
      let expected = B.pack [114,101,97,100,121]
      if bytes == expected then pure ()
      else if bytes `B.isPrefixOf` expected then threadDelay 1000 >> loop
      else check "independent literal graceful child marker" False

-- Install an actual same-process root BEFORE handle/ticket registration or any
-- worker can run. Root must retain this host after BOTH outcomes and async
-- cancellation. StablePtr does not survive process termination. No worker is
-- killed, resource closed, or root freed by this host adapter on a failed case.
runHosted :: Roots -> Mode -> Probe -> HeldExecutable -> Handle -> FilePath
  -> AdmissionDeadline -> IO (Either SomeException ())
runHosted (Roots roots) mode probe image input marker original = mask $ \restore -> do
  root <- newStablePtr (probe,image,input)
  atomicModifyIORef' roots (\old -> (root:old,()))
  outcome <- try (restore (runCase mode probe image input marker original))
  case outcome of
    Left problem -> case fromException problem :: Maybe SomeAsyncException of
      Just _ -> throwIO problem
      Nothing -> pure (Left problem)
    Right () -> pure (Right ())

runCase :: Mode -> Probe -> HeldExecutable -> Handle -> FilePath -> AdmissionDeadline -> IO ()
runCase mode probe image input marker original = mask $ \restore -> do
  previous <- atomicModifyIORef' (used probe) (\old -> (True,old))
  check "fresh single-use Probe" (not previous)
  writeIORef (heldRoot probe) (Just image)
  writeIORef (inputRoot probe) (Just input)
  check "absolute owned marker" (isAbsolute marker)
  exists <- within probe original "initial marker observation" (doesFileExist marker)
  check "fresh marker" (not exists)
  closedBefore <- within probe original "initial caller handle observation" (hIsClosed input)
  check "Root supplied exclusive open input handle" (not closedBefore)
  ticket <- fixtureTicketWithClose input $ do
    atomicModifyIORef' (closeAttempts probe) (\n -> (n+1,()))
    hClose input -- real close, never a success-only substitute
  writeIORef (ticketRoot probe) (Just ticket)
  -- Only the trusted original D is used for this startup. The 2s QA StopBudget
  -- is selected once before start, not an original/native acceptance threshold.
  stopBudget <- must (P.stopBudgetMicros 2000000)
  selection <- must (P.persistentHeld image [marker] ticket [("LANG","C"),("LC_ALL","C")])
  let hook stage = case stage of
        "persistent-before-transfer-claim" -> do
          once "before-claim hook" (beforeVisits probe)
          putMVar (beforeClaim probe) ()
          within probe original "before-claim release" (readMVar (allowClaim probe))
        "persistent-after-transfer-claim" -> do
          once "successful after-claim hook" (afterVisits probe)
          actual <- within probe original "successful claim ownership observation" (transferDisposition ticket)
          writeIORef (afterDisposition probe) (Just actual)
        "persistent-after-spawn-reserve" -> once "spawn reservation" (reserved probe)
        _ -> pure ()
      ready observation = do
        awaitActualMarker probe original marker
        check "real selected process observation" (observedPid observation > 1)
        once "actual startup verifier" (verified probe)
        writeIORef (selectedObservation probe) (Just observation)
        pure (Right ())
      body _ = once "actual live callback" (bodies probe)
  thread <- forkIOWithUnmask $ \unmask -> do
    result <- try (unmask (takeMVar (startBarrier probe) >>
      withPersistentOwnerHook (owner probe) selection 4096 (P.startBudgetFromDeadline original)
        stopBudget ready body hook))
    putMVar (finished probe) result
  -- A failed publication can leave a retained blocked worker, never unrecorded
  -- Backend/process activity: the worker has not crossed startBarrier yet.
  writeIORef (workerRoot probe) (Just thread)
  putMVar (startBarrier probe) ()
  restore $ do
    within probe original "after last stop peek, before actual claim" (readMVar (beforeClaim probe))
    initial <- within probe original "paused caller ownership observation" (transferDisposition ticket)
    check "actual ticket is still caller-owned at pause" (initial == CallerOwned)
    receipt <- case mode of
      NoStop -> pure Nothing
      StopBeforeClaim -> do
        actual <- within probe original "actual same-owner pre-live stop" (P.requestSessionStop (owner probe) stopBudget)
        check "actual first stop latched before live" (actual == P.StopLatchedBeforeLive)
        pure (Just actual)
    putMVar (allowClaim probe) ()
    result <- within probe original "actual selected operation completion" (readMVar (finished probe))
    preCount <- readIORef (beforeVisits probe)
    postCount <- readIORef (afterVisits probe)
    atClaim <- readIORef (afterDisposition probe)
    finalTicket <- within probe original "final ticket ownership observation" (transferDisposition ticket)
    closes <- readIORef (closeAttempts probe)
    closed <- within probe original "final caller handle observation" (hIsClosed input)
    verifyCount <- readIORef (verified probe)
    bodyCount <- readIORef (bodies probe)
    reserveCount <- readIORef (reserved probe)
    phase <- within probe original "final persistent phase observation" (P.persistentStatus (owner probe))
    raw <- within probe original "final raw owner observation" (P.persistentUnderlyingStatus (owner probe))
    markerAfter <- within probe original "final marker observation" (doesFileExist marker)
    observed <- readIORef (selectedObservation probe)
    check "same single actual before-claim route" (preCount == 1)
    case mode of
      NoStop -> do
        check "positive actual claim retained before after-hook"
          (postCount == 1 && atClaim == Just CoreOwned)
        check "actual verified/live selected child and one real close receipt"
          (verifyCount == 1 && bodyCount == 1 && reserveCount == 1 && closes == 1
            && closed && finalTicket == TransferClosed && markerAfter
            && maybe False ((>1) . observedPid) observed)
        check "positive owned leader/core retirement receipts" $
          phase == P.PersistentRetired && raw == Available && case result of
            Right (Right ((),P.LeaderReaped _)) -> True
            _ -> False
      StopBeforeClaim -> do
        check "stop wins before actual ownership transition; no close/replay"
          (postCount == 0 && atClaim == Nothing && finalTicket == CallerOwned
            && closes == 0 && not closed && verifyCount == 0 && bodyCount == 0
            && reserveCount == 0 && not markerAfter && observed == Nothing)
        -- These exact outcome classes are distinct. Cleanup Unknown is not
        -- upgraded to retirement; the ticket/handle remains rooted for Root.
        check "stopped result is definite refusal or retained cleanup Unknown" $ case result of
          Right (Left (P.StartupRefused SessionClosed)) -> phase == P.PersistentRetired && raw == Available
          Right (Left (P.ExitUncertain CleanupUncertain _)) ->
            (case phase of P.PersistentQuarantined _ -> True; _ -> False)
              && (case raw of Quarantined _ -> True; _ -> False)
          _ -> False
    putStrLn ("ticket-stop-claim observation: " ++ show
      (mode,receipt,preCount,postCount,atClaim,finalTicket,closes,verifyCount,bodyCount,reserveCount,phase,raw))
    -- StopBeforeClaim deliberately leaves CALLER-owned input open. Root alone
    -- disposes its original opaque ticket under its independent retained scope.
    -- These checks do not qualify descendants/provider/GUI/native/FD inventory.
