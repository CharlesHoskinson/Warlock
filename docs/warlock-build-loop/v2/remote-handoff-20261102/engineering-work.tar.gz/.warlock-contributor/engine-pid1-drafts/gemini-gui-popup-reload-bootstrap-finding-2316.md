# `HttpPopup` Reload Bootstrap Source Finding, Socket/Role Regression & Minimal Proposal (`20261101T231130Z`)

## 1. Direct Verdict
**No — reloading a stopped `HttpPopup` program does NOT receive a current projection automatically while the original controller and UI owner/broker remain alive.**

With the `Popup` role `/events` queue already drained by the pre-stop instance and no concurrent independent `POST /commit` or window geometry/monitor change occurring across the reload:
1. Reloading `http://127.0.0.1:<popupPort>/index.html` resets `HttpPopup` to `Popup.initial` (`Presentation.current == Nothing`, `pendingQuery == Nothing`), **destroying** both the stopped alert and the user's in-memory read-only retained query/preedit draft (`HttpPopup.elm:70-104`, `Popup.elm:40`).
2. The fresh `HttpPopup` polls `GET /events` (`UiHttp.elm:61-64`), receives **`204` empty body** (`Owner.hs:200-202`) every `100 ms` (`UiHttp.elm:110-111`), and renders **blank `text ""`** (`Popup.elm:59`), even though `Warlock.Ui.Owner` still holds the latest committed `view-frame` in `lastProjection` (`Owner.hs:216, 257`).
3. Worse, if the transport failure originated on the `Owner` side (`stopping == True`, e.g. queue bound, response/close uncertainty, native EOF, or deadline at `Owner.hs:132-137, 192, 225, 231-234`), reloading `/index.html` triggers main-frame `load-failed` (`WebKit.hs:448-452`) -> `any loadFailed active` exits `runWebKit` (`WebKit.hs:462`), tearing down the GTK window immediately.

Therefore, **`Reload view` (`Browser.Navigation.reload`, frozen unintegrated draft `04b7cb38…` / `31a446be…`) is NOT actual recovery and MUST remain unadopted** until a verified host-bound bootstrap route (and persistent listener custody for owner-stopped failures) exists and is independently observed. Both frozen prior drafts (`Bar` waiting `2f742fef…` and `HttpPopup` reload/style `04b7cb38…` / `6be4abc3…`) remain preserved and separate.

---

## 2. Exact Source-Bound Call Chain (Verified Against `HEAD` `a30ad9e9f` / Published `e5ce2487`)

| File | SHA-256 | Exact Lines & Role in Call Chain |
| --- | --- | --- |
| `implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs` | `a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9` | `128, 130`: `lastProjection <- newIORef Nothing`; `queues <- newMVar [(Controller,[]),(Bar,[]),(Popup,[])]`.<br>`147-150, 200-202`: `Events` route calls `dequeue role`, destructively popping `(Popup, x:xs)` -> `(Popup, xs)` and returning `204` (`B.empty`) once empty.<br>`197-199`: `Document` route (`GET /index.html`) serves static `documentBytes document` + CSP only; zero write to `queues`, `lastProjection`, or `Controller`.<br>`203-218, 360-384`: `Commit` (`POST /commit`) appends `[(Popup, gateway "presentation" frameValue), (Popup, gateway "announcements" announcement)]` (+ optional `focus`) **once** to `queues`, then writes `lastProjection (Just (D.commitProjection checked))`. `lastProjection` is read **only** by `uiLastProjection` (`257`) and `validateOwnerEvent` (`174, 341-358`), never by `Document` or `Events`. |
| `implementation/warlock/haskell/runtime/src/Warlock/Ui/Policy.hs` | `5c5d063cdd550a077aedce803656996fc63be34030df5ba635219ffed0d61d40` | `33, 65-68, 83, 86`: `navigationAllowed` (`uri == documentUri origin`) and `resourceAllowed` only prove URI admission for `GET /index.html` and `GET /events`. `Document` (`65`) intentionally omits `X-Warlock-Api: 1` so WebKit `webkit_web_view_load_uri` can load `/index.html`; `Events` (`66-68`) requires `X-Warlock-Api: 1`. |
| `implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs` | `b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a` | `84-101`: `decide` admits same-origin `/index.html` navigation and `200`/`204` responses.<br>`442-447`: `load-changed` sets `loadReady = False` on `WEBKIT_LOAD_STARTED` and `loadReady = True` on `WEBKIT_LOAD_FINISHED`; emits **zero** `TrustedOwnerEvent` or owner callback.<br>`448-462`: `load-failed` sets `loadFailed = True`, causing `loop` (`462`) to exit `runWebKit` if the listener is down.<br>`465-467`: When all 3 views return to `loadReady == True`, calls `stepMvpWindow mvp (readMvpLease (uiLastProjection endpoints)) ownerEvent`. |
| `implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc` | `57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6` | `433-491`: In `advanceMvpState`, under `(TopologyMapped scopeId gen prevMon, ViewMapped surf _ curMon)` with unchanged monitor (`curMon == prevMon`), unchanged surface size (`surf == prevSurf`), and no new Escape press, returns `Right (st, [])` — **zero** `TrustedOwnerEvent`s. |
| `implementation/warlock/src/HttpMain.elm` | `58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9` | `42-51`: Only runs `Policy.update` when `UiHttp.Incoming` arrives from `Controller` `/events` or a `Policy.Delay` timer fires; an in-place `Popup` subview reload produces neither, so `HttpMain` sends **zero** `POST /commit`. |
| `implementation/warlock/src/HttpPopup.elm` & `Popup.elm` & `UiHttp.elm` | `e814d56f…` / `a9f188f9…` / `3a649f51…` | Fresh `HttpPopup` starts at `Popup.initial` (`Presentation.initial`, `pendingQuery = Nothing`), polls `GET /events -> 204` every `100 ms` (`UiHttp.elm:110-111`), and renders `text ""` (`Popup.elm:59`). |

### Why Existing Controlled JS Harness Did Not Prove Bootstrap
- `implementation/warlock/qa/ui-http.cjs:621-623` (`await restarted.event(gateway('presentation', appFrame('6','10','')))`) manually injected a synthetic `presentation` gateway packet into the restarted `HttpPopup` VM rather than polling an `Owner` role queue after prior drain.
- Similarly, our frozen unintegrated `2245` draft (`httpPopupFailureStyleAndReload`) tested `location.reload(false)` spy invocation and separate fresh-VM initialization (`1 GET /events, 0 POSTs`), explicitly disclaiming live WebKit/owner navigation.

---

## 3. Controlled Socket/Role Regression Drafts (`test-ui-origin/Main.hs`)

Target preimage: `implementation/warlock/haskell/runtime/test-ui-origin/Main.hs` (`sha256:0b0f1780ed2ac5731bdcdf5405e48eddfec40407ff8cd194e8f0c67218e5e7ea`).

Both patches extend `exerciseOwner` after line `340` using **only** `GET /events` and `GET /index.html` on the live `runUiOwnerPrepared` sockets (`popup` and `controller`), preserving `Owner.uiCommitCount` (`4` in `Ordinary`, `5` in `RetireThrows`), `Owner.uiActionCount` (`1`), and pinned `production-cli` `warlock-backend` compatibility (`callbacks == 4`, `operations == 1`):

1. **Recommended Controlled Socket/Role Gap & Empty-Queue Non-Mutation Witness (`SOURCE_PREDICTED_PASS` on unmodified `Owner.hs`; zero execution — Refined `2323` Incorporating `terra-engine`, `terra-q-http`, `terra-browser`, and `sol-docs` Reviews)**:
   - Path: `.warlock-contributor/engine-pid1-drafts/gemini-gui-ui-origin-popup-reload-gap-witness-2323.patch`
   - SHA-256: `a2b578374d9483d7b9b50bb6a8c8fc90e3d6426431f495b91a1522d1f6def14f` (postimage `9cc085575d50de0ad35d5dd9c357059d52cd4a76e08b67a29c19a0363955e029`; supersedes preserved immutable initial `2316` witness `a24f75db…`)
   - Exact sequence on live `Owner` role sockets (within unchanged `5s` per-parent `D`):
     1. Pre-stop `Popup` drains all `8` queued `/events` items from the `4` prior commits (`4` `presentation` + `4` `announcements`), verifying the final `presentation` carries `newerFrame` (`publication = "2"`, `lease = "1"`), and confirms the next `GET /events` returns `204`.
     2. Reloaded `Popup` requests `GET /index.html` (`Host` header only) -> `200` with exact `Config.documentBytes` and pinned CSP.
     3. Verifies `Owner.uiLastProjection endpoints == Just (at "projection" newerCommit)` (`Owner` still holds the committed projection).
     4. Verifies `controller` `GET /events` returns `204` (zero reload notification and zero unconfirmed renderer action replay).
     5. Polls `popup` `GET /events` (`X-Warlock-Api: 1`) -> asserts `204` (`B.empty`), proving plain `Document` reload leaves `Popup` without automatic projection bootstrap.
     6. Executes `20` repeated unauthenticated `GET /index.html` requests (`> 16` role queue cap) on the drained queues and verifies `controller` `GET /events == 204`, `popup` `GET /events == 204`, and `RetireThrows`'s subsequent `POST /commit` fence still succeeds `204` — proving unauthenticated `Document` `GET`s leave **no residual enqueued events and do not poison `Popup`/`Controller` queues** under this empty-queue schedule (guarding any future bootstrap implementation against seeding on `Document` `GET`).
   - **Layered Queued-FIFO Non-Consumption Supplement (`sol-docs` sole follow-up owner, verified by `gemini-gui` `01M6CQ59T9WQC6GF0JS4N7QS3Y` & `terra-browser` `01M6CPZD5G90H0R612P3KC0TGA`)**:
     - Because `a2b57837…` drains queues before the `20×` burst (`terra-browser` `01M6CPT97SB6VM5X0TQVCYJ3ZC`, `terra-engine` `01M6CPT9Q6DN1HXDJ8QSWHC3K9`, `terra-q-http` `01M6CPTBSXYTXSWPK2ZQF6X5J3`, `sol-docs` `01M6CPVB4EP9B0RN39C0QZW40X`), `sol-docs` authored `.warlock-contributor/engine-pid1-drafts/sol-ui-document-no-bootstrap-2324.patch` (`sha256:0134e6b174069f93152b1eda07d84ea72f7f581521bfe25c13d865202a0a3070`, `9cc08557…` -> `f37e9447408dfd74a90dd37d3fbadfb9b3e0abe75aaf38382d4f6e9f4d5dff40`), issuing `17` blind `Document` `GET`s *before* draining the `8` pre-existing `Popup` packets and asserting complete independent gateway+payload FIFO equality (`SOURCE_PREDICTED_PASS`; zero execution, unchanged `5s` per-parent `D`).

2. **Deprecated Initial Plain-`GET` Sketch (`DO NOT ADOPT` as Acceptance Oracle)**:
   - Path: `.warlock-contributor/engine-pid1-drafts/gemini-gui-ui-origin-popup-reload-red-regression-2316.patch` (`sha256:b473941341938038438c109977c6b4bf4ff2e732830d8c1c9d22dfa76464eb82`, `SOURCE_PREDICTED_FAIL` on current `Owner.hs`, preserved immutable on disk)
   - **Oracle Safety Note (`terra-engine` `01M6CPNDJ09Q5SJV0RGYT3GKKK`, `terra-q-http` `01M6CPNNXEQ0Q04TJFXJBG74SJ`, `terra-browser` `01M6CPNQ62RC97PDKFY89YV63W`, `sol-docs` `01M6CPSG0TD92J7C99XYT0FHDA`)**: `b4739413…` demanded `popupAfterReloadCode == 200` immediately after plain `GET /index.html` without injecting a trusted host reload-completion callback. Satisfying `b4739413…` without a trusted host callback would force seeding on unauthenticated `Document` `GET` — encoding the exact queue-poisoning/replay hazard prohibited in Section 4. Any future positive recovery test must inject an explicit same-owner trusted host reload-completion / fresh-renderer-instance transition bound to current scope/lease **while keeping both the `17×` pre-drain (`0134e6b1…`) and `20×` post-drain (`a2b57837…`) plain `Document` `GET` non-mutation assertions passing**.

---

## 4. Minimal Proposal (No Broad Rewrite / No New Product API Now)

1. **Immediate Action (Current Wave)**:
   - **Keep `Reload view` (`2245` / `04b7cb38…`) unadopted.** Do not expose an in-page reload button while reload neither bootstraps a fresh `Popup` from `Owner` nor survives `Owner`-stopped listener teardown.
   - Keep visual stopped-state styling (`2247` pure view-style-only `6be4abc3…`, zero button, `Msg`/`update` unchanged) separate and unadopted unless Root explicitly selects visual styling; current `HEAD` `a30ad9e9f` already preserves the read-only retained query draft honestly without claiming reload recovery.
2. **Design Constraints for Any Future Host-Verified Reload/Bootstrap Slice (Not Implemented Now)**:
   - **Never re-seed `queues` from HTTP `GET /index.html` (`Document` route)**:
     - `Policy.hs:65` admits `Document` without `X-Warlock-Api: 1`. Enqueuing on `Document` would let blind same-namespace `GET /index.html` requests fill the 16-item role queue (`Owner.hs:144`) and fail `POST /commit` (`Owner.hs:213` `"UI presentation queue full"`).
     - Even a single-slot `Document` latch delivering a duplicate `Present` of the same `(publication, lease)` to an **already-live** `Popup` would interact with reversed-edit `pendingQuery` settlement at `Popup.elm:135` (`SurfaceRenderer.queryValue snapshot /= Just query`).
   - **Bind any future projection re-seed strictly to a trusted host renderer-reset receipt**:
     - Trigger only from the trusted host (`WebKit.hs` post-initial main-frame reload completion or persistent engine-broker renderer-instance attachment) under `scopeCell` lock when `stopping == False` and `lastProjection == Just currentViewFrame`.
     - Seed at most the single current `gateway "presentation" frameValue` when the freshly reset role's queue has no newer `"presentation"` item — **never** re-delivering one-shot `announcements` or `focus`, and **never** replaying unconfirmed renderer `Actions`.
   - **Honest Draft Scope (`terra-engine` precision)**:
     - `lastProjection` contains only the **last committed controller projection**, never an uncommitted `HttpPopup` `pendingQuery` / preedit draft. Even with future committed-view bootstrap, reloading discards uncommitted local draft memory unless the user copies the retained read-only field first; UI copy and QA claims must never conflate committed-view bootstrap with uncommitted draft recovery.
