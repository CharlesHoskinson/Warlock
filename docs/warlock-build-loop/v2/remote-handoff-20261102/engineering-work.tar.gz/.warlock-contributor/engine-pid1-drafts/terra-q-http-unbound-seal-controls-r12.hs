-- ROOT ONLY; UNEXECUTED. One Case per guardian-owned process. Owner, root,
-- callback worker and separate supervisor must remain strongly retained on
-- every exit. No fake phase, D, root registration or cleanup action.
module QHttpUnboundSealR12 (Case,newCase,releaseBarrier,runFresh,runPrelive,runBound,runActiveScope) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try,throwIO)
import Control.Monad (unless,void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,RootBindingSeal(..),StartBudget,StopBudget,StopReceipt(..),
  StopDeadlineObservation(..),StartupAdmissionFailure(..),newPersistentOwner,
  newPersistentRootCustody,sealPersistentUnboundRoot,withPersistentStartupScope,
  requestSessionStop,tryPersistentStopDeadline)
import Warlock.Platform.Resolver (RootCustody,RootCustodyObservation(..),observeRootCustody)

type Outcome = Either SomeException (Either StartupAdmissionFailure ())
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool) (IORef Int)
 (MVar ()) (MVar ()) (MVar ()) (MVar Outcome) (IORef (Maybe ThreadId))
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False <*> newIORef 0
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ _ _ _ release _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("unbound seal: " ++ label)))
within :: AdmissionDeadline -> String -> IO a -> IO a
within d label action = do
 left <- remainingMicros d
 if left<=0 then ioError (userError (label ++ ": existing D elapsed; retain guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": existing D elapsed; retain guardian"))) pure result
withinBoth :: AdmissionDeadline -> AdmissionDeadline -> String -> IO a -> IO a
withinBoth original stopD label action = do
 a <- remainingMicros original
 b <- remainingMicros stopD
 let left = min a b
 if left<=0 then ioError (userError (label ++ ": existing D elapsed; retain guardian")) else do
  result <- timeout left action
  maybe (ioError (userError (label ++ ": existing D elapsed; retain guardian"))) pure result
claim :: IORef Bool -> IO ()
claim used = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case" fresh
isBusyRoot :: Either ToolError RootCustody -> Bool
isBusyRoot value = case value of Left OwnerBusy -> True; _ -> False

-- Actual stop on the SAME owner selects one original first StopD. No
-- timeout, deadline or child state is manufactured by these controls.
latch :: PersistentOwner -> AdmissionDeadline -> StopBudget -> IO AdmissionDeadline
latch owner originalD budget = do
 stop <- within originalD "real same-owner first stop" (requestSessionStop owner budget)
 selected <- tryPersistentStopDeadline owner
 check "first prelive stop latched" (stop == StopLatchedBeforeLive)
 case selected of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "actual first StopD unavailable")

-- Fresh available owner must not seal while it can still start. Once real
-- stop is latched, the never-bound root receipt becomes sticky; it is not a
-- process, provider, native or whole-cleanup receipt.
runFresh :: Case -> AdmissionDeadline -> StopBudget -> IO ()
runFresh (Case owner _ used _ _ _ _ _ _) originalD budget = do
 claim used
 before <- within originalD "live fresh cannot seal" (sealPersistentUnboundRoot owner)
 check "un-stopped owner remains available" (before==Left OwnerBusy)
 stopD <- latch owner originalD budget
 first <- withinBoth originalD stopD "first post-stop seal" (sealPersistentUnboundRoot owner)
 again <- withinBoth originalD stopD "repeat seal" (sealPersistentUnboundRoot owner)
 candidate <- withinBoth originalD stopD "cannot register after seal" (newPersistentRootCustody owner)
 check "never-bound post-stop receipt sticky" $
  first==Right RootNeverBound && again==Right RootNeverBound && isBusyRoot candidate
 after <- tryPersistentStopDeadline owner
 check "first StopD unchanged" (after==StopDeadlineLatched stopD)

-- Host must run the actual same-owner configuration publication route and
-- independently check its real retained value. Its callback returns True only
-- for the production publication result; fabricated phase/value is invalid.
runPrelive :: Case -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO Bool) -> IO ()
runPrelive (Case owner _ used _ _ _ _ _ _) originalD budget actualConfig = do
 claim used
 published <- within originalD "actual same-owner config publication" (actualConfig owner)
 check "actual config published" published
 before <- within originalD "prelive cannot seal before stop" (sealPersistentUnboundRoot owner)
 check "published open owner cannot seal" (before==Left OwnerBusy)
 stopD <- latch owner originalD budget
 sealed <- withinBoth originalD stopD "published owner post-stop seal" (sealPersistentUnboundRoot owner)
 again <- withinBoth originalD stopD "published sealed owner cannot bind" (newPersistentRootCustody owner)
 after <- tryPersistentStopDeadline owner
 check "prelive stopped before startup scope retains first StopD and prevents bind" $
  sealed==Right RootNeverBound && isBusyRoot again && after==StopDeadlineLatched stopD

-- Registration precedes stop; seal cannot hide the actual bound root.
runBound :: Case -> AdmissionDeadline -> StopBudget -> IO ()
runBound (Case owner rootCell used _ _ _ _ _ _) originalD budget = mask $ \restore -> do
 claim used
 selected <- within originalD "actual root registration" (newPersistentRootCustody owner)
 root <- case selected of Right x -> pure x; Left err -> ioError (userError (show err))
 writeIORef rootCell (Just root)
 before <- restore $ within originalD "open bound owner cannot seal" (sealPersistentUnboundRoot owner)
 check "bound owner remains available before stop" (before==Left OwnerBusy)
 stopD <- restore $ latch owner originalD budget
 result <- restore $ withinBoth originalD stopD "stopped bound owner seal" (sealPersistentUnboundRoot owner)
 status <- observeRootCustody root
 again <- restore $ withinBoth originalD stopD "repeat bound seal" (sealPersistentUnboundRoot owner)
 after <- tryPersistentStopDeadline owner
 check "same owner never hides bound root or renews D" $
  result==Right RootAlreadyBound && again==Right RootAlreadyBound && status==RootNotStarted && after==StopDeadlineLatched stopD

-- Actual startup scope is held BEFORE its first step; stop uses this same
-- owner and existing StopBudget. The worker cannot enter before its ThreadId
-- is published in Case, and failure retains the worker and guardian.
runActiveScope :: Case -> AdmissionDeadline -> StartBudget -> StopBudget -> IO ()
runActiveScope c@(Case owner _ used actionCount start entered release done worker) originalD startupBudget stopBudget = mask $ \restore -> do
 claim used
 tid <- forkIOWithUnmask $ \unmask -> do
  outcome <- try $ unmask $ do
   readMVar start
   withPersistentStartupScope owner startupBudget $ \step _seal -> do
    putMVar entered ()
    readMVar release
    step (atomicModifyIORef' actionCount (\n -> (n+1,())))
  putMVar done outcome
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within originalD "real scope entered" (readMVar entered)
  blocked <- within originalD "active scope cannot seal root" (sealPersistentUnboundRoot owner)
  check "active scope refusal" (blocked==Left OwnerBusy)
  stop <- within originalD "same owner stop" (requestSessionStop owner stopBudget)
  firstD <- tryPersistentStopDeadline owner
  check "first stop actually selected" $
   stop==StopLatchedBeforeLive && case firstD of StopDeadlineLatched _ -> True; _ -> False
  selectedStop <- case firstD of
   StopDeadlineLatched d -> pure d
   _ -> ioError (userError "actual first StopD unavailable")
  releaseBarrier c
  observed <- withinBoth originalD selectedStop "real scope returned" (readMVar done) >>= either throwIO pure
  n <- readIORef actionCount
  check "zero-entry stop remains precise refusal" (observed==Left (StartupAdmissionRefused SessionClosed) && n==0)
  sealed <- withinBoth originalD selectedStop "quiescent never-bound seal" (sealPersistentUnboundRoot owner)
  again <- withinBoth originalD selectedStop "sealed root not bound later" (newPersistentRootCustody owner)
  lastD <- tryPersistentStopDeadline owner
  check "after unwind no new bind and no deadline renewal" $
   sealed==Right RootNeverBound && isBusyRoot again && lastD==firstD
