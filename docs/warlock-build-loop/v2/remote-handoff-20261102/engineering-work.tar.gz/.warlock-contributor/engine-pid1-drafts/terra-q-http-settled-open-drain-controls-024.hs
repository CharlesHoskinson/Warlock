{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY, UNEXECUTED. Run one Case in a separately guarded QA process.
-- The real config, display and original deadlines are supplied by Root. The
-- Case/worker/fds and independent guardian stay rooted on every result/error.
module QHttpSettledOpenDrain (Case,newCase,releaseBarrier,runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,newIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
 loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
 persistentBackendCounts,persistentBackendStartupRefusal,qaDrainHook,qaDrainSlots,
 qaDrainActive,qaDrainStopD,qaDrainCloseRoot,qaDrainReceipts)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Platform.Resolver (RootPart(..),RootStepResult(..))
import Warlock.Platform.Resolver.Internal (QaRootSlot(..))

data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 stopBudget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions stopBudget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ release _ _ _) = void (tryPutMVar release ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
runCase :: Case -> FilePath -> IO ()
runCase c@(Case owner start opened release completed worker used) path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "one case per isolated host" fresh
 exists <- doesPathExist path
 check "real config" (isAbsolute path && exists)
 loaded <- restore (within "same-owner config" (loadPersistentBackendConfig owner path))
 check "config accepted" (loaded == Right ())
 qaDrainHook (putMVar opened () >> readMVar release)
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar completed result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within "actual root-open slot publication" (readMVar opened)
  before <- qaDrainSlots
  activeBefore <- qaDrainActive owner
  check "real root open in flight and two reservations" $
   before == Just (QaSlotOpen,QaSlotUnused) && activeBefore == Just 2
  stopped <- within "same-owner stop" (requestPersistentBackendStop owner)
  firstD <- qaDrainStopD owner
  activeBlocked <- qaDrainActive owner
  blocked <- within "close while real action blocked" (qaDrainCloseRoot owner RootAnchor)
  stillBlocked <- qaDrainActive owner
  slotsBlocked <- qaDrainSlots
  check "blocked action cannot drain or close" $
   stopped == P.StopLatchedBeforeLive && (case firstD of P.StopDeadlineLatched _ -> True; _ -> False) &&
   activeBlocked == Just 2 && stillBlocked == Just 2 && blocked == Left OwnerBusy &&
   slotsBlocked == Just (QaSlotOpen,QaSlotUnused)
  releaseBarrier c
  actual <- within "actual lexical scope return" (readMVar completed) >>= either throwIO pure
  after <- qaDrainActive owner
  sameD <- qaDrainStopD owner
  slotsAfter <- qaDrainSlots
  receipts <- qaDrainReceipts
  check "returned scope drains; actual actor settles only recorded root" $
   after == Just 0 && firstD == sameD && slotsAfter == Just (QaSlotClosed,QaSlotUnused) &&
   receipts == [Right RootStepClosed,Right RootStepNotAcquired] &&
   persistentBackendStartupRefusal actual == Just P.StartupAdmissionUnknown && persistentBackendCounts actual == (0,0)
  repeated <- within "duplicate root close refused" (qaDrainCloseRoot owner RootAnchor)
  endD <- qaDrainStopD owner
  slotsEnd <- qaDrainSlots
  check "no fabricated proc acquisition or root replay" $
   repeated == Left OwnerBusy && endD == firstD && slotsEnd == Just (QaSlotClosed,QaSlotUnused)
