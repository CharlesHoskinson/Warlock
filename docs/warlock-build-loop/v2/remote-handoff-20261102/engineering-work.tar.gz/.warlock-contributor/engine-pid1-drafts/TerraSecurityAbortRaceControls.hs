{-# LANGUAGE OverloadedStrings #-}
-- Source-only QA. Root alone integrates/runs this with WARLOCK_OWNER_QA and
-- WARLOCK_BORROW_QA. The supplier must publish a resolver-verified held image
-- into an outer guardian before returning; no numeric FD or PID is adopted.
-- A timeout is uncertainty, not proof that any worker or resource was retired.
module TerraSecurityAbortRaceControls
 (RaceProbe, newRaceProbe, runRawBusy, runPhaseBusy, runStopGateBusy) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, PersistentStatus(..), SessionExit(..), newPersistentOwner
 , persistentStatus, persistentUnderlyingStatus, persistentHeldNoInput
 , startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal
 ( withPersistentOwnerHook, qaHoldPersistentRawGate, qaHoldPersistentPhaseGate
 , qaHoldPersistentStopGate, qaPersistentPendingIssues )
import Warlock.Platform.Executable (HeldExecutable, qaHoldHeldGate)

type OwnerResult = Either SomeException (Either SessionExit ((), SessionExit))
data RaceProbe = RaceProbe
 { ownerRef :: IORef (Maybe PersistentOwner)
 , heldRef :: IORef (Maybe HeldExecutable)
 , heldTid :: IORef (Maybe ThreadId), conflictTid :: IORef (Maybe ThreadId)
 , ownerTid :: IORef (Maybe ThreadId)
 , heldDone :: MVar (Either SomeException ())
 , conflictDone :: MVar (Either SomeException ())
 , ownerDone :: MVar OwnerResult
 , used :: IORef Bool }

newRaceProbe :: IO RaceProbe
newRaceProbe = RaceProbe <$> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("abort race: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe
 (ioError (userError (label ++ ": retain RaceProbe and exact owners"))) pure

data Mode = RawBusy | PhaseBusy | StopGateBusy deriving (Eq)
runRawBusy, runPhaseBusy, runStopGateBusy :: RaceProbe
 -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runRawBusy = runRace RawBusy
runPhaseBusy = runRace PhaseBusy
runStopGateBusy = runRace StopGateBusy

-- Each mode requires a separate Root-retained one-shot probe. It uses an actual
-- selected held image, but the held gate prevents spawning a child in this run.
runRace :: Mode -> RaceProbe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runRace mode probe acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selection <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 stop <- must (stopBudgetMicros 1000000)
 heldEntered <- newEmptyMVar
 heldRelease <- newEmptyMVar
 borrowBlocked <- newEmptyMVar
 rawCompleted <- newEmptyMVar
 rawContinue <- newEmptyMVar
 conflictEntered <- newEmptyMVar
 conflictRelease <- newEmptyMVar
 spawned <- newIORef (0 :: Int)
 let hook stage = case stage of
      "persistent-before-spawn" -> modifyIORef' spawned (+1)
      "qa-held-borrow-gate-blocked" -> void (tryPutMVar borrowBlocked ())
      "persistent-unborrowed-raw-aborted" -> case mode of
       RawBusy -> pure ()
       _ -> putMVar rawCompleted () >> readMVar rawContinue
      _ -> pure ()
     chosenHold = case mode of
      RawBusy -> qaHoldPersistentRawGate owner
      PhaseBusy -> qaHoldPersistentPhaseGate owner
      StopGateBusy -> qaHoldPersistentStopGate owner
     awaitCreated ref done = do
      thread <- readIORef ref
      case thread of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     cleanup = do
      void (tryPutMVar rawContinue ())
      void (tryPutMVar conflictRelease ())
      void (tryPutMVar heldRelease ())
      awaitCreated (heldTid probe) (heldDone probe)
      awaitCreated (conflictTid probe) (conflictDone probe)
      awaitCreated (ownerTid probe) (ownerDone probe)
     run = do
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldHeldGate held (putMVar heldEntered ()) (readMVar heldRelease))) (putMVar (heldDone probe))
       writeIORef (heldTid probe) (Just tid)
       pure tid
      within "held image gate locked" (readMVar heldEntered)
      start <- startBudgetAfter 1200000 >>= must
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop ready (\_ -> pure ()) hook)) (putMVar (ownerDone probe))
       writeIORef (ownerTid probe) (Just tid)
       pure tid
      within "actual acquire saw busy gate" (readMVar borrowBlocked)
      case mode of
       RawBusy -> pure ()
       _ -> within "checked raw receipt before phase decision" (readMVar rawCompleted)
      _ <- mask_ $ do
       tid <- forkFinally (restore (chosenHold (putMVar conflictEntered ()) (readMVar conflictRelease))) (putMVar (conflictDone probe))
       writeIORef (conflictTid probe) (Just tid)
       pure tid
      within "chosen actual owner gate held" (readMVar conflictEntered)
      case mode of RawBusy -> pure (); _ -> void (tryPutMVar rawContinue ())
      result <- within "owner returns while conflicting gate held" (readMVar (ownerDone probe))
      count <- readIORef spawned
      check "no spawn before refusal" (count == 0)
      let expectedReason = case mode of
           RawBusy -> "startup-unborrowed-raw-abort-unconfirmed"
           PhaseBusy -> "startup-unborrowed-phase-busy"
           StopGateBusy -> "startup-unborrowed-stop-gate-busy"
      check "exact uncertainty result" (case result of
       Right (Left (ExitUncertain CleanupUncertain [reason])) -> reason == expectedReason
       _ -> False)
      void (tryPutMVar conflictRelease ())
      conflictResult <- within "conflicting gate callback completed" (readMVar (conflictDone probe))
      check "conflicting gate holder returned" (case conflictResult of Right () -> True; _ -> False)
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      pending <- qaPersistentPendingIssues owner
      check "preserved precise owner evidence" (case mode of
       RawBusy -> phase == PersistentQuarantined ["startup-unborrowed-raw-abort-unconfirmed"]
        && raw == Starting && maybe False (elem "startup-unborrowed-raw-abort-unconfirmed") pending
       PhaseBusy -> phase == PersistentStarting && raw == Available && pending == Nothing
       StopGateBusy -> phase == PersistentQuarantined ["startup-unborrowed-stop-gate-busy"]
        && raw == Available && pending == Nothing)
 restore run `finally` cleanup
