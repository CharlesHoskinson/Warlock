{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, SOURCE ONLY, UNEXECUTED. One real PersistentOwner per case;
-- a separate host guardian retains the owner and all workers on any timeout.
-- This exercises synchronous returned-action reservation drain, not child,
-- provider, native or whole-owner cleanup.
module TerraEngineReturnedActionDrain
 (Mode(..), Case, newCase, runCase, retainedWorkers, retainedResults) where

import Control.Concurrent (ThreadId, forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException, SomeException, fromException, mask, throwIO, try)
import Control.Monad (unless)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, ToolError(..), remainingMicros)
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, StopBudget, StopReceipt(..), StopDeadlineObservation(..)
 , StartupAdmissionFailure(..), RootBindingSeal(..), newPersistentOwner
 , startBudgetFromDeadline, withPersistentStartupScope, requestSessionStop
 , tryPersistentStopDeadline, sealPersistentUnboundRoot )

data Mode = CompletedAction | StopWhileAction deriving (Eq, Show)
data Case = Case PersistentOwner (IORef Bool) (IORef [ThreadId]) (MVar ()) (MVar ())
 (IORef Bool) (IORef Bool) (IORef (Maybe (Either StartupAdmissionFailure ())))
 (IORef (Maybe (Either StartupAdmissionFailure ())))
 (MVar (Either SomeException (Either StartupAdmissionFailure ())))
 (MVar (Either SomeException (Either ToolError RootBindingSeal)))
 (MVar (Either SomeException StopReceipt))
 (MVar (Either SomeException (Either ToolError RootBindingSeal)))

newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef False <*> newIORef []
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False <*> newIORef False
 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar

retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ workers _ _ _ _ _ _ _ _ _ _) = readIORef workers

-- Read-only access to every preowned completion cell after a watchdog timeout;
-- these snapshots do not cancel a worker or authorize a retry.
retainedResults :: Case -> IO
 ( Maybe (Either SomeException (Either StartupAdmissionFailure ()))
 , Maybe (Either SomeException (Either ToolError RootBindingSeal))
 , Maybe (Either SomeException StopReceipt)
 , Maybe (Either SomeException (Either ToolError RootBindingSeal)) )
retainedResults (Case _ _ _ _ _ _ _ _ _ scope before stop root) =
 (,,,) <$> tryReadMVar scope <*> tryReadMVar before <*> tryReadMVar stop <*> tryReadMVar root

check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("returned-action-drain: " ++ label)))

-- The product call runs on a separately retained worker. Only readMVar is
-- timed out by the supervisor; timeout never cancels the product call.
launch :: IORef [ThreadId] -> MVar (Either SomeException a) -> [AdmissionDeadline] -> IO a -> IO ()
launch workers done bounds action = mask $ \_ -> do
 start <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar start
   left <- minimum <$> mapM remainingMicros bounds
   check "existing D live before fixture dispatch" (left > 0)
   action
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of
    Just _ -> throwIO ex
    Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()

observe :: [AdmissionDeadline] -> String -> MVar a -> IO a
observe deadlines label done = do
 left <- minimum <$> mapM remainingMicros deadlines
 if left <= 0 then ioError (userError (label ++ ": existing D expired; retain guardian")) else do
  result <- timeout left (readMVar done)
  case result of
   Nothing -> ioError (userError (label ++ ": Unknown; retain guardian"))
   Just value -> do
    after <- minimum <$> mapM remainingMicros deadlines
    check (label ++ ": receipt before existing D") (after > 0)
    pure value

-- Host supplies the original absolute StartD and a real StopBudget. No fake
-- owner/phase/clock, PID signal, renewal or externally fabricated receipt.
runCase :: Case -> AdmissionDeadline -> StopBudget -> Mode -> IO ()
runCase (Case owner used workers entered release returned secondEntered firstResult secondResult scopeDone beforeDone stopDone rootDone) originalD stopBudget mode = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "one isolated case" fresh
 launch workers scopeDone [originalD] $
  withPersistentStartupScope owner (startBudgetFromDeadline originalD) $ \step seal -> do
   first <- step $ do
    putMVar entered ()
    readMVar release
    writeIORef returned True
   writeIORef firstResult (Just first)
   case mode of
    CompletedAction -> do
     sealed <- seal
     check "returned positive action can seal its scope" (first == Right () && sealed == Right ())
    StopWhileAction -> do
     again <- step (writeIORef secondEntered True)
     writeIORef secondResult (Just again)
   pure (Right ())
 observe [originalD] "actual action entry" entered
 launch workers beforeDone [originalD] (sealPersistentUnboundRoot owner)
 blocked <- observe [originalD] "seal while action active" beforeDone >>= either throwIO pure
 check "active reservation excludes root seal" (blocked == Left OwnerBusy)
 selected <- case mode of
  CompletedAction -> pure Nothing
  StopWhileAction -> do
   launch workers stopDone [originalD] (requestSessionStop owner stopBudget)
   receipt <- observe [originalD] "actual same-owner first stop" stopDone >>= either throwIO pure
   actual <- tryPersistentStopDeadline owner
   check "first stop selected while action active" (receipt == StopLatchedBeforeLive)
   case actual of
    StopDeadlineLatched d -> pure (Just d)
    _ -> ioError (userError "first StopD not observable; retain owner")
 let bounds = originalD : maybe [] pure selected
 beforeRelease <- minimum <$> mapM remainingMicros bounds
 check "existing D live before releasing entered action" (beforeRelease > 0)
 putMVar release ()
 outcome <- observe bounds "same-thread scope return" scopeDone >>= either throwIO pure
 didReturn <- readIORef returned
 first <- readIORef firstResult
 extra <- readIORef secondEntered
 second <- readIORef secondResult
 case mode of
  CompletedAction -> do
   check "actual returned action reached positive control" (didReturn && first == Just (Right ()) && not extra)
   -- The fixture never starts/retire a real session. Even a correctly sealed
   -- preparation alone is insufficient for successful outer lifecycle.
   check "no fabricated successful lifecycle" (outcome == Left StartupAdmissionUnknown)
  StopWhileAction -> do
   check "returned action stays Unknown after stop and no later action enters" $
    didReturn && first == Just (Left StartupAdmissionUnknown) && not extra &&
    second == Just (Left (StartupAdmissionRefused OwnerBusy)) && outcome == Left StartupAdmissionUnknown
   launch workers rootDone bounds (sealPersistentUnboundRoot owner)
   rootReceipt <- observe bounds "post-unwind root seal" rootDone >>= either throwIO pure
   after <- tryPersistentStopDeadline owner
   check "only after real unwind: never-bound root and unchanged first StopD" $
    rootReceipt == Right RootNeverBound && after == maybe StopDeadlineNotLatched StopDeadlineLatched selected
-- RootNeverBound describes only no root registration. It is not a process,
-- descendant, callback, provider or full cleanup receipt.
