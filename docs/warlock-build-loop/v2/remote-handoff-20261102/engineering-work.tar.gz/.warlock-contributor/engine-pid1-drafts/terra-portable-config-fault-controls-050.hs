{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; source only. One isolated guarded process per case, with actual
-- config and owner. QA hook fires after the real StoreOwner is published and
-- before the config read starts; it is absent from production.
module PortableConfigFaultControls (Mode(..), Case, newCase, release, runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled),SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,atomicModifyIORef',newIORef,writeIORef)
import Data.Text (Text)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,newPersistentBackendOwner,loadPersistentBackendConfig,
 requestPersistentBackendStop,retirePersistentBackend,qaConfigOwnerPublished,qaBackendStopDeadline)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = AsyncBeforeRead | DuplicateConfig deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException (Either Text ()))) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
release :: Case -> IO ()
release (Case _ _ _ barrier _ _ _) = void (tryPutMVar barrier ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: AdmissionDeadline -> Maybe AdmissionDeadline -> String -> IO a -> IO a
within original stop label action = do
 first <- remainingMicros original
 second <- maybe (pure first) remainingMicros stop
 let left = min first second
 if left <= 0 then ioError (userError (label ++ ": original D expired; retain owner and guardian"))
 else timeout left action >>= maybe (ioError (userError (label ++ ": retain owner and guardian"))) pure
runCase :: AdmissionDeadline -> Case -> Mode -> FilePath -> IO ()
runCase original c@(Case owner start entered barrier done worker used) mode path = mask $ \restore -> do
 first <- atomicModifyIORef' used (\prior -> (True,not prior))
 check "one case" first
 exists <- doesPathExist path
 check "real absolute config" (isAbsolute path && exists)
 qaConfigOwnerPublished $ do
  putMVar entered ()
  case mode of AsyncBeforeRead -> throwIO ThreadKilled; DuplicateConfig -> readMVar barrier
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> loadPersistentBackendConfig owner path))
  putMVar done result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within original Nothing "published config owner" (readMVar entered)
  case mode of
   AsyncBeforeRead -> do
    outcome <- within original Nothing "faulted config" (readMVar done)
    case outcome of
     Left problem -> check "original ThreadKilled preserved" (case fromException problem of Just ThreadKilled -> True; _ -> False)
     Right _ -> ioError (userError "config async fault swallowed")
    selected <- within original Nothing "same owner first stop" (qaBackendStopDeadline owner)
    stopD <- case selected of P.StopDeadlineLatched value -> pure value; _ -> ioError (userError "first StopD not latched")
    clean <- within original (Just stopD) "unknown config retirement" (retirePersistentBackend owner)
    check "interrupted config never claims clean" (not clean)
   DuplicateConfig -> do
    duplicate <- within original Nothing "duplicate config" (loadPersistentBackendConfig owner path)
    check "exact duplicate refusal" (duplicate == Left "persistent config owner already used")
    beforeStop <- within original Nothing "original stop gate" (qaBackendStopDeadline owner)
    check "duplicate did not request stop" (beforeStop == P.StopDeadlineNotLatched)
    release c
    loaded <- within original Nothing "first actual config completion" (readMVar done) >>= either throwIO pure
    check "first config still succeeds" (loaded == Right ())
    receipt <- within original Nothing "same owner stop" (requestPersistentBackendStop owner)
    check "first stop latched" (receipt == P.StopLatchedBeforeLive)
