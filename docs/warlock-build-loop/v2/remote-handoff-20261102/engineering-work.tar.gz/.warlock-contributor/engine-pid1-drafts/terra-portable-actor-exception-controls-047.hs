{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY, unexecuted QA source. One mode per externally guarded process.
-- This calls the real Backend and same retained owner; hook is QA-only and
-- fires after the actual Catalog is published, before acquisition or spawn.
module PortableActorExceptionControls (Mode(..), Case, newCase, release, runCase) where
import Control.Concurrent (ThreadId, forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled), IOException, SomeException, fromException, mask, throwIO, try)
import Control.Monad (unless, void)
import Data.IORef (IORef, atomicModifyIORef', newIORef, writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import System.IO.Error (ioeGetErrorString)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Backend (PersistentBackendOwner, PersistentBackendRun, newPersistentBackendOwner,
 loadPersistentBackendConfig, runPersistentBackend, requestPersistentBackendStop,
 retirePersistentBackend, qaAfterCatalogHook, qaBackendStopDeadline)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = InjectAsync | DuplicateStart deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
release :: Case -> IO ()
release (Case _ _ _ barrier _ _ _) = void (tryPutMVar barrier ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: AdmissionDeadline -> Maybe AdmissionDeadline -> String -> IO a -> IO a
within original stop label action = do
 first <- remainingMicros original
 second <- case stop of Nothing -> pure first; Just deadline -> remainingMicros deadline
 let left = min first second
 if left <= 0 then ioError (userError (label ++ ": original deadline expired; retain owner and guardian"))
 else timeout left action >>= maybe (ioError (userError (label ++ ": retain owner, worker and guardian"))) pure
runCase :: AdmissionDeadline -> Case -> Mode -> FilePath -> IO ()
runCase original c@(Case owner start entered barrier done worker used) mode path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\was -> (True,not was))
 check "single case" fresh
 exists <- doesPathExist path
 check "absolute actual config" (isAbsolute path && exists)
 loaded <- restore (within original Nothing "load actual config" (loadPersistentBackendConfig owner path))
 check "config belongs to actor owner" (loaded == Right ())
 qaAfterCatalogHook $ do
  putMVar entered ()
  case mode of InjectAsync -> throwIO ThreadKilled; DuplicateStart -> readMVar barrier
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar done result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  within original Nothing "actual catalog publication" (readMVar entered)
  case mode of
   InjectAsync -> do
    result <- within original Nothing "actor exception" (readMVar done)
    case result of
     Left problem -> check "original ThreadKilled preserved" (case fromException problem of Just ThreadKilled -> True; _ -> False)
     Right _ -> ioError (userError "async exception was swallowed")
    stop <- within original Nothing "owner stop observed" (qaBackendStopDeadline owner)
    check "same owner stop latched" (case stop of P.StopDeadlineLatched _ -> True; _ -> False)
    stopD <- case stop of P.StopDeadlineLatched deadline -> pure deadline; _ -> ioError (userError "missing first stop deadline")
    cleaned <- within original (Just stopD) "uncertain owner observation" (retirePersistentBackend owner)
    check "exception cannot report clean retirement" (not cleaned)
   DuplicateStart -> do
    second <- try (within original Nothing "duplicate actor" (runPersistentBackend owner)) :: IO (Either SomeException PersistentBackendRun)
    case second of
     Left problem -> case fromException problem :: Maybe IOException of
      Just ioProblem -> check "duplicate rejected by actual one-shot guard" (ioeGetErrorString ioProblem == "persistent backend owner already used")
      Nothing -> throwIO problem
     Right _ -> ioError (userError "duplicate actor unexpectedly succeeded")
    beforeStop <- within original Nothing "observe original stop gate" (qaBackendStopDeadline owner)
    check "duplicate did not stop first actor" (beforeStop == P.StopDeadlineNotLatched)
    stop <- within original Nothing "explicit same-owner stop" (requestPersistentBackendStop owner)
    check "explicit stop latched" (stop == P.StopLatchedBeforeLive)
    selected <- within original Nothing "observe selected stop" (qaBackendStopDeadline owner)
    stopD <- case selected of P.StopDeadlineLatched deadline -> pure deadline; _ -> ioError (userError "missing first stop deadline")
    release c
    _ <- within original (Just stopD) "first actor returns" (readMVar done) >>= either throwIO pure
    pure ()
