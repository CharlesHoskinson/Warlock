port module DesktopPolicyAppBatchRetirementReplay213218Z exposing (main)

{-| Production-owning-route (`DesktopPolicy.initial` / `DesktopPolicy.update`)
seeded sequence and contract fixture for pure-application `OutputController`
terminal-reply batch retirement (`gemini-omarchy-outputcontroller-app-batch-retirement-213218Z.patch`).

Every transition enters through `DesktopPolicy.Msg` (`Incoming` / `TransportLost`).
Negative and idempotent transitions assert complete `DesktopPolicy.Model`
structural equality (`afterState == expectedPriorState`) and complete
`List DesktopPolicy.Effect` equality (`afterEffects == []`) without field
filtering or reducer-output harvesting.

Covers:
1. Positive >16 (24 rounds = 48 pure-application catalog/pin commits) remaining
   usable with `pendingBatches == 0` after each terminal domain reply.
2. Same-binding `oldB1receipt-afterB2` (superseded catalog request B1 receipt
   arriving after B2 refresh) -> complete `Policy.Model` no-op, B1 retains custody.
3. Post-rebind `oldB1receipt-afterB2` (old B1 catalog receipt arriving after
   rebind to B2) -> complete `Policy.Model` no-op, B2 batch retains custody.
4. Wrong-binding, mismatched-requestId, malformed gateway, extra-field, and
   malformed-catalog-snapshot receipts -> retain custody (no unsafe retirement).
5. `unresolvedUnknown` (`taskbar-pins-outcome` `"Unknown"` and invalid-revision
   `"Saved"`) + subsequent catalog recovery read -> pin batch retains custody.
6. Mixed startup batch, native observation batch, and native window-operation
   batch -> retain custody across domain receipts until `view-disposition`.
7. Reproducible seeded 32-step `DesktopPolicy` sequence (`seed = 1464617778`).
-}

import Bitwise
import Desktop
import DesktopPolicy as Policy
import Json.Decode as D
import Json.Encode as E
import OutputController as Outputs
import Pins
import Platform
import SurfaceController as Controller


port outgoing : E.Value -> Cmd msg


b1Json : E.Value
b1Json =
    E.object
        [ ( "lifetime", E.string "1" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "1" )
        ]


b2Json : E.Value
b2Json =
    E.object
        [ ( "lifetime", E.string "1" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "2" )
        ]


foreignBindingJson : E.Value
foreignBindingJson =
    E.object
        [ ( "lifetime", E.string "9" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "1" )
        ]


scopeOneJson : E.Value
scopeOneJson =
    E.object [ ( "id", E.string "1" ), ( "generation", E.string "1" ) ]


gatewayWire : String -> E.Value -> E.Value
gatewayWire kindName payloadVal =
    E.object
        [ ( "bridgeProtocol", E.int 1 )
        , ( "kind", E.string kindName )
        , ( "payload", payloadVal )
        ]


topologyWire : String -> E.Value
topologyWire rev =
    gatewayWire "view-topology"
        (E.object
            [ ( "viewProtocol", E.int 2 )
            , ( "kind", E.string "view-topology" )
            , ( "revision", E.string rev )
            , ( "views", E.list (\v -> v) [ scopeOneJson ] )
            , ( "locations"
              , E.list (\v -> v)
                    [ E.object
                        [ ( "scope", scopeOneJson )
                        , ( "box", E.list E.int [ 0, 0, 1280, 720 ] )
                        ]
                    ]
              )
            ]
        )


appAttachedWire : E.Value -> E.Value
appAttachedWire bindVal =
    gatewayWire "native-event"
        (E.object
            [ ( "protocolVersion", E.int 3 )
            , ( "kind", E.string "application-attached" )
            , ( "binding", bindVal )
            , ( "nativeOperations", E.list (\v -> v) [] )
            ]
        )


fullAttachedWire : E.Value -> E.Value
fullAttachedWire bindVal =
    gatewayWire "native-event"
        (E.object
            [ ( "protocolVersion", E.int 3 )
            , ( "kind", E.string "attached" )
            , ( "binding", bindVal )
            ]
        )


catalogSnapshotVal : String -> E.Value
catalogSnapshotVal genText =
    E.object
        [ ( "catalogProtocol", E.int 1 )
        , ( "lifetime", E.string "1" )
        , ( "generation", E.string genText )
        , ( "entries"
          , E.list (\v -> v)
                [ E.object
                    [ ( "id", E.string "alpha.desktop" )
                    , ( "name", E.string "Alpha" )
                    , ( "iconHint", E.string "" )
                    , ( "wmclass", E.string "Alpha" )
                    ]
                , E.object
                    [ ( "id", E.string "beta.desktop" )
                    , ( "name", E.string "Beta" )
                    , ( "iconHint", E.string "" )
                    , ( "wmclass", E.string "Beta" )
                    ]
                ]
          )
        ]


pinsPrefVal : String -> List String -> E.Value
pinsPrefVal revText ids =
    E.object
        [ ( "revision", E.string revText )
        , ( "identities", E.list E.string ids )
        ]


catalogReplyWire : E.Value -> String -> String -> E.Value -> E.Value
catalogReplyWire bindVal reqText genText prefVal =
    gatewayWire "native-event"
        (E.object
            [ ( "protocolVersion", E.int 3 )
            , ( "kind", E.string "application-catalog" )
            , ( "binding", bindVal )
            , ( "requestId", E.string reqText )
            , ( "snapshot", catalogSnapshotVal genText )
            , ( "preferences", prefVal )
            ]
        )


pinOutcomeWire : E.Value -> String -> String -> E.Value -> E.Value
pinOutcomeWire bindVal reqText statusText prefVal =
    gatewayWire "native-event"
        (E.object
            [ ( "protocolVersion", E.int 3 )
            , ( "kind", E.string "taskbar-pins-outcome" )
            , ( "binding", bindVal )
            , ( "requestId", E.string reqText )
            , ( "status", E.string statusText )
            , ( "preferences", prefVal )
            ]
        )


surfaceActionWire : String -> String -> Policy.Model -> E.Value
surfaceActionWire surfaceName controlId policyModel =
    let
        frameVal =
            Outputs.frame policyModel.controller

        pubText =
            D.decodeValue (D.at [ "frame", "publication" ] D.string) frameVal
                |> Result.withDefault "0"

        leaseText =
            D.decodeValue (D.at [ "frame", "lease" ] D.string) frameVal
                |> Result.withDefault "0"
    in
    gatewayWire "view-action"
        (E.object
            [ ( "viewProtocol", E.int 1 )
            , ( "kind", E.string "view-action" )
            , ( "scope", scopeOneJson )
            , ( "action"
              , E.object
                    [ ( "surfaceProtocol", E.int 2 )
                    , ( "kind", E.string "surface-action" )
                    , ( "surface", E.string surfaceName )
                    , ( "publication", E.string pubText )
                    , ( "lease", E.string leaseText )
                    , ( "id", E.string controlId )
                    , ( "trigger", E.string "keyboard" )
                    ]
              )
            ]
        )


dispositionAdmittedWire : E.Value -> String -> String -> E.Value -> E.Value
dispositionAdmittedWire bindVal pubText leaseText commitPacket =
    gatewayWire "view-disposition"
        (E.object
            [ ( "viewProtocol", E.int 1 )
            , ( "kind", E.string "batch-disposition" )
            , ( "disposition", E.string "admitted" )
            , ( "scope", scopeOneJson )
            , ( "revision", E.string "1" )
            , ( "publication", E.string pubText )
            , ( "lease", E.string leaseText )
            , ( "binding", bindVal )
            , ( "batch", E.string (E.encode 0 commitPacket) )
            ]
        )


stepIncoming : E.Value -> Policy.Model -> ( Policy.Model, List Policy.Effect )
stepIncoming wire policyModel =
    Policy.update (Policy.Incoming wire) policyModel


desktopOf : Policy.Model -> Desktop.Model
desktopOf policyModel =
    Controller.desktop (Outputs.controller policyModel.controller)


solePublishedPacket : List Policy.Effect -> Maybe E.Value
solePublishedPacket effects =
    case effects of
        [ Policy.Publish packet ] ->
            Just packet

        _ ->
            Nothing


publishedRequests : List Policy.Effect -> List D.Value
publishedRequests effects =
    case solePublishedPacket effects of
        Nothing ->
            []

        Just packet ->
            D.decodeValue (D.field "requests" (D.list D.value)) packet
                |> Result.withDefault []


firstRequestInfo : List Policy.Effect -> Maybe ( String, String )
firstRequestInfo effects =
    case publishedRequests effects of
        [ single ] ->
            D.decodeValue
                (D.map2 Tuple.pair
                    (D.field "kind" D.string)
                    (D.field "requestId" D.string)
                )
                single
                |> Result.toMaybe

        _ ->
            Nothing


commitHeaderOf : E.Value -> ( String, String )
commitHeaderOf packet =
    let
        pubText =
            D.decodeValue (D.at [ "projection", "frame", "publication" ] D.string) packet
                |> Result.withDefault "0"

        leaseText =
            D.decodeValue (D.at [ "projection", "frame", "lease" ] D.string) packet
                |> Result.withDefault "0"
    in
    ( pubText, leaseText )



-- Ready pure AppOnly session on B1: topology -> application-attached -> initial catalog 1 -> OpenApplications -> catalog 2.


readyAppOnlyPopup : ( Policy.Model, Bool )
readyAppOnlyPopup =
    let
        ( m1, _ ) =
            stepIncoming (topologyWire "1") Policy.initial

        ( m2, eff2 ) =
            stepIncoming (appAttachedWire b1Json) m1

        attachBatchRegistered =
            Outputs.pendingBatches m2.controller == 1 && firstRequestInfo eff2 == Just ( "catalog-request", "1" )

        ( m3, eff3 ) =
            stepIncoming (catalogReplyWire b1Json "1" "1" (pinsPrefVal "1" [ "alpha.desktop" ])) m2

        attachBatchRetired =
            Outputs.pendingBatches m3.controller == 0 && List.isEmpty (publishedRequests eff3)

        ( m4, eff4 ) =
            stepIncoming (surfaceActionWire "bar" "bar:applications" m3) m3

        openBatchRegistered =
            Outputs.pendingBatches m4.controller == 1 && firstRequestInfo eff4 == Just ( "catalog-request", "2" )

        ( m5, eff5 ) =
            stepIncoming (catalogReplyWire b1Json "2" "2" (pinsPrefVal "1" [ "alpha.desktop" ])) m4

        openBatchRetired =
            Outputs.pendingBatches m5.controller == 0 && List.isEmpty (publishedRequests eff5) && (desktopOf m5).open
    in
    ( m5, attachBatchRegistered && attachBatchRetired && openBatchRegistered && openBatchRetired )



-- 1. Positive >16 (24 rounds = 48 pure-application catalog + pin batches) without view-disposition.


checkRepeatedTwentyFourRounds : Bool
checkRepeatedTwentyFourRounds =
    let
        ( startModel, setupOk ) =
            readyAppOnlyPopup

        runRound roundIx ( curModel, curPinRev, curPins, okSoFar ) =
            let
                -- Step A: RefreshApplications (pure catalog-request batch)
                ( afterRefreshReq, refreshEff ) =
                    stepIncoming (surfaceActionWire "popup" "control:refresh" curModel) curModel

                expectedCatReqId =
                    case firstRequestInfo refreshEff of
                        Just ( "catalog-request", reqId ) ->
                            Just reqId

                        _ ->
                            Nothing

                catInFlightOk =
                    Outputs.pendingBatches afterRefreshReq.controller == 1 && expectedCatReqId /= Nothing

                catReqText =
                    Maybe.withDefault "0" expectedCatReqId

                catWire =
                    catalogReplyWire b1Json catReqText (String.fromInt (roundIx + 2)) (pinsPrefVal (String.fromInt curPinRev) curPins)

                ( afterCatReply, catReplyEff ) =
                    stepIncoming catWire afterRefreshReq

                -- Duplicate terminal catalog receipt must be a complete Policy.Model and Effect no-op.
                ( dupCatModel, dupCatEff ) =
                    stepIncoming catWire afterCatReply

                catRetiredOk =
                    Outputs.pendingBatches afterCatReply.controller == 0
                        && List.isEmpty (publishedRequests catReplyEff)
                        && dupCatModel == afterCatReply
                        && dupCatEff == []

                -- Step B: Toggle beta.desktop pin (pure taskbar-pins-write batch)
                toggleControlId =
                    if List.member "beta.desktop" curPins then
                        "unpin:beta.desktop"

                    else
                        "pin:beta.desktop"

                proposedPins =
                    if List.member "beta.desktop" curPins then
                        [ "alpha.desktop" ]

                    else
                        [ "alpha.desktop", "beta.desktop" ]

                ( afterPinReq, pinReqEff ) =
                    stepIncoming (surfaceActionWire "popup" toggleControlId afterCatReply) afterCatReply

                expectedPinReqId =
                    case firstRequestInfo pinReqEff of
                        Just ( "taskbar-pins-write", reqId ) ->
                            Just reqId

                        _ ->
                            Nothing

                pinInFlightOk =
                    Outputs.pendingBatches afterPinReq.controller == 1 && expectedPinReqId /= Nothing

                pinReqText =
                    Maybe.withDefault "0" expectedPinReqId

                ( nextPinRev, nextPins, pinReplyWire ) =
                    if modBy 2 roundIx == 0 then
                        ( curPinRev + 1
                        , proposedPins
                        , pinOutcomeWire b1Json pinReqText "Saved" (pinsPrefVal (String.fromInt (curPinRev + 1)) proposedPins)
                        )

                    else
                        ( curPinRev
                        , curPins
                        , pinOutcomeWire b1Json pinReqText "Refused" E.null
                        )

                ( afterPinReply, pinReplyEff ) =
                    stepIncoming pinReplyWire afterPinReq

                ( dupPinModel, dupPinEff ) =
                    stepIncoming pinReplyWire afterPinReply

                pinRetiredOk =
                    Outputs.pendingBatches afterPinReply.controller == 0
                        && List.isEmpty (publishedRequests pinReplyEff)
                        && Pins.writable (desktopOf afterPinReply).pins
                        && dupPinModel == afterPinReply
                        && dupPinEff == []
            in
            ( afterPinReply
            , nextPinRev
            , nextPins
            , okSoFar && catInFlightOk && catRetiredOk && pinInFlightOk && pinRetiredOk
            )

        ( endModel, _, _, allRoundsOk ) =
            List.foldl runRound ( startModel, 1, [ "alpha.desktop" ], setupOk ) (List.range 1 24)

        ( round25Model, round25Eff ) =
            stepIncoming (surfaceActionWire "popup" "control:refresh" endModel) endModel
    in
    allRoundsOk
        && Outputs.pendingBatches endModel.controller == 0
        && Outputs.pendingBatches round25Model.controller == 1
        && firstRequestInfo round25Eff /= Nothing



-- 2. Same-binding oldB1receipt-afterB2 & Post-rebind oldB1receipt-afterB2.


checkOldB1ReceiptAfterB2 : Bool
checkOldB1ReceiptAfterB2 =
    let
        ( startModel, setupOk ) =
            readyAppOnlyPopup

        -- Issue B1 catalog refresh (reqA), then supersede with B2 catalog refresh (reqB) before B1 replies.
        ( afterB1, effB1 ) =
            stepIncoming (surfaceActionWire "popup" "control:refresh" startModel) startModel

        reqB1 =
            firstRequestInfo effB1 |> Maybe.map Tuple.second |> Maybe.withDefault "0"

        ( afterB2, effB2 ) =
            stepIncoming (surfaceActionWire "popup" "control:refresh" afterB1) afterB1

        reqB2 =
            firstRequestInfo effB2 |> Maybe.map Tuple.second |> Maybe.withDefault "0"

        -- Old B1 receipt arriving after B2 must be a COMPLETE Policy.Model & Effect no-op (retains [B2, B1]).
        ( afterOldB1, oldB1Eff ) =
            stepIncoming (catalogReplyWire b1Json reqB1 "3" (pinsPrefVal "1" [ "alpha.desktop" ])) afterB2

        sameBindingOldNoOp =
            Outputs.pendingBatches afterB2.controller == 2
                && afterOldB1 == afterB2
                && oldB1Eff == []

        -- Terminal B2 reply retires ONLY B2; unanswered B1 retains custody (pendingBatches == 1).
        ( afterCurrentB2, _ ) =
            stepIncoming (catalogReplyWire b1Json reqB2 "4" (pinsPrefVal "1" [ "alpha.desktop" ])) afterOldB1

        onlyB2Retired =
            Outputs.pendingBatches afterCurrentB2.controller == 1

        -- Post-rebind oldB1receipt-afterB2: B1 pending -> TransportLost -> Reconnect -> attach B2 -> old B1 receipt.
        ( t1, _ ) =
            stepIncoming (topologyWire "1") Policy.initial

        ( a1, _ ) =
            stepIncoming (appAttachedWire b1Json) t1

        ( lost1, _ ) =
            Policy.update Policy.TransportLost a1

        ( recon1, _ ) =
            stepIncoming (surfaceActionWire "bar" "bar:reconnect" lost1) lost1

        ( reboundB2, effReboundB2 ) =
            stepIncoming (appAttachedWire b2Json) recon1

        ( afterCrossBindingOldB1, crossBindingEff ) =
            stepIncoming (catalogReplyWire b1Json "1" "1" (pinsPrefVal "1" [])) reboundB2

        rebindOldNoOp =
            Outputs.pendingBatches reboundB2.controller == 1
                && firstRequestInfo effReboundB2 == Just ( "catalog-request", "2" )
                && afterCrossBindingOldB1 == reboundB2
                && crossBindingEff == []
    in
    setupOk && sameBindingOldNoOp && onlyB2Retired && rebindOldNoOp



-- 3. Wrong-binding, mismatched-requestId, malformed outer/inner, and malformed catalog snapshot retain custody.


checkInvalidAndMalformedRetainCustody : Bool
checkInvalidAndMalformedRetainCustody =
    let
        ( startModel, setupOk ) =
            readyAppOnlyPopup

        ( pendingCat, effCat ) =
            stepIncoming (surfaceActionWire "popup" "control:refresh" startModel) startModel

        reqText =
            firstRequestInfo effCat |> Maybe.map Tuple.second |> Maybe.withDefault "0"

        rejectedWires =
            [ catalogReplyWire foreignBindingJson reqText "3" (pinsPrefVal "1" [ "alpha.desktop" ])
            , catalogReplyWire b1Json "999" "3" (pinsPrefVal "1" [ "alpha.desktop" ])
            , E.object [ ( "bridgeProtocol", E.int 2 ), ( "kind", E.string "native-event" ), ( "payload", E.object [] ) ]
            , gatewayWire "native-event"
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "application-catalog" )
                    , ( "binding", b1Json )
                    , ( "requestId", E.string reqText )
                    , ( "snapshot", catalogSnapshotVal "3" )
                    , ( "unexpected", E.bool True )
                    ]
                )
            ]

        allRejectedCompleteNoOp =
            List.all
                (\badWire ->
                    let
                        ( nextM, nextE ) =
                            stepIncoming badWire pendingCat
                    in
                    nextM == pendingCat && nextE == [] && Outputs.pendingBatches nextM.controller == 1
                )
                rejectedWires

        -- Accepted envelope with malformed inner catalog snapshot fails Catalog.decode -> applications == Nothing -> MUST retain custody!
        malformedSnapshotWire =
            gatewayWire "native-event"
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "application-catalog" )
                    , ( "binding", b1Json )
                    , ( "requestId", E.string reqText )
                    , ( "snapshot", E.object [ ( "catalogProtocol", E.int 99 ) ] )
                    , ( "preferences", E.null )
                    ]
                )

        ( afterBadSnap, _ ) =
            stepIncoming malformedSnapshotWire pendingCat

        badSnapshotRetainsCustody =
            (desktopOf afterBadSnap).applications == Nothing
                && Outputs.pendingBatches afterBadSnap.controller == 1
    in
    setupOk && allRejectedCompleteNoOp && badSnapshotRetainsCustody



-- 4. unresolvedUnknown pin outcomes & subsequent catalog recovery read retain pin batch custody.


checkUnresolvedUnknownRetainsCustody : Bool
checkUnresolvedUnknownRetainsCustody =
    let
        ( startModel, setupOk ) =
            readyAppOnlyPopup

        ( pendingPin, pinEff ) =
            stepIncoming (surfaceActionWire "popup" "pin:beta.desktop" startModel) startModel

        pinReqText =
            firstRequestInfo pinEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

        -- Invalid status "Stored" is a complete Policy.Model & Effect no-op.
        ( afterInvalidStatus, invalidEff ) =
            stepIncoming (pinOutcomeWire b1Json pinReqText "Stored" E.null) pendingPin

        invalidStatusNoOp =
            afterInvalidStatus == pendingPin && invalidEff == []

        -- Branch A: "Saved" with non-advancing revision "1" transitions Pins to Unconfirmed -> MUST retain custody!
        ( afterBadSaved, _ ) =
            stepIncoming (pinOutcomeWire b1Json pinReqText "Saved" (pinsPrefVal "1" [ "alpha.desktop", "beta.desktop" ])) pendingPin

        badSavedRetainsCustody =
            Outputs.pendingBatches afterBadSaved.controller == 1
                && (desktopOf afterBadSaved).pins.pending /= Nothing
                && not (Pins.writable (desktopOf afterBadSaved).pins)

        -- Branch B: "Unknown" -> unresolvedUnknown retains custody; duplicate Unknown is complete no-op;
        -- recovery catalog refresh retires ONLY the catalog batch while pin batch retains custody!
        ( afterUnknown, _ ) =
            stepIncoming (pinOutcomeWire b1Json pinReqText "Unknown" E.null) pendingPin

        ( dupUnknown, dupEff ) =
            stepIncoming (pinOutcomeWire b1Json pinReqText "Unknown" E.null) afterUnknown

        unknownRetains =
            Outputs.pendingBatches afterUnknown.controller == 1
                && not (Pins.writable (desktopOf afterUnknown).pins)
                && dupUnknown == afterUnknown
                && dupEff == []

        ( afterRecReq, recEff ) =
            stepIncoming (surfaceActionWire "popup" "control:refresh" afterUnknown) afterUnknown

        recReqText =
            firstRequestInfo recEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

        ( afterRecReply, _ ) =
            stepIncoming (catalogReplyWire b1Json recReqText "4" (pinsPrefVal "2" [ "alpha.desktop", "beta.desktop" ])) afterRecReq

        recoveryKeepsUnknownPinBatch =
            Outputs.pendingBatches afterRecReq.controller == 2
                && Outputs.pendingBatches afterRecReply.controller == 1
                && Pins.writable (desktopOf afterRecReply).pins
    in
    setupOk && invalidStatusNoOp && badSavedRetainsCustody && unknownRetains && recoveryKeepsUnknownPinBatch



-- 5. Mixed startup, native observation, and native window-operation batches retain custody.


checkNativeAndMixedBatchesRetainCustody : Bool
checkNativeAndMixedBatchesRetainCustody =
    let
        ( m1, _ ) =
            stepIncoming (topologyWire "1") Policy.initial

        -- Full shell "attached" emits mixed [catalog 1, settings 2, motion 3, shortcuts 4, projection 1].
        ( m2, eff2 ) =
            stepIncoming (fullAttachedWire b1Json) m1

        mixedPacket =
            solePublishedPacket eff2

        -- Authoritative catalog 1 reply MUST NOT retire mixed startup batch!
        ( m3, _ ) =
            stepIncoming (catalogReplyWire b1Json "1" "1" (pinsPrefVal "1" [])) m2

        mixedRetained =
            Outputs.pendingBatches m2.controller == 1 && Outputs.pendingBatches m3.controller == 1

        -- Reconcile action-projection 1 + pointer-ownership idle, then issue window Minimize operation.
        projWire reqId revText =
            gatewayWire "native-event"
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "action-projection" )
                    , ( "binding", b1Json )
                    , ( "requestId", E.string reqId )
                    , ( "context"
                      , E.object
                            [ ( "lifetime", E.string "1" )
                            , ( "epoch", E.string "1" )
                            , ( "output", E.string "1" )
                            , ( "revision", E.string revText )
                            ]
                      )
                    , ( "scene"
                      , E.object
                            [ ( "revision", E.string revText )
                            , ( "focused", E.string "1" )
                            , ( "windows"
                              , E.list (\v -> v)
                                    [ E.object
                                        [ ( "incarnation", E.string "1" )
                                        , ( "label", E.string "Window" )
                                        , ( "minimized", E.bool False )
                                        , ( "owner", E.null )
                                        , ( "application", E.string "demo" )
                                        , ( "available", E.bool True )
                                        ]
                                    ]
                              )
                            ]
                      )
                    ]
                )

        pointerIdleWire =
            gatewayWire "native-event"
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "pointer-ownership" )
                    , ( "ownershipProtocol", E.int 1 )
                    , ( "binding", b1Json )
                    , ( "requestId", E.string "1" )
                    , ( "serial", E.string "1" )
                    , ( "state", E.string "idle" )
                    , ( "owner", E.null )
                    ]
                )

        ( m4, _ ) =
            stepIncoming (projWire "1" "1") m3

        ( m5, _ ) =
            stepIncoming pointerIdleWire m4

        ( m6, eff6 ) =
            stepIncoming (surfaceActionWire "bar" "bar:group:application:demo" m5) m5

        opPacket =
            solePublishedPacket eff6

        effectCommittedWire =
            gatewayWire "native-event"
                (E.object
                    [ ( "protocolVersion", E.int 3 )
                    , ( "kind", E.string "effect-outcome" )
                    , ( "effectProtocol", E.int 1 )
                    , ( "binding", b1Json )
                    , ( "intent"
                      , E.object
                            [ ( "request", E.string "1" )
                            , ( "generation", E.string "1" )
                            , ( "incarnation", E.string "1" )
                            , ( "operation", E.string "minimize" )
                            , ( "context"
                              , E.object
                                    [ ( "lifetime", E.string "1" )
                                    , ( "epoch", E.string "1" )
                                    , ( "output", E.string "1" )
                                    , ( "revision", E.string "1" )
                                    ]
                              )
                            ]
                      )
                    , ( "status", E.string "Committed" )
                    , ( "reason", E.string "applied" )
                    , ( "revision", E.string "2" )
                    , ( "outputGeneration", E.string "1" )
                    ]
                )

        -- Committed window outcome emits projection-request 2; ALL THREE non-pure batches retain custody!
        ( m7, eff7 ) =
            stepIncoming effectCommittedWire m6

        obsPacket =
            solePublishedPacket eff7

        allThreeRetained =
            Outputs.pendingBatches m6.controller == 2 && Outputs.pendingBatches m7.controller == 3

        -- Explicit view-disposition "admitted" retires each non-pure batch one by one.
        retirePacket maybePkt cur =
            case maybePkt of
                Nothing ->
                    cur

                Just pkt ->
                    let
                        ( pubT, leaseT ) =
                            commitHeaderOf pkt
                    in
                    stepIncoming (dispositionAdmittedWire b1Json pubT leaseT pkt) cur |> Tuple.first

        m8 =
            retirePacket mixedPacket m7

        m9 =
            retirePacket opPacket m8

        m10 =
            retirePacket obsPacket m9
    in
    mixedRetained
        && allThreeRetained
        && Outputs.pendingBatches m8.controller == 2
        && Outputs.pendingBatches m9.controller == 1
        && Outputs.pendingBatches m10.controller == 0



-- 6. Seeded 32-step reproducible DesktopPolicy sequence property (seed = 1464617778).


lcgNext : Int -> Int
lcgNext state =
    Bitwise.shiftRightZfBy 0 (state * 1664525 + 1013904223)


checkSeededSequenceProperty : Int -> ( Bool, Maybe E.Value )
checkSeededSequenceProperty masterSeed =
    let
        ( startModel, setupOk ) =
            readyAppOnlyPopup

        stepSeed stepIx ( rng, curModel, curRev, curPins, failure ) =
            if failure /= Nothing then
                ( rng, curModel, curRev, curPins, failure )

            else
                let
                    rng1 =
                        lcgNext rng

                    variant =
                        modBy 5 rng1
                in
                case variant of
                    0 ->
                        -- Authoritative catalog refresh + wrong-binding negative check before settlement
                        let
                            ( reqModel, reqEff ) =
                                stepIncoming (surfaceActionWire "popup" "control:refresh" curModel) curModel

                            reqId =
                                firstRequestInfo reqEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

                            ( wrongModel, wrongEff ) =
                                stepIncoming (catalogReplyWire foreignBindingJson reqId (String.fromInt (stepIx + 10)) (pinsPrefVal (String.fromInt curRev) curPins)) reqModel

                            ( settledModel, _ ) =
                                stepIncoming (catalogReplyWire b1Json reqId (String.fromInt (stepIx + 10)) (pinsPrefVal (String.fromInt curRev) curPins)) wrongModel

                            stepOk =
                                Outputs.pendingBatches reqModel.controller == 1
                                    && wrongModel == reqModel
                                    && wrongEff == []
                                    && Outputs.pendingBatches settledModel.controller == 0
                        in
                        ( rng1
                        , settledModel
                        , curRev
                        , curPins
                        , if stepOk then
                            Nothing

                          else
                            Just (E.object [ ( "seed", E.int masterSeed ), ( "step", E.int stepIx ), ( "variant", E.string "catalog-refresh" ) ])
                        )

                    1 ->
                        -- Terminal Saved pin toggle
                        let
                            ctlId =
                                if List.member "beta.desktop" curPins then
                                    "unpin:beta.desktop"

                                else
                                    "pin:beta.desktop"

                            nextPins =
                                if List.member "beta.desktop" curPins then
                                    [ "alpha.desktop" ]

                                else
                                    [ "alpha.desktop", "beta.desktop" ]

                            ( reqModel, reqEff ) =
                                stepIncoming (surfaceActionWire "popup" ctlId curModel) curModel

                            reqId =
                                firstRequestInfo reqEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

                            nextRev =
                                curRev + 1

                            ( settledModel, _ ) =
                                stepIncoming (pinOutcomeWire b1Json reqId "Saved" (pinsPrefVal (String.fromInt nextRev) nextPins)) reqModel

                            stepOk =
                                Outputs.pendingBatches reqModel.controller == 1
                                    && Outputs.pendingBatches settledModel.controller == 0
                        in
                        ( rng1
                        , settledModel
                        , nextRev
                        , nextPins
                        , if stepOk then
                            Nothing

                          else
                            Just (E.object [ ( "seed", E.int masterSeed ), ( "step", E.int stepIx ), ( "variant", E.string "pin-saved" ) ])
                        )

                    2 ->
                        -- Terminal Refused pin toggle
                        let
                            ctlId =
                                if List.member "beta.desktop" curPins then
                                    "unpin:beta.desktop"

                                else
                                    "pin:beta.desktop"

                            ( reqModel, reqEff ) =
                                stepIncoming (surfaceActionWire "popup" ctlId curModel) curModel

                            reqId =
                                firstRequestInfo reqEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

                            ( settledModel, _ ) =
                                stepIncoming (pinOutcomeWire b1Json reqId "Refused" E.null) reqModel

                            stepOk =
                                Outputs.pendingBatches reqModel.controller == 1
                                    && Outputs.pendingBatches settledModel.controller == 0
                        in
                        ( rng1
                        , settledModel
                        , curRev
                        , curPins
                        , if stepOk then
                            Nothing

                          else
                            Just (E.object [ ( "seed", E.int masterSeed ), ( "step", E.int stepIx ), ( "variant", E.string "pin-refused" ) ])
                        )

                    3 ->
                        -- Unknown pin write retains batch until explicit view-disposition + catalog recovery read
                        let
                            ctlId =
                                if List.member "beta.desktop" curPins then
                                    "unpin:beta.desktop"

                                else
                                    "pin:beta.desktop"

                            ( reqModel, reqEff ) =
                                stepIncoming (surfaceActionWire "popup" ctlId curModel) curModel

                            reqId =
                                firstRequestInfo reqEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

                            pinPkt =
                                solePublishedPacket reqEff

                            ( unkModel, _ ) =
                                stepIncoming (pinOutcomeWire b1Json reqId "Unknown" E.null) reqModel

                            ( recReqModel, recEff ) =
                                stepIncoming (surfaceActionWire "popup" "control:refresh" unkModel) unkModel

                            recReqId =
                                firstRequestInfo recEff |> Maybe.map Tuple.second |> Maybe.withDefault "0"

                            ( recDoneModel, _ ) =
                                stepIncoming (catalogReplyWire b1Json recReqId (String.fromInt (stepIx + 20)) (pinsPrefVal (String.fromInt curRev) curPins)) recReqModel

                            retainedBeforeDisposition =
                                Outputs.pendingBatches unkModel.controller == 1
                                    && Outputs.pendingBatches recReqModel.controller == 2
                                    && Outputs.pendingBatches recDoneModel.controller == 1

                            clearedModel =
                                case pinPkt of
                                    Nothing ->
                                        recDoneModel

                                    Just pkt ->
                                        let
                                            ( pubT, leaseT ) =
                                                commitHeaderOf pkt
                                        in
                                        stepIncoming (dispositionAdmittedWire b1Json pubT leaseT pkt) recDoneModel |> Tuple.first

                            stepOk =
                                retainedBeforeDisposition && Outputs.pendingBatches clearedModel.controller == 0
                        in
                        ( rng1
                        , clearedModel
                        , curRev
                        , curPins
                        , if stepOk then
                            Nothing

                          else
                            Just (E.object [ ( "seed", E.int masterSeed ), ( "step", E.int stepIx ), ( "variant", E.string "pin-unknown-retained" ) ])
                        )

                    _ ->
                        -- Malformed outer envelope + stale catalog receipt complete no-op
                        let
                            ( afterMalformed, effMalformed ) =
                                stepIncoming (E.object [ ( "bridgeProtocol", E.int 1 ), ( "kind", E.string "unapproved" ), ( "payload", E.null ) ]) curModel

                            ( afterStale, effStale ) =
                                stepIncoming (catalogReplyWire b1Json "1" "1" (pinsPrefVal (String.fromInt curRev) curPins)) afterMalformed

                            stepOk =
                                afterMalformed == curModel
                                    && effMalformed == []
                                    && afterStale == curModel
                                    && effStale == []
                                    && Outputs.pendingBatches afterStale.controller == 0
                        in
                        ( rng1
                        , afterStale
                        , curRev
                        , curPins
                        , if stepOk then
                            Nothing

                          else
                            Just (E.object [ ( "seed", E.int masterSeed ), ( "step", E.int stepIx ), ( "variant", E.string "malformed-stale-noop" ) ])
                        )

        ( _, finalModel, _, _, firstFailure ) =
            List.foldl stepSeed
                ( masterSeed
                , startModel
                , 1
                , [ "alpha.desktop" ]
                , if setupOk then
                    Nothing

                  else
                    Just (E.string "setup-failed")
                )
                (List.range 1 32)
    in
    ( firstFailure == Nothing && Outputs.pendingBatches finalModel.controller == 0, firstFailure )


reportValue : E.Value
reportValue =
    let
        seedConst =
            1464617778

        ( seededOk, counterexample ) =
            checkSeededSequenceProperty seedConst

        checks =
            [ ( "repeatedTwentyFourCatalogAndPinRoundsRemainUsable", checkRepeatedTwentyFourRounds )
            , ( "oldB1ReceiptAfterB2SameBindingAndRebindNoOp", checkOldB1ReceiptAfterB2 )
            , ( "wrongBindingStaleAndMalformedReceiptsRetainCustody", checkInvalidAndMalformedRetainCustody )
            , ( "unresolvedUnknownAndRecoveryReadRetainPinCustody", checkUnresolvedUnknownRetainsCustody )
            , ( "nativeObservationOperationAndMixedBatchesRetainCustody", checkNativeAndMixedBatchesRetainCustody )
            , ( "seededDesktopPolicySequence32Steps", seededOk )
            ]

        allPassed =
            List.all Tuple.second checks
    in
    E.object
        [ ( "passed", E.bool allPassed )
        , ( "nativeAcceptance", E.bool False )
        , ( "guiAcceptance", E.bool False )
        , ( "seed", E.int seedConst )
        , ( "seedSteps", E.int 32 )
        , ( "counterexample", Maybe.withDefault E.null counterexample )
        , ( "checks", E.object (List.map (Tuple.mapSecond E.bool) checks) )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing reportValue )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
