-- Root-only candidate component fixture. Real AF_UNIX socketpairs exercise the
-- proposed readiness primitive; permissive STM latch is not an owner proof.
-- This does not exercise CredentialIngress, SCM, native UI or any original
-- scenario, and must not replace the existing 5s frame or diagnostic tests.
module Main (main) where

import Control.Concurrent (MVar, ThreadId, forkFinally, killThread, newEmptyMVar, putMVar, readMVar, threadDelay)
import GHC.Conc (STM, TVar, atomically, newTVarIO, readTVar, retry, writeTVar)
import Control.Exception (SomeException, bracket, finally)
import Control.Monad (forM_, unless)
import qualified Data.ByteString as B
import qualified Network.Socket as Socket
import qualified Network.Socket.ByteString as Net
import System.Timeout (timeout)
import Warlock.Transport.PersistentIdleWait

data MockWake = MockStop | MockDeath deriving (Eq, Show)

stopWhenSet :: TVar Bool -> STM ()
stopWhenSet latch = do
  stopped <- readTVar latch
  if stopped then pure () else retry

checkIO :: String -> Bool -> IO ()
checkIO label ok = unless ok (ioError (userError label))
withPair :: ((Socket.Socket,Socket.Socket) -> IO a) -> IO a
withPair = bracket (Socket.socketPair Socket.AF_UNIX Socket.Stream Socket.defaultProtocol)
  (\(a,b) -> Socket.close a `finally` Socket.close b)

-- The fixture owns and joins each watcher before its socket can be closed.
withWait :: IO (IdleWake ()) -> (MVar (Either SomeException (IdleWake ())) -> IO a) -> IO a
withWait operation action = bracket start finish (action . snd)
  where
    start = do
      done <- newEmptyMVar
      tid <- forkFinally operation (putMVar done)
      pure (tid,done)
    finish :: (ThreadId, MVar (Either SomeException (IdleWake ()))) -> IO ()
    finish (tid,done) = killThread tid >> readMVar done >> pure ()

bounded :: String -> IO a -> IO a
bounded label task = timeout 2000000 task >>= maybe (ioError (userError label)) pure

-- Stream receives may split even a short send; the outer timeout is one D.
receiveExactly :: Socket.Socket -> Int -> IO B.ByteString
receiveExactly socket count = bounded "expected bytes unavailable" (go count [])
  where
    go 0 pieces = pure (B.concat (reverse pieces))
    go left pieces = do
      bytes <- Net.recv socket left
      if B.null bytes then ioError (userError "early EOF")
        else go (left - B.length bytes) (bytes : pieces)

main :: IO ()
main = do
  -- A fresh wait may stay idle longer than a frame: the actual 5s frame D
  -- has not started. This 5.3s is a fixture schedule, not a new product D.
  withPair $ \(owned, peer) -> do
    latch <- newTVarIO False
    withWait (waitReadableOrStop owned (stopWhenSet latch)) $ \done -> do
      threadDelay 5300000
      early <- timeout 1000 (readMVar done)
      checkIO "quiet wait completed before readiness" (case early of Nothing -> True; _ -> False)
      Net.sendAll peer (B.pack [1,2,3,4])
      result <- bounded "readiness did not wake" (readMVar done)
      checkIO "readable result" (case result of Right Readable -> True; _ -> False)
      bytes <- receiveExactly owned 4
      checkIO "readiness preserves exact bytes" (bytes == B.pack [1,2,3,4])
  withPair $ \(owned, _peer) -> do
    latch <- newTVarIO False
    withWait (waitReadableOrStop owned (stopWhenSet latch)) $ \done -> do
      atomically (writeTVar latch True)
      result <- bounded "stop did not wake" (readMVar done)
      checkIO "stop result" (case result of Right (OwnerWake ()) -> True; _ -> False)
  -- Pre-latched stop and pre-buffered bytes establish priority, not a race schedule.
  forM_ [1..32 :: Int] $ \seed -> withPair $ \(owned, peer) -> do
    latch <- newTVarIO True
    let byte = fromIntegral seed
    Net.sendAll peer (B.singleton byte)
    outcome <- bounded "latched stop/read stalled" (waitReadableOrStop owned (stopWhenSet latch))
    checkIO "latched stop has priority" (outcome == OwnerWake ())
    bytes <- bounded "latched wait consumed data" (Net.recv owned 1)
    checkIO "latched wait leaves byte" (bytes == B.singleton byte)
  -- The helper preserves the owner's distinct reason; these are synthetic
  -- values, not evidence of an actual stop, pidfd or child exit.
  forM_ [MockStop, MockDeath] $ \reason -> withPair $ \(owned, peer) -> do
    Net.sendAll peer (B.singleton 77)
    wake <- bounded "owner reason was lost" (waitReadableOrStop owned (pure reason))
    bytes <- bounded "owner wake consumed byte" (Net.recv owned 1)
    checkIO "exact owner reason retained" (wake == OwnerWake reason && bytes == B.singleton 77)
  -- EOF wakes the same readiness path; only the subsequent read establishes EOF.
  withPair $ \(owned, peer) -> do
    Socket.shutdown peer Socket.ShutdownSend
    latch <- newTVarIO False
    result <- bounded "EOF not readable" (waitReadableOrStop owned (stopWhenSet latch))
    eof <- bounded "EOF read blocked" (Net.recv owned 1)
    checkIO "EOF observation" (result == Readable && B.null eof)
  -- A fresh wait still works after cancellation; this does not by itself prove
  -- the event-manager released the old registration or excluded a stale watcher.
  withPair $ \(owned, peer) -> do
    latch <- newTVarIO False
    cancelled <- timeout 20000 (waitReadableOrStop owned (stopWhenSet latch))
    checkIO "quiet cancellation" (cancelled == Nothing)
    Net.sendAll peer (B.singleton 42)
    fresh <- bounded "post-cancellation registration failed" (waitReadableOrStop owned (stopWhenSet latch))
    bytes <- bounded "post-cancellation byte unavailable" (Net.recv owned 1)
    checkIO "fresh registration and byte" (fresh == Readable && bytes == B.singleton 42)
  putStrLn "persistent idle source controls passed"
