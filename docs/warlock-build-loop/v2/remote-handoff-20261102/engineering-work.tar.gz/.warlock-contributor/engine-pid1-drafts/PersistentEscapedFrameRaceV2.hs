{-# LANGUAGE ScopedTypeVariables #-}
-- Unexecuted QA-only fixture for proposed persistent process custody. It runs
-- the actual owner/session/frame API against a Root-supplied owned fixture
-- child and readiness verifier; it does not claim native/provider cleanup.
module PersistentEscapedFrameRaceV2 (ProbeCustody(..), runEscapedFrameRace) where

import Control.Concurrent (ThreadId, forkFinally, isEmptyMVar, newEmptyMVar, putMVar, readMVar, tryPutMVar, tryReadMVar)
import Control.Concurrent.MVar (MVar)
import Control.Exception (IOException, SomeException, catch, finally, onException)
import Control.Monad (unless, void)
import Data.IORef (IORef, newIORef, readIORef, writeIORef)
import System.IO (Handle, IOMode(ReadMode), openFile)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError(..), deadlineAfter)
import Warlock.Capture.Process.Persistent
  ( LiveOperationFailure(..), PersistentOwner, SessionExit(..), StopReceipt(..)
  , enterLiveFrameAction, newPersistentOwner, requestSessionStop, startBudgetAfter
  , stopBudgetMicros, withLiveFrameAdmission )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)

-- The caller MUST store this bundle in an owned recovery registry whenever
-- cleanup cannot confirm BOTH owned-leader reap and callback completion. The
-- input handle and threads must not be silently closed/killed or forgotten.
data ProbeCustody = ProbeCustody
  { probeOwner :: PersistentOwner
  , probeInput :: Handle
  , probeOwnerThread :: ThreadId
  , probeActionThread :: IORef (Maybe ThreadId)
  , probeReleaseAction :: MVar ()
  , probeReleaseBody :: MVar ()
  , probeActionDone :: MVar (Either SomeException (Either LiveOperationFailure ()))
  , probeOwnerDone :: MVar (Either SomeException (Either SessionExit ((), SessionExit)))
  }

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("PersistentEscapedFrameRaceV2: " ++ label)))

-- The child must remain alive after verifyReady until the owner requests stop.
-- retainUncertain must durably retain the bundle for Root's owned cleanup. The
-- 150ms observation is a bounded race control, not a proof of all schedules.
runEscapedFrameRace :: FilePath -> [String]
  -> (SessionObservation -> IO (Either ToolError ()))
  -> (ProbeCustody -> IO ()) -> IO ()
runEscapedFrameRace childExe childArgs verifyReady retainUncertain = do
  owner <- newPersistentOwner
  start <- startBudgetAfter 2000000 >>= either (ioError . userError . show) pure
  stopBudget <- either (ioError . userError . show) pure (stopBudgetMicros 2000000)
  input <- openFile "/dev/null" ReadMode
  actionStarted <- newEmptyMVar
  actionBodyFinished <- newEmptyMVar
  actionRelease <- newEmptyMVar
  bodyRelease <- newEmptyMVar
  frameReturned <- newEmptyMVar
  beforeReap <- newEmptyMVar
  actionDone <- newEmptyMVar
  ownerDone <- newEmptyMVar
  actionThread <- newIORef Nothing
  escapedEntered <- newIORef False
  earlyDrainObserved <- newIORef False
  let hook name = case name of
        "persistent-after-operation-drain-before-reap" -> do
          active <- isEmptyMVar actionBodyFinished
          if active then writeIORef earlyDrainObserved True else pure ()
          void (tryPutMVar beforeReap ())
        _ -> pure ()
      liveBody session = do
        -- Independent frame/action budgets are minted once after readiness.
        frameDeadline <- deadlineAfter 5000000 >>= either (ioError . userError . show) pure
        actionDeadline <- deadlineAfter 1500000 >>= either (ioError . userError . show) pure
        result <- withLiveFrameAdmission session $ \admission -> do
          worker <- forkFinally
            (enterLiveFrameAction admission frameDeadline actionDeadline $ do
              putMVar actionStarted ()
              readMVar actionRelease
              -- Marker immediately before return; strongest checked interval
              -- is while the callback is deliberately blocked above.
              putMVar actionBodyFinished ()
              pure (Right ()))
            (putMVar actionDone)
          writeIORef actionThread (Just worker)
          readMVar actionStarted
          pure admission
        putMVar frameReturned (result,frameDeadline,actionDeadline)
        readMVar bodyRelease
  ownerThread <- forkFinally
    (withPersistentOwnerHook owner (persistentFixture childExe childArgs input)
      4096 start stopBudget verifyReady liveBody hook)
    (putMVar ownerDone)
  let custody = ProbeCustody owner input ownerThread actionThread actionRelease bodyRelease actionDone ownerDone
      cleanup = (do
        void (tryPutMVar actionRelease ())
        void (tryPutMVar bodyRelease ())
        void (requestSessionStop owner stopBudget `catch` \(_ :: IOException) -> pure StopNoLiveSession)
        outcome <- timeout 2500000 (readMVar ownerDone)
        callback <- tryReadMVar actionDone
        case (outcome,callback) of
          (Just (Right (Right ((), LeaderReaped _))), Just _) -> pure ()
          _ -> retainUncertain custody) `onException` retainUncertain custody
      body = do
        entered <- timeout 1000000 (readMVar actionStarted)
        check "nested-action-entered" (entered == Just ())
        -- Either a parent that already returned or a parent which waits for
        -- its entered child is valid. Test an escaped token independently only
        -- if it became available while the owner is still live.
        earlyFrame <- tryReadMVar frameReturned
        case earlyFrame of
          Just (Right admission,frameDl,actionDl) -> do
            stale <- enterLiveFrameAction admission frameDl actionDl $ do
              writeIORef escapedEntered True
              pure (Right ())
            ranEscaped <- readIORef escapedEntered
            check "returned-token-refused-before-stop" (stale == Left (OperationRefusedPreDispatch SessionClosed) && not ranEscaped)
          Just (Left _,_,_) -> check "frame-scope-entered" False
          Nothing -> pure ()
        receipt <- timeout 500000 (requestSessionStop owner stopBudget)
        check "owned-stop-latched" (case receipt of Just StopSignalSent -> True; _ -> False)
        void (tryPutMVar bodyRelease ())
        early <- timeout 150000 (readMVar beforeReap)
        check "blocked-entered-action-prevents-reap" (early == Nothing)
        void (tryPutMVar actionRelease ())
        finished <- timeout 500000 (readMVar actionDone)
        check "stopped-entered-action-is-unknown" (case finished of
          Just (Right (Left (OperationOutcomeUnknown SessionClosed))) -> True
          _ -> False)
        parent <- timeout 500000 (readMVar frameReturned)
        check "parent-scope-eventually-returns" (case parent of Just _ -> True; _ -> False)
        result <- timeout 1500000 (readMVar ownerDone)
        raced <- readIORef earlyDrainObserved
        check "drain-hook-does-not-overtake-blocked-action" (not raced)
        check "owned-leader-reaped-after-action" (case result of
          Just (Right (Right ((), LeaderReaped _))) -> True
          _ -> False)
  body `finally` cleanup
