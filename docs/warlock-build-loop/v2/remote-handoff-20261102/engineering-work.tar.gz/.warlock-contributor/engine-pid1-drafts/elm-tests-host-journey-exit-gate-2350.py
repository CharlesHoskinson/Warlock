#!/usr/bin/env python3
"""Root-only unrun source-extracted host final gate controls.

REVIEWED_HOST_DRIVER and REVIEWED_HOST_SHA256 must bind the exact integrated
candidate. Extracts only actual main's final trial/cleanup assignments + return.
Never invokes main, PIL, a subprocess, SSH, VM, GUI, QMP or real cleanup.
These synthetic controls establish only the exit predicate, not orchestration.
"""
import ast
import copy
import hashlib
import os
from pathlib import Path
import unittest

POSTIMAGE = '51b73872536c6369e6587df83556b3a03377f523a3b8344ce52b1c32b74e6960'


def actual_gate():
    path = Path(os.environ['REVIEWED_HOST_DRIVER'])
    raw = path.read_bytes()
    expected = os.environ['REVIEWED_HOST_SHA256']
    if expected != POSTIMAGE or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('exact reviewed host driver required')
    tree = ast.parse(raw, filename=str(path))
    mains = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main']
    if len(mains) != 1:
        raise ValueError('missing unique actual main')
    selected = mains[0].body[-3:]
    if not (len(selected) == 3 and isinstance(selected[0], ast.Assign)
            and isinstance(selected[1], ast.Assign) and isinstance(selected[2], ast.Return)
            and len(selected[0].targets) == len(selected[1].targets) == 1
            and isinstance(selected[0].targets[0], ast.Name) and selected[0].targets[0].id == 'trial'
            and isinstance(selected[1].targets[0], ast.Name) and selected[1].targets[0].id == 'cleanup'):
        raise ValueError('actual final gate layout changed')
    gate = ast.parse('def gate(report):\n return None\n').body[0]
    gate.body = copy.deepcopy(selected)
    module = ast.fix_missing_locations(ast.Module(body=[gate], type_ignores=[]))
    namespace = {}
    exec(compile(module, str(path), 'exec'), namespace)
    return namespace['gate']


def good_report():
    return {'completedPhysicalSequence': True,
            'guestTrialResult': {'exit': 0, 'failure': None, 'forcedAtOriginalDeadlineOrRefusal': False,
              'cleanup': {'launcherReaped': True, 'scopeInventoryConfirmedEmpty': True,
                          'footPreserved': True, 'idleRestore': {'exactEnabledRestored': True},
                          'originalOwnedBirthsRemain': [], 'originalOwnedBirthsUnknown': []}}}


class HostExitGateControls(unittest.TestCase):
    def setUp(self): self.gate = actual_gate()

    def test_actual_clean_zero_exit_positive(self):
        self.assertEqual(self.gate(good_report()), 0)

    def test_guest_nonzero_unreaped_and_malformed_exit_refused(self):
        for value in (1, -9, None, False, '0'):
            row = good_report(); row['guestTrialResult']['exit'] = value
            with self.subTest(exit=value): self.assertEqual(self.gate(row), 1)

    def test_guest_failure_never_succeeds(self):
        row = good_report(); row['guestTrialResult']['failure'] = 'AssertionError: named guard'
        self.assertEqual(self.gate(row), 1)

    def test_forced_or_missing_forced_observation_refused(self):
        for value in (True, None, 0):
            row = good_report(); row['guestTrialResult']['forcedAtOriginalDeadlineOrRefusal'] = value
            with self.subTest(forced=value): self.assertEqual(self.gate(row), 1)
        row = good_report(); del row['guestTrialResult']['forcedAtOriginalDeadlineOrRefusal']
        self.assertEqual(self.gate(row), 1)

    def test_missing_guest_result_refused(self):
        self.assertEqual(self.gate({'completedPhysicalSequence': True}), 1)

    def test_host_failure_or_incomplete_sequence_refused(self):
        row = good_report(); row['failure'] = 'host guard refused'
        self.assertEqual(self.gate(row), 1)
        row = good_report(); row['completedPhysicalSequence'] = False
        self.assertEqual(self.gate(row), 1)

    def test_cleanup_unknown_or_remaining_births_refused(self):
        for key in ('originalOwnedBirthsRemain', 'originalOwnedBirthsUnknown'):
            row = good_report(); row['guestTrialResult']['cleanup'][key] = [{'role': 'engine'}]
            with self.subTest(key=key): self.assertEqual(self.gate(row), 1)
            row = good_report(); del row['guestTrialResult']['cleanup'][key]
            with self.subTest(missing=key): self.assertEqual(self.gate(row), 1)

    def test_every_original_cleanup_guard_retained(self):
        for change in ({'launcherReaped': False}, {'scopeInventoryConfirmedEmpty': False},
                       {'footPreserved': False}, {'idleRestore': {'exactEnabledRestored': False}},
                       {'error': 'PermissionError'}):
            row = good_report(); row['guestTrialResult']['cleanup'].update(change)
            with self.subTest(change=change): self.assertEqual(self.gate(row), 1)


if __name__ == '__main__': unittest.main()
