# Warlock Persistent Runtime `v18` & `Bootstrap`/`Backend` Convergence Guide (`20261102T022627Z`)

- **Owner**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Canonical `HEAD`**: `05dc05572817d9821132ef6e29100efe8046f418` (`19/242` requirements, `42/417` scenarios)
- **Workspace Store `v3` Baseline (Root-owned, preserved untouched)**:
  - `Store.hsc`: `8a46bb60ec5815df1aced28ec8b24c0ebf52de7e8daecc008fb49ef56178a68d`
  - `Catalog.hs`: `023ae55ef72184dcd178542533560f4f56ac31fa1e2e0dd52ee126a005b2c9e0`
  - `PinStore.hs`: `7d2e532a64657b08dfaba0482c268b62fa4295da51f3a19c5cbf6d9e1e5e1de6`
- **Manifest JSON**: `gemini-omarchy-persistent-runtime-v18-manifest-022627Z.json` (`70db97942fbbcd13b718f68aee08f07ea6a49aaa75e82da165e4753b72ba9371`)

## 1. Genuine Source Defects Resolved in `v18`

1. **Cross-Module Post-`StartupRefused` Retirement Deadlock (`Persistent/Internal.hs` + `Bootstrap/Aggregate.hs` + `Backend.hs`)**:
   - In `Bootstrap/Aggregate.hs`, `Left (Persistent.StartupRefused _)` with `processState == PersistentRetired && custody == Available` transitions `Bootstrap` to `State Finished held ticket` (`BootstrapReady`).
   - Both `retirePersistentBootstrap` and `retirePersistentBackend` require `Persistent.tryPersistentStopDeadline core` to return `StopDeadlineLatched deadline`.
   - In `v17` (`f045bc2d`), when `withPersistentOwner` exited with `StartupRefused` *without* a prior explicit `requestSessionStop`:
     - Pre-spawn refusal left `PhaseRetired` with `mStop = Nothing`, and `requestSessionStop` in `PhaseRetired` only called `peekGateAttempted cbGate`, returning `StopNoLiveSession` without minting `StopD` (`claimExplicitStop`) and without setting `attempted = True`.
     - Post-spawn refusal (`retireStartupOrLatchedStop`) called `closeCallbackGate`, which overwrote `mStop = Nothing` with `Just (Left SessionClosed)`, causing `tryPersistentStopDeadline` to return `StopDeadlineFailed SessionClosed` and `retirePersistentBackend` to permanently latch `BackendRetireUnknown`.
   - **Fix in `v18` (`Persistent/Internal.hs` `f44ddd3f5517bb170a7ce669ebf2154c06a3ec5f599e2304f501234b8822be7e`)**:
     - Builds cleanly (`--fuzz=0`) on `terra-security-separate-stop-close-001.patch` (`37e06bf6524a08e9ac0d098c49ca12c6a69ca2251dc242588e215bd48953fb09`) so `closeCallbackGate` and `drainCallbackGate` close callback admission (`closed = True`) without overwriting `mStop = Nothing`.
     - In `requestSessionStop`, `PhaseRetired` invokes `claimExplicitStop cbGate stopReadyVar stopBell reqMicros` (preserving any existing `StopD`, or minting the one-shot `StopD` capped by `mCap` if `mStop == Nothing`, and setting `attempted = True`), returning `StopAlreadyRequested` if `already`, `StopUncertain err` on mint failure, or `StopNoLiveSession` on first post-exit latch. `PhaseQuarantined` invokes `claimStoppingAttemptFlag cbGate` so duplicate post-quarantine stop calls return `StopAlreadyRequested`.

2. **Post-Spawn Cleanup Per-Subaction `StopD` Capping (`Persistent/Internal.hs`)**:
   - Adds `effectiveCleanupDl` and `remainingCleanupMicros`, which sample `cbGate` nonblockingly at each post-spawn cleanup sub-action boundary (`boundedByDl`, `boundedByDlObserved`, `closeOwnedPidfdDl`, `terminateLeaderDl`, `retireStartupOrLatchedStop`, and `finishContainment` final settlement).
   - Admission closure (`closed = True` with `mStop = Nothing`) continues to allow bounded emergency containment under `base`, whereas a concurrent first explicit `StopD` latched during `PhaseStarting` cleanup caps every sub-action to `min(base, stopDl)` (and a contended gate or failed stop mint yields `0` remaining budget, preventing stale signal or close admission after `StopD` expiry).
   - Verified 100% `--fuzz=0` compatible with `terra-security-cleanup-signal-qa-001.patch` (`b852552d2f8e92173fff131567b216a6915227272e330dc0e6ac31755a7072d9` -> postimage `ffd17b450aba427349e7839e5770399bbb6bf1f2b58fd05e42e771aa451d438c`).

3. **Bounded Registration Retirement & Sticky Uncertainty Guards (`Bootstrap/Aggregate.hs`)**:
   - Builds cleanly (`--fuzz=0`) atop `terra-portable-retire-not-ready-010.patch` (`ac72abe519300d89e3bd85eb9072754f5c7e16cf4838c37aa4b7b1a3ae2277f4` -> `09c1aecef47e644707b0c6852c8700d233453a7b64cf0bac08ada706e6dea263`).
   - Replaces blocking `retireRegistration registration` in `cleanupWork` with `tryRetireRegistrationBefore deadline registration` (`Just ScopeRetired`).
   - Sets `atomicWriteIORef uncertain True` if `forkFinally` fails synchronously (`Left err`).
   - Re-checks `readIORef uncertain` and `remainingMicros deadline` before each subsequent close step in `cleanupWork` (`closeCallerTransfer`, `retireSocketOwner`, `retireExecutableLease` / `retireHeld`), and reflects `cleanup` contention/uncertainty in `persistentBootstrapReadiness`.

## 2. Deliverable Digests

| Deliverable | SHA-256 | Bytes |
|---|---|---:|
| `gemini-omarchy-post-separate-stop-close-v18-delta-022627Z.patch` | `2079c9d00c184e42a286fca5fccb91857aa44382786db9349725234cf22262cd` | 9628 |
| `gemini-omarchy-persistent-custody-v17-to-v18-delta-022627Z.patch` | `f5a71ccd33661243a3d693ee1d54bf8707fcfff2e4ca1c40abf4acd88981ce2f` | 24927 |
| `gemini-omarchy-bootstrap-backend-v18-delta-022627Z.patch` | `ac71a5d4dff1d5a72b21eb237dc18af07407252a05378eb285e638a417fb1e93` | 5794 |
| `gemini-omarchy-persistent-custody-prereqs-v18-022627Z.patch` | `055c00c0b7378edab5681541c9a913529114ead36deace26de720dce8edbf67b` | 301899 |
| `gemini-omarchy-full-persistent-runtime-v18-022627Z.patch` | `44bc10a85507649dbf79c5ca64f9b9257feb4aac8c05d3cf312f91f1cad2ef29` | 373509 |
| `GeminiOmarchyStartupRefusedRetireControls022627Z.hs` | `60c6a37107fcc77e7163c519ad70e090db608b58359de316d8fa7c238ae9c232` | 11568 |
| `gemini-omarchy-persistent-runtime-v18-manifest-022627Z.json` | `70db97942fbbcd13b718f68aee08f07ea6a49aaa75e82da165e4753b72ba9371` | 13698 |
