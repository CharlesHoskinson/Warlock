{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Real selected child, actual transfer ticket and
-- preowned owner. Root supplies an independently guarded, known-owned child
-- executable/arguments and keeps Probe, handle and external guardian in the
-- same live host. This does not establish provider or namespace cleanup.
module InputCancelControls (Probe,newProbe,runCancelledClose,runPositiveClose) where

import Control.Concurrent (ThreadId, forkFinally, throwTo)
import Control.Concurrent.MVar
import Control.Exception (AsyncException(ThreadKilled), SomeException, fromException, finally, mask, mask_)
import Control.Monad (unless,void)
import Data.IORef
import System.IO (Handle,hClose)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..),SessionObservation,ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),SessionExit(..),newPersistentOwner,
  persistentStatus,persistentUnderlyingStatus,startBudgetAfter,stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook,persistentTicketFixture,qaPersistentInputReferences)
import Warlock.Capture.Process.Transfer.Internal
 (TransferTicket,TransferDisposition(..),fixtureTicketWithClose,transferDisposition)

type Result = Either SomeException (Either SessionExit ((),SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe Handle)) (IORef (Maybe TransferTicket))
 (IORef (Maybe ThreadId)) (MVar Bool) (MVar ()) (MVar ()) (MVar Result) (IORef Int) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("input cancellation: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure

runCancelledClose,runPositiveClose :: Probe -> FilePath -> [String] -> Handle -> IO ()
runCancelledClose = run True
runPositiveClose = run False

run :: Bool -> Probe -> FilePath -> [String] -> Handle -> IO ()
run cancel (Probe owner handleCell ticketCell worker decision entered release done closes bodyCalls used) exe args input = mask $ \restore -> do
 first <- atomicModifyIORef' used (\v -> (True,not v))
 check "single use" first
 writeIORef handleCell (Just input)
 let closeAction = do
      atomicModifyIORef' closes (\n -> (n+1,()))
      putMVar entered ()
      if cancel then readMVar release else hClose input
     finish = do
      void (tryPutMVar release ())
      mtid <- readIORef worker
      case mtid of Nothing -> pure (); Just _ -> void (tryPutMVar decision False) >> void (timeout 3000000 (readMVar done))
     body = do
      ticket <- fixtureTicketWithClose input closeAction
      writeIORef ticketCell (Just ticket)
      start <- startBudgetAfter 4000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      tid <- mask_ $ do
       child <- forkFinally (do
        allowed <- readMVar decision
        if allowed then restore (withPersistentOwnerHook owner (persistentTicketFixture exe args ticket) 4096 start stop
         (\(_ :: SessionObservation) -> pure (Left SpawnOrIO))
         (\_ -> modifyIORef' bodyCalls (+1)) (const (pure ())))
        else ioError (userError "not admitted")) (putMVar done)
       writeIORef worker (Just child)
       putMVar decision True
       pure child
      within "real selected close entered" (readMVar entered)
      if cancel then within "deliver one cancellation" (throwTo tid ThreadKilled) else pure ()
      outcome <- within "owned startup result" (readMVar done)
      disposition <- transferDisposition ticket
      count <- readIORef closes
      calls <- readIORef bodyCalls
      if cancel then do
       phase <- within "owner phase" (persistentStatus owner)
       raw <- within "raw owner phase" (persistentUnderlyingStatus owner)
       refs <- qaPersistentInputReferences owner
       check "one actual close, typed cancellation, retained unknown" $
        count == 1 && calls == 0 && disposition == TransferUncertain && refs == (0,1,True) &&
        (case outcome of
         Left ex -> case (fromException ex :: Maybe AsyncException) of Just ThreadKilled -> True; _ -> False
         Right _ -> False) &&
        (case phase of PersistentQuarantined _ -> True; _ -> False) &&
        (case raw of Quarantined _ -> True; _ -> False)
      else check "normal close has a confirmed single transfer receipt" $
       count == 1 && calls == 0 && disposition == TransferClosed &&
       (case outcome of Right _ -> True; Left _ -> False)
 restore body `finally` finish
