# Desktop idle versus absolute frame deadline — source-only review

Status: proposal for independent review, not a source change, executed test, VM/native receipt or original-scenario acceptance. Root reported a real owned Elm window and one catalog operation followed by `CredentialTransport TimedOut` before the original 28s D; this worker has not independently examined guest evidence. Preserve the failed result and all 242/417 originals, original D, empty nativeOperations, HOSTSTOP2 and no-replay rules.

## Current contract and observed symptom

`runtime/src/Warlock/Bootstrap/Aggregate.hs:80-92` immediately calls `receiveCredentialIngress` again after every delivered frame. `protocol/src/Warlock/Transport/Channel.hs:122-136` sets `start = CLOCK_MONOTONIC` and `deadline = start + 5s` *before* waiting for the first header byte, wraps the whole `frame deadline` in `timeout 5000000`, and closes/returns `TimedOut` if no result. Thus the current API enforces a five-second **read-call deadline including idle time**, not merely a timer started on receipt of the first byte. It uses the same deadline through the header/body fragments and hands it to gate admission. `Ingress/Internal.hs:291-316` serializes admission, retires the gate on frame failure and dispatches via `dispatchUntil`; the Aggregate treats timeout as refusal and retires the session rather than replaying. This mechanism is consistent with the lead's reported idle timeout, but source alone does not establish that it caused the observed run.

`protocol/TRANSPORT.md:37-41` explicitly documents an absolute five-second read deadline carried into gate admission; `docs/warlock/reference/desktop-application-stream.md:26-30` says existing bootstrap and frame deadlines are preserved. The documents do not explicitly say an otherwise live desktop session must expire after five seconds with no pending data; however, the existing implementation does exactly that. Moving the timer's meaning or exempting idle is a lifecycle behavior change and must be independently reviewed against the original requirement registers, literal oracles and source-bound accepted tuples. Do not claim existing 5s read begins at first byte, alter native profile behavior silently, extend the original D, or infer that a model/component pass accepts native behavior.

## Candidate composition, pending review

After the first authenticated desktop frame has been delivered, have the retained **desktop-only** ingress/channel owner wait for socket readiness (including EOF/error) under the remaining original absolute session D, then initiate the **existing unchanged** credentialed receive call. On readiness, keep the existing five-second absolute receive-call/frame deadline and pass it unchanged into gate admission; the enclosing original D must remain a separate upper bound throughout. Preserve the existing first-frame path and native-profile call behavior unless an independently reviewed requirement expressly changes them. This candidate deliberately changes desktop inter-frame idle behavior; it is not an already-qualified fix.

Implementation constraints:

* Readiness is only a hint, not a frame, peer identity or permission. Do not consume or peek bytes, inject traffic, poll in a spin, synthesize a heartbeat, or restart a frame timer per fragment. A header/body that begins and stalls must still expire/retire under the original 5s read/admission budget, no replay. Existing 4.5s security fixtures and effect deadlines remain unchanged.
* The owner retains the single socket/close right and sole reader. Place readiness and actual receive under a coherent serialized ownership protocol: no second reader can consume the ready byte or reuse a stale numeric fd, no owner-state/credential-scope locks held while waiting, cancellation/retirement must unblock or produce explicit uncertainty. `Ingress` currently has a serial MVar and `Channel` its read gate; a naive outer wait followed by an independently reacquired read gate creates a race. No raw fd or close authority should escape the retained owner.
* Wait is bounded by the same original D, without `deadlineAfter` or `now + remaining` to mint a successor. `withLeaderExit` observes the held selected leader and shuts the retained peer write direction so a read may detect EOF (`Aggregate.hs:114-142`); integrate readiness with that lifecycle. EOF/close/errors and D expiry wake the wait, preserve existing leader/ingress retirement outcomes, and must not be converted into a successful frame or cleanup receipt. No timer renewal or replay.
* After readiness, every recvmsg fragment, UID/GID/peer guard, ancillary data, full framing/decoder, binding, gate and callback must follow existing paths. `MSG_PEEK` is not a safe shortcut for SCM data/rights. Keep no-CORS/native authority and application-only contracts unchanged.

## Root-owned test obligations

1. Actual desktop ingress and its real authenticated peer: deliver a valid frame, stay quiescent >5s but <D, then deliver another valid frame; verify session remains live, both callbacks exactly once, no heartbeat and same immutable D. Include immediate valid multi-frame and coalesced-frame positives.
2. Real partial header then silence, and valid header plus partial body then silence: timeout within original receive/frame bound, no callback, retired/uncertain as applicable, no retries and no changed native/profile behavior. Control 5s as an absolute bound from the unchanged receiver call, not a per-fragment reset.
3. Idle through D, selected child exit while idle, EOF, concurrent retire/close, cancellation and fd-reuse attempts: bounded shutdown under original D, truthful uncertain cleanup, no stale descriptor use, no double-close/reap, no fabricated frame and no second admission. SCM rights/credential changes and unknown/malformed frames remain refusal tests.
4. Run the exact original native/profile and security fixtures unchanged, including 4.5-second cases and literal deadline oracles. Preserve the historical VM timeout; root alone runs protected compiler/model/VM/native tests. Controlled tests and requested readiness schedule cannot prove whole original acceptance.

## Source snapshot SHA-256

```
1cf54460cfd06c162f42b142698f8a7c5229829c62d72d816b7c13172dd91891  implementation/warlock/haskell/protocol/src/Warlock/Transport/Channel.hs
d19e0f063981ab336d80c4eac9fbf4c234e1cc37fcb41aee95c485819f649ac4  implementation/warlock/haskell/protocol/src/Warlock/Protocol/Ingress/Internal.hs
21476f5689a3c822087317aa563f5b7993c857ce8be67105c45f2283a32dafe7  implementation/warlock/haskell/runtime/src/Warlock/Bootstrap/Aggregate.hs
47985c788f31031987aa4c9082829b20426eab83045aa74a0f17ccd989a6f98b  implementation/warlock/haskell/protocol/TRANSPORT.md
5bb4ce917998d9fd9343731541473e4e9b7cf75cc60004b2fd8c9876d05a6f6e  docs/warlock/reference/desktop-application-stream.md
```

## Original-ledger and existing-test check

The original ledger entries cited by `TRANSPORT.md` do not themselves specify a five-second idle-session expiry: `ELM-DEL-021` / `delivery-021` retains the oracle "closure receipts prove order and normal termination" (partial, including the separately recorded original 500ms drain); `ELM-TEA-005` / `tea-narrow-interop` requires the declared contract and exact model/effect fixture agreement (unadjudicated). This limited check does not establish that no other original obligation applies or authorize changing the documented read deadline. `OwnerControls.hs` covers short split/coalesced frames and `GuardControls.hs` credential-refusal cases; the bounded source search found no >5s quiescent-session positive. Preserve their existing tests and accepted source tuples; add independent controlled liveness and partial-frame cases before drawing a broader conclusion.
