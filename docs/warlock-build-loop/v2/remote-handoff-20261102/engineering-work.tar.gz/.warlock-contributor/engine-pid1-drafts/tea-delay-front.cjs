'use strict';

/* Source-derived QA draft; not executed. Insert this factory into the same
 * sandboxed oracle module as tea-contract-cases.cjs. The prelude uses actual
 * incoming policy events; no authority constructor is injected into the worker.
 * Runtime/model timers and native acceptance are outside this fixture. */
function buildLaunchDeadlineCases(c) {
  const { cloneLiteral: copy, literalPatches: patch, initial, topologyChanges,
    oneViewChanges, oneScope, oneScopeJson, binding, bindingJson, host,
    empty, none, zero, NIL } = c;
  if ([copy, patch, initial, topologyChanges, oneViewChanges, oneScope,
    oneScopeJson, binding, bindingJson, host, empty, none, zero, NIL]
    .some(value => value === undefined)) throw new Error('missing independently pinned source literal');
  const counter = value => ({ $: 'Counter', a: String(value) });
  const just = value => ({ $: 'Just', a: value });
  const list = values => values.reduceRight((tail, value) => ({ $: '::', a: value, b: tail }), empty());
  const tuple = (a, b) => ({ $: '#2', a, b });
  const prefix = n => 'applications:' + host + ':' + n + ':';
  const row = (id, domId, label, ariaLabel, detail, enabled) =>
    ({ id, domId, label, ariaLabel, detail, enabled, focusOnly: false });
  const bar = p => [
    row('bar:applications', prefix(p) + 'control:opener', 'Applications', 'Open applications', '', true),
    row('bar:overview', prefix(p) + 'control:overview-opener', 'Task View', 'Open Task View', '', false),
    row('bar:switcher', prefix(p) + 'control:switcher-opener', 'Switch windows', 'Open window switcher', '', false),
    row('bar:notifications', prefix(p) + 'notifications:opener', 'Notifications', 'Open notifications', '', true),
    row('bar:files', prefix(p) + 'files:opener', 'Files', 'Open Files menu', '', true),
    row('bar:system', prefix(p) + 'system:opener', 'System', 'Open system menu', '', true),
    row('bar:settings', prefix(p) + 'settings:opener', 'Settings', 'Open settings', '', true),
  ];
  const popup = (p, state, catalog) => {
    if (state === 'closed') return [];
    const rows = [
      row('control:search', 'launcher-search', '', 'Search applications', '', true),
      row('control:close', prefix(p) + 'control:close', 'Windows', 'Close applications and return to windows', '', true),
      row('control:refresh', prefix(p) + 'control:refresh', 'Refresh', 'Refresh applications', '', true),
    ];
    if (state === 'unknown') rows.push(row('control:acknowledge', prefix(p) + 'control:acknowledge',
      'I checked; allow another launch', 'I checked; allow another launch', '', true));
    if (catalog) rows.push(
      row('jump:open:sample.desktop', prefix(p) + 'jump:open:sample.desktop', 'Actions for Sample', 'Actions for Sample', 'Application actions and recent files', true),
      row('pin:sample.desktop', prefix(p) + 'pin:sample.desktop', 'Pin Sample', 'Pin Sample', 'Add to taskbar', true),
      row('entry:sample.desktop', prefix(p) + 'entry:sample.desktop', 'Open Sample', 'Open Sample', '', state === 'ready'));
    return rows;
  };
  const packet = (pub, lease, p, state, status, catalog, requests, focus) => ({
    viewProtocol: 1, kind: 'view-commit', projection: {
      viewProtocol: 1, kind: 'view-frame', revision: '1', views: [oneScopeJson],
      focusOwner: oneScopeJson, popupOwner: state === 'closed' ? null : oneScopeJson,
      frame: { surfaceProtocol: 2, keyboardParent: true, motion: 'reduced',
        appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
        publication: pub, lease, mode: state === 'closed' ? 'closed' : 'applications', status,
        bar: bar(p), popup: popup(p, state, catalog) },
      announcer: { scope: oneScopeJson, surface: state === 'closed' ? 'bar' : 'popup' }, announcement: null,
    }, requests, focus,
  });
  const request = (kind, id) => ({ protocolVersion: 3, kind, binding: bindingJson, requestId: id });
  const entry = { identity: { $: 'EntryId', a: 'sample.desktop' }, name: 'Sample', iconHint: '',
    wmclass: '', genericName: '', keywords: empty() };
  const dictEmpty = { $: 'RBEmpty_elm_builtin' };
  const dict = { $: 'RBNode_elm_builtin', a: { $: 'Black' }, b: 'sample.desktop', c: entry,
    d: dictEmpty, e: dictEmpty };
  const snapshot = { $: 'Snapshot', a: counter(1), b: counter(1), c: dict };
  const attachRequests = [request('catalog-request', '1'), request('shell-settings-request', '2'),
    request('motion-preferences-request', '3'), request('shortcut-preferences-request', '4'),
    request('projection-request', '1')];
  const attachPacket = packet('4', '0', '3', 'closed', 'Updating window information…', false, attachRequests, []);
  const openRequest = request('catalog-request', '5');
  const openPacket = packet('6', '1', '4', 'open', 'Loading applications…', false, [openRequest], ['launcher-search']);
  const catalogPacket = packet('7', '1', '5', 'ready', 'Type to search applications.', true, [], ['launcher-search']);
  const batch1 = { scope: oneScope, revision: counter(1), publication: counter(4), lease: zero(), binding,
    wire: JSON.stringify(attachPacket), observations: list([tuple('projection-request', counter(1))]),
    operations: empty(), catalogs: list([{ binding, request: counter(1) }]) };
  const batch2 = { scope: oneScope, revision: counter(1), publication: counter(6), lease: counter(1), binding,
    wire: JSON.stringify(openPacket), observations: empty(), operations: empty(),
    catalogs: list([{ binding, request: counter(5) }]) };
  const baseChanges = copy(topologyChanges);
  baseChanges[1].after = counter(3);
  const base = patch(initial, baseChanges.concat(copy(oneViewChanges)));
  const dp = ['controller', 'a', 'controller', 'a', 'desktop'];
  const path = (...tail) => dp.concat(tail);
  const given = patch(base, [
    { path: ['controller','a','controller','a','publication'], before: counter(3), after: counter(7) },
    { path: ['controller','a','controller','a','lease'], before: zero(), after: counter(1) },
    { path: path('presentation'), before: just(counter(2)), after: just(counter(5)) },
    { path: path('request'), before: zero(), after: counter(5) },
    { path: path('settingsExpected'), before: none(), after: just(counter(2)) },
    { path: path('motionExpected'), before: none(), after: just(counter(3)) },
    { path: path('shortcutExpected'), before: none(), after: just(counter(4)) },
    { path: path('open'), before: false, after: true },
    { path: path('workspaceNavigation','binding'), before: none(), after: just(binding) },
    { path: path('pointer','observation'), before: none(), after: just({ binding, serial: counter(1), state: { $: 'Idle' }, owner: none() }) },
    { path: path('applications'), before: none(), after: just(snapshot) },
    { path: path('pins','snapshot'), before: none(), after: just({ revision: counter(1), identities: empty() }) },
    { path: path('launch','a','host'), before: none(), after: just(host) },
    { path: path('launch','a','snapshot'), before: none(), after: just(snapshot) },
    { path: path('launch','a','revision'), before: counter(2), after: counter(6) },
    { path: path('windows','shell','binding'), before: none(), after: just(binding) },
    { path: path('windows','shell','phase'), before: { $: 'Detached' }, after: { $: 'Reconciling' } },
    { path: path('windows','shell','reconnecting'), before: true, after: false },
    { path: path('windows','shell','notice'), before: 'Connecting…', after: 'Updating window information…' },
    { path: path('windows','shell','request'), before: zero(), after: counter(1) },
    { path: path('windows','shell','expected'), before: none(), after: just(counter(1)) },
    { path: ['controller','a','batches'], before: empty(), after: list([batch2,batch1]) },
  ]);
  const gateway = (kind, payload) => ({ bridgeProtocol: 1, kind, payload });
  const native = (kind, fields) => gateway('native-event', { protocolVersion: 3, kind, ...fields });
  const action = (surface, publication, lease, id) => gateway('view-action', {
    viewProtocol: 1, kind: 'view-action', scope: oneScopeJson,
    action: { surfaceProtocol: 2, kind: 'surface-action', surface, publication, lease, id, trigger: 'keyboard' },
  });
  const values = [
    gateway('view-topology', { viewProtocol: 1, kind: 'view-topology', revision: '1', views: [oneScopeJson] }),
    native('attached', { binding: bindingJson }),
    native('pointer-ownership', { ownershipProtocol: 1, binding: bindingJson, requestId: '1', serial: '1', state: 'idle', owner: null }),
    action('bar', '5', '0', 'bar:applications'),
    native('application-catalog', { binding: bindingJson, requestId: '5',
      snapshot: { catalogProtocol: 1, lifetime: '1', generation: '1', entries: [
        { id: 'sample.desktop', name: 'Sample', iconHint: '', wmclass: '' } ] },
      preferences: { revision: '1', identities: [] } }),
  ];
  const publish = value => ({ $: 'Publish', a: { $: 0, a: value } });
  const intent = { request: counter(1), lifetime: counter(1), generation: counter(1), entry: 'sample.desktop' };
  const wireIntent = { request: '1', lifetime: '1', generation: '1', entry: 'sample.desktop' };
  const launchRequest = { protocolVersion: 3, kind: 'application-launch', binding: bindingJson, intent: wireIntent };
  const pendingPacket = packet('8', '1', '5', 'pending', 'Opening application…', true, [launchRequest], []);
  const batch3 = { scope: oneScope, revision: counter(1), publication: counter(8), lease: counter(1), binding,
    wire: JSON.stringify(pendingPacket), observations: empty(), operations: empty(), catalogs: empty() };
  const pending = patch(given, [
    { path: ['controller','a','controller','a','publication'], before: counter(7), after: counter(8) },
    { path: path('launchFromApplications'), before: false, after: true },
    { path: path('launch','a','request'), before: zero(), after: counter(1) },
    { path: path('launch','a','revision'), before: counter(6), after: counter(7) },
    { path: path('launch','a','phase'), before: { $: 'Idle' }, after: { $: 'Pending', a: host, b: intent } },
    { path: ['controller','a','batches'], before: list([batch2,batch1]), after: list([batch3,batch2,batch1]) },
  ]);
  const token = { $: 'PendingToken', a: host, b: intent };
  const pendingEffects = list([publish(pendingPacket), { $: 'Delay', a: 10000, b: { $: 'Deadline', a: token } }]);
  const unknown = patch(pending, [
    { path: ['controller','a','controller','a','publication'], before: counter(8), after: counter(9) },
    { path: path('launch','a','revision'), before: counter(7), after: counter(8) },
    { path: path('launch','a','phase'), before: { $: 'Pending', a: host, b: intent },
      after: { $: 'Settled', a: intent, b: { $: 'Unknown' } } },
  ]);
  const unknownPacket = packet('9', '1', '5', 'unknown',
    'The launch could not be confirmed. Check your windows before opening it again.', true, [], []);
  const reset = { input: { kind: 'reset' }, expected: { state: copy(initial), effects: copy(NIL) } };
  const givenStep = { input: { kind: 'prelude', values }, setupTimers: 0,
    expected: { state: copy(given), effects: list([publish(catalogPacket)]) } };
  const start = { input: { kind: 'incoming', value: action('popup', '7', '1', 'entry:sample.desktop') },
    expected: { state: copy(pending), effects: pendingEffects } };
  const submitted = patch(pending, [
    { path: ['controller','a','controller','a','publication'], before: counter(8), after: counter(9) },
    { path: path('open'), before: true, after: false },
    { path: path('launch','a','revision'), before: counter(7), after: counter(8) },
    { path: path('launch','a','phase'), before: { $: 'Pending', a: host, b: intent },
      after: { $: 'Settled', a: intent, b: { $: 'Submitted' } } },
  ]);
  const submittedPacket = packet('9', '1', '5', 'closed', 'Launch submitted.', true, [], []);
  const submittedReceipt = native('application-launch-outcome', { binding: bindingJson,
    outcome: { catalogProtocol: 1, kind: 'launch-outcome', intent: wireIntent,
      status: 'Submitted', reason: 'native-submission-accepted' } });
  return [
    { name: 'launch-delay-exact-timeout-and-stale-token', steps: [copy(reset), copy(givenStep), copy(start),
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(unknown), effects: list([publish(unknownPacket)]) } },
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(unknown), effects: copy(NIL) } },
    ] },
    { name: 'launch-delay-stale-after-matching-submitted', steps: [copy(reset), copy(givenStep), copy(start),
      { input: { kind: 'incoming', value: submittedReceipt }, expected: { state: copy(submitted), effects: list([publish(submittedPacket)]) } },
      { input: { kind: 'deadline', index: 0 }, expected: { state: copy(submitted), effects: copy(NIL) } },
    ] },
  ];
}
