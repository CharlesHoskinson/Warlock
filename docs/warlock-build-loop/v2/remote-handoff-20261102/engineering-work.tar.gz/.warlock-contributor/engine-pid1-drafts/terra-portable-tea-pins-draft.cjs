'use strict';
// Source-derived QA draft, NOT RUN. Integrator supplies the independent
// source-transcribed canonical initial/topology/attachment literals and the
// strict cloneLiteral/literalPatches helpers from tea-contract-cases.cjs.
// No test expectation may come from the replay worker's captured values.
// The hidden sanitized prelude must be run from Policy.initial by the worker;
// its full final GIVEN + last full effect are compared, but its intermediate
// steps are setup rather than tested transitions. Full debug encoding and
// source/artifact hashes require Root qualification.
module.exports = function buildPinCases(c) {
  const { cloneLiteral: copy, literalPatches: patch, initial, topologyChanges,
    oneViewChanges, attachedChanges, oneScope, oneScopeJson, binding, bindingJson,
    attachedBatch, host, empty, none, zero, NIL } = c;
  if ([copy, patch, initial, topologyChanges, oneViewChanges, attachedChanges,
       oneScope, oneScopeJson, binding, bindingJson, attachedBatch, host, empty,
       none, zero, NIL].some(value => value === undefined)) {
    throw new Error('independent full GIVEN dependencies required');
  }
  const counter = text => ({ $: 'Counter', a: text });
  const just = value => ({ $: 'Just', a: value });
  const list = values => values.reduceRight((tail, value) => ({ $: '::', a: value, b: tail }), empty());
  const scopeJson = { id: '1', generation: '1' };
  const givenIdentities = ['alpha', 'beta'];
  const desiredIdentities = ['beta', 'alpha'];
  const row = (id, domId, label, ariaLabel, detail, enabled) =>
    ({ id, domId, label, ariaLabel, detail, enabled, focusOnly: false });
  const prefix = n => 'applications:' + host + ':' + n + ':';
  const barRows = (presentation, order) => {
    const p = prefix(presentation);
    return order.map(id => row('bar:pin:' + id, p + 'pin:' + id, id,
      'Unavailable application: ' + id, 'Unavailable application: ', false)).concat([
      row('bar:applications', p + 'control:opener', 'Applications', 'Open applications', '', true),
      row('bar:overview', p + 'control:overview-opener', 'Task View', 'Open Task View', '', false),
      row('bar:switcher', p + 'control:switcher-opener', 'Switch windows', 'Open window switcher', '', false),
      row('bar:notifications', p + 'notifications:opener', 'Notifications', 'Open notifications', '', false),
      row('bar:files', p + 'files:opener', 'Files', 'Open Files menu', '', false),
      row('bar:system', p + 'system:opener', 'System', 'Open system menu', '', false),
      row('bar:settings', p + 'settings:opener', 'Settings', 'Open settings', '', false),
    ]);
  };
  const popupRows = (presentation, order, writable) => {
    const p = prefix(presentation);
    const controls = [
      row('control:search', 'launcher-search', '', 'Search applications', '', true),
      row('control:close', p + 'control:close', 'Windows', 'Close applications and return to windows', '', true),
      row('control:refresh', p + 'control:refresh', 'Refresh', 'Refresh applications', '', true),
    ];
    for (let i = 0; i < order.length; i++) {
      const id = order[i];
      for (const [suffix, label, detail, allowed] of [
        ['unpin:', 'Unpin ' + id, 'Pinned application', true],
        ['pin-left:', 'Move ' + id + ' left', 'Pin order', i > 0],
        ['pin-right:', 'Move ' + id + ' right', 'Pin order', i + 1 < order.length],
      ]) controls.push(row(suffix + id, p + suffix + id, label, label, detail, writable && allowed));
    }
    return controls;
  };
  const commit = ({ publication, presentation, status, order, writable, requests, focus }) => ({
    viewProtocol: 1, kind: 'view-commit', projection: {
      viewProtocol: 1, kind: 'view-frame', revision: '1', views: [scopeJson],
      focusOwner: scopeJson, popupOwner: scopeJson,
      frame: { surfaceProtocol: 2, keyboardParent: true, motion: 'reduced',
        appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
        publication, lease: '1', mode: 'applications', status,
        bar: barRows(presentation, order), popup: popupRows(presentation, order, writable) },
      announcer: { scope: scopeJson, surface: 'popup' }, announcement: null,
    }, requests, focus,
  });
  const publish = packet => ({ $: '::', a: { $: 'Publish', a: { $: 0, a: packet } }, b: empty() });
  const openRequest = { protocolVersion: 3, kind: 'catalog-request', binding: bindingJson, requestId: '2' };
  const writeRequest = { protocolVersion: 3, kind: 'taskbar-pins-write', binding: bindingJson,
    requestId: '3', proposal: { revision: '1', identities: desiredIdentities } };
  const openCommit = commit({ publication: '6', presentation: '5', status: 'Loading applications…',
    order: givenIdentities, writable: true, requests: [openRequest], focus: ['launcher-search'] });
  const pendingCommit = commit({ publication: '7', presentation: '6', status: 'Saving pin order…',
    order: givenIdentities, writable: false, requests: [writeRequest], focus: [] });
  const batch2 = { scope: oneScope, revision: counter('1'), publication: counter('6'), lease: counter('1'),
    binding, wire: JSON.stringify(openCommit), observations: empty(), operations: empty(),
    catalogs: list([{ binding, request: counter('2') }]) };
  const batch3 = { scope: oneScope, revision: counter('1'), publication: counter('7'), lease: counter('1'),
    binding, wire: JSON.stringify(pendingCommit), observations: empty(), operations: empty(), catalogs: empty() };
  const oneViewBaseChanges = copy(topologyChanges);
  oneViewBaseChanges[1].after = counter('3');
  const oneView = patch(initial, oneViewBaseChanges.concat(copy(oneViewChanges)));
  const attached = patch(oneView, attachedChanges);
  const modelPath = ['controller', 'a', 'controller', 'a', 'desktop'];
  const path = (...tail) => modelPath.concat(tail);
  const pendingChanges = [
    { path: ['controller','a','controller','a','publication'], before: counter('4'), after: counter('7') },
    { path: ['controller','a','controller','a','lease'], before: zero(), after: counter('1') },
    { path: path('presentation'), before: just(counter('3')), after: just(counter('6')) },
    { path: path('request'), before: counter('1'), after: counter('3') },
    { path: path('expected'), before: just(counter('1')), after: just(counter('2')) },
    { path: path('open'), before: false, after: true },
    { path: path('catalogOpening'), before: false, after: true },
    { path: path('pins','snapshot'), before: none(), after: just({ revision: counter('1'), identities: list(givenIdentities) }) },
    { path: path('pins','pending'), before: none(), after: just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Saving' } }) },
    { path: path('pins','notice'), before: '', after: 'Saving pin order…' },
    { path: path('launch','a','revision'), before: counter('4'), after: counter('6') },
    { path: ['controller','a','batches'], before: list([attachedBatch]), after: list([batch3, batch2, attachedBatch]) },
  ];
  const pending = patch(attached, pendingChanges);
  const topology = { bridgeProtocol: 1, kind: 'view-topology', payload: {
    viewProtocol: 1, kind: 'view-topology', revision: '1', views: [scopeJson] } };
  const attach = { bridgeProtocol: 1, kind: 'native-event', payload: {
    protocolVersion: 3, kind: 'application-attached', binding: bindingJson, nativeOperations: [] } };
  const catalog = { bridgeProtocol: 1, kind: 'native-event', payload: {
    protocolVersion: 3, kind: 'application-catalog', binding: bindingJson, requestId: '1',
    snapshot: { catalogProtocol: 1, lifetime: '1', generation: '1', entries: [] },
    preferences: { revision: '1', identities: givenIdentities } } };
  const action = (surface, publication, lease, id) => ({ bridgeProtocol: 1, kind: 'view-action', payload: {
    viewProtocol: 1, kind: 'view-action', scope: scopeJson, action: {
      surfaceProtocol: 2, kind: 'surface-action', surface, publication, lease, id, trigger: 'keyboard' } } });
  const values = [topology, attach, catalog, action('bar', '5', '0', 'bar:applications'),
    action('popup', '6', '1', 'pin-left:beta')];
  const receipt = (requestId, status, preferences) => ({ kind: 'incoming', value: {
    bridgeProtocol: 1, kind: 'native-event', payload: { protocolVersion: 3, kind: 'taskbar-pins-outcome',
      binding: bindingJson, requestId, status, preferences } } });
  const givenStep = { input: { kind: 'prelude', values }, setupTimers: 0,
    expected: { state: copy(pending), effects: publish(pendingCommit) } };
  const reset = { input: { kind: 'reset' }, expected: { state: copy(initial), effects: copy(NIL) } };
  const variants = [
    { name: 'pin-wrong-request-retains-pending', input: receipt('4', 'Refused', null),
      changes: [], effects: copy(NIL) },
    { name: 'pin-refused-retains-observed-order', input: receipt('3', 'Refused', null),
      changes: [
        { path: path('pins','pending'), before: just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Saving' } }), after: none() },
        { path: path('pins','notice'), before: 'Saving pin order…', after: 'Pin change refused. Refresh applications and choose again.' },
      ], status: 'Pin change refused. Refresh applications and choose again.', order: givenIdentities, writable: true },
    { name: 'pin-unknown-retains-reservation-no-replay', input: receipt('3', 'Unknown', null),
      changes: [
        { path: path('pins','pending','a','confirmation'), before: { $: 'Saving' }, after: { $: 'Unconfirmed', a: none() } },
        { path: path('pins','notice'), before: 'Saving pin order…', after: 'Pin save not confirmed. Refresh applications to read the order; the change will not be repeated.' },
      ], status: 'Pin save not confirmed. Refresh applications to read the order; the change will not be repeated.', order: givenIdentities, writable: false },
    { name: 'pin-saved-receipt-confirms-exact-new-order', input: receipt('3', 'Saved', { revision: '2', identities: desiredIdentities }),
      changes: [
        { path: path('pins','pending'), before: just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Saving' } }), after: none() },
        { path: path('pins','snapshot'), before: just({ revision: counter('1'), identities: list(givenIdentities) }), after: just({ revision: counter('2'), identities: list(desiredIdentities) }) },
        { path: path('pins','notice'), before: 'Saving pin order…', after: 'Pin order saved.' },
      ], status: 'Loading applications…', order: desiredIdentities, writable: true },
  ];
  const simpleCases = variants.map(v => {
    if (v.changes.length === 0) return { name: v.name, steps: [copy(reset), copy(givenStep),
      { input: copy(v.input), expected: { state: copy(pending), effects: copy(v.effects) } }] };
    const after = patch(pending, v.changes.concat([{ path: ['controller','a','controller','a','publication'],
      before: counter('7'), after: counter('8') }]));
    const expectedCommit = commit({ publication: '8', presentation: '6', status: v.status,
      order: v.order, writable: v.writable, requests: [], focus: ['launcher-search'] });
    const steps = [copy(reset), copy(givenStep), { input: copy(v.input), expected: { state: after, effects: publish(expectedCommit) } }];
    if (v.name === 'pin-unknown-retains-reservation-no-replay') {
      steps.push({ input: copy(v.input), expected: { state: copy(after), effects: copy(NIL) } });
      const recoveryRequest = { protocolVersion: 3, kind: 'catalog-request', binding: bindingJson, requestId: '4' };
      const recoveryCommit = commit({ publication: '9', presentation: '7', status: v.status,
        order: givenIdentities, writable: false, requests: [recoveryRequest], focus: [] });
      const batch4 = { scope: oneScope, revision: counter('1'), publication: counter('9'), lease: counter('1'),
        binding, wire: JSON.stringify(recoveryCommit), observations: empty(), operations: empty(),
        catalogs: list([{ binding, request: counter('4') }]) };
      const oldBatches = list([batch3, batch2, attachedBatch]);
      const recovery = patch(after, [
        { path: ['controller','a','controller','a','publication'], before: counter('8'), after: counter('9') },
        { path: path('presentation'), before: just(counter('6')), after: just(counter('7')) },
        { path: path('request'), before: counter('3'), after: counter('4') },
        { path: path('expected'), before: just(counter('2')), after: just(counter('4')) },
        { path: path('catalogOpening'), before: true, after: false },
        { path: path('launch','a','revision'), before: counter('6'), after: counter('7') },
        { path: path('pins','pending','a','confirmation'), before: { $: 'Unconfirmed', a: none() }, after: { $: 'Unconfirmed', a: just(counter('4')) } },
        { path: ['controller','a','batches'], before: oldBatches, after: list([batch4, batch3, batch2, attachedBatch]) },
      ]);
      steps.push({ input: { kind: 'incoming', value: action('popup', '8', '1', 'control:refresh') },
        expected: { state: copy(recovery), effects: publish(recoveryCommit) } });
      const catalogReply = (id, preferences) => ({ kind: 'incoming', value: {
        bridgeProtocol: 1, kind: 'native-event', payload: { protocolVersion: 3, kind: 'application-catalog',
          binding: bindingJson, requestId: id, snapshot: { catalogProtocol: 1, lifetime: '1', generation: '1', entries: [] }, preferences } } });
      steps.push({ input: catalogReply('2', null), expected: { state: copy(recovery), effects: copy(NIL) } });
      const observedSnapshot = { $: 'Snapshot', a: counter('1'), b: counter('1'), c: { $: 'RBEmpty_elm_builtin' } };
      const recovered = patch(recovery, [
        { path: ['controller','a','controller','a','publication'], before: counter('9'), after: counter('10') },
        { path: path('presentation'), before: just(counter('7')), after: just(counter('8')) },
        { path: path('expected'), before: just(counter('4')), after: none() },
        { path: path('applications'), before: none(), after: just(observedSnapshot) },
        { path: path('launch','a','revision'), before: counter('7'), after: counter('8') },
        { path: path('launch','a','snapshot'), before: none(), after: just(observedSnapshot) },
        { path: path('pins','snapshot'), before: just({ revision: counter('1'), identities: list(givenIdentities) }),
          after: just({ revision: counter('2'), identities: list(desiredIdentities) }) },
        { path: path('pins','pending'), before: just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Unconfirmed', a: just(counter('4')) } }), after: none() },
        { path: path('pins','notice'), before: v.status, after: '' },
      ]);
      const observedCommit = commit({ publication: '10', presentation: '8', status: 'No matching applications. Change your search or Refresh.',
        order: desiredIdentities, writable: true, requests: [], focus: [] });
      steps.push({ input: catalogReply('4', { revision: '2', identities: desiredIdentities }),
        expected: { state: recovered, effects: publish(observedCommit) } });
    }
    return { name: v.name, steps };
  });
  const unknownNotice = 'Pin save not confirmed. Refresh applications to read the order; the change will not be repeated.';
  const pendingSaving = just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Saving' } });
  const pendingUnknown = just({ request: counter('3'), identities: list(desiredIdentities), confirmation: { $: 'Unconfirmed', a: none() } });
  const unknownState = patch(pending, [
    { path: ['controller','a','controller','a','publication'], before: counter('7'), after: counter('8') },
    { path: path('pins','pending'), before: pendingSaving, after: pendingUnknown },
    { path: path('pins','notice'), before: 'Saving pin order…', after: unknownNotice },
  ]);
  const unknownCommit = commit({ publication: '8', presentation: '6', status: unknownNotice,
    order: givenIdentities, writable: false, requests: [], focus: ['launcher-search'] });
  const afterUnknown = [
    { name: 'pin-unknown-then-correlated-refused', status: 'Refused', preferences: null,
      notice: 'Pin change refused. Refresh applications and choose again.', order: givenIdentities },
    { name: 'pin-unknown-then-correlated-saved', status: 'Saved',
      preferences: { revision: '2', identities: desiredIdentities }, notice: 'Pin order saved.', order: desiredIdentities },
  ].map(v => {
    const changes = [
      { path: ['controller','a','controller','a','publication'], before: counter('8'), after: counter('9') },
      { path: path('pins','pending'), before: pendingUnknown, after: none() },
      { path: path('pins','notice'), before: unknownNotice, after: v.notice },
    ];
    if (v.status === 'Saved') changes.push({ path: path('pins','snapshot'),
      before: just({ revision: counter('1'), identities: list(givenIdentities) }),
      after: just({ revision: counter('2'), identities: list(desiredIdentities) }) });
    const settled = patch(unknownState, changes);
    const settledCommit = commit({ publication: '9', presentation: '6',
      status: v.status === 'Saved' ? 'Loading applications…' : v.notice,
      order: v.order, writable: true, requests: [], focus: ['launcher-search'] });
    return { name: v.name, steps: [copy(reset), copy(givenStep),
      { input: receipt('3', 'Unknown', null), expected: { state: copy(unknownState), effects: publish(unknownCommit) } },
      { input: receipt('3', v.status, v.preferences), expected: { state: settled, effects: publish(settledCommit) } },
    ] };
  });
  return simpleCases.concat(afterUnknown);
};
