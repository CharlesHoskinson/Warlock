{-# LANGUAGE OverloadedStrings #-}
-- Unexecuted source fixture for proposed v15 owned-frame request batch.
-- The child executable is built from TerraOwnedBatchStopPeer.hs. Root supplies
-- a pre-registered owned marker, source/binary pins and an external guardian.
-- The local counter actions are not Backend, native operations or ACKs.
module Main (main) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar (newEmptyMVar, putMVar, readMVar, tryPutMVar)
import Control.Exception (SomeException, finally, mask)
import Control.Monad (unless, void)
import Data.IORef
import Foreign.StablePtr (newStablePtr)
import GHC.Clock (getMonotonicTimeNSec)
import System.Directory (doesFileExist, removeFile)
import System.Environment (getArgs)
import System.IO (Handle, IOMode(ReadWriteMode), hIsClosed)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import qualified Network.Socket as S
import Warlock.Capture.Process (SessionObservation(..), ToolError(..))
import Warlock.Capture.Process.Bootstrap (deadlineFromAbsoluteNs, deadlineAbsoluteNs)
import Warlock.Capture.Process.Persistent
  ( LiveFrameAdmission, LiveOperationFailure(..), LiveWakeReason(..), PersistentOwner
  , SessionExit(..), StopReceipt(..), beginLiveFrameRequestBatch, defaultPersistentActionBudget
  , enterLiveBatchRequest, newPersistentOwner, requestSessionStop, startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)
import Warlock.Protocol.Codec (checkedDesktopCommit)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import qualified Warlock.Protocol.CredentialIngress as P
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (renderCounter)
import Warlock.Protocol.Ingress (Direction(..), OfferResult(..), ActivationResult(..), EndpointState(..), OwnerStatus(..), ingressBinding)
import qualified Warlock.Protocol.PeerCredential as Peer

data Refusal = MissingOwner | ForeignPeer deriving (Eq, Show)
type Context = (LiveFrameAdmission, P.FrameDeadline)
-- Every cell is published before acquiring a socket or launching the stopper.
-- Root retains the entire fixture process/guardian separately; a StablePtr is
-- not evidence of reap, thread join, descriptor closure or namespace cleanup.
data Owned = Owned PersistentOwner (IORef (Maybe (P.CredentialIngressT Context)))
  (IORef (Maybe (S.Socket,S.Socket))) (IORef (Maybe Handle))
  (IORef (Maybe ThreadId)) FilePath

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label op = timeout 2500000 op >>= maybe (ioError (userError label)) pure

main :: IO ()
main = do
 args <- getArgs
 (child,marker) <- case args of
  [exe,path] | all (\p -> not (null p) && head p == '/') [exe,path] -> pure (exe,path)
  _ -> ioError (userError "expected absolute pinned child and caller-owned marker")
 run child marker

run :: FilePath -> FilePath -> IO ()
run child marker = mask $ \restore -> do
 owner <- newPersistentOwner
 ingressCell <- newIORef Nothing
 socketsCell <- newIORef Nothing
 handleCell <- newIORef Nothing
 stopperCell <- newIORef Nothing
 signal <- newEmptyMVar
 release <- newEmptyMVar
 stopped <- newEmptyMVar
 firstCount <- newIORef (0 :: Int)
 secondCount <- newIORef (0 :: Int)
 outcomes <- newIORef Nothing
 observed <- newIORef Nothing
 frameDs <- newIORef ([] :: [Integer])
 _ <- newStablePtr (Owned owner ingressCell socketsCell handleCell stopperCell marker,
                    signal,release,stopped,firstCount,secondCount,outcomes,observed,frameDs)
 exists <- doesFileExist marker
 check "caller-owned marker exists" exists
 bound <- must (ingressBinding "1" "2" "3")
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 stopBudget <- must (stopBudgetMicros 2000000)
 let verifyCredential credential = do
      current <- readIORef observed
      pure $ case current of
       Nothing -> Left MissingOwner
       Just obs | Peer.credentialPid credential == toInteger (observedPid obs)
               && Peer.credentialUid credential == uid && Peer.credentialGid credential == gid -> Right ()
       _ -> Left ForeignPeer
     guardFor _ frame = CredentialGuard
      (\credential -> modifyIORef' frameDs (P.frameDeadlineNs frame :) >> verifyCredential credential)
      (\credential action -> do
       modifyIORef' frameDs (P.frameDeadlineNs frame :)
       allowed <- verifyCredential credential
       case allowed of Left refusal -> pure (Left refusal); Right () -> Right <$> action)
     callback (admission,frame) checked = do
      modifyIORef' frameDs (P.frameDeadlineNs frame :)
      commit <- maybe (ioError (userError "checked desktop commit missing")) pure (checkedDesktopCommit checked)
      let requests = D.commitRequests commit
      check "exact two authenticated ordered request identities" (map (renderCounter . D.requestId) requests == ["7","8"] && all ((== D.CatalogRead) . D.requestKind) requests)
      frameDl <- deadlineFromAbsoluteNs (show (P.frameDeadlineNs frame)) >>= must
      batch <- beginLiveFrameRequestBatch admission frameDl False (length requests) >>= must
      before <- toInteger <$> getMonotonicTimeNSec
      first <- enterLiveBatchRequest batch defaultPersistentActionBudget Nothing $ \actionDl -> do
       now <- toInteger <$> getMonotonicTimeNSec
       let parsed = readMaybe (deadlineAbsoluteNs actionDl) :: Maybe Integer
       modifyIORef' firstCount (+1)
       putMVar signal True
       readMVar release
       pure $ case parsed of
        Just end | end > now && end <= now + 5000000000 && end > before -> Right ()
        _ -> Left BadArguments
      second <- enterLiveBatchRequest batch defaultPersistentActionBudget Nothing $ \_ -> do
       modifyIORef' secondCount (+1)
       pure (Right ())
      stopOutcome <- within "stopper outcome" (readMVar stopped)
      one <- readIORef firstCount
      two <- readIORef secondCount
      let ok = first == Left (OperationOutcomeUnknown SessionClosed)
            && second == Left (OperationRefusedPreDispatch SessionClosed)
            && (case stopOutcome of Right (Just StopSignalSent) -> True; _ -> False) && one == 1 && two == 0
      writeIORef outcomes (Just ok)
 ingress <- P.newDesktopCredentialIngressWithContext bound FromElm callback (\_ _ -> ioError (userError "unexpected server callback"))
 writeIORef ingressCell (Just ingress)
 (host,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 writeIORef socketsCell (Just (host,peer))
 offered <- P.transferCredentialSocket ingress host
 check "host accepted" (offered == OfferAccepted)
 activated <- P.activateCredentialIngress ingress
 check "host activated" (activated == ActivationLive)
 peerHandle <- S.socketToHandle peer ReadWriteMode
 writeIORef handleCell (Just peerHandle)
 start <- startBudgetAfter 2000000 >>= must
 let verify obs = writeIORef observed (Just obs) >> pure (Right ())
     body session = do
      received <- P.receivePersistentCredentialIngressOwned False session ingress guardFor
      -- CredentialDelivered is only local checked frame callback completion;
      -- the request itself is explicitly Unknown, not a native receipt.
      check "frame callback completed" (received == Right (P.PersistentOutcome P.CredentialDelivered))
      checked <- readIORef outcomes
      check "one in-flight unknown; later request refused" (checked == Just True)
      ds <- readIORef frameDs
      check "same original frame D throughout" (length ds >= 4 && all (== head ds) ds && head ds > 0)
      terminal <- P.receivePersistentCredentialIngressOwned True session ingress guardFor
      check "latched stop wake" (terminal == Right (P.PersistentOwnerWake LiveWakeStopRequested))
      removeFile marker
     stopWorker = do
      go <- readMVar signal
      if go then Just <$> requestSessionStop owner stopBudget else pure Nothing
     cleanupWorker = do
      void (tryPutMVar signal False)
      void (tryPutMVar release ())
      thread <- readIORef stopperCell
      case thread of
       Nothing -> pure ()
       Just _ -> do
        ended <- timeout 2500000 (readMVar stopped)
        check "stop worker disposition observed" (case ended of Just _ -> True; Nothing -> False)
 -- forkFinally registers disposition even on exception; action release is
 -- guaranteed before any bounded wait in the enclosing finalizer.
 (do
   tid <- forkFinally (restore stopWorker `finally` void (tryPutMVar release ())) (putMVar stopped)
   writeIORef stopperCell (Just tid)
   result <- restore (withPersistentOwnerHook owner (persistentFixture child [marker] peerHandle)
     4096 start stopBudget verify body (\_ -> pure ()))
   case result of
    Right ((), LeaderReaped _) -> do
     closed <- hIsClosed peerHandle
     check "transferred handle closed" closed
     status <- P.retireCredentialIngress ingress
     check "host endpoint close confirmed" (endpoint status == Just EndpointConfirmed)
    other -> ioError (userError ("owner retained unconfirmed: " ++ show other)))
  `finally` cleanupWorker
