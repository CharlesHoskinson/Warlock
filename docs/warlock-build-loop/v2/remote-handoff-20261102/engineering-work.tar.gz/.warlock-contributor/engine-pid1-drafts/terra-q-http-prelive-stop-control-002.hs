{-# LANGUAGE OverloadedStrings #-}
-- QA ONLY. Isolated actor016/Engine lexical013 plus QA probe002; Root owns
-- original external guardian/deadline. Each mode gets its own SAME-process
-- strongly rooted Case; retain it on every failure/timeout. No worker kill,
-- fake metadata result, new product deadline or cleanup/native claim.
module QHttpPreliveStopControl (Mode(..),Case,newCase,runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try,throwIO)
import Control.Monad (unless)
import Data.IORef (IORef,newIORef,writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
  persistentBackendCounts,persistentBackendStartupRefusal,qaPreparationCount,qaSetPreparationHook)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(SessionClosed))
import qualified Warlock.Capture.Process.Persistent as P

data Mode = LiveEntryControl | StopBeforePreparation | StopDuringPreparation deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
  (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId))
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current budget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing

-- Root retains this Case before run and keeps the external original D; no
-- internal timeout supplies an acceptance threshold or cancels work.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase (Case owner start entered release completed workerSlot) mode path = mask $ \restore -> do
  exists <- doesPathExist path
  check "actual owned config exists" (isAbsolute path && exists)
  before <- qaPreparationCount
  check "isolated one-shot probe starts unused" (before==0)
  configured <- restore (loadPersistentBackendConfig owner path)
  check "actual same-owner config succeeded before schedule" (configured==Right ())
  case mode of
    StopBeforePreparation -> restore $ do
      stop <- requestPersistentBackendStop owner
      check "actual prelive stop latched" (stop==P.StopLatchedBeforeLive)
      result <- runPersistentBackend owner
      count <- qaPreparationCount
      check "stop-before-entry refuses with no display preparation"
        (count==0 && persistentBackendCounts result==(0,0)
          && persistentBackendStartupRefusal result==Just (P.StartupAdmissionRefused SessionClosed))
    _ -> do
      -- Mode StopDuringPreparation blocks AFTER the lexical owner admitted the
      -- real callback and immediately BEFORE display IO; no metadata faked.
      case mode of
        StopDuringPreparation -> qaSetPreparationHook (putMVar entered () >> takeMVar release)
        _ -> pure ()
      thread <- forkIOWithUnmask $ \unmask -> do
        result <- try (unmask (takeMVar start >> runPersistentBackend owner))
        putMVar completed result
      writeIORef workerSlot (Just thread)
      putMVar start ()
      restore $ do
        case mode of
          StopDuringPreparation -> readMVar entered
          _ -> let waitForProbe = do
                     count <- qaPreparationCount
                     if count>0 then pure () else do
                       result <- tryReadMVar completed
                       case result of
                         Just _ -> ioError (userError "live run ended before preparation probe")
                         Nothing -> threadDelay 1000 >> waitForProbe
               in waitForProbe
        count <- qaPreparationCount
        check "real admitted preparation reached probe once" (count==1)
        stop <- requestPersistentBackendStop owner
        case mode of
          StopDuringPreparation -> check "same owner latched during held prep" (stop==P.StopLatchedBeforeLive)
          _ -> check "same owner accepted stop before or after live" (stop==P.StopLatchedBeforeLive || stop==P.StopSignalSent)
        case mode of StopDuringPreparation -> putMVar release (); _ -> pure ()
        outcome <- readMVar completed
        case outcome of
          Left problem -> throwIO problem
          Right result -> case mode of
            StopDuringPreparation -> check "in-flight prep returns Unknown and no callbacks"
              (persistentBackendStartupRefusal result==Just P.StartupAdmissionUnknown
                && persistentBackendCounts result==(0,0))
            _ -> pure () -- entry positive only; does not infer process/cleanup status
