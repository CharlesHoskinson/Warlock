{-# LANGUAGE OverloadedStrings #-}
-- QA-only, unexecuted source fixture. Import from Root's existing
-- test-ui-origin / engine-protocol harness; do not ship as product code.
--
-- Production mapped topology: Mvp.encodeMappedTopology -> EngineAdapter
-- parseSourceEvent -> EngineProtocol.parseEvent/eventJson -> broker ->
-- Owner.topology/scope -> gateway -> UiHttp -> DesktopPolicy. Both parser
-- and owner require exact scope keys. An actual issuer requires a mapped
-- surface; this controlled fixture does not establish a guest callback.
module OwnKeyApprovedBoundary (parserChecks, adapterChecks, ownerRejectsFresh, validTopology, invalidTopologies) where

import Control.Exception (SomeException, fromException, try)
import Data.Either (isLeft, isRight)
import Data.IORef (newIORef, readIORef, modifyIORef')
import Data.Text (Text)
import qualified Data.Text.Encoding as TE
import System.IO.Error (ioeGetErrorString, isUserError)
import qualified Warlock.Protocol.Desktop as Desktop
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.EngineProtocol as P
import qualified Warlock.Ui.EngineAdapter as Adapter
import qualified Warlock.Ui.Owner as Owner

scope :: [(Text, J.Json)] -> J.Json
scope extras = J.JObject ([ ("id", J.JString "1"), ("generation", J.JString "1") ] ++ extras)

topology :: J.Json -> J.Json
topology item = J.JObject
  [ ("viewProtocol", J.JNumber "1"), ("kind", J.JString "view-topology")
  , ("revision", J.JString "1"), ("views", J.JArray [item]) ]

validTopology :: J.Json
validTopology = topology (scope [])

invalidTopologies :: [(String, J.Json)]
invalidTopologies =
  [ ("null", topology (scope [("hasOwnProperty", J.JNull)]))
  , ("false", topology (scope [("hasOwnProperty", J.JBool False)]))
  , ("text", topology (scope [("hasOwnProperty", J.JString "not-a-function")]))
  , ("object", topology (scope [("hasOwnProperty", J.JObject [("nested", J.JBool True)])]))
  ]

-- Independent literals: a valid topology round-trips through the typed
-- producer; each extra field is rejected by the actual parser. A string
-- value inside an unexpected field is still an extra *field*, not a blanket
-- ban on the text hasOwnProperty.
parserChecks :: [(String, Bool)]
parserChecks = ("valid-topology-roundtrip", case P.parseEvent P.OwnerTopology validTopology of
  Right event -> P.eventJson event == validTopology
  Left _ -> False) :
  [ ("reject-scope-extra-" ++ name, P.parseEvent P.OwnerTopology value == Left P.Invalid)
  | (name, value) <- invalidTopologies ] ++ nativeGatewayChecks

-- Run each malformed source event against the actual engine-side adapter with
-- a spy RPC, before any Owner is called. emitEvent intentionally throws on
-- malformed producer payload; it must never invoke RPC in these cases. The
-- positive control must invoke RPC exactly once with the canonical typed event.
-- This is a unit boundary fixture: the spy does not authenticate a peer or
-- exercise the real socket, broker, owner queue or Elm frontend.
adapterChecks :: IO [(String, Bool)]
adapterChecks = do
  positiveCount <- newIORef (0 :: Int)
  positiveCanonical <- newIORef False
  let positiveRpc request = do
        modifyIORef' positiveCount (+1)
        modifyIORef' positiveCanonical (const (case request of
          P.OwnerEvent event -> P.eventJson event == validTopology
          _ -> False))
        pure (Right (P.EventReply P.Accepted))
  accepted <- try (Adapter.emitEvent positiveRpc (Owner.OwnerTopology validTopology)) :: IO (Either SomeException (Either Text ()))
  calls <- readIORef positiveCount
  canonical <- readIORef positiveCanonical
  negatives <- mapM (\(name, value) -> do
    count <- newIORef (0 :: Int)
    let rpc _ = modifyIORef' count (+1) >> pure (Right (P.EventReply P.Accepted))
    result <- try (Adapter.emitEvent rpc (Owner.OwnerTopology value)) :: IO (Either SomeException (Either Text ()))
    seen <- readIORef count
    let expectedRefusal = case result of
          Left err -> case fromException err of
            Just ioe -> isUserError ioe && ioeGetErrorString ioe == "invalid engine owner event"
            Nothing -> False
          Right _ -> False
    pure ("adapter-blocks-before-rpc-" ++ name, expectedRefusal && seen == 0)) invalidTopologies
  pure (("adapter-valid-canonical-once", case accepted of
    Right (Right ()) -> calls == 1 && canonical
    _ -> False) : negatives)

-- Native.receiveGateway decodes this exact gateway and checks its configured
-- binding before forwarding the original bytes. The decoder's nested exact
-- schema rejects the extra key even though its JSON spelling is legitimate.
-- Conversely the same spelling as a catalog *string value* remains valid.
nativeGatewayChecks :: [(String, Bool)]
nativeGatewayChecks =
  [ ("native-catalog-ordinary-string-accepted", isRight (decode (catalogGateway [])))
  , ("native-catalog-extra-entry-key-refused", isLeft (decode (catalogGateway [("hasOwnProperty", J.JNull)])))
  , ("native-catalog-extra-binding-key-refused", isLeft (decode (bindingExtraGateway J.JNull)))
  ]
  where
    decode = Desktop.decodeDesktopGateway . TE.encodeUtf8 . J.renderJson
    binding extra = J.JObject ([ ("lifetime", J.JString "1"), ("session", J.JString "1"), ("frontend", J.JString "1") ] ++ extra)
    entry extra = J.JObject ([ ("id", J.JString "demo"), ("name", J.JString "hasOwnProperty")
      , ("iconHint", J.JString ""), ("wmclass", J.JString ""), ("genericName", J.JString "")
      , ("keywords", J.JArray [J.JString "hasOwnProperty"]) ] ++ extra)
    wrap owner extra = J.JObject [ ("bridgeProtocol", J.JNumber "1"), ("kind", J.JString "native-event")
      , ("payload", J.JObject [ ("protocolVersion", J.JNumber "3"), ("kind", J.JString "application-catalog")
        , ("binding", owner), ("requestId", J.JString "1"), ("preferences", J.JNull)
        , ("snapshot", J.JObject [ ("catalogProtocol", J.JNumber "2"), ("lifetime", J.JString "1")
          , ("generation", J.JString "1"), ("entries", J.JArray [entry extra]) ]) ]) ]
    catalogGateway extra = wrap (binding []) extra
    bindingExtraGateway value = wrap (binding [("hasOwnProperty", value)]) []

-- Invoke once per freshly constructed real UiOwner, AFTER the harness has
-- drained its normal startup queue and before any competing issuer is active.
-- Owner records a failure for malformed trusted callbacks: do not use one
-- owner for several negative probes or assume it continues serving GETs.
-- Root's harness must separately assert failed owner outcome, delivery/event
-- count and complete Elm observation; False/unknown cleanup stays distinct.
ownerRejectsFresh :: (Owner.TrustedOwnerEvent -> IO (Either Text ())) -> J.Json -> IO Bool
ownerRejectsFresh emit malformed = isLeft <$> emit (Owner.OwnerTopology malformed)
