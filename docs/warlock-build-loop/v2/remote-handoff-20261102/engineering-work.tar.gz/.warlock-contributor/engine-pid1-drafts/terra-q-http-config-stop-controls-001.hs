{-# LANGUAGE OverloadedStrings #-}
-- QA-ONLY module for an isolated source overlay of Store 8a46 + Backend
-- candidate 011/012 + Engine prelive gate. Not a shipped production module.
-- Root hosts one case at a time and MUST retain a strong root to Case BEFORE
-- calling runCase, through every exception/timeout. Root's existing protected
-- launcher and original external QA deadline guard all blocking reads; this
-- file invents no product deadline, kills no worker, and asserts no cleanup.
-- The caller supplies a valid real private config path and a distinct absent
-- child path beneath an owned existing directory. Neither is untrusted input.
module QHttpConfigStopControls (Mode(..),Case,newCase,runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException, mask, try)
import Control.Monad (unless)
import Data.IORef (IORef,newIORef,writeIORef)
import qualified Data.Text as T
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import Warlock.Backend (PersistentBackendOwner,newPersistentBackendOwner,
  loadPersistentBackendConfig,requestPersistentBackendStop,qaPersistentConfigState)
import Warlock.Backend.Store (qaStoreSetAcquireHook,qaStoreClearHooks,
  qaStoreEntryCount,qaStoreRawCount,qaStoreNegativeCount)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = ValidConfig | StopBeforeEntry | StopAfterRawAcquire | DefiniteMissing deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
  (MVar (Either SomeException (Either T.Text ()))) (IORef (Maybe ThreadId))

check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  stopBudget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current stopBudget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing

-- Root installs an owned root (e.g. its same-process StablePtr registry)
-- before runCase. The retained barriers and ThreadId remain reachable on any
-- failure. Do NOT free the root on an assertion, False, timeout or Stop ACK.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase (Case owner start rawAcquired release finished workerSlot) mode path = mask $ \restore -> do
  check "absolute owned config name" (isAbsolute path)
  exists <- doesPathExist path
  check "caller supplied correct valid/missing path" (if mode==DefiniteMissing then not exists else exists)
  qaStoreClearHooks
  case mode of
    ValidConfig -> restore $ do
      result <- loadPersistentBackendConfig owner path
      state <- qaPersistentConfigState owner
      entries <- qaStoreEntryCount
      raws <- qaStoreRawCount
      check "real config path loads and installs once" (result==Right () && state==(True,True,True) && entries>0 && raws>0)
      before <- qaStoreEntryCount
      repeatResult <- loadPersistentBackendConfig owner path
      after <- qaStoreEntryCount
      check "duplicate config does not enter Store" (repeatResult==Left "persistent config owner already used" && after==before)
    StopBeforeEntry -> restore $ do
      stop <- requestPersistentBackendStop owner
      result <- loadPersistentBackendConfig owner path
      state <- qaPersistentConfigState owner
      entries <- qaStoreEntryCount
      raws <- qaStoreRawCount
      check "actual pre-live stop prevents config Store entry" (stop==P.StopLatchedBeforeLive && isLeft result && state==(True,True,False) && entries==0 && raws==0)
      repeatResult <- loadPersistentBackendConfig owner path
      after <- qaStoreEntryCount
      check "pre-stop config attempt cannot replay" (repeatResult==Left "persistent config owner already used" && after==0)
    StopAfterRawAcquire -> do
      -- The one-shot hook fires only after the actual acquire returned a real
      -- Acquired value, BEFORE Store publishes that value or starts body IO.
      qaStoreSetAcquireHook (putMVar rawAcquired () >> takeMVar release)
      thread <- forkIOWithUnmask $ \unmask -> do
        result <- try (unmask (takeMVar start >> loadPersistentBackendConfig owner path))
        putMVar finished result
      writeIORef workerSlot (Just thread)
      putMVar start ()
      restore $ do
        readMVar rawAcquired
        stateAtHook <- qaPersistentConfigState owner
        raws <- qaStoreRawCount
        check "same owner retained Store before actual raw acquisition" (stateAtHook==(True,True,False) && raws==1)
        stop <- requestPersistentBackendStop owner
        check "stop latched during admitted config read" (stop==P.StopLatchedBeforeLive)
        putMVar release ()
        outcome <- readMVar finished
        stateAfter <- qaPersistentConfigState owner
        check "post-stop config cannot install" (case outcome of Right (Left _) -> stateAfter==(True,True,False); _ -> False)
        before <- qaStoreEntryCount
        repeatResult <- loadPersistentBackendConfig owner path
        after <- qaStoreEntryCount
        check "post-stop unknown cannot replay read" (repeatResult==Left "persistent config owner already used" && after==before)
    DefiniteMissing -> restore $ do
      result <- loadPersistentBackendConfig owner path
      state <- qaPersistentConfigState owner
      negatives <- qaStoreNegativeCount
      check "actual open received at least one explicit negative receipt" (isLeft result && negatives>0 && state==(True,True,False))
      before <- qaStoreEntryCount
      repeatResult <- loadPersistentBackendConfig owner path
      after <- qaStoreEntryCount
      check "definite missing config cannot replay same owner" (repeatResult==Left "persistent config owner already used" && after==before)
  -- No result above asserts backend retirement, resource close, FD drainage,
  -- native provider acceptance, or that the selected worker was killed.
  where
    isLeft (Left _) = True
    isLeft _ = False
