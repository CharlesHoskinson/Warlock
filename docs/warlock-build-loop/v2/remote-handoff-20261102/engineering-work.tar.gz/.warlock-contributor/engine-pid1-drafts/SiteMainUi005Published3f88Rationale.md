# Website Visual & Status Draft Aligned to Published `3f88ed9b4` Idle-MVP, Physical `Applications` Catalog & Bounded `run-08` Search View (`SiteMainUi005Published3f88.diff`)

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`, run `warlock-20261031-setup`)
- **Timestamp (UTC)**: `2026-11-01T18:10:30Z` (governing cutoff `2026-11-01T18:19:00Z`)
- **Target File (Untouched on Disk)**: `/home/charl/code/Warlock/site/src/SiteMain.elm`
  - Existing SHA-256: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (`1,663` lines)
  - Patch Draft (v2, incorporating `sol-docs` `01M6C4S149JGXM063JMN19T163` & `gemini-gui` `01M6C4H8KSZ7DPDTKMQVD6D47R`): `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainUi005Published3f88.diff`
  - Patch SHA-256 (v2): `275143199950a257ca6c3b2b0d973847d57488c061d0699ddfc0021c35608139` (`26,838` bytes, `421` lines; `git apply --check` `exit 0` and `-R` reverse round-trip verified)
  - Simulated Post-Apply `SiteMain.elm` SHA-256: `40541637a130f3051e59e021b707d0a2285b224444a9d729faf8361b5737cd21` (`77,176` bytes, `1,801` lines)
  - Retained Historical Drafts (Untouched):
    - `SiteMainIdleDeliveryStatus.diff`: `3132bf6f1e3b6999cdd191a0743f92385c64e203516a8e6a1a16ab09bcafcea5`
    - `SiteMainVisualHierarchy1713.diff`: `03913cad0a950ec22a3ac7c497ddaf40916224d4a1b9a2f4df87349cc4c9f344`
- **Strict Scope & Source-Only Proposal Framing**:
  - **Source-only Elm preparation draft** awaiting Root's canonical evidence integration, protected compiler, and browser verification. Not compiled, rendered in a live browser, or measured by automated QA; CSS layout/zoom behavior and `tokens.css` hex luminance ratios below are static source-level calculations only.
  - **Small pure-Elm delta only** (`SiteMain.elm` only; zero new authored JS, zero edits to `site/elm.json`, zero changes to exported module API `AppearanceTheme(..)`, `CueFacts`, `Model`, `MotionMode(..)`, `Msg(..)`, `OutcomeSample(..)`, `SurfaceCategory(..)`, `SurfaceId(..)`, `init`, `main`, `update`, `view`, `viewDocument`, and zero new routes).

---

## 1. Published `3f88ed9b4` Evidence & Directly Viewed VM Screenshots

Directly inspected canonical artifacts and VM screenshots on unchanged `3f88ed9b498cf07d7c944cdcb3cb27163358b310`:
1. **`implementation/warlock/qa/evidence/engine-idle-20261101/component-observation.json` & `docs/HANDOFF.md:358-367`**:
   - Offline protected check `1793553496966127943` (`protected-report.json` `sha256:2088b85bda81004372a59d7cf9237deecae9dba24d2b52e10ca3d744a66e539b`, `source-freeze.json` `sha256:409c150abd2f5789b478d4f68334e8949f4b5f13a3d1751a0567b0b44dc378ed`, `345` pinned input hashes): **all `10` Haskell suites PASS** and **`273` named model tests PASS** (`+25` new desktop-idle named model tests over the prior **`248` named model tests** on `392d1838f`), retaining earlier RED `1793552951595244964`.
   - Every occurrence of `273` and `248` in `SiteMainUi005Published3f88.diff` uses the exact phrase **`"273 named model tests"`** (`3`×) and **`"248 named model tests"`** (`3`×)—zero bare `"models"` or `"Quint models"` labels.
2. **Directly Viewed Omarchy VM Screenshots (`engine-idle-20261101T172728Z`, Retaining Failed Pre-Input/Timing Runs `run-02..07` Without Allocation-Bug Claims)**:
   - **`run-01/live-07.png` (`sha256:93567684e5cc887043c2ffe0d8080d0ed88b1647a2540e2be13710fb703f70df`)**: Same-ELF PID-1 `warlock-ui-owner` (`pid 106427`) recorded **mapped-window samples across `26.4s`** (`26.415s` sampled interval, not a claim of perpetual/continuous visibility or stream quiescence) inside the unchanged **`28s`** original trial deadline `D` (`callbacks: 3`, `operations: 1`, `auth: CredentialDelivered`, replacing the prior `7.445s` `CredentialTransport TimedOut`), alongside intact `Foot` (`pid 2095`).
   - **`run-03-apps-settled.png` (`sha256:ca5d63e49ae2ae6d72d027c44843ef72180ebf281f71ecb7a5d0639ea556c1d0`)**: Physical QMP `Applications` click at `(715, 65)` under fresh PID/birth/lineage/cgroup/window/geometry/monitor/lock/`Foot`/`D` fences opened the live Elm `Applications` catalog displaying **`62` matching catalog entries** (`Items 1–8 of 64 · 62 matching applications · 0 pinned`).
   - **`run-08-query.png` (`sha256:9ed3d02bd0b360afbfb9073eca6b9b83d8a190bfd7c851d766e0357c0094d84e`)**: On unchanged `3f88ed9b498cf07d7c944cdcb3cb27163358b310`, bounded physical `Applications`/`Search` clicks plus 5 keys (`qvxz9`, no `Enter`) visibly retained `qvxz9` in `Search applications` alongside canonical `"No matching applications. Change your search or Refresh."` in both `HttpBar` and `HttpPopup` (`#8EC8FF` info-blue `3px` solid inline-start rule on `#141112` recessed callout surface) with no route launch action.
3. **Explicitly Partial / Unverified / Open Gates (`sol-docs` `01M6C4S149JGXM063JMN19T163` & `component-observation.json`)**:
   - **`ELM-UI-005` & `ELM-ARC-002` remain `partial`** (neither whole `ELM-UI-005` nor scenario/whole ledger counters are incremented).
   - **Exact final-query authoritative projection correlation remains unverified** (`Popup.pendingQuery` can overlay the displayed `<input>` field while projected status comes from an accepted query).
   - **AT, IME, provider cleanup (`providerCleanupQualified: false`), and final scope cleanup (`finalScopeMembershipKnown: false`) remain unqualified**.
   - **Native window controls remain unavailable**: `nativeOperations: []`.
   - **Stop guard `HOSTSTOP2` preserved** (explicitly distinct from `OPEN` gates).
   - **Historical ledger counts unchanged**: `15 / 242` whole requirements and `39 / 417` scenarios hold source-hash-bound historical verdicts only; all `242` requirements, `417` scenarios, original `28s`/`5s` deadlines `D`, and retained failed runs (`1793552951595244964`, `run-02..07`—inline `SurfaceTheme.barActionsStyles` `overflow-x: auto` / QMP single-warp timing observations, zero product allocation-bug claim) remain preserved; `ELM-ARC-024`, `ELM-DEL-014`, and native/release acceptance remain `OPEN`.

---

## 2. Scoped Visual, Spacing & Accessibility Delta Summary (`SiteMain.elm` Only)

1. **Hero Tester Action + 3-Row Lacquer Status Ledger (`viewHero`)**:
   - Replaces the flat 75-word `<p class="wl-hero-note">` with `<dl class="wl-hero-ledger">` (no prohibited `aria-label` on `<dl>`) on `#141112` recessed surface with `3px` solid `#FCA399` inline-start rule and stroke- + token-coded `2px` row markers (`is-simulated` `#8EC8FF`, `is-observed` `#FCA399` for recorded `3f88ed9b4` `26.4s` mapped samples + `62`-entry `Applications` catalog + bounded `qvxz9` visible no-match view, `is-open` dashed `#F2C172` for `ELM-UI-005` `partial` / unverified `pendingQuery` projection correlation + unqualified AT/IME/cleanup + `HOSTSTOP2 preserved` + open gates).
   - Groups hero CTAs in `role="group"` (`Open browser test drive (simulated)`, `Current build and acceptance status`, `Inspect 8 surfaces`).
2. **`#scope` Readiness Strip (`4 -> 2 -> 1`) & `2 × 2` Scope Cards (`viewScopeSection`, `supplementalCss`)**:
   - Replaces `auto-fit` `3 + 1` orphan wrapping with `4 -> 2 -> 1` on `.wl-home-readiness-strip` (`>1040px`, `<=1040px`, `<=560px`) and `.wl-home-root .wl-band .wl-home-scope-grid` `(0,3,0)` `2 × 2 -> 1` (`>760px`, `<=760px`), flex-aligned `.wl-home-card-footer`, `aria-labelledby` `<article>` landmarks, and existing-route jump links.
   - Aligns the Principles receipt-preview badge (`line 1391`) to `"Model preview · Offline component checks pass; ELM-UI-005 partial & native ELM-UI-007/AT/IME gates OPEN"`.
3. **Dawn, Night, High Contrast & `forced-colors` Token Consistency (Source-Level Proposal)**:
   - Uses `--wl-sys-color-border-essential` on `.wl-doc-skip`, `.wl-hero-eyebrow`, secondary hero buttons, and `.wl-hero-ledger` (static `tokens.css` luminance math: `6.39:1` Night, `5.01:1` Dawn, `21:1` High Contrast vs canvas); sets solid `#FFFFFF` / `CanvasText` on `.wl-home-card-footer` in `High contrast` and `@media (forced-colors: active)`; disables `backdrop-filter` in `High contrast` and `forced-colors`; moves Dawn hero mobile breakpoint to `960px`; raises `.wl-home-chip` `min-height` to `2.5rem`.

---

## 3. Coordination & Peer Review Log (`sol-docs` & `gemini-gui`)

1. **`sol-docs` review received (`01M6C4S149JGXM063JMN19T163`, `18:08:33Z`) — ALL POINTS INCORPORATED IN v2 (`27514319...`)**:
   - Replaced stale `"NOT YET OBSERVED"` / `"search typing unqualified"` copy with the bounded `run-08` physical query/no-match visible observation (`qvxz9` + `"No matching applications. Change your search or Refresh."` on unchanged `3f88ed9b4`, no `Enter`, no route launch) after directly viewing `run-08-query.png` (`sha256:9ed3d02bd0b360afbfb9073eca6b9b83d8a190bfd7c851d766e0357c0094d84e`).
   - Marked `ELM-UI-005` `partial` alongside `ELM-ARC-002` `partial`, explicitly noted exact final-query authoritative projection correlation remains unverified (`Popup` `pendingQuery` overlay), kept AT/IME/provider/scope/native/release unqualified/OPEN, and kept `15 / 242` whole & `39 / 417` scenarios unchanged.
   - Worded `26.4s` strictly as **mapped-window samples** (not perpetual/continuous visibility), preserved `10` suites / `273 named model tests` / `345` pinned inputs (+`25` over `248 named model tests`), retained failed runs (`1793552951595244964`, `run-02..07`) with zero allocation-bug claim, and framed v2 as a preparation draft awaiting Root's canonical integration.
2. **`gemini-gui` coordination (`01M6C4H8KSZ7DPDTKMQVD6D47R`, `18:04:19Z` & `01M6C2GN8EP0MVC4RSBA84B2BX`)**:
   - Preserved all 3 ARIA/CSS fixes (no prohibited `aria-label` on `<dl>`, solid High-Contrast / `forced-colors` `.wl-home-card-footer` top border, clean eyebrows + `"recorded tuple 3f88ed9b4"` attribution) and incorporated exact inline `SurfaceTheme.barActionsStyles` (`overflow-x: auto`) scanline provenance in this rationale.
