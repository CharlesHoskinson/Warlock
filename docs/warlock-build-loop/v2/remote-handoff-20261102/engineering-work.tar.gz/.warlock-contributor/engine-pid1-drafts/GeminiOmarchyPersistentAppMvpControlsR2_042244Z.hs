{-# LANGUAGE OverloadedStrings #-}
-- Candidate persistent application MVP positive & negative controls (r2,
-- unexecuted by worker; Root alone compiles and executes under protected QA).
-- Exercises Warlock.Backend (055..058) + Warlock.Bootstrap (r7) directly
-- against the real independently-pinned ui-stream-child executable without
-- inventing a CLI host StopBudget policy:
--   1. Persistent attachment + catalog + pin write across multiple commits
--      (empty + empty + catalog-request + taskbar-pins-write), verifying single
--      application-attached emission, DeliveryCompleted WrittenLocally,
--      persisted taskbar.json, and natural-exit retirement (once + idempotent)
--      without explicit stop.
--   2. Restart persistence: fresh PersistentBackendOwner reads persisted
--      revision "2" without replay and retires cleanly.
--   3. Pre-live StopLatchedBeforeLive + central OwnedStopState (Portable 058):
--      requestPersistentBackendStop after config load and before run refuses
--      with StartupAdmissionRefused SessionClosed, reuses StopLatchedBeforeLive
--      on duplicate stop, seals unused root, and retires cleanly (True).
--   4. Settled missing-config refusal retiring cleanly via unbound root seal.
--   5. 20 deterministic hostile whole-frame rejection cases (shell-command,
--      window-effect, mismatched binding, bad protocolVersion, duplicate
--      requestId, trailing field, duplicate JSON key) refusing before domain IO
--      (operations == 0, DeliveryNotAttempted, sentinel absent, pins unchanged).
--   6. Nonzero child exit (exitCode = 23) synthetic stderr injection control:
--      verifies child wrote WARLOCK_SYNTHETIC_* markers to .stderr-injected and
--      documents that LeaderReaped Captured carries no ExitCode until Engine's
--      persistentLeaderExit (e9f0fc84) is reconciled and wired.
module GeminiOmarchyPersistentAppMvpControlsR2_042244Z
 ( runPersistentAppMvpControls ) where

import Control.Monad (forM_, unless)
import qualified Crypto.Hash.SHA256 as SHA
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import Data.IORef (modifyIORef', newIORef, readIORef)
import Data.List (sortOn)
import qualified Data.Text as T
import qualified Data.Text.Encoding as TE
import GHC.Clock (getMonotonicTimeNSec)
import Numeric (showHex)
import System.Directory (createDirectory, doesPathExist, listDirectory)
import System.FilePath ((</>), takeDirectory)
import System.Posix.Files (deviceID, fileID, getSymbolicLinkStatus, isRegularFile, setFileMode)
import System.Timeout (timeout)
import Warlock.Backend
 ( DirectoryPin(..)
 , PersistentDelivery(..)
 , loadPersistentBackendConfig
 , newPersistentBackendOwner
 , persistentBackendCounts
 , persistentBackendDelivery
 , persistentBackendOutcome
 , persistentBackendStartupRefusal
 , requestPersistentBackendStop
 , retirePersistentBackend
 , runPersistentBackend
 )
import Warlock.Bootstrap (PersistentBootstrapResult(..), newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as Persistent
import Warlock.Protocol.CredentialIngress (PersistentSendResult(..))
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (Counter, binding, parseCounter)
import qualified Warlock.Protocol.StrictJson as J

counter :: T.Text -> Counter
counter = either (error . show) id . parseCounter False

shaHex :: B.ByteString -> String
shaHex = concatMap (\byteVal -> let hexDigits = showHex byteVal "" in replicate (2 - length hexDigits) '0' ++ hexDigits) . B.unpack . SHA.hash

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

within :: String -> IO a -> IO a
within label action = timeout 10000000 action >>= maybe (ioError (userError (label ++ ": timed out"))) pure

encoded :: J.Json -> B.ByteString
encoded = TE.encodeUtf8 . J.renderJson

obj :: [(T.Text, J.Json)] -> J.Json
obj = J.JObject

txt :: String -> J.Json
txt = J.JString . T.pack

canonicalJson :: J.Json -> J.Json
canonicalJson (J.JObject pairs) = J.JObject (sortOn fst [(k, canonicalJson v) | (k, v) <- pairs])
canonicalJson (J.JArray items) = J.JArray (map canonicalJson items)
canonicalJson atomVal = atomVal

bindingValue :: J.Json
bindingValue = obj
 [ ("lifetime", txt "9007199254740993")
 , ("session", txt "9007199254740995")
 , ("frontend", txt "9007199254740997")
 ]

closedProjection :: J.Json
closedProjection = obj
 [ ("viewProtocol", J.JNumber "1")
 , ("kind", txt "view-frame")
 , ("revision", txt "1")
 , ("views", J.JArray [])
 , ("focusOwner", J.JNull)
 , ("popupOwner", J.JNull)
 , ("frame", obj
    [ ("surfaceProtocol", J.JNumber "2")
    , ("publication", txt "1")
    , ("lease", txt "0")
    , ("mode", txt "closed")
    , ("status", txt "")
    , ("bar", J.JArray [])
    , ("popup", J.JArray [])
    ])
 , ("announcer", J.JNull)
 , ("announcement", J.JNull)
 ]

requestJson :: String -> Int -> [(T.Text, J.Json)] -> J.Json
requestJson kindName reqIdentity extraFields = obj
 ( [ ("protocolVersion", J.JNumber "3")
   , ("kind", txt kindName)
   , ("binding", bindingValue)
   , ("requestId", txt (show reqIdentity))
   ] ++ extraFields )

commitBytes :: [J.Json] -> B.ByteString
commitBytes reqList = encoded $ obj
 [ ("viewProtocol", J.JNumber "1")
 , ("kind", txt "view-commit")
 , ("projection", closedProjection)
 , ("requests", J.JArray reqList)
 , ("focus", J.JArray [])
 ]

proposalJson :: String -> [String] -> J.Json
proposalJson revText identList = obj
 [ ("revision", txt revText)
 , ("identities", J.JArray (map txt identList))
 ]

pinDirectory :: FilePath -> IO DirectoryPin
pinDirectory dirPath = do
 statVal <- getSymbolicLinkStatus dirPath
 pure (DirectoryPin dirPath (toInteger (deviceID statVal)) (toInteger (fileID statVal)))

directoryJson :: DirectoryPin -> J.Json
directoryJson pinVal = obj
 [ ("path", txt (directoryPath pinVal))
 , ("device", txt (show (directoryDevice pinVal)))
 , ("inode", txt (show (directoryInode pinVal)))
 ]

freshDir :: FilePath -> IO FilePath
freshDir dirPath = createDirectory dirPath >> setFileMode dirPath 0o700 >> pure dirPath

writePrivate :: FilePath -> B.ByteString -> IO ()
writePrivate filePath rawBytes = B.writeFile filePath rawBytes >> setFileMode filePath 0o600

pinImage :: FilePath -> IO [String]
pinImage exePath = do
 statVal <- getSymbolicLinkStatus exePath
 rawBytes <- B.readFile exePath
 unless (isRegularFile statVal) (ioError (userError "nonregular trusted QA executable"))
 pure [show (deviceID statVal), show (fileID statVal), show (B.length rawBytes), shaHex rawBytes]

atField :: T.Text -> J.Json -> J.Json
atField fieldName (J.JObject pairs) = maybe J.JNull id (lookup fieldName pairs)
atField _ _ = J.JNull

runPersistentAppMvpControls
 :: FilePath -> [String] -> FilePath -> [String] -> FilePath -> IO Int
runPersistentAppMvpControls backendExe backendPins childExe childPins suiteRoot = do
 actualBackend <- pinImage backendExe
 actualChild <- pinImage childExe
 unless (actualBackend == backendPins && actualChild == childPins)
  (ioError (userError "independent executable pins differ"))
 (cDev, cIno, cSize, cSha) <- case childPins of
  [d0, d1, d2, d3] -> pure (d0, d1, d2, d3)
  _ -> ioError (userError "expected 4 child pin components")
 checksRun <- newIORef (0 :: Int)
 let check label good = do
      modifyIORef' checksRun (+ 1)
      unless good (ioError (userError label))
     makeSub subName = freshDir (suiteRoot </> subName)
 existingEntries <- listDirectory suiteRoot
 check "fresh private persistent MVP root" (null existingEntries)
 applicationsDir <- makeSub "applications"
 pinsDir <- makeSub "pins"
 let sentinelPath = suiteRoot </> "must-not-spawn"
 writePrivate (applicationsDir </> "alpha.desktop")
  (C.pack ("[Desktop Entry]\nType=Application\nName=Alpha\nExec=/bin/sh -c 'touch " ++ sentinelPath ++ "'\n"))
 writePrivate (applicationsDir </> "beta.desktop")
  "[Desktop Entry]\nType=Application\nName=Beta\nExec=/bin/true\n"
 catalogPin <- pinDirectory applicationsDir
 storagePin <- pinDirectory pinsDir
 let parentDirs = reverse (takeWhile (/= "/") (iterate takeDirectory (takeDirectory childExe)))
 ancestorPins <- mapM pinDirectory parentDirs
 testStopBudget <- must (Persistent.stopBudgetMicros 5000000)
 let expectedBinding = either (error . show) id
      (binding (counter "9007199254740993") (counter "9007199254740995") (counter "9007199254740997"))
     expectedAttachmentEnvelope = obj
      [ ("bridgeProtocol", J.JNumber "1")
      , ("kind", txt "native-event")
      , ("payload", obj
         [ ("protocolVersion", J.JNumber "3")
         , ("kind", txt "application-attached")
         , ("binding", bindingValue)
         , ("nativeOperations", J.JArray [])
         ])
      ]
     buildConfig scriptFile repliesFile deadlineNs attachOptIn =
      let baseFields =
           [ ("schema", J.JNumber "1")
           , ("binding", bindingValue)
           , ("deadlineMonotonicNs", txt (show deadlineNs))
           , ("ui", obj
              [ ("path", txt childExe)
              , ("device", txt cDev)
              , ("inode", txt cIno)
              , ("size", txt cSize)
              , ("sha256", txt cSha)
              , ("arguments", J.JArray [txt scriptFile, txt repliesFile])
              , ("ancestors", J.JArray (map directoryJson ancestorPins))
              ])
           , ("catalogRoots", J.JArray [directoryJson catalogPin])
           , ("pinsRoot", directoryJson storagePin)
           , ("locale", txt "C")
           ]
      in obj (if attachOptIn then ("applicationAttachment", J.JBool True) : baseFields else baseFields)
     framesJson exitCodeOpt frameRows =
      let baseRows =
           [ ("schema", J.JNumber "1")
           , ("frames", J.JArray
              [ obj
                 [ ("wire", J.JString (TE.decodeUtf8 wireBytes))
                 , ("replies", J.JNumber (T.pack (show replyCnt)))
                 , ("refused", J.JBool isRefused)
                 ]
              | (wireBytes, replyCnt, isRefused) <- frameRows
              ])
           ]
      in obj (case exitCodeOpt of
          Nothing -> baseRows
          Just ec -> baseRows ++ [("exitCode", J.JNumber (T.pack (show ec)))])
     prepareCase caseLabel attachOptIn exitCodeOpt frameRows = do
      caseDir <- makeSub caseLabel
      let scriptFile = caseDir </> "script.json"
          repliesFile = caseDir </> "replies.json"
          configFile = caseDir </> "startup.json"
      writePrivate scriptFile (encoded (framesJson exitCodeOpt frameRows))
      nowNs <- getMonotonicTimeNSec
      writePrivate configFile (encoded (buildConfig scriptFile repliesFile (toInteger nowNs + 5000000000) attachOptIn))
      pure (configFile, repliesFile)
     readReplyFrames repliesFile = do
      rawBytes <- B.readFile repliesFile
      limits <- must (J.bounds (8 * 1024 * 1024) 16)
      decodedTree <- must (J.decodeStrict limits rawBytes)
      case decodedTree of
       J.JArray items -> mapM (\itemVal -> case itemVal of
        J.JString frameText -> pure (TE.encodeUtf8 frameText)
        _ -> ioError (userError "reply log entry must be string")) items
       _ -> ioError (userError "reply log must be JSON array")
     decodeJson rawBytes = do
      limits <- must (J.bounds 65536 16)
      must (J.decodeStrict limits rawBytes)

 -- 1. Positive persistent session: attachment once + catalog + pin write + natural exit retirement.
 (posCfg, posReplies) <- prepareCase "persistent-positive" True Nothing
  [ (commitBytes [], 1 :: Int, False)
  , (commitBytes [], 0 :: Int, False)
  , (commitBytes [requestJson "catalog-request" 2 []], 1 :: Int, False)
  , (commitBytes [requestJson "taskbar-pins-write" 3 [("proposal", proposalJson "1" ["alpha"])]], 1 :: Int, False)
  ]
 posSessions <- newCurrentSessions
 posOwner <- newPersistentBackendOwner posSessions testStopBudget
 posLoaded <- within "positive config load" (loadPersistentBackendConfig posOwner posCfg)
 check "positive persistent config loaded" (posLoaded == Right ())
 posRun <- within "positive persistent run" (runPersistentBackend posOwner)
 posDelivery <- persistentBackendDelivery posOwner
 check "positive persistent counts and delivery"
  ( persistentBackendCounts posRun == (4, 2)
  && persistentBackendStartupRefusal posRun == Nothing
  && posDelivery == DeliveryCompleted WrittenLocally
  )
 check "positive persistent observed LeaderReaped"
  (case persistentBackendOutcome posRun of
    Right (PersistentBootstrapObserved (Right (_, Persistent.LeaderReaped _))) -> True
    _ -> False)
 posRetired1 <- within "positive natural-exit retire" (retirePersistentBackend posOwner)
 posRetired2 <- within "positive natural-exit retire idempotent" (retirePersistentBackend posOwner)
 check "natural exit retires once and stays idempotent without explicit stop" (posRetired1 && posRetired2)
 posFrames <- readReplyFrames posReplies
 case posFrames of
  [attBytes, catBytes, pinBytes] -> do
   attGateway <- must (D.decodeDesktopGateway attBytes)
   attTree <- decodeJson attBytes
   catTree <- decodeJson catBytes
   pinTree <- decodeJson pinBytes
   check "first frame is authenticated application-attached"
    ( D.replyBinding attGateway == expectedBinding
    && canonicalJson attTree == canonicalJson expectedAttachmentEnvelope
    )
   check "second frame is catalog reply for requestId 2"
    ( atField "kind" (atField "payload" catTree) == txt "application-catalog"
    && atField "requestId" (atField "payload" catTree) == txt "2"
    )
   check "third frame saves taskbar pin revision 2"
    ( atField "status" (atField "payload" pinTree) == txt "Saved"
    && atField "revision" (atField "preferences" (atField "payload" pinTree)) == txt "2"
    )
  _ -> check "expected exactly 3 reply frames" False
 persistedPins <- B.readFile (pinsDir </> "taskbar.json")
 check "persisted taskbar.json matches expected content"
  (persistedPins == "{\"schema\":1,\"revision\":\"2\",\"identities\":[\"alpha\"]}")

 -- 2. Restart persistence without replay.
 (restartCfg, restartReplies) <- prepareCase "persistent-restart" False Nothing
  [(commitBytes [requestJson "catalog-request" 4 []], 1 :: Int, False)]
 restartSessions <- newCurrentSessions
 restartOwner <- newPersistentBackendOwner restartSessions testStopBudget
 restartLoaded <- within "restart config load" (loadPersistentBackendConfig restartOwner restartCfg)
 check "restart config loaded" (restartLoaded == Right ())
 restartRun <- within "restart persistent run" (runPersistentBackend restartOwner)
 restartRetired <- within "restart retire" (retirePersistentBackend restartOwner)
 restartFrames <- readReplyFrames restartReplies
 case restartFrames of
  [firstRestartFrame] -> do
   restartTree <- decodeJson firstRestartFrame
   check "restart owner reads persisted revision 2 and retires cleanly"
    ( persistentBackendCounts restartRun == (1, 1)
    && restartRetired
    && atField "revision" (atField "preferences" (atField "payload" restartTree)) == txt "2"
    )
  _ -> check "expected 1 restart frame" False

 -- 3. Pre-live StopLatchedBeforeLive + central OwnedStopState (Portable 058).
 (preStopCfg, _) <- prepareCase "persistent-prelive-stop" False Nothing
  [(commitBytes [requestJson "catalog-request" 5 []], 1 :: Int, False)]
 preStopSessions <- newCurrentSessions
 preStopOwner <- newPersistentBackendOwner preStopSessions testStopBudget
 preStopLoaded <- within "pre-stop config load" (loadPersistentBackendConfig preStopOwner preStopCfg)
 check "pre-stop config loaded" (preStopLoaded == Right ())
 stopReceipt1 <- within "pre-stop first stop" (requestPersistentBackendStop preStopOwner)
 stopReceipt2 <- within "pre-stop duplicate stop" (requestPersistentBackendStop preStopOwner)
 check "central stop state latches once and reuses StopLatchedBeforeLive"
  ( stopReceipt1 == Persistent.StopLatchedBeforeLive
  && stopReceipt2 == Persistent.StopLatchedBeforeLive
  )
 preStopRun <- within "pre-stop run" (runPersistentBackend preStopOwner)
 preStopDelivery <- persistentBackendDelivery preStopOwner
 check "pre-stop run refuses with SessionClosed and DeliveryNotAttempted"
  ( persistentBackendStartupRefusal preStopRun == Just (Persistent.StartupAdmissionRefused SessionClosed)
  && persistentBackendCounts preStopRun == (0, 0)
  && preStopDelivery == DeliveryNotAttempted
  )
 preStopRetired <- within "pre-stop retire" (retirePersistentBackend preStopOwner)
 check "pre-stop owner retires cleanly via sealUnusedRootCustody + finishPersistentBootstrapPreLive" preStopRetired

 -- 4. Settled missing-config refusal retiring cleanly via unbound root seal.
 missingSessions <- newCurrentSessions
 missingOwner <- newPersistentBackendOwner missingSessions testStopBudget
 missingLoaded <- within "missing config load"
  (loadPersistentBackendConfig missingOwner (suiteRoot </> "does-not-exist-startup.json"))
 check "missing config refused" (missingLoaded /= Right ())
 missingRetired <- within "missing config retire" (retirePersistentBackend missingOwner)
 check "settled missing config retires cleanly via sealPersistentUnboundRoot" missingRetired

 -- 5. Negative: 20 deterministic hostile whole-frame rejection cases before domain IO.
 let hostileFrame caseIdx = case caseIdx `mod` (5 :: Int) of
      0 -> commitBytes [requestJson "shell-command" (100 + caseIdx) [("command", txt ("touch " ++ sentinelPath))]]
      1 -> commitBytes [requestJson "catalog-request" (100 + caseIdx) [], requestJson "catalog-request" (100 + caseIdx) []]
      2 -> commitBytes
            [ requestJson "catalog-request" (100 + caseIdx) []
            , obj
               [ ("protocolVersion", J.JNumber "3")
               , ("kind", txt "catalog-request")
               , ("binding", obj
                  [ ("lifetime", txt "9007199254740993")
                  , ("session", txt (show (9007199254741100 + toInteger caseIdx)))
                  , ("frontend", txt "9007199254740997")
                  ])
               , ("requestId", txt (show (200 + caseIdx)))
               ]
            ]
      3 -> commitBytes [requestJson "catalog-request" (100 + caseIdx) [("path", txt "/etc/passwd")]]
      _ -> "{\"viewProtocol\":1,\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{},\"requests\":[],\"focus\":[]}"
 forM_ [0 .. 19 :: Int] $ \caseIdx -> do
  let badLabel = "persistent-hostile-" ++ show caseIdx
  (badCfg, _) <- prepareCase badLabel True Nothing [(hostileFrame caseIdx, 0 :: Int, True)]
  badSessions <- newCurrentSessions
  badOwner <- newPersistentBackendOwner badSessions testStopBudget
  badLoaded <- within (badLabel ++ " load") (loadPersistentBackendConfig badOwner badCfg)
  check (badLabel ++ " config loaded") (badLoaded == Right ())
  badRun <- within (badLabel ++ " run") (runPersistentBackend badOwner)
  badDelivery <- persistentBackendDelivery badOwner
  badRetired <- within (badLabel ++ " retire") (retirePersistentBackend badOwner)
  sentinelExists <- doesPathExist sentinelPath
  currentPins <- B.readFile (pinsDir </> "taskbar.json")
  check (badLabel ++ " refuses before attachment/domain IO and retires cleanly")
   ( snd (persistentBackendCounts badRun) == 0
   && badDelivery == DeliveryNotAttempted
   && badRetired
   && not sentinelExists
   && currentPins == persistedPins
   )

 -- 6. Child nonzero exit (exitCode = 23) synthetic stderr injection + non-inference of exit 0.
 (privCfg, privReplies) <- prepareCase "persistent-stderr-23" False (Just (23 :: Int))
  [(commitBytes [requestJson "catalog-request" 500 []], 1 :: Int, False)]
 privSessions <- newCurrentSessions
 privOwner <- newPersistentBackendOwner privSessions testStopBudget
 privLoaded <- within "stderr-23 load" (loadPersistentBackendConfig privOwner privCfg)
 check "stderr-23 config loaded" (privLoaded == Right ())
 privRun <- within "stderr-23 run" (runPersistentBackend privOwner)
 privRetired <- within "stderr-23 retire" (retirePersistentBackend privOwner)
 injectedExists <- doesPathExist (privReplies ++ ".stderr-injected")
 let syntheticMarkers =
      [ "WARLOCK_SYNTHETIC_CREDENTIAL_DEL017_8C41A2"
      , "WARLOCK_SYNTHETIC_DRAFT_DEL017_9D52B3"
      , "WARLOCK_SYNTHETIC_PIXELS_DEL017_AE63C4"
      ]
 injectedBytes <- if injectedExists then B.readFile (privReplies ++ ".stderr-injected") else pure B.empty
 check "child exit 23 flushed all three synthetic stderr markers and owner retired cleanly"
  ( injectedExists
  && injectedBytes == B.intercalate "\n" syntheticMarkers <> "\n"
  && persistentBackendCounts privRun == (1, 1)
  && privRetired
  )
 readIORef checksRun
