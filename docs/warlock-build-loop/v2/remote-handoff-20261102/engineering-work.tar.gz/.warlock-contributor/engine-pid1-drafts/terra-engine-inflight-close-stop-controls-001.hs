{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Exercise real TransferTicket -> CoreTransfer close
-- while the same owner receives its first stop. Root must root each Probe,
-- input Handle and independent child guardian before entry, even on no-spawn.
-- The MVar deliberately blocks an interruptible Haskell close action: it is
-- not evidence that an in-flight kernel hClose is preemptible or completes by D.
module InflightCloseStopControls (Probe, newProbe, runNoStop, runLateStop) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.IO (Handle, hClose, hIsClosed)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), SessionExit(..), StopReceipt(..),
  StopDeadlineObservation(..), newPersistentOwner, persistentStatus,
  persistentUnderlyingStatus, requestSessionStop, tryPersistentStopDeadline,
  startBudgetAfter, startBudgetDeadline, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (persistentTicketFixture, withPersistentOwnerHook, qaPersistentInputReferences,
  qaPersistentPendingIssues)
import Warlock.Capture.Process.Transfer.Internal
 (TransferTicket, TransferDisposition(..), fixtureTicketWithClose, transferDisposition)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe Handle)) (IORef (Maybe TransferTicket))
 (IORef (Maybe ThreadId)) (MVar ()) (MVar ()) (MVar ()) (MVar ()) (MVar Result)
 (IORef Int) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("inflight close stop: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label io = timeout 5000000 io >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
expired :: AdmissionDeadline -> IO ()
expired d = do
 left <- remainingMicros d
 if left <= 0 then pure () else threadDelay (min 1000 left) >> expired d

runNoStop, runLateStop :: Probe -> Handle -> IO ()
runNoStop = run False
runLateStop = run True

run :: Bool -> Probe -> Handle -> IO ()
run late (Probe owner handleCell ticketCell worker prepared continue closeEntered closeContinue done closes reserves used) input = mask $ \restore -> do
 firstUse <- atomicModifyIORef' used (\x -> (True,not x))
 check "single-use probe" firstUse
 writeIORef handleCell (Just input)
 let closeAction = do
      atomicModifyIORef' closes (\n -> (n+1,()))
      putMVar closeEntered ()
      readMVar closeContinue
      hClose input
     hook stage = case stage of
      "persistent-before-spawn-reserve" -> putMVar prepared () >> readMVar continue
      "persistent-after-spawn-reserve" -> atomicModifyIORef' reserves (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar continue ())
      void (tryPutMVar closeContinue ())
      tid <- readIORef worker
      case tid of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     body = do
      ticket <- fixtureTicketWithClose input closeAction
      writeIORef ticketCell (Just ticket)
      start <- startBudgetAfter 1000000 >>= need
      configuredStop <- need (stopBudgetMicros 1000000)
      let selected = persistentTicketFixture "/warlock-qa-never-spawn" [] ticket
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selected 4096 start configuredStop
        (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar done)
       writeIORef worker (Just tid)
       pure tid
      within "input prepared" (readMVar prepared)
      within "original startup deadline expires" (expired (startBudgetDeadline start))
      void (tryPutMVar continue ())
      within "real transfer close action entered" (readMVar closeEntered)
      if late then do
       budget <- need (stopBudgetMicros 40000)
       receipt <- requestSessionStop owner budget
       first <- tryPersistentStopDeadline owner
       check "first stop latched while close is pending" (receipt == StopLatchedBeforeLive)
       stopD <- case first of
        StopDeadlineLatched d -> pure d
        _ -> ioError (userError "stop deadline unavailable: retain Unknown")
       within "original stop deadline expires" (expired stopD)
       again <- tryPersistentStopDeadline owner
       check "stop deadline unchanged" (again == StopDeadlineLatched stopD)
      else pure ()
      void (tryPutMVar closeContinue ())
      result <- within "owner returned" (readMVar done)
      closeCount <- readIORef closes
      reserveCount <- readIORef reserves
      disposition <- transferDisposition ticket
      refs <- qaPersistentInputReferences owner
      pending <- qaPersistentPendingIssues owner
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      closed <- hIsClosed input
      check "one actual close and no spawn reservation" (closeCount == 1 && reserveCount == 0 && closed && disposition == TransferClosed)
      if late then do
       second <- requestSessionStop owner configuredStop
       closeCountAfter <- readIORef closes
       check "late stop preserves retained uncertainty without replay" $
        refs == (0,1,True) && maybe False (const True) pending &&
        (case phase of PersistentQuarantined _ -> True; _ -> False) &&
        (case raw of Quarantined _ -> True; _ -> False) &&
        (case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False) &&
        second == StopAlreadyRequested && closeCountAfter == 1
      else check "no-stop positive returns confirmed cleanup" $
       refs == (0,0,False) && phase == PersistentRetired && raw == Available &&
       (case result of Right (Left (StartupRefused TimedOut)) -> True; _ -> False)
 restore body `finally` finish
