# Source-Literal Preference Receipt Regression Contract (`tea-positive-1900`)

- **Author**: `gemini-gui` (`warlock-20261031-setup`)
- **Draft Factory**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/tea-preference-receipt-cases.cjs`
  - **SHA-256**: `e154e44c78ec453bd7dbed9dcf12220f381b39dfa7d520182031dffd6dc7ac57`
- **Status**: Ignored preparation draft only — **NOT executed**, **zero reducer output captured**, **zero canonical edits**, **NOT EARS or native acceptance** (`242` requirements / `417` scenarios, `15` historical whole / `39` scenarios, deadlines, failures, `nativeOperations = []`, and `HOSTSTOP2` preserved).

---

## 1. Pinned Elm Source Tuple

Every `GIVEN`, intermediate state patch, `Publish` frame, `OutcomeAnnouncements` record, and byte-exact retained `batch.wire` string in `tea-preference-receipt-cases.cjs` is transcribed directly from:

| File | SHA-256 | Role in Contract |
| --- | --- | --- |
| `implementation/warlock/src/Desktop.elm` | `91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4` | Finite `SaveReceipt` / `ShortcutSaveReceipt` decoders (`120-150`, `918-926`, `1058-1065`, `1074-1081`), `windowBase` (`412-492`), `updateOrdinary` / `syncMotion` (`620-728`), `OpenSettings` / `Edit*` / `Save*` (`1210-1268`) |
| `implementation/warlock/src/DesktopPolicy.elm` | `018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e` | Outer envelope & `Effect` mapping (`Publish`, `Delay`) |
| `implementation/warlock/src/OutputController.elm` | `fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae` | `Topology`, `Renderer` (`view-action`), `commit` / `register` (`batches`, `observations`, `catalogs`, `operations`) |
| `implementation/warlock/src/SurfaceController.elm` | `2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998` | `publication` & `lease` minting (`34-95`) |
| `implementation/warlock/src/Surface.elm` | `91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca` | 7 bar rows (`376-435`) & 43 open-settings popup rows (`192-238`), `notice` / `packet` (`436-532`) |
| `implementation/warlock/src/Settings.elm` | `d13f4d63327eae4a80052252c8ba1f1e40db0f69954b46470ccff248e5ba0e7c` | `observe`, `edit`, `propose`, `receive` (`40-63`) |
| `implementation/warlock/src/MotionPreferences.elm` | `d3130d74c3172cb1808df38efd7a2cc267ba5ae346b564544661d3d539f5c560` | `observe`, `edit`, `propose`, `receive` (`42-70`) |
| `implementation/warlock/src/Motion.elm` | `e101862bae874426f0cf9aaf02340c6582abdeea21dec38c32003da7f94e8a69` | `desired`, `propose`, `ready`, `notice` (`23-82`) |
| `implementation/warlock/src/ShortcutPreferences.elm` | `d8c1a63f199612161e078e0f6c7f75cbbfa190953e19325e50169debc425dcec` | `inventoryDecoder`, `observe`, `edit`, `propose`, `receive` (`33-115`) |
| `implementation/warlock/src/PointerOwnership.elm` | `7e6d9f3e1ad79670383f58502449533d8a0857d38c6b62538eb89855a70b3ef3` | `receive`, `blocked` (`20-33`) |
| `implementation/warlock/src/OutcomeAnnouncements.elm` | `e1160f27432b3869ceb3627224d07cfdbfc9a996d83bf063f9563ec5c29216bb` | `settings-refused` correlation & sequence (`29, 77-116`) |

---

## 2. Exact Pre-`d6fa51ec` vs Post-`d6fa51ec` Source-Contract Proof

Before `d6fa51ec` (integrated into `Desktop.elm` `91223c94...`), `shell-settings-outcome`, `motion-preferences-outcome`, and `shortcut-preferences-outcome` decoded `"status"` with raw `D.string`. When a reachable pending save (`requestId: "7"`) received a malformed or cross-domain `status` string, it bypassed decoder rejection and hit the catch-all `else` branch of the domain `receive` function:

| Wire Event (`requestId: "7"`, matching `binding`) | Malformed `status` Inputs Covered | Pre-`d6fa51ec` Behavior (`D.field "status" D.string`) | Post-`d6fa51ec` Behavior (`saveReceiptDecoder` / `shortcutSaveReceiptDecoder`) |
| --- | --- | --- | --- |
| `shell-settings-outcome` (`Desktop.elm:1074-1081`, `Settings.elm:55-63`) | `"Stored"` (wrong domain), `"bogus"`, `""` | `Settings.receive` hit line `63` `else`: mutated `settings.outcome` (`Nothing -> Just { request = Counter "7", result = Unconfirmed }`), mutated `settings.notice` (`"Saving settings…" -> "Settings save not confirmed..."`), called `Desktop.advance` (`presentation: 11 -> 12`), incremented `controller.publication` (`11 -> 12`), and emitted a `[Publish ...]` `view-commit` frame. | `saveReceiptDecoder` (`"Saved" \| "Refused" \| "Unknown"`) fails with `Err "Save outcome status"`; `Desktop.elm:1081` returns `(model, [])`; `OutputController` emits `NIL` (`[]`) with **zero** state or effect mutation. |
| `motion-preferences-outcome` (`Desktop.elm:918-926`, `MotionPreferences.elm:62-70`) | `"Stored"` (wrong domain), `"bogus"`, `"Pending"` | `MotionPreferences.receive` hit line `70` `else`: mutated `motion.preferences.notice` (`"Saving motion preference…" -> "Motion preference save not confirmed..."`), called `Desktop.advance` (`presentation: 11 -> 12`), incremented `controller.publication` (`11 -> 12`), and emitted a `[Publish ...]` `view-commit` frame. | `saveReceiptDecoder` fails with `Err "Save outcome status"`; `Desktop.elm:920` returns `(model, [])`; `OutputController` emits `NIL` (`[]`) with **zero** state or effect mutation. |
| `shortcut-preferences-outcome` (`Desktop.elm:1058-1065`, `ShortcutPreferences.elm:106-115`) | `"Applied"` (internal adapter status), `"saved"` (wrong case), `"UNKNOWN"` (wrong case) | `ShortcutPreferences.receive` hit line `115` `else`: mutated `shortcutPreferences.notice` (`"Saving and applying shortcut choices…" -> "Shortcut application not confirmed..."`), called `Desktop.advance` (`presentation: 11 -> 12`), incremented `controller.publication` (`11 -> 12`), and emitted a `[Publish ...]` `view-commit` frame. | `shortcutSaveReceiptDecoder` (`"Saved" \| "Stored" \| "Refused" \| "Unknown"`) fails with `Err "Shortcut save outcome status"`; `Desktop.elm:1065` returns `(model, [])`; `OutputController` emits `NIL` (`[]`) with **zero** state or effect mutation. |

---

## 3. Reachable 9-Event Prelude Counter & Batch Ledger

Opening Settings requires full-shell `"attached"` (`applicationOnly == False`, `Surface.elm:424`) AND an idle `"pointer-ownership"` observation (`Desktop.elm:621`, `PointerOwnership.elm:25-33`).

| Step | Input Event | `publication` | `lease` | `Desktop.presentation` | `Desktop.request` | `batches` (head-first) | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `0` | `reset` | `'0'` | `'0'` | `Just '0'` | `'0'` | `[]` | Canonical `DesktopPolicy.initial` |
| `1` | `view-topology` (`rev '1'`, `[oneScope]`) | `'3'` | `'0'` | `Just '2'` | `'0'` | `[]` | `launch.revision = '2'`, `ownerScope = Just {1,1}` |
| `2` | `attached` (`binding`) | `'4'` | `'0'` | `Just '3'` | `'4'` | `[batchAttach]` | Emits `catalog '1'`, `settings '2'`, `motion '3'`, `shortcuts '4'`, `projection '1'` |
| `3` | `pointer-ownership` (`idle`, `serial '1'`) | `'5'` | `'0'` | `Just '3'` | `'4'` | `[batchAttach]` | `Desktop` does not call `advance`; `SurfaceController.elm:87-94` mints `publication '5'` |
| `4` | `view-action` `bar:settings` (`pub '5', lease '0'`) | `'6'` | `'1'` | `Just '6'` | `'6'` | `[batchOpenSettings, batchAttach]` | `OpenSettings` calls `advance` 3× (`3->4->5->6`); supersedes `settingsExpected = Just '5'`, `shortcutExpected = Just '6'`; `motionExpected` stays `Just '3'` |
| `5` | `shell-settings` (`requestId '5'`, Night) | `'7'` | `'1'` | `Just '7'` | `'6'` | `[batchOpenSettings, batchAttach]` | Clears `settingsExpected` & `settingsOpening`; emits `[Focus "...:7:settings:close"]` (no request -> no batch) |
| `6` | `motion-preferences` (`requestId '3'`, `override: null`) | `'8'` | `'1'` | `Just '8'` | `'6'` | `[batchOpenSettings, batchAttach]` | Clears `motionExpected`; `Motion.ready` holds (`observation == Nothing && selected == System`) |
| `7` | `shortcut-preferences` (`requestId '6'`, `baseInventory`) | `'9'` | `'1'` | `Just '9'` | `'6'` | `[batchOpenSettings, batchAttach]` | Reaches shared `loadedState` |
| `8` | `view-action` edit (`pub '9', lease '1'`) | `'10'` | `'1'` | `Just '10'` | `'6'` | `[batchOpenSettings, batchAttach]` | `settings:theme:dawn` / `settings:motion:full` / `settings:shortcuts:applications:alternate` |
| `9` | `view-action` save (`pub '10', lease '1'`) | `'11'` | `'1'` | `Just '11'` | `'7'` | `[batch*Write, batchOpenSettings, batchAttach]` | Reaches `pendingSettings.given` / `pendingMotion.given` / `pendingShortcut.given` (`setupTimers: 0`) |

---

## 4. Exported Cases (7 Cases, 26 Non-Prelude Tested Transitions)

1. `settings-pending-malformed-status-noop-then-unknown-and-refused`:
   - Rejects `'Stored'`, `'bogus'`, and uncorrelated `requestId: '99'` `'Refused'` with exact `(s.given, NIL)`.
   - Accepts `'Unknown'` (`pub '12', pres '12'`, `outcome = Just Unconfirmed`, `pending` retained).
   - Verifies duplicate `'Unknown'` and `view-action` `settings:save` (`pub '12', lease '1'`) while `Unknown` are exact `(s.unknown.state, NIL)` (no replay).
   - Accepts correlated `'Refused'` (`pub '13', pres '13'`, clears `pending`, emits `OutcomeAnnouncements` `settings-refused` sequence `'1'`).
2. `settings-pending-malformed-status-noop-then-saved`:
   - Rejects `''` even with valid `revision: '2'` snapshot -> `(s.given, NIL)`.
   - Accepts `'Saved'` (`pub '12', pres '12'`, updates `snapshot` + `appearance` to `dawn`, clears `pending`).
3. `motion-pending-malformed-status-noop-then-unknown-and-refused`:
   - Rejects `'Stored'` and `'bogus'` -> `(m.given, NIL)`; verifies `'Unknown'`, no-op re-save (`settings:motion:save`), and `'Refused'`.
4. `motion-pending-malformed-status-noop-then-saved-syncs-profile`:
   - Rejects `'Pending'` even with valid `revision: '2'` `'full'` snapshot -> `(m.given, NIL)`.
   - Accepts `'Saved'`, triggering `Desktop.syncMotion -> Motion.propose` (`requestId: '8'`, `motion-profile-set` `'full'`, `presentation: 11 -> 13`, `batchMotionProfileSet` at `publication: '12'`).
5. `shortcut-pending-malformed-status-noop-then-unknown-and-refused`:
   - Rejects `'Applied'` -> `(k.given, NIL)`; verifies `'Unknown'`, no-op re-save (`settings:shortcuts:save`), and `'Refused'`.
6. `shortcut-pending-malformed-status-noop-then-stored`:
   - Rejects lowercase `'saved'` -> `(k.given, NIL)`; accepts shortcut-only `'Stored'` (`snapshot` updated to `revision: '2'`, `inventory` stays `baseShortcutInventoryWire` so `settings:shortcuts:save` stays enabled for live-chord retry).
7. `shortcut-pending-malformed-status-noop-then-saved`:
   - Rejects uppercase `'UNKNOWN'` -> `(k.given, NIL)`; accepts `'Saved'` with `appliedShortcutInventoryWire` (`applications.active == 'alternate'`, `settings:shortcuts:save` disabled).

---

## 5. Integration Wiring for Root (`tea-contract-cases.cjs` & UX Companion)

`tea-preference-receipt-cases.cjs` is pure CommonJS with zero `require` or host globals:

- **Direct `tea-contract-cases.cjs` integration (`lines 1399, 1417-1420`)**:
  Inline `buildPreferenceSeeds` and `buildPreferenceReceiptCases`, and pass `buildPreferenceReceiptCases` in the `buildAdditionalCases({...})` argument object (all 14 required context keys are already present at `tea-contract-cases.cjs:1417-1420`).
- **Companion `terra-browser-tea-preference-feedback.cjs` integration**:
  Pass `pendingSettings: buildPreferenceSeeds(baseContext).pendingSettings` into `buildPreferenceFeedbackCases({ cloneLiteral, initial, NIL, bindingJson, pendingSettings })`. Every precondition (`prelude`, `setupTimers: 0`, `given`, `givenEffects`, `requestId: '7'`, `unknown: { state, effects }`) is populated directly.
