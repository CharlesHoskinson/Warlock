port module CapturedActionLifecycleReplay exposing (main)

{-| Source-only deterministic sequence fixture. Exercises real Surface.packet,
Presentation.accept/dispatch and Surface.resolve. Values are synthetic Elm
inputs: this does not establish a native origin or authenticate a renderer.
No production constructors are exposed and no runtime execution is claimed.
Root must add this module to a result-consuming QA profile and run its checks.
-}

import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Presentation
import Shell
import Surface
import SurfaceSnapshot
import TaskbarShell
import UInt64

port outgoing : E.Value -> Cmd msg

counter value =
    D.decodeValue UInt64.decoder (E.string value) |> Result.withDefault UInt64.zero

bound =
    E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]

native wire model =
    NativePointerFixture.incoming wire model |> Tuple.first

attached =
    E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",bound)]

window identity =
    E.object [("incarnation",E.string identity),("label",E.string ("Document "++identity)),
        ("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]

projection request =
    E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",bound),
        ("requestId",E.string request),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),
            ("output",E.string "1"),("revision",E.string "1")]),
        ("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),
            ("windows",E.list identity [window "1",window "2"])])]

ready =
    Desktop.initial |> native attached |> native (projection "1")

groupId =
    "bar:group:" ++ (TaskbarShell.groups ready.windows |> List.head |> Maybe.map .key |> Maybe.withDefault "missing")

action surface publication lease control =
    E.object [("surface",E.string surface),("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),
        ("publication",E.string publication),("lease",E.string lease),("id",E.string control),
        ("trigger",E.string "pointer")]

picker =
    Surface.resolve (counter "1") UInt64.zero (action "bar" "1" "0" groupId) ready
        |> Maybe.map (\message -> Desktop.update message ready |> Tuple.first)
        |> Maybe.withDefault ready

closed =
    picker.windows.picker
        |> Maybe.map (\held -> Desktop.update (Desktop.Window (TaskbarShell.Close held.scope held.generation)) picker |> Tuple.first)
        |> Maybe.withDefault picker

reopened =
    Surface.resolve (counter "2") (counter "1") (action "bar" "2" "1" groupId) refreshed
        |> Maybe.map (\message -> Desktop.update message refreshed |> Tuple.first)
        |> Maybe.withDefault refreshed

-- Closing starts a real Shell.Refresh; the matching projection reply is a
-- synthetic fixture, not an observation from the native host.
refreshed =
    native (projection "2") closed

wire publication lease =
    "{\"surface\":\"popup\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\""
        ++ publication ++ "\",\"lease\":\"" ++ lease ++ "\",\"id\":\"control:close\",\"trigger\":\"pointer\"}"

accepted model raw expected =
    Presentation.dispatch True raw model
        |> Maybe.map (E.encode 0 >> (==) expected)
        |> Maybe.withDefault False

refused model raw =
    Presentation.dispatch True raw model == Nothing

-- Deterministic seeds produce different nonzero publication values. Each
-- expected result is an explicit semantic assertion, never reducer output.
sequence seed =
    let
        p = String.fromInt (seed * 5 + 1)
        pNext = String.fromInt (seed * 5 + 2)
        pClose = String.fromInt (seed * 5 + 3)
        pLease = String.fromInt (seed * 5 + 4)
        pRecovery = String.fromInt (seed * 5 + 5)
        firstFrame = Surface.packet (counter p) (counter "1") picker
        nextFrame = Surface.packet (counter pNext) (counter "1") picker
        -- A higher publication with an older lease must not replace a frame.
        regressingLeaseFrame = Surface.packet (counter pClose) UInt64.zero closed
        lowerLeaseWellFormed =
            case SurfaceSnapshot.decode regressingLeaseFrame of
                Ok _ -> True
                Err _ -> False
        closedFrame = Surface.packet (counter pClose) (counter "1") closed
        newLeaseFrame = Surface.packet (counter pLease) (counter "2") reopened
        recoveredFrame = Surface.packet (counter pRecovery) (counter "2") reopened
        a = action "popup" p "1" "control:close"
        b = action "popup" pNext "1" "control:close"
        closedPopup = action "popup" pClose "1" "control:close"
        closedBar = action "bar" pClose "1" "bar:settings"
        c = action "popup" pLease "2" "control:close"
        d = action "popup" pRecovery "2" "control:close"
        s1 = Presentation.accept firstFrame Presentation.initial
        s2 = Presentation.accept nextFrame s1
        s3 = Presentation.accept firstFrame s2
        s4 = Presentation.accept regressingLeaseFrame s3
        sClosed = Presentation.accept closedFrame s4
        s5 = Presentation.accept newLeaseFrame sClosed
        invalidated = Presentation.accept (E.object []) s5
        sameFrameAfterInvalid = Presentation.accept newLeaseFrame invalidated
        recovered = Presentation.accept recoveredFrame sameFrameAfterInvalid
        checks =
            [ ("picker_is_real", picker.windows.picker /= Nothing)
            , ("close_retires_picker", closed.windows.picker == Nothing)
            , ("close_waits_for_projection", not (Shell.available closed.windows.shell) && closed.windows.shell.expected == Just (counter "2"))
            , ("matching_projection_restores_readiness", Shell.available refreshed.windows.shell)
            , ("reopen_creates_picker", reopened.windows.picker /= Nothing)
            , ("first_frame_accepts_exact_action", accepted s1 a (wire p "1"))
            , ("first_action_resolves", Surface.resolve (counter p) (counter "1") a picker /= Nothing)
            , ("publication_advance_refuses_old", refused s2 a)
            , ("publication_advance_accepts_new", accepted s2 b (wire pNext "1"))
            , ("stale_frame_keeps_current_action", accepted s3 b (wire pNext "1") && refused s3 a)
            , ("lower_lease_frame_is_well_formed", lowerLeaseWellFormed)
            , ("lease_regression_keeps_current", accepted s4 b (wire pNext "1") && refused s4 a)
            , ("closed_frame_refuses_old_and_closed_popup", refused sClosed b && refused sClosed closedPopup && Surface.resolve (counter pClose) (counter "1") closedPopup closed == Nothing)
            , ("closed_frame_keeps_current_bar", Presentation.dispatch False closedBar sClosed |> Maybe.map (E.encode 0 >> (==) ("{\"surface\":\"bar\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\"" ++ pClose ++ "\",\"lease\":\"1\",\"id\":\"bar:settings\",\"trigger\":\"pointer\"}")) |> Maybe.withDefault False)
            , ("lease_advance_refuses_old", refused s5 b && refused s5 a && refused s5 closedPopup)
            , ("lease_advance_accepts_new", accepted s5 c (wire pLease "2"))
            , ("new_lease_action_resolves", Surface.resolve (counter pLease) (counter "2") c reopened /= Nothing)
            , ("malformed_frame_revokes_dispatch", refused invalidated c)
            , ("same_publication_cannot_restore_invalidated", refused sameFrameAfterInvalid c)
            , ("later_frame_recovers_exact_action", accepted recovered d (wire pRecovery "2"))
            , ("recovery_rejects_preinvalid_action", refused recovered c)
            ]
    in
    E.object [("seed",E.int seed),("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]

result =
    E.object [("scope",E.string "synthetic Elm current-frame admission; not native authentication"),
        ("sequences",E.list sequence (List.range 1 32))]

main : Program () () Never
main =
    Platform.worker { init = \_ -> ((),outgoing result), update = \message model -> never message, subscriptions = \_ -> Sub.none }
