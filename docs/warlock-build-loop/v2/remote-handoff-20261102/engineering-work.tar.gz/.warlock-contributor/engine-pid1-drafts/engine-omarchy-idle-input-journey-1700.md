# Omarchy Actual UI Evidence Review & Post-Idle-Fix Bounded Physical Input Journey (`1700`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Bus Run**: `warlock-20261031-setup` (`lead` sole coordinator)
- **Reviewed Evidence Directory**: `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-display-20261101T163508Z/`
- **Posture**: Preparation / controller & journey specification only. Zero production/model/tool edits, zero compiler/test/VM commands executed, zero Foot focus or synthetic clicks, `nativeOperations: []`, `providerCleanupQualified: false`, `15/242` whole requirements and `39/417` scenarios unchanged, historical failed and partial evidence preserved.

---

## 1. Review of Actual Omarchy UI Evidence (`engine-display-20261101T163508Z`)

### 1.1 Process Lineage, Window Geometry, and Clean Desktop Preservation
- **Same-ELF Broker + PID-1 Engine Lineage (`observations.json:21-80`, `backend.stdout:1`)**:
  - `warlock-ui-backend` (`PID 100509`, `device 58, inode 36473`, `namespacePids: [100509]`) spawned `warlock-ui-owner` broker (`PID 100516`, `selectedPid: 100516`, `device 58, inode 36472`, `namespacePids: [100516]`), which spawned `warlock-ui-owner --engine-only` (`PID 100517`, same `device 58, inode 36472`, `namespacePids: [100517, 1]`).
  - WebKitGTK 6 `bwrap` (`PIDs 100557, 100558, 100562, 100565, 100569, 100570, 100574, 100577, 100581...`), `xdg-dbus-proxy` (`PIDs 100559, 100571...`), and 3 `WebKitWebProcess` instances (`cView`, `bView`, `pView`) launched cleanly inside the 1-UID user namespace + PID-1 mount namespace.
- **Mapped Hyprland Client (`observations.json` indices `3..24`, `monotonic 61518.599..61523.727`)**:
  - Exactly one mapped client for `eligibleEnginePIDs: [100517]`:
    - `address`: `"0x55fad1594fe0"`, `class`: `"GTK Application"`, `pid`: `100517`, `workspace`: `1`, `floating`: `false`
    - `at`: `[647, 38]`, `size`: `[621, 750]`, `mapped`: `true`, `visible`: `true`, `acceptsInput`: `true`, `focusHistoryID`: `0` (automatically active upon dwindle map on Workspace `1` without any `hyprctl dispatch` command).
- **Visual Inspection of `live-00.png` (`61518.743`) and `live-01.png` (`61521.949`)**:
  - **`live-00.png`**: Captures initial surface realization (`~0.14s` after `obs[3]`) with the right-half tiled Warlock surface (`[647, 38] 621x750`, active blue border) beside `Foot 2095` (`[12, 38] 621x750`, inactive border) while the 3 WebKit processes finish initial HTML paint.
  - **`live-01.png`**: Captures settled Elm Night-theme rendering across `bView` (`HttpBar.html`) and `pView` (`HttpPopup.html`):
    - **Top Bar (`bView`, `y = 40..111`, `.surface-bar` at `y = 40..94`)**:
      - **`Applications` (`id = "bar:applications"`, enabled)**: Rendered with coral `#fca399` active contour (`SurfaceTheme.elm:701, 733`) at exact screen pixel bounding box **`x = 654..776, y = 41..90`** (center **`(715, 65)`**).
      - **`Task View` (`id = "bar:overview"`, disabled)**: Rendered with `#4d4446` dashed disabled border at **`x = 782..884, y = 41..90`** (center **`(833, 65)`**).
      - **`Switch windows` (`id = "bar:switcher"`, disabled)**: Rendered at **`x = 890..1030, y = 41..90`** (center **`(960, 65)`**).
      - **Status region (`[role="status"]`)**: Displays `"Applications connected. Window controls unavailable."` (`x = 1036..1265, y = 40..94`).
    - **Popup Body (`pView`, `y = 112..786`)**:
      - Because startup begins in `mode == "closed"` (`model.open == False`, `Surface.elm:75, 110`), `SurfaceRenderer.elm:145` renders `<h1>Choose a window</h1>` (`y = 120..149`) and `<p role="status">Applications connected. Window controls unavailable.</p>` (`y = 156..190`) with an empty `.surface-controls` grid below (`y >= 199`).
- **Why `callbacks: 3, operations: 1` Followed by `CredentialTransport TimedOut` at `7.445s` (`backend.stdout:1`, `trial-result.json:6`)**:
  1. **Callback 1 (`operations: 0 -> 1`)**: Initial Elm startup commit requests `CatalogRead` (`Backend.hs:152-153`); `Backend.hs:193-196` (`applicationAttachment == True`) also emits `D.applicationAttached` (`"Applications connected. Window controls unavailable."`) and `D.catalogReply` (populated from `/usr/share/applications`).
  2. **Callbacks 2 & 3 (`operations: 1`)**: Elm (`HttpMain`) processes `applicationAttached` and `catalogReply`, committing the settled `mode = "closed"` presentation (`callbacks = 3`) by `t ≈ 2.45s`.
  3. **5.0s Idle Expiry (`t ≈ 2.45s -> 7.445s`)**: `Aggregate.hs:80-92` immediately invoked `receiveCredentialIngress` for frame 4, which started the `5.0s` timer in `Channel.hs:122-136` before any header byte arrived. With no physical user input during `t = 2.45s..7.45s`, `CredentialTransport TimedOut` fired at `7.445s`, cleanly retiring the window (`obs[25]` at `61523.964` has `n_vis: 0`) and restoring `Foot 2095` to `[12, 38] 1256x750` (`preservation-after.json:3-48`, `finalScopeState: inactive/dead`, `forcedAtOriginalDeadline: false`).

---

## 2. Exact Layout & Source Mechanics Once `Applications` Is Clicked (`mode == "applications"`)

When a physical pointer click lands on `Applications` (`(715, 65)` in `bView`):
1. **Elm & Backend State Transition (`Desktop.elm:1236-1237, 1365-1381`, `Backend.hs:152-165`)**:
   - `Desktop.OpenApplications` sets `model.open = True` (`Surface.mode model == "applications"`) and emits `[catalogRequest binding request, Focus "launcher-search"]`.
   - `Backend.hs:152-165` executes a second `CatalogRead` (`operations` increments `1 -> 2`) and returns `D.catalogReply`.
   - `HttpMain` commits the `OpenApplications` frame and the post-`catalogReply` presentation frame (`callbacks` increments `3 -> 5`).
2. **Rendered Controls & Exact Screen Coordinates in `pView` (`Surface.elm:306-346`, `SurfaceTheme.elm:382-649, 1087-1108`)**:
   - Within the Warlock window (`at = [647, 38], size = [621, 750]`), `pView` occupies `x = 649..1266, y = 112..786` (`padding: 8px 10px`):
     - `y = 120..149`: `<h1>Applications</h1>` (`border-left: 3px solid #fca399`).
     - `y = 156..190`: `<p role="status">Type to search applications.</p>`.
     - `y = 199..`: `.surface-controls` (`display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 8px; padding: 4px`, inner `x = 663..1252`):
       1. **Row 1 (`grid-column: 1 / -1`, `y = 205..222`)**: `<label class="launcher-search-label" for="launcher-search">Search applications</label>`.
       2. **Row 2 (`grid-column: 1 / -1`, `x = 663..1252, y = 230..274`)**:
          - **`<input id="launcher-search" class="launcher-search" type="search" placeholder="Search applications">` (`id = "control:search"`, `enabled = True`)**.
          - Safe click target center: **`(820, 252)`** (`QMP abs: x = 20991, y = 10322`).
          - **Critical Multi-WebView Focus Detail (`Mvp.hsc:838-850`)**: Because `bView` (`HttpBar`) and `pView` (`HttpPopup`) are two separate `WebKitWebView` widgets inside `GtkBox`, clicking `Applications` in `bView` leaves GTK4 widget focus on `bView` even though `HttpPopup.elm:57` runs `Browser.Dom.focus "launcher-search"` inside `pView`'s DOM. **A physical pointer click at `(820, 252)` inside `pView` is mandatory before typing** so GTK4 widget focus and Wayland seat keyboard routing move from `bView` to `pView`'s `<input id="launcher-search">` without synthetic focus calls.
       3. **Row 3 (`grid-column: span 3` + `span 3`, `y = 284..328`, `Surface.elm:344-345`, `SurfaceTheme.elm:630-631`)**:
          - Left half (**`x = 663..953, y = 284..328`**): **`Windows` (`id = "control:close"`, `enabled = True`)**, center **`(808, 306)`** (`QMP abs: x = 20684, y = 12533`).
          - Right half (**`x = 961..1252, y = 284..328`**): **`Refresh` (`id = "control:refresh"`, `enabled = True`)**, center **`(1106, 306)`** (`QMP abs: x = 28313, y = 12533`). Clicking `Refresh` dispatches `Desktop.RefreshApplications` -> `CatalogRead` (`operations + 1`, `callbacks + 2`).
       4. **Below Row 3 (`y >= 336`)**:
          - Paging controls (`control:page-range`, `control:page-previous`, `control:page-next` when `bodyCount > 8`, `Desktop.elm:1389`), `jump:open:<first>` (`enabled = False` in `applicationOnly` mode, `Surface.elm:324`), **`pin:<first>` (`enabled = True`, `Surface.elm:317` -> `D.PinsWrite`)**, and catalog `entry:<id>` rows (`enabled = False` in `applicationOnly` mode, `Surface.elm:310`, preventing accidental foreign app launches during app-only trials).
3. **Physical `Escape` Key Routing (`Mvp.hsc:819-830, 1070-1141`)**:
   - Pressing physical `Escape` (`gdkKeyEscape`) while the Warlock window has Wayland seat focus is captured by `GtkEventControllerKey` (`GTK_PHASE_CAPTURE`) on `mvpGtkWindow`, setting `mvpEscapeRef = True`.
   - On the next `25ms` tick, `stepMvpWindow` observes `leasePopupOpen lease == True` and emits `OwnerEscape (encodeEscape scopeId gen publication leaseToken)`, causing Elm to close `Applications` (`mode` returns to `"closed"`, `<h1>Choose a window</h1>`) and commit the updated presentation (`callbacks + 1`) while keeping the window alive until `D - 1.0s`.

---

## 3. Bounded Physical Input Journey & Minimal Controller Specification (Post-Idle-Fix, Original `28s` `D`)

### 3.1 Architecture: Two-Process Split or Host-Driven QMP with Guest Observation File
- **Why QMP `input-send-event` / `qmp.py` (`drive-live-02.py:26-32`, `vm-live-driver.py:125-163`) is required**:
  - Guest user processes cannot inject hardware pointer/key events without root `/dev/uinput` or compositor IPC; host QMP `input-send-event` (`abs` `x = round(px * 32767 / 1280)`, `y = round(py * 32767 / 800)`, `btn` `left` down/up) and `qmp.py keys` deliver real kernel `libinput` -> Hyprland Wayland seat events with `nativeOperations: []` and zero synthetic DOM events.
- **Minimal Coordination with Existing Guest Controller (`live-controller-display-01.py`)**:
  - Keep `live-controller-display-01.py`'s exact `systemd-run --user --scope` launch, `28s` `deadlineMonotonicNs` (`D`), `0.2s` observation loop writing `RUN/'live-current.json'`, and `finally` cleanup.
  - Add only two read-only fields to each `row` in `live-controller-display-01.py:69`:
    1. `activeWindow`: output of `command(['hyprctl', 'activewindow', '-j'])` (so the host QMP driver or guest gate can verify `activeWindow.pid == eligible_pid` and `activeWindow.address == visible[0].address` from `live-current.json`).
    2. `monitors`: output of `command(['hyprctl', 'monitors', '-j'])` (verifying single `1280x800` scale-`1` active monitor).
  - Dismiss transient Quickshell notifications once before launch (`command(['omarchy-shell', 'notifications', 'dismissAll'])` after `L56` lock check) so no popup toast can intercept pointer clicks in the top-right region (`x = 900..1268, y = 38..120`).
  - At `L74-76` (right at `time.monotonic() >= deadline`), record `exitedByOriginalDeadline = (p.poll() is not None)` before any `SIGKILL`, and allow a bounded `0.8s` post-`D` reap poll (`exitedByOriginalDeadline: false` if post-`D`) so `D - 1.0s` retirement (`EngineEntrypoint.hs:323-325`) is never truncated mid-flush of `backend.stdout`.

### 3.2 Fail-Closed Pre-Input Gate (Must Pass Before Every QMP Pointer or Key Event)
Before **every** QMP pointer move, button press, or key press, verify from fresh guest state (`live-current.json` + `/proc` + `omarchy-shell lock isLocked`):
1. **Session & Deadline**: `isLocked == "false"`, `pgrep -x hyprlock` absent, `p.poll() is None`, and `remaining >= 6.0` seconds before original `28s` `D`.
2. **Unique Same-ELF PID-1 Engine Identity**: `eligibleEnginePIDs == [engine_pid]` (`len == 1`), `processes` entry for `engine_pid` has unchanged `(pid, birth, device, inode)` and `namespacePids[-1] == 1`.
3. **Unique Mapped Active Warlock Window**: `len(visible) == 1`, `w = visible[0]` has `w['pid'] == engine_pid`, `w['mapped'] is True`, `w['visible'] is True`, `w['floating'] is False`, `w['workspace']['id'] == 1`, `w['at'] == [647, 38]`, `w['size'] == [621, 750]`, AND `activeWindow['pid'] == engine_pid` with `activeWindow['address'] == w['address']`.
4. **Foot Isolation Guard**: `Foot` (`pid == 2095`, `birth == "6930"`, `address == "0x55fad233fd80"`) is at `at == [12, 38]`, `size == [621, 750]`, is **not** `activeWindow`, and target coordinates `(x, y)` satisfy `654 <= x <= 1252` and `41 <= y <= 780` (strictly inside `w` and `>= 21px` right of `Foot`'s right edge `x = 633`).

### 3.3 Timed Step-by-Step Journey Under Original `28s` `D`

| Phase | Elapsed Window (`t` from launch) | Action (Host QMP -> Guest Wayland Seat) | Screen Pixel `(x, y)` & QMP `abs` `(X, Y)` | Expected Elm / Backend / Visual Outcome | Screenshot Artifact |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **P0: Map & Initial Settle** | `0.0s .. 2.5s` | None (engine maps at `t ≈ 0.65s`; initial `CatalogRead` + `applicationAttached` + 3 commits settle by `t ≈ 2.45s`). | — | `visible[0]` at `[647, 38] 621x750`, `focusHistoryID: 0`; `callbacks == 3`, `operations == 1`. | `live-00-initial.png` (`t ≈ 1.5s`) |
| **P1: Real Quiescent Idle `> 5s`** | `2.5s .. 8.8s` (`> 6.3s` continuous silence after callback 3) | **Zero input, zero heartbeat.** Wait until `t >= 8.8s` (past the `7.445s` point where `163508Z` died with `TimedOut`). | — | Pre-Input Gate at `t = 8.8s` proves `p.poll() is None`, `visible[0]` still mapped & active after `> 6.3s` quiet period. | `live-01-post-idle.png` (`t ≈ 8.8s`) |
| **P2: Disabled Control Click** | `9.0s .. 9.6s` | Gate -> QMP `abs` move + left click (`75ms`) on disabled **`Task View`** (`bar:overview`). | `(833, 65)` -> QMP `(21324, 2662)` (`bbox [782..884, 41..90]`) | Ignored (`disabled = True`); `pView` stays `"Choose a window"`, `callbacks == 3`, `operations == 1`. | — |
| **P3: Open `Applications`** | `9.8s .. 11.2s` | Gate -> QMP `abs` move + left click (`75ms`) on enabled **`Applications`** (`bar:applications`). Wait `0.9s` for `CatalogRead` + render. | `(715, 65)` -> QMP `(18303, 2662)` (`bbox [654..776, 41..90]`) | `Desktop.OpenApplications` -> `CatalogRead` (`operations: 1 -> 2`, `callbacks: 3 -> 5`). `pView` renders `<h1>Applications</h1>`, `<input id="launcher-search">`, `Windows`, `Refresh`, `Pin <App>`, and catalog list. | `live-02-applications.png` (`t ≈ 11.0s`) |
| **P4: Focus Search & Type `"foot"`** | `11.4s .. 13.4s` | Gate -> QMP `abs` move + left click (`75ms`) on `<input id="launcher-search">` inside `pView` (transfers GTK4 widget focus from `bView` to `pView`), then Gate + QMP `keys` `f`, `o`, `o`, `t` (`120ms` apart). Wait `0.6s`. | `(820, 252)` -> QMP `(20991, 10322)` (`bbox [663..1252, 230..274]`) | `surface-query` -> `Desktop.SearchQuery "foot"` (`callbacks` increases by `+1..+4` to `6..9`; `operations == 2`). Search input displays `"foot"` and filters catalog entries. | `live-03-search-foot.png` (`t ≈ 13.2s`) |
| **P5: Click `Refresh` in Popup** | `13.6s .. 15.0s` | Gate -> QMP `abs` move + left click (`75ms`) on **`Refresh`** (`control:refresh`, Row 3 right half). Wait `0.9s`. | `(1106, 306)` -> QMP `(28313, 12533)` (`bbox [961..1252, 284..328]`) | `Desktop.RefreshApplications` -> `CatalogRead` (`operations: 2 -> 3`, `callbacks` increases by `+2`). | — |
| **P6: Physical `Escape` Dismiss** | `15.2s .. 16.4s` | Gate -> QMP `keys esc` (`gdkKeyEscape`). Wait `0.6s`. | Keyboard on active `w` (`pid == engine_pid`) | `Mvp.hsc:825, 1124` `OwnerEscape` -> Elm closes `Applications` (`mode` -> `"closed"`, `<h1>Choose a window</h1>`, `callbacks + 1`). Window stays mapped. | `live-04-escape-closed.png` (`t ≈ 16.2s`) |
| **P7: Second Idle `> 5s` & Clean `D - 1.0s` Exit** | `16.4s .. 27.5s` (`~10.6s` quiet -> `localStop` at `27.0s`) | **Zero input.** Engine initiates `localStop` at `D - 1.0s` (`27.0s`), destroys `MvpWindow`, and exits before `D = 28.0s`. | — | `exit == 0`, `forcedAtOriginalDeadline == False`, `backend.stdout`: `passed: true, cleanup: true, callbacks >= 9, operations: 3, auth: "Nothing"`. `Foot 2095` (`birth 6930`) restored to `[12, 38] 1256x750`, `unitMembers: []`. | — |

### 3.4 Exact Failure Conditions (Fail-Closed Oracles)
The bounded trial fails closed (`passed: false`) if any of the following occurs:
1. `p.poll() is not None` or `visible == []` at `t = 8.8s` (proving `> 5s` quiescent idle still aborts the session).
2. Any Pre-Input Gate check fails before any QMP event (session locked, `Foot 2095` focused or moved into `x >= 640`, `engine_pid` or `birth` changed, or `remaining < 6.0s`).
3. `live-02-applications.png` does not show `<h1>Applications</h1>` and `<input id="launcher-search">`, `live-03-search-foot.png` does not show `"foot"` in the search box, or `live-04-escape-closed.png` does not return to `<h1>Choose a window</h1>`.
4. `backend.stdout` reports `passed != true`, `cleanup != true`, `auth != "Nothing"`, `operations < 3` (must observe initial `CatalogRead` + `OpenApplications` `CatalogRead` + `Refresh` `CatalogRead`), or `callbacks < 8`.
5. `forcedAtOriginalDeadline == true`, `unitMembers != []` after retirement, `Foot 2095` (`birth 6930`) is altered, or `nativeOperations != []`.
