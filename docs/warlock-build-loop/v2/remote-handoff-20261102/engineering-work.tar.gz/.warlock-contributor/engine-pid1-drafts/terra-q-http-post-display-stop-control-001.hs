{-# LANGUAGE OverloadedStrings #-}
-- QA ONLY, isolated actor016/lexical013 source + post-display probe overlay.
-- Root strongly roots each Case in this same process before runCase and uses
-- existing external guardian/original D. One process/Case, no global reset,
-- no worker kill, no fake display result or native/cleanup qualification.
module QHttpPostDisplayStopControl (Mode(..),Case,newCase,runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef (IORef,newIORef,writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
  persistentBackendCounts,persistentBackendStartupRefusal,qaRootStatCount,qaSetAfterDisplayHook)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = RootEntryPositive | StopAfterDisplay deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
  (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId))
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current budget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing

-- Caller supplies actual valid owned config/display and same original StartD;
-- an external guarded launcher bounds any read or wait without timer reset.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase (Case owner start displayDone release completed workerSlot) mode path = mask $ \restore -> do
  exists <- doesPathExist path
  check "actual owned config exists" (isAbsolute path && exists)
  before <- qaRootStatCount
  check "isolated root-stat probe unused" (before==0)
  configured <- restore (loadPersistentBackendConfig owner path)
  check "same-owner config succeeded" (configured==Right ())
  case mode of StopAfterDisplay -> qaSetAfterDisplayHook (putMVar displayDone () >> takeMVar release); _ -> pure ()
  thread <- forkIOWithUnmask $ \unmask -> do
    result <- try (unmask (takeMVar start >> runPersistentBackend owner))
    putMVar completed result
  writeIORef workerSlot (Just thread)
  putMVar start ()
  restore $ do
    case mode of
      StopAfterDisplay -> readMVar displayDone
      RootEntryPositive -> let waitForStat = do
                                  count <- qaRootStatCount
                                  if count>0 then pure () else do
                                    result <- tryReadMVar completed
                                    case result of
                                      Just _ -> ioError (userError "live run ended before real root-stat probe")
                                      Nothing -> threadDelay 1000 >> waitForStat
                           in waitForStat
    initialCount <- qaRootStatCount
    case mode of
      StopAfterDisplay -> check "display completed before any root stat" (initialCount==0)
      RootEntryPositive -> check "unstopped real run reaches root-stat entry" (initialCount==1)
    stop <- requestPersistentBackendStop owner
    case mode of
      StopAfterDisplay -> check "actual stop latched during held prelive prep" (stop==P.StopLatchedBeforeLive)
      RootEntryPositive -> check "same owner accepted stop" (stop==P.StopLatchedBeforeLive || stop==P.StopSignalSent)
    case mode of StopAfterDisplay -> putMVar release (); _ -> pure ()
    outcome <- readMVar completed
    case outcome of
      Left problem -> throwIO problem
      Right result -> case mode of
        StopAfterDisplay -> do
          after <- qaRootStatCount
          check "stop between stages prevents later root stat and yields Unknown"
            (after==0 && persistentBackendStartupRefusal result==Just P.StartupAdmissionUnknown
              && persistentBackendCounts result==(0,0))
        RootEntryPositive -> pure () -- positive proves probe reachability only
