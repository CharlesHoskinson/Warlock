# TEA initial-detached surface packet: independent literal leaf

Source-only, no runs. This is the `Surface.packet` **leaf**, not a complete policy model, `Publish` effect, or a test pass. Its caller must independently determine the exact publication, lease, and final `Desktop.presentation` counters from the actual owning-route trace. For the given path use the literal below only if the final complete Desktop retains all of these source-checked premises: shell remains `Detached`, binding `Nothing`, `reconnecting=True`, shell notice `Connecting…`, no observations, pending transactions, pins, groups, menus, open surfaces, notification snapshots, choice notice or workspace recovery; settings snapshot Nothing, initial preferences and popup origin KeyboardEntry. Desktop presentation must be `Just (Counter p)`. `publication`, `lease`, and `p` below are substitution variables for canonical decimal **strings**, not JSON fields or arbitrary test tokens.

```json
{
  "surfaceProtocol": 2,
  "keyboardParent": true,
  "motion": "reduced",
  "appearance": {"theme":"night","textScale":100,"effectsOff":false,"reducedTransparency":false},
  "publication": "<publication>",
  "lease": "<lease>",
  "mode": "closed",
  "status": "Connecting…",
  "bar": [
    {"id":"bar:reconnect","domId":"reconnect","label":"Reconnect","ariaLabel":"Reconnect to the window system","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:overview","domId":"applications:detached:<p>:control:overview-opener","label":"Task View","ariaLabel":"Open Task View","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:switcher","domId":"applications:detached:<p>:control:switcher-opener","label":"Switch windows","ariaLabel":"Open window switcher","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:notifications","domId":"applications:detached:<p>:notifications:opener","label":"Notifications","ariaLabel":"Open notifications","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:files","domId":"applications:detached:<p>:files:opener","label":"Files","ariaLabel":"Open Files menu","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:system","domId":"applications:detached:<p>:system:opener","label":"System","ariaLabel":"Open system menu","detail":"","enabled":false,"focusOnly":false},
    {"id":"bar:settings","domId":"applications:detached:<p>:settings:opener","label":"Settings","ariaLabel":"Open settings","detail":"","enabled":false,"focusOnly":false}
  ],
  "popup": []
}
```

This literal follows `Surface.packet`/`barControls` (no `checked` field without a menu), `Desktop.key`, `Motion.desired/name`, and `Settings.defaults/encodeValues`; initial Files and JumpList notices do not have the special failure prefixes that append a notice. Initial shell `reconnecting=True` makes reconnect disabled. Exact `DomId` counters must come from the complete independently derived model, not from observed reducer output. The view-topology path with empty revision-1 views calls `RegistrationAvailable False` and `SupersedeObservations False` via Desktop; in detached state `windowBase` calls `advance` and `Launch.disconnect` even where the underlying Shell update is a no-op. Do not assume the final leaf equals `Surface.packet 0 0 Desktop.initial`.

The outer exact commit also needs independently derived `OutputController.frame`, final revision/selection/announcements and every emitted typed effect. No authority is inferred from this fixture; no reducer changes, native run, or test execution was performed.
