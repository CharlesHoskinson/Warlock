'use strict';

// Independent source transcription for a single named GIVEN, never a view
// implementation or reducer capture. Preconditions: current Settings popup;
// schema-2 settings snapshot Night/100, draft Dawn/100, save request pending;
// settingsExpected absent, settingsHelp true; motionExpected and
// shortcutExpected present, both corresponding snapshots/inventory absent;
// initial motion/shortcut draft and notices; a successful Desktop.capture;
// notificationsOpen/overview false, no active menu or checked-item collision,
// and no capacity or workspace block.
// The caller must independently construct and compare the complete Model and
// complete Policy.Effect; this is only the literal popup portion of a packet.
// Root must qualify this prediction against the exact source/compiler tuple.
function pendingSettingsPopup(host, presentation) {
  if (host !== '{"lifetime":"1","session":"1","frontend":"1"}' ||
      !['9', '10'].includes(presentation)) {
    throw new Error('unsupported literal settings fixture identity');
  }
  const prefix = 'applications:' + host + ':' + presentation + ':';
  const row = (id, label, detail, enabled) => ({
    id, domId: prefix + (id === 'control:close' ? 'settings:close' : id),
    label, ariaLabel: label, detail, enabled, focusOnly: false,
  });
  const rows = [
    row('control:close', 'Close settings', '', true),
    row('settings:help', 'Dismiss help', 'Expanded', true),
    row('settings:help:text:keyboard', 'Keyboard navigation', 'Tab and Shift+Tab move focus. Arrows move through lists; Home/End reach endpoints. Enter chooses; Escape closes.', false),
    row('settings:help:text:preferences', 'Keeping your preferences', 'Save applies appearance preferences. Motion has its own Save. Dismissing help keeps unsaved edits.', false),
    row('settings:help:text:recovery', 'When an action is not confirmed', 'Pending is waiting; Refused did not proceed; Unknown is unconfirmed. Refresh reads state without repeating an action.', false),
    row('settings:effects-off', 'Disable soft effects', 'Off', false),
    row('settings:reduced-transparency', 'Reduce transparency', 'Off', false),
    row('settings:motion', 'Reading motion preference…', 'Reading motion preference…', false),
    row('settings:motion:system', 'Follow system', 'Selected', false),
    row('settings:motion:reduced', 'Reduced motion', '', false),
    row('settings:motion:full', 'Full motion', '', false),
    row('settings:motion:save', 'Save motion preference', 'Apply and keep across restart', false),
    row('settings:motion:refresh', 'Refresh motion preference', 'Read stored preference; no write is repeated', false),
    row('settings:theme:night', 'Night theme', '', false),
    row('settings:theme:dawn', 'Dawn theme', 'Selected', false),
    row('settings:theme:high-contrast', 'High contrast theme', '', false),
    row('settings:scale:100', 'Text size 100%', 'Selected', false),
    row('settings:scale:125', 'Text size 125%', '', false),
    row('settings:scale:150', 'Text size 150%', '', false),
    row('settings:scale:200', 'Text size 200%', '', false),
    row('settings:save', 'Save settings', 'Apply and keep across restart', false),
    row('settings:refresh', 'Refresh settings', 'Read stored values; discard unsaved changes', true),
    row('settings:shortcuts:notice:state', 'Loading shortcut choices…', '', false),
  ];
  for (const [route, label] of [
    ['applications', 'Apps menu'], ['system', 'System menu'], ['notifications', 'Notification history'],
  ]) {
    const id = 'settings:shortcuts:' + route + ':';
    rows.push(
      row(id + 'state', label + ': live bindings unavailable', '', false),
      row(id + 'keep', 'Keep existing shortcut for ' + label, '', false),
      row(id + 'default', 'Use ' + label + ' default', '', false),
      row(id + 'default:state', 'Default unavailable', '', false),
      row(id + 'alternate', 'Use ' + label + ' alternative', '', false),
      row(id + 'alternate:state', 'Alternative unavailable', '', false),
    );
  }
  rows.push(
    row('settings:shortcuts:save', 'Save shortcut choices', 'Apply only the free chosen chords; preserve existing bindings', false),
    row('settings:shortcuts:refresh', 'Refresh shortcut choices', 'Read stored choices and live bindings without repeating an action', false),
  );
  return rows;
}

module.exports = pendingSettingsPopup;
