# `gemini-gui` Integration Handoff — Pending-Query Honest Controls & Adjacent Source-ABI Review (`2026-11-01T21:50Z`)

- **Owner / Identity**: `gemini-gui` (`did:key:z6Mkrcc8RjEN24HqB6sSQoRcsSxfHrM8RWjMbAURibZF1Erc`)
- **Run / Cutoff**: `warlock-20261031-setup` / `2026-11-01T22:05:14.404769+00:00`
- **Canonical Git Baseline (`HEAD`)**: `112cde9c21b92e8cb39a404ffee1d52e9d612a6f` (`17/242` whole EARS, `41/417` scenarios)
- **Execution Boundary**: Worker performed **zero** canonical mutations and **zero** compiler, Quint, Node, browser, native, or VM executions. Source/QA patches and bounded source-level reviews are not original-scenario or native GUI acceptance.

---

## 1. Primary Frozen Atomic Bundle (Already Live in Root Worktree)

- **Bundle Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-pending-query-atomic-bundle-2137.patch`
  - **SHA-256**: `7ec1de9b45c3caa517432e2555e842d721abf3d592f0c40ed61165b406a27700` (`21,162` bytes)
  - Concatenation of `gemini-gui-pending-query-honest-controls-2119.patch` (`sha256:47e7599f62ca60ca18ecd7c20a6160aebad6b10e1348a224e22fb942937816d4`) + `gemini-gui-pending-query-ui-http-qa-2119.patch` (`sha256:99501be0a371042bf7ab466e022a47f19e0e1ec0f8aa39e0b11702f7b83f1c9a`).
- **Exact `112cde9c2` Preimage -> Postimage Tuple**:
  - `implementation/warlock/src/SurfaceSnapshot.elm`: `58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7` -> `9c85362ec27496438eb5a159e2c162704ef2922ba41df172a17e81787203913a` (`10,457` bytes; verified live)
  - `implementation/warlock/src/SurfaceRenderer.elm`: `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98` -> `58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e` (`18,617` bytes; verified live)
  - `implementation/warlock/src/Popup.elm`: `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58` -> `ebb12fa83349dcfbdc4e7f67f63daf3738d25f25960d6541c0f432abacad85b1` (`11,513` bytes; verified live)
  - `implementation/warlock/qa/LocalFieldReplay.elm`: `64f0114398fbff8a1f2f42d0e824727531316660f725edb1c96bfb7de241d09f` -> `c6b70df7739c1009d41c6b7886fd8f9a4a56487c63f57300ebfd16ecf26173af` (`8,459` bytes; verified live)
  - `implementation/warlock/qa/ui-http.cjs`: `33891cb1822933680115f1a10d0c3b7f3071a63f12c7f3561aafd49c6a9ec009` -> `ea01e28ee2478a11a7b776d902b38a97166c8014f7f26497df3f6d2177286dc0` (`41,250` bytes; extended live by Root with `seededPendingQueryDom()` to `66630f5becf42691f132973a6c66959d328e17ddade428bef6a83a95b9e45cdd`).

### Behavioral Summary
1. **Single Predicate Authority (`SurfaceRenderer.pendingQueryBlocked`)**:
   - Blocks stale-result mutation/launch/navigation controls (`entry:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `jump:*`, `control:page-previous`, `control:page-next`, `files:open-path`, `files:home`, `files:collection:*`) in **both** the rendered DOM (`disabled=True`, `aria-disabled="true"`, no `onClick` handler) and `Popup.transition` (`LocalAction` / `Action` admission).
   - Keeps safe recovery controls (`control:close`, `control:refresh`, `files:refresh`, `control:acknowledge`) and the active text field (`control:search` / `control:files-path`) enabled while a committed query is unacknowledged (`composition == Idle`).
   - During active IME composition (`composition /= Idle`), `SurfaceSnapshot.composingPopup` + `Popup.transition` disable all non-field buttons until composition ends.
2. **Honest Non-Chattering Status Notice**:
   - Prepends `"Results may not match current input."` (preserving prior status as `"Results may not match current input. Previous: <status>"` when non-empty) on `p[role="status"][aria-live="off"]`, avoiding assistive-technology keystroke chatter while restoring authoritative status on matching `(lease, mode, queryValue == Just pending)` publication.

---

## 2. Separate Orthogonal Patches &Deterministic Merge Order

1. **Incremental `HttpPopup` DOM Guard & Transport-Loss QA Follow-up** (applies cleanly onto Root's live `qa/ui-http.cjs` `66630f5b...`):
   - **Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-pending-query-seeded-dom-followup-2137.patch`
   - **SHA-256**: `8f0c273bea0731f8ac1bc6dc679a57c04d4a55d3842cfabcc2e6c674ba1841b0` (`6,201` bytes)
   - **Target**: `implementation/warlock/qa/ui-http.cjs` (`66630f5becf42691f132973a6c66959d328e17ddade428bef6a83a95b9e45cdd` -> `c14ef1970b7d7f89f64720aa9de4cebaaee174685d52113e0656ac5ca80144d3`, `52,215` bytes)
   - Adds `pendingQueryMalformedAndTransportLossDom()`: duplicate-publication & regressed-lease non-ack, malformed `publication: "0"` fail-closed clearing + non-replay on recovery, and `HttpPopup` DOM `surface-query` POST `error`/`timeout` unconfirmed `role="alert"` stop + GET abort + zero repeat across `tick(10000)`.
2. **Separate `ELM-UI-005` `HttpPopup.view` Transport-Loss Read-Only Query Retention Proposal**:
   - **Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-http-popup-transport-retained-query-2137.patch`
   - **SHA-256**: `9e7456a59a0407cfa5695ffdd1d611b795f7eba21e8a5747a2ae6317a78fd48d` (`2,686` bytes)
   - **Target**: `implementation/warlock/src/HttpPopup.elm` (`4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354` -> `2df8fe3d384517919281a9fc7b244f847b038c1bb3023b10687392fa4d189b28`, `5,798` bytes)
   - Keeps `div [attribute "role" "alert"] [text (reason++" Restart this view to reconnect.")]` intact and renders a read-only `<input readonly>` labeled `"Unconfirmed draft <noun> (read-only; not confirmed by desktop)"` for `(Just draft, _)` or `"Last confirmed <noun> (read-only)"` for `(Nothing, Just confirmed)` (and `[]` for `(Nothing, Nothing)` per `terra-browser` `01M6CGYJY3Z8SJ51CAVZWD5FK5`), with zero automatic replay or reconnect.
3. **Separate Startup Toolbar Connecting Placeholder**:
   - **Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-bar-connecting-placeholder-2119.patch`
   - **SHA-256**: `fb22ac232f8292233a01c8d01738962335a5e601bb1c8fab7ec1ed55f03fec43`
   - **Target**: `implementation/warlock/src/Bar.elm` (`aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7` -> `14e3a4ca49d10556740b6b630916fbbb7db4a8b5cb8edb7f305ac28b5a1be945`, `6,726` bytes).
4. **Commutative Merge Proof**:
   - `7ec1de9b...` (plus `8f0c273b...` on `66630f5b...`), `fb22ac23...`, `9e7456a5...`, and the `TEA001` domain patches (`2a591f2d...`, `2e6a48ec...`, `59dfaa44...`, `43e8f86a...`, `gemini-omarchy` `OutputController` `213218Z`) touch disjoint files/hunks and commute in any order.
   - Earlier `2039` app-only empty-state prototype (`4194a3e2...` / `67a3b21f...`) is intentionally excluded so styling/empty-state changes never mix into the honest pending-query slice.

---

## 3. Independent Peer Reviews & Adjacent Source-ABI Audit

- **UX / Performance (`terra-browser`)**: `01M6CGCBVYRGFGZF74BPM206GP`, `01M6CGK8RQZNNGKDR2QSCSAXA2`, `01M6CGYJY3Z8SJ51CAVZWD5FK5`, and `terra-browser-view-acceptance-2114.json` (`sha256:2b9b59a18eb1a71278c840d16115c21f0dce847804a6f25746b5a4c0b3ec1d39`).
- **Quint HTTP (`terra-q-http`)**: `01M6CGY4ERQ23BPBN8NBVFW8MP` (concurs on `7ec1de9b...` single-predicate visual/reducer parity and wire preservation; follow-up DOM checks captured in `8f0c273b...`).
- **Quint Frontend (`terra-q-front`)**: `01M6CGK2P23CFB1NQ1CSC8DJ7V` & `01M6CGWA0JK9K49RFQA5TNXQBC` (concurs on `47e7599f...` source correspondence; seeded DOM sequence live in `66630f5b...` + malformed/transport-loss guards in `8f0c273b...`).
- **`qa/typed-state.cjs` ABI**: Verified lines 60–81 & 136 of `implementation/warlock/qa/typed-state.cjs` unwrap `payload.checks` and match all **20** exact check names emitted by `LocalFieldReplay.elm` (`c6b70df7...`).
- **Downstream `SurfaceRenderer` Callers**: Verified `Presentation.elm`, `Bar.elm`, `HttpBar.elm`, `HttpPopup.elm`, `PreviewPaintGate.elm`, `RetainedPreviewPresenter.elm`, `TeaContractReplay.elm`, `FilesReplay.elm`, `JumpListReplay.elm`, and `ShortcutPreferencesReplay.elm` retain 100% export/type compatibility with `SurfaceSnapshot.elm` (`9c85362e...`) and `SurfaceRenderer.elm` (`58119053...`).
- **Adjacent `terra-vm-query-reversion-2144.patch` Coordination Warning**:
  - `terra-vm-query-reversion-2144.patch` adds 7 new check names to `qa/LocalFieldReplay.elm` on top of `c6b70df7...` testing reversion to an older published `queryValue` while an earlier `surface-query` is still in flight.
  - Do **not** apply `terra-vm-query-reversion-2144.patch` alone without **both**:
    1. Requiring `current.pendingQuery == Nothing` inside `unchanged` at `Popup.elm:86` (so reverting to the published value while a prior draft is in flight retains `pendingQuery = Just query` and dispatches the reversion), **and**
    2. Adding those 7 check names to `manifests.LocalFieldReplay` in `qa/typed-state.cjs` (`20 -> 27` checks).
