{-# LANGUAGE OverloadedStrings #-}
-- Unexecuted QA source. Root builds the owned peer and runs these two fresh
-- owners under its external guardian. No native actions or ACKs are involved.
module Main (main) where

import Control.Exception (finally, mask)
import Control.Monad (unless)
import Data.IORef
import Foreign.StablePtr (newStablePtr)
import GHC.Clock (getMonotonicTimeNSec)
import qualified Data.Text as T
import System.Directory (doesFileExist, removeFile)
import System.Environment (getArgs)
import System.IO (Handle, IOMode(ReadWriteMode), hIsClosed)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import qualified Network.Socket as S
import Warlock.Capture.Process (SessionObservation(..), ToolError(..))
import Warlock.Capture.Process.Bootstrap (deadlineAfter, deadlineFromAbsoluteNs, deadlineAbsoluteNs)
import Warlock.Capture.Process.Persistent
  ( LiveFrameAdmission, LiveOperationFailure(..), PersistentOwner, SessionExit(..), beginLiveFrameRequestBatch
  , defaultPersistentActionBudget, enterLiveBatchRequest, newPersistentOwner
  , startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)
import Warlock.Protocol.Codec (checkedDesktopCommit)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import qualified Warlock.Protocol.CredentialIngress as P
import qualified Warlock.Protocol.Desktop as D
import Warlock.Protocol.Identity (renderCounter)
import Warlock.Protocol.Ingress (Direction(..), OfferResult(..), ActivationResult(..),
  EndpointState(..), OwnerStatus(..), Reason(..), ingressBinding)
import qualified Warlock.Protocol.PeerCredential as Peer

data Refusal = MissingOwner | ForeignPeer deriving (Eq, Show)
type Context = (LiveFrameAdmission, P.FrameDeadline)
data Owned = Owned PersistentOwner (IORef (Maybe (P.CredentialIngressT Context)))
  (IORef (Maybe (S.Socket,S.Socket))) (IORef (Maybe Handle)) FilePath

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

main :: IO ()
main = do
 args <- getArgs
 (child,positiveMarker,negativeMarker) <- case args of
  [exe,p,n] | all (\v -> not (null v) && head v == '/') [exe,p,n] && p /= n -> pure (exe,p,n)
  _ -> ioError (userError "expected pinned child and two distinct absolute caller-owned markers")
 run child positiveMarker 16
 run child negativeMarker 17

run :: FilePath -> FilePath -> Int -> IO ()
run child marker count = mask $ \restore -> do
 owner <- newPersistentOwner
 ingressCell <- newIORef Nothing
 socketsCell <- newIORef Nothing
 handleCell <- newIORef Nothing
 observed <- newIORef Nothing
 callbacks <- newIORef (0 :: Int)
 effects <- newIORef ([] :: [T.Text])
 frameDs <- newIORef ([] :: [Integer])
 actionDs <- newIORef ([] :: [String])
 _ <- newStablePtr (Owned owner ingressCell socketsCell handleCell marker,
                    observed,callbacks,effects,frameDs,actionDs)
 exists <- doesFileExist marker
 check "caller-owned marker exists" exists
 bound <- must (ingressBinding "1" "2" "3")
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 stopBudget <- must (stopBudgetMicros 2000000)
 let verifyCredential credential = do
      current <- readIORef observed
      pure $ case current of
       Nothing -> Left MissingOwner
       Just obs | Peer.credentialPid credential == toInteger (observedPid obs)
               && Peer.credentialUid credential == uid && Peer.credentialGid credential == gid -> Right ()
       _ -> Left ForeignPeer
     guardFor _ frame = CredentialGuard
      (\credential -> modifyIORef' frameDs (P.frameDeadlineNs frame :) >> verifyCredential credential)
      (\credential action -> do
       modifyIORef' frameDs (P.frameDeadlineNs frame :)
       allowed <- verifyCredential credential
       case allowed of Left refusal -> pure (Left refusal); Right () -> Right <$> action)
     callback (admission,frame) checked = do
      modifyIORef' callbacks (+1)
      modifyIORef' frameDs (P.frameDeadlineNs frame :)
      commit <- maybe (ioError (userError "checked desktop commit missing")) pure (checkedDesktopCommit checked)
      let requests = D.commitRequests commit
          ids = map (renderCounter . D.requestId) requests
      check "sixteen decoded ordered catalog requests" (count == 16 && ids == map (T.pack . show) [1..16 :: Int]
             && all ((== D.CatalogRead) . D.requestKind) requests)
      frameDl <- deadlineFromAbsoluteNs (show (P.frameDeadlineNs frame)) >>= must
      batch <- beginLiveFrameRequestBatch admission frameDl False (length requests) >>= must
      -- Created once by this trusted fixture, before any entry. Every selected
      -- action must receive this exact stricter deadline, never a fresh one.
      strictDl <- deadlineAfter 4000000 >>= must
      strictNow <- toInteger <$> getMonotonicTimeNSec
      outcomes <- mapM (\request -> enterLiveBatchRequest batch defaultPersistentActionBudget (Just strictDl) $ \actionDl -> do
       modifyIORef' actionDs (++ [deadlineAbsoluteNs actionDl])
       modifyIORef' effects (++ [renderCounter (D.requestId request)])
       pure (Right ())) requests
      check "sixteen actual admitted callbacks completed" (outcomes == replicate 16 (Right ()))
      excess <- enterLiveBatchRequest batch defaultPersistentActionBudget (Just strictDl) $ \_ -> do
       modifyIORef' effects (++ ["unexpected-17th"])
       pure (Right ())
      check "exhausted batch refuses entry before callback" (excess == Left (OperationRefusedPreDispatch OwnerBusy))
      ds <- readIORef actionDs
      check "one exact trusted stricter deadline" (length ds == 16 && all (== deadlineAbsoluteNs strictDl) ds)
      finish <- toInteger <$> getMonotonicTimeNSec
      check "monotonic elapsed action sequence" (finish >= strictNow)
 ingress <- P.newDesktopCredentialIngressWithContext bound FromElm callback (\_ _ -> ioError (userError "unexpected server callback"))
 writeIORef ingressCell (Just ingress)
 (host,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 writeIORef socketsCell (Just (host,peer))
 offered <- P.transferCredentialSocket ingress host
 check "host accepted" (offered == OfferAccepted)
 activated <- P.activateCredentialIngress ingress
 check "host activated" (activated == ActivationLive)
 peerHandle <- S.socketToHandle peer ReadWriteMode
 writeIORef handleCell (Just peerHandle)
 start <- startBudgetAfter 2000000 >>= must
 let verify obs = writeIORef observed (Just obs) >> pure (Right ())
     body session = do
      received <- P.receivePersistentCredentialIngressOwned False session ingress guardFor
      seen <- readIORef callbacks
      done <- readIORef effects
      if count == 16
       then do
        check "valid frame delivered" (received == Right (P.PersistentOutcome P.CredentialDelivered))
        check "one callback and exact ordered test effects" (seen == 1 && done == map (T.pack . show) [1..16 :: Int])
        ds <- readIORef frameDs
        check "same original frame D" (length ds >= 4 && all (== head ds) ds && head ds > 0)
       else do
        check "17 request frame rejected by checked schema" (received == Right (P.PersistentOutcome (P.CredentialRejected BadSchema)))
        check "whole invalid frame before callback or effects" (seen == 0 && null done)
      removeFile marker
     finalizer = do
      -- The Root guardian owns exceptional child cleanup; marker removal only
      -- permits a normally started child to exit, and is not a reap receipt.
      existsNow <- doesFileExist marker
      if existsNow then removeFile marker else pure ()
 (do
   result <- restore (withPersistentOwnerHook owner (persistentFixture child [marker,show count] peerHandle)
      4096 start stopBudget verify body (\_ -> pure ()))
   case result of
    Right ((), LeaderReaped _) -> do
     closed <- hIsClosed peerHandle
     check "transferred child handle closed" closed
     status <- P.retireCredentialIngress ingress
     check "host endpoint close confirmed" (endpoint status == Just EndpointConfirmed)
    other -> ioError (userError ("owner retained unconfirmed: " ++ show other))) `finally` finalizer
