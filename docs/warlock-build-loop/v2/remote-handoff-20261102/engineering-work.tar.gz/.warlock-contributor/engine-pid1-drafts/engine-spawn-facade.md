# Engine PID1 spawn and ownership facade — preparation draft

Status: proposed interface and proof obligations only. No implementation, build, execution, VM acceptance, or change to original deadlines or failures is implied. Keep the current fail-closed namespace guard until the entire replacement is independently reviewed and root verifies it. Preserve all 242 requirements, 417 scenarios and stop histories. The original architecture capability scenario is not whole ARC024 or DEL014 acceptance.

## Source boundary

At review, SHA-256 was: `Warlock/Capture/Process.hs` `39a0805202bd0843affe2c32bfc0c8f9f79197231a94f1f2e6c40905dcf96fef`; `Process/Bootstrap.hs` `dc8273cb33d6f23757b20f16f7cefc83d00fc8ab4d00520149744928bbd1a461`; `Process/Whitelist.hsc` `62775261c983b9b2f8f256734c731fee492f1f4a327ceab845370bd6e82da416`; `Process/Internal.hsc` `f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f`; `Ui/EngineCustody.hsc` `e8fa295690356aef8621e04ad5d28665dfe195189baa7536b76245b295696070`. Paths are under `implementation/warlock/haskell/{process-custody/src/Warlock/Capture,runtime/ui/Warlock}`. Recheck hashes and actual source before implementation.

`Whitelist` is a package-private module, not a caller API. It builds checked dup2/closefrom actions and records pending resources, PID, group and handle. Existing public selected-spawn routes do not expose the fixed additional engine FD plan; their existing runner starts capture readers and owns group-before-wait. Neither import a private constructor nor copy the descriptor executor. A package-owned addition must retain existing owner/pending/lease invariants, expose only opaque capabilities, and provide a nonthreaded broker path. Nothing here establishes that this addition currently exists.

## Proposed owned API

The following is illustrative type-level design, not an available Haskell signature:

```
withEngine :: Owner -> HeldExecutable -> EngineOnlyConfig
           -> AdmissionDeadline
           -> (EngineSession -> IO (Either EngineError a))
           -> IO (Either EngineError (a, EngineCleanup))

engineRequest :: EngineSession -> BoundedRequest -> IO (Either EngineError BoundedReply)
engineFacts   :: EngineSession -> IO (Either EngineError EngineIdentityFacts)
```

`EngineOnlyConfig`, session, image and endpoint capabilities are opaque and package-issued; creation validates fixed argv/environment, one immutable deadline D, exact held executable and one engine-only mode. No caller-supplied PID, raw signal, waiter, descriptor list, constructor or unrestricted child action is exposed. Any exposed observation callback is strictly read-only, bounded and scoped; it must not close, duplicate, transfer or mutate descriptors, signal, wait/reap, change callbacks, or outlive its session. Enforce this structurally with immutable facts rather than relying on a callback promise. Publication is atomic with retaining pending state; an exception or inability to establish ownership leaves the owner quarantined, never a silently unowned child. Retain the image and endpoint leases until identity checks and shutdown settle.

**One reaper and stop authority: process-custody Owner.** It alone publishes, signals and reaps this direct child, using its established group-before-final-wait discipline or a separately reviewed replacement wholly owned by that same Owner. No EngineCustody `waitid`, signal, reap, or competing process handle is permitted for this child. GLib owns its own WebKit child watches; no wildcard wait may steal them. Failure or uncertain ownership/cleanup is not success. Ensure PID1 termination also ends its namespace descendants, while unrelated children cannot be signalled. Group and PID reuse, shutdown ordering and forced versus natural exit must be proven under the original D.

## Descriptor and identity contract

A finite, fixed child manifest is proposed: 0, 1 and 2 are explicitly owned harmless inputs/outputs (for example `/dev/null`, with stderr only an approved diagnostics sink); 3 is one owned full-duplex framed RPC endpoint; 4 is the one-way parent lifeline read end; optionally a separately reserved executable FD is retained only if the chosen held-exec mechanism requires it. These numbers are illustrative until integrated with the actual public API. Sources must not alias improperly, all extra descriptors must be excluded with a checked complete close plan, and failure is fatal. In particular, backend native fd0, native grants, HTTP listeners, parent lifeline writer and unrelated descriptors never enter the child. The broker retains its own endpoint and sole lifeline writer; no descendant gets a writer. After adoption set CLOEXEC on engine endpoints before library/renderer child creation. Held-image FD lifetime and close semantics must be proved for the actual executable and loader, not assumed for scripts/interpreters. Per-descriptor lease/close uncertainty fails closed; never blindly close a reused number.

Use an independently pinned *same held executable image* with a fixed engine-only mode, never a mutable path lookup or unverified replacement. Bind the launched direct child to owner-recorded host PID and birth identity, exact executable device/inode/hash and approved source/build tuple, namespace identity, and original D. The engine proves local PID 1 and correct user/network/PID/mount namespace relationships using actual kernel observations; the broker validates what it can from its own namespace and receives the remaining facts over the authenticated channel. A claimed PID, local PID 1, `/proc` pathname, nonce, or SO_PEERCRED captured at socketpair creation alone is insufficient proof of the post-exec sender.

Enable and validate kernel-provided per-message SCM credentials on the receiving Unix socket, including PID as interpreted in the receiver's PID namespace and expected UID/GID; compare the sender to the owned host PID/birth and expected identity. Reject missing, truncated, duplicate, malformed, unexpected or mismatched credentials and ancillary descriptors. Verify the exact stream or message socket transport semantics and association of credentials with each framed message; do not assume a nonce or socketpair creation credentials prove who sent later bytes. Bind the exchange to a fresh challenge, selected session and D as replay/cross-session protection, not as a substitute for kernel credentials. A mechanism that cannot reliably deliver/associate credentials with each required message is an open implementation blocker, not permission to downgrade authentication.

## Lifecycle and readiness

The broker after namespace setup remains nonthreaded and never initializes GTK/WebKit. It owns native IPC and all listeners. The engine alone initializes GTK/WebKit after exec in the reviewed namespace, with its own engine-only dispatcher; Elm remains GUI authority and no untrusted page receives native access.

Protect the parent-death race: establish `PDEATHSIG` at the correct point and check its syscall result; because the parent can die before installation or during exec, verify the parent-only lifeline has neither EOF nor unexpected data after establishment and immediately before sending ready, and monitor it for the entire engine lifetime. PID 1's `getppid == 0` when the real parent is outside the namespace cannot prove the parent is alive. Parent writer leakage, privilege/exec transitions that alter death-signal semantics, fork/exec races, and death after the check require explicit proof and fail-closed shutdown. Correct signal dispositions and interactions with GLib must be reviewed. A lifetime FD, process group or one observed check alone is not a complete death proof.

Startup-ready means all of: exact held image and engine-only mode, authenticated selected direct child/birth, local PID 1 and required namespace tuple, fixed FD census and adopted IPC, live parent/lifeline, successful bounded challenge and original D still positive. The parent independently verifies its half before admitting the engine. Any EOF, sender mismatch, malformed frame, expired D or uncertain cleanup poisons the session. Startup-ready is **not** provider-ready, GUI acceptance, native authority, or proof of any original security scenario. Browser/provider readiness requires separate actual observations and remains open.

## Feasibility and implementation gates

Current `posix_spawn` wrapper is path-based and supplies FD actions and signal/group attributes; it has no namespace creation, private proc mount, PDEATHSIG or arbitrary child setup hook. A borrowed `/proc/<outer-pid>/fd/<n>` path may cease to resolve after switching proc mounts; action ordering/closefrom can also remove an executable FD before lookup. Do not assert bare `posix_spawn` solves the split. Before changing code, prove one compatible held-exec and setup sequence for the actual image, namespace and loader while preserving an owned, nonthreaded broker, complete FD plan, deadline, and one owner. If required capabilities disappear across exec, setup ordering must account for it; kernel/guest capability and mount assumptions remain hypotheses until independently verified. Haskell runtime post-fork safety and nonthreaded requirements need review. A new C helper or copied executor is not authorized by this draft; Warlock-authored production remains Elm/Haskell. Any missing primitive or conflicting requirement blocks implementation rather than weakening isolation, native grants or evidence.

## Root-owned verification after source review

No tests were run for this draft. Once specifically authorized and implemented, root should run source-bound checks that exercise the actual held executable, actual owner and actual engine-only mode, rather than a mirror or injected browser script:

* Pin/race: replace or rename path after holding; mutate wrong image, argv or mode; reject mismatched inode/hash, stale birth, wrong namespace, missing/forged/truncated SCM credentials, replay and D expiry. Verify exact same held image executed and correct receiver-namespace PID.
* FD census before engine adoption and immediately before GTK/renderer spawn: fd0 and listener absence, only the fixed plan, correct endpoint direction, no leaked lifeline writer, CLOEXEC on adopted endpoints, no inherited credentials or foreign connections. Test colliding source/target descriptors, failed close/dup, low limits and partial publication with retained uncertainty.
* Real parent-death and lifecycle interleavings before spawn, during setup/exec, before/after ready and while active; use actual kill/EOF and blocked/leaked-writer controls. Verify bounded termination, no false ready, no orphaned PID1/descendants and distinguish natural exit from forced cleanup.
* Pthread census of actual broker immediately around namespace setup/spawn and during its lifetime, with an injected extra-thread refusal; independently confirm GTK/WebKit never starts in broker. Exercise actual engine after exec with its own provider readiness separately measured.
* Competing unrelated child, concurrent stop/exception/cancel, owned process group/pid reuse and GLib child watch tests prove exactly one reaper, no foreign reaping/signalling, correct cleanup and quarantined failure. All original deadlines remain fixed, and failed evidence is retained.
