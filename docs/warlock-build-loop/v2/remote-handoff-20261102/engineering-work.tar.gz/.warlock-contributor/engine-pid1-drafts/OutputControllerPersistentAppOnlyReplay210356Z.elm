port module OutputControllerPersistentAppOnlyReplay210356Z exposing (main)

{-| Ignored QA sequence/property replay for persistent AppOnly OutputController
batch retirement paired with gemini-omarchy-persistent-app-only-210356Z.patch.

Verifies:
1. 24 (> 16) sequential bound catalog-request and taskbar-pins-write commits
   settled via authoritative native-event replies ("application-catalog" and
   "taskbar-pins-outcome") without "view-disposition" keep pendingBatches == 0
   and never trip 16-batch exhaustion in a persistent AppOnly session.
2. Partial multi-request pure-application batch (1 catalog-request + 1 pin write)
   remains retained until BOTH authoritative replies arrive on active binding.
3. Mixed batch containing a native observation ("projection-request") is NEVER
   retired by "application-catalog".
4. Foreign-binding, mismatched-requestId, and malformed replies NEVER free
   pending batch capacity.
5. "taskbar-pins-outcome" with status "Unknown" frees the transport batch slot
   (proving socket delivery occurred) while preserving Pins domain Unknown
   (pending /= Nothing, blocking further pin writes until recovery read) and
   keeping nativeOperations == [] (Shell.AppOnly) and entry:<id> disabled.
-}

import Desktop
import Json.Decode as D
import Json.Encode as E
import OutputController as Outputs
import Pins
import Platform
import Shell
import Surface
import SurfaceController as Controller

port outgoing : E.Value -> Cmd msg

bindingJson : E.Value
bindingJson =
    E.object
        [ ( "lifetime", E.string "1" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "1" )
        ]

foreignBindingJson : E.Value
foreignBindingJson =
    E.object
        [ ( "lifetime", E.string "2" )
        , ( "session", E.string "1" )
        , ( "frontend", E.string "1" )
        ]

scopeJson : String -> E.Value
scopeJson gen =
    E.object [ ( "id", E.string "1" ), ( "generation", E.string gen ) ]

topologyJson : String -> String -> E.Value
topologyJson rev gen =
    E.object
        [ ( "viewProtocol", E.int 2 )
        , ( "kind", E.string "view-topology" )
        , ( "revision", E.string rev )
        , ( "views", E.list identity [ scopeJson gen ] )
        , ( "locations"
          , E.list identity
                [ E.object
                    [ ( "scope", scopeJson gen )
                    , ( "box", E.list E.int [ 0, 0, 1280, 720 ] )
                    ]
                ]
          )
        ]

applicationAttachedJson : E.Value
applicationAttachedJson =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "application-attached" )
        , ( "binding", bindingJson )
        , ( "nativeOperations", E.list identity [] )
        ]

catalogSnapshotJson : String -> E.Value
catalogSnapshotJson gen =
    E.object
        [ ( "catalogProtocol", E.int 2 )
        , ( "lifetime", E.string "1" )
        , ( "generation", E.string gen )
        , ( "entries"
          , E.list identity
                [ E.object
                    [ ( "id", E.string "warlock-files" )
                    , ( "name", E.string "Files" )
                    , ( "iconHint", E.string "system-file-manager" )
                    , ( "wmclass", E.string "org.omarchy.files" )
                    , ( "genericName", E.string "File Manager" )
                    , ( "keywords", E.list E.string [ "folders", "browse" ] )
                    ]
                , E.object
                    [ ( "id", E.string "warlock-editor" )
                    , ( "name", E.string "Editor" )
                    , ( "iconHint", E.string "accessories-text-editor" )
                    , ( "wmclass", E.string "org.omarchy.editor" )
                    , ( "genericName", E.string "Text Editor" )
                    , ( "keywords", E.list E.string [ "code", "notes" ] )
                    ]
                ]
          )
        ]

pinsSnapshotJson : String -> List String -> E.Value
pinsSnapshotJson rev ids =
    E.object
        [ ( "revision", E.string rev )
        , ( "identities", E.list E.string ids )
        ]

catalogReplyJson : E.Value -> String -> String -> E.Value -> E.Value
catalogReplyJson bindVal reqId catGen prefVal =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "application-catalog" )
        , ( "binding", bindVal )
        , ( "requestId", E.string reqId )
        , ( "snapshot", catalogSnapshotJson catGen )
        , ( "preferences", prefVal )
        ]

pinsOutcomeJson : E.Value -> String -> String -> E.Value -> E.Value
pinsOutcomeJson bindVal reqId statusTag prefVal =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "taskbar-pins-outcome" )
        , ( "binding", bindVal )
        , ( "requestId", E.string reqId )
        , ( "status", E.string statusTag )
        , ( "preferences", prefVal )
        ]

catalogReqWire : String -> E.Value
catalogReqWire reqId =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "catalog-request" )
        , ( "binding", bindingJson )
        , ( "requestId", E.string reqId )
        ]

pinReqWire : String -> String -> List String -> E.Value
pinReqWire reqId rev ids =
    E.object
        [ ( "protocolVersion", E.int 3 )
        , ( "kind", E.string "taskbar-pins-write" )
        , ( "binding", bindingJson )
        , ( "requestId", E.string reqId )
        , ( "proposal", pinsSnapshotJson rev ids )
        ]

stepAndRegister : Outputs.Event -> Outputs.Model -> ( Outputs.Model, Maybe E.Value )
stepAndRegister ev current =
    let
        ( updated, effects ) =
            Outputs.update ev current
    in
    Outputs.register effects updated

incomingPayload : E.Value -> Outputs.Model -> Outputs.Model
incomingPayload payload current =
    Outputs.update (Outputs.Interaction (Desktop.Incoming payload)) current |> Tuple.first

appOnlySession : Outputs.Model
appOnlySession =
    let
        ( topModel, _ ) =
            stepAndRegister (Outputs.Topology (topologyJson "1" "1")) Outputs.initial
    in
    incomingPayload applicationAttachedJson topModel

openApplicationsOnce : Outputs.Model -> ( Outputs.Model, Maybe E.Value )
openApplicationsOnce current =
    let
        desk =
            Controller.desktop (Outputs.controller current)
    in
    case Desktop.capture desk of
        Just stamp ->
            stepAndRegister (Outputs.Interaction (Desktop.OpenApplications stamp)) current

        Nothing ->
            ( current, Nothing )

extractFirstRequestId : Maybe E.Value -> String
extractFirstRequestId maybePacket =
    case maybePacket of
        Nothing ->
            "0"

        Just packet ->
            D.decodeValue
                (D.field "requests" (D.index 0 (D.field "requestId" D.string)))
                packet
                |> Result.withDefault "0"

-- Run 24 (> 16) sequential real Desktop catalog refreshes + pin toggles in a
-- single persistent AppOnly binding without any view-disposition event.
runTwentyFourAppOnlyRoundTrips : ( Outputs.Model, Bool )
runTwentyFourAppOnlyRoundTrips =
    let
        ( opened0, packet0 ) =
            openApplicationsOnce appOnlySession

        req0 =
            extractFirstRequestId packet0

        settled0 =
            incomingPayload
                (catalogReplyJson bindingJson req0 "1" (pinsSnapshotJson "1" []))
                opened0

        stepRound roundIx ( state, allClearSoFar, currentPins ) =
            let
                deskBeforeRefresh =
                    Controller.desktop (Outputs.controller state)

                ( refreshedState, refreshPacket ) =
                    case Desktop.capture deskBeforeRefresh of
                        Just stamp ->
                            stepAndRegister (Outputs.Interaction (Desktop.RefreshApplications stamp)) state

                        Nothing ->
                            ( state, Nothing )

                refreshReqId =
                    extractFirstRequestId refreshPacket

                pendingDuringRefresh =
                    Outputs.pendingBatches refreshedState == 1

                afterCatalog =
                    incomingPayload
                        (catalogReplyJson
                            bindingJson
                            refreshReqId
                            (String.fromInt (roundIx + 1))
                            (pinsSnapshotJson (String.fromInt (roundIx * 2)) currentPins)
                        )
                        refreshedState

                clearedAfterCatalog =
                    Outputs.pendingBatches afterCatalog == 0

                deskBeforePin =
                    Controller.desktop (Outputs.controller afterCatalog)

                ( pinState, pinPacket ) =
                    case Desktop.capture deskBeforePin of
                        Just stamp ->
                            stepAndRegister (Outputs.Interaction (Desktop.TogglePin stamp "warlock-files")) afterCatalog

                        Nothing ->
                            ( afterCatalog, Nothing )

                pinReqId =
                    extractFirstRequestId pinPacket

                nextPins =
                    Pins.toggle "warlock-files" currentPins

                pendingDuringPin =
                    Outputs.pendingBatches pinState == 1

                afterPin =
                    incomingPayload
                        (pinsOutcomeJson
                            bindingJson
                            pinReqId
                            "Saved"
                            (pinsSnapshotJson (String.fromInt (roundIx * 2 + 1)) nextPins)
                        )
                        pinState

                clearedAfterPin =
                    Outputs.pendingBatches afterPin == 0
            in
            ( afterPin
            , allClearSoFar && refreshPacket /= Nothing && pinPacket /= Nothing && pendingDuringRefresh && clearedAfterCatalog && pendingDuringPin && clearedAfterPin
            , nextPins
            )

        ( finalModel, roundsOk, _ ) =
            List.foldl stepRound ( settled0, Outputs.pendingBatches settled0 == 0, [] ) (List.range 1 12)
    in
    ( finalModel, roundsOk )

checks : List ( String, Bool )
checks =
    let
        ( after24Model, twentyFourOk ) =
            runTwentyFourAppOnlyRoundTrips

        finalDesktop =
            Controller.desktop (Outputs.controller after24Model)

        openButtonsDisabled =
            Surface.controls finalDesktop
                |> List.filter (\c -> String.startsWith "entry:" c.id)
                |> (\cs -> not (List.isEmpty cs) && List.all (\c -> not c.enabled) cs)

        -- Partial multi-request pure-application batch (catalog 41 + pin 42):
        ( multiBatchState, multiPacket ) =
            Outputs.register
                [ Controller.DesktopEffect (Desktop.Send (catalogReqWire "41"))
                , Controller.DesktopEffect (Desktop.Send (pinReqWire "42" "30" [ "warlock-files" ]))
                ]
                after24Model

        afterHalfMulti =
            incomingPayload
                (catalogReplyJson bindingJson "41" "99" (pinsSnapshotJson "30" []))
                multiBatchState

        afterFullMulti =
            incomingPayload
                (pinsOutcomeJson bindingJson "42" "Refused" E.null)
                afterHalfMulti

        -- Mixed batch (catalog 51 + native projection-request 52) must NEVER retire on catalog reply:
        mixedObsWire =
            E.object
                [ ( "protocolVersion", E.int 3 )
                , ( "kind", E.string "projection-request" )
                , ( "binding", bindingJson )
                , ( "requestId", E.string "52" )
                ]

        ( mixedBatchState, _ ) =
            Outputs.register
                [ Controller.DesktopEffect (Desktop.Send (catalogReqWire "51"))
                , Controller.DesktopEffect (Desktop.WindowEffect (Shell.Send mixedObsWire))
                ]
                afterFullMulti

        afterCatalogOnMixed =
            incomingPayload
                (catalogReplyJson bindingJson "51" "100" (pinsSnapshotJson "30" []))
                mixedBatchState

        -- Foreign binding, wrong requestId, and malformed status must NOT retire a pure-application batch:
        ( guardedBatchState, _ ) =
            Outputs.register
                [ Controller.DesktopEffect (Desktop.Send (catalogReqWire "61")) ]
                afterFullMulti

        afterForeignReply =
            incomingPayload
                (catalogReplyJson foreignBindingJson "61" "101" E.null)
                guardedBatchState

        afterWrongRequest =
            incomingPayload
                (catalogReplyJson bindingJson "999" "101" E.null)
                afterForeignReply

        malformedCatalog =
            E.object
                [ ( "protocolVersion", E.int 3 )
                , ( "kind", E.string "application-catalog" )
                , ( "binding", bindingJson )
                , ( "requestId", E.string "61" )
                ]

        afterMalformed =
            incomingPayload malformedCatalog afterWrongRequest

        -- Unknown pin outcome retires transport Batch slot while preserving domain Pins Unknown:
        deskReadyForUnknown =
            Controller.desktop (Outputs.controller afterFullMulti)

        ( unknownPinState, unknownPinPacket ) =
            case Desktop.capture deskReadyForUnknown of
                Just stamp ->
                    stepAndRegister (Outputs.Interaction (Desktop.TogglePin stamp "warlock-editor")) afterFullMulti

                Nothing ->
                    ( afterFullMulti, Nothing )

        unknownReqId =
            extractFirstRequestId unknownPinPacket

        afterUnknownOutcome =
            incomingPayload
                (pinsOutcomeJson bindingJson unknownReqId "Unknown" E.null)
                unknownPinState

        deskAfterUnknown =
            Controller.desktop (Outputs.controller afterUnknownOutcome)

        -- Capacity recovery at 16 pure-application batches:
        fill16 =
            List.foldl
                (\ix st ->
                    Outputs.register
                        [ Controller.DesktopEffect (Desktop.Send (catalogReqWire (String.fromInt (200 + ix)))) ]
                        st
                        |> Tuple.first
                )
                afterFullMulti
                (List.range 1 16)

        ( seventeenthRefusedState, _ ) =
            Outputs.register
                [ Controller.DesktopEffect (Desktop.Send (catalogReqWire "217")) ]
                fill16

        recoveredFrom16 =
            incomingPayload
                (catalogReplyJson bindingJson "201" "120" E.null)
                seventeenthRefusedState

        ( eighteenthAdmittedState, eighteenthPacket ) =
            Outputs.register
                [ Controller.DesktopEffect (Desktop.Send (catalogReqWire "218")) ]
                recoveredFrom16
    in
    [ ( "twentyFourSequentialCommitsNeverExhaust16BatchCap", twentyFourOk && Outputs.pendingBatches after24Model == 0 )
    , ( "appOnlyPhaseAndZeroNativeAuthorityPreserved"
      , finalDesktop.windows.shell.phase == Shell.AppOnly && not (Shell.available finalDesktop.windows.shell)
      )
    , ( "catalogOpenButtonsRemainDisabledWithoutNativeAuthority", openButtonsDisabled )
    , ( "multiRequestBatchRetainedUntilAllRepliesArrive"
      , multiPacket /= Nothing
            && Outputs.pendingBatches multiBatchState == 1
            && Outputs.pendingBatches afterHalfMulti == 1
            && Outputs.pendingBatches afterFullMulti == 0
      )
    , ( "mixedObservationBatchNeverRetiredByCatalogReply"
      , Outputs.pendingBatches mixedBatchState == 1 && Outputs.pendingBatches afterCatalogOnMixed == 1
      )
    , ( "foreignWrongIdAndMalformedRepliesNeverFreeBatch"
      , Outputs.pendingBatches guardedBatchState == 1
            && Outputs.pendingBatches afterForeignReply == 1
            && Outputs.pendingBatches afterWrongRequest == 1
            && Outputs.pendingBatches afterMalformed == 1
      )
    , ( "unknownPinOutcomeRetiresTransportBatchButPreservesDomainUnknown"
      , unknownPinPacket /= Nothing
            && Outputs.pendingBatches unknownPinState == 1
            && Outputs.pendingBatches afterUnknownOutcome == 0
            && deskAfterUnknown.pins.pending /= Nothing
            && not (Pins.writable deskAfterUnknown.pins)
      )
    , ( "sixteenthBatchSettlementRecoversCapacityForNextCommit"
      , Outputs.pendingBatches fill16 == 16
            && Outputs.pendingBatches recoveredFrom16 == 15
            && eighteenthPacket /= Nothing
            && Outputs.pendingBatches eighteenthAdmittedState == 16
      )
    ]

result : E.Value
result =
    E.object
        [ ( "allPassed", E.bool (List.all Tuple.second checks) )
        , ( "checks", E.object (List.map (\( k, v ) -> ( k, E.bool v )) checks) )
        ]

main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing result )
        , update = \_ s -> ( s, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
