// QA-only proposal. Root executes only in the existing isolated browser runner.
// Usage: node TEST.mjs http://127.0.0.1:PORT/PATH/HttpPopup.html ime.json CHROMIUM NEW-REPORT.json HTML-SOURCE
// The HTML must be built from the current HttpPopup.elm; ime.json must be from
// current ImeReplay.elm. Synthetic HTTP/CDP is not native input, IME, AT or paint.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const [documentArg, framePath, binary, reportPath, htmlSourcePath] = process.argv.slice(2);
if (process.argv.length !== 7) throw Error('expected URL, ime.json, chromium, new report path and exact HTML source');
const documentUrl = new URL(documentArg);
if (documentUrl.protocol !== 'http:' || documentUrl.hostname !== '127.0.0.1' || !documentUrl.port || documentUrl.username || documentUrl.password || documentUrl.hash)
  throw Error('document URL must use an explicit loopback HTTP origin');
const packet = JSON.parse(fs.readFileSync(framePath, 'utf8'));
if (!packet.frame || packet.frame.publication !== '1' || packet.frame.lease !== '1') throw Error('unexpected source-bound ImeReplay fixture');
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const reportFd = fs.openSync(reportPath, 'wx', 0o600);
const report = { schema: 1, passed: false, checks: [], errors: [], scope: 'Synthetic controlled browser; not physical keyboard/IME, AT, independent paint, latency, native or release', fixtureSha256: hash(framePath), testSha256: hash(fileURLToPath(import.meta.url)), binarySha256: hash(binary), htmlSha256: hash(htmlSourcePath), nativeAcceptance: false };
const profile = path.join(path.dirname(path.resolve(reportPath)), 'stopped-focus-profile-' + process.pid);
const browser = spawn(binary, ['--headless=new','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--disable-background-networking','--disable-gpu','--disable-breakpad','--disable-crash-reporter','--no-first-run','--user-data-dir='+profile,'about:blank'], { stdio: ['ignore','pipe','pipe'] });
let stderr = '', ws, session, targetId = null, sequence = 0, stage = 0, eventCount = 0, actionRequests = [], heldAction = null, heldPoll = null;
const pending = new Map();
browser.stderr.on('data', chunk => { stderr += chunk; });
browser.stdout.resume();
browser.on('error', error => report.errors.push('browser process error: '+String(error)));
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
function check(name, passed, detail) { report.checks.push({name, passed: Boolean(passed), ...(passed ? {} : {detail})}); if (!passed) throw Error(name); }
function call(method, params = {}, sessionId = session) {
  return new Promise((resolve, reject) => {
    const id = ++sequence, timer = setTimeout(() => { pending.delete(id); reject(Error('CDP timeout: '+method)); }, 15000);
    pending.set(id, {resolve,reject,timer}); ws.send(JSON.stringify({id,method,params,...(sessionId ? {sessionId} : {})}));
  });
}
async function evaluate(expression) { const r = await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true}); if (r.exceptionDetails) throw Error('page exception: '+JSON.stringify(r.exceptionDetails)); return r.result.value; }
async function until(probe, label) { for (let i=0;i<150;i++) { if (await probe()) return; await sleep(20); } throw Error('fixture timeout: '+label); }
const gateway = payload => ({bridgeProtocol:1,kind:'presentation',payload});
async function onPaused(event, pausedSession) {
  if (pausedSession !== session) return;
  const request = event.request, url = new URL(request.url), id = event.requestId;
  if (url.origin !== documentUrl.origin) { report.errors.push('unexpected cross-origin request'); await call('Fetch.failRequest',{requestId:id,errorReason:'BlockedByClient'},pausedSession); return; }
  if (url.pathname === '/events' && request.method === 'GET') {
    eventCount++;
    if (eventCount === 1) {
      await call('Fetch.fulfillRequest',{requestId:id,responseCode:200,responseHeaders:[{name:'Content-Type',value:'application/json'}],body:Buffer.from(JSON.stringify(gateway(packet.frame))).toString('base64')},pausedSession);
    } else { if (heldPoll !== null) throw Error('unexpected concurrent event poll'); heldPoll = id; }
  } else if (url.pathname === '/actions' && request.method === 'POST') {
    if (heldAction !== null) throw Error('unexpected concurrent action');
    actionRequests.push(JSON.parse(request.postData || 'null')); heldAction = id;
  } else { await call('Fetch.continueRequest',{requestId:id},pausedSession); }
}
async function key(name, code, modifiers=0) {
  const keyCode = name === 'Tab' ? 9 : 65;
  await call('Input.dispatchKeyEvent',{type:'keyDown',key:name,code,windowsVirtualKeyCode:keyCode,modifiers});
  await call('Input.dispatchKeyEvent',{type:'keyUp',key:name,code,windowsVirtualKeyCode:keyCode,modifiers});
}
async function runCase(otherControl) {
  // Each case has its own closed CDP target/session. A paused GET from a
  // retired document must never be classified as a poll of the next case.
  if (targetId !== null) {
    const retiring=targetId; session=null; targetId=null;
    const closed=await call('Target.closeTarget',{targetId:retiring},null);
    if (!closed.success) throw Error('prior target did not close');
  }
  stage++; eventCount=0; actionRequests=[]; heldAction=null; heldPoll=null;
  const target=await call('Target.createTarget',{url:'about:blank'},null); targetId=target.targetId;
  session=(await call('Target.attachToTarget',{targetId,flatten:true},null)).sessionId;
  await call('Page.enable'); await call('Runtime.enable');
  await call('Emulation.setDeviceMetricsOverride',{width:621,height:620,deviceScaleFactor:1,mobile:false});
  await call('Fetch.enable',{patterns:[{urlPattern:'*',requestStage:'Request'}]});
  await call('Page.navigate',{url:documentUrl.href});
  await until(async()=>Boolean(await evaluate(`!!document.querySelector('[data-surface-field="control:search"]')`)), 'initial search field');
  const tree=await call('Page.getFrameTree');
  const content=await call('Page.getResourceContent',{frameId:tree.frameTree.frame.id,url:documentUrl.href});
  const bytes=Buffer.from(content.content,content.base64Encoded?'base64':'utf8');
  check('case '+stage+' served HTML matches pinned local artifact',crypto.createHash('sha256').update(bytes).digest('hex')===report.htmlSha256);
  await evaluate(`document.querySelector('[data-surface-field="control:search"]').focus()`);
  check('case '+stage+' precondition search focused',await evaluate(`document.activeElement===document.querySelector('[data-surface-field="control:search"]')`));
  await call('Input.insertText',{text:'foot'});
  await until(()=>heldAction !== null,'outgoing query');
  const sent=actionRequests[0];
  check('case '+stage+' sends one exact current query',actionRequests.length===1 && sent && JSON.stringify(Object.keys(sent).sort())===JSON.stringify(['id','kind','lease','publication','query','surface','surfaceProtocol']) && sent.surfaceProtocol===2 && sent.kind==='surface-query' && sent.surface==='popup' && sent.publication==='1' && sent.lease==='1' && sent.id==='control:search' && sent.query==='foot',actionRequests);
  if (otherControl) {
    await evaluate(`document.querySelector('[data-surface-control="control:refresh"]').focus()`);
    check('case '+stage+' precondition other control focused',await evaluate(`document.activeElement===document.querySelector('[data-surface-control="control:refresh"]')`));
  }
  const failed = heldAction; heldAction = null;
  await call('Fetch.failRequest',{requestId:failed,errorReason:'Failed'});
  await until(async()=>Boolean(await evaluate(`!!document.querySelector('[data-transport-stopped="true"]')`)),'stopped view');
  const stopped = await evaluate(`(()=>{const f=document.querySelector('#http-popup-retained-query'),a=document.querySelector('[role="alert"]');return {found:!!f,readOnly:f?.readOnly,value:f?.value,label:f?.getAttribute('aria-label'),state:f?.dataset.retainedQueryState,focusIsRetained:document.activeElement===f,alert:a?.textContent,editable:!!document.querySelector('[data-surface-field]'),controls:document.querySelectorAll('[data-surface-control]').length};})()`);
  check('case '+stage+' retains unconfirmed draft read-only and removes actions',stopped.found && stopped.readOnly && stopped.value==='foot' && stopped.label==='Unconfirmed draft search query (read-only; not confirmed by desktop)' && stopped.state==='unconfirmed-draft' && !stopped.editable && stopped.controls===0 && Boolean(stopped.alert?.includes('will not be repeated')),stopped);
  if (otherControl) check('loss from other control does not force focus into retained input',!stopped.focusIsRetained,stopped);
  // After loss, either the retained field already has focus or normal Tab must
  // reach it. This does not require or claim physical focus or copy to clipboard.
  if (!stopped.focusIsRetained) { for (let i=0;i<4 && !(await evaluate(`document.activeElement===document.querySelector('#http-popup-retained-query')`));i++) await key('Tab','Tab'); }
  const reachable = await evaluate(`(()=>{const f=document.querySelector('#http-popup-retained-query');return !!f && document.activeElement===f;})()`);
  check('case '+stage+' retained field keyboard reachable',reachable,stopped);
  await key('a','KeyA',2); // Linux Control+A, selection only; no clipboard read.
  const selection = await evaluate(`(()=>{const f=document.querySelector('#http-popup-retained-query');return {start:f.selectionStart,end:f.selectionEnd,value:f.value};})()`);
  check('case '+stage+' retained draft selectable without mutation',selection.start===0 && selection.end===4 && selection.value==='foot',selection);
  check('case '+stage+' no additional POST observed during keyboard steps',actionRequests.length===1,actionRequests);
}
try {
  let endpoint;
  await until(()=>{const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m)endpoint=m[1];if(browser.exitCode!==null)throw Error('browser exited before ready');return Boolean(endpoint);},'browser endpoint');
  ws = new WebSocket(endpoint); await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject;});
  ws.onmessage = event => { const message=JSON.parse(event.data); if(message.id){const item=pending.get(message.id);if(item){pending.delete(message.id);clearTimeout(item.timer);message.error?item.reject(Error(JSON.stringify(message.error))):item.resolve(message.result);}} else if(message.method==='Fetch.requestPaused' && message.sessionId===session) onPaused(message.params,message.sessionId).catch(error=>report.errors.push(String(error))); else if(message.method==='Runtime.exceptionThrown' && message.sessionId===session) report.errors.push('page exception'); };
  await runCase(false); await runCase(true);
  check('no unexpected browser or fetch errors',report.errors.length===0,report.errors); report.passed=true;
} catch (error) { report.errors.push(String(error.stack || error)); }
finally {
  const waitExit = ms => new Promise(resolve => {
    if (browser.exitCode!==null || browser.signalCode!==null || !browser.pid) { resolve(browser.exitCode!==null || browser.signalCode!==null); return; }
    const done=()=>{clearTimeout(timer);resolve(true);};
    const timer=setTimeout(()=>{browser.off('exit',done);resolve(false);},ms);
    browser.once('exit',done);
  });
  if (ws?.readyState===1) { try { await Promise.race([call('Browser.close',{},null),sleep(2000)]); } catch (_) {} ws.close(); }
  const graceful=await waitExit(3000);
  if (!graceful && browser.pid) { try { browser.kill('SIGTERM'); } catch (error) { report.errors.push('browser stop: '+String(error)); } await waitExit(2000); }
  report.browserExitCode=browser.exitCode; report.browserSignal=browser.signalCode;
  report.browserClosedGracefully=graceful && browser.exitCode===0 && browser.signalCode===null;
  if (!report.browserClosedGracefully || report.errors.length) report.passed=false;
  fs.writeFileSync(reportFd,JSON.stringify(report,null,2)+'\n');fs.closeSync(reportFd);
  process.exitCode=report.passed ? 0 : 1;
}
