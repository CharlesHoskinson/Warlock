{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY; UNEXECUTED. The caller must root Probe, the supplied input handle,
-- and an independent child guardian before running, including the no-spawn
-- cases. QA hooks inject fixture-close failure only; they are not production.
module InputRetentionControls (Probe, newProbe, runFixtureFailure, runFixtureSuccess, runTicketFailure, runTicketSuccess, runFixtureStartupException, runTicketStartupException) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.IO (Handle, hClose, hIsClosed)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), SessionExit(..), newPersistentOwner,
  persistentStatus, persistentUnderlyingStatus,
  startBudgetAfter, startBudgetDeadline, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook, qaPersistentInputReferences, persistentFixture, persistentTicketFixture)
import Warlock.Capture.Process.Transfer.Internal
 (TransferTicket, TransferDisposition(..), fixtureTicketWithClose, transferDisposition)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe Handle)) (IORef (Maybe TransferTicket))
 (IORef (Maybe ThreadId)) (MVar ()) (MVar ()) (MVar Result) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError ("input-retention: " ++ name)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
expired :: AdmissionDeadline -> IO ()
expired d = do
 left <- remainingMicros d
 if left <= 0 then pure () else threadDelay (min 1000 left) >> expired d

data Kind = FixtureFail | FixturePass | TicketFail | TicketPass | FixtureException | TicketException
runFixtureFailure, runFixtureSuccess, runTicketFailure, runTicketSuccess, runFixtureStartupException, runTicketStartupException :: Probe -> Handle -> IO ()
runFixtureFailure = run FixtureFail
runFixtureSuccess = run FixturePass
runTicketFailure = run TicketFail
runTicketSuccess = run TicketPass
runFixtureStartupException = run FixtureException
runTicketStartupException = run TicketException

-- The externally guarded handle must be open; each call consumes a fresh Probe.
-- The fixture path is never intentionally spawned. A guard must still own any
-- child produced by a broken implementation.
run :: Kind -> Probe -> Handle -> IO ()
run kind (Probe owner handleCell ticketCell worker sampled resume done reserved used) input = mask $ \restore -> do
 first <- atomicModifyIORef' used (\v -> (True,not v))
 check "single use" first
 writeIORef handleCell (Just input)
 let failure = case kind of FixtureFail -> True; TicketFail -> True; _ -> False
     fixture = case kind of FixtureFail -> True; FixturePass -> True; FixtureException -> True; _ -> False
     exceptional = case kind of FixtureException -> True; TicketException -> True; _ -> False
     closeAction = if failure || exceptional then ioError (userError "injected actual transfer close failure") else hClose input
     hook stage = case stage of
      "persistent-before-spawn-reserve" | exceptional -> ioError (userError "injected startup action failure")
      "persistent-before-spawn-reserve" -> putMVar sampled () >> readMVar resume
      "persistent-after-spawn-reserve" -> atomicModifyIORef' reserved (\n -> (n+1,()))
      "qa-prespawn-input-close" | fixture && failure -> ioError (userError "injected fixture close failure")
      _ -> pure ()
     finish = do
      void (tryPutMVar resume ())
      thread <- readIORef worker
      case thread of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     body = do
      ticket <- if fixture then pure Nothing else do
       t <- fixtureTicketWithClose input closeAction
       writeIORef ticketCell (Just t)
       pure (Just t)
      let selected = case ticket of
           Nothing -> persistentFixture "/warlock-qa-never-spawn" [] input
           Just t -> persistentTicketFixture "/warlock-qa-never-spawn" [] t
      start <- startBudgetAfter 1000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selected 4096 start stop
        (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar done)
       writeIORef worker (Just tid)
       pure tid
      unless exceptional $ do
       within "prepared actual input before reserve" (readMVar sampled)
       within "same original startup deadline expires" (expired (startBudgetDeadline start))
       void (tryPutMVar resume ())
      result <- within "startup abort result" (readMVar done)
      count <- readIORef reserved
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      refs <- qaPersistentInputReferences owner
      closed <- hIsClosed input
      disposition <- traverse transferDisposition ticket
      check "no reservation" (count == 0)
      if exceptional then do
       let expectedRefs = if fixture then (1,0,False) else (0,1,True)
       check "startup action exception retains preowned input and quarantines" $
        refs == expectedRefs && (if fixture then closed else not closed) &&
        (case phase of PersistentQuarantined _ -> True; _ -> False) &&
        (case raw of Quarantined _ -> True; _ -> False) &&
        (case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False) &&
        (if fixture then disposition == Nothing else disposition == Just TransferUncertain)
      else if failure then do
       let expectedRefs = if fixture then (1,0,False) else (0,1,True)
       check "uncertain close retains actual owner references and no clean result" $
        refs == expectedRefs && not closed &&
        (case phase of PersistentQuarantined _ -> True; _ -> False) &&
        (case raw of Quarantined _ -> True; _ -> False) &&
        (case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False) &&
        (if fixture then disposition == Nothing else disposition == Just TransferUncertain)
      else check "confirmed close retires legacy owner and drops references" $
       refs == (0,0,False) && closed && phase == PersistentRetired && raw == Available &&
       (case result of Right (Left (StartupRefused TimedOut)) -> True; _ -> False) &&
       (if fixture then disposition == Nothing else disposition == Just TransferClosed)
 restore body `finally` finish
