# Warlock Homepage Staging, Byte-Check & Visual Verification Plan (`engine-pid1` Preparation)

> **Preparation Scope Notice**: This document is a preparation draft only under `.warlock-contributor/engine-pid1-drafts/homepage-stage-plan.md` (`gemini-site`). It performs zero repository product/model/tool edits, runs zero compilers/models/VMs, and claims neither delivery progress nor browser, native, AT, or release acceptance. Historical source-bound proofs (including the `9c432ddf` / `2e5730d2` `10`-check QMP receipt in `87029e7e8` and the `eb217829` / `81edb2c7` `architecture-024` capability-branch scenario verdict) retain their recorded source tuples and never transfer to new source or generated HTML.

---

## 1. Frozen Artifact & Repository Baseline Tuple

| Artifact | Path | Bytes / Lines | SHA-256 | Current Status |
| --- | --- | --- | --- | --- |
| Authored Elm homepage candidate | `/home/charl/code/Warlock/site/src/SiteMain.elm` | `68,121` B / `1,663` L | `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` | **FROZEN** (`3` dc5284 scope/contract/wrap refinements) |
| Website Elm manifest | `/home/charl/code/Warlock/site/elm.json` | `475` B / `25` L | `ffe9bc4f6811166a7bbafca49540bf7b8af214118dd9aff2f4707890eb9824dc` | **FROZEN** (`Browser.element`, zero ports/authored JS) |
| Protected `--site` compile output | `/home/charl/code/Warlock/.warlock-contributor/haskell-cpu-1793533581836712578/site-build/site.html` | `196,342` B / `7,564` L (no trailing LF) | `377bf031a4415887f0ff71ed8df5d7dbbcfea30d852494ec2ab0262a787d69a9` | **COMPILED, UNPROMOTED** |
| Published repository bootstrap | `/home/charl/code/Warlock/site/index.html` | `191,648` B / `7,500` L (no trailing LF) | `2e5730d25fdc15b5c64197351d2c772021f5ad23a07887789793c8ec16ae69f2` | **FROZEN** (`9c432ddf` promotion; QMP proof in `87029e7e8` stays bound to `9c432ddf`/`2e5730d2`) |
| Shared runtime guard commit | `implementation/warlock/haskell/runtime/src/Warlock/Ui/ThreadNamespace.hs` (`0d0bfd8595680096c4c1c145f553be0931cdd2f0`) | `17` L | `3a8504a5dd8fb4dac2b7c721da5e141cf571dae18f5c814dfd11bb5ebb8f3e2f` | Verified fail-closed (`7` runtime suites + guest controlled refusal `negative05`); makes prior `eb217829` tuple historical |

---

## 2. Exact Metadata Wrapper & Deterministic Byte-Check Contract

Elm's standalone HTML output (`site.html` `377bf031...`) emits a minimal `<head>` (`<meta charset="UTF-8">`, `<title>SiteMain</title>`, reset `<style>`) without the document-level attributes, responsive `<meta name="viewport">`, page description, or `class="wl-landing-page"` body attributes present on `site/index.html` (`2e5730d2...`).

To stage the compiled `f05a3768` candidate **without altering a single byte of compiler-emitted JavaScript** and **without mutating `site/index.html` before Root headed verification**, Root constructs the staged `index.html` outside the repository by concatenating two exact slices:

### 2.1 Slice Specification

1. **Metadata Prefix (`index_prefix`)**:
   - Source: `/home/charl/code/Warlock/site/index.html` (`sha256:2e5730d25fdc15b5c64197351d2c772021f5ad23a07887789793c8ec16ae69f2`)
   - Byte slice: `index_bytes[0:546]` (lines `1–14`, ending immediately before `<script>\n`)
   - Exact length: **`546` bytes**
   - Exact digest: **`sha256:46601149d80ede5425f75c21f197159e6b048db7d9a833a15996728d3c75e51e`**
   - Exact HTML carried:
     ```html
     <!DOCTYPE HTML>
     <html lang="en" data-warlock-design="v1" data-theme="night">
     <head>
       <meta charset="UTF-8">
       <title>Warlock · An Elm and Haskell desktop for Omarchy</title>
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <meta name="description" content="Explore Warlock’s Lacquer design, interactive Elm desktop previews, and the developing Elm and Haskell beta.">
       <style>body { padding: 0; margin: 0; }</style>
     </head>

     <body data-page="index.html" data-root="./" class="wl-landing-page">

     <pre id="elm"></pre>

     ```
   - Invariant: **zero `<script>` tags and zero authored JavaScript** in `index_prefix`.

2. **Compiled Payload Suffix (`site_suffix`)**:
   - Source: `/home/charl/code/Warlock/.warlock-contributor/haskell-cpu-1793533581836712578/site-build/site.html` (`sha256:377bf031a4415887f0ff71ed8df5d7dbbcfea30d852494ec2ab0262a787d69a9`)
   - Byte slice: `site_bytes[169:196342]` (lines `13–7564`, from `<script>\n` through `</html>` EOF; no trailing newline)
   - Exact length: **`196,173` bytes** (`196,156`-byte `<script>...</script>` block + `17`-byte `\n\n</body>\n</html>` trailer)
   - Exact `<script>...</script>` slice (`site_bytes[169:196325]`): **`196,156` bytes**, **`sha256:19b0be4f80135474b3cd62f9c327195a0575c15023dfcda2a460baa09f7193fb`**
   - Exact suffix digest: **`sha256:edd3a1903ee39394e9367f2a2e7f1e57b311939523d84e2a969d7ff3c1b8a4d7`**

3. **Expected Staged Candidate (`candidate_index = index_prefix + site_suffix`)**:
   - Exact length: **`196,719` bytes** (`546 + 196,173`)
   - Exact line count: **`7,566` lines** (`ends_with_lf = False`, matching `site.html` and `site/index.html`)
   - Exact digest: **`sha256:a8eb6478351f3dfb25501ba4c3ce05d32aa02c5a61a49fe4f101e77d0f9e1e60`**

### 2.2 Root Outside-Repo Staging & Byte-Verification Command

Root stages all `607` files (`606` unchanged `site/` sibling assets/pages + wrapped `index.html` `a8eb6478...`) into a fresh outside-repo staging directory (e.g., `/tmp/warlock-homepage-candidate-02` on host, then copied to `~/warlock-homepage-candidate-02` in the isolated Omarchy guest) while keeping `/home/charl/code/Warlock/site/index.html` untouched:

```python
# Root-only deterministic staging + byte-invariant check (do not run from worker lane)
import hashlib, pathlib, shutil

repo_site = pathlib.Path("/home/charl/code/Warlock/site")
compiled_html = pathlib.Path(
    "/home/charl/code/Warlock/.warlock-contributor/haskell-cpu-1793533581836712578/site-build/site.html"
)
stage_dir = pathlib.Path("/tmp/warlock-homepage-candidate-02")

idx_bytes = (repo_site / "index.html").read_bytes()
site_bytes = compiled_html.read_bytes()

assert hashlib.sha256(idx_bytes).hexdigest() == "2e5730d25fdc15b5c64197351d2c772021f5ad23a07887789793c8ec16ae69f2"
assert hashlib.sha256(site_bytes).hexdigest() == "377bf031a4415887f0ff71ed8df5d7dbbcfea30d852494ec2ab0262a787d69a9"

prefix = idx_bytes[: idx_bytes.index(b"<script>\n")]
s_start = site_bytes.index(b"<script>\n")
s_end = site_bytes.index(b"</script>") + len(b"</script>")
script_block = site_bytes[s_start:s_end]
suffix = site_bytes[s_start:]
candidate = prefix + suffix

assert len(prefix) == 546 and b"<script" not in prefix.lower()
assert hashlib.sha256(prefix).hexdigest() == "46601149d80ede5425f75c21f197159e6b048db7d9a833a15996728d3c75e51e"
assert len(script_block) == 196156
assert hashlib.sha256(script_block).hexdigest() == "19b0be4f80135474b3cd62f9c327195a0575c15023dfcda2a460baa09f7193fb"
assert len(suffix) == 196173
assert hashlib.sha256(suffix).hexdigest() == "edd3a1903ee39394e9367f2a2e7f1e57b311939523d84e2a969d7ff3c1b8a4d7"
assert len(candidate) == 196719
assert hashlib.sha256(candidate).hexdigest() == "a8eb6478351f3dfb25501ba4c3ce05d32aa02c5a61a49fe4f101e77d0f9e1e60"

# Verify embedded <script> in candidate is byte-identical to compiler output
c_start = candidate.index(b"<script>\n")
c_end = candidate.index(b"</script>") + len(b"</script>")
assert candidate[c_start:c_end] == script_block

if stage_dir.exists():
    shutil.rmtree(stage_dir)
shutil.copytree(repo_site, stage_dir)
(stage_dir / "index.html").write_bytes(candidate)
assert sum(1 for p in stage_dir.rglob("*") if p.is_file()) == 607
```

---

## 3. Alignment with `engine-pid1` Contracts & Canonical Ledger (`242` / `417`)

The homepage is an external documentation artifact (`site/`), never a policy fork or native runtime witness. Every status claim on `SiteMain.elm` (`f05a3768`) and any subsequent post-`engine-pid1` copy update must preserve the exact boundaries established by independent review and `docs/HANDOFF.md`:

1. **Canonical Requirement & Scenario Counts**:
   - **`242` original requirements** and **`417` original scenarios** remain binding with original latency deadlines (`D`), literal oracles, failed evidence (`B14`, standalone `run01`/`run02`, CSP `negative01`/`03`/`04`/`05`), and stop histories (`HOSTSTOP2`) preserved.
   - **`15` whole original requirements** (`15 / 242`) hold historical source-scoped acceptance in `docs/warlock-build-loop/v2/requirement-ledger.json`.
   - **`39` scenarios** (`39 / 417`) hold source-bound acceptance on their historical tuples, including the `architecture-024` privileged-capability OR branch (`81edb2c79`) on `eb2178293`. Subsequent runtime/guard commits (`0d0bfd859`) make `eb2178293` historical; **no acceptance transfers automatically**.
   - **Whole `ELM-ARC-024` remains partial/OPEN** (navigation/resource decision integration pending), **`ELM-DEL-014` remains OPEN** (execution-negative CSP proof pending; missing child receipts and controlled guard refusals are not CSP enforcement proof), and **native MVP / AT / IME / release acceptance remain OPEN**.

2. **Alignment with Reviewed `engine-pid1` Architecture Preparation**:
   - Current committed source (`0d0bfd859`) enforces `Warlock.Ui.ThreadNamespace.requireThreadCompatibleNamespace` (`sha256:3a8504a5...`), failing closed before GTK initialization when `/proc/thread-self/ns/pid` differs from `/proc/thread-self/ns/pid_for_children` (`negative05` controlled refusal in `0.5498s` within the `4.5s` bound).
   - Minimum independent review authorizes **preparation only** of the strict **broker / exec-PID1 engine split**:
     - **Broker / Selected Owner**: Retains inherited native `fd 0` (`SO_PEERCRED` + binding + private `CLONE_NEWUSER | CLONE_NEWNET` witness), **pinned held-executable lease** (`Warlock.Platform.Executable` + explicit FD whitelist), **one sole child reaper** in `warlock-process-custody` (no competing `EngineCustody` `waitid` on that child), and the **unchanged original monotonic deadline `D`**.
     - **Exec-PID1 Engine**: Runs GTK4 / WebKitGTK 6.0 as actual `PID 1` in its compatible PID namespace (`pid == pid_for_children`), never receiving `fd 0` or native peer authority, verifying lifeline after `PR_SET_PDEATHSIG` (since namespace-local `ppid == 0` does not prove a live parent), and keeping process exit, GObject/callback retirement, provider confinement, and filter-store backing cleanup separate (`wholeClean` never inferred from namespace exit alone).
     - **Inner Broker-Engine RPC**: Fixed binary framing (`<= 393,216` B conservative `3x` `StrictJson` projection bound + fixed header, checked before allocation without wrapper depth inflation), **per-fragment `SCM_CREDENTIALS` verification** against the owned engine identity, and **finite read-only/event `UiEndpoints` callbacks** (`uiShouldStop`, `uiRemainingMicros`, `uiLastProjection`, `TrustedOwnerEvent` forwarding with non-fatal `"stale native UI projection"` handling) holding **no `Owner` queue/scope `MVar` locks across IPC** and preserving original `D`.
   - Homepage copy must **never** describe `engine-pid1` drafts, `ThreadNamespace` guard refusals, or the `15s` permissive CSP sensitivity control as a working native desktop or accepted `ELM-ARC-024`/`ELM-DEL-014` gate.

---

## 4. Narrow Actual Visual Verification Plan for Staged `a8eb6478` (`SiteMain.elm` `f05a3768`)

Root executes a fresh headed Chromium / physical QMP inspection against guest-staged `~/warlock-homepage-candidate-02/index.html` (`sha256:a8eb6478...`), preserving guest `Foot` and idle state and claiming zero carryover from `9c432ddf` / `2e5730d2` (`87029e7e8`):

1. **Horizontal Overflow & Responsive Geometry (`1280x800`, `621x800` `200%`-zoom equivalent, `320x640`)**:
   - Assert `document.documentElement.scrollWidth <= window.innerWidth` in all three themes (`data-theme="night"`, `"dawn"`, `"high-contrast"` on `.wl-home-root`).
   - At `621px` and `320px`, verify `.wl-home-readiness-strip` wraps cleanly across columns/stack without badge clipping, horizontal scrollbar, or overlapping borders.
2. **Verify the Three `f05a3768` Refinements Visually & Semantically**:
   - **Tiered Readiness Strip (`.wl-home-readiness-strip`)**: Renders all four distinct tiers (`Browser simulated`, `Component + Quint`, `15 / 242 requirements`, `Native MVP & release OPEN` with `417 scenario obligations · ARC-024, DEL-014 & native AT gates OPEN`).
   - **Workbench Contract & Simulated CTA (`#wl-workbench-panel`, `SiteMain.elm:1070-1095`)**: Displays `Target Haskell / Hyprland contract` heading (replacing `Host observation workbench`) and appends `(simulated stage)` to the primary scenario CTA link.
   - **Outcome Lab Preview Badge & Label Wrapping (`SiteMain.elm:1025-1068, 1290-1365`)**: Displays the `Model preview` badge alongside interactive outcome states, wraps long status/receipt strings via `min-width: 0` + `overflow-wrap: anywhere`, and keeps `:focus-visible` outlines (`2px` accent outline + offset) unclipped across `Night`, `Dawn`, and `High-Contrast`.
3. **Keyboard Roving Tablist & Mobile Drawer (`ARIA` / Physical Key Dispatch)**:
   - Focus `#wl-tab-taskbar`, dispatch `ArrowRight`, `End`, `Home`, `ArrowLeft`, and `Enter`; verify `document.activeElement.id` and `aria-selected="true"` track the focused surface tab (`#wl-tab-taskbar` .. `#wl-tab-files`) and `#wl-workbench-panel` updates synchronously.
   - At `320x640`, activate `.wl-home-nav-toggle` (`aria-controls="wl-home-nav-drawer"`), verify `aria-expanded="true"`, dispatch `Escape` (`decodeEscapeKey`), and verify drawer closes (`aria-expanded="false"`).
4. **Promotion Gate**:
   - Only after all headed checks above pass on `a8eb6478...` does Root copy `candidate` (`196,719` B, `sha256:a8eb6478...`) to `/home/charl/code/Warlock/site/index.html` under Root's protected lane.

---

## 5. `ELM-ARC-002` & Dual-Path Trial Drop-In Source Candidate (`HomepageCandidate.elm`)

Alongside the frozen `f05a3768` staging receipt above, a complete Elm 0.19.2 drop-in source candidate is prepared at:

- **Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/HomepageCandidate.elm`
- **Metrics & Digest**: **`85,823` bytes**, **`1,949` lines**, **`sha256:3770ea32ed1ee923c4219c75e2366beb68b068c6007085c4f771013cdd3fba29`**
- **Module Contract**: `module SiteMain exposing (AppearanceTheme(..), CueFacts, Model, MotionMode(..), Msg(..), OutcomeSample(..), SurfaceCategory(..), SurfaceId(..), init, main, update, view, viewDocument)` — uses **only** existing `site/elm.json` (`ffe9bc4f...`) direct packages (`elm/browser`, `elm/core`, `elm/html`, `elm/json`), zero ports, zero new JavaScript, `@layer components` specificity aligned with `site/assets/shared/landing.css`, and zero missing `./` routes or assets (`35` verified internal `#` anchor IDs, `43` verified `href`/`src` targets).

### 5.1 Upgrades Included in `HomepageCandidate.elm` (`3770ea32...`, synced with `MvpLayout.patch` `23e2e146...`)
1. **Active Slice & Canonical Ledger Accuracy**:
   - Replaces stale `ELM-UI-007 slice active` copy with **`ELM-ARC-002` (`ownership-presentation` / `architecture-002`) & non-threaded broker / `HeldExecutable` `exec`-PID1 engine split** in active integration.
   - Cites **`15 / 242` whole requirements** and **`39 / 417` scenarios** accepted on historical source-scoped records (`ARC-024` partial/OPEN, `ELM-DEL-014` OPEN, stopped `ui-origin` history preserved without reset, `HOSTSTOP2`, `NativeOps []`, and original monotonic deadlines `D` preserved).
2. **Dual-Path Run & Trial Section (`section#trial` + Hero `#trial` Tonal CTA)**:
   - `#wl-trial-simulated`: deterministic browser test drive (`./test-drive/index.html`, `16` seeded scenarios) and frozen v6 catalog (`./reference/catalog/v6/index.html`) explicitly scoped as client-side fixtures.
   - `#wl-trial-app-only`: standalone Omarchy Wayland application-only beta path (`applicationAttachment: true` -> `protocolVersion: 3`, `"kind": "application-attached"`, **`"nativeOperations": []`** -> `Shell.applicationOnly = True`), detailing the single undecorated `GtkWindow` (`gtk_window_set_decorated 0`, `980x680` default), `GtkOverlay` packing (`56px` `Bar` + `480x360` min `Popup` + non-measuring `1x1` untargetable `Controller` with `data-warlock-role="controller"|"bar"|"popup"`), enabled catalog/search/pin/refresh vs disabled window/launch/jump controls, verified `ThreadNamespace` (`0d0bfd859`) fail-closed guard, and active broker/`exec`-PID1 gate under original `<= 28s` deadline `D` (routing primary CTA to `#architecture` on-page and secondary CTA to `./get-started/contributing/index.html`, while noting `./architecture/index.html` retains the historical v1 component-flow explorer).
3. **Approved `ELM-ARC-002` EARS Callout & Custody / Role Matrices (`section#architecture`)**:
   - `#wl-arc-002-callout`: quotes the approved `ELM-ARC-002` EARS sentence and both literal scenario oracles (`architecture-002` and `ownership-presentation`) verbatim as OPEN.
   - `.wl-home-custody-grid`: 4-plane ownership breakdown (`Elm DOM & Policy Authority`, `Haskell Broker (warlock-ui-owner)`, `Exec-PID1 Display Engine (warlock-ui-engine)`, `Backend & Single Native Authority`).
   - `.wl-home-role-grid`: 3 loopback UI role cards (`Controller` / `HttpMain.elm`, `Bar` / `HttpBar.elm`, `Popup` / `HttpPopup.elm`).

### 5.2 Root Drop-In Build & Metadata-Wrapper Sequence for `HomepageCandidate.elm`
1. Under Root's serialized lock, copy `HomepageCandidate.elm` (`3770ea32...`) to `/home/charl/code/Warlock/site/src/SiteMain.elm` and run `python3 -B tools/check_haskell_cpu.py --site`.
2. Concatenate the unchanged `546`-byte `index_prefix` (`sha256:46601149d80ede5425f75c21f197159e6b048db7d9a833a15996728d3c75e51e`, zero `<script>` tags) with the new `site.html[site.html.index(b"<script>\n"):]` suffix into a fresh outside-repo staging directory (`/tmp/warlock-homepage-candidate-03`), asserting byte-identical `<script>...</script>` payload and `607` staged files.
3. Run the Section 4 headed Chromium / QMP checks at `1280x800`, `621x800`, and `320x640` plus DOM assertions on `#trial`, `#wl-trial-simulated`, `#wl-trial-app-only`, `#wl-arc-002-callout`, `.wl-home-custody-grid`, and `.wl-home-role-grid` (`scrollWidth <= innerWidth` across `Night`, `Dawn`, and `High-Contrast`) before promoting to `site/index.html`.
