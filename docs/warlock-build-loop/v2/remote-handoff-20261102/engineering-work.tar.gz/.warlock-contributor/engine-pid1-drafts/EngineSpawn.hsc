{-# LANGUAGE ForeignFunctionInterface #-}
-- PREPARATION DRAFT ONLY: not integrated, compiled, run, or accepted.
-- Proposed package-internal child half of the EngineCustody-owned PID1 path.
-- The Haskell post-fork/RTS safety proof is OPEN. Do not ship or call this
-- until the independent review and root's actual tests pass. The parent half,
-- held-image lease API, fd validator, RPC and engine-only dispatcher do not
-- exist here; no child can legitimately be launched by this file on its own.
--
-- Required parent ordering: verify one OS thread and SIGCHLD ownership; keep
-- the peer witness and original deadline D; adopt the native endpoint and bind
-- three listeners without starting any workers; prepare and pin all C strings,
-- argv/envp and poll storage below while masked; duplicate exactly the held
-- image, RPC and lifeline through the narrow fixed-trio acquisition below,
-- using withFdSocket while borrowing the original Socket. The owner records
-- raw duplicates only: no Socket, Handle, ForeignPtr, or FD finalizer wraps
-- them. Check all FDs and identities. The fixed image is the SAME held ELF and argv is the approved
-- engine-only mode. No arbitrary executable, argv or descriptor API is public.
--
-- EngineCustody is the ONLY PID1 signalling and reaping authority. Retain PID,
-- pidfd, birth/image/namespace evidence and resources atomically; failures at
-- any step must terminate/reap through that owner or quarantine the parent.
-- Do not use process-custody's group reaper for this child. Parent must not
-- start native/HTTP workers until ownership publication and engine startup
-- protocol are safely established. Any CLONE_NEWPID-for-children failure after
-- unshare requires exiting the parent; the namespace cannot be reset.
--
-- Finite child manifest: RPC socket and lifeline read are distinct FDs >= 3;
-- image FD is distinct >= 3 and remains CLOEXEC. All other descriptors,
-- including inherited native fd0, listeners, parent lifeline writer and
-- stdout/stderr, stay CLOEXEC. No dup2, close or new FD allocation before exec:
-- this avoids *close_range itself* recycling a managed FD number in copied
-- heap. Raw duplicates remove the ordinary original Socket finalizer from
-- ownership of those numbers, conditional on an audit ruling out stale numeric
-- finalizers and other foreign close paths. This does NOT prove RTS safety.
-- Engine must reserve harmless stdio after exec, before other libraries open
-- FDs, and restore CLOEXEC on RPC/lifeline after adopting them. Establish that
-- missing stdio during loader startup is safe or revise through reviewed plan.
--
-- Child code below is deliberately a concrete syscall sketch, not an assertion
-- that evaluating Haskell after fork is async-signal-safe or free of GC. No
-- exception handling, allocation, ThreadDelay, forkIO, console IO or user
-- callbacks are allowed in child. Prove pinned RTS behavior, FFI calls, pointer
-- lifetime and finalizer isolation before replacing this with production code.
module Warlock.Ui.EngineSpawnDraft (ChildInputs(..), retainEngineRoles, childSetupExec) where

#define _GNU_SOURCE
#include <sched.h>
#include <sys/mount.h>
#include <sys/syscall.h>
#include <sys/prctl.h>
#include <linux/close_range.h>
#include <linux/capability.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>

import Control.Exception (mask_)
import Data.Bits ((.&.), (.|.), complement)
import Data.Word (Word32)
import Foreign (Ptr, nullPtr, pokeByteOff, peekByteOff, fillBytes)
import Foreign.C (CChar, CInt, CLong, CShort, CUInt, CULong, CString)

foreign import ccall unsafe "unshare" c_unshare :: CInt -> IO CInt
foreign import ccall unsafe "mount" c_mount :: CString -> CString -> CString -> CULong -> Ptr () -> IO CInt
foreign import ccall unsafe "prctl" c_prctl :: CInt -> CULong -> CULong -> CULong -> CULong -> IO CInt
foreign import ccall unsafe "getpid" c_getpid :: IO CInt
foreign import ccall unsafe "getppid" c_getppid :: IO CInt
foreign import ccall unsafe "fcntl" c_fcntl :: CInt -> CInt -> CInt -> IO CInt
foreign import ccall unsafe "poll" c_poll :: Ptr () -> CULong -> CInt -> IO CInt
foreign import ccall unsafe "syscall" c_closeRange :: CLong -> CUInt -> CUInt -> CUInt -> IO CLong
foreign import ccall unsafe "syscall" c_execveat :: CLong -> CInt -> CString -> Ptr CString -> Ptr CString -> CInt -> IO CLong
foreign import ccall unsafe "syscall" c_capset :: CLong -> Ptr () -> Ptr () -> IO CLong
foreign import ccall unsafe "syscall" c_capget :: CLong -> Ptr () -> Ptr () -> IO CLong
foreign import ccall unsafe "_exit" c_exit :: CInt -> IO ()

-- PARENT-SIDE FIXED-TRIO ACQUISITION SKETCH; package-owned only, not a general
-- descriptor executor. Slots must be separately allocated and retained in an
-- already published EngineCustody pending record BEFORE this call. Three CInt
-- slots, initially -1, represent image/RPC/lifeline in that order. `srcImage`
-- is a held same-image lease, `srcRpc` is obtained INSIDE withFdSocket, and
-- `srcLife` is the owned read end. Caller independently verifies each source
-- and each duplicate identity and holds the original owners during the call.
-- No close happens here: on any False/exception the pending owner retains
-- every nonnegative slot and resolves cleanup exactly once or quarantines.
-- The unsafe FFI call, immediate raw slot write and masked publication gap,
-- including synchronous failure/GC, require actual runtime review; masking
-- alone is not a proof of atomicity. Parent must preclude stale FD finalizers
-- and unexpected competing thread/foreign FD mutations throughout handoff.
retainEngineRoles :: Ptr () -> CInt -> CInt -> CInt -> IO Bool
retainEngineRoles slots srcImage srcRpc srcLife = mask_ $ do
 let stride = #{size int}
     copyOne source index = do
      fd <- c_fcntl source #{const F_DUPFD_CLOEXEC} 3
      if fd < 0 then pure False else do
       -- No fallible identity lookup or Socket allocation before retention.
       pokeByteOff slots (index * stride) fd
       pure True
 if srcImage < 0 || srcRpc < 0 || srcLife < 0
    || srcImage == srcRpc || srcImage == srcLife || srcRpc == srcLife
  then pure False else do
   a <- copyOne srcImage 0
   if not a then pure False else do
    b <- copyOne srcRpc 1
    if not b then pure False else copyOne srcLife 2

-- All memory and owners are retained in the parent until the child execs or is
-- reaped. pollSlot has sizeof(struct pollfd) bytes allocated before fork.
-- External callers must NEVER construct this: it stands in for the missing
-- package-owned validated capability and only documents the concrete inputs.
data ChildInputs = ChildInputs
  { imageFd :: !CInt, rpcFd :: !CInt, lifeFd :: !CInt
  , emptyPath :: !CString, rootPath :: !CString, procPath :: !CString
  , procType :: !CString, childArgv :: !(Ptr CString), childEnv :: !(Ptr CString)
  , pollSlot :: !(Ptr ())
  -- Pinned parent-allocated buffers: cap header and two v3 capability words.
  -- Parent obtains kernel cap_last_cap before fork, rejects malformed or >1024.
  , capHeader :: !(Ptr ()), capData :: !(Ptr ()), capLast :: !CInt
  }

-- Must run after the mount and before exec, GTK, helper creation or any
-- authenticated engine message. Bounding drop needs CAP_SETPCAP, so it must
-- precede clearing permitted/effective sets. A partial operation is fatal.
-- capLast comes from a validated actual-kernel read, not a compiled constant.
-- This Haskell recursion and FFI are STILL subject to the open post-fork RTS
-- safety proof; all buffers must have been allocated before fork.
dropCapabilities :: ChildInputs -> IO Bool
dropCapabilities p = do
 let lastCap = capLast p
     eachDrop n | n > lastCap = pure True
                | otherwise = do
                    result <- c_prctl #{const PR_CAPBSET_DROP} (fromIntegral n) 0 0 0
                    if result /= 0 then pure False else eachDrop (n+1)
     eachCheck n | n > lastCap = pure True
                 | otherwise = do
                    bound <- c_prctl #{const PR_CAPBSET_READ} (fromIntegral n) 0 0 0
                    ambient <- c_prctl #{const PR_CAP_AMBIENT} #{const PR_CAP_AMBIENT_IS_SET} (fromIntegral n) 0 0
                    if bound /= 0 || ambient /= 0 then pure False else eachCheck (n+1)
 if lastCap < 0 || lastCap > 1024 then pure False else do
  dropped <- eachDrop 0
  if not dropped then pure False else do
   ambient <- c_prctl #{const PR_CAP_AMBIENT} #{const PR_CAP_AMBIENT_CLEAR_ALL} 0 0 0
   if ambient /= 0 then pure False else do
    fillBytes (capHeader p) 0 #{size struct __user_cap_header_struct}
    pokeByteOff (capHeader p) #{offset struct __user_cap_header_struct, version} (#{const _LINUX_CAPABILITY_VERSION_3} :: Word32)
    fillBytes (capData p) 0 (2 * #{size struct __user_cap_data_struct})
    cleared <- c_capset #{const SYS_capset} (capHeader p) (capData p)
    if cleared /= 0 then pure False else do
     noPrivs <- c_prctl #{const PR_SET_NO_NEW_PRIVS} 1 0 0 0
     if noPrivs /= 0 then pure False else do
      -- Sentinel first, so a failed or partial read is never mistaken for zero.
      fillBytes (capData p) 255 (2 * #{size struct __user_cap_data_struct})
      got <- c_capget #{const SYS_capget} (capHeader p) (capData p)
      if got /= 0 then pure False else do
       a <- peekByteOff (capData p) 0 :: IO Word32
       b <- peekByteOff (capData p) 4 :: IO Word32
       c <- peekByteOff (capData p) 8 :: IO Word32
       d <- peekByteOff (capData p) 12 :: IO Word32
       e <- peekByteOff (capData p) 16 :: IO Word32
       f <- peekByteOff (capData p) 20 :: IO Word32
       if a /= 0 || b /= 0 || c /= 0 || d /= 0 || e /= 0 || f /= 0
        then pure False else eachCheck 0

-- Parent validates actual held image / FD identities and exact engine-only
-- argument/environment; range, collision and ownership checks are repeated
-- below. F_GETFD identifies an already closed descriptor only; it is not proof
-- of underlying identity. Authentication and readiness happen AFTER exec.
childSetupExec :: ChildInputs -> IO ()
childSetupExec p = do
 let image = imageFd p; rpc = rpcFd p; life = lifeFd p
     failChild = c_exit 121
     valid = image >= 3 && rpc >= 3 && life >= 3
          && image /= rpc && image /= life && rpc /= life
 if not valid then failChild else do
  local <- c_getpid
  parent <- c_getppid
  -- Outside-namespace parent appears as zero, not as proof of liveness.
  if local /= 1 || parent /= 0 then failChild else do
   death <- c_prctl #{const PR_SET_PDEATHSIG} #{const SIGKILL} 0 0 0
   if death /= 0 then failChild else do
    -- Parent-only writer is retained by the broker, never inherited past exec.
    pokeByteOff (pollSlot p) #{offset struct pollfd, fd} life
    pokeByteOff (pollSlot p) #{offset struct pollfd, events} (#{const POLLIN} :: CShort)
    pokeByteOff (pollSlot p) #{offset struct pollfd, revents} (0 :: CShort)
    alive <- c_poll (pollSlot p) 1 0
    events <- peekByteOff (pollSlot p) #{offset struct pollfd, revents} :: IO CShort
    -- EOF/HUP, data, error and EINTR all refuse; no retry after uncertainty.
    if alive /= 0 || events /= 0 then failChild else do
     moved <- c_unshare #{const CLONE_NEWNS}
     if moved /= 0 then failChild else do
      private <- c_mount nullPtr (rootPath p) nullPtr
         (#{const MS_REC} .|. #{const MS_PRIVATE}) nullPtr
      if private /= 0 then failChild else do
       proc <- c_mount (procType p) (procPath p) (procType p)
          (#{const MS_NOSUID} .|. #{const MS_NODEV} .|. #{const MS_NOEXEC}) nullPtr
       if proc /= 0 then failChild else do
        capsClear <- dropCapabilities p
        if not capsClear then failChild else do
        -- Mark, do not close: preserve copied-heap descriptor numbering.
         marked <- c_closeRange #{const SYS_close_range} 0 (maxBound :: CUInt) #{const CLOSE_RANGE_CLOEXEC}
         if marked /= 0 then failChild else do
          rpcFlags <- c_fcntl rpc #{const F_GETFD} 0
          lifeFlags <- c_fcntl life #{const F_GETFD} 0
          imageFlags <- c_fcntl image #{const F_GETFD} 0
          if rpcFlags < 0 || lifeFlags < 0 || imageFlags < 0
            || imageFlags .&. #{const FD_CLOEXEC} == 0
           then failChild else do
            a <- c_fcntl rpc #{const F_SETFD} (rpcFlags .&. complement #{const FD_CLOEXEC})
            b <- c_fcntl life #{const F_SETFD} (lifeFlags .&. complement #{const FD_CLOEXEC})
            if a /= 0 || b /= 0 then failChild else do
            -- Only the same verified held ELF; not a path lookup. An ELF
            -- loader, kernel and executable-FD CLOEXEC combination must be
            -- proven in the exact target; scripts/interpreters are excluded.
             _ <- c_execveat #{const SYS_execveat} image (emptyPath p)
                  (childArgv p) (childEnv p) #{const AT_EMPTY_PATH}
             failChild

-- MANDATORY MISSING INTEGRATION / REVIEW (do not paper over these with success):
-- 1. There is no public selected FD plan/lease in current process-custody;
--    Whitelist is private. Add a narrow reviewed owned validator/facade rather
--    than importing constructors, inventing grants or copying its executor.
-- 2. EngineCustody currently forks a lifeline-only PID1 and has its own ready,
--    pidfd, signal and waitid. Refactor that existing owner to invoke this
--    fixed child only after audited publication; do not layer a second reaper.
-- 3. Owner currently starts native/HTTP workers immediately after binding; split
--    bind/launch while preserving actual socket ownership, peer provenance,
--    cancellation and original D. withFdSocket must span the fork/exec handoff.
-- 4. Verify post-exec death-signal semantics and lifeline again before ready,
--    and throughout life; initial poll does not by itself cover exec changes.
--    Verify local PID1, namespace IDs and proc mount, held image, exact PID and
--    birth from parent, credentials on EVERY RPC fragment, FD census, and D.
--    Startup-ready is not provider-ready or native/ARC024/DEL014 acceptance.
-- 5. Prove the drop order and exact ABI above on target, verify every capability
--    set and no_new_privs AGAIN after exec before GTK/helpers/messages, and prove
--    capabilities for mount before exec, private propagation, close_range
--    kernel support, same ELF/loader execution and strict per-fragment SCM
--    identity. Fatal syscall errors, signals, deadline expiry, uncertain close
--    and unknown reap remain failures. Root owns all tests and evidence.
-- 6. Strongest unresolved issue: Haskell actions even after single-threaded
--    fork can allocate, run GC/finalizers or interact with RTS state. Retaining
--    Socket handles alone and marking CLOEXEC are NOT proof against that. An
--    unsafe-to-prove path stays blocked; do not introduce a C helper against
--    the existing Elm/Haskell production-language rule or weaken topology.
