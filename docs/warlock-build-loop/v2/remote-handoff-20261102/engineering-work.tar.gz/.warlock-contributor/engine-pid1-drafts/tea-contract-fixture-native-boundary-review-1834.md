# Fixture-vs-Native Boundary & Policy Fixture Contract Review (`ELM-TEA-001` / `ELM-TEA-002`)

- **Reviewer**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`), run `warlock-20261031-setup`
- **Published Base Commit**: `31a92dce92538f5282643c006854e23294b15bbe` (`HEAD` on `main`)
- **Active Contributor Slice**: `/home/charl/code/Warlock/.warlock-contributor/tea-model-effects.json` (`ELM-TEA-001` `tea-typed-model`, `ELM-TEA-002` `tea-pure-update`; `ELM-TEA-005` remains queued and is **not** selected)
- **Preserved Delivery Baseline**: `242` original requirements / `417` scenarios, `15` historical whole requirements / `39` scenarios, original deadlines, failed/stopped histories, `HOSTSTOP2`, `nativeOperations = []`. Source-only review; zero compiler, Node, Quint, VM, QMP, or GPU execution performed.

## Reviewed Artifact Inventory (SHA-256)

| File | SHA-256 | Role |
| --- | --- | --- |
| `docs/elm-roadmap/requirements.json` | `d26c6d1e5b1f0bf7f92b66bc321eb428e50cf2b42694f4725e0e61c1d596267d` | Canonical 242/417 EARS register |
| `implementation/warlock/src/DesktopPolicy.elm` | `018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e` | Owning policy reducer & `Effect` union |
| `implementation/warlock/src/OutputController.elm` | `fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae` | Multi-output topology, batch registration & disposition |
| `implementation/warlock/src/SurfaceController.elm` | `2e86781c41c1b1c62d518e886ee965a875a04ea88980159a00511c549b25e998` | Publication/lease framing & reconciliation routing |
| `implementation/warlock/src/Desktop.elm` | `273622ad7a83a5538896b438831ffc705e3c38df9c1419ee0ec43cd5f81bec2c8` | Desktop domain state & `windowBase` |
| `implementation/warlock/src/Shell.elm` | `6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094` | Native connection & observation/effect state |
| `implementation/warlock/qa/TeaContractReplay.elm` | `cd0c08ac0d572943586d9cd9f01251d2055ad607cdeffbfa680646f50b30bb06` -> `a63153fc341d548a4382f78f6de331da62dd0d4882bb28d0c4e7dfd20387ed13` | Canonical QA replay worker (`q-front`) |
| `implementation/warlock/qa/tea-contract.cjs` | `8c88af33a71c73edf22195ec8cfa84e8e945b8a2d0c077d1b1926f48087af6d7` (+ `terra-q-origin-tea-input.patch` `68dc812687292a55048b55b6f959a98666bf1c51e559e63e33d0e3a3d73eb7a0`) | Canonical QA Node runner (`terra-q-origin`) |
| `implementation/warlock/qa/tea-contract-cases.cjs` | `34a4f0aca8d140dd9ce06f4a023f4c7e431b038810e03a2b934c7c1452d3954a` -> `3a9dba6077ef23badf73e44989dfd11bef776c00303a0990d21a9e76d2b4ce7d` | Canonical independent literal oracle (`terra-portable`) |

---

## 1. Fixture-vs-Native Verification Boundary for `ELM-TEA-001` & `ELM-TEA-002`

### 1.1 Exact Original Requirement Obligations (`docs/elm-roadmap/requirements.json`)

- **`ELM-TEA-001` (`tea-typed-model`)**:
  - *Clause*: *"The Warlock Elm application SHALL represent lifecycle, receipt and operation state with custom types, separating native observations from desired state."*
  - *Verification*: *"Typed compiler checks, deterministic replay and independent boundary fixtures with source hashes; native behavior qualified separately."*
  - *Scenario `tea-typed-model` `then` oracle*: *"the declared contract holds, exact models and effect descriptions match the fixture and no native acceptance is inferred"*.
- **`ELM-TEA-002` (`tea-pure-update`)**:
  - *Clause*: *"While running the Elm update loop, the Warlock Elm application SHALL compute next state and effect descriptions deterministically from the current model and incoming message."*
  - *Verification*: *"Typed compiler checks, deterministic replay and independent boundary fixtures with source hashes; native behavior qualified separately."*
  - *Scenario `tea-pure-update` `then` oracle*: *"the declared contract holds, exact models and effect descriptions match the fixture and no native acceptance is inferred"*.
- **Deferred Neighbor (`ELM-TEA-005` `tea-command-boundary`)**: Queued for a subsequent WIP slice; not selected in `.warlock-contributor/tea-model-effects.json` and must not be conflated with `TEA-001`/`TEA-002`.

### 1.2 Two-Sided Boundary Ruling

1. **No Synthetic Physical / VM / Omarchy Gate Required for `ELM-TEA-001` or `ELM-TEA-002`**:
   - Both original requirements explicitly define their acceptance mechanism as **typed compiler checks + deterministic replay + independent boundary fixtures with source hashes**, and explicitly state **"native behavior qualified separately"**.
   - Inventing a new QEMU/Omarchy physical GUI trial as a prerequisite to close `ELM-TEA-001` or `ELM-TEA-002` would contradict the literal original verification method. Once (a) all `ELM-TEA-001` custom-type obligations across the declared Elm modules hold, (b) `tea-contract-cases.cjs` reaches complete positive/negative/timer/receipt/disconnect/rebind coverage (`coverage.complete === true`), and (c) Root's protected `tools/qa_cpu.py` (`tools/check_elm_cpu.py --tea-contract`) and independent readiness review pass with bound source/compiler/toolchain hashes, `ELM-TEA-001` and `ELM-TEA-002` are eligible for whole-requirement disposition without a VM run.
2. **Zero Native, Frontend-DOM, Transport, Provider, or UX-Latency Acceptance May Be Inferred**:
   - `check_elm_cpu.py` already enforces `nativeAcceptance: False`, `releaseAccepted: False`, and `teaContract.nativeAccepted: False`. Reviewers and documentation (`site/`, `HANDOFF.md`, `STATE.json`) must preserve that passing `TeaContractReplay` proves **nothing** about:
     - **Compositor / Layer-Shell / Pointer Routing**: Hyprland/Wayland `zwlr_layer_shell_v1` exclusive zones, output hotplug geometry, surface keyboard/pointer focus grants, or pointer coordinate routing;
     - **WebKitGTK Renderer / DOM / IME / AT**: actual HTML/CSS layout, `Popup.Composition` IME composition events in WebKitGTK, ARIA live-region screen-reader delivery, or physical click/key translation;
     - **Haskell Owner & Transport Custody**: `Warlock/Ui/Owner.hs` endpoint role stamping, `CredentialIngress.hs` `SO_PEERCRED` verification, user/mount namespace ordering, or `HttpMain`/`HttpPopup` loopback HTTP transport stop behavior;
     - **Native Provider & UX Budgets**: DRM/provider cleanup (`providerCleanup`), `nativeOperations = []`, `HOSTSTOP2`, or end-to-end physical input-to-matching-result latency (`terra-browser`'s post-TEA UX measurement lane).

---

## 2. Concrete Audit of Policy Fixture Drafts (`TeaContractReplay.elm`, `tea-contract.cjs`, `tea-contract-cases.cjs`)

### 2.1 CRITICAL SHOWSTOPPER DEFECT in `tea-contract.cjs` (`8c88af33...` lines `73, 154, 198`) — `Object.create(null)` on Port Input Crashes Elm `D.keyValuePairs`

- **Exact Mechanism**:
  1. `full(value)` (`tea-contract.cjs:73`) normalizes every plain object into `const out = Object.create(null)` (`Object.getPrototypeOf(out) === null`).
  2. `validateCases()` (`tea-contract.cjs:154`) stores `const input = full(step.input, ...)`, which turns `step.input.value` and every nested object (`payload`, `views[0]`, `binding`, `scope`, etc.) into `Object.create(null)`.
  3. `executeCase()` (`tea-contract.cjs:198`) calls:
     ```js
     app.ports.incoming.send({ ...current.input, caseId: testCase.name, step: i });
     ```
     The top-level spread `{ ...current.input, ... }` restores `Object.prototype` **only** on the outer request envelope (`{ kind, value, caseId, step }`), so `TeaContractReplay.requestDecoder` (`TeaContractReplay.elm:86`, which uses `D.field`, not `D.keyValuePairs`) succeeds and passes `current.input.value` directly into `DesktopPolicy.incomingEvent` (`DesktopPolicy.elm:23`).
  4. `DesktopPolicy.incomingEvent` (`DesktopPolicy.elm:27`), `OutputController.strict` (`OutputController.elm:45`), `Binding.decoder` (`Binding.elm:11`), and `Desktop.strict` (`Desktop.elm:374`) all call `D.keyValuePairs D.value`.
  5. Pinned `elm/json 1.1.3` (`Elm/Kernel/Json.js:252-261`) implements `D.keyValuePairs` as:
     ```js
     for (var key in value)
     {
       if (value.hasOwnProperty(key))
       { ... }
     }
     ```
  6. Because `current.input.value` has `null` prototype, `value.hasOwnProperty` is `undefined`. Step `1` of the very first case (`empty-topology-publishes-complete-frame/1`) — and **17 of the 18 cases** in `tea-contract-cases.cjs` (every case except `outer-not-object` where `value === null`) — will throw **`TypeError: value.hasOwnProperty is not a function`** inside `app.ports.incoming.send(...)`!
- **Required Fix (`terra-q-origin` / `lead`)**:
  - Keep `full()` unchanged on `observed` (`tea-contract.cjs:105, 109`), `ack` (`line 187`), and `expected` (`line 157`) so `isDeepStrictEqual(observed, current.expected)` continues to compare `Object.create(null)` trees on both sides.
  - After `full(step.input, ...)` validates `step.input` (rejecting `-0`, non-finite numbers, symbols, accessors, sparse arrays, functions, cycles, and untrusted prototypes), convert `current.input` via a small helper `toPortValue(node)` (or instantiate inside `loadElm`'s `context`) that creates plain `{}` objects (`Object.prototype`) using `Object.defineProperty(out, key, { value: toPortValue(node[key]), enumerable: true, configurable: true, writable: true })` (so even a `"__proto__"` key remains an own data property without mutating prototypes) before `app.ports.incoming.send(...)`.

### 2.2 Verified Elm 0.19 Unoptimized (`Dev`) Layout & Edge-Case Notes

- **Compiler Flag & Kernel Symbols (`tools/check_elm_cpu.py:163`, `tea-contract.cjs:86-99`)**:
  - Verified against pinned `Elm/Kernel/Debug.js:12-21`, `Elm/Kernel/Json.js:418`, `Dict.elm:50`, and existing `--optimize` outputs (`Main.js:318-327`): running `[compiler, 'make', 'qa/TeaContractReplay.elm', '--output=...']` **without** `--optimize` compiles in Elm 0.19 `Dev` mode, which:
    1. Emits active `var _Debug_log = F2(function(tag, value) { console.log(tag + ': ' + _Debug_toString(value)); return value; });` (matching `tea-contract.cjs:86-93`, whereas `_Debug_log_UNUSED` will not match `/var _Debug_log\s*=/`);
    2. Emits `_Json_wrap` as `function(value) { return { $: 0, a: value }; }` (matching `{ $: 'Publish', a: { $: 0, a: packet } }` in `tea-contract-cases.cjs:231, 372`);
    3. Emits 2-tuples as `{ $: '#2', a, b }`, lists as `{ $: '::', a, b }` / `{ $: '[]' }`, and `Dict.empty` as `{ $: 'RBEmpty_elm_builtin' }` (`tea-contract-cases.cjs:67`).
- **Elm `Char` Prototype Note (`Elm/Kernel/Debug.js:70` vs `tea-contract.cjs:72`)**:
  - In Elm 0.19 JS runtime, `Char` values are boxed `new String(c)` (`Object.getPrototypeOf(v) === String.prototype`). `full()` at `tea-contract.cjs:72` rejects `String.prototype` (`untrusted prototype`). Verified across all declared Elm modules that neither `DesktopPolicy.Model` nor any of the 4 `Policy.Delay` `Desktop.Msg` payloads stores a `Char` field (only `String`, `Int`, `Float`, `Bool`, records, tuples, lists, `Dict`, and ADTs). Failing closed is therefore safe today; if `Char` is ever added to `Model` or `Desktop.Msg`, `full()` will need explicit boxed-`Char` tagging rather than silent coercion to `string`.

### 2.3 Source-Identity & Derivation Provenance Boundary

- `tea-contract.cjs:239-245` records SHA-256 digests of `compiledPath`, the in-memory instrumented JS, `tea-contract-cases.cjs`, `tea-contract.cjs`, and `TeaContractReplay.elm` only. Standalone `node qa/tea-contract.cjs` does **not** prove which `src/*.elm` tree, `elm.json`, or compiler produced `compiledPath`.
- Verified in `tools/check_elm_cpu.py:66-70, 151-176` and `tools/qa_cpu.py:117-132` (`--tea-contract` mode) that Root's protected harness closes this gap: it verifies the pinned Elm toolchain (`compilerSHA256`, `elm-home`, `httpDependencies`), records `node` and `python` SHA-256s, hashes every `implementation/warlock/src/*.elm` + `elm.json` + all three QA files, compiles `TeaContractReplay.elm` freshly inside an isolated `work/` copy, and asserts `contract['originalFixtureSha256'] == sha(output / 'tea-contract.js')` and `contract['oracleSha256'] == sha(work / 'qa/tea-contract-cases.cjs')`.
- **Rule**: Only receipts produced via `tools/qa_cpu.py` -> `tools/check_elm_cpu.py --tea-contract` have transitive source-to-artifact provenance; standalone `tea-contract.cjs` runs must never be cited as source-bound evidence.

### 2.4 Hidden Frontend / Multi-Root Assumptions & `tea-contract-cases.cjs` Verification

1. **`Main.elm` vs `HttpMain.elm` Divergence on `TransportLost`**:
   - `TeaContractReplay.elm:172` and `Main.elm:25-26` preserve the `[Publish <detached-frame>]` returned by `DesktopPolicy.update Policy.TransportLost`.
   - By contrast, `HttpMain.elm:15-18, 28, 47` (`lost`) executes `let (next, _) = Policy.update Policy.TransportLost model.policy` and **discards** the returned `Publish` effect because `UiHttp` has already failed/stopped. Do not infer `HttpMain` wire publication on transport loss from `TeaContractReplay`.
2. **Channel Role Discrimination Is Owned by Haskell `Owner.hs`, Not `DesktopPolicy`**:
   - `DesktopPolicy.incomingEvent` (`DesktopPolicy.elm:20-43`) routes solely on `"kind"` (`"native-event"`, `"view-topology"`, `"view-action"`, `"view-disposition"`, `"view-dismiss"`, `"view-escape"`, `"view-reflow"`). Synthetic `"native-event"` steps in `tea-contract-cases.cjs` validate pure reducer transitions *given* owner-stamped envelopes; renderer-to-owner privilege separation lives in Haskell `Warlock/Ui/Owner.hs` and is outside `TeaContractReplay`.
3. **Separate Renderer TEA Roots in `.warlock-contributor/tea-model-effects.json`**:
   - The active slice also declares `Bar.elm`, `Popup.elm`, `HttpBar.elm`, and `HttpPopup.elm`. `TeaContractReplay.elm` exercises `DesktopPolicy` only. Notably, `Popup.elm` maintains local `Composition` (`Idle | Composing String`) and `pendingQuery`, while `HttpPopup.elm:19-35` (`supported`) fails closed via `UiHttp.stop` on non-empty preview commands. `check_elm_cpu.py --tea-contract` compiles all 6 roots and runs `UiHttpReplay` (`lines 105-133`), which complements `TeaContractReplay` for HTTP renderer roots, while `Bar.elm`/`Popup.elm` pure reducer contracts rely on compiler checks + source review unless dedicated renderer replay cases are added.
4. **Independent Verification of All 18 Cases in `tea-contract-cases.cjs` (`34a4f0ac...`) & Remaining `TEA-002` Gaps**:
   - Verified byte-for-byte against `31a92dce9` source (`OutputController.elm`, `SurfaceController.elm`, `Desktop.elm`, `Shell.elm`, `Launch.elm`, `Surface.elm`, `Settings.elm`, `Binding.elm`, `OutcomeAnnouncements.elm`):
     - Complete `initial` GIVEN (`lines 25-77`) matches every `initial`/`init`/`empty` value across all nested modules.
     - `empty-topology-publishes-complete-frame`, `topology-full-width-9007199254740993`, `topology-maximum-then-overflow` (+ post-step duplicate/overflow no-op), and `one-view-topology-assigns-owner` match exact counter advances (`revision`, `publication`, `desktop.presentation`, `launch.revision`, `highest`, `views`, `selected`, `ownerScope`) and complete `Publish` JSON packets.
     - All 6 `pending-catalog-disposition-mismatch-*` 4-step histories (`scope`, `revision`, `publication`, `lease`, `binding`, `wire`) accurately capture `application-attached` (`Launch.bind` double-advance `2 -> 4` via `disconnect` + `advance`, `desktop.presentation` `2 -> 3`, `publication` `3 -> 4`, `batches = [attachedBatch]`, exact `E.encode 0` field insertion order in `attachedWire`) and exact unchanged state on mismatched `preflight-unsent` certificates.
     - All 7 `invalidEnvelopes` and 5 `invalidTopologies` accurately expect unchanged `initial` + empty effect list.
   - `coverage.complete` is honestly `false` (`lines 382-389`). Closing whole `ELM-TEA-002` still requires independent literal histories for: `pending-mutation`, `mismatched-domain-receipt`, `committed-receipt`, `refused-receipt`, `disconnect-unknown-no-replay` (including `TransportLost`), `rebind`, and reachable `Policy.Delay` effects across `DesktopPolicy.effectsFor` (`2000 Window (ExpirePrepared token)`, `2000 (WorkspaceNavigationDeadline intent)`, `2000 (ChoiceDeadline token)`, `10000 (Deadline token)`).

---

## 3. `ELM-TEA-001` Custom-Type & Single-Authority Audit (`31a92dce9`)

### 3.1 Confirmed Custom-Type Authorities & Observation-vs-Desired-State Separation

- **Strong Custom-Type Domains**: `Shell.Phase` (`Detached | Reconciling | Ready | Exhausted`), `Shell.RecoveryFailure`, `Effects.Status` (`Pending | Committed | Refused | Cancelled | Unknown`), `Effects.Operation`, `Launch.Phase` (`Idle | Pending String Intent | Settled Intent ResultState`), `Launch.ResultState` (`Submitted | Refused | Unknown`), `Pins.Confirmation` (`Saving | Unconfirmed (Maybe Counter)`), `Settings.Theme`, `Settings.SaveOutcome` (`Saved | Refused | Unconfirmed`), `MotionPreferences.Choice`, `ShortcutPreferences.Decision`, `WorkspaceNavigation.Status` (`Pending | Refused | Unknown`), `OverviewRecovery.Model`, `PointerOwnership.State`, `Switcher.Phase`, `Menu.Status`, `Popup.Composition`, and opaque `Binding`, `UInt64.Counter`, `OutputController.Scope`.
- **Clean Observation-vs-Desired-State Separation**: Verified across `Shell.effects` (`observed` vs `transaction`/`unresolved`/`issued`), `Pins` (`snapshot` vs `pending`), `Settings` (`snapshot` vs `draft`/`pending`/`outcome`), `Motion` (`observation` vs `preferences.draft`/`preferences.pending`/`pending`/`applied`), `ShortcutPreferences` (`snapshot`/`inventory` vs `draft`/`pending`), and `OutputController` (`views`/`locations` vs unacknowledged `batches`).

### 3.2 Concrete `String`-Typed Lifecycle / Receipt / Operation Gaps Requiring Resolution Before Whole `ELM-TEA-001` Closure

Strict reading of `ELM-TEA-001` (*"SHALL represent lifecycle, receipt and operation state with custom types"*) identifies **five** modules on the active `DesktopPolicy` owning route that validate finite lifecycle, receipt, operation, or permission states at decode time but still store or route them as raw `String` values inside `Model` or domain transition functions:

1. **`implementation/warlock/src/Notifications.elm:10-13, 27, 52, 67-76`**:
   - `Entry.state : String` stores 8 finite lifecycle states (`"live" | "expired" | "invoked" | "dismissed" | "closed" | "disconnected" | "unknown" | "unavailable"`), `Target.verb : String` stores `"dismiss" | "invoke"`, `Model.outcome` stores `status : String`, and `receiveReason` branches on `"Dispatched" | "Refused" | "Unknown"`.
2. **`implementation/warlock/src/JumpList.elm:6, 15, 30-35`**:
   - `Action.kind : String` stores `"desktop" | "recent"`, and `receive : Counter -> String -> String -> Model -> Model` branches on raw receipt `status : String` (`"Submitted" | "Refused" | "Unknown"`).
3. **`implementation/warlock/src/Files.elm:52-65`**:
   - `receive : Counter -> String -> String -> Maybe Snapshot -> Model -> Model` branches on raw receipt `status : String` (`"Opened" | "Refused" | "Unknown"`).
4. **`implementation/warlock/src/SystemMenu.elm:12-14, 28-29, 73-79`**:
   - `Snapshot.network.permission : String` (`"yes" | "no" | "auth"`), `Snapshot.power.suspend/reboot/poweroff : String` (`"yes" | "no" | "na" | "challenge"`), and `receive` branches on raw receipt `status : String` (`"Committed" | "Submitted" | "Refused" | "Unknown"`).
5. **`implementation/warlock/src/ReconciliationFrame.elm:10, 31-36`** (retained in `SurfaceController.Model.recovery` via `ReconciliationTracking.Release.proof`):
   - `Proof.operation : String` (`"observe" | "retire"`) and `Proof.grantState : String` (`"Retired"`), as well as `Proof.kind : String` (`"binding-retirement"`).

**Disposition Recommendation**: Do not infer whole `ELM-TEA-001` acceptance solely from the already-typed `Shell`/`Effects`/`Launch` domains or from `TEA-002` replay fixtures. Root should either convert these finite lifecycle/receipt/operation fields to Elm custom types at the decoder boundary (preserving wire JSON and `initial` / `GIVENS` transcription where `Model` tags change) or obtain explicit clause-by-clause independent readiness adjudication before marking `ELM-TEA-001` whole-accepted.

---

## 4. `18:54Z` Addendum — Verification of Updated Drafts (`a63153fc...`, `3a9dba60...`, `68dc8126...`)

1. **`terra-q-origin` Input-Prototype Patch Verified (`terra-q-origin-tea-input.patch`, `sha256: 68dc812687292a55048b55b6f959a98666bf1c51e559e63e33d0e3a3d73eb7a0`)**:
   - Verified `portValue()` recursively materializes plain `{}` objects (`Object.prototype`) via `Object.defineProperty` (preserving `"__proto__"` safety, array order, and primitive types) on `current.input` right before `app.ports.incoming.send(...)` while leaving `observed`, `ack`, and `expected` as `full()` (`Object.create(null)`) trees. This cleanly resolves the `Elm/Kernel/Json.js:260` `value.hasOwnProperty(key)` crash (`implementation/warlock-preview-provider-v143/qa/toolchain/elm-home/0.19.2/packages/elm/json/1.1.3/src/Elm/Kernel/Json.js:250-268`).
2. **New `Prelude` Timer-Retention Mismatch Between `TeaContractReplay.elm` (`a63153fc...` lines `191-203`) and `tea-contract.cjs` (`8c88af33...` lines `155, 204-206`)**:
   - `TeaContractReplay.elm:191-203` adds `Prelude (List D.Value)`, which folds from `initial`, retains `deadlines` across **every** intermediate event in `values`, logs only the **final** event's `(policy, lastEffects)`, and reports `ack.timers = List.length retained.deadlines`.
   - However, `tea-contract.cjs:204-206` computes `if (i === 0) deadlineCount = 0; deadlineCount += countDelays(observed.effects, ...); insist(ack.timers === deadlineCount)`.
   - Two concrete mismatches arise as soon as any case uses `kind: 'prelude'`:
     - **(a)** If any **non-final** element of `prelude.values` emits a `Policy.Delay`, `ack.timers` includes it while `observed.effects` (`lastEffects`) does not, failing `ack.timers === deadlineCount` (`timer retention mismatch`).
     - **(b)** If `kind: 'prelude'` appears at `step > 1` after an earlier step emitted a `Policy.Delay`, `TeaContractReplay.elm:203` resets from `initial` whereas `tea-contract.cjs:204` only zeroes `deadlineCount` at `i === 0`, also failing `ack.timers === deadlineCount` (and `transitions += testCase.steps.length - 1` at `line 237` would count a `prelude` setup step as a verified transition).
   - **Recommended Runner Guard (`terra-q-origin` / `lead`)**: Restrict `kind === 'prelude'` in `validateCases` to `index === 1` only, require an explicit literal `expected.preludeTimers` (or `expected.retainedTimers`) integer when `input.kind === 'prelude'` so intermediate setup timers are accounted explicitly rather than guessed, and exclude `kind === 'prelude'` steps from `transitions` count (`tea-contract.cjs:237`).
3. **Updated `tea-contract-cases.cjs` (`3a9dba6077ef23badf73e44989dfd11bef776c00303a0990d21a9e76d2b4ce7d`, 22 cases) Source-Verified**:
   - Verified the 4 newly added cases (`pending-catalog-mismatched-domain-receipt`, `catalog-preflight-refusal-no-replay`, `catalog-matched-read-then-stale-receipt`, `catalog-pending-disconnect-rejects-late-receipt`, including `Shell.disconnect` retaining `binding = Just binding` and `batches = [attachedBatch]`, `OutcomeAnnouncements` `adapter-unavailable` correlation/sequence `'1'`, and `bar:reconnect` `[host-reconnect]` bypassing batch registration via `not bound` at `OutputController.elm:268, 295`) against `31a92dce9` source. None of the 22 current cases use `kind: 'prelude'`, so once `terra-q-origin-tea-input.patch` is applied, all 22 cases are ready for Root's protected `--tea-contract` run.
