# `SiteMainTeaContractPublished31a92.diff` — Pure-Elm Website Visual & Status Candidate (`31a92dce9` / `1834` Wave, v2)

- **Target Baseline**: `/home/charl/code/Warlock/site/src/SiteMain.elm` (`sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`, untouched in repository)
- **Claimed Ignored Draft Patch (v2)**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainTeaContractPublished31a92.diff` (`sha256:9e4961eb6c2c1c35172fe5cadbfa13e6722adf56a277c9d06abe05df284fb2a1`, `27,949` bytes, `421` lines; supersedes v1 `61a396c5520f094fc9ea12a0533a2255b61de7306de14f6370ffbc408871a31d`)
- **Simulated Post-Apply `SiteMain.elm`**: `sha256:967a9d540249e1f4153325cd0cebef3ba88bc79e1828134be22302c154c00ed1` (`78,287` bytes, `1,801` lines; verified via `git apply --check` `exit 0` and clean forward + `-R` reverse apply round-trip)
- **Preserved Prior Drafts (Untouched)**:
  - `SiteMainUi005Published3f88.diff` (`sha256:275143199950a257ca6c3b2b0d973847d57488c061d0699ddfc0021c35608139`)
  - `SiteMainVisualHierarchy1713.diff` (`sha256:03913cad0a950ec22a3ac7c497ddaf40916224d4a1b9a2f4df87349cc4c9f344`)
  - `SiteMainIdleDeliveryStatus.diff` (`sha256:3132bf6f1e3b6999cdd191a0743f92385c64e203516a8e6a1a16ab09bcafcea5`)

---

## 1. Exact Alignment with Published `31a92dce92538f5282643c006854e23294b15bbe`, `sol-docs` (`01M6C5E135Y6ZXDBJ2FQBHQQ4P` & `01M6C6XJZ9ACXG4MHFP1WR8T81`), & `terra-browser` (`01M6C6W0N0TJ8FHPWNR9HWFJ66` / `UX-PERFORMANCE-ACCEPTANCE.md` `3937acb6...`)

1. **Historical Whole `ELM-UI-005` vs Current-Port `ELM-UI-005` Requalification vs Current Haskell/Elm `ELM-ARC-002` Partial (`sol-docs` `01M6C5E135Y6ZXDBJ2FQBHQQ4P` & `01M6C6XJZ9ACXG4MHFP1WR8T81`)**:
   - Preserves the historical source-tuple whole verdict for `ELM-UI-005` within `15 / 242` whole requirements and `39 / 417` scenarios (`docs/warlock-build-loop/v2/requirement-ledger.json` & `STATE.json:3909`), while keeping `ELM-UI-005` current-port requalification `partial` (`implementation/warlock/qa/evidence/ui005-haskell-search-20261101/observation.json`).
   - Separates `ELM-ARC-002` from `ELM-UI-005` rather than grouping both as `"requalifications"`, since `ELM-ARC-002` is not historically whole-accepted (`"current Haskell/Elm ELM-ARC-002 remains partial, and ELM-UI-005 current-port requalification remains partial"`).
2. **QMP-Injected Software-VM Input Wording (`terra-browser` `01M6C6W0N0TJ8FHPWNR9HWFJ66`) & Recorded-Sequence No-Launch Scope (`sol-docs` `01M6C5E135Y6ZXDBJ2FQBHQQ4P`)**:
   - Replaces `"physical Applications click"` / `"5 physical keys"` with `"QMP-injected pointer click on Applications"` (`run-03`) and `"QMP-injected pointer clicks on Applications/Search and five QMP-injected key events"` (`run-08`) in the software VM—explicitly stating that these exercise the guest input path without establishing physical hardware input or physical latency.
   - Uses exact recorded-sequence wording (`"no Enter or launch action in the recorded sequence on the app-only route"` / `"no launch action in recorded sequence on app-only route"`), matching `observation.json:141` rather than claiming OS interval-wide absence.
3. **Explicit Unqualified Correlation, AT/IME, Cleanup & UX/Latency Boundaries**:
   - Keeps **final-query authoritative projection correlation** unverified (`Popup` `pendingQuery` may locally overlay an older authoritative projection), **native/AT/IME** and **provider/scope cleanup** unqualified (`nativeOperations: []`, `HOSTSTOP2` preserved), and **physical-hardware UX/latency criteria** (`docs/warlock-build-loop/v2/UX-PERFORMANCE-ACCEPTANCE.md` `3937acb6...`, starting at verified physical/native input before internal queueing) **unmeasured**.
4. **Hourly `2–3` Whole EARS Goal & Active `ELM-TEA-001` / `ELM-TEA-002` WIP1**:
   - Explicitly frames the `2–3` whole original EARS/hour cadence (`aim 3`, `plan min 2`) as an **operational / planning goal, not actual closures**; accepted counts remain `15 / 242` whole and `39 / 417` scenarios.
   - Marks active WIP1 (`ELM-TEA-001` / `ELM-TEA-002` in `.warlock-contributor/tea-model-effects.json`) as **active / unaccepted (not preaccepted)**.
5. **Exact Model-Test Labels**:
   - Every occurrence of `273` and `248` uses the exact strings `"273 named model tests"` (`3` occurrences) and `"248 named model tests"` (`3` occurrences), with `0` shorthand model labels.

---

## 2. Supporting Source Cross-Checks Shared with `sol-docs` & `terra-browser` (`ELM-TEA-001` & `pendingQuery`)

- **`implementation/warlock/src/SurfaceSnapshot.elm:10,35,48`** (`sha256` bound in `Bar.elm`/`Popup.elm` -> `Presentation.elm`): `SurfaceSnapshot.Details` validates `mode` against the 12 closed surface modes and `motion` against `["reduced","full"]`, then retains `mode : String` and `motion : String` inside the renderer presentation snapshot (compared as string literals in `Popup.elm:107` and `Presentation.elm:55,57`), whereas owning `Desktop` policy uses custom `Surface.Mode`. Whole-clause `ELM-TEA-001` review should explicitly record whether renderer wire-projection fields (`SurfaceSnapshot.Details`) are outside authority lifecycle/receipt/operation ADTs or require typed tags alongside `Notifications.elm:10-13` and `ReconciliationFrame.Proof`.
- **`implementation/warlock/src/Shell.elm:33,115-120`** (`sha256:6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094`): `UnsentObservations (List (String, Counter))` and `RegistrationRefused (List UnsentOperation.Key) (List (String, Counter))` pass observation-slot kind as `String` (`"projection-request"`, `"geometry-facts-request"`, `"geometry-attach"`, `"notifications-request"`), while `UnsentOperation.Key` already uses typed `Effects.Intent`.
- **`implementation/warlock/src/SurfaceSnapshot.elm:75` & `Popup.elm:101`**: Confirms by exact line numbers `terra-browser`'s `pendingQuery` observation—both `SurfaceSnapshot.pendingQuery` and `Popup.transition` disable/drop `entry:*`, `files:open-path`, `files:collection:*`, and `files:home` while `pendingQuery /= Nothing`, leaving `pin:*` and `jump:*` enabled on the prior snapshot until the next publication arrives.

---

## 3. Preserved Visual Hierarchy, Lacquer Token, Responsive & ARIA Fixes

- **Exported Elm API Unchanged**: `module SiteMain exposing (AppearanceTheme(..), CueFacts, Model, MotionMode(..), Msg(..), OutcomeSample(..), SurfaceCategory(..), SurfaceId(..), init, main, update, view, viewDocument)` untouched; zero JS/ports/subscriptions added.
- **ARIA `<dl>` Compliance**: `<dl class="wl-hero-ledger">` and `<dl class="wl-home-readiness-strip">` carry zero `aria-label`/`aria-labelledby` attributes (`aria-prohibited-attr` clean) and use `margin: 0`.
- **CSS Specificity & Responsive Grids**: `.wl-home-root .wl-band .wl-home-scope-grid` (`(0,3,0)` > `landing.css:51` `(0,2,0)`) renders `2 × 2` above `760px` and `1`-column at `<=760px`; `.wl-home-readiness-strip` steps `4 -> 2 -> 1` (`>1040px` / `<=1040px` / `<=560px`); Dawn hero switches cleanly at `960px`; `.wl-home-chip` preserves `min-height: 2.5rem` (`40px`).
- **High Contrast & Forced Colors**: Solid `#000000`/`#FFFFFF` (`[data-theme="high-contrast"]`) and `Canvas`/`CanvasText`/`Highlight` (`@media (forced-colors: active)`), including solid `.wl-home-card-footer` top border and `backdrop-filter: none`.
