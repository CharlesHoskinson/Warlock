{-# LANGUAGE OverloadedStrings #-}
-- Root-owned child fixture: sends one literal desktop frame with two distinct requests on inherited fd 0
-- then remains alive while the caller-owned marker exists. No native ACK and
-- no native/window authority. Root compiles and runs the bounded fixture.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless)
import qualified Data.ByteString as B
import System.Directory (doesFileExist)
import System.Environment (getArgs)
import System.IO (BufferMode(NoBuffering), hClose, hFlush, hSetBinaryMode, hSetBuffering)
import System.Posix.IO (fdToHandle)
import System.Posix.Types (Fd(..))
import qualified Warlock.Protocol.Framing as F

packet :: B.ByteString
packet = "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"QA\",\"bar\":[{\"id\":\"qa:focus-valid\",\"domId\":\"focus-valid\",\"label\":\"QA control\",\"ariaLabel\":\"QA control\",\"detail\":\"\",\"enabled\":true,\"focusOnly\":false}],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"7\"},{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"8\"}],\"focus\":[]}"

waitRemoval :: FilePath -> Int -> IO Bool
waitRemoval marker attempts = do
 exists <- doesFileExist marker
 if not exists then pure True
 else if attempts <= 0 then pure False
 else threadDelay 10000 >> waitRemoval marker (attempts - 1)

main :: IO ()
main = do
 args <- getArgs
 marker <- case args of
  [path] | not (null path) && head path == '/' -> pure path
  _ -> ioError (userError "expected one absolute owned marker")
 framed <- either (ioError . userError . show) pure (F.desktopCommitPrefix packet)
 h <- fdToHandle (Fd 0)
 hSetBinaryMode h True
 hSetBuffering h NoBuffering
 -- Two writes exercise actual fragmented credential admission without timing
 -- or claiming that the kernel preserves these as distinct recvmsg fragments.
 let (first,rest) = B.splitAt 3 framed
 B.hPut h first
 B.hPut h rest
 hFlush h
 removed <- waitRemoval marker 400
 unless removed (ioError (userError "caller-owned marker remained present"))
 hClose h
