port module FocusSurfaceBoundaryReplay exposing (main)

{-| Source-only QA draft for Presentation.focusTarget. The notification frame
is an independent synthetic protocol fixture; the picker frame is produced by
Surface.packet after a real Desktop update with synthetic native inputs. Focus
is renderer-only and this does not establish native origin or physical focus.
Root owns integration, artifact pinning and protected compilation/execution. -}

import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Presentation
import Surface
import TaskbarShell
import UInt64

port outgoing : E.Value -> Cmd msg

counter value = D.decodeValue UInt64.decoder (E.string value) |> Result.withDefault UInt64.zero
bound = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]
native raw model = NativePointerFixture.incoming raw model |> Tuple.first
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",bound)]
window id = E.object [("incarnation",E.string id),("label",E.string ("Document "++id)),("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]
projection = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",bound),("requestId",E.string "1"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")]),("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),("windows",E.list identity [window "1",window "2"])])]
ready = Desktop.initial |> native attached |> native projection
groupId = "bar:group:" ++ (TaskbarShell.groups ready.windows |> List.head |> Maybe.map .key |> Maybe.withDefault "missing")
openAction = E.object [("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("surface",E.string "bar"),("publication",E.string "1"),("lease",E.string "0"),("id",E.string groupId),("trigger",E.string "pointer")]
picker = Surface.resolve (counter "1") UInt64.zero openAction ready |> Maybe.map (\message -> Desktop.update message ready |> Tuple.first) |> Maybe.withDefault ready
pickerDom = "picker-close:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:1:1:1"
pickerPresentation = Presentation.accept (Surface.packet (counter "17") (counter "9") picker) Presentation.initial

control id dom enabled focusOnly = E.object [("id",E.string id),("domId",E.string dom),("label",E.string id),("ariaLabel",E.string id),("detail",E.string ""),("enabled",E.bool enabled),("focusOnly",E.bool focusOnly)]
frame pub lease = E.object [("surfaceProtocol",E.int 2),("publication",E.string pub),("lease",E.string lease),("mode",E.string "notifications"),("status",E.string "fixture"),
    ("bar",E.list identity [control "bar:enabled" "bar-target" True False,control "bar:disabled" "bar-disabled" False False]),
    ("popup",E.list identity [control "normal" "normal-target" True False,control "disabled" "disabled-target" False False,control "retired" "focus-target" False True])]
focus surface pub lease dom = E.object [("focusProtocol",E.int 1),("kind",E.string "focus"),("surface",E.string surface),("publication",E.string pub),("lease",E.string lease),("domId",E.string dom)]
call popup value presentation = Presentation.focusTarget popup value presentation
notAllowed popup value presentation = call popup value presentation == Nothing
presentation = Presentation.accept (frame "17" "9") Presentation.initial
validBar = focus "bar" "17" "9" "bar-target"
validPopup = focus "popup" "17" "9" "normal-target"
validFocusOnly = focus "popup" "17" "9" "focus-target"
maxCounter = "18446744073709551615"
maxPresentation = Presentation.accept (frame maxCounter maxCounter) Presentation.initial
base = [("focusProtocol",E.int 1),("kind",E.string "focus"),("surface",E.string "popup"),("publication",E.string "17"),("lease",E.string "9"),("domId",E.string "normal-target")]
required = ["focusProtocol","kind","surface","publication","lease","domId"]
remove key fields = List.filter (Tuple.first >> (/=) key) fields
replace key value fields = List.map (\(name,old) -> (name,if name==key then value else old)) fields
wrongType key = if key=="focusProtocol" then E.string "1" else E.int 1
fieldChecks key =
    [ ("missing:"++key,notAllowed True (E.object (remove key base)) presentation)
    , ("null:"++key,notAllowed True (E.object (replace key E.null base)) presentation)
    , ("wrong-type:"++key,notAllowed True (E.object (replace key (wrongType key) base)) presentation)
    ]
checks =
    [ ("synthetic_notification_frame_accepted",Presentation.current presentation/=Nothing)
    , ("bar_exact_current",call False validBar presentation==Just "bar-target")
    , ("popup_exact_current",call True validPopup presentation==Just "normal-target")
    , ("focus_only_is_focusable",call True validFocusOnly presentation==Just "focus-target")
    , ("focus_only_not_action_authority",Presentation.dispatch True (E.object [("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("surface",E.string "popup"),("publication",E.string "17"),("lease",E.string "9"),("id",E.string "retired")]) presentation==Nothing)
    , ("disabled_popup_rejected",notAllowed True (focus "popup" "17" "9" "disabled-target") presentation)
    , ("disabled_bar_rejected",notAllowed False (focus "bar" "17" "9" "bar-disabled") presentation)
    , ("popup_as_bar_rejected",notAllowed False validPopup presentation)
    , ("bar_as_popup_rejected",notAllowed True validBar presentation)
    , ("unknown_role_rejected",notAllowed True (focus "foreign" "17" "9" "normal-target") presentation)
    , ("unknown_dom_rejected",notAllowed True (focus "popup" "17" "9" "missing") presentation)
    , ("empty_dom_rejected",notAllowed True (focus "popup" "17" "9" "") presentation)
    , ("oversized_dom_rejected",notAllowed True (focus "popup" "17" "9" (String.repeat 1025 "x")) presentation)
    , ("control_dom_rejected",notAllowed True (focus "popup" "17" "9" ("x"++String.fromChar (Char.fromCode 31))) presentation)
    , ("stale_publication_rejected",notAllowed True (focus "popup" "16" "9" "normal-target") presentation)
    , ("future_publication_rejected",notAllowed True (focus "popup" "18" "9" "normal-target") presentation)
    , ("stale_lease_rejected",notAllowed True (focus "popup" "17" "8" "normal-target") presentation)
    , ("future_lease_rejected",notAllowed True (focus "popup" "17" "10" "normal-target") presentation)
    , ("zero_publication_rejected",notAllowed True (focus "popup" "0" "9" "normal-target") presentation)
    , ("full_width_current",call True (focus "popup" maxCounter maxCounter "normal-target") maxPresentation==Just "normal-target")
    , ("overflow_publication_rejected",notAllowed True (focus "popup" "18446744073709551616" "9" "normal-target") presentation)
    , ("wrong_version_rejected",notAllowed True (E.object (replace "focusProtocol" (E.int 2) base)) presentation)
    , ("wrong_kind_rejected",notAllowed True (E.object (replace "kind" (E.string "surface-action") base)) presentation)
    , ("extra_field_rejected",notAllowed True (E.object (base++[("extra",E.bool True)])) presentation)
    , ("missing_frame_rejected",notAllowed True validPopup Presentation.initial)
    , ("actual_picker_opens",picker.windows.picker/=Nothing)
    , ("actual_picker_literal_target",call True (focus "popup" "17" "9" pickerDom) pickerPresentation==Just pickerDom)
    ] ++ List.concatMap fieldChecks required
result = E.object [("scope",E.string "synthetic renderer focus instruction; no native focus authority"),("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]
main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\message model -> never message,subscriptions=\_ -> Sub.none}
