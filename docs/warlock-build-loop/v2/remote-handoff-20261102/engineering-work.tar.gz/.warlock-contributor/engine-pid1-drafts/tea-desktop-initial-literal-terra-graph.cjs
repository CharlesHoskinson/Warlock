'use strict';
// Source-derived draft; no observed reducer output and no execution/acceptance.
// Supply terra-engine's source-derived windows and launch literals, and the
// independently verified debug Dict.empty representation. Fail closed on gaps.
module.exports = function desktopInitial({ windows, launch, dictEmpty }) {
  if (windows === undefined || launch === undefined || dictEmpty === undefined) {
    throw new Error('Independent windows, launch and debug Dict.empty literals required');
  }
  const n = () => ({ $: 'Nothing' });
  const z = () => ({ $: 'Counter', a: '0' });
  const e = () => ({ $: '[]' });
  const c = tag => ({ $: tag });
  return {
    windows, choice:n(), choiceNotice:'', popupOrigin:c('KeyboardEntry'), returnFocus:n(),
    menuOrigin:n(), ownerScope:n(), ownerExhausted:false, launch, launchFromApplications:false,
    applications:n(), applicationPage:0, presentationCapacity:false, query:'',
    pins:{snapshot:n(),pending:n(),notice:''},
    pointer:{observation:n()}, shortcuts:{binding:n(),seen:z()},
    jumpList:{snapshot:n(),pending:n(),spent:e(),notice:'Reading application actions…'},
    jumpEntry:n(),jumpOpening:false,jumpExpected:n(),jumpBack:false,
    files:{snapshot:n(),draft:'',pending:n(),spent:e(),notice:'Loading Files…'},
    filesOpen:false,filesOpening:false,filesExpected:n(),
    systemMenu:{snapshot:n(),pending:n(),spent:e(),notice:'Loading system state…'},
    systemMenuOpen:false,systemMenuOpening:false,systemMenuExpected:n(),systemMenuConfirmation:n(),
    notifications:{focused:n(),outcome:n(),policy:{doNotDisturb:false,interruptCritical:false},snapshot:n(),pending:n(),spent:e(),notice:'Loading notifications…'},
    notificationsOpen:false,notificationsOpening:false,notificationsExpected:n(),motionExpected:n(),
    motion:{preferences:{snapshot:n(),draft:c('System'),pending:n(),notice:'Reading motion preference…'},observation:n(),pending:n(),applied:n()},
    settings:{outcome:n(),snapshot:n(),draft:{theme:c('Night'),textScale:100,effectsOff:false,reducedTransparency:false},pending:n(),notice:'Loading settings…'},
    settingsOpen:false,settingsOpening:false,settingsExpected:n(),settingsHelp:true,
    shortcutPreferences:{snapshot:n(),inventory:n(),draft:{applications:c('Undecided'),system:c('Undecided'),notifications:c('Undecided')},pending:n(),conflicts:e(),notice:'Loading shortcut choices…'},
    shortcutExpected:n(),open:false,overview:false,overviewWorkspace:n(),overviewRecovery:c('Idle'),
    workspaceInventory:n(),workspaceNavigation:{binding:n(),ready:false,request:z(),generation:z(),record:n(),recovering:false,origin:n(),returning:false},
    overviewTransfer:n(),snap:n(),
    switcher:{$:'Model',a:{generation:z(),phase:c('Idle'),steps:dictEmpty,released:n(),ready:false,entries:e(),ring:e(),origin:n(),selected:0,baseline:n()}},
    nativeSwitcher:n(),switcherOrigin:n(),switcherExpected:n(),switcherHistory:n(),request:z(),
    presentation:{$:'Just',a:z()},expected:n(),adapterNotice:n(),catalogFailure:n(),catalogOpening:false
  };
};
