port module SafeExactOriginReplay exposing (main)

{-| Unexecuted QA-only adapter. The independent host supplies JSON-only inputs,
declared allowed keys and expected results. No reducer or native authority. -}

import Json.Decode as D
import Json.Encode as E
import Platform
import SafeExactOrigin


port incoming : (D.Value -> msg) -> Sub msg


port outgoing : E.Value -> Cmd msg


type Msg
    = Input D.Value


type alias Case =
    { id : Int, allowed : List String, payload : D.Value }


caseDecoder : D.Decoder Case
caseDecoder =
    D.map3 Case
        (D.field "id" D.int)
        (D.field "allowed" (D.list D.string))
        (D.field "payload" D.value)


update : Msg -> () -> ( (), Cmd Msg )
update (Input raw) model =
    case D.decodeValue caseDecoder raw of
        Err _ ->
            ( model, outgoing (E.object [ ( "adapterError", E.bool True ) ]) )

        Ok sample ->
            let
                accepted =
                    case D.decodeValue (SafeExactOrigin.strict sample.allowed D.value) sample.payload of
                        Ok _ ->
                            True

                        Err _ ->
                            False
            in
            ( model, outgoing (E.object [ ( "id", E.int sample.id ), ( "accepted", E.bool accepted ) ]) )


main : Program () () Msg
main =
    Platform.worker
        { init = \() -> ( (), Cmd.none )
        , update = update
        , subscriptions = \_ -> incoming Input
        }
