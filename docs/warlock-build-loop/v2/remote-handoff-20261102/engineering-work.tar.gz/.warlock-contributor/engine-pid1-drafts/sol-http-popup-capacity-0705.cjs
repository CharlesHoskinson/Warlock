'use strict';
// Independent source literals at the existing UiHttp queue bound. These are
// transport slots, NOT an original/native threshold or a protocol-frame cap.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const PIN='2e864be5b07d505dcd045f03b627a92b71703a1b8ef37638de6465befa2a7ac4';
const C=(tag,...args)=>Object.fromEntries([['$',tag],...args.map((v,i)=>[String.fromCharCode(97+i),v])]);
const L=values=>values.reduceRight((tail,head)=>C('::',head,tail),C('[]'));
const N=()=>C('Nothing');
const J=x=>C('Just',x);
const JSONV=x=>({$:0,a:x});
const U=x=>C('Counter',String(x));
const S=()=>({$:2,m:C('[]')});
const DESC=(module,effects)=>({module,effects:L(effects)});
const H=effects=>DESC('UiHttp',effects);
const SEND=wire=>C('SendRenderer',JSONV(wire));
const LOSS='UI transport capacity exceeded. No action was retried.';
const QUERIES=['q01','q02','q03','q04','q05','q06','q07','q08','q09',
  'q10','q11','q12','q13','q14','q15','q16','q17','q18'];
const WIRE=query=>({surfaceProtocol:2,surface:'popup',kind:'surface-query',
  publication:'1',lease:'1',id:'control:search',query});
function http(active,pending,failed=false) {
  return C('Model',{role:C('Renderer'),pending:L(pending.map(JSONV)),
    active:active===null?N():J(JSONV(active)),polling:true,
    failed:failed?J(C('CapacityExceeded')):N()});
}
function expected(popup,transport,descriptions,effects,event=N()) {
  return {state:{popup,http:transport},subscriptions:S(),descriptions,
    transportReturns:[{kind:'transition',value:C('#3',transport,L(effects),event)}]};
}
function build() {
  const filename=path.join(__dirname,'sol-http-popup-local-0640.cjs');
  if(crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex')!==PIN) throw Error('independent Popup literal base changed');
  // Only source-authored expected initial/presentation data is reused, never
  // model-under-test observations. Every unmodified field remains present.
  const literal=require(filename).build();
  const base=literal.cases.find(x=>x.name==='HttpPopup-local-rebase-pending-refresh-confirmation-cancel-and-new-lease');
  if(!base||base.steps.length!==16) throw Error('pinned source literal shape changed');
  const shown=base.steps[1].expected.state.popup;
  const stateAt=query=>({...shown,pendingQuery:J(query),composition:C('Idle'),lastQuery:J(C('#3',query,U(1),U(1)))});
  function queryStep(query,active,pending,failed=false,send=false) {
    const wire=WIRE(query);
    const dispatch=[C('Dispatch',JSONV(wire))];
    const effects=failed?[C('CancelEvents'),C('CancelPost')]:send?[SEND(wire)]:[];
    return {input:{kind:'viewLocalAction',value:wire},expected:expected(stateAt(query),http(active,pending,failed),
      [DESC('Popup',dispatch),DESC('Popup',dispatch),H(effects)],effects,failed?J(C('Lost',LOSS)):N())};
  }
  const wires=QUERIES.map(WIRE);
  const firstSixteen=()=>base.steps.slice(0,2).concat(QUERIES.slice(0,16).map((query,i)=>
    queryStep(query,wires[0],wires.slice(1,i+1),false,i===0)));
  const after16=stateAt('q16');
  const stopped17=http(wires[0],wires.slice(1,16),true);
  const completion={input:{kind:'postedOk',body:''},expected:expected(after16,http(wires[1],wires.slice(2,16)),
    [H([SEND(wires[1])])],[SEND(wires[1])])};
  return {cases:[
    {name:'HttpPopup-sixteen-retained-slots-seventeenth-refused-and-failed-late-completion-inert',root:'HttpPopup',steps:firstSixteen().concat([
      queryStep('q17',wires[0],wires.slice(1,16),true),
      {input:{kind:'postedOk',body:''},expected:expected(stateAt('q17'),stopped17,[H([])],[])},
    ])},
    {name:'HttpPopup-post-completion-releases-only-transport-slot-and-preserves-unconfirmed-query',root:'HttpPopup',steps:firstSixteen().concat([
      completion,
      // HTTP completion did not settle the UI: q16 remains pending above.
      // Exactly one free slot permits q17, then q18 refuses with all16 kept.
      queryStep('q17',wires[1],wires.slice(2,17)),
      queryStep('q18',wires[1],wires.slice(2,17),true),
    ])},
  ]};
}
module.exports={schema:1,build,coverage:{complete:false,roots:['HttpPopup'],
  scope:'complete actual wrapper state/every reached typed effect at existing 16-slot UiHttp bound',
  limits:['unexecuted independent source proposal; Root-only replay against actual compiled owning root',
    '18 distinct short source-literal queries, no captured model or oracle',
    'capacity bound belongs to UiHttp local transport; no original/native/frame threshold claim',
    'failed state retains active first payload and ordered15pending payloads; no request replay',
    'HTTP completion releases one queue slot but never confirms desktop query or native action',
    'no actual network load/latency, browser focus, physical IME, provider or release acceptance']}};
