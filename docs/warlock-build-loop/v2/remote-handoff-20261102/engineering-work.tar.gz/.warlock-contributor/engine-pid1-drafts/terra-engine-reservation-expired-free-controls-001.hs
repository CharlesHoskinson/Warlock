{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, NOT EXECUTED. Direct selected no-input expiry control. Root must
-- pre-root each Probe, resolver-held image and independent guardian; even an
-- expected-no-spawn bug may spawn. Original StartD is never restarted.
module ReservationExpiredFreeControls (Probe, newProbe, runExpiredFree) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), SessionExit(..), newPersistentOwner,
  persistentHeldNoInput, persistentStatus, persistentUnderlyingStatus,
  startBudgetAfter, startBudgetDeadline, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook, qaPersistentPendingIssues)
import Warlock.Platform.Executable (HeldExecutable, qaHeldBorrowCount)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe HeldExecutable)) (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar Result) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("free reservation expiry: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
expired :: AdmissionDeadline -> IO ()
expired d = do
 left <- remainingMicros d
 if left <= 0 then pure () else threadDelay (min 1000 left) >> expired d

runExpiredFree :: Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runExpiredFree (Probe owner held worker sampled resume done reserved used) supply = mask $ \restore -> do
 first <- atomicModifyIORef' used (\v -> (True,not v))
 check "single-use probe" first
 let hook stage = case stage of
      "qa-before-spawn-reservation-positive" -> putMVar sampled () >> readMVar resume
      "persistent-after-spawn-reserve" -> atomicModifyIORef' reserved (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar resume ())
      tid <- readIORef worker
      case tid of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     run = do
      image <- restore (supply owner)
      writeIORef held (Just image)
      selection <- need (persistentHeldNoInput image [] [("LANG","C"),("LC_ALL","C")])
      start <- startBudgetAfter 1000000 >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop
        (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar done)
       writeIORef worker (Just tid)
       pure tid
      within "positive original-D sample" (readMVar sampled)
      one <- qaHeldBorrowCount image
      check "actual selected borrow retained" (one == Just 1)
      within "same original StartD expires" (expired (startBudgetDeadline start))
      void (tryPutMVar resume ())
      result <- within "owner result" (readMVar done)
      count <- readIORef reserved
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      pending <- qaPersistentPendingIssues owner
      borrows <- qaHeldBorrowCount image
      check "free gate rechecks original deadline, no reserve and checked no-input cleanup" $
       count == 0 && phase == PersistentRetired && raw == Available &&
       maybe True (const False) pending && borrows == Just 0 &&
       case result of Right (Left (StartupRefused TimedOut)) -> True; _ -> False
 restore run `finally` finish
