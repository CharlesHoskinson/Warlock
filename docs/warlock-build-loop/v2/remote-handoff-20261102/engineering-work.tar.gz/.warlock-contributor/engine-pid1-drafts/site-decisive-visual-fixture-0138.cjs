#!/usr/bin/env node
/**
 * Decisive Visual & Reachable-Usability Fixture Proposal (0138)
 *
 * Scope: Root-only isolated qualification proposal (worker executes ZERO Node,
 * Elm, Playwright, or VM processes).
 *
 * Covers two source-bound visual & reachable-usability contracts on HEAD 8d1100f0e:
 *   Part A — Minimal Converged Website Entrypoints (`index.html`, `get-started/index.html`, `search/index.html`):
 *     1. Zero `<style>` tags and zero `[style]` attributes inside `.wl-home-root`
 *        (`SiteMainMinimal0138.elm` + `site-landing-minimal-0138.css`).
 *     2. Honest `18 / 242` & `42 / 417` partial runtime/native counts, `ELM-DEL-017`
 *        `selectedOperationSucceeded = false` (`exitCode = 1`), no-desktop-binary truth,
 *        and compact `#beta-walkthrough` inside `#scope` (zero duplicate decorative sections).
 *     3. Reachable usability & responsive/contrast checks across `320x640`, `768x900`,
 *        `930x900` (`901-960px` Dawn hero stacked gradient fix), and `1440x900`:
 *        - Workbench roving tablist `ArrowRight`/`End`/`Home` + IME `229` guard;
 *        - Mobile `320x640` `Escape` returns focus to `#wl-home-nav-toggle` (`index.html`)
 *          and `[data-nav-toggle]` (`get-started/index.html`);
 *        - High-Contrast hero secondary button border contrast `>= 3.0:1` (`21:1` fixed from `1.77:1`);
 *        - 3-way `[data-theme-toggle]` (`night` -> `dawn` -> `high-contrast` -> `night`) on static pages;
 *        - IME-safe + multi-word search (`"tokens download"`, `"beta omarchy"`) on `search/index.html`.
 *
 *   Part B — Current MVP `--application-only` Visual & Unavailable-Operation Oracle
 *            (bound to `typed-model-live-20261102` 1280x800 & `backend-private-diagnostics-20261102` 621x750):
 *     1. Exact enabled solid vs 10 disabled dashed controls (`bar:*`, `jump:open:*`, `entry:*`).
 *     2. `1280x800` 7-button fit vs `621x750` `overflow-x: auto` + `statusWidth >= 180`.
 *     3. `--strict-app-only-status`: RED on HEAD `"Choose a matching application."`, GREEN on
 *        gemini-gui 0132 / terra-browser `"Matching applications are shown, but opening is unavailable in this session."`
 *     4. `--strict-close-label`: RED on HEAD `"Windows"`, GREEN on terra-browser 0120 (`a244fdfe`) `"Close applications"`.
 *
 * Non-claims: Browser/DOM visual fixture checks never establish native Wayland/Hyprland,
 * physical OS IME, assistive-technology, pointer-scroll, or release acceptance.
 */

'use strict';

const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

function parseRgb(raw) {
  const m = String(raw || '').match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,/\s]+([\d.]+))?\s*\)/i);
  if (!m) return null;
  return { r: Number(m[1]), g: Number(m[2]), b: Number(m[3]), a: m[4] === undefined ? 1 : Number(m[4]) };
}

function relLum(rgb) {
  const ch = (v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * ch(rgb.r) + 0.7152 * ch(rgb.g) + 0.0722 * ch(rgb.b);
}

function contrastRatio(fg, bg) {
  const l1 = relLum(fg);
  const l2 = relLum(bg);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2'
};

function startStaticServer(rootDir) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      const reqUrl = new URL(req.url || '/', 'http://127.0.0.1');
      let rel = decodeURIComponent(reqUrl.pathname).replace(/^\/+/, '');
      if (!rel || rel.endsWith('/')) rel += 'index.html';
      const target = path.resolve(rootDir, rel);
      if (!target.startsWith(path.resolve(rootDir) + path.sep) && target !== path.resolve(rootDir)) {
        res.writeHead(403).end('Forbidden');
        return;
      }
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
        res.writeHead(404).end('Not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream' });
      fs.createReadStream(target).pipe(res);
    });
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port });
    });
  });
}

async function verifyConvergedSiteEntrypoints(browser, siteRoot) {
  const { server, port } = await startStaticServer(siteRoot);
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });

  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load', timeout: 20000 });
    await page.locator('#scope #beta-walkthrough').waitFor({ state: 'visible', timeout: 10000 });

    const domAudit = await page.evaluate(() => {
      const root = document.querySelector('.wl-home-root');
      if (!root) return { missingRoot: true };
      const txt = root.innerText || '';
      const walkItems = root.querySelectorAll('#scope #beta-walkthrough ol.wl-home-walkthrough > li').length;
      return {
        missingRoot: false,
        inlineStyles: root.querySelectorAll('style').length,
        styleAttrs: root.querySelectorAll('[style]').length + (root.hasAttribute('style') ? 1 : 0),
        walkItems,
        honest18: txt.includes('18 of 242') && txt.includes('42 of 417') && !txt.includes('Fifteen whole'),
        honestBackend: txt.includes('selectedOperationSucceeded = false') && txt.includes('FileNotFoundError') && txt.includes('nativeOperations = []')
      };
    });
    record(
      'siteMainCssFreeAndHonest18Of242Walkthrough',
      !domAudit.missingRoot &&
        domAudit.inlineStyles === 0 &&
        domAudit.styleAttrs === 0 &&
        domAudit.walkItems === 4 &&
        domAudit.honest18 &&
        domAudit.honestBackend,
      JSON.stringify(domAudit)
    );

    // Workbench IME 229 guard + roving tablist focus
    const tabTaskbar = page.locator('#wl-tab-taskbar');
    await tabTaskbar.focus();
    await tabTaskbar.evaluate((el) =>
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true, cancelable: true, isComposing: true, keyCode: 229 }))
    );
    record('workbenchIgnoresIme229', (await tabTaskbar.getAttribute('aria-selected')) === 'true');
    await page.keyboard.press('ArrowRight');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-tab-launcher' && document.activeElement.getAttribute('aria-selected') === 'true',
      { timeout: 5000 }
    );
    record('workbenchArrowRightMovesFocusAndSelection', true);

    // Responsive 320, 768, 930 (Dawn 901-960px stacked hero), 1440 + High-Contrast hero secondary button border >= 3.0:1
    for (const themeLabel of ['Night', 'Dawn', 'High contrast']) {
      await page.getByRole('button', { name: themeLabel, exact: true }).click();
      for (const [w, h] of [[320, 640], [768, 900], [930, 900], [1440, 900]]) {
        await page.setViewportSize({ width: w, height: h });
        const noOverflow = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
        record(`noHorizontalOverflow_${themeLabel.replace(/\s+/g, '')}_${w}x${h}`, noOverflow);
      }
      if (themeLabel === 'High contrast') {
        const hcContrast = await page.evaluate(() => {
          const hero = document.querySelector('.wl-hero');
          const secBtn = document.querySelector('.wl-hero-actions .wl-doc-button:not(.wl-doc-button-primary)');
          return {
            heroBg: hero ? getComputedStyle(hero).backgroundColor : '',
            btnBorder: secBtn ? getComputedStyle(secBtn).borderTopColor : '',
            btnFg: secBtn ? getComputedStyle(secBtn).color : '',
            btnBg: secBtn ? getComputedStyle(secBtn).backgroundColor : ''
          };
        });
        const heroBg = parseRgb(hcContrast.heroBg);
        const btnBorder = parseRgb(hcContrast.btnBorder);
        const btnFg = parseRgb(hcContrast.btnFg);
        const btnBg = parseRgb(hcContrast.btnBg);
        const borderRatio = heroBg && btnBorder ? contrastRatio(btnBorder, heroBg) : 0;
        const textRatio = btnFg && btnBg ? contrastRatio(btnFg, btnBg) : 0;
        record('highContrastHeroButtonBorderAndTextContrast', borderRatio >= 3.0 && textRatio >= 7.0, JSON.stringify({ borderRatio, textRatio }));
      }
    }

    // Mobile 320x640 Escape focus return on homepage
    await page.setViewportSize({ width: 320, height: 640 });
    const homeToggle = page.locator('#wl-home-nav-toggle');
    await homeToggle.click();
    await page.locator('#wl-home-nav-drawer a').first().focus();
    await page.keyboard.press('Escape');
    await page.waitForFunction(
      () => document.activeElement?.id === 'wl-home-nav-toggle' && document.querySelector('.wl-home-root')?.getAttribute('data-nav-open') === 'false',
      { timeout: 5000 }
    );
    record('homeMobileEscapeReturnsFocusToToggle', true);

    // Static doc pages: 3-way High-Contrast theme toggle + mobile #site-nav Escape focus return + multi-word IME search
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(`http://127.0.0.1:${port}/get-started/index.html`, { waitUntil: 'load', timeout: 15000 });
    const docThemeBtn = page.locator('[data-theme-toggle]');
    await docThemeBtn.click();
    const t1 = await page.evaluate(() => document.documentElement.dataset.theme);
    await docThemeBtn.click();
    const t2 = await page.evaluate(() => document.documentElement.dataset.theme);
    await docThemeBtn.click();
    const t3 = await page.evaluate(() => document.documentElement.dataset.theme);
    record('docThemeToggleCyclesDawnHighContrastNight', t1 === 'dawn' && t2 === 'high-contrast' && t3 === 'night', `${t1}->${t2}->${t3}`);

    await page.setViewportSize({ width: 320, height: 640 });
    const docNavBtn = page.locator('[data-nav-toggle]');
    await docNavBtn.click();
    await page.locator('#site-nav a').first().focus();
    await page.keyboard.press('Escape');
    const docEscOk = await page.evaluate(
      () => document.activeElement?.hasAttribute('data-nav-toggle') && document.getElementById('site-nav')?.hidden === true
    );
    record('docMobileEscapeReturnsFocusToNavToggle', docEscOk);

    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(`http://127.0.0.1:${port}/search/index.html`, { waitUntil: 'load', timeout: 15000 });
    const searchInput = page.locator('input[data-search]');
    await searchInput.evaluate((el) => {
      el.value = 'beta omarchy';
      el.dispatchEvent(new InputEvent('input', { bubbles: true, isComposing: true }));
    });
    const duringCompose = await page.locator('[data-search-results] a').count();
    await searchInput.evaluate((el) => el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true })));
    await page.waitForFunction(() => document.querySelectorAll('[data-search-results] a').length >= 2, { timeout: 5000 });
    const afterCompose = await page.locator('[data-search-results] a').count();
    record('searchGuardsImeComposingAndMatchesMultiWordQuery', duringCompose === 0 && afterCompose >= 2, JSON.stringify({ duringCompose, afterCompose }));

    await context.close();
  } finally {
    await new Promise((r) => server.close(r));
  }
  return checks;
}

function buildAppOnlySnapshot({ publication, query, positive, statusText, closeLabel }) {
  const barControls = [
    { id: 'bar:applications', domId: 'bar:applications', label: 'Applications', detail: '', ariaLabel: 'Open Applications', enabled: true, focusOnly: false, checked: true },
    { id: 'bar:overview', domId: 'bar:overview', label: 'Task View', detail: '', ariaLabel: 'Open Task View', enabled: false, focusOnly: false, checked: null },
    { id: 'bar:switcher', domId: 'bar:switcher', label: 'Switch windows', detail: '', ariaLabel: 'Switch windows', enabled: false, focusOnly: false, checked: null },
    { id: 'bar:notifications', domId: 'bar:notifications', label: 'Notifications', detail: '', ariaLabel: 'Open Notifications', enabled: false, focusOnly: false, checked: null },
    { id: 'bar:files', domId: 'bar:files', label: 'Files', detail: '', ariaLabel: 'Open Files', enabled: false, focusOnly: false, checked: null },
    { id: 'bar:system', domId: 'bar:system', label: 'System', detail: '', ariaLabel: 'Open System menu', enabled: false, focusOnly: false, checked: null },
    { id: 'bar:settings', domId: 'bar:settings', label: 'Settings', detail: '', ariaLabel: 'Open Settings', enabled: false, focusOnly: false, checked: null }
  ];

  const popupControls = [
    { id: 'control:search', domId: 'launcher-search', label: query, detail: '', ariaLabel: 'Search applications', enabled: true, focusOnly: false, checked: null },
    { id: 'control:close', domId: 'control:close', label: closeLabel, detail: '', ariaLabel: 'Close applications and return to windows', enabled: true, focusOnly: false, checked: null },
    { id: 'control:refresh', domId: 'control:refresh', label: 'Refresh', detail: '', ariaLabel: 'Refresh applications', enabled: true, focusOnly: false, checked: null }
  ];

  if (positive) {
    popupControls.push(
      { id: 'jump:open:foot.desktop', domId: 'jump:open:foot.desktop', label: 'Actions for Foot', detail: 'Application actions unavailable in this session', ariaLabel: 'Actions for Foot', enabled: false, focusOnly: false, checked: null },
      { id: 'pin:foot.desktop', domId: 'pin:foot.desktop', label: 'Pin Foot', detail: 'Add to taskbar', ariaLabel: 'Pin Foot', enabled: true, focusOnly: false, checked: null },
      { id: 'entry:foot.desktop', domId: 'entry:foot.desktop', label: 'Open Foot', detail: 'Opening unavailable in this session', ariaLabel: 'Open Foot', enabled: false, focusOnly: false, checked: null },
      { id: 'entry:foot-server.desktop', domId: 'entry:foot-server.desktop', label: 'Open Foot Server', detail: 'Opening unavailable in this session', ariaLabel: 'Open Foot Server', enabled: false, focusOnly: false, checked: null },
      { id: 'entry:footclient.desktop', domId: 'entry:footclient.desktop', label: 'Open Foot Client', detail: 'Opening unavailable in this session', ariaLabel: 'Open Foot Client', enabled: false, focusOnly: false, checked: null }
    );
  }

  return {
    surfaceProtocol: 2,
    publication: String(publication),
    lease: '1',
    mode: 'applications',
    status: statusText,
    motion: 'standard',
    appearance: { theme: 'night', textScale: 100, effectsOff: false, reducedTransparency: false },
    bar: barControls,
    popup: popupControls
  };
}

async function verifyMvpAppOnlyVisualContract(browser, compiledStageDir, strictStatusOracle, strictCloseLabel) {
  const checks = [];
  const record = (name, ok, detail = '') => checks.push({ name, ok: Boolean(ok), detail });
  if (!compiledStageDir || !fs.existsSync(compiledStageDir)) {
    record('mvpStageProvided', false, 'Pass --mvp-stage <isolated-http-stage-dir> under Root custody to run Part B');
    return checks;
  }

  const positiveSnap = buildAppOnlySnapshot({
    publication: 2,
    query: 'foot',
    positive: true,
    statusText: strictStatusOracle ? 'Matching applications are shown, but opening is unavailable in this session.' : 'Choose a matching application.',
    closeLabel: strictCloseLabel ? 'Close applications' : 'Windows'
  });
  const negativeSnap = buildAppOnlySnapshot({
    publication: 3,
    query: 'footz',
    positive: false,
    statusText: 'No matching applications. Change your search or Refresh.',
    closeLabel: strictCloseLabel ? 'Close applications' : 'Windows'
  });

  let activeSnapshot = positiveSnap;
  const server = http.createServer((req, res) => {
    const u = new URL(req.url || '/', 'http://127.0.0.1');
    if (u.pathname === '/events') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify([{ topic: 'presentation', payload: activeSnapshot }]));
      return;
    }
    let rel = u.pathname.replace(/^\/+/, '') || 'index.html';
    const target = path.resolve(compiledStageDir, rel);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      res.writeHead(404).end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream' });
    fs.createReadStream(target).pipe(res);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;

  try {
    const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load', timeout: 15000 });
    await page.locator('[data-surface-control="bar:applications"]').waitFor({ state: 'visible', timeout: 10000 });

    const audit1280 = await page.evaluate(() => {
      const enabledIds = ['bar:applications', 'control:close', 'control:refresh', 'pin:foot.desktop'];
      const disabledIds = [
        'bar:overview', 'bar:switcher', 'bar:notifications', 'bar:files', 'bar:system', 'bar:settings',
        'jump:open:foot.desktop', 'entry:foot.desktop', 'entry:foot-server.desktop', 'entry:footclient.desktop'
      ];
      const checkBtn = (id) => {
        const el = document.querySelector(`[data-surface-control="${id}"]`);
        if (!el) return { id, missing: true };
        return {
          id,
          text: el.textContent?.trim() || '',
          ariaLabel: el.getAttribute('aria-label') || '',
          disabled: el.disabled,
          ariaDisabled: el.getAttribute('aria-disabled'),
          borderStyle: getComputedStyle(el).borderTopStyle
        };
      };
      const actions = document.querySelector('.surface-actions');
      const popupStatus = document.querySelector('.surface-popup [role="status"]')?.textContent?.trim() || '';
      const closeBtn = checkBtn('control:close');
      const allEntriesDisabled = ['entry:foot.desktop', 'entry:foot-server.desktop', 'entry:footclient.desktop'].every(
        (id) => document.querySelector(`[data-surface-control="${id}"]`)?.disabled === true
      );
      return {
        enabled: enabledIds.map(checkBtn),
        disabled: disabledIds.map(checkBtn),
        barFitsAt1280: actions ? actions.scrollWidth <= actions.clientWidth : false,
        popupStatus,
        closeBtn,
        allEntriesDisabled
      };
    });

    record(
      'positiveFootExactEnabledControlsSolid',
      audit1280.enabled.every((c) => !c.missing && c.disabled === false && c.ariaDisabled === 'false' && c.borderStyle === 'solid'),
      JSON.stringify(audit1280.enabled)
    );
    record(
      'positiveFootExactTenUnavailableControlsDashed',
      audit1280.disabled.every((c) => !c.missing && c.disabled === true && c.ariaDisabled === 'true' && c.borderStyle === 'dashed'),
      JSON.stringify(audit1280.disabled)
    );
    record('fullscreen1280FitsAllSevenBarControls', audit1280.barFitsAt1280);

    if (strictStatusOracle) {
      record(
        'appOnlyPositiveMatchStatusDoesNotInstructDisabledLaunch',
        !(audit1280.allEntriesDisabled && audit1280.popupStatus === 'Choose a matching application.'),
        `popupStatus=${JSON.stringify(audit1280.popupStatus)}`
      );
    }
    if (strictCloseLabel) {
      record(
        'closeApplicationsVisibleLabelHonestAndAriaPreserved',
        audit1280.closeBtn.text.includes('Close applications') &&
          audit1280.closeBtn.ariaLabel === 'Close applications and return to windows',
        JSON.stringify(audit1280.closeBtn)
      );
    }

    await page.setViewportSize({ width: 621, height: 750 });
    const audit621 = await page.evaluate(() => {
      const actions = document.querySelector('.surface-actions');
      const barStatus = document.querySelector('.surface-bar [role="status"]');
      const statusRect = barStatus ? barStatus.getBoundingClientRect() : null;
      return {
        overflowX: actions ? getComputedStyle(actions).overflowX : '',
        scrollsAt621: actions ? actions.scrollWidth > actions.clientWidth : false,
        statusWidth: statusRect ? statusRect.width : 0
      };
    });
    record(
      'tiled621PreservesStatusBoxAndUsesOverflowAutoOnToolbar',
      audit621.overflowX === 'auto' && audit621.scrollsAt621 && audit621.statusWidth >= 180,
      JSON.stringify(audit621)
    );

    activeSnapshot = negativeSnap;
    await page.reload({ waitUntil: 'load' });
    await page.locator('[data-surface-field="control:search"]').waitFor({ state: 'visible', timeout: 10000 });
    const negAudit = await page.evaluate(() => ({
      query: document.querySelector('[data-surface-field="control:search"]')?.value,
      entryCount: document.querySelectorAll('[data-surface-control^="entry:"]').length,
      status: document.querySelector('.surface-popup [role="status"]')?.textContent?.trim()
    }));
    record(
      'negativeFootzRetainsQueryAndClearsEntries',
      negAudit.query === 'footz' && negAudit.entryCount === 0 && negAudit.status === 'No matching applications. Change your search or Refresh.',
      JSON.stringify(negAudit)
    );

    await context.close();
  } finally {
    await new Promise((r) => server.close(r));
  }
  return checks;
}

async function main() {
  const args = process.argv.slice(2);
  const getArg = (flag) => {
    const idx = args.indexOf(flag);
    return idx >= 0 && idx + 1 < args.length ? args[idx + 1] : '';
  };
  const siteRoot = getArg('--site-root');
  const mvpStage = getArg('--mvp-stage');
  const strictStatus = args.includes('--strict-app-only-status');
  const strictClose = args.includes('--strict-close-label');

  const { chromium } = require('playwright');
  const browser = await chromium.launch({ headless: true });
  try {
    const report = {
      schema: 1,
      fixture: 'site-decisive-visual-fixture-0138',
      siteChecks: siteRoot ? await verifyConvergedSiteEntrypoints(browser, siteRoot) : [],
      mvpChecks: mvpStage ? await verifyMvpAppOnlyVisualContract(browser, mvpStage, strictStatus, strictClose) : []
    };
    const all = [...report.siteChecks, ...report.mvpChecks];
    report.passed = all.length > 0 && all.every((c) => c.ok);
    process.stdout.write(JSON.stringify(report, null, 2) + '\n');
    process.exitCode = report.passed ? 0 : 1;
  } finally {
    await browser.close();
  }
}

if (require.main === module) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
