{-# LANGUAGE OverloadedStrings #-}
-- Source proposal only. ROOT compiles/runs the separate QA configuration.
-- Requires held-document QA-only public re-export of the engine CPP seam
-- qaForceHeldUnknown/qaHeldBorrowCount (5c433172); no production mutator.
-- Root must register an independent outer fixture guardian before calling: it
-- must retain the exact owned child and handle failed readiness, hook exceptions
-- and timeouts. Probe/worker retention alone is not cleanup or a reap receipt.
-- Caller retains Probe and the resolver-backed fixture executable, including
-- after timeout; it must never retire/close the injected HeldUnknown object.
-- Exact singleton failure reasons require all unrelated cleanup steps to finish
-- under the unchanged StopDeadline; otherwise the assertion fails honestly.
-- These owner-route controls do not prove a native provider, descendant reap,
-- SCM behavior, original deadline compliance or release acceptance.
module TerraGraphStickyOwnerControls0018
 (Probe, newProbe, runLiveStickyUnknown, runPreSpawnStickyUnknown) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar (MVar, newEmptyMVar, putMVar, readMVar)
import Control.Exception (SomeException, mask, mask_)
import Control.Monad (unless, when)
import Data.IORef (IORef, atomicModifyIORef', modifyIORef', newIORef, readIORef, writeIORef)
import System.Timeout (timeout)
import Warlock.Platform.Executable (HeldExecutable, qaForceHeldUnknown, qaHeldBorrowCount)
import Warlock.Capture.Process.Bootstrap (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, PersistentStatus(..), SessionExit(..), StopReceipt(..)
 , newPersistentOwner, persistentHeldNoInput, persistentStatus, persistentUnderlyingStatus
 , requestSessionStop, startBudgetAfter, stopBudgetMicros )
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe
 { ownerRef :: IORef (Maybe PersistentOwner)
 , heldRef :: IORef (Maybe HeldExecutable)
 , workerRef :: IORef (Maybe ThreadId)
 , completed :: MVar Result
 , used :: IORef Bool
 }

newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
                 <*> newEmptyMVar <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("sticky owner: " ++ label)))

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

await :: String -> IO a -> IO a
await label act = do
 out <- timeout 5000000 act
 maybe (ioError (userError ("sticky owner watchdog: " ++ label ++ "; retain Probe"))) pure out

-- A fixture supplier installs the resolver-verified held child and roots every
-- underlying lease before returning. The supplied child must remain alive until
-- explicitly stopped, and readiness must identify that actual owned child.
-- The probe is one-shot and must be held by Root through any uncertainty.
runScenario
 :: Bool -> Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runScenario live probe acquireAndRetain args ready = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 owner <- newPersistentOwner
 writeIORef (ownerRef probe) (Just owner)
 held <- restore (acquireAndRetain owner)
 writeIORef (heldRef probe) (Just held)
 selected <- must (persistentHeldNoInput held args [("LANG","C"),("LC_ALL","C")])
 start <- startBudgetAfter 3000000 >>= must
 stop <- must (stopBudgetMicros 1000000)
 forced <- newIORef False
 stopReceipt <- newIORef Nothing
 spawnEntries <- newIORef (0 :: Int)
 let forceAndStop = do
      count <- qaHeldBorrowCount held
      check "actual held borrow was committed" (count == Just 1)
      qaForceHeldUnknown held
      after <- qaHeldBorrowCount held
      check "held unknown is visible before release" (after == Nothing)
      writeIORef forced True
      receipt <- requestSessionStop owner stop
      writeIORef stopReceipt (Just receipt)
     onSession _ = if live then forceAndStop else pure ()
     hook stage = do
      when (stage == "persistent-after-spawn-reserve") (modifyIORef' spawnEntries (+1))
      when (not live && stage == "persistent-before-spawn") forceAndStop
     action = withPersistentOwnerHook owner selected 4096 start stop ready onSession hook
 _ <- mask_ $ do
  tid <- forkFinally (restore action) (putMVar (completed probe))
  writeIORef (workerRef probe) (Just tid)
  pure tid
 outcome <- restore (await "owner completion" (readMVar (completed probe)))
 didForce <- readIORef forced
 receipt <- readIORef stopReceipt
 entries <- readIORef spawnEntries
 ownerState <- persistentStatus owner
 rawState <- persistentUnderlyingStatus owner
 finalCount <- qaHeldBorrowCount held
 let reason = if live then "borrow-release" else "startup-borrow-release"
     expectedStop = if live then StopSignalSent else StopLatchedBeforeLive
     expected = case outcome of
      Right (Left (ExitUncertain CleanupUncertain [actual])) -> actual == reason
      _ -> False
     quarantined = case ownerState of PersistentQuarantined reasons -> reasons == [reason]; _ -> False
     rawQuarantined = case rawState of Quarantined reasons -> reasons == [reason]; _ -> False
 check "real sticky False quarantines owner and retains unknown" $
  didForce && receipt == Just expectedStop && expected && quarantined && rawQuarantined
   && finalCount == Nothing && (if live then entries == 1 else entries == 0)

runLiveStickyUnknown
 :: Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runLiveStickyUnknown = runScenario True

runPreSpawnStickyUnknown
 :: Probe -> (PersistentOwner -> IO HeldExecutable) -> [String]
 -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runPreSpawnStickyUnknown = runScenario False
