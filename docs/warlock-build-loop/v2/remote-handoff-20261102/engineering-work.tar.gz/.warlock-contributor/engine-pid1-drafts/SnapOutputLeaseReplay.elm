port module SnapOutputLeaseReplay exposing (main)

{-| Source-only QA proposal. All events enter OutputController.update. The host
binding, view scope, capability advertisement and observed geometry are literal
synthetic inputs, not an issuer or a native acknowledgement. Requires the
Snap.Region and GeometryProjection ADT migrations before integration. Root
owns compiler, execution and independent review. -}

import Binding
import Desktop
import Json.Decode as D
import Json.Encode as E
import Motion
import OutputController as Outputs
import Platform
import Shell
import Snap
import Surface
import SurfaceController as Controller
import UInt64

port outgoing : E.Value -> Cmd msg

counter text = D.decodeValue UInt64.decoder (E.string text) |> Result.withDefault UInt64.zero
binding = E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]
scope generation = E.object [("id",E.string "1"),("generation",E.string generation)]
topology = E.object [("viewProtocol",E.int 2),("kind",E.string "view-topology"),("revision",E.string "1"),("views",E.list identity [scope "1"]),("locations",E.list identity [E.object [("scope",scope "1"),("box",E.list E.int [0,0,800,600])]])]
attached = E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",binding)]
pointerIdle = E.object [("protocolVersion",E.int 3),("kind",E.string "pointer-ownership"),("ownershipProtocol",E.int 1),("binding",binding),("requestId",E.string "1"),("serial",E.string "1"),("state",E.string "idle"),("owner",E.null)]
projection = E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",binding),("requestId",E.string "1"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),("output",E.string "1"),("revision",E.string "1")]),("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),("windows",E.list identity [E.object [("incarnation",E.string "1"),("label",E.string "Document"),("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]])])]
step event model = Outputs.update event model |> Tuple.first
incoming wire = step (Outputs.Interaction (Desktop.Incoming wire))
desktop model = Controller.desktop (Outputs.controller model)
settle model =
    (desktop model).motion.pending
        |> Maybe.map (\pending -> incoming (E.object [("protocolVersion",E.int 3),("kind",E.string "motion-profile"),("binding",Binding.encode pending.binding),("requestId",E.string (UInt64.string pending.request)),("profile",E.string (Motion.name pending.profile))]) model)
        |> Maybe.withDefault model

negotiate = E.object [("protocolVersion",E.int 3),("kind",E.string "host-geometry-negotiate")]
caps = E.object [("observe",E.bool True),("effects",E.bool True),("effectProtocol",E.int 2),("operations",E.list E.string ["maximize","restore-geometry","snap","transfer-workspace","pin","unpin","exit-fullscreen"]),("placementCapacity",E.int 256),("canonicalScene",E.bool False)]
geometryAttached request = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-attached"),("geometryProtocol",E.int 3),("binding",binding),("requestId",request),("capabilities",caps)]
sizeProjection logical visual configure = E.object [("logical",E.list E.float logical),("visual",visual),("real",E.list E.float logical),("configure",E.list E.float configure)]
sizePolicy = E.object
    [("inputs",E.object [("profile",E.string "wayland-zero-origin-v1"),("rawMinimum",E.list E.float [1,1]),("rawMaximum",E.list E.float [0,0]),("layoutMinimum",E.list E.float [1,1]),("layoutMaximum",E.list E.float [10000,10000]),("geometryOrigin",E.list E.float [0,0]),("reservedTopLeft",E.list E.float [0,0]),("reservedBottomRight",E.list E.float [0,0]),("monitorScale",E.float 1)])
    ,("maximize",sizeProjection [0,0,800,600] E.null [800,600]),("restoreGeometry",sizeProjection [10,20,320,240] (E.list E.float [10,20,320,240]) [320,240])]
geometryRow = E.object
    [("incarnation",E.string "1"),("owner",E.null),("workspace",E.string "1"),("workspaceGeneration",E.string "4"),("monitor",E.string "0"),("outputOwnershipGeneration",E.string "2"),("workAreaRevision",E.string "3"),("workArea",E.list E.float [0,0,800,600])
    ,("logicalGeometry",E.list E.float [10,20,320,240]),("visualGeometry",E.list E.float [10,20,320,240]),("nativeMode",E.string "ordinary"),("clientMode",E.string "ordinary"),("minimized",E.bool False),("floating",E.bool True),("grouped",E.bool False),("fixedSize",E.bool False),("constrainedSize",E.bool True),("geometryEligible",E.bool True),("ordinaryPlacementKnown",E.bool False)
    ,("capabilities",E.object [("maximize",E.bool True),("restoreGeometry",E.bool False)]),("sizePolicy",sizePolicy),("pin",E.object [("pinned",E.bool False),("eligible",E.bool True)])]
facts request = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-facts"),("geometryProtocol",E.int 3),("binding",binding),("requestId",request),("sequence",E.string "1"),("revision",E.string "1"),("outputGeneration",E.string "1"),("facts",E.object [("focused",E.string "1"),("inputBlocked",E.bool False),("windows",E.list identity [geometryRow])])]
request field model = field (desktop model).windows.shell |> Maybe.map (UInt64.string >> E.string) |> Maybe.withDefault E.null
field name model = D.decodeValue (D.field name UInt64.decoder) (Controller.frame (Outputs.controller model)) |> Result.withDefault UInt64.zero
callback shown lease view identity = E.object [("viewProtocol",E.int 1),("kind",E.string "view-action"),("scope",scope view),("action",E.object [("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("surface",E.string "popup"),("publication",E.string (UInt64.string shown)),("lease",E.string (UInt64.string lease)),("id",E.string identity)])]

result =
    let ready = Outputs.initial |> step (Outputs.Topology topology) |> incoming attached |> incoming pointerIdle |> incoming projection |> settle
        attachPending = incoming negotiate ready
        observedPending = incoming (geometryAttached (request .geometryAttachExpected attachPending)) attachPending
        observed = incoming (facts (request .geometryExpected observedPending)) observedPending
        opened = Desktop.capture (desktop observed) |> Maybe.map (\stamp -> step (Outputs.Interaction (Desktop.OpenSnap stamp (counter "1"))) observed) |> Maybe.withDefault observed
        oldShown = field "publication" opened
        oldLease = field "lease" opened
        closed = Desktop.capture (desktop opened) |> Maybe.map (\stamp -> step (Outputs.Interaction (Desktop.CloseSnap stamp)) opened) |> Maybe.withDefault opened
        reopened = Desktop.capture (desktop closed) |> Maybe.map (\stamp -> step (Outputs.Interaction (Desktop.OpenSnap stamp (counter "1"))) closed) |> Maybe.withDefault closed
        shown = field "publication" reopened
        lease = field "lease" reopened
        fresh = Outputs.update (Outputs.Renderer (callback shown lease "1" "snap:region:right-half")) reopened
        stalePublication = Outputs.update (Outputs.Renderer (callback oldShown lease "1" "snap:region:right-half")) reopened
        staleLease = Outputs.update (Outputs.Renderer (callback shown oldLease "1" "snap:region:right-half")) reopened
        foreignView = Outputs.update (Outputs.Renderer (callback shown lease "2" "snap:region:right-half")) reopened
        freshModel = Tuple.first fresh
        selected = (desktop freshModel).snap |> Maybe.andThen Snap.proposal
        checks =
            [("decodedGeometryAndSnapCapability",(desktop observed).windows.shell.geometry/=Nothing && (desktop observed).windows.shell.geometryCaps/=Nothing)
            ,("enabledSnapHasCurrentPopupOwner",Surface.mode (desktop opened)=="snap" && Surface.mode (desktop reopened)=="snap" && Outputs.owner reopened/=Nothing && List.any (\control -> control.id=="snap:region:right-half" && control.enabled) (Surface.controls (desktop reopened)))
            ,("retiredCountersAreRealAndNonzero",oldShown/=UInt64.zero && oldLease/=UInt64.zero && UInt64.compare oldShown shown==LT && UInt64.compare oldLease lease==LT && Surface.mode (desktop closed)=="closed")
            ,("freshScopedSnapSelectsLiteralRightHalf",selected |> Maybe.map (\p -> p.region==Snap.RightHalf && p.geometry==[400,0,400,600]) |> Maybe.withDefault False)
            ,("freshSelectionOnlyPublishes",List.length (Tuple.second fresh)==1 && List.all (\effect -> case effect of
                Controller.Publish _ -> True
                _ -> False) (Tuple.second fresh))
            ,("stalePublicationDoesNotSelect",Tuple.first stalePublication==reopened && List.isEmpty (Tuple.second stalePublication))
            ,("staleLeaseDoesNotSelect",Tuple.first staleLease==reopened && List.isEmpty (Tuple.second staleLease))
            ,("foreignViewCannotSelect",Tuple.first foreignView==reopened && List.isEmpty (Tuple.second foreignView))]
    in E.object [("checks",E.object (List.map (\(name,ok) -> (name,E.bool ok)) checks)),("scope",E.string "Synthetic decoded protocol and actual output renderer; no native issuer, physical input, or placement acknowledgement.")]

main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\_ state -> (state,Cmd.none),subscriptions=\_ -> Sub.none}
