// UNRUN integration draft. Root's reviewed runner owns the browser, target,
// CDP dispatcher, source/artifact attestation, assertions and cleanup. This
// helper neither launches a browser nor changes any production endpoint.
//
// Before navigating, enable interception with install(); forward every CDP
// event for the target to onEvent(message), without replacing the dispatcher's
// response handling. Never also continue/fail those paused requests elsewhere.
// Only the explicitly named local HTML/JS/CSS asset URLs can reach a server;
// /events and /actions are held and fulfilled in CDP. Unexpected traffic is
// blocked and invalidates the run. Use an isolated fresh browser/profile,
// disable cache and bypass service workers before navigation, intercept all
// child sessions or prove none exist, and bind the full source closure,
// compiler, generated artifacts and harness. check must throw synchronously;
// evaluate must await page promises. All three owner attestation/quiescence
// callbacks must return literal true after verifying their obligations; false,
// undefined, exceptions or timeouts fail. Calls/evaluate must be bounded under
// the owner's one absolute fixture deadline. Keep dispatch active until teardown.
// No operation here establishes physical input, native behavior, IME, AT,
// compositor presentation, timing or original-scenario acceptance.

export function controlledPopupHttp({ call, sessionId, origin, assetUrls,
  assertSourceIdentity, attestFreshIsolatedTarget, quiesceAndDrain, evaluate, until, check,
  sleep, timeoutMs }) {
  const parsed = new URL(origin);
  if (parsed.origin !== origin || parsed.protocol !== 'http:' ||
      parsed.hostname !== '127.0.0.1' || !parsed.port || parsed.username ||
      parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash)
    throw Error('Require a bare local HTTP origin with explicit port');
  if (!sessionId || !Number.isFinite(timeoutMs) || timeoutMs <= 0 ||
      !Array.isArray(assetUrls) || !assetUrls.length)
    throw Error('Require target session, finite timeout and exact asset allowlist');
  const allowed = new Set(assetUrls);
  for (const url of allowed) {
    const value = new URL(url);
    if (value.origin !== origin || value.protocol !== 'http:' ||
        value.username || value.password || value.href !== url || value.search || value.hash ||
        value.pathname === '/events' || value.pathname === '/actions')
      throw Error('Invalid fixture asset URL');
  }
  let installed = false;
  const events = [], posts = [], errors = [], blocked = [], inFlight = new Set();
  const failIfInvalid = () => {
    if (errors.length || blocked.length) throw Error(JSON.stringify({ errors, blocked }));
  };
  const requireTrue = async (promise, label) => {
    if (await promise !== true) throw Error(`${label} did not attest success`);
  };
  const attestTarget = () => requireTrue(attestFreshIsolatedTarget({ origin, sessionId,
    assetUrls: [...allowed], requireCacheDisabled: true, requireServiceWorkerBypass: true,
    requireChildSessionIsolation: true }), 'Target isolation');
  const invoke = (method, params) => call(method, params, sessionId);
  const hold = async (message) => {
    const { requestId, request } = message.params;
    const url = request.url, method = request.method;
    if (url === `${origin}/events` && method === 'GET') {
      events.push({ requestId, done: false });
    } else if (url === `${origin}/actions` && method === 'POST') {
      if (typeof request.postData !== 'string') throw Error('POST body unavailable');
      posts.push({ requestId, body: JSON.parse(request.postData), done: false });
    } else if (method === 'GET' && allowed.has(url)) {
      await invoke('Fetch.continueRequest', { requestId });
    } else {
      blocked.push({ url, method });
      await invoke('Fetch.failRequest', { requestId, errorReason: 'BlockedByClient' });
    }
  };
  const onEvent = (message) => {
    if (message.sessionId !== sessionId || message.method !== 'Fetch.requestPaused') return false;
    const task = hold(message).catch(async error => {
      errors.push(String(error));
      try { await invoke('Fetch.failRequest', { requestId: message.params.requestId, errorReason: 'BlockedByClient' }); }
      catch (failure) { errors.push(String(failure)); }
    });
    inFlight.add(task);
    task.finally(() => inFlight.delete(task));
    return true;
  };
  const waitFor = async (predicate, label) => {
    const deadline = Date.now() + timeoutMs;
    while (!predicate()) {
      failIfInvalid();
      if (Date.now() >= deadline) throw Error(`Bounded fixture wait expired: ${label}`);
      await sleep(10);
    }
    failIfInvalid();
  };
  const fulfill = async (item, status, body, contentType) => {
    if (!item || item.done) throw Error('Missing or already fulfilled intercepted request');
    item.done = true;
    try {
      await invoke('Fetch.fulfillRequest', { requestId: item.requestId,
        responseCode: status,
        responseHeaders: [{ name: 'Content-Type', value: contentType }, { name: 'Cache-Control', value: 'no-store' }],
        body: Buffer.from(body, 'utf8').toString('base64') });
    } catch (error) { errors.push(String(error)); throw error; }
  };
  return {
    onEvent,
    async install() {
      if (installed) throw Error('Interception already installed');
      await attestTarget();
      await invoke('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
      installed = true;
    },
    async assertSourceIdentity(hashes) {
      await requireTrue(assertSourceIdentity(hashes), 'Source and artifact identity');
    },
    async assertNetworkIsolation() {
      if (!installed) throw Error('Interception not installed before navigation');
      await attestTarget();
      failIfInvalid();
    },
    async deliverPresentation(frame) {
      await waitFor(() => events.some(event => !event.done), 'actual GET /events');
      await fulfill(events.find(event => !event.done), 200,
        JSON.stringify({ bridgeProtocol: 1, kind: 'presentation', payload: frame }), 'application/json');
      failIfInvalid();
    },
    actions() { failIfInvalid(); return posts.map(post => structuredClone(post.body)); },
    async waitForActionCount(n) {
      if (!Number.isSafeInteger(n) || n < 1) throw Error('Invalid action count');
      await waitFor(() => posts.length >= n, `actual POST /actions count ${n}`);
    },
    async respondAction(index, status, body) {
      if (!Number.isSafeInteger(index) || status !== 204 || body !== '') throw Error('Expected indexed empty 204 only');
      await fulfill(posts[index], status, body, 'text/plain');
      failIfInvalid();
    },
    evaluate, until, check,
    // A bounded scheduling drain only; not a latency measurement or proof of
    // absence of all future work. The owner must provide a bounded evaluate.
    async settleElm() {
      for (let n = 0; n < 3; n++) await evaluate('new Promise(resolve => setTimeout(resolve, 0))');
      failIfInvalid();
    },
    async finish() {
      // The runner must stop new target requests without discarding intercepted
      // POSTs and drain its dispatcher while interception stays active; merely
      // taking a promise snapshot races CDP. Owned cleanup handles the GET.
      await requireTrue(quiesceAndDrain(), 'Target quiescence and dispatcher drain');
      await Promise.all([...inFlight]);
      failIfInvalid();
      if (posts.some(post => !post.done)) throw Error('Unfulfilled captured POST /actions');
      return { interceptedEvents: events.length, interceptedActions: posts.length,
        unfulfilledEvents: events.filter(event => !event.done).length,
        unfulfilledActions: posts.filter(post => !post.done).length, blocked: [...blocked] };
    }
  };
}
