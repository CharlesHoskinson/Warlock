# Website Elm Beauty Patch (`v2`) & Root VM Live-Usability UX Coordination (`2016` Wave)

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run**: `warlock-20261031-setup` (Coordinator: `lead`; Recurring Advisor: `sol-docs`; UX/Performance Owner: `terra-browser`)
- **Scope**: Ignored exact-claimed source patch + source-bound UX coordination artifacts only. Zero canonical or foreign-dirty mutations; zero compiler, browser, Node, Quint, VM, or GPU execution; zero original-scenario or native acceptance claims.

---

## 1. Ignored Website Elm Beauty Patch (`SiteMainWebsiteLiveContinuity2016v2.patch`)

- **Protected Foreign-Dirty Target (Untouched)**: `/home/charl/code/Warlock/site/src/SiteMain.elm`
  - **Preimage SHA-256**: `f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (verified untouched before and after patch generation)
- **Initial `2016` Patch (`v1`, Preserved Untouched)**:
  - `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteLiveContinuity2016.patch`
  - **SHA-256**: `ee0c21f3bf96336b1909d2d38eb9c9edd9a83861a56f3d76dc5d7d7720aec021` (`postimage`: `370288b8cee59a39e8dee7141cf22d3394f05e5f7b00dee27831912d55b38218`)
- **Peer-Reviewed Superseding `2016` Patch (`v2`)**:
  - `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/SiteMainWebsiteLiveContinuity2016v2.patch`
  - **Patch SHA-256**: `343f62f5670473cf9e5fbdd50b82e0435242a48fb747dff09599b9e665528e93`
  - **Postimage SHA-256**: `0d27e1f560b46c291d9b5723310621554d0866176ddbf1d898d67e29770154e3`

### What `SiteMainWebsiteLiveContinuity2016v2.patch` Delivers

1. **100% Elm (`Browser.element`) + Existing Lacquer v1 Brand & Tokens**:
   - Preserves all simultaneous foreign edits on `site/src/SiteMain.elm` (`f05a3768...`), uses shared `--wl-sys-*` tokens (`tokens.css`, `site.css`, `landing.css`) with zero new JavaScript, zero new pages, and zero duplicate design systems.
   - Retains `2.5rem` (`40px`) minimum interactive target height on `.wl-doc-button`, `.wl-feature-link`, `.wl-home-chip`, and `.wl-home-nav a`, `role="tablist"` with roving `tabindex` + Left/Right/Home/End keyboard navigation on the 8-surface workbench, and `aria-describedby="hero-scope-note"` on the primary hero CTA.
2. **Clear, Accessible CTAs & Plain-English Scope (Incorporating `terra-browser` `01M6CCG6NCE3K5KZQR3MZ8EEJB` + `sol-docs` `01M6CCHNP988CB58WA6CFPWVC7`)**:
   - **Runs in browser now**: Primary CTA `"Try simulated desktop in browser"` (`./test-drive/index.html`, `aria-describedby="hero-scope-note"`) and Scope Card 1 (`"Launch simulated browser test drive"`) clearly state that the browser test drive executes Warlock's compiled Elm surfaces over simulated fixture windows, never a live Wayland session.
   - **Current 28-second diagnostic trial budget (not persistent desktop)**: Hero `#hero-scope-note`, Readiness Tier 2 (`"28s trial budget"`), `viewScopeSection` lead, and Scope Card 2 (`"Build from source · 28s diagnostic trial budget"`) state in plain human English that current source-built diagnostic trials use a **28-second budget rather than a persistent desktop session** while persistent session ownership is in development (framing 28s as the current diagnostic trial budget rather than an intrinsic build limit, per `terra-browser`).
   - **Honest verification counts & unqualified gates**: Accurately reports **`16` of `242` whole requirements** and **`40` of `417` scenarios** accepted on tested source tuples (following `59a2f38ab` accepting whole original `ELM-TEA-002` at `889e9458d`), states **native window controls and provider cleanup remain unqualified** (rather than "unavailable", per `terra-browser`), and makes **zero native Omarchy installer or fake latency promises**.
   - **Accurate source build CTA label**: Labels the `README.md#build-and-contribute` CTA `"Read source build instructions"` (per `sol-docs` `01M6CCHNP988CB58WA6CFPWVC7`, avoiding claiming `README.md#build-and-contribute` contains the live 28s VM driver recipe and never linking the superseded `run-omarchy-mvp.md` 25s guide), alongside `"Frontend build guide"` (`docs/warlock/how-to/build-current-frontend.md`) and `"Build & source docs"` (`docs/warlock/index.md`).

### Bounded Static Verification Executed (Read-Only / Scratch)
- `git apply --check` against `/home/charl/code/Warlock/site/src/SiteMain.elm` (`f05a3768...`): **PASS (`0`)**.
- Forward & reverse `patch -p1` round-trip in isolated tempdir (`f05a3768... -> 0d27e1f5... -> f05a3768...`): **PASS (`0`)**.
- Comment/string-aware Elm delimiter balance (`()[]{}`), `supplementalCss` brace balance, `17` unique `Attr.id` attributes (including `hero-scope-note`), `62` local `./...` paths under `site/`, and `3` `https://github.com/CharlesHoskinson/Warlock/blob/main/...` doc paths on disk (zero `run-omarchy-mvp` references): **PASS**.
- **Explicit non-claims**: `elm make`, headless/live browser rendering, computed contrast/focus/AT verification, and native execution were **not** run by `gemini-site` (Root owns protected builds and checks).

---

## 2. Root VM Live-Usability & `Popup.pendingQuery` UX Coordination

- **Checked Live-Usability Staging & Actual `run-01` (`20:29Z`) (`/home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/`)**:
  - Verified `stage.json` (`0d9c7f4045585137144212ef8af6fdd2f2749d9d4baeb5562b8ec92bdd4bbab1`), `guard-clarifications.json`, `sol-driver-lifetime-2016.md`, and the completed `run-01/host-journey-result.json` (`sha256:9c0ecae8f03992fa8fe8e35e3e1d5188fc59ad171b32ff663031edfe98d6e6fb`) + `run-01/003-applications-ready.png` (`sha256:7f9d83085519d43c46e08cef2ef3895da7d8221e55fb0c3b772d8b3b6659f6f2`).
  - **Observed `run-01` execution & halt boundary**: `run-01` pinned all 3 process identities (`engine` PID `125011` / namespace PID `1`, `broker` PID `124979`, `backend` PID `124930`), rendered the live Elm window at `at: [0, 0], size: [1280, 800]`, matched `applications-ready`, and halted safely *before* dispatching QMP motion #1 (`warlock-live-usability-6e1d6d1152334bb1-0001-motion.json`: `outcome: "not-dispatched"`, `failureType: "AssertionError"` inside `host-driver.py` `fence()` lines `68-70` — where `guard_region` checks `value['clients']` across all mapped windows without filtering `workspace.id`/fullscreen stacking and checks `levels['2'|'3']` against `(10, 7, 129, 50)`), then retired cleanly at `28.704s` (`originalOwnedBirthsRemain: []`, `exactEnabledRestored: true`, `foot` PID `2095` preserved; `providerCleanupQualified: false`, `nativeAccepted: false`).
  - **Concrete Live-Frame UX Observations from `003-applications-ready.png` Coordinated with `terra-browser`**:
    1. **Duplicate status copy across bar and main pane**: `"Applications connected. Window controls unavailable."` renders verbatim twice simultaneously — once in the top-right bar status strip and identically in the full-width status banner under `Choose a window`.
    2. **Misleading empty-state heading in application-only mode**: When only `Applications` is enabled (`Task View`, `Switch windows`, `Notifications`, `Files`, `System`, `Settings` all disabled because window controls are unavailable), the main pane still displays `Choose a window` over an empty dark canvas rather than prompting `"Select Applications above to browse and search apps"` (or opening `Applications` directly when zero window-picker targets exist).
- **Delivered Two-Regime FIFO & Local-Refusal Fixture Spec (`PopupPendingRecoveryCases2016.json`)**:
  - Fulfilling `terra-browser` request `01M6CCE0S6VNEG9D7RK0VA2XRP`, authored `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/PopupPendingRecoveryCases2016.json` documenting:
    1. Exact `Popup.elm:54` merge expression reconciling `terra-browser-pending-query-feedback.patch` (`d38d4d64`) and `gemini-gui-popup-pending-query-mvp-1936.patch` (`2dcce34d`).
    2. **Regime 1** (`dropped-query / same publication P + empty HTTP 204 polls`): why `lastQuery == Just (q, P, L)` suppresses duplicate `surface-query` while `pendingQueryBlocked` disables `control:close` / `control:refresh`.
    3. **Regime 2** (`accepted in-flight query advancing P -> P+1`): why a trailing `surface-action(pub=P)` in FIFO fails `event.shown == publication` (`Surface.elm:542`) and drops without mutation (preserving safety, never rebasing stale `surface-action`s, while explaining why an unblocked button click at `P` is not guaranteed one-click recovery).
    4. **Regime 3** (`Presentation.localEdit` / `Presentation.query` refusal on `>256` / `>512` chars or `DEL` `127`): why `Popup.transition` returns `(model, [])` while live DOM `<input>.value` diverges without visible refusal text.
