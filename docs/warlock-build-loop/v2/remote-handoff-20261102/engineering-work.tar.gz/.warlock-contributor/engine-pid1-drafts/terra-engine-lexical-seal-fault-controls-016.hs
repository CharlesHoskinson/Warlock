{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Isolated QA hook; the same host must retain each
-- Probe, supplied input and an independent guardian for the selected child.
-- No kernel, resolver-close, provider or release acceptance is implied.
module LexicalSealFaultControls (Probe,newProbe,runAfterReadyFault,runPositiveOwned) where
import Control.Exception (SomeException,fromException,try)
import Control.Monad (unless)
import Data.IORef
import System.IO (Handle)
import System.IO.Error (isUserError,ioeGetErrorString)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (SessionObservation,ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),SessionExit(..),StartupAdmissionFailure(..),
  newPersistentOwner,persistentStatus,startBudgetAfter,stopBudgetMicros,withPersistentStartupScope)
import Warlock.Capture.Process.Persistent.Internal
 (persistentFixture,withPersistentOwnerHook,qaWithPersistentStartupScopeSealHook)

data Probe = Probe PersistentOwner (IORef Int) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef 0 <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("lexical seal fault: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure
claim :: Probe -> IO ()
claim (Probe _ _ _ used) = do
 fresh <- atomicModifyIORef' used (\was -> (True,not was))
 check "single use" fresh
runAfterReadyFault :: Probe -> IO ()
runAfterReadyFault p@(Probe owner hooks continuations _) = do
 claim p
 budget <- startBudgetAfter 4000000 >>= need
 result <- try (qaWithPersistentStartupScopeSealHook
  (modifyIORef' hooks (+1) >> ioError (userError "injected after preparation Ready")) owner budget $ \seal -> do
   admitted <- seal
   case admitted of
    Left err -> pure (Left err)
    Right () -> modifyIORef' continuations (+1) >> pure (Right ()))
  :: IO (Either SomeException (Either StartupAdmissionFailure ()))
 phase <- within "phase after fault" (persistentStatus owner)
 replay <- withPersistentStartupScope owner budget (\_ -> pure (Right ()))
 n <- readIORef hooks
 calls <- readIORef continuations
 check "fault after Ready remains quarantined with no continuation or replay" $
  (case result of
   Left ex -> case (fromException ex :: Maybe IOError) of
    Just e -> isUserError e && ioeGetErrorString e == "injected after preparation Ready"
    Nothing -> False
   Right _ -> False) && n == 1 && calls == 0 &&
  (case phase of PersistentQuarantined _ -> True; _ -> False) &&
  replay == Left (StartupAdmissionRefused OwnerBusy)
runPositiveOwned :: Probe -> FilePath -> [String] -> Handle -> IO ()
runPositiveOwned p@(Probe owner hooks verifies _) exe args input = do
 claim p
 budget <- startBudgetAfter 4000000 >>= need
 stop <- need (stopBudgetMicros 1000000)
 result <- qaWithPersistentStartupScopeSealHook (modifyIORef' hooks (+1)) owner budget $ \seal -> do
  admitted <- seal
  case admitted of
   Left err -> pure (Left err)
   Right () -> do
    outcome <- withPersistentOwnerHook owner (persistentFixture exe args input) 4096 budget stop
     (\(_ :: SessionObservation) -> modifyIORef' verifies (+1) >> pure (Left SpawnOrIO))
     (\_ -> pure ()) (const (pure ()))
    pure $ case outcome of Left (StartupRefused SpawnOrIO) -> Right (); _ -> Left StartupAdmissionUnknown
 phase <- within "positive phase" (persistentStatus owner)
 n <- readIORef hooks
 count <- readIORef verifies
 check "real owned session finishes inside sealed scope" $
  result == Right () && n == 1 && count == 1 && phase == PersistentRetired
