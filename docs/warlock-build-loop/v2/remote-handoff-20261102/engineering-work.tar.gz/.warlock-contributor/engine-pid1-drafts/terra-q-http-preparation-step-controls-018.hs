{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; UNEXECUTED. Exactly one Case in an independently guarded process.
-- The real config/display and original StartD are supplied by Root. Retain the
-- Case, its worker and separate guardian on every result or exceptional exit.
module QHttpPreparationStepControls (Mode(..), Case, newCase, releaseBarrier, runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless,void)
import Data.IORef (IORef,newIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
  persistentBackendCounts,qaStepHooks,qaStepObservations)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P

data Mode = NoStopPositive | StopAfterDisplay | StopDuringDisplay deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
  (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current budget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
releaseBarrier :: Case -> IO ()
releaseBarrier (Case _ _ _ release _ _ _) = void (tryPutMVar release ())

-- Config contains the real trusted startup D. The stop budget is the existing
-- fixture 1s, not a replacement for D; external guardian bounds the host.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase (Case owner start entered release completed workerSlot used) mode path = mask $ \restore -> do
  fresh <- atomicModifyIORef' used (\old -> (True,not old))
  check "single isolated case" fresh
  exists <- doesPathExist path
  check "actual owned config exists" (isAbsolute path && exists)
  before <- qaStepObservations
  check "unvisited probes" (before==(0,0,Nothing,Nothing))
  configured <- restore (loadPersistentBackendConfig owner path)
  check "same-owner config succeeded" (configured==Right ())
  let barrier = putMVar entered () >> readMVar release
  case mode of
    StopDuringDisplay -> qaStepHooks barrier (pure ())
    StopAfterDisplay -> qaStepHooks (pure ()) barrier
    NoStopPositive -> qaStepHooks (pure ()) (pure ())
  thread <- forkIOWithUnmask $ \unmask -> do
    result <- try (unmask (takeMVar start >> runPersistentBackend owner))
    putMVar completed result
  writeIORef workerSlot (Just thread)
  putMVar start ()
  restore $ do
    case mode of
      NoStopPositive -> let waitForStat = do
                              (_,n,_,receipt) <- qaStepObservations
                              if n==1 && receipt==Just (Right ()) then pure () else do
                                ended <- tryReadMVar completed
                                case ended of
                                  Just _ -> ioError (userError "actor ended before actual root stat")
                                  Nothing -> threadDelay 1000 >> waitForStat
                        in waitForStat
      _ -> readMVar entered
    (displayEntries,statEntries,displayResult,statResult) <- qaStepObservations
    case mode of
      StopDuringDisplay -> check "inside admitted display; no stat or receipt" $
        displayEntries==1 && statEntries==0 && displayResult==Nothing && statResult==Nothing
      StopAfterDisplay -> check "display complete before next admission" $
        displayEntries==1 && statEntries==0 && displayResult==Just (Right ()) && statResult==Nothing
      NoStopPositive -> check "real root-stat action completed" (displayEntries==1 && statEntries==1 && statResult==Just (Right ()))
    stop <- requestPersistentBackendStop owner
    case mode of
      NoStopPositive -> pure ()
      _ -> check "real owner latches stop during preparation" (stop==P.StopLatchedBeforeLive)
    releaseBarrier (Case owner start entered release completed workerSlot used)
    outcome <- readMVar completed
    case outcome of
      Left problem -> throwIO problem
      Right actual -> do
        (displays,stats,displayReceipt,statReceipt) <- qaStepObservations
        case mode of
          StopDuringDisplay -> check "in-flight completion uncertain and next step never entered" $
            displays==1 && stats==0 && displayReceipt==Just (Left P.StartupAdmissionUnknown) &&
            statReceipt==Nothing && persistentBackendCounts actual==(0,0)
          StopAfterDisplay -> check "latched stop specifically refused root-stat admission" $
            displays==1 && stats==0 && displayReceipt==Just (Right ()) &&
            statReceipt==Just (Left (P.StartupAdmissionRefused SessionClosed)) &&
            persistentBackendCounts actual==(0,0)
          NoStopPositive -> check "real unstopped root stat completed" (displays==1 && stats==1 && statReceipt==Just (Right ()))
