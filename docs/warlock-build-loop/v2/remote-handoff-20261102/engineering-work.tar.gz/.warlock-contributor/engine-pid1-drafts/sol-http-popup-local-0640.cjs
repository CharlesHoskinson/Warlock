'use strict';
// Independent SOURCE literals for Root-only compiled owning-root replay.
// Never import a reducer or manufacture expectations from an actual run.
// Immutable baseline ab7af2ab supplies the independently transcribed initial
// shape below; this module has no policy-oracle or executable-model dependency.
const C = (tag, ...args) => Object.fromEntries([['$', tag], ...args.map((v, i) => [String.fromCharCode(97+i), v])]);
const N = () => C('Nothing');
const J = value => C('Just', value);
const L = values => values.reduceRight((tail, head) => C('::', head, tail), C('[]'));
const U = value => C('Counter', String(value));
const D = () => C('RBEmpty_elm_builtin');
const JSONV = value => ({ $: 0, a: value });
const SUB = () => ({ $: 2, m: C('[]') });
const DESC = (module, values) => ({ module, effects: L(values) });
const H = values => DESC('UiHttp', values);
const P = values => DESC('Popup', values);
const EMPTY = () => [];
const KEY = (query, pub, lease) => J(C('#3', query, U(pub), U(lease)));
const EDIT = (kind, query, pub = '1', lease = '1') => ({ surfaceProtocol: 2, surface: 'popup', kind,
  publication: String(pub), lease: String(lease), id: 'control:search', query });
const QUERY = (query, pub = '1', lease = '1') => EDIT('surface-query', query, pub, lease);
const ACTION = (id, pub = '1', lease = '1') => ({ surfaceProtocol: 2, surface: 'popup',
  kind: 'surface-action', publication: String(pub), lease: String(lease), id });
const DISPATCH = wire => [C('Dispatch', JSONV(wire))];
const READ = () => C('ReadEvents');
const SEND = wire => C('SendRenderer', JSONV(wire));
function initialPopup() {
  const preview = C('Model', D(), N(), { observed: N(), settled: N(), channel: N(), processed: U(0) },
    { grant: N(), closing: false, closed: false, processed: U(0), completed: D() });
  return { announcements: C('Model', {last: U(0), active: false, message: N()}),
    presentation: C('Model', {last: U(0), lease: U(0), snapshot: N()}),
    previews: C('Model', preview, N(), N(), L([])), paintGate: C('Model', U(0), D()),
    pendingQuery: N(), composition: C('Idle'), lastQuery: N() };
}
function http(active = null, pending = [], failed = null) {
  return C('Model', { role: C('Renderer'), pending: L(pending.map(JSONV)),
    active: active === null ? N() : J(JSONV(active)), polling: true,
    failed: failed === null ? N() : J(C(failed)) });
}
function control(id, label, domId) {
  return {id, domId, label, ariaLabel: label, detail: '', enabled: true};
}
function snapshot(pub, lease, query) {
  // Enabled entry is a positive control: pending/preedit refuses it despite
  // exact admitted scope and an enabled underlying presentation row.
  const popup = [control('control:search', query, 'fixture-search'),
    control('control:close', 'Close', 'fixture-close'),
    control('control:refresh', 'Refresh', 'fixture-refresh'),
    control('entry:sample.desktop', 'Sample', 'fixture-sample')];
  return { surfaceProtocol: 2, publication: String(pub), lease: String(lease),
    mode: 'applications', status: 'Ready', bar: [], popup };
}
function presentation(raw) {
  const rows = raw.popup.map(({id, ...rest}) => ({identity: id, ...rest, focusOnly: false, checked: N()}));
  const decoded = C('Snapshot', { publication: U(raw.publication), lease: U(raw.lease), keyboardParent: N(),
    mode: raw.mode, status: raw.status,
    appearance: { theme: C('Night'), textScale: 100, effectsOff: false, reducedTransparency: false },
    motion: 'reduced', bar: L([]), popup: L(rows) });
  return C('Model', {last: U(raw.publication), lease: U(raw.lease), snapshot: J(decoded)});
}
const STATE = (popup, transport) => ({popup, http: transport});
function expectation(state, descriptions, returns) {
  return {state, subscriptions: SUB(), descriptions, transportReturns: returns};
}
const transition = (state, effects, event = N()) => ({kind: 'transition', value: C('#3', state, L(effects), event)});
function init() {
  const state = STATE(initialPopup(), http());
  return {input: {kind: 'init'}, expected: expectation(state, [H([READ()])],
    [{kind: 'startup', value: C('#2', state.http, L([READ()]))}])};
}
function presented(raw, popupAfter, transport = http()) {
  const gateway = {bridgeProtocol: 1, kind: 'presentation', payload: raw};
  const preview = [C('PreviewCommand', JSONV([])), C('PaintRequest', JSONV([]))];
  return {input: {kind: 'polledOk', body: JSON.stringify(gateway)},
    expected: expectation(STATE(popupAfter, transport), [H([READ()]), P(preview)],
      [transition(transport, [READ()], J(C('Incoming', JSONV(gateway))))])};
}
function action(input, popupAfter, transportAfter, popupEffects, options = {}) {
  const descriptions = [];
  // Actual LocalAction recursively calls transition(Action rebasedValue).
  // Observe both complete typed lists; interpret only the OUTER list once.
  const count = options.rejectedLocal ? 1 : input.kind === 'viewLocalAction' ? 2 : 1;
  for (let i=0; i<count; i++) descriptions.push(P(popupEffects));
  const returns = [];
  if (options.enqueue) {
    descriptions.push(H(options.httpEffects || []));
    returns.push(transition(transportAfter, options.httpEffects || []));
  }
  return {input, expected: expectation(STATE(popupAfter, transportAfter), descriptions, returns)};
}
function posted(popup, transportAfter, effects, failed = false) {
  const kind = failed ? 'postedNetworkError' : 'postedOk';
  const input = failed ? {kind} : {kind, body: ''};
  const event = failed ? J(C('Lost', 'UI delivery is unconfirmed. The action will not be repeated.')) : N();
  return {input, expected: expectation(STATE(popup, transportAfter), [H(effects)], [transition(transportAfter, effects, event)])};
}
const LOCAL = value => ({kind: 'viewLocalAction', value});
const BUTTON = value => ({kind: 'viewAction', value});
function build() {
  const base = initialPopup();
  const raw1 = snapshot(1, 1, '');
  const shown1 = {...base, presentation: presentation(raw1)};
  const qSam = QUERY('sam');
  const sam = {...shown1, pendingQuery: J('sam'), lastQuery: KEY('sam',1,1)};
  const refresh = ACTION('control:refresh');
  const raw2 = snapshot(2,1,'sam');
  const settled2 = {...sam, presentation: presentation(raw2), pendingQuery: N()};
  const repeated2 = {...settled2, lastQuery: KEY('sam',2,1)};
  const start2 = {...repeated2, composition: C('Preediting', {baseline: 'sam', before: N()}), pendingQuery: J('sam')};
  const preedit2 = {...start2, pendingQuery: J('samx')};
  const raw3 = snapshot(3,2,'fresh');
  const rebound = {...base, presentation: presentation(raw3)};
  const reboundRepeated = {...rebound, lastQuery: KEY('fresh',3,2)};
  const localFromOld = (kind, value) => LOCAL(EDIT(kind,value,1,1));
  const cancelled = {...preedit2, composition: C('Idle'), pendingQuery: N()};
  const held = {...sam, composition: C('Preediting', {baseline: 'sam', before: J('sam')})};
  const heldEdit = {...held, pendingQuery: J('samx')};
  const committedAfterLoss = {...heldEdit, composition: C('Idle'), lastQuery: KEY('samx',1,1)};
  const loss = http(qSam,[], 'DeliveryUnconfirmed');
  const composeEmpty = {...shown1, composition: C('Preediting', {baseline: '', before: N()}), pendingQuery: J('')};
  const composeAccent = {...composeEmpty, pendingQuery: J('é')};
  const accent = {...composeAccent, composition: C('Idle'), lastQuery: KEY('é',1,1)};
  const qAccent = QUERY('é');
  return {cases: [
    {name: 'HttpPopup-local-rebase-pending-refresh-confirmation-cancel-and-new-lease', root: 'HttpPopup', steps: [
      init(), presented(raw1,shown1),
      action(LOCAL(qSam),sam,http(qSam),DISPATCH(qSam), {enqueue: true, httpEffects: [SEND(qSam)]}),
      action(BUTTON(ACTION('entry:sample.desktop')),sam,http(qSam),EMPTY()),
      action(BUTTON(refresh),sam,http(qSam,[refresh]),DISPATCH(refresh),{enqueue: true}),
      posted(sam,http(refresh),[SEND(refresh)]),
      presented(raw2,settled2,http(refresh)),
      posted(settled2,http(),[]),
      action(localFromOld('surface-query','sam'),repeated2,http(),EMPTY()),
      action(localFromOld('surface-composition-start','sam'),start2,http(),EMPTY()),
      action(localFromOld('surface-preedit','samx'),preedit2,http(),EMPTY()),
      action(BUTTON(ACTION('control:refresh',2,1)),preedit2,http(),EMPTY()),
      action(localFromOld('surface-composition-end','sam'),cancelled,http(),EMPTY()),
      presented(raw3,rebound),
      action(localFromOld('surface-query','late'),rebound,http(),EMPTY(),{rejectedLocal: true}),
      action(LOCAL(QUERY('fresh',3,2)),reboundRepeated,http(),EMPTY()),
    ]},
    {name: 'HttpPopup-composition-retained-after-post-loss-no-wire-replay', root: 'HttpPopup', steps: [
      init(), presented(raw1,shown1),
      action(LOCAL(qSam),sam,http(qSam),DISPATCH(qSam),{enqueue: true,httpEffects: [SEND(qSam)]}),
      action(LOCAL(EDIT('surface-composition-start','sam')),held,http(qSam),EMPTY()),
      action(LOCAL(EDIT('surface-preedit','samx')),heldEdit,http(qSam),EMPTY()),
      action(BUTTON(ACTION('entry:sample.desktop')),heldEdit,http(qSam),EMPTY()),
      posted(heldEdit,loss,[C('CancelEvents'),C('CancelPost')],true),
      action(LOCAL(EDIT('surface-composition-end','samx')),committedAfterLoss,loss,DISPATCH(QUERY('samx')),{enqueue: true}),
      posted(committedAfterLoss,loss,[]),
      action(LOCAL(QUERY('samx')),committedAfterLoss,loss,EMPTY()),
    ]},
    {name: 'HttpPopup-source-composition-callback-commits-once-and-duplicate-end-inert', root: 'HttpPopup', steps: [
      init(), presented(raw1,shown1),
      action(LOCAL(EDIT('surface-composition-start','')),composeEmpty,http(),EMPTY()),
      action(LOCAL(EDIT('surface-preedit','é')),composeAccent,http(),EMPTY()),
      action(LOCAL(EDIT('surface-composition-end','é')),accent,http(qAccent),DISPATCH(qAccent),{enqueue: true,httpEffects:[SEND(qAccent)]}),
      action(LOCAL(EDIT('surface-composition-end','é')),accent,http(qAccent),EMPTY()),
    ]},
  ]};
}
module.exports = {schema: 1, build, coverage: {complete: false, roots: ['HttpPopup'],
  scope: 'complete HttpPopup Model/Sub.none and every reached typed effect/pure transport return; independent source literals',
  limits: ['unexecuted source proposal; Root-only compiled owning-root execution',
    'synthetic composition callbacks do not qualify native IME, AT, focus or caret',
    'no real network/provider acknowledgement or native operation',
    'HTTP completion never substitutes for a matching presentation',
    'late field edits after stopped transport are boundary negatives, not interactive DOM delivery',
    'Cmd interpretation needs separate optimized-root boundary checks']}};
