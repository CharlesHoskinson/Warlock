# Independent Source-Bound Audit: `05` GREEN Report (`1793560906209268899`), Follow-On `06` (`1793561026384253514`), and Whole `ELM-TEA-002` Purity / Typed-Effect Interpreter Checklist

- **Author / Reviewer Identity**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Run / Coordinator / Advisors**: `warlock-20261031-setup`; sole coordinator `lead` (Root); recurring advisor `sol-docs` (Sol HIGH); 15th UX/performance owner `terra-browser`
- **Observed Base Git Commit**: `873d9c51809f594d2c615c2dfd6877e0d2fa8333` (working tree uncommitted candidate tuple recorded in `component-observation.json`)
- **Active Slice**: `.warlock-contributor/tea-model-effects.json` (`ELM-TEA-001` `tea-typed-model`, `ELM-TEA-002` `tea-pure-update`; `ELM-TEA-005` not selected)
- **Disposition / Non-Preacceptance**: **Component & Source-Route Audit Only — NO Whole-EARS, Native, or Release Preacceptance.** Historical delivery counts remain **`15 / 242` whole requirements** and **`39 / 417` scenarios**; host `nativeOperations = []`; `HOSTSTOP2` preserved; zero VM/QMP/compiler/model/QA executions performed by this reviewer.

---

## 1. Literal Original `ELM-TEA-002` Contract & Boundary Ruling (`docs/elm-roadmap/requirements.json:4867-4889`)

| Field | Exact Original Text | Source-Bound Audit Implication |
|---|---|---|
| **ID / Scenario** | `ELM-TEA-002` / `tea-pure-update` | Active WIP1 alongside `ELM-TEA-001` (`tea-typed-model`). |
| **EARS Statement** | *"The Elm frontend SHALL implement state transitions as pure Model and Msg reducers with typed effect descriptions, and SHALL reproduce identical models and effects for identical sanitized message histories."* | Decomposes into three exact obligations: **(2A)** pure `Model`/`Msg` transition reducers across the Elm frontend, **(2B)** typed `Effect` descriptions (not opaque `Cmd` in business/state reducers), and **(2C)** deterministic reproduction of identical models and effects across identical **sanitized** message histories. |
| **Verification** | *"Typed compiler checks, deterministic replay and independent boundary fixtures with source hashes; native behavior qualified separately."* | Explicitly **forbids** inventing a universal VM/native gate for `ELM-TEA-002`. Native GUI/input/AT/IME/cleanup remain separately gated (`nativeOperations = []`). |
| **Scenario Oracle** | *"the declared contract holds, exact models and effect descriptions match the fixture and no native acceptance is inferred."* | Structural comparison of complete models, structural `Policy.Publish E.Value` payloads, exact embedded `OutputController.Batch.wire : String` values, and exact `Policy.Delay Float Desktop.Msg` values satisfies the literal oracle. **Arbitrary JS `JSON.stringify` property key byte-ordering of `Publish` `E.Value` objects is not part of Elm's reducer semantics or `ELM-TEA-002`.** |

---

## 2. Independent Verification of `05` GREEN Report (`1793560906209268899`), Retained RED Reports, and Follow-On `06` (`1793561026384253514`)

### 2.1 Retained RED History Verification (Preserved, Unmasked)
1. **Retained RED #1 — `/home/charl/code/Warlock/.warlock-contributor/elm-cpu-1793560764634625506/report.json`**
   - **SHA-256**: `609c9c86d724d3e7f6bb834ff2e3b244c0c3a2177639ab6b041cfb13c58fa3c8`
   - **Fact**: All `6` `--optimize` production roots (`Main`, `Bar`, `Popup`, `HttpMain`, `HttpBar`, `HttpPopup`) plus `FeedbackContextReplay` and `UiHttpReplay` passed; `compile-typed-notifications` failed Elm shadowing check on three local QA lambda names shadowing top-level `result` in `qa/NotificationsReplay.elm`. Repaired by renaming QA local lambda bindings only; zero production model or assertion changes.
2. **Retained RED #2 — `/home/charl/code/Warlock/.warlock-contributor/elm-cpu-1793560824139363218/report.json`**
   - **SHA-256**: `3aad8b7e8595ff45de602fb85ad4d8f73ff8c1a8af0b363d876d2192ab4893fe`
   - **Fact**: `qa/NotificationRelevanceReplay.elm` (`d5ec4f6102587e59180c0cf10061cb2c87954456e900ed0235703fbca9ebf6c4`) omitted current-binding `pointer-ownership` `idle` setup input, causing the real production `PointerOwnership` gesture guard to refuse notification setup. Repaired strictly in QA setup (`de99c29c7d40cd8cf253e54e9e960519745aab39df054465df85502c8d980466`, `20` checks); zero production authority or gesture guards relaxed.

### 2.2 Assigned `05` GREEN Component Report (`elm-cpu-1793560906209268899`)
- **Report Path**: `/home/charl/code/Warlock/.warlock-contributor/elm-cpu-1793560906209268899/report.json`
  - **SHA-256**: `9f85f4555f555ba65095d81c3dcb2440a1da44e4430a04019907efb410c18b07`
  - **Execution Isolation**: `19` serialized commands, all `exit: 0`, inside 1-core `systemd` scope `qa-harness-3862898c3ba04b1cb73c7b74b099fb02.scope` (`AllowedCPUs: 1`, `MemoryMax: 8G`, `TasksMax: 512`), Elm `0.19.1` (`c4db5a7e...`), Node `v24.22.1` (`e32e2d16...`).
- **6 `--optimize` Production Roots Verified (`exit: 0`)**:
  - `Main.js`: `c825ef5a990bf3e74c45d191188a5d8e526b0786a5e487a1d5cb814ba8b73e16` (`Main.elm` `a63de0a1...`)
  - `Bar.js`: `3409c3b5599238922f1afac9f3b8681bc0bc1fcba0954586544643ad54fa36b6` (`Bar.elm` `aa3cd927...` — byte-identical to prior `1793559549930167342` because `Bar` consumes `SurfaceSnapshot` only)
  - `Popup.js`: `3aeb35c1d7e1e719c26cc4a9573b8f977f0c4c2f9fc578e23f01990e91b6b66f` (`Popup.elm` `fb24afed...` — byte-identical)
  - `HttpMain.js`: `ef8f4aa6f6a3c74d61dcbf7ad938e3d06d0c0fa5cb329cbeb1c7f19ac7a010ee` (`HttpMain.elm` `58a3b1f2...`)
  - `HttpBar.js`: `661f044cb190105a4d1dbac2237dc63554b6fd110e1067608be1ed7f767ebaf7` (`HttpBar.elm` `74d4b6b8...` — byte-identical)
  - `HttpPopup.js`: `e57e0923c6c07716e3a734af0d40942df9a5b6fd17ccfc162bbda9c52b2900b6` (`HttpPopup.elm` `4185692e...` — byte-identical)
- **4 `--optimize` Typed-State Workers (`87` Checks, All `passed: true`)**:
  - `typed-state.json` SHA-256: `e0d587e272be908aaba2e8e365d13fba42ecc4124028e3c494e988d3e14aad59` (`qa/typed-state.cjs` `cf6e8b17...`)
  - Exact check breakdown: `NotificationsReplay` (`24`) + `JumpListReplay` (`23`) + `NotificationRelevanceReplay` (`20`) + `RetirementProofReplay` (`20`) = **`87` checks** verifying finite ADTs in `Notifications.elm` (`e61311c3...`), `JumpList.elm` (`2ef6dbc9...`), `ReconciliationFrame.elm` (`5f9480ab...`), `Surface.elm` (`91d38d81...`), and `OutcomeAnnouncements.elm` (`e1160f27...`).
- **`tea-contract` Owning-Route Replay (`42` Histories, `101` Tested Transitions, `15` Preludes, `2` Runs/Case)**:
  - `tea-contract.stdout` SHA-256: `c7502045fd0b33ea7c1ad1a4e22ee7653f69138c4158fcd4bf7da68199244e98`
  - Reversible 85-byte observer hook at byte offset `7279` (`TEA_CONTRACT_OBSERVE_V1`): `tea-contract.js` `9ab8c194562a3ac7648e0130e15122adf19bdcf47c3c6b6f874270d360ecadf6` -> instrumented `2061481549bee5504b4c2b67f2372839c25435ede8c3f4746fd414e7d01e17ad` (`reversiblePatch: true`, zero opaque constructors exposed in production Elm).
  - Exact transition arithmetic (`qa/tea-contract-cases.cjs` `015e13d6e2a0bc3835f4e82c1fe8a6bb60f0408aba868c589f234d7b49562969`):
    - `26` `baseCases`: `52` tested transitions, `0` setup preludes.
    - `6` `pinCases`: `12` tested transitions, `6` setup preludes (`setupTimers: 0`).
    - `10` `additionalCases`: `catalog-rebind-new-frontend-no-old-replay` (`7` transitions, `0` preludes) + `4 × pin-pending-invalid-status-{Stored,Bogus,saved,empty}` (`12` transitions, `4` preludes) + `2 × window-minimize-{committed,refused}-duplicate-and-stale` (`6` transitions, `2` preludes) + `window-pending-disconnect-rebind-historical-receipt` (`6` transitions, `1` prelude) + `2 × launch-delay-{exact-timeout-and-stale-token,stale-after-matching-submitted}` (`6` transitions, `2` preludes) = `37` tested transitions, `9` setup preludes.
    - **Verified Sum**: `26 + 6 + 10 = 42` cases; `52 + 12 + 37 = 101` tested transitions; `0 + 6 + 9 = 15` setup preludes excluded; `runsPerCase = 2` fresh Node VM contexts per case.
  - Honest scope flags in `05`: `coverageDeclaration.complete: false`, `missing: ["pending-preference-finite-status", "whole-frontend-contract-review"]`, `wholeTeaStatus: "NOT_ASSESSED"`.

### 2.3 Follow-On `06` Preference-Integrated GREEN Report (`elm-cpu-1793561026384253514`)
- **Report Path**: `/home/charl/code/Warlock/.warlock-contributor/elm-cpu-1793561026384253514/report.json` (`6e2124772c3a7f831633994ca963fa1536c88a3caa07827daece247f85b22e5d`)
- **Component Observation**: `implementation/warlock/qa/evidence/tea-typed-state-20261101/component-observation.json` (`602b1065fda198d57807f0fddb7d229520e449caff3bb2abd02f7b69a63bbc14`)
- **Delta from `05` -> `06`**: All `6` compiled root JS hashes and `87` typed-state checks are byte-identical to `05`; `qa/tea-contract-cases.cjs` (`ab9d3f43d5bbe5b8588274e839d1530e145a68f92d651056a3a694b4735e7b59`) adds `16` pending-preference & UX malformed-status cases (`tea-contract.stdout` `6900e27d41e74372456bcd0d184769d937183cc5d70c6bcde3a0ff388fe08d82`: **`58` complete histories, `134` tested transitions, `31` setup preludes, `runsPerCase: 2`**, `passed: true`), leaving `coverageDeclaration.missing: ["whole-frontend-contract-review"]`.

---

## 3. Complete `ELM-TEA-002` Source-Route Purity & Typed-`Effect` vs `Cmd` Interpreter Audit

### 3.1 108-Module `implementation/warlock/src/` Purity Census
A complete lexical/import audit across all `108` `.elm` files in `implementation/warlock/src/` establishes:
1. **Zero Impure Standard Imports**: **Zero** modules in `src/` import `Random`, `Time`, `File`, or `Bytes`.
2. **Domain / Authority / View Layer Purity (`100%` Pure)**: Every domain, protocol, authority, reconciliation, preference, shell, taskbar, menu, files, snap, workspace, notifications, jump-list, and presentation module in `src/` is pure (no `port`, no `Cmd`, no `Task`, no `Process`, no `Http`, no `Browser.Dom`).
3. **Standalone Non-Root Port Harnesses**: All `*Replay.elm` modules in `src/` plus `NativePreviewAdmission.elm` (`ef5c5aa2...`) and `NativePreviewRenderer.elm` (`91c7bf75...`) are standalone `Platform.worker` port harnesses **not imported by any of the 6 production roots**.
4. **Effectful Boundary Modules**: Across the 6 production roots' transitive import closure, **only** `Main.elm`, `Bar.elm`, `Popup.elm`, `HttpMain.elm`, `HttpBar.elm`, `HttpPopup.elm`, and `UiHttp.elm` mention `port`, `Cmd`, `Sub`, `Task`, `Process`, `Http`, `Browser`, or `Browser.Dom`.

### 3.2 Six-Root Reducer & Effect-Interpreter Matrix

| Production Root (SHA-256) | Pure Reducer Entrypoint & Signature | Typed `Effect` ADT | Root `Cmd` Interpreter | `ELM-TEA-002` Purity / Typed-Effect Audit Verdict |
|---|---|---|---|---|
| **`Main.elm`** (`a63de0a1...`) -> **`DesktopPolicy.elm`** (`018934fe...`) | `DesktopPolicy.update : Msg -> Model -> (Model, List Effect)` (`DesktopPolicy.elm:15-23`) | `type Effect = Publish E.Value \| Delay Float Desktop.Msg` (`DesktopPolicy.elm:11`) | `Main.interpret : Policy.Effect -> Cmd Policy.Msg` (`Main.elm:15-19`): `Publish -> surfaceCommits`, `Delay -> Process.sleep \|> Task.perform (\_ -> Policy.Deadline msg)` | **CLEAN.** `Main.elm` (`27` lines) contains zero policy or branching logic; 100% of state transitions and typed effect emission live in pure `DesktopPolicy.update`. |
| **`Bar.elm`** (`aa3cd927...`) | `Bar.step : Msg -> Model -> (Model, List Effect)` (`Bar.elm:47-101`) | `type Effect = Dispatch E.Value \| ResetStatusViewport StatusScroll.Epoch String` (`Bar.elm:26-28`) | `Bar.main` `interpret` + `Bar.localEffect` (`Bar.elm:122-130, 156-169`): `Dispatch -> actions`, `ResetStatusViewport _ id -> Browser.Dom.setViewportOf id 0 0 \|> Task.attempt (\_ -> ViewportSettled)` | **CLEAN IN SOURCE; REPLAY NOT IN `05`/`06` SLICE.** Pure `Bar.step` owns all state/effect transitions; `qa/StatusScrollReplay.elm` (`274cacb5...`) drives `Bar.step` directly, but is not yet included in the `tea-typed-state` / `tea-contract` evidence run. |
| **`Popup.elm`** (`fb24afed...`) | `Popup.transition : Msg -> Model -> (Model, List Effect)` (`Popup.elm:65-145`) | `type Effect = Dispatch E.Value \| PreviewCommand E.Value \| PaintRequest E.Value` (`Popup.elm:36`) | `Popup.update : Msg -> Model -> (Model, Cmd Msg)` (`Popup.elm:56-63`): maps 1-for-1 to `actions`, `previewCommands`, `previewPaintRequests` | **CLEAN IN SOURCE; EFFECT REPLAY GAP IN QA.** Pure `Popup.transition` owns all state/effect transitions (including IME `Composition` draft rules). However, `qa/LocalFieldReplay.elm` and `qa/ImeReplay.elm` call `Popup.update (...) \|> Tuple.first`, discarding effects rather than asserting `(Popup.Model, List Popup.Effect)`. |
| **`HttpMain.elm`** (`58a3b1f2...`) + **`UiHttp.elm`** (`3a649f51...`) | `DesktopPolicy.update` for domain; `HttpMain.update : Msg -> Model -> (Model, Cmd Msg)` (`HttpMain.elm:33-46`) for transport glue | Reuses `DesktopPolicy.Effect` for domain; **`UiHttp` has NO typed `Effect` ADT** (`UiHttp.update : Msg -> Model -> (Model, Cmd Msg, Maybe Event)`) | `HttpMain.interpret` (`HttpMain.elm:20-31`) maps `Policy.Publish -> UiHttp.enqueue` and `Policy.Delay -> Process.sleep`; `UiHttp` builds `Http.request` / `Http.cancel` / `Process.sleep 100` directly | **TWO BOUNDARY FINDINGS (H1 & H2 — see §3.3).** Domain policy is pure via `DesktopPolicy.update`, but (H1) `UiHttp` returns `Cmd Msg` directly, and (H2) `HttpMain.lost` (`lines 15-18`) discards `Tuple.second` of `Policy.update Policy.TransportLost`. |
| **`HttpBar.elm`** (`74d4b6b8...`) | Delegates `"presentation"` / `"announcements"` / `View` / `ViewportSettled` to pure `Bar.step`; `HttpBar.update : Msg -> Model -> (Model, Cmd Msg)` (`HttpBar.elm:22-50`) | Reuses `Bar.Effect` for `Bar.step`; **no typed `Effect` for `"focus"` or unknown-gateway `stop`** | `HttpBar.apply` (`lines 52-63`) maps `Bar.Dispatch -> UiHttp.enqueue`, `Bar.ResetStatusViewport -> Bar.localEffect`; `HttpBar.update` (`lines 40-47`) calls `Browser.Dom.focus` and `UiHttp.stop` directly | **BOUNDARY FINDING H3 (see §3.3).** `"focus"` gateway frames (`Presentation.focusTarget False ... -> Browser.Dom.focus`) and unknown-gateway `UiHttp.stop` execute directly inside `Cmd`-returning `HttpBar.update`. |
| **`HttpPopup.elm`** (`4185692e...`) | Delegates `"presentation"` / `"announcements"` / `View` to pure `Popup.transition`; `HttpPopup.update : Msg -> Model -> (Model, Cmd Msg)` (`HttpPopup.elm:29-63`) | Reuses `Popup.Effect` for `Popup.transition`; **no typed `Effect` for `"focus"` or `supported` fail-closed `stop`** | `HttpPopup.step` (`lines 30-45`) & `HttpPopup.update` (`lines 53-61`) call `UiHttp.enqueue`, `UiHttp.stop`, and `Browser.Dom.focus` directly | **CONCRETE POLICY-IN-`Cmd` FINDING H4 (see §3.3).** `HttpPopup.elm:54` evaluates `current.popup.composition == Popup.Idle` (IME focus-suppression policy) and `HttpPopup.elm:19-25, 33-35` evaluates `supported` fail-closed stop directly inside `Cmd`-returning `HttpPopup.update`. |

### 3.3 Detailed Technical Analysis of HTTP-Profile Findings (H1–H4)

1. **Finding H4 (Highest Relevance to Literal `ELM-TEA-002` — Stateful Policy Guard Inside `Cmd`-Returning `HttpPopup.update`)**:
   - In `implementation/warlock/src/HttpPopup.elm:53-59`:
     ```elm
     Just ("focus",payload) ->
         let target=if current.popup.composition==Popup.Idle then Presentation.focusTarget True payload current.popup.presentation else Nothing
             focusCommand=target |> Maybe.map (\id -> Browser.Dom.focus id |> Task.attempt (\_ -> Focused)) |> Maybe.withDefault Cmd.none
         in (current,Cmd.batch [Cmd.map Transport command,focusCommand])
     ```
   - And in `HttpPopup.elm:19-25, 33-35`: `supported : Popup.Effect -> Bool` inspects `Popup.PreviewCommand` / `Popup.PaintRequest` payloads and transitions `model.http` to `failed` via `UiHttp.stop "Native preview ports are unavailable in the HTTP UI profile."` inside `Cmd`-returning `step`.
   - **Why this matters for whole `ELM-TEA-002`**: Unlike `Main`, `Bar`, and `Popup`—where 100% of branching and policy guards return typed `Effect` values—`HttpPopup` makes an observable UX/IME policy decision (`current.popup.composition == Popup.Idle` suppressing DOM focus during active IME preedit) directly inside `Cmd`-returning `update`, making that focus-suppression decision unobservable as a pure typed `Effect` description without a DOM/runtime harness.
2. **Finding H3 (`HttpBar.elm:40-47` `"focus"` and Unknown-Gateway Fail-Closed Stop)**:
   - `HttpBar.update` similarly evaluates `Presentation.focusTarget False payload current.bar.presentation` -> `Browser.Dom.focus` and unknown-gateway `UiHttp.stop ("Unsupported HTTP UI gateway event: " ++ other)` directly in `Cmd`-returning `update`.
3. **Finding H2 (`HttpMain.elm:15-18` Silent Effect Discard in `lost`)**:
   - `lost model = let (policy, _) = Policy.update Policy.TransportLost model.policy in { model | policy = policy }`.
   - **Source Trace**: `Policy.TransportLost` (`DesktopPolicy.elm:21-22`) synthesizes `{"version":2,"kind":"host-disconnected","payload":null}`. In `Desktop.elm` / `DesktopPolicy.effectsFor` (`lines 48-51`), `"host-disconnected"` cannot emit any of the four `Delay` effects (`Arm`, `ArmPrepared`, `ArmWorkspaceNavigation`, `ArmChoice`) and emits only `[Publish frame]`, which `UiHttp.enqueue` (`UiHttp.elm:61`) drops when `model.http.failed /= Nothing`. Thus **no observable runtime bug exists today**, but folding or asserting `effects` rather than discarding `_` eliminates a fragile implicit coupling.
4. **Finding H1 (`UiHttp.elm` Direct `Cmd Msg` Return)**:
   - `UiHttp.elm` (`121` lines) is the shared `/events` + `/commit`|`/actions` HTTP transport state machine (`inflight`, `polling`, `queued`, `failed`). Its functions (`controller`, `renderer`, `enqueue`, `stop`, `update`) return `Cmd Msg` directly (`Http.request`, `Http.cancel`, `Process.sleep 100 |> Task.perform (\_ -> Poll)`) rather than a pure `type Effect = GetEvents | Post String E.Value | Cancel String | RetryPoll Float`. Today `qa/UiHttpReplay.elm` (`0af3b614...`) exercises `UiHttp` via JS `XMLHttpRequest` shimming in `qa/ui-http.cjs` (`8ec7289e...`). Either extracting a pure `UiHttp.step` returning typed `UiHttp.Effect` **or** explicitly scoping `UiHttp` as the runtime transport adapter layer (analogous to JS port bindings) should be explicitly adjudicated in the whole-`TEA-002` review.

---

## 4. Concrete Remaining Clauses Checklist for Whole `ELM-TEA-002` (and Interface to `ELM-TEA-001`)

To move `ELM-TEA-002` (`tea-pure-update`) from component evidence (`partial` / `NOT_ASSESSED`) to honest whole-requirement closure—**without** inventing a universal native gate or arbitrary JSON key-order serialization rule—the following concrete items remain:

| # | Clause / Scope | Current Status (`05` `1793560906209268899` & `06` `1793561026384253514`) | Concrete Closure Action Required (Root-Owned) |
|---|---|---|---|
| **C1** | **Pending Preference Finite-Status & Positive Controls** (`Settings`, `MotionPreferences`, `ShortcutPreferences`) | **OPEN in `05` (`42/101/15`); CLOSED at Component Level in `06` (`58/134/31`, `ab9d3f43...`)** | Retain `06` (`16` added preference + UX malformed/Unknown cases) in the committed immutable tuple. |
| **C2** | **Remaining `DesktopPolicy.Effect` `Delay 2000` Constructors** (`DesktopPolicy.elm:49-51`) | **PARTIAL (`1 / 4` `Delay` branches in `tea-contract-cases.cjs`)**: `Arm` (`Delay 10000 (Desktop.Deadline token)`) is covered; `ExpirePrepared token` (`2000ms`), `WorkspaceNavigationDeadline intent` (`2000ms`), and `ChoiceDeadline token` (`2000ms`) have `0` cases in `tea-contract-cases.cjs`. | Add source-literal cases in `qa/tea-contract-cases.cjs` exercising reachable `Delay 2000` emission + exact timeout settlement + stale token no-op for `ExpirePrepared`, `WorkspaceNavigationDeadline`, and `ChoiceDeadline`. |
| **C3** | **Renderer Pure-Reducer Replay (`Bar.step` & `Popup.transition`)** | **PARTIAL**: `Bar.step` (`Dispatch`, `ResetStatusViewport`) has `qa/StatusScrollReplay.elm` (`274cacb5...`) outside this slice; `Popup.transition` (`Dispatch`, `PreviewCommand`, `PaintRequest`) has `LocalFieldReplay`/`ImeReplay` which discard effects via `Popup.update (...) \|> Tuple.first`. | Bind deterministic two-run (`runsPerCase = 2`) model + typed-`Effect` replay for `Bar.step` and `Popup.transition` (covering `Bar.Dispatch`, `Bar.ResetStatusViewport`, `Popup.Dispatch`, `Popup.PreviewCommand`, `Popup.PaintRequest`, and IME `Composition` transitions) into the protected `TEA-002` QA suite. |
| **C4** | **HTTP-Profile Typed-Effect Boundary (`HttpPopup`, `HttpBar`, `HttpMain`, `UiHttp`)** | **OPEN (§3.3 Findings H1–H4)**: `HttpPopup.elm:54` (`composition == Popup.Idle` focus gate) and `supported` preview fail-closed stop execute inside `Cmd`-returning `update`. | Extract pure `step` reducer(s) in `HttpPopup` / `HttpBar` emitting typed `Effect` descriptions (e.g., `Enqueue E.Value \| FocusDom String \| LocalBar Bar.Effect \| FailClosed String`) so IME focus-suppression and preview fail-closed transitions are pure and deterministically replayable; explicitly fold/assert `HttpMain.lost` effects; and either give `UiHttp` typed `Effect` descriptions or formally record `UiHttp` as the runtime transport driver tested by `UiHttpReplay`. |
| **C5** | **Sanitized Ingress vs Raw JS Port Quirk & Rebind Receipt Authority Note** | **SOURCE-IDENTIFIED (`component-observation.json:198`)** | Record in the review packet: (a) `ELM-TEA-002` governs *"identical sanitized message histories"*—Elm 0.19.1 kernel `value.hasOwnProperty` collision on raw untrusted JS `{"hasOwnProperty": 1}` pertains to unsanitized raw port objects rather than Haskell-sanitized envelopes; (b) confirm `Shell.elm:275-285` settling an exact `model.issued` receipt (`1/1/1`) after `attached` rebind (`1/1/2`) matches intended `ELM-TEA-001` / `ELM-TEA-003` authority semantics. |
| **C6** | **Whole `ELM-TEA-001` Interface & Immutable Reviewer Gate** | **OPEN (`disposition: "partial"`, `sourceRevision: null`)** | Complete remaining whole-frontend finite-state/authority inventory for `ELM-TEA-001` (`tea-model-effects.json:311-313`), flip `coverageDeclaration.complete: true` (`missing: []`) only after C2–C5 hold, commit the exact source tuple (`sourceRevision != null`), and record independent `reviewer != author` acceptance with `nativeAccepted: false` and `nativeOperations: []`. |
