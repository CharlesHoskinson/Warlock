-- Preparation draft. This module carries parsed selection data only; it does
-- not authenticate an event, mint authority, read a clock, or admit an effect.
module Warlock.Persistent.ActionDeadline
  ( ActionDeadline, RelativeTime(..), ObservationError(..)
  , fromSelection, selectionData, selectionIdentity, originalDeadline, inspectAt
  ) where

import Data.Text (Text)
import Warlock.Protocol.Identity (Counter, isZero)
import Warlock.Protocol.StrictJson (Json)
import qualified Warlock.Protocol.Wire as Wire

-- Constructors stay private. Wire.parseSelection already checks canonical
-- counters, CLOCK_MONOTONIC, exact shape and original accepted + 2s deadline.
data ActionDeadline = ActionDeadline !Json !Text !Counter deriving (Eq, Show)
data RelativeTime = BeforeDeadline | AtOrAfterDeadline deriving (Eq, Show)
data ObservationError = InvalidClockObservation deriving (Eq, Show)

fromSelection :: Json -> Either Text ActionDeadline
fromSelection input = do
  (selected, original) <- Wire.parseSelection input
  pure (ActionDeadline input selected original)

-- Still-untrusted original selection, retained in full for exact correlation.
selectionData :: ActionDeadline -> Json
selectionData (ActionDeadline input _ _) = input

selectionIdentity :: ActionDeadline -> Text
selectionIdentity (ActionDeadline _ selected _) = selected

originalDeadline :: ActionDeadline -> Counter
originalDeadline (ActionDeadline _ _ original) = original

-- Comparison is a pure observation at the caller-provided instant, never an
-- execution permit: the actual provider must perform its own fresh trusted
-- monotonic check at its mutation boundary. Zero is not a clock observation.
inspectAt :: Counter -> ActionDeadline -> Either ObservationError RelativeTime
inspectAt now (ActionDeadline _ _ original)
  | isZero now = Left InvalidClockObservation
  | now < original = Right BeforeDeadline
  | otherwise = Right AtOrAfterDeadline
