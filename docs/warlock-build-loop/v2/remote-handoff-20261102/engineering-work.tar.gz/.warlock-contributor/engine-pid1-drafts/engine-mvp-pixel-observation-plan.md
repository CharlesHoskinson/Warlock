# Engine MVP Pixel-Observation Plan & `EngineMvpJourney.elm` Compilability Review

- **Author**: `gemini-gui` (`warlock-20261031-setup`)
- **Coordinator**: `lead` (Root)
- **Status**: **Preparation draft only** (`nativeAcceptance = false`, `guiAcceptance = false`, `releaseAccepted = false`, `protectedQaAccepted = false`)
- **Current Ground Truth**: **No actual Warlock window has been mapped yet**; `nativeOperations: []`; whole accepted requirements `15 / 242` and original scenarios `39 / 417` unchanged; **zero invented screenshots or UI elements**.
- **Bound Artifacts**:
  - `MvpLayout.patch`: `sha256:23e2e1469450fe0126dccef5cb20c5c5a47880fb60e14b588718652d1b97e2fd` (`39,353` B)
  - `EngineMvpJourney.elm` (Wave 13 baseline): `sha256:71946785ce4804669220aefc1a8a63813e0b333045470447906bee67536cc082` (`2,081` lines)
  - `EngineMvpJourneyTrim.patch` (Wave 14 targeted trim + 3 source-bound fixes): `sha256:b344b4cda241dfe505e327cbc645ec71087c184da7ecca8b87ecb5ceb60df897` (`1,295` lines; post-apply `EngineMvpJourney.elm` `1,563` lines, `sha256:36638133492ec1819a2ab355ee02917dea3defd98ac45dae5092e489ab5e078f`)

---

## 1. GTK4 + Three-Elm-Root Container Geometry (`HEAD` vs `MvpLayout.patch`)

All pixel coordinates derive dynamically from the live Wayland client geometry `[wx, wy, ww, wh]` queried from `hyprctl clients -j` matched by exact child `pid == PID_ENGINE` on `Virtual-1` (`1280×800`, scale `1.0`).
- **GTK4 window (`Warlock/Ui/Mvp.hsc:803-855`)**: `gtkWindowSetDecorated window 0` (`0px` client-side titlebar/borders), `gtkWindowSetResizable window 1`, `gtkWindowSetDefaultSize window 980 680`.
  - **Standalone workspace**: `[wx, wy, ww, wh] ≈ [150, 60, 980, 680]` (or compositor tile fill).
  - **Hyprland dwindle split alongside pre-existing `Foot`**: `ww ≈ 616..630px`, `wh ≈ 760..800px`.

| WebKit6 Surface / Elm Root | Role & HTML Root | Geometry in `MvpLayout.patch` (`23e2e146`) | Geometry in Unpatched `HEAD` (`57b150fd`) |
| --- | --- | --- | --- |
| **`cView` (`HttpMain.elm`)** | Policy controller (`div[data-warlock-role="controller"][aria-hidden="true"]`, `0×0` in `MvpLayout.patch`; empty `text ""` in `HEAD`) | Non-measuring `GtkOverlay` child (`GTK_ALIGN_START`, `measure_overlay = 0`, `1×1` at `(wx, wy)`, `opacity = 0.0`, `focusable = 0`, `canTarget = 0`, `visible = 1`) -> **`0px` visual footprint, `0px` bottom seam** | Appended 3rd child of `GtkBox`: `[wx, wy + wh - 1, ww, 1]` (`1px` bottom row) |
| **`bView` (`HttpBar.elm`)** | Taskbar (`div[data-warlock-role="bar"] > div.surface-bar`) | **`[wx, wy, ww, 56]`** (`sizeRequest (-1, 56)`, matching `.surface-bar` `calc(3em + 8px) = 56px` at `100%` / `16px` -> **`0px` dead band**) | `[wx, wy, ww, 72]` (`sizeRequest (-1, 72)` -> `16px` unthemed `#ffffff` band at `wy + 56 .. wy + 72`) |
| **`pView` (`HttpPopup.elm`)** | Workspace / `Applications` (`div[data-warlock-role="popup"] > div.surface-popup`) | **`[wx, wy + 56, ww, wh - 56]`** (`sizeRequest (480, 360)` -> allows narrow `600×680` `OwnerReflow` on Wayland) | `[wx, wy + 72, max(ww, 640), max(wh - 73, 480)]` (`sizeRequest (640, 480)` clamps min window to `640×553`) |

---

## 2. Exact Default `Settings.Night` (`100%` / `16px`) Pixel Palette (`SurfaceTheme.elm:80-108`)

| Semantic Token | Hex / CSS Value | Where Observed in First App-Only Window |
| --- | --- | --- |
| `canvas` | **`#100e0e`** | `pView` (`HttpPopup` shell & `.surface-popup` background) |
| `surface` | **`#191516`** | `bView` (`HttpBar` shell & `.surface-bar` background), `#launcher-search` enabled input fill, `MvpLayout.patch` `.surface-closed-card` fill |
| `surfaceRecessed` | **`#131011`** | `.surface-status` pill fill, `.surface-popup` `<p role="status">` banner fill, **all disabled `Bar` & `Popup` buttons** |
| `surfaceUtility` | **`#1e191b`** | Enabled `pin-left:*`, `pin-right:*`, pagination `control:page-previous` / `control:page-next` |
| `surfaceRaised` | **`#262022`** | Enabled `unpin:*`, `control:close` (`"Windows"`), `control:refresh` (`"Refresh"`) in `MvpLayout.patch` |
| `surfaceSelected` | **`#351c1f`** | Enabled `bar:applications` (`"Applications"`) and enabled `pin:<headId>` (`"Pin <App>"`) |
| `textPrimary` / `textSecondary` | **`#f6efe8`** / **`#c6bab7`** | Enabled labels, headings, search text / detail subtitles & closed-card hint |
| `textDisabled` / `borderDisabled` | **`#9a8e8b`** / **`#4d4446`** | Disabled window/utility/launch/jump/bar-pin labels & dashed `1px` borders (`cursor: not-allowed`) |
| `brandAccent` / `actionFill` | **`#fca399`** / **`#b02026`** | `3px` `<h1>` left bar, `bar:applications` border + `inset 3px 0 0 #b02026`, `pin:<headId>` `4px` left border + `inset 2px 0 0 #b02026` |
| `focusRing` | **`#8ec8ff`** | `3px` focus outline on `#launcher-search` (`outline-offset: 2px`) and focused buttons |

---

## 3. Expected Visible Controls & Hit Coordinates Across Journey Stages

### Stage S1 — Closed App-Only Window (`mode == "closed"`, `nativeOperations: []`, `pinIds == []`)

1. **`bView` (`HttpBar`, `[wx, wy, ww, 56]`, `#191516` background, `1px solid #3b3335` bottom border)**:
   - **Left `.surface-actions[role="toolbar"][aria-label="Warlock taskbar"]`** (`flex: 1 1 auto; min-width: 0; height: 56px; overflow-x: auto`):
     - **Index 0 (`bar:applications`)**: `<button data-surface-control="bar:applications" aria-label="Open applications">` -> visible label **`"Applications"`**, **ENABLED** (`disabled` absent, `#351c1f` fill, `1px solid #fca399` + `inset 3px 0 0 #b02026`, `#f6efe8` weight `600`).
       - **Safe click coordinate (ONLY while `pinIds == []`)**: **`(wx + 52, wy + 28)`** (vertical center of `56px` bar; in unpatched `HEAD` `72px` request, `.surface-bar` still renders at top `wy .. wy + 56`, so `wy + 28` hits center in both!).
     - **Indices 1–6 (all DISABLED under `applicationOnly = True`)**: `disabled` attribute present, `aria-disabled="true"`, `#131011` fill, `1px dashed #4d4446`, `#9a8e8b` text:
       1. `bar:overview` — **`"Task View"`** (`aria-label="Open Task View"`)
       2. `bar:switcher` — **`"Switch windows"`** (`aria-label="Switch windows"`)
       3. `bar:notifications` — **`"Notifications"`** (`aria-label="Open notifications"`)
       4. `bar:files` — **`"Files"`** (`aria-label="Open Files menu"`)
       5. `bar:system` — **`"System"`** (`aria-label="Open system menu"`)
       6. `bar:settings` — **`"Settings"`** (`aria-label="Open settings"`)
       - *(On `ww ≈ 620px` narrow split, rightmost disabled utility chips clip cleanly inside `.surface-actions` `overflow-x: auto` without overlapping `.surface-status`.)*
   - **Right `.surface-status[role="status"]`** (`flex: 0 1 clamp(180px, 40vw, 360px)` at `wx + ww - statusW .. wx + ww`):
     - Inner focusable `<span id="warlock-bar-status-scroll-2" tabindex="0">`: **`"Applications connected. Window controls unavailable."`** (`#131011` fill, `#f6efe8` text).
   - **Live region**: `.shell-announcement` visually clipped `1×1` (`clip-path: inset(50%)`) in `MvpLayout.patch` (zero visible text bleed).
2. **`pView` (`HttpPopup`, `[wx, wy + 56, ww, wh - 56]`, `#100e0e` canvas)**:
   - **With `MvpLayout.patch` (`SurfaceRenderer.elm:286-304`)**:
     - `.surface-popup[data-mode="closed"][data-theme="night"][data-text-scale="100"]`
     - `<h1>` (`3px solid #fca399` left accent): **`"Application Workspace"`**
     - `<p role="status">`: **`"Applications connected. Window controls unavailable."`** (`#131011` fill)
     - `.surface-controls` contains one read-only `.surface-closed-card` (`#191516` fill, `4px solid #fca399` left border):
       - Title: **`"Standalone Application Catalog & Taskbar Pins"`**
       - Hint: **`"Choose Applications in the top bar to browse installed desktop entries, filter by search, and pin or reorder taskbar items. Window management and process launch stay disabled while nativeOperations is empty."`**
       - **Interactive controls inside `pView` in S1**: **ZERO** (`0` `<button>`, `0` `<input>`).
   - *(Without `MvpLayout.patch` in `HEAD`: `<h1>Choose a window</h1>` + status paragraph + empty `.surface-controls`.)*

---

### Stage S2 — Open `Applications` Launcher (`mode == "applications"`, `query == ""`, `pinIds == []`)

Clicking `bar:applications` emits `catalog-request` (`Bar` status briefly `<span id="warlock-bar-status-scroll-3">Loading applications…</span>`), then `application-catalog` settles `mode == "applications"`:
- **`Bar` status**: `<span id="warlock-bar-status-scroll-4" tabindex="0">Type to search applications.</span>`.
- **`Popup` header**: `<h1>Applications</h1>` + `<p role="status">Type to search applications.</p>`.
- **`Popup` `.surface-controls[role="group"]`** (`display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 9px; max-width: 58rem; margin: 0 auto`):

| Grid Row (`100%` scale) | Column Span | Control Identity (`data-surface-control` / `data-surface-field`) | Visible Label & Detail | Enabled? | Visual / Focus / Interaction Contract |
| --- | --- | --- | --- | --- | --- |
| **Row 1** | `1 / -1` (all 6 cols) | `control:search` (`input#launcher-search[type="search"]`) | `<label>Search applications</label>`, `placeholder="Type an application name"`, `value=""` | **ENABLED** | **Auto-focused** via `Presentation.focusTarget` (`3px solid #8ec8ff` ring); `#191516` fill, `2px solid #786c6e` border. Type directly without clicking! |
| **Row 2 L** | `span 3` (cols 1–3) | `control:close` | **`"Windows"`** (`aria-label="Close applications and return to windows"`) | **ENABLED** | `#262022` fill, `3px solid #a89b99` left border (`MvpLayout.patch`). Closes popup (`mode -> "closed"`). |
| **Row 2 R** | `span 3` (cols 4–6) | `control:refresh` | **`"Refresh"`** (`aria-label="Refresh applications"`) | **ENABLED** | `#262022` fill, `3px solid #fca399` left border (`MvpLayout.patch`). Emits fresh `catalog-request`. |
| **Row 3** *(iff `bodyCount > 8`)* | `1 / -1` | `control:page-range` | **`"Items 1–8 of <N>"`**, detail `"<M> matching applications · 0 pinned"` | **DISABLED** | Read-only range banner (`cursor: default`, `#131011` fill). Present whenever guest `.desktop` count + 2 prefix rows `> 8` (i.e. `> 6` installed apps). |
| **Row 4** *(iff `bodyCount > 8`)* | `span 3` + `span 3` | `control:page-previous` / `control:page-next` | **`"Previous page"`** / **`"Next page"`** | Prev **DISABLED** (p.0), Next **ENABLED** | `#131011` dashed vs `#1e191b` solid. |
| **Next Row (`prefix[0]`)** | `1 / -1` | `jump:open:<headId>` *(ONLY for `List.head entries`, `Surface.elm:324`!)* | **`"Actions for <HeadName>"`**, detail `"Application actions and recent files"` | **DISABLED** | `disabled`, `aria-disabled="true"` because `applicationOnly == True` (`#131011` fill, `#4d4446` dashed). |
| **Next Row (`prefix[1]`)** | `1 / -1` | `pin:<headId>` *(ONLY for `List.head entries` when unpinned, `Surface.elm:317`!)* | **`"Pin <HeadName>"`**, detail `"Add to taskbar"` | **ENABLED** | `#351c1f` fill, `4px solid #fca399` left border + `inset 2px 0 0 #b02026`, `#f6efe8` weight `600`. |
| **Remaining Page Slots** *(up to `8 - len(prefix)`)* | `1 / -1` | `entry:<appId>` (sorted lexicographically by `id` when `query == ""`, `Catalog.elm:25-27`) | **`"Open <AppName>"`** (no detail) | **DISABLED** | **All `entry:*` launch cards stay DISABLED** (`disabled`, `aria-disabled="true"`, `cursor: not-allowed`) under `nativeOperations: []`. |

> **Critical `Surface.elm:317,324` Visibility Rule**: `jump:open:<id>` and `pin:<id>` are rendered **only for `List.head (Catalog.search query snapshot)`**, never for all 8 page entries at once. To expose `pin:<targetAppId>` for a specific installed app (e.g., `foot.desktop`), filter `#launcher-search` first so `<targetAppId>` becomes `List.head entries`!

---

### Stage S3 — Keyboard Search & IME Preedit (`#launcher-search`)

- **Direct keyboard query (e.g., QMP `send-key f, o, o, t` while `#launcher-search` is auto-focused)**:
  - `#launcher-search.value` becomes `"foot"`, keyed node `"field:control:search"` preserves focus and selection.
  - `Catalog.search "foot"` ranks exact/prefix match `"Foot"` (`foot.desktop`) at `List.head entries`.
  - If filtered `bodyCount <= 8`, **pagination rows (`control:page-range`, `control:page-previous`, `control:page-next`) disappear**, collapsing the grid vertically to:
    1. Row 1: `#launcher-search` (`value="foot"`, focused)
    2. Row 2: `control:close` (`"Windows"`) | `control:refresh` (`"Refresh"`)
    3. Row 3: `jump:open:foot.desktop` (`"Actions for Foot"`, **DISABLED**)
    4. Row 4: `pin:foot.desktop` (`"Pin Foot"`, **ENABLED**)
    5. Row 5: `entry:foot.desktop` (`"Open Foot"`, **DISABLED**)
  - Status text in both `Bar` and `Popup` updates to **`"Choose a matching application."`** (or **`"No matching applications. Change your search or Refresh."`** with `1px solid #f2c172` warning contour if 0 entries match).
  - **Deterministic keyboard activation of `pin:<headId>` (immune to pagination row height shifts)**: From focused `#launcher-search` when filtered `bodyCount <= 8` and `pinIds == []`, pressing **`Tab` 3 times** (`#launcher-search` -> `control:close` -> `control:refresh` -> `pin:<headId>`, skipping disabled `jump:open:<headId>`) focuses `pin:<headId>` (`3px solid #8ec8ff` outline), and **`Return` / `spc`** triggers `taskbar-pins-write`!
- **Active IME preedit (`compositionstart` / `Preediting`)**:
  - `#launcher-search` carries `data-input-composing="true"` and displays local `pendingQuery` without emitting `surface-query`; Popup button clicks are locally suppressed until `compositionend`, and an in-flight same-lease `application-catalog` refresh neither overwrites `pendingQuery` nor steals DOM focus (`HttpPopup.elm:54`).

---

### Stage S4 — Taskbar Pin Toggle, `Saved` Receipt & Reorder (`Surface.elm:317-325, 425, 434`)

1. **While `taskbar-pins-write` is in flight (`Pins.writable == False`)**:
   - Status in `Bar` (new epoch `<span id="warlock-bar-status-scroll-<k>">`) and `Popup` reads **`"Saving pin order…"`**.
   - All `pin:*` / `unpin:*` / `pin-left:*` / `pin-right:*` controls render **DISABLED** until `taskbar-pins-outcome` arrives.
2. **After `taskbar-pins-outcome` (`status: "Saved"`, `identities: ["foot.desktop"]`)**:
   - **CRITICAL `Bar` Left-Prepend Geometry Shift (`Surface.elm:434` + `Shell.elm:187`)**:
     - `application-attached` sets `shell.phase = Shell.Reconciling` (`/=` `Shell.Detached`), so `Surface.bar` orders controls as **`applications ++ supportedUtilities`**!
     - **`button[data-surface-control="bar:pin:foot.desktop"]`** (label **`"Foot"`**, detail **`"Pinned launcher"`**, `aria-label="Open Foot; Foot"`, **DISABLED** `disabled` + `aria-disabled="true"` because `Shell.available == False`) is inserted at **Index 0 on the far left of `.surface-actions`**, **shifting `bar:applications` (`"Applications"`) rightward to Index 1** by the width of the `"Foot"` chip (~`88..128px`)!
     - **QMP Coordinate Guard**: Never click hardcoded `(wx + 52, wy + 28)` to reopen `Applications` after pinning an item — at `(wx + 52, wy + 28)` sits the **disabled `bar:pin:<id>` chip**! Either query live DOM/accessibility bounds or shift x past the prepended `bar:pin:*` chip(s) (or close/reopen before pinning).
   - **In `Popup` (`.surface-controls`)**:
     - Because `foot.desktop` is now in `pinIds`, `pin:foot.desktop` is omitted (`pinFirst == []` while `foot.desktop` is `List.head entries`).
     - A 3-button pin management row (`span 2` + `span 2` + `span 2` across the 6-column grid at `100%`–`125%` scale) appears immediately after `jump:open:<headId>`:
       - Cols 1–2 (`span 2`): `unpin:foot.desktop` — **`"Unpin Foot"`**, detail `"Pinned application"`, **ENABLED** (`#262022` fill, `3px solid #fca399` left border, `#f6efe8` weight `600`).
       - Cols 3–4 (`span 2`): `pin-left:foot.desktop` — **`"Move Foot left"`**, detail `"Pin order"`, **DISABLED** at index `0`.
       - Cols 5–6 (`span 2`): `pin-right:foot.desktop` — **`"Move Foot right"`**, detail `"Pin order"`, **DISABLED** when `pinCount == 1` (**ENABLED** `#1e191b` fill when `pinCount >= 2` and `index < pinCount - 1`).
     - `Popup` auto-focuses `#launcher-search` on the `Saved` frame.

---

### Stage S5 — Narrow Split / `OwnerReflow` & Physical `Escape` Close (`>= 2.0s` Margin Before `D = 28.0s`)

- **Narrow Wayland width (`600..630px` dwindle split) + `OwnerReflow`**:
  - `data-lease` on `.surface-bar` and `.surface-popup` increments to a fresh positive `UInt64` while `data-mode="applications"`, search query, and `bar:pin:*` / `unpin:*` chips remain intact (`480×360` `pView` minimum in `MvpLayout.patch` prevents horizontal overflow).
- **Physical QMP `send-key esc` (with Warlock window active, `t <= 24.0s`)**:
  - `Warlock/Ui/Mvp.hsc` `GTK_PHASE_CAPTURE` key controller intercepts `GDK_KEY_Escape` before WebKit consumes it and posts `view-escape` with active `(scope, publication, lease)`.
  - `Popup` transitions to `data-mode="closed"` (rendering the read-only **`"Application Workspace"`** card in `MvpLayout.patch`, zero interactive buttons/inputs), while `Bar` retains the disabled `bar:pin:<appId>` chip at Index 0 and enabled `bar:applications` at Index 1.
  - Pre-existing `Foot` terminal window retains identical `PID`, `/proc/<PID>/stat` `starttime`, and window address throughout.

---

## 4. Unexecuted Compilability Review & Trim Summary (`EngineMvpJourney.elm` -> `EngineMvpJourneyTrim.patch`)

Line-by-line unexecuted static audit of Wave 13 `EngineMvpJourney.elm` (`2,081` lines, `sha256:71946785ce4804669220aefc1a8a63813e0b333045470447906bee67536cc082`) against `implementation/warlock/src/*.elm` and `elm.json` (`elm 0.19.2`):

1. **Static Module/Type/Scope Check**:
   - All 17 local Warlock imports (`Announcement`, `Bar`, `Binding`, `Catalog`, `Desktop`, `DesktopPolicy`, `OutputController`, `Pins`, `Popup`, `Presentation`, `Shell`, `StatusScroll`, `SurfaceController`, `SurfaceRenderer`, `SurfaceSnapshot`, `UInt64`, `UiHttp`) and 5 `elm/*` core/html/json imports resolve to real exported symbols; zero tabs, balanced delimiters, and zero Elm 0.19.2 variable shadowing across Prelude, top-level, parameter, `let`, and lambda scopes.
2. **Three Concrete Hazards / Contract Defects Fixed in `EngineMvpJourneyTrim.patch` (`sha256:b344b4cda241dfe505e327cbc645ec71087c184da7ecca8b87ecb5ceb60df897`)**:
   - **Hazard 1 (`routeFocusTarget` raw JSON mirror & `Result D.Error` `==` comparison, `L310-333`)**: `matchesIn` manually decoded raw JSON `frameVal` control arrays and evaluated `D.decodeValue ... == Ok targetDom` (`Result D.Error` wraps `D.Failure String D.Value`, unsafe if `Err` values are ever compared in Elm `_Utils_eq`, while duplicating `Presentation.focusTarget`). **Fixed**: removed `matchesIn` completely; `routeFocusTarget` now queries `Presentation.focusTarget False` (`Bar`) and `Presentation.focusTarget True` (`Popup`) directly.
   - **Hazard 2 (`Surface.elm:317,324` `List.head entries` visibility contract in `L1350-1352, L1588-1603`)**: Wave 13 asserted `pin:org.gnome.Nautilus.desktop` and `jump:open:org.gnome.Nautilus.desktop` while `query == ""` (`List.head entries == foot.desktop`) and invoked `stepPopupAction "pin:org.gnome.Nautilus.desktop"` without filtering `query` first (which is a no-op once `foot.desktop` is pinned because `List.head entries` remains `foot.desktop`). **Fixed**: asserts `pin:foot.desktop` / `jump:open:foot.desktop` at `query == ""`, filters `query` to `"Files"` before `pin:org.gnome.Nautilus.desktop`, and asserts the exact `Bar` left-prepend order `[ "bar:pin:org.gnome.Nautilus.desktop", "bar:pin:foot.desktop", "bar:applications" ]` (`Surface.elm:434`).
   - **Hazard 3 (`E.encode 0` stringification mirrors in `L405-406, L1566-1568`)**: Replaced raw JSON string comparisons for `announcer` and `Binding` with typed `Outputs.scopeDecoder` (`selectedScope : Maybe Outputs.Scope`) and `Binding.decoder` equality.
3. **Mirror Assertion & Boilerplate Trim (`2,081` lines -> `1,563` lines, `-518` lines)**:
   - Removed 8 duplicate single-module decoder/exhaustion/reconnect/loop checks already owned by `StandaloneMvpReplay.elm`, `StatusScrollReplay.elm`, `ImeReplay.elm`, and `PinsReplay.elm`, plus the 14-field `AcceptanceLimits` echo record and 12-branch interactive `update` switch.
   - Retained **15 high-signal cross-role coupled `Controller <-> Bar + Popup` positive & negative journey checks** (`git -C /home/charl/code/Warlock apply --check` clean; post-apply candidate `sha256:36638133492ec1819a2ab355ee02917dea3defd98ac45dae5092e489ab5e078f`).
