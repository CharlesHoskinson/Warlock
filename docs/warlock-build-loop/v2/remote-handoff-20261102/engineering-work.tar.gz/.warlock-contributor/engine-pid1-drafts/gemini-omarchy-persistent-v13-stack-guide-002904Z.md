# Consolidated Persistent-Custody `v13` Stack Guide (`20261102T002904Z`)

## 1. Frozen Artifacts (`.warlock-contributor/engine-pid1-drafts/`)
- **Standalone `v13` patch against canonical `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f`**:
  - `gemini-omarchy-persistent-custody-prereqs-v13-002904Z.patch` (`sha256:3716614fc6e299d3504d8778beecf96150c66239a6a5ecb70fff6f365862b526`)
- **Incremental `v12 -> v13` delta patch** (folds `terra-engine-stop-deadline-read-001.patch` `a4920d3f` + `PersistentControls` assertions onto `v12` `7df4cdf0`):
  - `gemini-omarchy-persistent-custody-v12-to-v13-delta-002904Z.patch` (`sha256:0fa6c45feddd46f2609008d381c8194a34a5e52e9cb5fcebb0446751e71429af`)
- **Preserved prior immutable variants**:
  - `v12` (`7df4cdf0be86efa80b4526f1346f390de0b85185b6b7cf6be85798e0030b97bb`), `v11` (`f661f6eb5c92f0e6238921b7c35de0ab57d906a59c669a8d03141b91cab1dca8`), and `v6`–`v10` remain untouched on disk.

## 2. Complete `v13` Consolidation (`held-document` + `process-custody` Only)
1. **Engine synchronous bounded startup borrow** (`c9969670`): `borrowHeldWhile` in `Warlock.Platform.Executable` + `Warlock.Capture.Process.Lease`.
2. **Security checked unborrowed startup abort** (`946a7f74` + `aa817b0a`): `tryAbortUnborrowed` in `Warlock.Capture.Process.Owner` + non-blocking `abortBeforeBorrow` in `Warlock.Capture.Process.Persistent.Internal`.
3. **Engine nonblocking owner-attested `StopDeadlineObservation`** (`a4920d3f` byte-for-byte):
   ```haskell
   data StopDeadlineObservation
    = StopDeadlineBusy
    | StopDeadlineNotLatched
    | StopDeadlineFailed ToolError
    | StopDeadlineLatched AdmissionDeadline
    deriving (Eq, Show)

   tryPersistentStopDeadline :: PersistentOwner -> IO StopDeadlineObservation
   ```
   Uses `tryReadMVar` only on `CallbackGate`; never blocks, never mints or renews a deadline, and matches `terra-portable-bootstrap-cleanup-004.patch` (`14140811`) and `terra-engine-stop-deadline-read-controls-001.hs` (`3eaaf0af`) byte-for-byte. Note: `retireLive` always latches `StopDeadlineLatched` on normal/EOF/fault live exit as well as explicit `requestSessionStop`.
4. **Trusted `ActionBudget` issuer + bounded per-request `LiveFrameBatch` admission** (preserving 1-shot `enterLiveFrameAction` unchanged):
   ```haskell
   ActionBudget -- opaque (1..30_000_000 us)
   actionBudgetMicros :: Int -> Either ToolError ActionBudget
   actionBudgetMicrosValue :: ActionBudget -> Int
   issueActionDeadline :: ActionBudget -> IO (Either ToolError AdmissionDeadline)

   LiveFrameBatch -- opaque per-frame serial batch capability
   maxLiveFrameBatchActions :: Int -- = 32 (accommodates 1 applicationAttached + 16 DesktopCommit requests = 17)
   beginLiveFrameBatch :: LiveFrameAdmission -> AdmissionDeadline -> Int -> IO (Either ToolError LiveFrameBatch)
   enterLiveBatchAction :: LiveFrameBatch -> AdmissionDeadline -> IO (Either ToolError a) -> IO (Either LiveOperationFailure a)
   enterLiveBatchBudgetedAction :: LiveFrameBatch -> ActionBudget -> IO (Either ToolError a) -> IO (Either LiveOperationFailure a)
   ```
   - `frameDl` is checked once at `beginLiveFrameBatch adm frameDl quota` (`0 <= quota <= 32`) alongside owner stop and synchronous `inScope scope frameDl` child liveness/identity; mutually exclusive with `enterLiveFrameAction`.
   - Each serial action in `enterLiveBatchAction` / `enterLiveBatchBudgetedAction` uses its own fresh immutable `actionDl` without re-requiring expired `frameDl`, checks stop + `inScope scope actionDl` before and after `act`, holds `CallbackGate` across execution, and atomically poisons the batch on any pre-dispatch stop/timeout/liveness failure or post-entry `OperationOutcomeUnknown`/exception (closing `witnessPostStopSecondEffect`).
5. **`DeadlineStop.hs` `-Wall -Werror` fix + `PersistentControls.hs` section 22**: removes unused `IORef` type constructor in `DeadlineStop.hs` line 5 and exercises 25 `StablePtr`-rooted owners (15 quarantined, 10 retired), including a 17-action positive batch (`1` attachment + `16` requests) surviving `frameDl` expiry, `0`-quota presentation commit, mode exclusivity, sticky `OperationOutcomeUnknown` poison, stop-between-actions refusal, and `tryPersistentStopDeadline` idempotence.

## 3. Verified Zero-Fuzz 10-Patch 4-Package Stack Order (`patch -p1 --fuzz=0`, `rc = 0` on `HEAD` `af1bf0efeb195a9ac9e9664547d695967b41111f`)
1. `gemini-omarchy-persistent-custody-prereqs-v13-002904Z.patch` (`3716614fc6e299d3`)
2. `terra-engine-lexical-ingress-integration.patch` (`74b07921d42d7a9e`)
3. `terra-q-front-context-ingress-001.patch` (`c9fe0c1ac30e5775`)
4. `terra-q-front-owned-ingress-001.patch` (`51f9669976294b69`)
5. `terra-portable-persistent-scope-001.patch` (`c55ee1346a16ac0a`)
6. `terra-portable-registration-deadline-001.patch` (`4a3245e6a118e7be`)
7. `terra-portable-socket-context-001.patch` (`262f9403c0b0cd4a`)
8. `terra-portable-owned-pump-002.patch` (`ffaaadeefa0ca92e`)
9. `terra-portable-persistent-bootstrap-002.patch` (`ca1736bc1b4326e2`)
10. `terra-portable-bootstrap-cleanup-004.patch` (`14140811c7c5c7a0`)

## 4. Remaining Gaps Before Root Gate & Acceptance
- Rebase `terra-engine-outbound-pin-followup.patch` (`a825f10c`) onto `51f96699` (`CredentialIngressT` outbound send pin).
- Wire `tryRetireRegistrationBefore deadline registration` into `Aggregate.cleanupWork` (if `terra-portable` bumps `cleanup-005`) + wire persistent `Backend` actor onto Root diagnostic `Backend.hs` (`641e06dc8326fdf7d4e1be2aaa316d5739fcf161d5854c895c3d800a48450c06`) consuming `v13` `beginLiveFrameBatch` + `enterLiveBatchBudgetedAction`.
- Root Cabal closure audit (`protocol -> warlock-process-custody`), protected compiler/model/QA execution, and live guardian run. Ledger remains `18/242` whole EARS and `42/417` scenarios (`nativeOperations = []`, `HOSTSTOP2` retained).
