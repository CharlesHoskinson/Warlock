#!/usr/bin/env node
/**
 * Literal responsive, keyboard/focus, strict-IME, conversion, and WCAG 2.1 contrast QA oracle
 * for compiled HEAD-based site/src/SiteMain.elm (SiteMainHeadBeautyA11y2135.patch).
 *
 * Usage (Root executor):
 *   node .warlock-contributor/engine-pid1-drafts/site-head-responsive-focus-contrast-qa-2135.cjs \
 *     <compiled-site-or-index.html> <tokens.css> [report-out.json]
 */
'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function parseHexColor(hex) {
  const clean = String(hex).trim().replace(/^#/, '');
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) {
    throw new Error(`Expected 6-digit hex color, got ${hex}`);
  }
  return [
    parseInt(clean.slice(0, 2), 16),
    parseInt(clean.slice(2, 4), 16),
    parseInt(clean.slice(4, 6), 16),
  ];
}

function relativeLuminance([r8, g8, b8]) {
  const chan = (v) => {
    const s = v / 255;
    return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * chan(r8) + 0.7152 * chan(g8) + 0.0722 * chan(b8);
}

function wcagContrastRatio(fgHex, bgHex) {
  const l1 = relativeLuminance(parseHexColor(fgHex));
  const l2 = relativeLuminance(parseHexColor(bgHex));
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return Number(((lighter + 0.05) / (darker + 0.05)).toFixed(2));
}

function parseThemeTokens(tokensCss) {
  const themes = {};
  for (const theme of ['night', 'dawn', 'high-contrast']) {
    const blockRe = new RegExp(`\\[data-theme="${theme}"\\][^{]*\\{([\\s\\S]*?)\\}`, 'm');
    const match = tokensCss.match(blockRe);
    if (!match) {
      throw new Error(`Missing [data-theme="${theme}"] block in tokens.css`);
    }
    const vars = {};
    for (const m of match[1].matchAll(/(--wl-[a-z0-9-]+)\s*:\s*([^;]+);/gi)) {
      vars[m[1]] = m[2].trim();
    }
    themes[theme] = vars;
  }
  return themes;
}

function evaluateContrastOracle(themes) {
  const checks = [];
  for (const theme of ['night', 'dawn', 'high-contrast']) {
    const t = themes[theme];
    const pressedIndicator =
      theme === 'high-contrast' ? t['--wl-sys-color-focus'] : t['--wl-sys-color-brand-text'];
    const pairs = [
      ['text-on-canvas', t['--wl-sys-color-text'], t['--wl-sys-color-canvas'], 4.5],
      ['text-on-surface', t['--wl-sys-color-text'], t['--wl-sys-color-surface'], 4.5],
      ['secondary-on-canvas', t['--wl-sys-color-text-secondary'], t['--wl-sys-color-canvas'], 4.5],
      ['secondary-on-surface', t['--wl-sys-color-text-secondary'], t['--wl-sys-color-surface'], 4.5],
      ['brand-on-surface', t['--wl-sys-color-brand-text'], t['--wl-sys-color-surface'], 4.5],
      ['brand-on-recessed', t['--wl-sys-color-brand-text'], t['--wl-sys-color-surface-recessed'], 4.5],
      ['primary-cta', t['--wl-sys-color-on-action'], t['--wl-sys-color-action-fill'], 4.5],
      ['pressed-chip-text', t['--wl-sys-color-text'], t['--wl-sys-color-surface-selected'], 4.5],
      ['pressed-chip-indicator', pressedIndicator, t['--wl-sys-color-surface'], 3.0],
      ['focus-ring-on-gap', t['--wl-sys-color-focus'], t['--wl-sys-color-focus-gap'], 3.0],
      ['focus-ring-on-canvas', t['--wl-sys-color-focus'], t['--wl-sys-color-canvas'], 3.0],
    ];
    for (const [label, fg, bg, minRatio] of pairs) {
      const ratio = wcagContrastRatio(fg, bg);
      checks.push({
        theme,
        pair: label,
        fg,
        bg,
        ratio,
        minRatio,
        passed: ratio >= minRatio,
      });
    }
  }
  return checks;
}

function evaluateResponsiveAndTargetCssOracle(cssText) {
  const checks = [
    {
      name: 'rootOverflowClip',
      passed: /\.wl-home-root\s*\{[\s\S]*?overflow-x:\s*clip;/m.test(cssText),
    },
    {
      name: 'heroOverflowClip',
      passed: /\.wl-home-root\s+\.wl-hero\s*\{\s*overflow-x:\s*clip;\s*\}/m.test(cssText),
    },
    {
      name: 'chipTouchTargetMin44px',
      passed: /\.wl-home-chip\s*\{[^}]*min-height:\s*2\.75rem;/m.test(cssText),
    },
    {
      name: 'mobileActionsTouchTargetMin44px',
      passed: /\.wl-home-mobile-actions\s+\.wl-doc-button\s*\{[^}]*min-height:\s*2\.75rem;/m.test(cssText),
    },
    {
      name: 'tablet1180HeroImageContainment',
      passed: /@media\s*\(max-width:\s*1180px\)\s*\{[\s\S]*?\.wl-hero-shot\s+img\s*\{[^}]*width:\s*100%;[^}]*transform:\s*none;/m.test(
        cssText
      ),
    },
    {
      name: 'mobile900DrawerAnd44pxNavTargets',
      passed:
        /@media\s*\(max-width:\s*900px\)\s*\{[\s\S]*?\.wl-home-root\[data-nav-open="false"\]\s+\.wl-home-drawer\s*\{\s*display:\s*none;\s*\}[\s\S]*?\.wl-home-nav\s+a\s*\{[^}]*min-height:\s*2\.75rem;/m.test(
          cssText
        ),
    },
    {
      name: 'highContrastPressedChipNonColorAndFocusBorder',
      passed:
        /\.wl-home-root\[data-theme="high-contrast"\]\s+\.wl-home-chip\.is-pressed\s*\{[^}]*--wl-sys-color-focus[^}]*text-decoration:\s*underline;/m.test(
          cssText
        ),
    },
    {
      name: 'reducedMotionZeroDuration',
      passed:
        /\.wl-home-root\[data-motion="reduced"\]\s*\*[\s\S]*?transition-duration:\s*0ms\s*!important;[\s\S]*?animation-duration:\s*0ms\s*!important;/m.test(
          cssText
        ),
    },
  ];
  return checks;
}

function createControlledDom() {
  const focusCalls = [];
  let activeElement = null;
  const rafQueue = [];

  class NodeBase {
    constructor(nodeType, tagName) {
      this.nodeType = nodeType;
      this.tagName = tagName ? tagName.toUpperCase() : '';
      this.nodeName = this.tagName || '#text';
      this.namespaceURI = 'http://www.w3.org/1999/xhtml';
      this.parentNode = null;
      this.childNodes = [];
      this.attributes = new Map();
      this.listeners = new Map();
      this.style = {};
      this._id = '';
      this._className = '';
      this.tabIndex = 0;
    }
    get id() {
      return this._id;
    }
    set id(v) {
      this._id = String(v);
      this.attributes.set('id', this._id);
    }
    get className() {
      return this._className;
    }
    set className(v) {
      this._className = String(v);
      this.attributes.set('class', this._className);
    }
    setAttribute(name, value) {
      const k = String(name);
      const v = String(value);
      this.attributes.set(k, v);
      if (k === 'id') this._id = v;
      if (k === 'class') this._className = v;
      if (k === 'tabindex') this.tabIndex = Number(v);
    }
    getAttribute(name) {
      const k = String(name);
      return this.attributes.has(k) ? this.attributes.get(k) : null;
    }
    removeAttribute(name) {
      const k = String(name);
      this.attributes.delete(k);
      if (k === 'id') this._id = '';
      if (k === 'class') this._className = '';
    }
    appendChild(child) {
      if (child.nodeType === 11) {
        for (const c of [...child.childNodes]) this.appendChild(c);
        return child;
      }
      if (child.parentNode) child.parentNode.removeChild(child);
      child.parentNode = this;
      this.childNodes.push(child);
      return child;
    }
    insertBefore(newNode, refNode) {
      if (!refNode) return this.appendChild(newNode);
      const idx = this.childNodes.indexOf(refNode);
      if (idx === -1) return this.appendChild(newNode);
      if (newNode.parentNode) newNode.parentNode.removeChild(newNode);
      newNode.parentNode = this;
      this.childNodes.splice(idx, 0, newNode);
      return newNode;
    }
    removeChild(child) {
      const idx = this.childNodes.indexOf(child);
      if (idx !== -1) {
        this.childNodes.splice(idx, 1);
        child.parentNode = null;
      }
      return child;
    }
    replaceChild(newChild, oldChild) {
      const idx = this.childNodes.indexOf(oldChild);
      if (idx === -1) return this.appendChild(newChild);
      if (newChild.parentNode) newChild.parentNode.removeChild(newChild);
      newChild.parentNode = this;
      oldChild.parentNode = null;
      this.childNodes[idx] = newChild;
      return oldChild;
    }
    addEventListener(type, handler) {
      if (!this.listeners.has(type)) this.listeners.set(type, new Set());
      this.listeners.get(type).add(handler);
    }
    removeEventListener(type, handler) {
      if (this.listeners.has(type)) this.listeners.get(type).delete(handler);
    }
    focus() {
      activeElement = this;
      focusCalls.push(this.id || this.tagName);
    }
    get textContent() {
      if (this.nodeType === 3) return this.data || '';
      return this.childNodes.map((c) => c.textContent).join('');
    }
    set textContent(v) {
      this.childNodes = [];
      if (v !== '' && v !== null && v !== undefined) {
        const t = new TextNode(String(v));
        this.appendChild(t);
      }
    }
    dispatchEvent(rawEvent) {
      const event = Object.assign(
        {
          target: this,
          currentTarget: this,
          bubbles: true,
          cancelable: true,
          defaultPrevented: false,
          propagationStopped: false,
          preventDefault() {
            if (this.cancelable) this.defaultPrevented = true;
          },
          stopPropagation() {
            this.propagationStopped = true;
          },
        },
        rawEvent
      );
      let cur = this;
      while (cur) {
        event.currentTarget = cur;
        const set = cur.listeners.get(event.type);
        if (set) {
          for (const fn of [...set]) {
            if (typeof fn === 'function') fn.call(cur, event);
            else if (fn && typeof fn.handleEvent === 'function') fn.handleEvent(event);
          }
        }
        if (!event.bubbles || event.propagationStopped) break;
        cur = cur.parentNode;
      }
      return !event.defaultPrevented;
    }
  }

  class TextNode extends NodeBase {
    constructor(data) {
      super(3, '');
      this.data = String(data);
    }
    get nodeValue() {
      return this.data;
    }
    set nodeValue(v) {
      this.data = String(v);
    }
  }

  const documentElement = new NodeBase(1, 'html');
  const head = new NodeBase(1, 'head');
  const body = new NodeBase(1, 'body');
  const mountNode = new NodeBase(1, 'pre');
  mountNode.id = 'elm';
  documentElement.appendChild(head);
  documentElement.appendChild(body);
  body.appendChild(mountNode);

  function walk(root, pred, acc = []) {
    if (root.nodeType === 1 && pred(root)) acc.push(root);
    for (const c of root.childNodes) walk(c, pred, acc);
    return acc;
  }

  const document = {
    documentElement,
    head,
    body,
    get activeElement() {
      return activeElement || body;
    },
    createElement(tag) {
      return new NodeBase(1, tag);
    },
    createElementNS(_ns, tag) {
      return new NodeBase(1, tag);
    },
    createTextNode(text) {
      return new TextNode(text);
    },
    createDocumentFragment() {
      return new NodeBase(11, '');
    },
    getElementById(id) {
      return walk(documentElement, (el) => el.id === id)[0] || null;
    },
    querySelectorAll(pred) {
      return walk(documentElement, pred);
    },
    addEventListener(type, fn) {
      documentElement.addEventListener(type, fn);
    },
    removeEventListener(type, fn) {
      documentElement.removeEventListener(type, fn);
    },
  };

  function flushFrames() {
    while (rafQueue.length > 0) {
      const batch = rafQueue.splice(0, rafQueue.length);
      for (const cb of batch) cb(16.67);
    }
  }

  const windowObj = {
    document,
    navigator: { userAgent: 'WarlockHeadSiteQA/1.0' },
    location: { href: 'http://127.0.0.1/Warlock/index.html' },
    requestAnimationFrame(cb) {
      rafQueue.push(cb);
      return rafQueue.length;
    },
    cancelAnimationFrame() {},
    setTimeout,
    clearTimeout,
  };

  return { windowObj, document, focusCalls, flushFrames };
}

function validateRenderedDomSnapshot(document) {
  const root = document.querySelectorAll((el) =>
    (el.getAttribute('class') || '').includes('wl-home-root')
  )[0];
  if (!root) return { ok: false, reason: 'Missing .wl-home-root' };

  const tabs = document.querySelectorAll((el) => el.getAttribute('role') === 'tab');
  const zeroTabs = tabs.filter((t) => t.getAttribute('tabindex') === '0');
  const minusOneTabs = tabs.filter((t) => t.getAttribute('tabindex') === '-1');
  const selectedTabs = tabs.filter((t) => t.getAttribute('aria-selected') === 'true');
  if (tabs.length !== 8 || zeroTabs.length !== 1 || minusOneTabs.length !== 7 || selectedTabs.length !== 1) {
    return { ok: false, reason: 'Roving tabindex 1-of-8 invariant violated' };
  }
  if (zeroTabs[0].id !== selectedTabs[0].id) {
    return { ok: false, reason: 'tabindex=0 tab does not match aria-selected=true tab' };
  }

  const quickStrip = document.getElementById('wl-quick-scenarios');
  if (!quickStrip) return { ok: false, reason: 'Missing #wl-quick-scenarios conversion strip' };
  const quickLinks = document.querySelectorAll((el) =>
    (el.getAttribute('class') || '').includes('wl-home-scenario-chip')
  );
  if (quickLinks.length !== 5) {
    return { ok: false, reason: `Expected 5 quick scenario chips, got ${quickLinks.length}` };
  }

  for (const tierId of [
    'wl-tier-browser',
    'wl-tier-omarchy-app-only',
    'wl-tier-native-gate',
    'wl-tier-site-source',
  ]) {
    if (!document.getElementById(tierId)) {
      return { ok: false, reason: `Missing scope separation card #${tierId}` };
    }
  }

  const fullText = root.textContent;
  if (/15\s+whole\s+original/i.test(fullText)) {
    return { ok: false, reason: 'Stale 15 whole requirements text still present' };
  }
  if (!fullText.includes('17 / 242') || !fullText.includes('41 / 417')) {
    return { ok: false, reason: 'Missing current 17 / 242 and 41 / 417 ledger counts' };
  }
  if (!fullText.includes('--application-only') || !fullText.includes('Native release unaccepted')) {
    return { ok: false, reason: 'Missing truthful bounded app-only vs unaccepted native separation' };
  }

  return { ok: true, activeTabId: zeroTabs[0].id };
}

function runMutationSensitivitySelfTest() {
  // 1. Contrast oracle catches sub-4.5:1 text contrast (#777777 on #FFFFFF = 4.48:1)
  const lowRatio = wcagContrastRatio('#777777', '#FFFFFF');
  assert.equal(lowRatio < 4.5, true, 'Contrast oracle must reject #777777 on #FFFFFF (4.48:1 < 4.5:1)');

  // 2. Responsive target oracle catches 2.25rem (36px) chip height regression
  const regressedCss = '.wl-home-chip { min-height: 2.25rem; }';
  const cssChecks = evaluateResponsiveAndTargetCssOracle(regressedCss);
  const chipCheck = cssChecks.find((c) => c.name === 'chipTouchTargetMin44px');
  assert.equal(chipCheck.passed, false, 'Target-size oracle must reject 2.25rem chip min-height');

  return {
    passed: true,
    rejectedContrastSample: lowRatio,
    rejected36pxTargetSample: true,
  };
}

function main() {
  const htmlPath = path.resolve(process.argv[2] || path.join(__dirname, '../../site/index.html'));
  const tokensPath = path.resolve(
    process.argv[3] || path.join(__dirname, '../../site/assets/shared/tokens.css')
  );
  const reportOut = process.argv[4] ? path.resolve(process.argv[4]) : null;

  const htmlSource = fs.readFileSync(htmlPath, 'utf8');
  const tokensCss = fs.readFileSync(tokensPath, 'utf8');

  const scriptMatch = htmlSource.match(/<script>\s*(try\s*\{[\s\S]*?)\s*<\/script>/);
  assert.ok(scriptMatch, `Could not locate compiled Elm <script> block in ${htmlPath}`);

  const { windowObj, document, focusCalls, flushFrames } = createControlledDom();
  const sandbox = Object.assign(windowObj, {
    window: windowObj,
    self: windowObj,
    globalThis: windowObj,
    console,
  });
  vm.createContext(sandbox);
  vm.runInContext(scriptMatch[1], sandbox, { filename: htmlPath });
  flushFrames();

  // 1. Initial rendered DOM, quick test-drive conversion strip, and 3-tier status separation
  const initialSnap = validateRenderedDomSnapshot(document);
  assert.equal(initialSnap.ok, true, initialSnap.reason);
  assert.equal(initialSnap.activeTabId, 'wl-tab-taskbar');

  // 2. Extract rendered supplementalCss and verify responsive/target-size/reduced-motion/HC rules
  const styleNodes = document.querySelectorAll((el) => el.tagName === 'STYLE');
  assert.ok(styleNodes.length >= 1, 'Expected rendered <style> node from SiteMain.view');
  const supplementalCss = styleNodes.map((s) => s.textContent).join('\n');
  const responsiveChecks = evaluateResponsiveAndTargetCssOracle(supplementalCss);
  for (const rc of responsiveChecks) {
    assert.equal(rc.passed, true, `Responsive/CSS oracle failed: ${rc.name}`);
  }

  // 3. Literal WCAG 2.1 luminance contrast oracle across Night, Dawn, and High Contrast
  const themes = parseThemeTokens(tokensCss);
  const contrastChecks = evaluateContrastOracle(themes);
  for (const cc of contrastChecks) {
    assert.equal(
      cc.passed,
      true,
      `Contrast oracle failed on ${cc.theme}/${cc.pair} (${cc.fg} vs ${cc.bg}): ${cc.ratio}:1 < ${cc.minRatio}:1`
    );
  }

  // 4. Roving tabindex + Dom.focus + untrapped Tab + strict IME/null/wrong-type rejection on workbench
  const tabTaskbar = document.getElementById('wl-tab-taskbar');
  assert.ok(tabTaskbar);

  // Tab and Shift+Tab must NOT be prevented or steal focus
  const tabNotPrevented = tabTaskbar.dispatchEvent({
    type: 'keydown',
    key: 'Tab',
    isComposing: false,
    keyCode: 9,
  });
  flushFrames();
  assert.equal(tabNotPrevented, true, 'Tab key must not call preventDefault on tablist');
  assert.equal(focusCalls.length, 0);

  // IME composing, keyCode 229, Process, explicit null, and wrong-typed fields must all be rejected
  for (const rejectedEvent of [
    { type: 'keydown', key: 'ArrowRight', isComposing: true, keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: 229 },
    { type: 'keydown', key: 'Process', isComposing: false, keyCode: 0 },
    { type: 'keydown', key: 'ArrowRight', isComposing: null, keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: null },
    { type: 'keydown', key: 'ArrowRight', isComposing: 'false', keyCode: 39 },
    { type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: '39' },
  ]) {
    const allowedDefault = tabTaskbar.dispatchEvent(rejectedEvent);
    flushFrames();
    assert.equal(allowedDefault, true, 'Rejected event must not call preventDefault');
    assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-taskbar');
    assert.equal(focusCalls.length, 0);
  }

  // Valid ArrowRight moves roving tabindex to wl-tab-launcher and invokes Dom.focus
  const arrowPrevented = !tabTaskbar.dispatchEvent({
    type: 'keydown',
    key: 'ArrowRight',
    isComposing: false,
    keyCode: 39,
  });
  flushFrames();
  assert.equal(arrowPrevented, true);
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-launcher');
  assert.equal(focusCalls.at(-1), 'wl-tab-launcher');

  // End -> wl-tab-files, ArrowRight wraps -> wl-tab-taskbar
  const tabLauncher = document.getElementById('wl-tab-launcher');
  tabLauncher.dispatchEvent({ type: 'keydown', key: 'End', isComposing: false, keyCode: 35 });
  flushFrames();
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-files');
  assert.equal(focusCalls.at(-1), 'wl-tab-files');

  const tabFiles = document.getElementById('wl-tab-files');
  tabFiles.dispatchEvent({ type: 'keydown', key: 'ArrowRight', isComposing: false, keyCode: 39 });
  flushFrames();
  assert.equal(validateRenderedDomSnapshot(document).activeTabId, 'wl-tab-taskbar');
  assert.equal(focusCalls.at(-1), 'wl-tab-taskbar');

  // 5. Mobile drawer Escape focus return to #wl-home-nav-toggle + IME/null rejection
  const navToggle = document.getElementById('wl-home-nav-toggle');
  const drawer = document.getElementById('wl-home-nav-drawer');
  assert.ok(navToggle && drawer, 'Expected #wl-home-nav-toggle and #wl-home-nav-drawer');
  assert.equal(navToggle.getAttribute('aria-expanded'), 'false');

  const focusCountBeforeDrawer = focusCalls.length;
  navToggle.dispatchEvent({ type: 'click' });
  flushFrames();
  assert.equal(navToggle.getAttribute('aria-expanded'), 'true');

  // Composing or malformed/null Escape inside drawer must NOT close drawer
  for (const badEsc of [
    { type: 'keydown', key: 'Escape', isComposing: true, keyCode: 27 },
    { type: 'keydown', key: 'Escape', isComposing: false, keyCode: 229 },
    { type: 'keydown', key: 'Escape', isComposing: null, keyCode: 27 },
    { type: 'keydown', key: 'Escape', isComposing: 'false', keyCode: 27 },
  ]) {
    drawer.dispatchEvent(badEsc);
    flushFrames();
    assert.equal(navToggle.getAttribute('aria-expanded'), 'true');
    assert.equal(focusCalls.length, focusCountBeforeDrawer);
  }

  // Valid Escape closes drawer AND focuses #wl-home-nav-toggle
  drawer.dispatchEvent({ type: 'keydown', key: 'Escape', isComposing: false, keyCode: 27 });
  flushFrames();
  assert.equal(navToggle.getAttribute('aria-expanded'), 'false');
  assert.equal(focusCalls.at(-1), 'wl-home-nav-toggle');

  // Escape when already closed is a pure no-op
  const focusCountAfterClose = focusCalls.length;
  drawer.dispatchEvent({ type: 'keydown', key: 'Escape', isComposing: false, keyCode: 27 });
  flushFrames();
  assert.equal(focusCalls.length, focusCountAfterClose);

  // 6. Mutation sensitivity self-test
  const sensitivity = runMutationSensitivitySelfTest();

  const report = {
    suite: 'site-head-responsive-focus-contrast-qa-2135',
    htmlInput: htmlPath,
    tokensInput: tokensPath,
    allPassed: true,
    focusSequenceObserved: focusCalls,
    responsiveChecks,
    contrastChecksCount: contrastChecks.length,
    minObservedContrastRatio: Math.min(...contrastChecks.map((c) => c.ratio)),
    contrastChecks,
    mutationSensitivitySelfTest: sensitivity,
  };

  if (reportOut) {
    fs.writeFileSync(reportOut, JSON.stringify(report, null, 2) + '\n', 'utf8');
  }
  process.stdout.write(JSON.stringify({ ok: true, suite: report.suite, focusCalls, minContrast: report.minObservedContrastRatio }) + '\n');
}

main();
