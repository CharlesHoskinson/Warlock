{-# LANGUAGE OverloadedStrings #-}
-- QA ONLY: isolated candidate Backend + prelive-preparation-qa overlay.
-- Root must strong-root Case before runCase, keep same process/guardian and
-- original external QA deadline after all failures. One process, one Case;
-- no reset of QA counter while a worker might exist. The caller supplies the
-- Root-owned valid pinned real config path, never a synthetic peer or raw PID.
-- Current candidate014 enters the probe after prelive stop; expected RED.
-- Future fixed API must explicitly return a run result for pre-stop; if it
-- instead returns a typed refusal, update the oracle to that exact contract.
module QHttpPreliveStopControl (Mode(..),Case,newCase,runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try,throwIO)
import Control.Monad (unless)
import Data.IORef (IORef,newIORef,writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,requestPersistentBackendStop,
  persistentBackendCounts,qaPreparationCount)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

data Mode = LiveEntryControl | StopBeforePreparation deriving (Eq,Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar (Either SomeException PersistentBackendRun))
  (IORef (Maybe ThreadId))
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  stopBudget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  owner <- newPersistentBackendOwner current stopBudget
  Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing

-- The caller roots this Case before invoking; original caller deadline and
-- guardian bound reads/waiting, NOT a new internal duration or reset.
runCase :: Case -> Mode -> FilePath -> IO ()
runCase (Case owner start completed workerSlot) mode path = mask $ \restore -> do
  exists <- doesPathExist path
  check "actual owned config exists" (isAbsolute path && exists)
  before <- qaPreparationCount
  check "isolated one-shot probe starts unused" (before==0)
  configured <- restore (loadPersistentBackendConfig owner path)
  check "actual same-owner config succeeded before schedule" (configured==Right ())
  case mode of
    StopBeforePreparation -> restore $ do
      stop <- requestPersistentBackendStop owner
      check "actual prelive stop latched" (stop==P.StopLatchedBeforeLive)
      outcome <- try (runPersistentBackend owner) :: IO (Either SomeException PersistentBackendRun)
      entered <- qaPreparationCount
      check "stopped owner never enters display/root preparation" (entered==0)
      case outcome of
        Left problem -> throwIO problem -- never turn an arbitrary exception into a passing refusal
        Right result -> check "no checked callbacks or domain operations" (persistentBackendCounts result==(0,0))
    LiveEntryControl -> do
      thread <- forkIOWithUnmask $ \unmask -> do
        result <- try (unmask (takeMVar start >> runPersistentBackend owner))
        putMVar completed result
      writeIORef workerSlot (Just thread)
      putMVar start ()
      restore $ do
        let waitForActualProbe = do
              entered <- qaPreparationCount
              if entered>0 then pure () else do
                result <- tryReadMVar completed
                case result of
                  Just _ -> ioError (userError "live run ended before actual preparation probe")
                  Nothing -> threadDelay 1000 >> waitForActualProbe
        waitForActualProbe
        observed <- qaPreparationCount
        check "unstopped real run reaches preparation boundary" (observed==1)
        -- Same owner only. This receipt is not a reap or drain proof.
        _ <- requestPersistentBackendStop owner
        _ <- readMVar completed
        pure ()
