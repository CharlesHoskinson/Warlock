{-# LANGUAGE ScopedTypeVariables #-}
-- Unexecuted QA-only fixture for candidate persistent-owner v6 (source draft
-- 2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8).
-- Root compiles/runs only after selecting and hashing the exact owner source.
-- One fresh owned fixture process per case; no VM, provider, native effect or
-- release claim. `verifyReady` must verify the real owned child's readiness;
-- the supplied child must remain alive until its owner's stop or retirement.
module StopAdmissionOutcomes (runStopAdmissionOutcomes) where

import Control.Monad (unless, when)
import Data.IORef (newIORef, readIORef, writeIORef, modifyIORef')
import System.IO (Handle)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError(..), deadlineAfter)
import Warlock.Capture.Process.Persistent
  ( PersistentOwner, LiveOperationFailure(..), SessionExit(..), StopReceipt(..)
  , enterLiveFrameAction, newPersistentOwner, requestSessionStop
  , startBudgetAfter, stopBudgetMicros, withLiveFrameAdmission )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)

data Scenario = Normal | StopBeforeGate | StopBeforeBody | StopAfterEffect deriving (Eq, Show)

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError ("StopAdmissionOutcomes: " ++ name)))

must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- The caller's acquireAndRetain MUST put the new Owner into an external
-- recovery registry before acquiring an input handle, then register that
-- handle atomically before returning it. On any exception or uncertain owner
-- disposition the registry retains both; this helper never closes either.
-- Only the external owner may later release after confirmed disposition.
runStopAdmissionOutcomes :: (PersistentOwner -> IO Handle) -> FilePath -> [String]
  -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runStopAdmissionOutcomes acquireAndRetain childExe childArgs verifyReady =
  mapM_ one [Normal, StopBeforeGate, StopBeforeBody, StopAfterEffect]
  where
    one scenario = do
      owner <- newPersistentOwner
      input <- acquireAndRetain owner
      start <- startBudgetAfter 2000000 >>= must
      stopBudget <- must (stopBudgetMicros 2000000)
      calls <- newIORef (0 :: Int)
      receipt <- newIORef Nothing
      let stopOnce = do
            value <- requestSessionStop owner stopBudget
            writeIORef receipt (Just value)
          hook stage = when (scenario == StopBeforeBody && stage == "persistent-before-action-timeout") stopOnce
          live session = do
            frameD <- deadlineAfter 1500000 >>= must
            actionD <- deadlineAfter 1500000 >>= must
            withLiveFrameAdmission session $ \admission -> do
              when (scenario == StopBeforeGate) stopOnce
              enterLiveFrameAction admission frameD actionD $ do
                modifyIORef' calls (+1)
                when (scenario == StopAfterEffect) stopOnce
                pure (Right ())
      result <- withPersistentOwnerHook owner
        (persistentFixture childExe childArgs input) 4096 start stopBudget verifyReady live hook
      count <- readIORef calls
      stopped <- readIORef receipt
      -- LeaderReaped is only the direct owned leader/associated handle result;
      -- it is not provider, descendant containment or native cleanup evidence.
      let reaped = case result of Right (_, LeaderReaped _) -> True; _ -> False
          nested = case result of Right (value, _) -> Just value; _ -> Nothing
      check (show scenario ++ ": direct leader retirement") reaped
      case scenario of
        Normal -> check "normal admitted positive" (nested == Just (Right (Right ())) && count == 1 && stopped == Nothing)
        StopBeforeGate -> check "stop before gate refused without handler"
          (stopped == Just StopSignalSent && count == 0 && case nested of
            Just (Right (Left (OperationRefusedPreDispatch SessionClosed))) -> True
            Just (Right (Left (OperationRefusedPreDispatch SpawnOrIO))) -> True
            _ -> False)
        StopBeforeBody -> check "entered stop before handler is Unknown, not refusal"
          (stopped == Just StopSignalSent && nested == Just (Right (Left (OperationOutcomeUnknown SessionClosed))) && count == 0)
        StopAfterEffect -> check "entered effect then stop is Unknown once"
          (stopped == Just StopSignalSent && nested == Just (Right (Left (OperationOutcomeUnknown SessionClosed))) && count == 1)
