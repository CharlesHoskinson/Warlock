{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Actual PersistentOwner and its existing stop gate;
-- local actions stand in for retained resolver preparation and do not prove
-- any Root descriptor/cleanup/native result. Caller keeps Probe and any real
-- acquisition owner in the same live host; original external guardian remains.
module LexicalPreparationControls
 (Probe,newProbe,runPositive,runStopBefore,runStopDuring,runNoSeal,runEscapedSeal) where
import Control.Concurrent (ThreadId,forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException,finally,mask,mask_)
import Control.Monad (unless,void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),StopReceipt(..),StartupAdmissionFailure(..),
  newPersistentOwner,persistentStatus,requestSessionStop,startBudgetAfter,stopBudgetMicros,
  withPersistentStartupScope)

type ScopeResult = Either SomeException (Either StartupAdmissionFailure ())
data Probe = Probe PersistentOwner (IORef (Maybe ThreadId)) (MVar Bool) (MVar ()) (MVar ())
 (MVar ScopeResult) (IORef Int) (IORef Int) (IORef (Maybe (IO (Either StartupAdmissionFailure ())))) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef 0 <*> newIORef Nothing <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("lexical preparation: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain owner and host"))) pure
begin :: Probe -> IO ()
begin (Probe _ _ _ _ _ _ _ _ _ used) = do
 fresh <- atomicModifyIORef' used (\v -> (True,not v))
 check "single use" fresh
runPositive :: Probe -> IO ()
runPositive p@(Probe owner _ _ _ _ _ prep calls _ _) = do
 begin p
 budget <- startBudgetAfter 4000000 >>= need
 result <- withPersistentStartupScope owner budget $ \seal -> do
  modifyIORef' prep (+1)
  first <- seal
  case first of
   Left err -> pure (Left err)
   Right () -> do
    second <- seal
    check "seal is one shot" (second == Left (StartupAdmissionRefused OwnerBusy))
    modifyIORef' calls (+1)
    pure (Right ())
 a <- readIORef prep
 b <- readIORef calls
 check "actual owner admits single preparation and continuation" (result == Right () && a == 1 && b == 1)
runStopBefore :: Probe -> IO ()
runStopBefore p@(Probe owner _ _ _ _ _ prep calls _ _) = do
 begin p
 budget <- startBudgetAfter 4000000 >>= need
 stop <- need (stopBudgetMicros 1000000)
 receipt <- requestSessionStop owner stop
 result <- withPersistentStartupScope owner budget $ \seal -> do
  modifyIORef' prep (+1)
  r <- seal
  case r of Left e -> pure (Left e); Right () -> modifyIORef' calls (+1) >> pure (Right ())
 a <- readIORef prep
 b <- readIORef calls
 check "stop first refuses before preparation entry" $
  receipt == StopLatchedBeforeLive && result == Left (StartupAdmissionRefused SessionClosed) && a == 0 && b == 0
runNoSeal :: Probe -> IO ()
runNoSeal p@(Probe owner _ _ _ _ _ prep calls _ _) = do
 begin p
 budget <- startBudgetAfter 4000000 >>= need
 result <- withPersistentStartupScope owner budget $ \_ -> modifyIORef' prep (+1) >> pure (Right ())
 phase <- within "phase" (persistentStatus owner)
 a <- readIORef prep
 b <- readIORef calls
 check "entered work without seal remains unknown" $
  result == Left StartupAdmissionUnknown && a == 1 && b == 0 && case phase of PersistentQuarantined _ -> True; _ -> False
-- A retained continuation attempted after the body returned must not seal.
-- The production caller must not store it; this negative control checks the
-- ordinary sequential misuse only, not all possible concurrent escapes.
runEscapedSeal :: Probe -> IO ()
runEscapedSeal p@(Probe owner _ _ _ _ _ _ _ saved _) = do
 begin p
 budget <- startBudgetAfter 4000000 >>= need
 result <- withPersistentStartupScope owner budget $ \seal -> writeIORef saved (Just seal) >> pure (Right ())
 captured <- readIORef saved
 late <- case captured of Nothing -> ioError (userError "seal not captured"); Just action -> action
 check "late seal is refused" (result == Left StartupAdmissionUnknown && late == Left (StartupAdmissionRefused OwnerBusy))
runStopDuring :: Probe -> IO ()
runStopDuring p@(Probe owner worker decision entered resume done prep calls _ _) = mask $ \restore -> do
 begin p
 let finish = do
      void (tryPutMVar resume ())
      mtid <- readIORef worker
      case mtid of Nothing -> pure (); Just _ -> void (tryPutMVar decision False) >> void (timeout 3000000 (readMVar done))
     body = do
      budget <- startBudgetAfter 4000000 >>= need
      _ <- mask_ $ do
       tid <- forkFinally (do
        allowed <- readMVar decision
        if allowed then restore (withPersistentStartupScope owner budget $ \seal -> do
         modifyIORef' prep (+1)
         putMVar entered ()
         readMVar resume
         r <- seal
         case r of Left e -> pure (Left e); Right () -> modifyIORef' calls (+1) >> pure (Right ()))
        else ioError (userError "worker not admitted")) (putMVar done)
       writeIORef worker (Just tid)
       putMVar decision True
       pure tid
      within "actual preparation entered" (readMVar entered)
      stop <- need (stopBudgetMicros 1000000)
      receipt <- requestSessionStop owner stop
      void (tryPutMVar resume ())
      result <- within "scope result" (readMVar done)
      phase <- within "phase" (persistentStatus owner)
      a <- readIORef prep
      b <- readIORef calls
      check "first stop prevents seal and continuation" $
       receipt == StopLatchedBeforeLive && a == 1 && b == 0 &&
       (case result of Right (Left StartupAdmissionUnknown) -> True; _ -> False) &&
       (case phase of PersistentQuarantined _ -> True; _ -> False)
 restore body `finally` finish
