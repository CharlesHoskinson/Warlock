# Engine PID1 split: current source map

Preparation only. This describes the current source and review constraints; it
does not implement a broker, qualify a native engine, or accept an original
scenario. Preserve the original 242 requirements, 417 scenarios, deadlines,
failure evidence, stop histories and desktop. Root owns protected execution.

## Existing boundary

- `runtime/ui/Main.hs:15-25` captures `withPeerNetwork` before entering the
  private network, reads config, starts custody, then calls `runUiOwner` with
  `runWebKitWithCustody`; `abandonCustody` is in `finally`.
- `runtime/src/Warlock/Ui/PrivateNetwork.hsc:174-207,236-290` duplicates fd 0
  for non-consuming Unix-stream and peer checks; captures parent pidfd and
  network namespace before transition; revalidates identity, liveness and
  isolation using an owned, scoped witness. This witness is process-bound.
- `runtime/src/Warlock/Ui/Owner.hs:33-35,106,234-236` defines endpoints,
  trusted owner events, `EngineResult`, and `runUiOwner`; it adopts the native
  channel and checks the witness. A future split must specify custody and
  authenticated transport for facts; a callback or serialized boolean does not
  transfer the witness or authenticate a new sender.
- `runtime/ui/Warlock/Ui/EngineCustody.hsc:150-203` requires one OS task and
  compatible SIGCHLD ownership, unshares PID-for-children, forks the PID1
  custodian, and captures its pidfd and ready/lifeline. This unshare cannot be
  rolled back in the caller. `stopCustody` at 205-228 uses verified pidfd
  signal, observation and `waitid(P_PIDFD)` within the remaining deadline;
  `abandonCustody` at 229-241 signals/closes but does not claim a reap.
- `runtime/src/Warlock/Ui/ThreadNamespace.hs:8-16` exports
  `requireThreadCompatibleNamespace`, comparing device/inode of calling
  thread's `pid` and `pid_for_children`; mismatch or unreadable procfs refuses.
  `runtime/ui/Warlock/Ui/WebKit.hs:375-382` calls it before GTK initialization.
  Existing same-process custody changes the children namespace; the guard does
  not itself implement an exec/PID1 broker split.
- WebKit `connectOwnedSignal` at 220 and `compileFilter` at 293 retain callback
  and backing objects until completion/retirement is observed. `runWebKit` and
  `runWebKitWithCustody` at 366-370 feed `EngineResult`; the latter's cleanup
  facts at 483 onward distinguish namespace exit, provider and callback
  retirement. Split-process event callbacks must remain scoped observations,
  not authority or fabricated cleanup receipts.

## Spawn and authentication contracts

- `process-custody/process-custody.cabal:11,15` keeps `Whitelist` internal and
  exposes `Warlock.Capture.Process.Bootstrap`. `Bootstrap.hs:3-11` exposes
  held executable selection, transfer tickets, `Session`, nonreaping
  observation/`awaitLeader`, deadline and `runSelectedDetailed`. It does **not**
  expose `SelectedFDPlan`, `trustedBorrowedPlan`, or `spawnWhitelisted`.
- `Whitelist.hsc:30-40,62-70,115-145` is a private borrowed-FD bridge, not a
  public issuer: the caller holds source leases and retained `Pending`, records
  PID and process handle before publication, and uses the existing owned
  group-before-wait, sole-reaper path. It uses fixed argv/environment and
  selected descriptors. `Internal.hsc:502-503` currently refuses a selected
  stdin transfer on the selected-FD route; a needed combined facade must be
  explicitly designed and reviewed rather than assumed available.
- `Internal.hsc:266-285,434-480` observes leader exit without reaping, drains
  the session scope, signals the owned group before final reap, and quarantines
  uncertain cleanup. A split must have one explicit reaper per child and not
  race GLib, SIGCHLD handlers or another waiter.
- `runtime/src/Warlock/Bootstrap/ScopedPeer.hs:30-67` binds admission to the
  selected process/session on its original thread; each credential is from
  `recvmsg`, not JSON or `SO_PEERCRED`. `protocol/src/Warlock/Transport/PeerCredentials.hsc:200-235`
  validates SCM credentials and rejects rights/unexpected controls. A helper's
  actual sender identity is distinct; routing through it cannot silently reuse
  the original selected child's credential authority.
- Held executable selection, transfer close ownership, original absolute
  deadline and callback retirement remain separate proof obligations. No new
  raw descriptor, PID, diagnostic text, or page input should become a policy
  authority by crossing the proposed boundary.

## Existing regression locations

- `runtime/test-ui-webkit/Main.hs:248-270`: actual thread namespace guard
  and isolated owned mismatch child; earlier signal/context tests cover
  callback lifetime without establishing GTK or WebKit execution.
- `runtime/test-ui-engine/Main.hs`: actual custody and fd 0 retention,
  already-reaped and callback-uncertainty controls.
- `runtime/test-ui-private-network/Main.hs:57-150,184-224,255-310`: witness
  process binding, fd swap/closed peer, retirement and non-consuming checks.
- `process-custody/test/SelectedFD.hs` and `FacadeControl.hs`: existing private
  selected-FD and public bootstrap boundaries; `Internal.hsc:649-671` retains
  startup failure and group/reap handling.

These are locations for root-reviewed checks, not results for a new split.
Source-only review did not run a compiler, test, model, GPU, native or VM.

## Source SHA-256 at review

| Source | SHA-256 |
| --- | --- |
| `runtime/src/Warlock/Ui/ThreadNamespace.hs` | `3a8504a5dd8fb4dac2b7c721da5e141cf571dae18f5c814dfd11bb5ebb8f3e2f` |
| `runtime/src/Warlock/Ui/PrivateNetwork.hsc` | `2205761421203a631a1dc861c55501c8356e5630e96de3206dc00f986531fd2b` |
| `runtime/src/Warlock/Ui/Owner.hs` | `e6100f7ae8b5512c66b9cbde2a81a167719f6415c1e92fc33570974d5b69ad2f` |
| `runtime/ui/Warlock/Ui/EngineCustody.hsc` | `e8fa295690356aef8621e04ad5d28665dfe195189baa7536b76245b295696070` |
| `runtime/ui/Warlock/Ui/WebKit.hs` | `b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a` |
| `process-custody/src/Warlock/Capture/Process/Bootstrap.hs` | `dc8273cb33d6f23757b20f16f7cefc83d00fc8ab4d00520149744928bbd1a461` |
| `process-custody/src/Warlock/Capture/Process/Whitelist.hsc` | `62775261c983b9b2f8f256734c731fee492f1f4a327ceab845370bd6e82da416` |
| `process-custody/src/Warlock/Capture/Process/Internal.hsc` | `f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f` |

Paths in this table are relative to `implementation/warlock/haskell/`.
