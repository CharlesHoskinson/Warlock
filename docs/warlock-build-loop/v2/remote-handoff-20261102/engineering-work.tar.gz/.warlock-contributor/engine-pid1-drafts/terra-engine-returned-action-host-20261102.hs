-- ROOT ONLY, SOURCE ONLY, UNEXECUTED.
-- Root supplies an already selected absolute CLOCK_MONOTONIC deadline and
-- its existing stop budget. Run each mode in a distinct externally guarded
-- process; a timed-out worker/owner stays with the guardian, never guessed clean.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Exception (SomeException, displayException, try)
import System.Environment (getArgs)
import System.IO (hPutStrLn, stderr)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap (deadlineFromAbsoluteNs)
import Warlock.Capture.Process.Persistent (stopBudgetMicros)
import qualified TerraEngineReturnedActionDrain as T

main :: IO ()
main = do
 args <- getArgs
 (mode, absoluteD, budgetText) <- case args of
  ["positive", deadline, budget] -> pure (T.CompletedAction, deadline, budget)
  ["stop-return", deadline, budget] -> pure (T.StopWhileAction, deadline, budget)
  _ -> ioError (userError "expected positive|stop-return ABSOLUTE_MONOTONIC_NS STOP_BUDGET_US")
 originalD <- deadlineFromAbsoluteNs absoluteD >>= either (ioError . userError . show) pure
 micros <- maybe (ioError (userError "invalid stop budget")) pure (readMaybe budgetText :: Maybe Int)
 stopBudget <- either (ioError . userError . show) pure (stopBudgetMicros micros)
 ownerCase <- T.newCase
 result <- try (T.runCase ownerCase originalD stopBudget mode) :: IO (Either SomeException ())
 case result of
  Right () -> putStrLn "returned-action-drain: source-bound control passed"
  Left problem -> do
   -- Keep the Case and its possibly running workers reachable; the external
   -- protected guardian owns any later process disposition. No retry or signal.
   hPutStrLn stderr ("returned-action-drain: Unknown/failure: " ++ displayException problem)
   let retain = do
        threadDelay 1000000
        _ <- T.retainedResults ownerCase
        retain
   retain
-- This report is a control result only. It does not establish child/provider,
-- callback, native UI or whole-owner cleanup, and does not accept an EARS.
