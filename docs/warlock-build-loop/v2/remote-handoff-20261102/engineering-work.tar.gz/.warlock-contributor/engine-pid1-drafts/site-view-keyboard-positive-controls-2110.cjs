'use strict';
// Controlled Node DOM positive/negative view, keyboard, roving-tabindex,
// Escape-disclosure, and IME/malformed-event harness for compiled SiteMain
// (either <output>/site-build/site.html from `check_haskell_cpu.py --site`
// or the spliced `site/index.html` production entry).
//
// Component/DOM evidence only: never claims physical browser layout/contrast,
// physical Dom.focus race timing, assistive-technology speech, or native/release
// acceptance. Pair with Playwright browser checks (KBD-01..KBD-07).

const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');

const [entryFile, reportFile] = process.argv.slice(2);
if (!entryFile || !reportFile || process.argv.length !== 4) {
  throw new Error('Usage: node site-view-keyboard-positive-controls-2110.cjs <SITE_HTML_OR_JS> <REPORT.json>');
}

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

const report = {
  schema: 1,
  harness: 'site-view-keyboard-positive-controls-2110',
  passed: false,
  componentDomEvidenceOnly: true,
  physicalBrowserLayoutVerified: false,
  physicalDomFocusRaceVerified: false,
  assistiveTechVerified: false,
  nativeAccepted: false,
  releaseAccepted: false,
  artifactHashes: {
    entry: sha256(fs.readFileSync(entryFile)),
    harness: sha256(fs.readFileSync(__filename)),
  },
  focusTrace: [],
  checks: [],
  failures: [],
};

function check(name, ok, witness) {
  const row = { name, passed: Boolean(ok) };
  if (!ok) row.witness = witness ?? null;
  report.checks.push(row);
  if (!ok) report.failures.push(row);
}

function saveReport() {
  fs.writeFileSync(reportFile, JSON.stringify(report, null, 2) + '\n', 'utf8');
}

function extractExecutableScript(rawSource, filePath) {
  if (!filePath.toLowerCase().endsWith('.html')) {
    return { script: rawSource, wrapperChecks: null };
  }
  const match = rawSource.match(/<script>([\s\S]*?)<\/script>/i);
  if (!match) {
    throw new Error('No <script>...</script> bundle found in HTML entry: ' + filePath);
  }
  const isProductionIndex = rawSource.includes('data-page="index.html"');
  const wrapperChecks = {
    isProductionIndex,
    hasHtmlLangEn: /<html[^>]*\blang="en"/i.test(rawSource),
    hasViewportMeta: /<meta[^>]*\bname="viewport"/i.test(rawSource),
    hasElmMountPre: /<pre\s+id="elm"\s*><\/pre>/i.test(rawSource),
    hasDesignAttr: !isProductionIndex || /data-warlock-design="v1"/.test(rawSource),
    hasBodyLandingClass: !isProductionIndex || /class="wl-landing-page"/.test(rawSource),
  };
  return { script: match[1], wrapperChecks };
}

function createDomEnvironment(scriptCode) {
  const timers = new Map();
  let seq = 0;
  let activeElement = null;
  const focusCalls = [];

  class DomNode {
    constructor(nodeType, tagName, text = '') {
      this.nodeType = nodeType;
      this.tagName = tagName;
      this.nodeName = tagName;
      this.localName = tagName.toLowerCase();
      this.data = text;
      this.nodeValue = text;
      this.parentNode = null;
      this.childNodes = [];
      this._attrMap = Object.create(null);
      this.attributes = [];
      this.style = {};
      this.listeners = Object.create(null);
      this.id = '';
      this.className = '';
      this.tabIndex = undefined;
      this.href = '';
      this.type = '';
    }
    _syncAttrArray() {
      this.attributes = Object.entries(this._attrMap).map(([name, value]) => ({ name, value }));
    }
    get textContent() {
      return this.nodeType === 3 ? this.data : this.childNodes.map((c) => c.textContent).join('');
    }
    set textContent(v) {
      if (this.nodeType === 3) {
        this.data = String(v);
        this.nodeValue = String(v);
      } else {
        this.childNodes = [];
        if (v) this.appendChild(new DomNode(3, '#text', String(v)));
      }
    }
    appendChild(child) {
      return this.insertBefore(child, null);
    }
    insertBefore(child, before) {
      if (child.nodeType === 11) {
        for (const item of [...child.childNodes]) this.insertBefore(item, before);
        return child;
      }
      if (child.parentNode) child.parentNode.removeChild(child);
      let idx = before ? this.childNodes.indexOf(before) : -1;
      if (idx < 0) idx = this.childNodes.length;
      this.childNodes.splice(idx, 0, child);
      child.parentNode = this;
      return child;
    }
    removeChild(child) {
      const idx = this.childNodes.indexOf(child);
      if (idx < 0) throw new Error('Missing DOM child');
      this.childNodes.splice(idx, 1);
      child.parentNode = null;
      return child;
    }
    replaceChild(child, old) {
      this.insertBefore(child, old);
      this.removeChild(old);
      return old;
    }
    replaceData(_off, _cnt, val) {
      this.data = String(val);
      this.nodeValue = String(val);
    }
    setAttribute(k, v) {
      const sv = String(v);
      this._attrMap[k] = sv;
      if (k === 'id') this.id = sv;
      if (k === 'class') this.className = sv;
      if (k === 'href') this.href = sv;
      if (k === 'tabindex') this.tabIndex = Number(sv);
      this._syncAttrArray();
    }
    setAttributeNS(_ns, k, v) {
      this.setAttribute(k, v);
    }
    getAttribute(k) {
      if (k in this._attrMap) return this._attrMap[k];
      if (k === 'id' && this.id) return this.id;
      if (k === 'class' && this.className) return this.className;
      if (k === 'href' && this.href) return this.href;
      if (k === 'tabindex' && this.tabIndex !== undefined) return String(this.tabIndex);
      return null;
    }
    removeAttribute(k) {
      delete this._attrMap[k];
      if (k === 'id') this.id = '';
      if (k === 'class') this.className = '';
      if (k === 'tabindex') this.tabIndex = undefined;
      this._syncAttrArray();
    }
    removeAttributeNS(_ns, k) {
      this.removeAttribute(k);
    }
    addEventListener(type, fn) {
      this.listeners[type] = fn;
    }
    removeEventListener(type, fn) {
      if (this.listeners[type] === fn) delete this.listeners[type];
    }
    focus() {
      activeElement = this;
      const domId = this.getAttribute('id') || '';
      focusCalls.push(domId);
      report.focusTrace.push(domId);
    }
    hasClass(cls) {
      const raw = this.getAttribute('class') || '';
      return raw.split(/\s+/).includes(cls);
    }
  }

  function walkAll(root, pred, out = []) {
    if (root.nodeType === 1 && pred(root)) out.push(root);
    for (const ch of root.childNodes) walkAll(ch, pred, out);
    return out;
  }

  function findFirst(root, pred) {
    if (root.nodeType === 1 && pred(root)) return root;
    for (const ch of root.childNodes) {
      const hit = findFirst(ch, pred);
      if (hit) return hit;
    }
    return null;
  }

  const body = new DomNode(1, 'BODY');
  const mount = new DomNode(1, 'PRE');
  mount.setAttribute('id', 'elm');
  body.appendChild(mount);

  const later = (fn, delay = 0) => {
    const id = ++seq;
    timers.set(id, { fn, delay });
    return id;
  };
  const cancel = (id) => timers.delete(id);

  const document = {
    body,
    documentElement: body,
    get activeElement() {
      return activeElement;
    },
    createTextNode: (t) => new DomNode(3, '#text', String(t)),
    createElement: (tag) => new DomNode(1, String(tag).toUpperCase()),
    createElementNS: (_ns, tag) => new DomNode(1, String(tag).toUpperCase()),
    createDocumentFragment: () => new DomNode(11, '#document-fragment'),
    addEventListener() {},
    removeEventListener() {},
    getElementById: (id) => findFirst(body, (n) => n.getAttribute('id') === id),
  };

  const window = {
    document,
    navigator: { userAgent: 'WarlockSiteControlledDom/1.0' },
    location: { href: 'http://127.0.0.1/index.html' },
    addEventListener() {},
    removeEventListener() {},
    requestAnimationFrame: (fn) => later(fn, 0),
    cancelAnimationFrame: cancel,
  };

  const sandbox = {
    console,
    document,
    window,
    navigator: window.navigator,
    setTimeout: later,
    clearTimeout: cancel,
    requestAnimationFrame: window.requestAnimationFrame,
    cancelAnimationFrame: cancel,
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;

  vm.createContext(sandbox);
  vm.runInContext(scriptCode, sandbox, { timeout: 5000 });

  // If raw JS bundle without inline Elm.SiteMain.init was passed, mount explicitly.
  if (sandbox.Elm?.SiteMain && document.getElementById('elm')) {
    sandbox.Elm.SiteMain.init({ node: document.getElementById('elm') });
  }

  function flush() {
    for (let round = 0; round < 16; round++) {
      const ready = [...timers.entries()].filter(([, row]) => row.delay <= 0);
      if (ready.length === 0) break;
      for (const [id, row] of ready) {
        timers.delete(id);
        row.fn();
      }
    }
  }

  function dispatch(target, type, init = {}) {
    if (!target) throw new Error('Cannot dispatch ' + type + ' on null target');
    let defaultPrevented = false;
    let propagationStopped = false;
    const event = Object.assign(
      {
        type,
        target,
        currentTarget: target,
        bubbles: init.bubbles !== undefined ? init.bubbles : true,
        cancelable: true,
        get defaultPrevented() {
          return defaultPrevented;
        },
        preventDefault() {
          defaultPrevented = true;
        },
        stopPropagation() {
          propagationStopped = true;
        },
      },
      init
    );
    let cur = target;
    while (cur && !propagationStopped) {
      event.currentTarget = cur;
      const listener = cur.listeners && cur.listeners[type];
      if (listener) listener(event);
      if (!event.bubbles) break;
      cur = cur.parentNode;
    }
    flush();
    return { defaultPrevented };
  }

  flush();
  return { body, document, walkAll, findFirst, dispatch, flush, focusCalls };
}

function validateWorkbenchRovingDom(env, expectedTabId) {
  const tablist = env.findFirst(env.body, (n) => n.getAttribute('role') === 'tablist');
  const panel = env.document.getElementById('wl-workbench-panel');
  if (!tablist || !panel) return { ok: false, reason: 'missing tablist or tabpanel' };
  const tabs = env.walkAll(tablist, (n) => n.getAttribute('role') === 'tab');
  if (tabs.length !== 8) return { ok: false, reason: 'expected 8 tabs, got ' + tabs.length };
  const zeroTabs = tabs.filter((t) => Number(t.getAttribute('tabindex')) === 0 && t.getAttribute('aria-selected') === 'true');
  const minusOneTabs = tabs.filter((t) => Number(t.getAttribute('tabindex')) === -1 && t.getAttribute('aria-selected') === 'false');
  const allControlsLinked = tabs.every((t) => t.getAttribute('aria-controls') === 'wl-workbench-panel');
  const panelLinked =
    panel.getAttribute('role') === 'tabpanel' &&
    panel.getAttribute('aria-labelledby') === expectedTabId &&
    Number(panel.getAttribute('tabindex')) === 0;
  return {
    ok:
      zeroTabs.length === 1 &&
      zeroTabs[0].getAttribute('id') === expectedTabId &&
      minusOneTabs.length === 7 &&
      allControlsLinked &&
      panelLinked,
    zeroTabIds: zeroTabs.map((t) => t.getAttribute('id')),
    panelLabelledBy: panel.getAttribute('aria-labelledby'),
  };
}

function validateHonestCopyDom(rootText) {
  return (
    rootText.includes('16 of 242 requirements') &&
    rootText.includes('40 of 417 scenarios') &&
    rootText.includes('28-second') &&
    rootText.includes('unqualified') &&
    rootText.includes('Read source build instructions') &&
    !rootText.includes('15 / 242') &&
    !rootText.includes('15 of 242') &&
    !rootText.includes('ELM-UI-007') &&
    !rootText.includes('run-omarchy-mvp')
  );
}

try {
  const raw = fs.readFileSync(entryFile, 'utf8');
  const { script, wrapperChecks } = extractExecutableScript(raw, entryFile);
  if (wrapperChecks) {
    check(
      'html-entry-wrapper-structure',
      wrapperChecks.hasHtmlLangEn &&
        wrapperChecks.hasViewportMeta &&
        wrapperChecks.hasElmMountPre &&
        wrapperChecks.hasDesignAttr &&
        wrapperChecks.hasBodyLandingClass,
      wrapperChecks
    );
  }

  const env = createDomEnvironment(script);
  const root = env.findFirst(env.body, (n) => n.hasClass('wl-home-root'));
  check(
    'mounted-site-root-initial-dataset',
    Boolean(root) &&
      root.getAttribute('data-theme') === 'night' &&
      root.getAttribute('data-motion') === 'standard' &&
      root.getAttribute('data-nav-open') === 'false',
    root && root.attributes
  );

  // 1. Landmark, skip-link, hero scope association, and onboarding steps in rendered view
  const skipLink = env.findFirst(env.body, (n) => n.hasClass('wl-doc-skip'));
  const mainLandmark = env.document.getElementById('main');
  check(
    'skip-link-and-main-landmark-rendered',
    Boolean(skipLink) &&
      skipLink.getAttribute('href') === '#main' &&
      Boolean(mainLandmark) &&
      mainLandmark.tagName === 'MAIN' &&
      Number(mainLandmark.getAttribute('tabindex')) === -1
  );

  const heroNote = env.document.getElementById('hero-scope-note');
  const heroPrimaryCta = env.findFirst(
    env.body,
    (n) => n.tagName === 'A' && n.getAttribute('aria-describedby') === 'hero-scope-note'
  );
  check(
    'hero-primary-cta-described-by-honest-scope-note',
    Boolean(heroNote) &&
      Boolean(heroPrimaryCta) &&
      heroPrimaryCta.getAttribute('href') === './test-drive/index.html' &&
      validateHonestCopyDom(env.body.textContent)
  );

  const readinessItems = env.walkAll(env.body, (n) => n.hasClass('wl-home-readiness-item'));
  const onboardingList = env.findFirst(env.body, (n) => n.hasClass('wl-home-onboarding-list'));
  const onboardingSteps = onboardingList ? env.walkAll(onboardingList, (n) => n.hasClass('wl-home-onboarding-step')) : [];
  check(
    'readiness-strip-and-3-step-onboarding-rendered',
    readinessItems.length === 4 &&
      Boolean(onboardingList) &&
      onboardingList.tagName === 'OL' &&
      onboardingSteps.length === 3
  );

  // 2. Initial roving tabindex + full 8-step ArrowRight cycle with real Dom.focus
  const initialRoving = validateWorkbenchRovingDom(env, 'wl-tab-taskbar');
  check('initial-workbench-roving-tabindex-dom', initialRoving.ok, initialRoving);

  const expectedCycle = [
    'wl-tab-launcher',
    'wl-tab-switcher',
    'wl-tab-task-view',
    'wl-tab-snap',
    'wl-tab-notifications',
    'wl-tab-settings',
    'wl-tab-files',
    'wl-tab-taskbar',
  ];
  let activeTabId = 'wl-tab-taskbar';
  let cycleAllOk = true;
  for (const nextId of expectedCycle) {
    const currentTab = env.document.getElementById(activeTabId);
    const beforeFocusLen = env.focusCalls.length;
    const res = env.dispatch(currentTab, 'keydown', { key: 'ArrowRight', keyCode: 39 });
    const roving = validateWorkbenchRovingDom(env, nextId);
    const focusedNow = env.document.activeElement && env.document.activeElement.getAttribute('id') === nextId;
    if (!res.defaultPrevented || !roving.ok || !focusedNow || env.focusCalls.length !== beforeFocusLen + 1) {
      cycleAllOk = false;
      break;
    }
    activeTabId = nextId;
  }
  check('workbench-arrow-right-8-step-wrap-and-dom-focus', cycleAllOk, env.focusCalls);

  // 3. ArrowLeft wrap, End, Home, and untrapped Tab negative control
  const taskbarTab = env.document.getElementById('wl-tab-taskbar');
  const leftRes = env.dispatch(taskbarTab, 'keydown', { key: 'ArrowLeft', keyCode: 37 });
  check(
    'workbench-arrow-left-wraps-to-files-with-focus',
    leftRes.defaultPrevented &&
      validateWorkbenchRovingDom(env, 'wl-tab-files').ok &&
      env.document.activeElement?.getAttribute('id') === 'wl-tab-files'
  );

  const filesTab = env.document.getElementById('wl-tab-files');
  const homeRes = env.dispatch(filesTab, 'keydown', { key: 'Home', keyCode: 36 });
  const endRes = env.dispatch(env.document.getElementById('wl-tab-taskbar'), 'keydown', { key: 'End', keyCode: 35 });
  check(
    'workbench-home-and-end-jump-with-focus',
    homeRes.defaultPrevented &&
      endRes.defaultPrevented &&
      validateWorkbenchRovingDom(env, 'wl-tab-files').ok &&
      env.document.activeElement?.getAttribute('id') === 'wl-tab-files'
  );

  const focusBeforeTab = env.focusCalls.length;
  const tabKeyRes = env.dispatch(env.document.getElementById('wl-tab-files'), 'keydown', { key: 'Tab', keyCode: 9 });
  check(
    'workbench-tab-key-not-trapped',
    !tabKeyRes.defaultPrevented &&
      validateWorkbenchRovingDom(env, 'wl-tab-files').ok &&
      env.focusCalls.length === focusBeforeTab
  );

  // 4. IME composition & malformed synthetic event negative controls on tablist
  const focusBeforeImeTab = env.focusCalls.length;
  const imeArrow1 = env.dispatch(env.document.getElementById('wl-tab-files'), 'keydown', { key: 'ArrowRight', isComposing: true });
  const imeArrow2 = env.dispatch(env.document.getElementById('wl-tab-files'), 'keydown', { key: 'ArrowRight', keyCode: 229 });
  const badArrow3 = env.dispatch(env.document.getElementById('wl-tab-files'), 'keydown', { key: 'ArrowRight', isComposing: 'false' });
  check(
    'workbench-rejects-composing-and-malformed-key-events',
    !imeArrow1.defaultPrevented &&
      !imeArrow2.defaultPrevented &&
      !badArrow3.defaultPrevented &&
      validateWorkbenchRovingDom(env, 'wl-tab-files').ok &&
      env.focusCalls.length === focusBeforeImeTab
  );

  // 5. Mobile navigation disclosure, bubbling Escape focus restore, IME guard, and link non-hijack
  const navToggle = env.document.getElementById('wl-mobile-nav-toggle');
  const navDrawer = env.document.getElementById('wl-home-nav-drawer');
  check(
    'mobile-nav-initial-aria-attributes',
    Boolean(navToggle) &&
      Boolean(navDrawer) &&
      navToggle.getAttribute('aria-expanded') === 'false' &&
      navToggle.getAttribute('aria-controls') === 'wl-home-nav-drawer'
  );

  env.dispatch(navToggle, 'click');
  check(
    'mobile-nav-toggle-opens-drawer',
    navToggle.getAttribute('aria-expanded') === 'true' && root.getAttribute('data-nav-open') === 'true'
  );

  const drawerLink = env.findFirst(navDrawer, (n) => n.tagName === 'A');
  // Composing or malformed Escape inside open drawer must NOT close drawer
  env.dispatch(drawerLink, 'keydown', { key: 'Escape', isComposing: true, bubbles: true });
  env.dispatch(drawerLink, 'keydown', { key: 'Escape', keyCode: 229, bubbles: true });
  env.dispatch(drawerLink, 'keydown', { key: 'Escape', isComposing: 1, bubbles: true });
  check(
    'mobile-nav-composing-or-malformed-escape-does-not-close',
    root.getAttribute('data-nav-open') === 'true' && navToggle.getAttribute('aria-expanded') === 'true'
  );

  // Real Escape bubbling from drawer link up to <header> closes drawer and focuses #wl-mobile-nav-toggle
  const focusBeforeEsc = env.focusCalls.length;
  env.dispatch(drawerLink, 'keydown', { key: 'Escape', isComposing: false, keyCode: 27, bubbles: true });
  check(
    'mobile-nav-escape-closes-and-restores-toggle-focus',
    root.getAttribute('data-nav-open') === 'false' &&
      navToggle.getAttribute('aria-expanded') === 'false' &&
      env.focusCalls.length === focusBeforeEsc + 1 &&
      env.document.activeElement?.getAttribute('id') === 'wl-mobile-nav-toggle'
  );

  // Escape when already closed is a pure no-op (zero focus calls)
  const focusBeforeClosedEsc = env.focusCalls.length;
  env.dispatch(navToggle, 'keydown', { key: 'Escape', keyCode: 27, bubbles: true });
  check('mobile-nav-closed-escape-is-noop', env.focusCalls.length === focusBeforeClosedEsc);

  // Clicking a drawer link closes drawer without hijacking focus back to toggle button
  env.dispatch(navToggle, 'click');
  const focusBeforeLinkClick = env.focusCalls.length;
  env.dispatch(env.findFirst(navDrawer, (n) => n.tagName === 'A'), 'click');
  check(
    'mobile-nav-link-click-closes-without-focus-hijack',
    root.getAttribute('data-nav-open') === 'false' && env.focusCalls.length === focusBeforeLinkClick
  );

  // 6. Appearance, motion, and causality live-region controls
  const hcBtn = env.findFirst(env.body, (n) => n.tagName === 'BUTTON' && n.textContent.trim() === 'High contrast');
  const rmBtn = env.findFirst(env.body, (n) => n.tagName === 'BUTTON' && n.textContent.trim() === 'Reduced motion');
  const refusedBtn = env.findFirst(env.body, (n) => n.tagName === 'BUTTON' && n.textContent.trim() === 'Refused');
  env.dispatch(hcBtn, 'click');
  env.dispatch(rmBtn, 'click');
  env.dispatch(refusedBtn, 'click');
  const liveSpecimen = env.findFirst(env.body, (n) => n.getAttribute('aria-live') === 'polite');
  check(
    'appearance-motion-and-outcome-aria-pressed-controls',
    root.getAttribute('data-theme') === 'high-contrast' &&
      root.getAttribute('data-motion') === 'reduced' &&
      hcBtn.getAttribute('aria-pressed') === 'true' &&
      rmBtn.getAttribute('aria-pressed') === 'true' &&
      refusedBtn.getAttribute('aria-pressed') === 'true' &&
      Boolean(liveSpecimen)
  );

  // 7. Sensitivity / mutation self-test: verify validators refuse broken roving tabindex & stale copy
  const tabToMutate = env.document.getElementById('wl-tab-taskbar');
  const origTabIdx = tabToMutate.getAttribute('tabindex');
  tabToMutate.setAttribute('tabindex', '0'); // creates illegal 2-of-8 tabindex="0" alongside wl-tab-files
  const brokenRovingDetected = !validateWorkbenchRovingDom(env, 'wl-tab-files').ok;
  tabToMutate.setAttribute('tabindex', origTabIdx);
  const staleCopyDetected =
    !validateHonestCopyDom('15 / 242 requirements accepted and ELM-UI-007') &&
    !validateHonestCopyDom('run-omarchy-mvp installer');
  check('validator-sensitivity-catches-mutated-dom-and-stale-copy', brokenRovingDetected && staleCopyDetected);

  report.passed = report.failures.length === 0;
} catch (err) {
  report.error = String(err && err.stack ? err.stack : err);
  check('harness-completed-without-exception', false, report.error);
  report.passed = false;
} finally {
  saveReport();
  process.exitCode = report.passed ? 0 : 1;
}
