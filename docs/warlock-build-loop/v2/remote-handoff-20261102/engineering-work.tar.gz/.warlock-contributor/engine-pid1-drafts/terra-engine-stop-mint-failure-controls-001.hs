{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. The injected mint result is a defensive fault seam:
-- a valid StopBudget normally makes deadlineAfter return Right. This does not
-- simulate or prove an OS clock failure. The real requestSessionStop gate/path
-- performs the sticky transition; the seam only supplies the mint result.
-- Root must retain each Probe, input Handle and independent child guardian.
module StopMintFailureControls (Probe, newProbe, runFixtureFailure, runTicketFailure, runFixturePositive, runTicketPositive) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.IO (Handle, hClose, hIsClosed)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), SessionExit(..), StopReceipt(..),
  StopDeadlineObservation(..), newPersistentOwner, persistentStatus,
  persistentUnderlyingStatus, requestSessionStop, tryPersistentStopDeadline,
  startBudgetAfter, stopBudgetMicros)
import Warlock.Capture.Process.Persistent.Internal
 (persistentFixture, persistentTicketFixture, withPersistentOwnerHook,
  qaPersistentInputReferences, qaPersistentPendingIssues, qaRequestStopMintFailure)
import Warlock.Capture.Process.Transfer.Internal
 (TransferTicket, TransferDisposition(..), fixtureTicketWithClose, transferDisposition)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe Handle)) (IORef (Maybe TransferTicket))
 (IORef (Maybe ThreadId)) (MVar ()) (MVar ()) (MVar Result) (IORef Int) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newIORef 0 <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("stop mint failure: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label io = timeout 4000000 io >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure

runFixtureFailure, runTicketFailure, runFixturePositive, runTicketPositive :: Probe -> Handle -> IO ()
runFixtureFailure = run True True
runTicketFailure = run False True
runFixturePositive = run True False
runTicketPositive = run False False

run :: Bool -> Bool -> Probe -> Handle -> IO ()
run fixture inject (Probe owner handleCell ticketCell worker prepared resume done closeCalls reserves used) input = mask $ \restore -> do
 first <- atomicModifyIORef' used (\v -> (True,not v))
 check "single use" first
 writeIORef handleCell (Just input)
 let closeAction = atomicModifyIORef' closeCalls (\n -> (n+1,())) >> hClose input
     hook stage = case stage of
      "persistent-before-spawn-reserve" -> putMVar prepared () >> readMVar resume
      "persistent-after-spawn-reserve" -> atomicModifyIORef' reserves (\n -> (n+1,()))
      "qa-prespawn-input-close" | fixture -> atomicModifyIORef' closeCalls (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar resume ())
      tid <- readIORef worker
      case tid of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
     body = do
      ticket <- if fixture then pure Nothing else do
       t <- fixtureTicketWithClose input closeAction
       writeIORef ticketCell (Just t)
       pure (Just t)
      let selected = case ticket of
           Nothing -> persistentFixture "/warlock-qa-never-spawn" [] input
           Just t -> persistentTicketFixture "/warlock-qa-never-spawn" [] t
      start <- startBudgetAfter 4000000 >>= need
      stop <- need (stopBudgetMicros 2000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selected 4096 start stop
        (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar done)
       writeIORef worker (Just tid)
       pure tid
      within "actual prepared input before spawn reservation" (readMVar prepared)
      receipt <- if inject then qaRequestStopMintFailure owner stop else requestSessionStop owner stop
      firstStop <- tryPersistentStopDeadline owner
      if inject then do
       check "simulated mint error is sticky on actual owner gate" $
        receipt == StopUncertain BadArguments && firstStop == StopDeadlineFailed BadArguments
       duplicate <- requestSessionStop owner stop
       again <- tryPersistentStopDeadline owner
       check "real later request cannot mint another deadline" $
        duplicate == StopAlreadyRequested && again == StopDeadlineFailed BadArguments
      else check "actual stop positive is latched" $
       receipt == StopLatchedBeforeLive && case firstStop of StopDeadlineLatched _ -> True; _ -> False
      void (tryPutMVar resume ())
      result <- within "owner finished startup refusal" (readMVar done)
      closes <- readIORef closeCalls
      reservations <- readIORef reserves
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      refs <- qaPersistentInputReferences owner
      pending <- qaPersistentPendingIssues owner
      closed <- hIsClosed input
      disposition <- traverse transferDisposition ticket
      check "no spawn reservation" (reservations == 0)
      if inject then check "mint fault retains selected input and pending without close" $
       closes == 0 && not closed && refs == (if fixture then (1,0,False) else (0,1,True)) &&
       maybe False (const True) pending &&
       (case phase of PersistentQuarantined _ -> True; _ -> False) &&
       (case raw of Quarantined _ -> True; _ -> False) &&
       (case result of Right (Left (ExitUncertain _ _)) -> True; _ -> False) &&
       (if fixture then disposition == Nothing else disposition == Just CoreOwned)
      else check "actual valid stop positive closes selected input" $
       closes == 1 && closed && refs == (0,0,False) && phase == PersistentRetired && raw == Available &&
       (case result of Right (Left (StartupRefused SessionClosed)) -> True; _ -> False) &&
       (if fixture then disposition == Nothing else disposition == Just TransferClosed)
 restore body `finally` finish
