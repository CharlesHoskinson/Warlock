module SafeExactOrigin exposing (strict)

{-| UNEXECUTED SOURCE PROPOSAL: strict top-level JSON object keys without
Json.Decode.keyValuePairs (whose pinned kernel calls value.hasOwnProperty).

PRECONDITION: input is a finite, size-bounded, JSON-only value produced by
JSON.parse or an equivalently validated JSON source; arbitrary JS port objects,
functions, undefined, cyclic values and proxies are NOT qualified. Json.Encode
can omit or throw on such non-JSON values. Original transport bounds still apply.
Duplicate object keys already collapsed by JSON.parse cannot be recovered here;
retain Haskell's original strict duplicate-key checks at its own boundary.
Encoding plus String.toList allocates proportional to the complete encoded
subtree; repeated nested strict decoders can scan it repeatedly. Do not select
a new limit here: the integrating caller must prove its existing byte/depth
bound and measure worst-case latency and allocation on the actual GUI path.
In particular a JavaScript character count is not a UTF-8 byte count. This
proposal must not silently reject large otherwise-valid production messages.

This lexes *only the current object's* keys from Elm's JSON encoding. It neither
rejects nested keys generically nor changes child decoders or allowed fields.
Every strict consumer must independently use this helper where appropriate.
Root must compile, fuzz against an independent JSON parser, and review before use.
-}

import Json.Decode as Decode
import Json.Encode as Encode


strict : List String -> Decode.Decoder a -> Decode.Decoder a
strict allowed child =
    Decode.value
        |> Decode.andThen
            (\value ->
                case topKeys (String.toList (Encode.encode 0 value)) of
                    Ok keys ->
                        if List.sort keys == List.sort allowed then
                            child

                        else
                            Decode.fail "unexpected object fields"

                    Err reason ->
                        Decode.fail reason
            )


topKeys : List Char -> Result String (List String)
topKeys chars =
    case chars of
        '{' :: rest ->
            members rest []

        _ ->
            Err "object required"


members : List Char -> List String -> Result String (List String)
members chars reversed =
    case chars of
        '}' :: [] ->
            Ok (List.reverse reversed)

        '"' :: rest ->
            case quoted rest [ '"' ] of
                Err reason ->
                    Err reason

                Ok ( token, afterKey ) ->
                    case ( Decode.decodeString Decode.string token, afterKey ) of
                        ( Ok key, ':' :: afterColon ) ->
                            case skipValue afterColon [] False of
                                Err reason ->
                                    Err reason

                                Ok afterValue ->
                                    case afterValue of
                                        ',' :: next ->
                                            -- A comma must lead to another key, not '}'.
                                            case next of
                                                '"' :: _ ->
                                                    members next (key :: reversed)

                                                _ ->
                                                    Err "object member required"

                                        '}' :: [] ->
                                            Ok (List.reverse (key :: reversed))

                                        _ ->
                                            Err "object terminator required"

                        _ ->
                            Err "object key required"

        _ ->
            Err "object member required"


-- Input starts immediately after the opening quote; reversed includes it.
quoted : List Char -> List Char -> Result String ( String, List Char )
quoted chars reversed =
    case chars of
        [] ->
            Err "unterminated string"

        '\\' :: escaped :: rest ->
            quoted rest (escaped :: '\\' :: reversed)

        '"' :: rest ->
            Ok ( String.fromList (List.reverse ('"' :: reversed)), rest )

        char :: rest ->
            quoted rest (char :: reversed)


-- Values have already been encoded by Json.Encode and their text is not
-- needed. Avoid constructing a second copy just to skip a quoted value.
skipQuotedValue : List Char -> Result String (List Char)
skipQuotedValue chars =
    case chars of
        [] ->
            Err "unterminated string"

        '\\' :: _ :: rest ->
            skipQuotedValue rest

        '"' :: rest ->
            Ok rest

        _ :: rest ->
            skipQuotedValue rest


-- Input is already a JSON encoding. Track nested delimiters and skip quoted
-- strings intact; stop only on the current object's comma or closing brace.
skipValue : List Char -> List Char -> Bool -> Result String (List Char)
skipValue chars stack consumed =
    case chars of
        [] ->
            Err "unterminated object value"

        '"' :: rest ->
            case skipQuotedValue rest of
                Ok next ->
                    skipValue next stack True

                Err reason ->
                    Err reason

        '{' :: rest ->
            skipValue rest ('}' :: stack) True

        '[' :: rest ->
            skipValue rest (']' :: stack) True

        '}' :: rest ->
            case stack of
                '}' :: tail ->
                    skipValue rest tail True

                [] ->
                    if consumed then
                        Ok chars

                    else
                        Err "object value required"

                _ ->
                    Err "mismatched object delimiter"

        ']' :: rest ->
            case stack of
                ']' :: tail ->
                    skipValue rest tail True

                _ ->
                    Err "mismatched array delimiter"

        ',' :: rest ->
            if List.isEmpty stack then
                if consumed then
                    Ok chars

                else
                    Err "object value required"

            else
                skipValue rest stack True

        _ :: rest ->
            skipValue rest stack True
