{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY, SOURCE ONLY, UNEXECUTED. The host owns each Case, real verified
-- root/image inputs and a separate guardian, including any uncertain workers.
module QHttpPrivateRootScope035 (Case,newCase,runPrebound,runPositive,retainedWorkers) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,NestedScope,StartupAdmissionFailure(..),newPersistentOwner,newPersistentRootCustody,
  startBudgetFromDeadline,withPersistentBoundNestedStartup,runPersistentBoundImage)
import Warlock.Platform.Executable.Internal (LeaseRole(..))
import Warlock.Platform.Resolver.Internal (RootCustody,RootAdmissionFailure(..),Identity,Pin,Link)

data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef (Maybe NestedScope)) (IORef Bool) (IORef [ThreadId])
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing <*> newIORef False <*> newIORef []
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ _ _ xs) = readIORef xs
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("private-root: " ++ label)))
wait :: AdmissionDeadline -> String -> MVar a -> IO a
wait d label done = do
 left <- remainingMicros d
 if left<=0 then ioError (userError (label ++ ": Unknown; retain guardian")) else do
  result <- timeout left (readMVar done)
  maybe (ioError (userError (label ++ ": Unknown; retain guardian"))) pure result
launch :: IORef [ThreadId] -> IO a -> IO (MVar (Either SomeException a))
launch workers action = mask $ \_ -> do
 start <- newEmptyMVar
 done <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (readMVar start >> action))
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of
    Just _ -> throwIO ex
    Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar start ()
 pure done
claim :: IORef Bool -> IO ()
claim used = atomicModifyIORef' used (\old -> (True,not old)) >>= check "single case"

-- A real previously bound root must not be silently adopted by the secured
-- route. The actual prebound RootCustody stays retained in Case on every exit.
runPrebound :: Case -> AdmissionDeadline -> IO ()
runPrebound (Case owner root _ used workers) originalD = do
 claim used
 ran <- launch workers $ do
  bound <- newPersistentRootCustody owner
  actual <- either (ioError . userError . show) pure bound
  writeIORef root (Just actual)
  entered <- newIORef False
  result <- withPersistentBoundNestedStartup owner (startBudgetFromDeadline originalD) $ \_ _ _ -> do
   writeIORef entered True
   pure (Right ())
  called <- readIORef entered
  check "real existing root refuses before nested body" (result==Left (StartupAdmissionRefused OwnerBusy) && not called)
 wait originalD "prebound owner" ran >>= either throwIO pure

-- Host provides the real pinned/validated root, image bytes/digest and path.
-- A genuine private owner scope runs the full real route. A foreign thread
-- presents the opaque scope while live and must be refused. The SAME scope
-- thread tries again after lexical return and must also be refused. Neither
-- denial issues a grant or accesses a raw Root/FD. This fixture intentionally
-- retains the opaque stale scope only to demonstrate its revocation.
runPositive :: Case -> AdmissionDeadline -> B.ByteString -> Identity -> [Pin] -> B.ByteString -> [Link] -> Integer -> B.ByteString -> IO ()
runPositive (Case owner _ scopeCell used workers) originalD rootPath rootId pins path links size digest = do
 claim used
 ran <- launch workers $ do
  result <- withPersistentBoundNestedStartup owner (startBudgetFromDeadline originalD) $ \_ _ scope -> do
   writeIORef scopeCell (Just scope)
   other <- launch workers $ runPersistentBoundImage scope rootPath rootId pins path links size digest UiImage
   foreignResult <- wait originalD "foreign actual worker" other >>= either throwIO pure
   check "foreign thread refused before scope authority" (case foreignResult of Left RootAdmissionRefused -> True; _ -> False)
   actual <- runPersistentBoundImage scope rootPath rootId pins path links size digest UiImage
   check "same scope real preparation succeeds without issuer" (case actual of Right (Right _) -> True; _ -> False)
   pure (Right ())
  check "actual same-owner lexical scope returned" (result==Right ())
  stale <- readIORef scopeCell >>= maybe (ioError (userError "scope not retained for revocation check")) pure
  staleResult <- runPersistentBoundImage stale rootPath rootId pins path links size digest UiImage
  check "same original thread cannot reuse expired scope" (case staleResult of Left RootAdmissionRefused -> True; _ -> False)
 wait originalD "actual private-root route" ran >>= either throwIO pure
-- All product actions run in prepublished owner/foreign workers; timeouts
-- observe only MVars and never cancel actions or release retained resources.
-- A successful preparation is not an executable/native grant or cleanup.
