{-# LANGUAGE OverloadedStrings #-}
-- SOURCE ONLY, NOT RUN. One actual Backend owner per guardian-owned process.
-- The QA hook parks only after the real aggregate Fresh -> PreliveChecking CAS.
module QHttpBootstrapBusy002 (Case,newCase,runCase,retainedWorkers,retainedResults) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,newPersistentBackendOwner,requestPersistentBackendStop,
 retirePersistentBackend,qaBackendStopDeadline,qaLaunchSnapshot,qaBootstrapReadiness)
import Warlock.Bootstrap (newCurrentSessions,PersistentBootstrapReadiness(..),qaBootstrapPreliveHook)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

type Outcome a = Either SomeException a
data Case = Case PersistentBackendOwner (IORef Bool) (IORef [ThreadId])
 (MVar (Outcome P.StopReceipt)) (MVar (Outcome Bool)) (MVar (Outcome Bool)) (MVar ()) (MVar ())
newCase :: P.StopBudget -> IO Case
newCase budget = do
 sessions <- newCurrentSessions
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newIORef False <*> newIORef [] <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ workers _ _ _ _ _) = readIORef workers
retainedResults :: Case -> IO (Maybe (Outcome P.StopReceipt),Maybe (Outcome Bool),Maybe (Outcome Bool))
retainedResults (Case _ _ _ stop first second _ _) = (,,) <$> tryReadMVar stop <*> tryReadMVar first <*> tryReadMVar second
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("bootstrap busy: " ++ label)))
start :: IORef [ThreadId] -> MVar (Outcome a) -> [AdmissionDeadline] -> IO a -> IO ()
start workers done bounds action = mask $ \_ -> do
 gate <- newEmptyMVar
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar gate
   left <- minimum <$> mapM remainingMicros bounds
   check "same deadlines live before action entry" (left>0)
   action
  putMVar done result
  case result of
   Left ex -> case fromException ex :: Maybe SomeAsyncException of Just _ -> throwIO ex; Nothing -> pure ()
   Right _ -> pure ()
 atomicModifyIORef' workers (\xs -> (tid:xs,()))
 putMVar gate ()
await :: [AdmissionDeadline] -> String -> MVar (Outcome a) -> IO a
await ds label done = do
 left <- minimum <$> mapM remainingMicros ds
 check (label ++ ": existing D live") (left>0)
 result <- timeout left (readMVar done)
 case result of
  Nothing -> ioError (userError (label ++ ": Unknown; retain Case, workers and guardian"))
  Just value -> do
   after <- minimum <$> mapM remainingMicros ds
   check (label ++ ": receipt before same D") (after>0)
   either throwIO pure value
waitSignal :: [AdmissionDeadline] -> String -> MVar () -> IO ()
waitSignal ds label signal = do
 left <- minimum <$> mapM remainingMicros ds
 check (label ++ ": existing D live") (left>0)
 value <- timeout left (readMVar signal)
 case value of Nothing -> ioError (userError (label ++ ": Unknown; retain Case and guardian")); Just () -> pure ()

-- No synthetic backend state, deadline, stop or continuation. Host provides
-- the preexisting original D and a real StopBudget; a fresh isolated owner has
-- no config and no spawned child. The first stop must latch on that same owner.
runCase :: Case -> AdmissionDeadline -> IO ()
runCase (Case owner used workers stopped first second entered release) originalD = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single owner and isolated process" fresh
 before <- qaBackendStopDeadline owner
 check "no preexisting stop" (before==P.StopDeadlineNotLatched)
 qaBootstrapPreliveHook (putMVar entered () >> readMVar release)
 start workers stopped [originalD] (requestPersistentBackendStop owner)
 stopReceipt <- restore $ await [originalD] "actual prelive stop" stopped
 check "first stop latched before live" (stopReceipt==P.StopLatchedBeforeLive)
 selected <- qaBackendStopDeadline owner
 stopD <- case selected of P.StopDeadlineLatched d -> pure d; _ -> ioError (userError "first StopD unavailable")
 let bounds = [originalD,stopD]
 start workers first bounds (retirePersistentBackend owner)
 restore $ waitSignal bounds "first real retirement owns PreliveChecking" entered
 phase <- qaLaunchSnapshot owner
 readiness <- qaBootstrapReadiness owner
 firstPending <- tryReadMVar first
 check "same owner sealed, actual aggregate checking, first still in flight" $
  phase=="sealed" && readiness==BootstrapNotReady && case firstPending of Nothing -> True; _ -> False
 -- A second real Backend retirement must finish False while first is parked;
 -- there is no recursive retry, borrowed receipt or forced phase transition.
 start workers second bounds (retirePersistentBackend owner)
 secondResult <- restore $ await bounds "concurrent retirement" second
 stillPending <- tryReadMVar first
 check "busy concurrent retirement refuses without waiting for first" $
  not secondResult && case stillPending of Nothing -> True; _ -> False
 beforeRelease <- minimum <$> mapM remainingMicros bounds
 check "existing D live before releasing first retirement" (beforeRelease>0)
 putMVar release ()
 firstResult <- restore $ await bounds "first actual retirement after release" first
 check "real prelive positive completes under same first StopD" firstResult
 after <- qaBackendStopDeadline owner
 check "first StopD was not replaced" (after==selected)
-- Positive is scoped owner-level retirement, not GUI/provider/native cleanup.
