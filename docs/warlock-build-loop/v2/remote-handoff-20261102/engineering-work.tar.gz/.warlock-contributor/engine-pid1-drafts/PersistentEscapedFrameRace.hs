{-# LANGUAGE ScopedTypeVariables #-}
-- Unexecuted QA-only fixture for gemini-omarchy persistent custody v3.
-- The harness supplies an owned fixture child, its arguments and a real ready
-- verifier. This invokes the proposed production owner/session/frame API;
-- it does not itself establish native containment, provider cleanup or GUI.
-- Tests must run only in Root's isolated, protected serial process profile.
module PersistentEscapedFrameRace (runEscapedFrameRace) where

import Control.Concurrent (forkFinally, isEmptyMVar, newEmptyMVar, putMVar, readMVar, takeMVar, tryPutMVar)
import Control.Exception (IOException, catch, finally)
import Control.Monad (unless, void)
import Data.IORef (newIORef, readIORef, writeIORef)
import System.IO (IOMode(ReadMode), hClose, openFile)
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (SessionObservation, ToolError(..), deadlineAfter)
import Warlock.Capture.Process.Persistent
  ( LiveOperationFailure(..)
  , SessionExit(..), StopReceipt(..), enterLiveFrameAction, newPersistentOwner
  , requestSessionStop, startBudgetAfter, stopBudgetMicros, withLiveFrameAdmission )
import Warlock.Capture.Process.Persistent.Internal (persistentFixture, withPersistentOwnerHook)

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("PersistentEscapedFrameRace: " ++ label)))

-- Fixture process must remain live after the verifier, until owner stop. The
-- supplied verifier is the existing source-bound child readiness check, not a
-- fabricated live-session grant. Each wait is bounded; no deadline is renewed.
runEscapedFrameRace :: FilePath -> [String]
  -> (SessionObservation -> IO (Either ToolError ())) -> IO ()
runEscapedFrameRace childExe childArgs verifyReady = do
  owner <- newPersistentOwner
  input <- openFile "/dev/null" ReadMode
  start <- startBudgetAfter 2000000 >>= either (ioError . userError . show) pure
  stopBudget <- either (ioError . userError . show) pure (stopBudgetMicros 2000000)
  actionStarted <- newEmptyMVar
  actionBodyFinished <- newEmptyMVar
  actionRelease <- newEmptyMVar
  bodyRelease <- newEmptyMVar
  frameReturned <- newEmptyMVar
  drainReached <- newEmptyMVar
  beforeReap <- newEmptyMVar
  actionDone <- newEmptyMVar
  ownerDone <- newEmptyMVar
  escapedEntered <- newIORef False
  earlyDrainObserved <- newIORef False
  -- This marker is just before the callback returns; the stronger no-reap
  -- interval is the time the callback is deliberately blocked on actionRelease.
  let hook name = case name of
        "persistent-callback-drain" -> void (tryPutMVar drainReached ())
        "persistent-after-operation-drain-before-reap" -> do
          active <- isEmptyMVar actionBodyFinished
          if active then writeIORef earlyDrainObserved True else pure ()
          void (tryPutMVar beforeReap ())
        _ -> pure ()
      liveBody session = do
        -- Mint the independent frame and action budgets only after verified
        -- session readiness; neither budget is renewed while this test runs.
        frameDeadline <- deadlineAfter 5000000 >>= either (ioError . userError . show) pure
        actionDeadline <- deadlineAfter 1500000 >>= either (ioError . userError . show) pure
        result <- withLiveFrameAdmission session $ \admission -> do
          void $ forkFinally
            (enterLiveFrameAction admission frameDeadline actionDeadline $ do
              putMVar actionStarted ()
              takeMVar actionRelease
              putMVar actionBodyFinished ()
              pure (Right ()))
            (putMVar actionDone)
          -- The parent cannot leave its frame until the nested action actually
          -- enters. Once it returns, the action deliberately stays blocked.
          takeMVar actionStarted
          pure admission
        putMVar frameReturned (result,frameDeadline,actionDeadline)
        takeMVar bodyRelease
      cleanup = do
        void (tryPutMVar actionRelease ())
        void (tryPutMVar bodyRelease ())
        void (requestSessionStop owner stopBudget `catch` \(_ :: IOException) -> pure StopNoLiveSession)
        void (timeout 2500000 (readMVar ownerDone))
        hClose input `catch` \(_ :: IOException) -> pure ()
  void $ forkFinally
    (withPersistentOwnerHook owner (persistentFixture childExe childArgs input)
      4096 start stopBudget verifyReady liveBody hook)
    (putMVar ownerDone)
  let body = do
        observed <- timeout 1000000 (takeMVar frameReturned)
        (admission,frameDeadline,actionDeadline) <- case observed of
          Just (Right value,frameDl,actionDl) -> pure (value,frameDl,actionDl)
          _ -> ioError (userError "frame did not enter and return within fixture bound")
        -- The escaped token must fail without running another callback even
        -- before stop; this must not be confused with the in-flight callback.
        stale <- enterLiveFrameAction admission frameDeadline actionDeadline $ do
          writeIORef escapedEntered True
          pure (Right ())
        ranEscaped <- readIORef escapedEntered
        check "escaped-frame-token-refused-before-dispatch"
          (stale == Left (OperationRefusedPreDispatch SessionClosed) && not ranEscaped)
        receipt <- timeout 500000 (requestSessionStop owner stopBudget)
        check "owned-stop-latched" (case receipt of
          Just StopSignalSent -> True
          _ -> False)
        putMVar bodyRelease ()
        reached <- timeout 500000 (readMVar drainReached)
        check "finalizer-reached-callback-gate" (reached == Just ())
        -- If the outer scope's pin was released while the entered nested action
        -- is still blocked, the after-drain hook exposes the premature reap.
        early <- timeout 150000 (readMVar beforeReap)
        check "entered-action-prevents-reap-before-exit" (early == Nothing)
        putMVar actionRelease ()
        doneAction <- timeout 500000 (takeMVar actionDone)
        check "stopped-entered-action-is-unknown" (case doneAction of
          Just (Right (Left (OperationOutcomeUnknown SessionClosed))) -> True
          _ -> False)
        ownerResult <- timeout 1500000 (readMVar ownerDone)
        raced <- readIORef earlyDrainObserved
        check "drain-hook-never-overtakes-action-body" (not raced)
        check "owned-leader-finally-reaped-after-action-exit" (case ownerResult of
          Just (Right (Right ((), LeaderReaped _))) -> True
          _ -> False)
  body `finally` cleanup
