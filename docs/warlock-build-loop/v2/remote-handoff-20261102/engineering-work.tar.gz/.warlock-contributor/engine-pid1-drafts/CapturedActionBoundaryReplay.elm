port module CapturedActionBoundaryReplay exposing (main)

{-| Source-only QA draft. This exercises the production CapturedAction decoder,
encoder, typed Surface/Trigger accessors, Presentation dispatch, and
Surface.resolve using a synthetic Elm fixture. It requires the separately
reviewed Tea001CapturedActionAdt.patch SHA256
2e6a48ec7fa576fec647aa9ea27e25f219ddc095dd01418219e6e90dc0bd157f.
Do not compile it against the pre-ADT source. It does not authenticate a renderer or assert a native origin. The
CapturedAction constructor stays opaque. Root must place this file under the
QA source directory and run the protected Elm checks against the final source.
-}

import CapturedAction
import Desktop
import Json.Decode as D
import Json.Encode as E
import NativePointerFixture
import Platform
import Presentation
import Surface
import TaskbarShell
import UInt64

port outgoing : E.Value -> Cmd msg

counter value =
    D.decodeValue UInt64.decoder (E.string value) |> Result.withDefault UInt64.zero

bound =
    E.object [("lifetime",E.string "1"),("session",E.string "1"),("frontend",E.string "1")]

native wire model =
    NativePointerFixture.incoming wire model |> Tuple.first

attached =
    E.object [("protocolVersion",E.int 3),("kind",E.string "attached"),("binding",bound)]

window identity =
    E.object [("incarnation",E.string identity),("label",E.string ("Document "++identity)),
        ("owner",E.null),("application",E.string "documents"),("minimized",E.bool False),("available",E.bool True)]

projection =
    E.object [("protocolVersion",E.int 3),("kind",E.string "action-projection"),("binding",bound),
        ("requestId",E.string "1"),("context",E.object [("lifetime",E.string "1"),("epoch",E.string "1"),
            ("output",E.string "1"),("revision",E.string "1")]),
        ("scene",E.object [("revision",E.string "1"),("focused",E.string "1"),
            ("windows",E.list identity [window "1",window "2"])])]

ready =
    Desktop.initial |> native attached |> native projection

groupId =
    "bar:group:" ++ (TaskbarShell.groups ready.windows |> List.head |> Maybe.map .key |> Maybe.withDefault "missing")

-- Independently literal expected encoding follows CapturedAction.encode field
-- order. Trigger is included only when actually supplied.
action surface publication lease identity trigger extra =
    E.object ([("surface",E.string surface),("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),
        ("publication",E.string publication),("lease",E.string lease),("id",E.string identity)]
        ++ (trigger |> Maybe.map (\value -> [("trigger",value)]) |> Maybe.withDefault []) ++ extra)

valid surface trigger =
    action surface "17" "9" (if surface=="bar" then "bar:settings" else "control:close") trigger []

openWith trigger =
    let input = action "bar" "1" "0" groupId trigger []
    in Surface.resolve (counter "1") UInt64.zero input ready
        |> Maybe.map (\message -> Desktop.update message ready |> Tuple.first)
        |> Maybe.withDefault ready

openPicker =
    openWith (Just (E.string "keyboard"))

frame =
    Surface.packet (counter "17") (counter "9") openPicker

presentation =
    Presentation.accept frame Presentation.initial

rejected raw =
    case CapturedAction.decode raw of
        Err _ -> True
        Ok _ -> False

exactRoundTrip raw expected =
    CapturedAction.decode raw
        |> Result.map (CapturedAction.encode >> E.encode 0 >> (==) (E.encode 0 expected))
        |> Result.withDefault False

exactRoundTripText raw expected =
    CapturedAction.decode raw
        |> Result.map (CapturedAction.encode >> E.encode 0 >> (==) expected)
        |> Result.withDefault False

typedScope raw expectedSurface expectedTrigger =
    CapturedAction.decode raw
        |> Result.map (\value -> CapturedAction.surface value==expectedSurface && CapturedAction.trigger value==expectedTrigger)
        |> Result.withDefault False

exactDispatchText popup raw expected =
    Presentation.dispatch popup raw presentation
        |> Maybe.map (E.encode 0 >> (==) expected)
        |> Maybe.withDefault False

refusesDispatch popup raw =
    Presentation.dispatch popup raw presentation == Nothing

actualSurfaceResolves raw =
    Surface.resolve (counter "17") (counter "9") raw openPicker /= Nothing

result =
    let
        absent = Nothing
        pointer = Just (E.string "pointer")
        keyboard = Just (E.string "keyboard")
        barP = valid "bar" pointer
        barK = valid "bar" keyboard
        barNone = valid "bar" absent
        popP = valid "popup" pointer
        popK = valid "popup" keyboard
        popNone = valid "popup" absent
        -- Literal wire strings are independently stated, including exact
        -- field order and omission/presence of the optional trigger.
        barWire = "{\"surface\":\"bar\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\"17\",\"lease\":\"9\",\"id\":\"bar:settings\""
        popupWire = "{\"surface\":\"popup\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\"17\",\"lease\":\"9\",\"id\":\"control:close\""
        pointerSuffix = ",\"trigger\":\"pointer\"}"
        keyboardSuffix = ",\"trigger\":\"keyboard\"}"
        malformed trigger = action "bar" "17" "9" "bar:settings" trigger []
        malformedPopup trigger = action "popup" "17" "9" "control:close" trigger []
        zeroPub = action "bar" "0" "9" "bar:settings" absent []
        zeroLease = action "popup" "17" "0" "control:close" absent []
        zeroBar = action "bar" "17" "0" "bar:settings" absent []
        zeroBarFrame = Presentation.accept (Surface.packet (counter "17") UInt64.zero ready) Presentation.initial
        zeroBarWire = "{\"surface\":\"bar\",\"surfaceProtocol\":2,\"kind\":\"surface-action\",\"publication\":\"17\",\"lease\":\"0\",\"id\":\"bar:settings\"}"
        zeroBarDispatch = Presentation.dispatch False zeroBar zeroBarFrame
            |> Maybe.map (E.encode 0 >> (==) zeroBarWire)
            |> Maybe.withDefault False
        overflowPub = action "bar" "18446744073709551616" "9" "bar:settings" absent []
        overflowLease = action "popup" "17" "18446744073709551616" "control:close" absent []
        maxWidth = action "bar" "18446744073709551615" "18446744073709551615" "x" absent []
        extra = action "bar" "17" "9" "bar:settings" absent [("extra",E.bool True)]
        badSurface = action "native" "17" "9" "bar:settings" absent []
        emptyId = action "bar" "17" "9" "" absent []
        zeroTextId = action "bar" "17" "9" "0" absent []
        emptyPublication = action "bar" "" "9" "bar:settings" absent []
        paddedPublication = action "bar" "017" "9" "bar:settings" absent []
        numericId = E.object [("surface",E.string "bar"),("surfaceProtocol",E.int 2),("kind",E.string "surface-action"),("publication",E.string "17"),("lease",E.string "9"),("id",E.int 0)]
        oversizedId = action "bar" "17" "9" (String.repeat 513 "x") absent []
        id512 = action "bar" "17" "9" (String.repeat 512 "x") absent []
        controlId = action "bar" "17" "9" ("x"++String.fromChar (Char.fromCode 31)) absent []
        delId = action "bar" "17" "9" ("x"++String.fromChar (Char.fromCode 127)) absent []
        checks =
            [ ("fixtureOpensRealPicker",openPicker.windows.picker/=Nothing)
            , ("currentFrameAccepted",Presentation.current presentation/=Nothing)
            , ("pointerEntryOriginPreserved",(openWith pointer).popupOrigin==Desktop.PointerEntry)
            , ("keyboardEntryOriginPreserved",(openWith keyboard).popupOrigin==Desktop.KeyboardEntry)
            , ("absentEntryDefaultsKeyboard",(openWith absent).popupOrigin==Desktop.KeyboardEntry)
            , ("typedBarPointer",typedScope barP CapturedAction.Bar (Just CapturedAction.Pointer))
            , ("typedBarKeyboard",typedScope barK CapturedAction.Bar (Just CapturedAction.Keyboard))
            , ("typedBarAbsent",typedScope barNone CapturedAction.Bar Nothing)
            , ("typedPopupPointer",typedScope popP CapturedAction.Popup (Just CapturedAction.Pointer))
            , ("typedPopupKeyboard",typedScope popK CapturedAction.Popup (Just CapturedAction.Keyboard))
            , ("typedPopupAbsent",typedScope popNone CapturedAction.Popup Nothing)
            , ("barPointerExactWire",exactRoundTripText barP (barWire++pointerSuffix) && exactDispatchText False barP (barWire++pointerSuffix) && actualSurfaceResolves barP)
            , ("barKeyboardExactWire",exactRoundTripText barK (barWire++keyboardSuffix) && exactDispatchText False barK (barWire++keyboardSuffix) && actualSurfaceResolves barK)
            , ("barAbsentTriggerExactWire",exactRoundTripText barNone (barWire++"}") && exactDispatchText False barNone (barWire++"}") && actualSurfaceResolves barNone)
            , ("popupPointerExactWire",exactRoundTripText popP (popupWire++pointerSuffix) && exactDispatchText True popP (popupWire++pointerSuffix) && actualSurfaceResolves popP)
            , ("popupKeyboardExactWire",exactRoundTripText popK (popupWire++keyboardSuffix) && exactDispatchText True popK (popupWire++keyboardSuffix) && actualSurfaceResolves popK)
            , ("popupAbsentTriggerExactWire",exactRoundTripText popNone (popupWire++"}") && exactDispatchText True popNone (popupWire++"}") && actualSurfaceResolves popNone)
            , ("presentNullTriggerRefused",rejected (malformed (Just E.null)))
            , ("unknownTriggerRefused",rejected (malformed (Just (E.string "touch"))))
            , ("emptyTriggerRefused",rejected (malformed (Just (E.string ""))))
            , ("nonStringTriggerRefused",rejected (malformed (Just (E.int 1))))
            , ("popupPresentNullTriggerRefused",rejected (malformedPopup (Just E.null)))
            , ("popupUnknownTriggerRefused",rejected (malformedPopup (Just (E.string "touch"))))
            , ("popupEmptyTriggerRefused",rejected (malformedPopup (Just (E.string ""))))
            , ("popupNonStringTriggerRefused",rejected (malformedPopup (Just (E.int 1))))
            , ("foreignSurfaceRefused",rejected badSurface)
            , ("extraFieldRefused",rejected extra)
            , ("emptyIdentityRefused",rejected emptyId)
            , ("zeroTextIdentityAcceptedButNotCurrentControl",exactRoundTrip zeroTextId zeroTextId && refusesDispatch False zeroTextId)
            , ("numericIdentityRefused",rejected numericId)
            , ("emptyPublicationRefused",rejected emptyPublication)
            , ("paddedPublicationRefused",rejected paddedPublication)
            , ("oversizedIdentityRefused",rejected oversizedId)
            , ("boundary512IdentityAccepted",exactRoundTrip id512 id512)
            , ("controlCharacterIdentityRefused",rejected controlId)
            , ("deleteCharacterDecodePreserved",exactRoundTrip delId delId)
            , ("zeroPublicationRefused",rejected zeroPub)
            , ("zeroLeaseDecodedButNotCurrent",exactRoundTrip zeroLease zeroLease && refusesDispatch True zeroLease)
            , ("currentBarZeroLeaseExactWire",typedScope zeroBar CapturedAction.Bar Nothing && exactRoundTripText zeroBar zeroBarWire && zeroBarDispatch && Surface.resolve (counter "17") UInt64.zero zeroBar ready/=Nothing)
            , ("publicationOverflowRefused",rejected overflowPub)
            , ("leaseOverflowRefused",rejected overflowLease)
            , ("fullWidthCountersPreserved",exactRoundTrip maxWidth maxWidth)
            , ("stalePublicationNotDispatched",refusesDispatch False (action "bar" "16" "9" "bar:settings" absent []))
            , ("futurePublicationNotDispatched",refusesDispatch False (action "bar" "18" "9" "bar:settings" absent []))
            , ("oldLeaseNotDispatched",refusesDispatch True (action "popup" "17" "8" "control:close" absent []))
            , ("futureLeaseNotDispatched",refusesDispatch True (action "popup" "17" "10" "control:close" absent []))
            , ("popupAsBarNotDispatched",refusesDispatch False popP)
            , ("barAsPopupNotDispatched",refusesDispatch True barP)
            , ("unknownIdentityNotDispatched",refusesDispatch False (action "bar" "17" "9" "bar:not-a-control" absent []))
            ]
    in E.object [("scope",E.string "Elm CapturedAction and current-frame dispatch; synthetic fixture"),
        ("checks",E.object (List.map (Tuple.mapSecond E.bool) checks))]

main : Program () () Never
main =
    Platform.worker { init = \_ -> ((),outgoing result), update = \message model -> never message, subscriptions = \_ -> Sub.none }
