-- QA-ONLY same-module fragment, appended/exported only in isolated Backend
-- candidate 014 test build. Read-only: never exposes config or StoreOwner.
qaPersistentConfigState :: PersistentBackendOwner -> IO (Bool,Bool,Bool,Bool)
qaPersistentConfigState (PersistentBackendOwner _ _ _ _ _ _ _ _ _ _ used store installed confirmed) = do
  seen <- readIORef used
  owner <- readIORef store
  value <- readIORef installed
  receipt <- readIORef confirmed
  let present x = case x of Nothing -> False; Just _ -> True
  pure (seen,present owner,present value,receipt)
