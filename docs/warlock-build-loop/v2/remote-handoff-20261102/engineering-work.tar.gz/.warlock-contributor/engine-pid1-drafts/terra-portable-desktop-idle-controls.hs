{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
-- PREPARATION DRAFT ONLY. No compile/test has been run. This exercises the
-- proposed public after-idle ingress API on real Unix sockets and actual kernel
-- SCM credentials with a same-process PID/UID/GID guard. It does not prove a
-- real selected child, held-pidfd guard, production bootstrap, native effect,
-- VM, GUI, original scenario or release. Run only through root's protected QA.
-- API dependency: receiveDesktopCredentialIngressAfterIdle in current root source
-- (original absolute monotonic D first; root requalification required). Tests intentionally detect a partial frame crossing D.
module Main (main) where

import Control.Concurrent (forkIO, forkFinally, killThread, newEmptyMVar, putMVar, takeMVar, threadDelay, tryPutMVar)
import Control.Exception (SomeException, bracket, finally, onException)
import Control.Monad (unless, void)
import Data.IORef (IORef, modifyIORef', newIORef, readIORef, writeIORef)
import qualified Data.ByteString as B
import GHC.Clock (getMonotonicTimeNSec)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Posix.Process (getProcessID)
import System.Posix.User (getEffectiveGroupID, getEffectiveUserID)
import System.Timeout (timeout)
import Warlock.Protocol.CredentialIngress
import Warlock.Protocol.Ingress (ingressBinding, Direction(..), OfferResult(..), ActivationResult(..), ChannelError(..))
import qualified Warlock.Protocol.PeerCredential as P
import qualified Warlock.Protocol.Framing as F

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError name))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure
now :: IO Integer
now = toInteger <$> getMonotonicTimeNSec

data Refusal = Foreign | Revoked deriving (Eq, Show)
data Fixture = Fixture CredentialIngress S.Socket (IORef Int) (IORef Int) (IORef Bool) (CredentialGuard Refusal) Int

-- The real recvmsg credential must match this process and the synchronous
-- guard checks it again at final dispatch. This deliberately does NOT pretend
-- to authenticate a selected child or establish a pidfd-backed custody scope.
fixtureGuard :: Integer -> Integer -> Integer -> IORef Int -> IORef Bool -> CredentialGuard Refusal
fixtureGuard pid uid gid seen revoked = CredentialGuard fragment admit
 where
  matches c = P.credentialPid c == pid && P.credentialUid c == uid && P.credentialGid c == gid
  fragment c = do
   modifyIORef' seen (+1)
   stopped <- readIORef revoked
   pure (if stopped then Left Revoked else if matches c then Right () else Left Foreign)
  admit c action = do
   stopped <- readIORef revoked
   if stopped then pure (Left Revoked) else if not (matches c) then pure (Left Foreign) else Right <$> action

withFixture :: Bool -> (Fixture -> IO ()) -> IO ()
withFixture desktop action = do
 owner <- must (ingressBinding "1" "2" "3")
 pid <- toInteger <$> getProcessID
 uid <- toInteger <$> getEffectiveUserID
 gid <- toInteger <$> getEffectiveGroupID
 calls <- newIORef 0
 observed <- newIORef 0
 revoked <- newIORef False
 let callback _ = modifyIORef' calls (+1)
 ingress <- (if desktop then newDesktopCredentialIngress else newCredentialIngress) owner FromElm callback callback
 (incoming,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
 originalFd <- S.withFdSocket incoming (pure . fromIntegral)
 let closeBoth = void (retireCredentialIngress ingress) >> S.close peer
 offered <- transferCredentialSocket ingress incoming `onException` S.close peer
 check "socket offered" (offered == OfferAccepted)
 active <- activateCredentialIngress ingress `onException` closeBoth
 check "socket active" (active == ActivationLive)
 action (Fixture ingress peer calls observed revoked (fixtureGuard pid uid gid observed revoked) originalFd) `finally` closeBoth

-- One independent well-formed whole desktop commit, valid through the actual
-- desktop checked codec and matching the fixture's immutable binding.
desktopFrame :: B.ByteString -> IO B.ByteString
desktopFrame requestId = must $ F.desktopCommitPrefix $
 "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"controlled QA transport projection\",\"bar\":[{\"id\":\"qa:focus-valid\",\"domId\":\"focus-valid\",\"label\":\"QA control\",\"ariaLabel\":\"QA control\",\"detail\":\"\",\"enabled\":true,\"focusOnly\":false}],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":[{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"" <> requestId <> "\"}],\"focus\":[]}"

nativeFrame :: IO B.ByteString
nativeFrame = must $ F.prefix
 "{\"version\":1,\"kind\":\"negotiate\",\"body\":{\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"8\"}}"

seedFirst :: Fixture -> Integer -> B.ByteString -> IO ()
seedFirst (Fixture ingress peer calls _ _ guard _) originalD frame = do
 before <- now
 check "original D live before first frame" (before < originalD)
 N.sendAll peer frame
 let leftMicros = fromInteger (min 5000000 ((originalD-before) `div` 1000))
 first <- bounded "first frame under original D" leftMicros (receiveCredentialIngress ingress guard)
 after <- now
 count <- readIORef calls
 check "first real credential frame delivered under same D" (first == CredentialDelivered && count == 1 && after < originalD)

-- One immutable absolute monotonic D per fresh independent test fixture.
-- Deadlines here are test inputs, never replacements for a production D.
deadlineAfterSeconds :: Integer -> IO Integer
deadlineAfterSeconds secs = (+ (secs * 1000000000)) <$> now

-- Internal watchdog only fails a stuck control; it is never used as the
-- product deadline and no uncertain outcome is retried or treated as pass.
bounded :: String -> Int -> IO a -> IO a
bounded label micros action = do
 result <- timeout micros action
 maybe (ioError (userError (label ++ " watchdog"))) pure result

withSender :: IO () -> IO a -> IO a
withSender send action = bracket (forkIO send) killThread (const action)

readExactly :: S.Socket -> Int -> IO B.ByteString
readExactly socket count = loop count [] where
 loop 0 chunks = pure (B.concat (reverse chunks))
 loop remaining chunks = do
  bytes <- N.recv socket remaining
  if B.null bytes then pure (B.concat (reverse chunks))
   else loop (remaining - B.length bytes) (bytes:chunks)

expectTimeout :: String -> Fixture -> Integer -> IO ()
expectTimeout label (Fixture ingress _ calls _ _ guard _) absoluteD = do
 result <- bounded label 9000000 (receiveDesktopCredentialIngressAfterIdle absoluteD ingress guard)
 count <- readIORef calls
 check (label ++ " times out with no further callback")
  (result == CredentialFrameRejected (CredentialTransport TimedOut) && count == 1)

main :: IO ()
main = do
 desktopFirst <- desktopFrame "7"
 desktopSecond <- desktopFrame "8"
 native <- nativeFrame
 -- First desktop receive is unchanged: no frame at all must time out on the
 -- original five-second transport path. Its fixture D was created first.
 withFixture True $ \(Fixture ingress _ calls _ _ guard _) -> do
  originalD <- deadlineAfterSeconds 12
  started <- now
  result <- bounded "first frame timeout" 8500000 (receiveCredentialIngress ingress guard)
  finished <- now
  count <- readIORef calls
  check "first frame unchanged timeout" (result == CredentialFrameRejected (CredentialTransport TimedOut) && count == 0 && finished < originalD && finished-started >= 4500000000 && finished-started < 8500000000)
 -- Exactly one valid frame after genuinely more than five seconds of silence;
 -- first byte has real kernel SCM credentials and final guard admission.
 withFixture True $ \fixture@(Fixture ingress peer calls fragments _ guard _) -> do
  originalD <- deadlineAfterSeconds 15
  seedFirst fixture originalD desktopFirst
  started <- now
  withSender (threadDelay 5300000 >> N.sendAll peer desktopSecond) $ do
   result <- bounded "healthy idle" 12000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
   completed <- now
   count <- readIORef calls
   seen <- readIORef fragments
   check "idle >5s then authenticated frame delivers once" (completed-started >= 5000000000 && completed < originalD && result == CredentialDelivered && count == 2 && seen >= 2)
 -- Partial HEADER and BODY use the existing 5-second whole-frame budget.
 -- Wall-clock upper tolerance is scheduler grace, not a claim that a longer
 -- transport deadline is permitted; exact timer arithmetic needs its own seam.
 withFixture True $ \fixture@(Fixture _ peer _ _ _ _ _) -> do
  originalD <- deadlineAfterSeconds 12
  seedFirst fixture originalD desktopFirst
  N.sendAll peer (B.take 2 desktopSecond)
  started <- now
  expectTimeout "partial header" fixture originalD
  finished <- now
  check "partial header kept five-second bound" (finished-started >= 4500000000 && finished-started < 8500000000)
 withFixture True $ \fixture@(Fixture _ peer _ _ _ _ _) -> do
  originalD <- deadlineAfterSeconds 12
  seedFirst fixture originalD desktopFirst
  N.sendAll peer (B.take 5 desktopSecond)
  started <- now
  expectTimeout "partial body" fixture originalD
  finished <- now
  check "partial body kept five-second bound" (finished-started >= 4500000000 && finished-started < 8500000000)
 -- Each header fragment arrives within five seconds of the previous one, but
 -- the full frame remains incomplete past the original frame deadline.
 -- Later scheduled fragments must not renew that deadline or be replayed.
 withFixture True $ \fixture@(Fixture _ peer _ _ _ _ _) -> do
  originalD <- deadlineAfterSeconds 12
  seedFirst fixture originalD desktopFirst
  N.sendAll peer (B.take 1 desktopSecond)
  started <- now
  withSender (do
    threadDelay 2000000
    N.sendAll peer (B.take 1 (B.drop 1 desktopSecond))
    threadDelay 2000000
    N.sendAll peer (B.take 1 (B.drop 2 desktopSecond))
    threadDelay 2000000
    N.sendAll peer (B.drop 3 desktopSecond)) $ do
   expectTimeout "dribbled header" fixture originalD
   finished <- now
   check "dribble does not renew frame timer" (finished-started >= 4500000000 && finished-started < 8500000000)
 -- EOF is a readable condition; unchanged receive must report it, not spin or
 -- manufacture a delivered message.
 withFixture True $ \fixture@(Fixture ingress peer calls _ _ guard _) -> do
  originalD <- deadlineAfterSeconds 5
  seedFirst fixture originalD desktopFirst
  S.shutdown peer S.ShutdownSend
  result <- bounded "EOF" 3000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
  count <- readIORef calls
  check "EOF fails closed without callback" (result == CredentialFrameRejected (CredentialTransport StreamEOF) && count == 1)
 -- Revocation happens before the next actual SCM-bearing write and is checked
 -- by the production receive/admission hooks, not by an invented success.
 withFixture True $ \fixture@(Fixture ingress peer calls _ revoked guard _) -> do
  originalD <- deadlineAfterSeconds 5
  seedFirst fixture originalD desktopFirst
  writeIORef revoked True
  N.sendAll peer desktopSecond
  result <- bounded "revocation" 3000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
  count <- readIORef calls
  check "revoked guard refuses without callback" (result == CredentialFrameRejected (CredentialPeer Revoked) && count == 1)
 -- Retire an admitted idle reader and encourage actual descriptor-number
 -- reuse with an unrelated socketpair. Busy independently witnesses that the
 -- first receiver owns ingress serialization before retirement; this does not
 -- prove its kernel event registration was already installed. The old receive
 -- must not dispatch or consume the sentinel, and reuse must be observed.
 withFixture True $ \fixture@(Fixture ingress _ calls _ _ guard originalFd) -> do
  originalD <- deadlineAfterSeconds 10
  seedFirst fixture originalD desktopFirst
  readerStarted <- newEmptyMVar
  readerDone <- newEmptyMVar
  ready <- newEmptyMVar
  inspect <- newEmptyMVar
  retired <- newEmptyMVar
  let unrelated = bracket (S.socketPair S.AF_UNIX S.Stream S.defaultProtocol)
        (\(a,b) -> S.close a `finally` S.close b) $ \(a,b) -> do
         fdA <- S.withFdSocket a (pure . fromIntegral)
         fdB <- S.withFdSocket b (pure . fromIntegral)
         let reused = fdA == originalFd || fdB == originalFd
             (target,writer) = if fdB == originalFd then (b,a) else (a,b)
             sentinel = "unrelated-socket-sentinel"
         N.sendAll writer sentinel
         putMVar ready reused
         takeMVar inspect
         observed <- timeout 2000000 (readExactly target (B.length sentinel))
         pure (reused,observed == Just sentinel)
  readerThread <- forkFinally
    (putMVar readerStarted () >> receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
    (putMVar readerDone)
  (do
   _ <- bounded "idle receiver started" 1000000 (takeMVar readerStarted)
   threadDelay 100000
   concurrent <- bounded "idle reader busy witness" 1000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
   check "first reader holds ingress while idle" (concurrent == CredentialFrameRejected (CredentialTransport Busy))
   retireThread <- forkFinally (retireCredentialIngress ingress >> unrelated) (putMVar retired)
   (do
    readerOutcome <- bounded "idle retirement" 3000000 (takeMVar readerDone)
    result <- case readerOutcome of
     Left problem -> ioError (userError ("idle reader failed: " ++ show (problem :: SomeException)))
     Right value -> pure value
    reused <- bounded "unrelated socket prepared" 3000000 (takeMVar ready)
    void (tryPutMVar inspect ())
    completion <- bounded "retirement and reuse completion" 3000000 (takeMVar retired)
    (reportedReuse,intact) <- case completion of
     Left problem -> ioError (userError ("retirement/reuse failed: " ++ show (problem :: SomeException)))
     Right evidence -> pure evidence
    count <- readIORef calls
    putStrLn ("idle_retirement_result=" ++ show result ++ " reused=" ++ show reused)
    check "original descriptor number reused" (reused && reportedReuse)
    check "unrelated socket bytes remain intact" intact
    let refused = case result of
         CredentialNotLive -> True
         CredentialFrameRejected (CredentialTransport Closed) -> True
         CredentialFrameRejected (CredentialTransport IOErrorClosed) -> True
         CredentialFrameRejected (CredentialTransport StreamEOF) -> True
         _ -> False
    check "retired idle channel refuses without dispatch" (refused && count == 1)
    ) `finally` (void (tryPutMVar inspect ()) >> killThread retireThread)
   ) `finally` (void (tryPutMVar inspect ()) >> killThread readerThread)
 -- An idle D expires without bytes and does not become a new five-second D.
 withFixture True $ \fixture@(Fixture ingress _ calls _ _ guard _) -> do
  started <- now
  let originalD = started + 2000000000
  seedFirst fixture originalD desktopFirst
  result <- bounded "idle original D" 3000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
  finished <- now
  count <- readIORef calls
  check "idle original D is honored" (result == CredentialFrameRejected (CredentialTransport TimedOut) && count == 1 && finished < originalD + 1500000000)
 -- A partial header that becomes readable before D must not receive a fresh
 -- five-second lifetime after D. This is expected to expose an implementation
 -- that limits readiness only; actual outer owner cancellation is separate.
 withFixture True $ \fixture@(Fixture ingress peer calls _ _ guard _) -> do
  started <- now
  let originalD = started + 2000000000
  seedFirst fixture originalD desktopFirst
  N.sendAll peer (B.take 2 desktopSecond)
  result <- bounded "partial original D" 3000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress guard)
  finished <- now
  count <- readIORef calls
  check "partial frame cannot extend original D" (result == CredentialFrameRejected (CredentialTransport TimedOut) && count == 1 && finished < originalD + 1500000000)
 -- Delay the real credential-admission continuation beyond the same D.
 -- The callback must not begin after expiration, regardless of which
 -- fail-closed result represents the elapsed deadline.
 withFixture True $ \fixture@(Fixture ingress peer calls _ _ guard _) -> do
  started <- now
  let originalD = started + 2000000000
      delayedGuard = CredentialGuard (checkFragment guard)
        (\credential action -> threadDelay 2500000 >> withCredentialAdmission guard credential action)
  seedFirst fixture originalD desktopFirst
  N.sendAll peer desktopSecond
  result <- bounded "admission crosses D" 4000000 (receiveDesktopCredentialIngressAfterIdle originalD ingress delayedGuard)
  finished <- now
  count <- readIORef calls
  check "expired admission invokes no callback" (finished >= originalD && result /= CredentialDelivered && count == 1)
 -- The native profile must keep its legacy immediate 5-second read behavior.
 withFixture False $ \fixture@(Fixture _ _ _ _ _ _ _) -> do
  originalD <- deadlineAfterSeconds 12
  seedFirst fixture originalD native
  started <- now
  expectTimeout "native unchanged idle" fixture originalD
  finished <- now
  check "native timeout remains five seconds" (finished-started >= 4500000000 && finished-started < 8500000000)
 putStrLn "desktop idle transport controls: same-process SCM fixture; no native acceptance"
