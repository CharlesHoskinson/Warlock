# Persistent Process-Custody v3/v6 Freeze, Source Peer Reviews & Unimplemented Call Chain (`223711Z`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Wave / Cutoff**: `2026-11-01T22:37:11.760182+00:00` -> `2026-11-01T23:05:11.760182+00:00`
- **Committed Base `HEAD`**: `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70`
- **Frozen Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-prereqs-v6-220528Z.patch` (`sha256:2614f60e4fbb285abccd78e0ef98ef5aaae444dcf5f4a8ef8c10029c6b3dedd8`, `113981` bytes; identical hunks to `v5` `sha256:960997938a0a649899bc2c06c880beceb1c3a3203d98ef029dfdbb96a219362c` with normalized `diff --git a/... b/...` header)
- **Frozen Manifest**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-custody-manifest-223711Z.json` (`sha256:b5b46c877ae7311a3bfc3421a2f70aa056911cbdc3f3651e131081fa5b5a2e89`)
- **Scope & Honesty Boundary**: Unexecuted source candidate only. Zero compiler/model/VM/GPU execution performed; zero canonical files mutated. Does **not** claim the proposed persistent API or `PersistentAggregate` is compiled or runnable, and claims neither native/provider cleanup nor whole-EARS closure (`17/242` whole, `41/417` scenarios, `HOSTSTOP2`, `nativeOperations = []` unchanged).

---

## 1. Frozen File & Preimage/Postimage Table (Against `HEAD` `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70`)

| Repository Path | Status | Lines | Preimage SHA-256 (`a30ad9e9`) | Postimage SHA-256 (`v6` `2614f60e`) |
|---|---|---:|---|---|
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Persistent.hs` | Added | `73` | *(new file)* | `bb0ce67248898fa9b87bf6837caf81ac416f13721bb5a1c651efcadf2f5c71b3` |
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Persistent/Internal.hs` | Added | `1430` | *(new file)* | `de2c15190bf8e217f83512b9fe4994170036fabf837f020ed07ed71b9f802e0f` |
| `implementation/warlock/haskell/process-custody/test/PersistentControls.hs` | Added | `617` | *(new file)* | `5fd6e81607de20e734126b7476d9cf74c2258970772b388cc5303ec1c22ad098` |
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Internal.hsc` | Modified | `681` | `f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f` | `fa3b055daad9495a4fa1fda1ffbf8b7f3b6ce1c21fec512c1a09869b508ef1a2` |
| `implementation/warlock/haskell/process-custody/process-custody.cabal` | Modified | `77` | `ba77fc52c394747e446475a53660d0c5065e9753d77aeaea22714e5737bc13ab` | `409fcd9b96285481f9df948ce23797487d22b9ba478a37290c1494cdd8e113d5` |
| `implementation/warlock/haskell/process-custody/test/DeadlineStop.hs` | Modified | `98` | `73d44888cd349224663790847e2ac593c3fb60ec27cd07fcbfef9b130cc00166` | `42caab64dbe2ba230d8835f57548a124acffc75e463fa602e8268b0467604ed6` |
| `implementation/warlock/haskell/process-custody/fixture-graceful/Main.hs` | Modified | `26` | `e2116e43764fce5ff0e0649a294cc6ca2fe0dabaae4a220009cd15f75ab0af6c` | `48f85b9c227e66b2579d149f1c6e12bf90328dbcaf2ba7b76b2bc247a8f3a3fc` |

- Both `git -C /home/charl/code/Warlock apply --check` and `patch -d /home/charl/code/Warlock --batch --dry-run -p1 --fuzz=0` exit `0` against `HEAD` `a30ad9e9fa669e7b5d8af2f8fd8d58bc19313f70`.
- Preserves existing diagnostic `runSelectedDetailed` and `AdmissionDeadline` (`<= 30s` cap, `28s` Root attempt budget) completely unchanged.

---

## 2. Source Peer-Review Disposition (`terra-engine`, `terra-q-lifetime`, `terra-graph`, `terra-q-front`, `terra-portable`, `sol-docs`)

### A. Findings Closed in Frozen `v6` (`2614f60e`)
1. **Forked/Overlapping `enterLiveFrameAction` vs `withLiveFrameAdmission` Return (`terra-engine` & `terra-q-lifetime`)**:
   - `LiveFrameAdmission` carries `MVar FrameState` (`FrameState !Bool !Bool`, acquired before `CallbackGate`).
   - `admitFrameActionAttempt` increments `CallbackGate` `activeCount` by `+1` for the entered action itself (`Persistent/Internal.hs:206-222`), released in `enterLiveFrameAction`'s own `finally (releaseCallback cbGate)` (`lines 500-538`).
   - `withLiveFrameAdmission`'s outer `finally` marks `FrameState False used` before releasing its outer pin (`line 1090`), so an escaped token is refused pre-dispatch (`OperationRefusedPreDispatch SessionClosed`) while an already-entered forked action blocks `retireLive` in `drainCallbackGate` before child reap (Control #8 in `PersistentControls.hs:466-521`).
2. **Pre-Entry & Post-Action Synchronous Liveness vs Kernel Exit TOCTOU (`terra-engine` `01M6CK8K1NXW3SRXNXNR1GR5VG`)**:
   - `enterLiveFrameAction` performs synchronous `leaderExited pid` (`waitid(WNOHANG|WNOWAIT)`) + `observeChild frameDl pid == expectedObs` under `SessionScope` before entry (`lines 469-477`), and a second synchronous `leaderExited pid` + `observeChild actionDl pid == expectedObs` after `act` completes before returning `Right val` (`lines 521-537`, tested in Control #11 `PersistentControls.hs:586-617`).
   - Explicit linearization note: kernel child exit is an asynchronous OS event; any exit after the last observation linearizes after that observation (`ChildExitDuringExecution -> OperationOutcomeUnknown` when observed before return).
3. **`openSessionPidfd` Publication Before Postchecks (`terra-q-lifetime` `01M6CK45Y00VS3KV5DKB6G2PSH`)**:
   - `openSessionPidfd` (`lines 962-988`) writes `Just (Fd rawFd)` into `pidfdCell` inside `mask_` immediately upon `c_pidfd_open >= 0` (never wrapped inside `inScope`'s postcheck discard), and `finishContainment` closes `pidfdCell` under `boundedByDl stopDl` with `"pidfd-close"` quarantine on error/expiry (Control #9 `PersistentControls.hs:523-552`).
4. **Atomic Pre-Spawn Reservation (`terra-q-lifetime` `01M6CK40QBADCP8Q9GECY4T0Y0`)**:
   - `GateState` includes `SpawnPhase` (`SpawnUnreserved | SpawnReserved`) and `reserveSpawnUnderGate` (`lines 171-180`), linearizing pre-spawn stop checks under `CallbackGate`'s single `MVar`.
5. **Retained `verifyReady` Worker (`terra-q-lifetime` `01M6CK4M2JRPNK8FVYTB5P50SN`)**:
   - `vTid` is registered via `O.retainReader child tid (void waitVerifyDone)` under `mask_` (`lines 809-816`) and drained by `retireInterruptedStartup` (`lines 1201-1238`) if an async exception interrupts `PhaseStarting`.
6. **Fresh `actionDl` Sample Right Before `timeout` (`terra-q-lifetime` `01M6CK55ATHERH9HJNC5ZTRWZS`)**:
   - `enterLiveFrameAction` runs `hook "persistent-before-action-timeout"`, then re-samples `stoppedBeforeTimeout` and `freshActionBudget <- remainingMicros actionDl` right before `timeout freshActionBudget` (`lines 502-510`, Control #10 `PersistentControls.hs:554-584`).

### B. Open Source-Review Findings on Frozen `v6` (`2614f60e`) Requiring Next-Iteration Follow-Up Before Integration
1. **Wake-Scope Tombstone Ordering vs `threadWaitReadSTM` Unregister (`terra-engine` `01M6CKR07NAF1ADJG24SMHCWSW`, `terra-graph` `01M6CKS714N5N4DGS7M2J0CN8S`, `terra-portable` `01M6CKRQVSMWMQ8SW83AYNBC7Q`)**:
   - In `Persistent/Internal.hs:1062-1075`, `bracket (threadWaitReadSTM (fromIntegral rawPidfd)) snd` unregisters the event-manager callback (`snd`) before the outer `finally` writes `scopeExitedVar = True`.
   - **Required 3-line fix before production integration**: wrap `restore (wakeBody wakeSTM)` inside `bracket` with `finally (restore (wakeBody wakeSTM)) (atomically (writeTVar scopeExitedVar True))` so `scopeExitedVar = True` commits *before* `snd` unregisters, while keeping the outer `finally` for pre-registration branches and `releaseWake wg`.
2. **Owner-Retained Sticky `PidfdCustody` Record Across Quarantine (`terra-q-lifetime` `01M6CKR48QSX9GV3J08MR8FMBJ` & `01M6CKYPCB9KBT18GBECNCXCDE`)**:
   - In `Persistent/Internal.hs:768,1391`, `pidfdCell` is a local `IORef (Maybe Fd)` cleared by `takeOwnedPidfd` prior to `boundedByDl stopDl (closeFd pfd)`. If `closeFd` fails/times out or `drainWakeGate` quarantines `["persistent-wake-not-drained"]`, `PersistentOwner` / `O.Child` does not retain the descriptor's `Owned | Closing | Closed | CloseUncertain` disposition.
   - **Required fix before production integration**: store `IORef PidfdCustody` on `PersistentOwner` / `O.Child` (`PidfdUnopened | PidfdOwned !Fd | PidfdClosing !Fd | PidfdClosed | PidfdCloseUncertain !Fd`), transition `PidfdOwned -> PidfdClosing` before `closeFd`, and record `PidfdCloseUncertain fd` on failure/timeout for audit/quarantine only (never retrying `closeFd` or signaling through an uncertain `Fd`).
3. **Advisor Scope Note (`sol-docs` `01M6CM49E7KJE1RQP7G7MNME2W`)**:
   - `sol-docs` recorded receipt of `2614f60e` and explicitly noted that advisor review of the full 1430-line owner body and 617-line controls is not yet complete while prioritized on the `001` atomic 37-bundle and pending-cancel correction.

### C. Source Peer Review of Coordinated Peer Artifacts
1. **`terra-q-front` `PersistentEscapedFrameRaceV3.hs` (`sha256:70a165849edf3c843e1a163173888ebfb482820b1b0cffcb8a35d2a7ad86ed22`) — PASS**:
   - Publishes `ProbeCustody` cells (`probeOwner`, `probeInput`, `probeOwnerThread`, `probeActionThread`, etc.) via `publishCustody` before opening `input` or forking (`lines 87-90, 145-154`), and only calls `retireCustody` when leader reap (`LeaderReaped`), callback completion, and `hIsClosed handle` are all positively confirmed (`lines 108-110`).
   - Accommodates either a parent `withLiveFrameAdmission` that returns while the forked child action remains pinned or one that waits (`lines 117-126`), and verifies `early == Nothing` (`150ms` blocked-action no-reap check), `OperationOutcomeUnknown SessionClosed`, `not raced` (`actionBodyFinished` before return), and final `LeaderReaped`.
   - 100% API-compatible with `v6` (`2614f60e`) exports and hook names.
2. **`terra-engine` `terra-engine-persistent-idle-wait.hs` (`sha256:62bfea249ff83d69210e16760b278a4cb42d75fa336d3d5905efcbf5ca3fe102`) — PASS**:
   - Polymorphic `IdleWake reason = OwnerWake reason | Readable` composes directly with `withLiveSessionWakeSTM :: LiveSession -> (STM LiveWakeReason -> IO a) -> IO (Either ToolError a)` via `awaitReadableOrOwnerWake (SocketFd sockFd) wakeSTM` without minting any `AdmissionDeadline` during inter-frame idle wait.
3. **`terra-q-lifetime` `terra-q-lifetime-persistent-aggregate-route-v2.hs` (`sha256:cdd7ea9e2105fd0231f8f60fed72a33bfbe8d066f0ab491ebab13b665754e9b3`) & `terra-q-lifetime-frame-admission.qnt` (`sha256:1284523017579302c3b36f6b18dec20c839381d486b8e6c04a6fd06d7ad96b1c`) — PASS (Contract Specification)**:
   - `v6` (`2614f60e`) implements the three owner-side prerequisites (`requestSessionStop` during `PhaseAvailable`/`PhaseStarting` under one-shot `StopDeadline`, `withLiveSessionWakeSTM` via verified `SYS_pidfd_open`, and lexical `withLiveFrameAdmission`/`enterLiveFrameAction` distinguishing `frameDl` from `actionDl`).

---

## 3. Precise Unimplemented Production Call Chain (Why Persistent MVP Is Not Yet Runnable)

1. **`Warlock.Capture.Process.Persistent` (`implementation/warlock/haskell/process-custody`)**:
   - Authored in frozen patch `2614f60e` (uncompiled/unintegrated in canonical `HEAD` `a30ad9e9`), with the two open source-review items in Section 2.B above (`runWakeScope` inner-bracket tombstone ordering and owner-retained `PidfdCustody` state).
2. **`Omarchy.VerifiedSocket.SocketOwner` & `Omarchy.VerifiedSocket.Channel` (`implementation/warlock/haskell/verified-socket`)**:
   - **Current canonical state**: `SocketOwner.withOwnedExecSocket` (`SocketOwner.hsc:91-125`) uses `runSelectedDetailed` with a single one-shot `AdmissionDeadline` (`<= 30s`), and `Channel.receiveCredentialedFrame` (`Channel.hs:84-99`) mints its `5s` `FrameDeadline` (`frameBudgetMicros = 5_000_000`) immediately upon entry before waiting for socket readability (`stepBudgetMicros = 500_000`).
   - **Unimplemented seam**:
     - `SocketOwner` must add a persistent variant (`withPersistentOwnedExecSocket`) that delegates child lifecycle custody to `PersistentOwner.withPersistentOwner` (`StartBudget` `<= 30s` / `28s` for startup + handshake only, `StopBudget` minted once on first stop) while verifying `/proc/<pid>/fd/0` socket inode identity against `observeLiveStartup`.
     - `Channel` must separate inter-frame idle wait from frame admission:
       1. Wait for readability or owner wake inside `withLiveSessionWakeSTM session (\wakeSTM -> awaitReadableOrOwnerWake sockFd wakeSTM)` with **zero** `FrameDeadline` running during idle.
       2. On `Right Readable`, enter `withLiveFrameAdmission session $ \frameAdm -> ...` and **then** mint the `5s` `FrameDeadline` (`frameDl`) and `500ms` fragment step deadlines (`stepBudgetMicros`) to read and validate `SCM_CREDENTIALS` (`pid == observedPid`, `uid`, `gid`) + `/proc` birth/exe identity.
       3. Mint or pass the caller's immutable `actionDl` (`<= 30s`, never renewed) into `enterLiveFrameAction frameAdm frameDl actionDl act`.
3. **`Omarchy.Runtime.PersistentAggregate` (`terra-q-lifetime-persistent-aggregate-route-v2.hs` `cdd7ea9e`)**:
   - **Unimplemented seam**: `TrustedPump` in `cdd7ea9e` has no production constructor yet; it must be instantiated by wiring step 2's `withPersistentOwnedExecSocket` + `withLiveSessionWakeSTM` + `withLiveFrameAdmission` + `enterLiveFrameAction` loop.
4. **`Omarchy.Runtime.Production` / `Main.hs` (Backend HTTP / Elm Bridge)**:
   - **Unimplemented seam**: Production runtime routes currently invoke one-shot `runSelectedDetailed` and read-only catalog/`HttpPopup` handlers (`a30ad9e9`). No production call site constructs `PersistentOwner` or `PersistentAggregate` yet, and `nativeOperations` remains `[]`.

---

## 4. Addendum: Source Peer Reviews Received During 60s Post-Handoff Window (`22:46:02Z` -> `22:49:10Z`)

1. **`terra-security` `terra-security-wake-unregister-quarantine.patch` (`sha256:5c60fb5ec337b7c0e2541f73a39630e003c388dc2b6b2e528599b7331fa9782d`) — SOURCE REVIEW PASS**:
   - Applies with zero fuzz (`patch --batch --dry-run -p1 --fuzz=0`) directly onto frozen `v6` `Persistent/Internal.hs` preimage `de2c15190bf8e217f83512b9fe4994170036fabf837f020ed07ed71b9f802e0f` (producing postimage `421fd87ff22c120addf5d25d2507f5ecb3b2c8902f3dd21d258d7df666a1f89d`).
   - Resolves **both** the wake-scope tombstone ordering gap (`atomically (writeTVar scopeExitedVar True)` runs first inside `bracket`'s release handler *before* `unregister`) **and** the event-manager deregistration uncertainty defect (`registrationSafe` is set `False` before `bracket (threadWaitReadSTM ...)` and set `True` only after `unregister` returns cleanly; the outer `finally` calls `releaseWake wg` only when `registrationSafe == True`, retaining the `WakeGate` pin so `drainWakeGate` quarantines `persistent-wake-not-drained` without closing `pidfd` if registration/unregistration fails or is interrupted).
   - Zero collision with frozen `v6` (`2614f60e`): cleanly layered as an orthogonal 38-line delta patch on top of `de2c1519`.
2. **`terra-q-network` (`01M6CMJ2BHJXXF1H6ZSXM51TYN`) — Independent Confirmation of `PidfdCustody` State Requirement**:
   - Independently confirmed `terra-q-lifetime`'s finding on `2614f60e`: clearing `pidfdCell` before `boundedByDl stopDl (closeFd pfd)` conflates pre-close deadline expiry (where `pfd` is still known-unclosed) with failed/timed-out `closeFd` (where `pfd` close disposition is uncertain and must never be blindly retried or signaled). Next owner iteration should retain an explicit `PidfdCustody` state on `O.Child` / `PersistentOwner` distinguishing `KnownUnclosed Fd` vs `CloseAttemptedUncertain Fd`.
3. **`terra-q-lifetime` (`01M6CMN0YVBVQXZD5WWNW17A2F`) — Hung-Wake Quarantine Fixture Reap Custody Note**:
   - In `PersistentControls.hs` Control #4 and Control #7, after intentional quarantine (`leader-reap` / `persistent-wake-not-drained`) leaves the fixture child alive during the assertion window, the test currently unblocks and sends raw `c_kill(..., sigKILL)` without an explicit `waitpid`/reap proof or Root recovery-registry handoff. Future execution-ready controls should register quarantined test children in Root's recovery registry or perform a bounded verified reap after the quarantine assertion.
