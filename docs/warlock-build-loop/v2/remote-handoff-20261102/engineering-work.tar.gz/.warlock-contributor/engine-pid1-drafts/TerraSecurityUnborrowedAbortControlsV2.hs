-- QA-only source draft. Root must compile in the process-custody test component.
-- These tests exercise the private Owner implementation; they do not certify
-- caller single-writer ownership, stop linearization, native or VM behavior.
module TerraSecurityUnborrowedAbortControls (runUnborrowedAbortControls, GateProbe, newGateProbe, runGateProbe) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar (MVar, newEmptyMVar, putMVar, readMVar, takeMVar, tryPutMVar)
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef (IORef, modifyIORef', newIORef, readIORef, writeIORef)
import System.Timeout (timeout)
import qualified Warlock.Capture.Process.Owner as O

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("unborrowed-abort: " ++ label)))

freshBeginning :: IO (O.Owner, O.Pending)
freshBeginning = do
 owner <- O.newOwner
 began <- O.begin owner
 pending <- O.newPending
 retained <- O.retainPending owner pending
 check "fresh beginning and exact pending installed" (began && retained)
 pure (owner, pending)

runUnborrowedAbortControls :: IO ()
runUnborrowedAbortControls = do
 -- Positive exact pending: no borrow, input, process or native evidence.
 (clean, pending) <- freshBeginning
 accepted <- O.tryAbortUnborrowed clean pending
 status <- O.status clean
 missing <- maybe True (const False) <$> O.ownerPending clean
 repeated <- O.tryAbortUnborrowed clean pending
 check "only exact clean beginning aborts once" (accepted && status == O.Available && missing && not repeated)

 -- A different Pending never authorizes clearing the real pending slot.
 (mismatch, actual) <- freshBeginning
 foreignPending <- O.newPending
 refusedMismatch <- O.tryAbortUnborrowed mismatch foreignPending
 stillStarting <- O.status mismatch
 recoveredActual <- O.tryAbortUnborrowed mismatch actual
 check "mismatch retains exact pending" (not refusedMismatch && stillStarting == O.Starting && recoveredActual)

 -- An already-started marker is evidence of an attempted operation, even if
 -- there is no PID, descriptor or visible child yet. Preserve the pending.
 (started, marked) <- freshBeginning
 firstStart <- O.pendingStart marked
 refusedStarted <- O.tryAbortUnborrowed started marked
 startedPhase <- O.status started
 stillPending <- maybe False (const True) <$> O.ownerPending started
 check "started pending cannot be cleared as unborrowed" (firstStart && not refusedStarted && startedPhase == O.Starting && stillPending)

 -- A retained release action is evidence of a borrowed capability. Refusal
 -- must neither execute nor silently drop it; the test invokes it explicitly.
 (borrowed, borrowedPending) <- freshBeginning
 calls <- newIORef (0 :: Int)
 O.retainBorrow borrowed (modifyIORef' calls (+1))
 refusedBorrow <- O.tryAbortUnborrowed borrowed borrowedPending
 before <- readIORef calls
 borrowedPhase <- O.status borrowed
 O.releaseBorrows borrowed
 after <- readIORef calls
 check "retained borrow survives refusal" (not refusedBorrow && borrowedPhase == O.Starting && before == 0 && after == 1)

 -- Existing issue history is evidence. A failed check cannot erase it.
 (issued, issuedPending) <- freshBeginning
 O.pendingRecordIssue issuedPending "fixture-uncertainty"
 refusedIssue <- O.tryAbortUnborrowed issued issuedPending
 issuePhase <- O.status issued
 issues <- O.pendingIssues issuedPending
 check "pending issue history survives refusal" (not refusedIssue && issuePhase == O.Starting && "fixture-uncertainty" `elem` issues)

-- Root must retain this probe before starting any worker and continue to own it
-- after any timeout. A completion cell is not a thread-termination receipt.
data GateProbe = GateProbe O.Owner O.Pending (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar (Either SomeException ()))

newGateProbe :: IO GateProbe
newGateProbe = do
 (owner, pending) <- freshBeginning
 GateProbe owner pending <$> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar

within :: String -> IO a -> IO a
within label action = do
 value <- timeout 2000000 action
 maybe (ioError (userError ("unborrowed-abort watchdog: " ++ label))) pure value

-- The held gate is the actual raw Owner state mutex. A separate one-shot probe
-- is required for each execution. Cleanup releases the fixture gate even if
-- an assertion fails; an unconfirmed callback remains retained in the probe.
runGateProbe :: GateProbe -> IO ()
runGateProbe (GateProbe owner pending workerRef entered release done) = mask $ \restore -> do
 let finish = do
      void (tryPutMVar release ())
      worker <- readIORef workerRef
      case worker of
       Nothing -> pure ()
       Just _ -> void (timeout 2000000 (readMVar done))
     run = do
      _ <- mask_ $ do
       tid <- forkFinally (restore (O.qaHoldOwnerGate owner (putMVar entered ()) (takeMVar release))) (putMVar done)
       writeIORef workerRef (Just tid)
       pure tid
      within "actual owner gate held" (readMVar entered)
      refused <- within "unborrowed abort returns while gate held" (O.tryAbortUnborrowed owner pending)
      check "occupied owner lock refuses immediately" (not refused)
      void (tryPutMVar release ())
      result <- within "gate holder callback" (readMVar done)
      check "gate holder completed normally" (case result of Right () -> True; _ -> False)
      status <- O.status owner
      final <- O.tryAbortUnborrowed owner pending
      check "original pending remains abortable after gate release" (status == O.Starting && final)
 restore run `finally` finish
