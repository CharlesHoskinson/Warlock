-- QA ONLY, ROOT EXECUTION ONLY.  No compiler/test/native execution by author.
-- Link against the selected production library, not copied source modules.
-- The host must strongly root Probe, its actual owner and an independent
-- guardian BEFORE armBeforeFault.  Timeout never terminates either worker.
module SolFirstStopDeadline0432
  ( Expectation(..), Probe, Observation(..)
  , newProbe, armBeforeFault, startAfterFault, observe, retainedWorkers
  , retainedFirstDeadline
  ) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception
  ( SomeAsyncException, SomeException, fromException, mask, throwIO, try )
import Control.Monad (unless)
import Data.IORef
import GHC.Clock (getMonotonicTimeNSec)
import System.Timeout (timeout)
import Text.Read (readMaybe)
import Warlock.Capture.Process.Bootstrap
  ( AdmissionDeadline, ToolError(..), deadlineAbsoluteNs, remainingMicros )
import Warlock.Capture.Process.Persistent
  ( PersistentOwner, StopBudget, StopDeadlineObservation(..), StopReceipt(..)
  , requestSessionStop, stopBudgetMicrosValue, tryPersistentStopDeadline )

-- Literal semantic expectations, never copied from a reducer/runtime result.
-- BeforeLive is the positive control on a genuinely fresh actual owner.
-- FaultedRoot is reached by the companion's REAL same-owner implicit-
-- containment/root-close fault route, with NO preceding explicit stop.
data Expectation = BeforeLive | FaultedRoot deriving (Eq, Show)

data TimedReceipt = TimedReceipt Integer Integer StopReceipt
data ArmState = Unarmed | Claimed | Armed deriving (Eq)
data Worker = Worker (MVar ()) (MVar ())
  (MVar (Either SomeException TimedReceipt)) (IORef (Maybe ThreadId))
  (IORef Bool)
data Probe = Probe PersistentOwner StopBudget AdmissionDeadline Expectation
  (IORef ArmState) Worker Worker (IORef (Maybe AdmissionDeadline)) (IORef Bool)

-- Complete is a QA witness, never a clean-retirement/native/EARS verdict.
-- A missing latch, expired observation, exception or unsupported receipt
-- is explicitly retained and cannot become Complete by retrying this Probe.
data Observation
  = WaitingUnknown String
  | ExceptionUnknown String
  | Mismatch String
  | Complete AdmissionDeadline StopReceipt StopReceipt
  deriving (Eq, Show)

newWorker :: IO Worker
newWorker = Worker <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
  <*> newIORef Nothing <*> newIORef False

newProbe :: PersistentOwner -> StopBudget -> AdmissionDeadline -> Expectation -> IO Probe
newProbe owner budget originalD expected =
  Probe owner budget originalD expected <$> newIORef Unarmed
    <*> newWorker <*> newWorker <*> newIORef Nothing <*> newIORef False

check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError ("first-stop QA: " ++ label)))

-- This checks actual production state before fault injection.  A companion
-- that calls requestSessionStop first is NOT a first-stop-after-fault fixture.
-- It does not reset or inject the owner, phase, root markers, gate, or D.
armBeforeFault :: Probe -> IO ()
armBeforeFault (Probe owner _ originalD _ armed _ _ _ _) = do
  fresh <- atomicModifyIORef' armed (\old -> (Claimed, old == Unarmed))
  check "one arm only; retain failed Probe" fresh
  left <- remainingMicros originalD
  check "original observation D already expired" (left > 0)
  actual <- tryPersistentStopDeadline owner
  check "must precede EVERY explicit stop" (actual == StopDeadlineNotLatched)
  writeIORef armed Armed

launch :: PersistentOwner -> StopBudget -> AdmissionDeadline -> Maybe AdmissionDeadline -> Worker -> IO ()
launch owner budget originalD firstD (Worker begin entered done worker used) = mask $ \_ -> do
  fresh <- atomicModifyIORef' used (\old -> (True, not old))
  check "worker reused; do not replay stop" fresh
  tid <- forkIOWithUnmask $ \unmask -> do
    result <- try $ unmask $ do
      readMVar begin
      putMVar entered ()
      originalLeft <- remainingMicros originalD
      stopLeft <- maybe (pure originalLeft) remainingMicros firstD
      check "no dispatch after unchanged applicable D" (min originalLeft stopLeft > 0)
      before <- toInteger <$> getMonotonicTimeNSec
      receipt <- requestSessionStop owner budget
      after <- toInteger <$> getMonotonicTimeNSec
      pure (TimedReceipt before after receipt)
    putMVar done result
    -- Publish the exception first; do not silently consume async cancellation.
    case result of
      Left ex -> case fromException ex :: Maybe SomeAsyncException of
        Just _ -> throwIO ex
        Nothing -> pure ()
      Right _ -> pure ()
  -- No owner activity before its actual ThreadId is retained in Probe.
  writeIORef worker (Just tid)
  putMVar begin ()

startAfterFault :: Probe -> IO ()
startAfterFault (Probe owner budget originalD _ armed first _ _ _) = do
  ready <- readIORef armed
  check "host must arm BEFORE fault and root Probe BEFORE arm" (ready == Armed)
  left <- remainingMicros originalD
  check "cannot start after original observation D" (left > 0)
  launch owner budget originalD Nothing first

-- min of the SAME original absolute observation D and the SAME selected
-- first StopD on every wait.  No deadlineAfter, fresh relative operation D,
-- wire D, timeout-based owner cancellation, or fixture cleanup exists here.
waitWithin :: AdmissionDeadline -> Maybe AdmissionDeadline -> IO a -> IO (Maybe a)
waitWithin originalD firstD action = do
  originalLeft <- remainingMicros originalD
  stopLeft <- maybe (pure originalLeft) remainingMicros firstD
  let left = min originalLeft stopLeft
  if left <= 0 then pure Nothing else timeout left action

awaitLatch :: PersistentOwner -> AdmissionDeadline -> IO (Either Observation AdmissionDeadline)
awaitLatch owner originalD = do
  left <- remainingMicros originalD
  if left <= 0 then pure (Left (WaitingUnknown "first StopD unavailable by original observation D"))
  else do
    actual <- tryPersistentStopDeadline owner
    case actual of
      StopDeadlineLatched firstD -> pure (Right firstD)
      StopDeadlineFailed _ -> pure (Left (ExceptionUnknown "actual first StopD selection failed"))
      _ -> do
        -- Read-only polling; neither busy nor not-latched is success.  This
        -- can observe the old regression without filling its withheld gate.
        threadDelay (min 1000 left)
        awaitLatch owner originalD

receiptMatches :: Expectation -> StopReceipt -> Bool
receiptMatches expected actual = case expected of
  BeforeLive -> actual == StopLatchedBeforeLive
  FaultedRoot -> actual == StopUncertain CleanupUncertain

timely :: StopBudget -> AdmissionDeadline -> TimedReceipt -> Bool
timely budget firstD (TimedReceipt before after _) =
  case readMaybe (deadlineAbsoluteNs firstD) :: Maybe Integer of
    Nothing -> False
    Just end -> before < end && after <= end
      && end <= after + toInteger (stopBudgetMicrosValue budget) * 1000

observe :: Probe -> IO Observation
observe (Probe owner budget originalD expected armed first second recordedD observed) = do
  ready <- readIORef armed
  check "observe requires arm" (ready == Armed)
  fresh <- atomicModifyIORef' observed (\old -> (True, not old))
  check "one observation only; Unknown cannot be retried into a pass" fresh
  let Worker _ entered done _ used = first
  started <- readIORef used
  check "observe requires start" started
  began <- waitWithin originalD Nothing (readMVar entered)
  case began of
    Nothing -> pure (WaitingUnknown "first worker entry unobserved")
    Just () -> do
      selected <- awaitLatch owner originalD
      case selected of
        Left unknown -> pure unknown
        Right firstD -> do
          writeIORef recordedD (Just firstD)
          firstResult <- waitWithin originalD (Just firstD) (readMVar done)
          case firstResult of
            Nothing -> pure (WaitingUnknown "first stop did not return within unchanged applicable D")
            Just (Left _) -> pure (ExceptionUnknown "first actual stop raised")
            Just (Right timed@(TimedReceipt _ _ receipt)) ->
              if not (receiptMatches expected receipt) then pure (Mismatch "wrong literal FIRST stop receipt")
              else if not (timely budget firstD timed) then pure (Mismatch "first receipt outside actual first StopD/budget")
              else do
                beforeRepeat <- tryPersistentStopDeadline owner
                if beforeRepeat /= StopDeadlineLatched firstD then pure (Mismatch "first StopD changed before repeat")
                else do
                  -- This is a DISTINCT explicit caller on the SAME actual
                  -- owner, not a retry of an uncertain child operation.
                  left <- remainingMicros firstD
                  originalLeft <- remainingMicros originalD
                  if min left originalLeft <= 0 then pure (WaitingUnknown "no applicable D remains for repeat")
                  else do
                    launch owner budget originalD (Just firstD) second
                    let Worker _ _ repeatedDone _ _ = second
                    repeated <- waitWithin originalD (Just firstD) (readMVar repeatedDone)
                    afterRepeat <- tryPersistentStopDeadline owner
                    case repeated of
                      Nothing -> pure (WaitingUnknown "repeat did not return within original first StopD")
                      Just (Left _) -> pure (ExceptionUnknown "repeated actual stop raised")
                      Just (Right (TimedReceipt _ returned repeatedReceipt)) ->
                        if repeatedReceipt /= StopAlreadyRequested then pure (Mismatch "repeat must be AlreadyRequested")
                        else if afterRepeat /= StopDeadlineLatched firstD then pure (Mismatch "repeat renewed/lost actual first StopD")
                        else case readMaybe (deadlineAbsoluteNs firstD) :: Maybe Integer of
                          Just end | returned <= end -> pure (Complete firstD receipt repeatedReceipt)
                          _ -> pure (Mismatch "repeat returned after first StopD")

-- Read-only host inventory: no join, kill, cancellation, FD close, gate put,
-- process signal, root release, or claim of worker termination.
retainedWorkers :: Probe -> IO [Maybe ThreadId]
retainedWorkers (Probe _ _ _ _ _ (Worker _ _ _ first _) (Worker _ _ _ second _) _ _) =
  sequence [readIORef first, readIORef second]

retainedFirstDeadline :: Probe -> IO (Maybe AdmissionDeadline)
retainedFirstDeadline (Probe _ _ _ _ _ _ _ deadline _) = readIORef deadline
