port module SiteMainKeyboardFocusReplay2039 exposing (checks, main, result)

{-| Source-bound pure Elm semantic keyboard/focus and runnable-MVP onboarding
replay for `site/src/SiteMain.elm` (`SiteMainOnboardingKeyboard2039.patch`).

Scope:
- Exercises actual `SiteMain` decoders (`decodeWorkbenchTabKey`, `decodeEscapeKey`),
  pure `transition : Msg -> Model -> ( Model, List Effect )`, and shared
  `semanticSnapshot : Model -> SemanticSnapshot` used by `SiteMain.view`.
- Does NOT claim live browser layout/computed CSS contrast, screen-reader speech,
  or native Omarchy/Wayland acceptance; those remain explicit Root/browser/AT
  verification gates documented in `SiteMainKeyboardFocusOracle2039.json`.
-}

import Browser.Dom as Dom
import Json.Decode as D
import Json.Encode as E
import Platform
import SiteMain as Site


port outgoing : E.Value -> Cmd msg


stepMany : List Site.Msg -> Site.Model -> ( Site.Model, List (List Site.Effect) )
stepMany msgs startModel =
    List.foldl
        (\msg ( accModel, accEffects ) ->
            let
                ( nextModel, nextEffects ) =
                    Site.transition msg accModel
            in
            ( nextModel, accEffects ++ [ nextEffects ] )
        )
        ( startModel, [] )
        msgs


rovingValidFor : Site.SurfaceId -> List Site.WorkbenchTabSemantic -> Bool
rovingValidFor expectedActive tabs =
    let
        activeTabs =
            List.filter (\t -> t.tabIndex == 0 && t.ariaSelected == "true") tabs

        inactiveTabs =
            List.filter (\t -> t.tabIndex == -1 && t.ariaSelected == "false") tabs

        allLinked =
            List.all (\t -> t.role == "tab" && t.ariaControls == Site.workbenchPanelDomId) tabs
    in
    List.length tabs == 8
        && List.map .surfaceId activeTabs == [ expectedActive ]
        && List.length inactiveTabs == 7
        && allLinked


checks : List ( String, Bool )
checks =
    let
        initialSnap =
            Site.semanticSnapshot Site.initModel

        modelWithSpotlight targetSurface =
            Tuple.first (Site.transition (Site.SelectSpotlight targetSurface) Site.initModel)

        allTabpanelsLinked =
            List.all
                (\surfaceId ->
                    let
                        snap =
                            Site.semanticSnapshot (modelWithSpotlight surfaceId)
                    in
                    snap.workbenchPanelDomId == "wl-workbench-panel"
                        && snap.workbenchPanelTabIndex == 0
                        && snap.workbenchPanelAriaLabelledBy == Site.surfaceTabDomId surfaceId
                        && rovingValidFor surfaceId snap.workbenchTabs
                )
                Site.orderedSurfaceIds

        decodeKey keyName =
            Result.toMaybe (D.decodeString Site.decodeWorkbenchTabKey ("{\"key\":\"" ++ keyName ++ "\"}"))

        arrowAndHomeEndOk =
            decodeKey "ArrowRight" == Just ( Site.KeyboardStepSpotlight 1, True )
                && decodeKey "ArrowDown" == Just ( Site.KeyboardStepSpotlight 1, True )
                && decodeKey "ArrowLeft" == Just ( Site.KeyboardStepSpotlight -1, True )
                && decodeKey "ArrowUp" == Just ( Site.KeyboardStepSpotlight -1, True )
                && decodeKey "Home" == Just ( Site.KeyboardJumpSpotlight Site.SurfaceTaskbar, True )
                && decodeKey "End" == Just ( Site.KeyboardJumpSpotlight Site.SurfaceFiles, True )

        tabNotTrappedOk =
            decodeKey "Tab" == Nothing
                && decodeKey "Enter" == Nothing
                && decodeKey " " == Nothing
                && decodeKey "Escape" == Nothing

        eightRightSteps =
            List.repeat 8 (Site.KeyboardStepSpotlight 1)

        ( wrappedModel, eightRightEffects ) =
            stepMany eightRightSteps Site.initModel

        expectedEightTargets =
            [ Site.SurfaceLauncher
            , Site.SurfaceSwitcher
            , Site.SurfaceTaskView
            , Site.SurfaceSnap
            , Site.SurfaceNotifications
            , Site.SurfaceSettings
            , Site.SurfaceFiles
            , Site.SurfaceTaskbar
            ]

        expectedEightEffects =
            List.indexedMap
                (\idx targetSurface ->
                    [ Site.RequestDomFocus
                        (idx + 1)
                        (Site.FocusWorkbenchTab targetSurface)
                        (Site.surfaceTabDomId targetSurface)
                    ]
                )
                expectedEightTargets

        arrowRightWrapOk =
            wrappedModel.spotlight == Site.SurfaceTaskbar
                && wrappedModel.tabFocusSeq == 8
                && eightRightEffects == expectedEightEffects
                && rovingValidFor Site.SurfaceTaskbar (Site.semanticSnapshot wrappedModel).workbenchTabs

        ( leftWrapModel, leftWrapEffects ) =
            Site.transition (Site.KeyboardStepSpotlight -1) Site.initModel

        arrowLeftWrapOk =
            leftWrapModel.spotlight == Site.SurfaceFiles
                && leftWrapEffects
                    == [ Site.RequestDomFocus 1 (Site.FocusWorkbenchTab Site.SurfaceFiles) "wl-tab-files" ]
                && (Site.semanticSnapshot leftWrapModel).workbenchPanelAriaLabelledBy == "wl-tab-files"

        snapSelectedModel =
            modelWithSpotlight Site.SurfaceSnap

        ( homeModel, homeEffects ) =
            Site.transition (Site.KeyboardJumpSpotlight Site.SurfaceTaskbar) snapSelectedModel

        ( endModel, endEffects ) =
            Site.transition (Site.KeyboardJumpSpotlight Site.SurfaceFiles) homeModel

        homeAndEndOk =
            homeModel.spotlight == Site.SurfaceTaskbar
                && homeEffects == [ Site.RequestDomFocus 1 (Site.FocusWorkbenchTab Site.SurfaceTaskbar) "wl-tab-taskbar" ]
                && endModel.spotlight == Site.SurfaceFiles
                && endEffects == [ Site.RequestDomFocus 2 (Site.FocusWorkbenchTab Site.SurfaceFiles) "wl-tab-files" ]

        ( pointerSelectModel, pointerSelectEffects ) =
            Site.transition (Site.SelectSpotlight Site.SurfaceSettings) Site.initModel

        ( pointerStepModel, pointerStepEffects ) =
            Site.transition (Site.StepSpotlight 1) pointerSelectModel

        pointerNoFocusHijackOk =
            pointerSelectModel.spotlight == Site.SurfaceSettings
                && List.isEmpty pointerSelectEffects
                && pointerStepModel.spotlight == Site.SurfaceFiles
                && List.isEmpty pointerStepEffects

        decodeEsc keyName =
            Result.toMaybe (D.decodeString (Site.decodeEscapeKey Site.EscapeMobileNav) ("{\"key\":\"" ++ keyName ++ "\"}"))

        decodeEscapeOk =
            decodeEsc "Escape" == Just Site.EscapeMobileNav
                && decodeEsc "Esc" == Just Site.EscapeMobileNav
                && decodeEsc "Tab" == Nothing
                && decodeEsc "Enter" == Nothing

        ( openedNavModel, openedNavEffects ) =
            Site.transition Site.ToggleMobileNav Site.initModel

        openedNavSnap =
            Site.semanticSnapshot openedNavModel

        ( escapedNavModel, escapedNavEffects ) =
            Site.transition Site.EscapeMobileNav openedNavModel

        escapedNavSnap =
            Site.semanticSnapshot escapedNavModel

        escapeRestoresToggleFocusOk =
            List.isEmpty openedNavEffects
                && openedNavSnap.mobileToggleAriaExpanded == "true"
                && openedNavSnap.navOpen == "true"
                && escapedNavSnap.mobileToggleAriaExpanded == "false"
                && escapedNavSnap.navOpen == "false"
                && escapedNavEffects == [ Site.RequestDomFocus 1 Site.FocusMobileNavToggle "wl-mobile-nav-toggle" ]

        ( closedEscModel, closedEscEffects ) =
            Site.transition Site.EscapeMobileNav Site.initModel

        escapeWhenClosedNoOpOk =
            closedEscModel == Site.initModel && List.isEmpty closedEscEffects

        ( drawerClosedModel, drawerClosedEffects ) =
            Site.transition Site.CloseMobileNav openedNavModel

        drawerLinkCloseNoHijackOk =
            not drawerClosedModel.mobileNavOpen && List.isEmpty drawerClosedEffects

        ( step1Model, _ ) =
            Site.transition (Site.KeyboardStepSpotlight 1) Site.initModel

        ( step2Model, _ ) =
            Site.transition (Site.KeyboardStepSpotlight 1) step1Model

        ( afterStaleMissModel, staleMissEffects ) =
            Site.transition
                (Site.FocusSettled 1 (Site.FocusWorkbenchTab Site.SurfaceLauncher) (Err (Dom.NotFound "wl-tab-launcher")))
                step2Model

        staleFocusRejectedOk =
            afterStaleMissModel == step2Model
                && afterStaleMissModel.lastTabFocusMiss == Nothing
                && List.isEmpty staleMissEffects

        ( recordedMissModel, recordedMissEffects ) =
            Site.transition
                (Site.FocusSettled 2 (Site.FocusWorkbenchTab Site.SurfaceSwitcher) (Err (Dom.NotFound "wl-tab-switcher")))
                step2Model

        ( clearedMissModel, clearedMissEffects ) =
            Site.transition
                (Site.FocusSettled 2 (Site.FocusWorkbenchTab Site.SurfaceSwitcher) (Ok ()))
                recordedMissModel

        currentFocusMissAndClearOk =
            recordedMissModel.lastTabFocusMiss == Just "wl-tab-switcher"
                && List.isEmpty recordedMissEffects
                && clearedMissModel.lastTabFocusMiss == Nothing
                && List.isEmpty clearedMissEffects

        landmarksAndAriaLinksOk =
            initialSnap.skipLinkHref == "#main"
                && initialSnap.mainLandmarkId == "main"
                && initialSnap.mainLandmarkTabIndex == -1
                && initialSnap.mobileToggleDomId == "wl-mobile-nav-toggle"
                && initialSnap.mobileToggleAriaControls == initialSnap.mobileDrawerDomId
                && initialSnap.mobileDrawerDomId == "wl-home-nav-drawer"
                && initialSnap.heroPrimaryHref == "./test-drive/index.html"
                && initialSnap.heroPrimaryAriaDescribedBy == initialSnap.heroScopeNoteDomId
                && initialSnap.heroScopeNoteDomId == "hero-scope-note"

        ( uiControlsModel, uiControlsEffects ) =
            stepMany
                [ Site.SelectTheme Site.ThemeHighContrast
                , Site.ToggleMotion
                , Site.SelectCategory Site.CategoryAppsFiles
                , Site.ToggleWindowFocused
                , Site.ToggleActiveApplication
                , Site.ToggleSwitcherCandidate
                , Site.SelectOutcomeSample Site.SampleUnknown
                ]
                Site.initModel

        uiControlsSnap =
            Site.semanticSnapshot uiControlsModel

        uiControlsPureOk =
            uiControlsSnap.rootTheme == "high-contrast"
                && uiControlsSnap.rootMotion == "reduced"
                && uiControlsSnap.visibleCategoryCount == 2
                && uiControlsModel.cues == { windowFocused = False, activeApplication = False, switcherCandidate = True }
                && uiControlsModel.outcomeSample == Site.SampleUnknown
                && List.all List.isEmpty uiControlsEffects

        allCopyBlob =
            String.join " | "
                ([ initialSnap.heroScopeNoteText ]
                    ++ List.map (\t -> t.kicker ++ " " ++ t.summary) initialSnap.readinessTiers
                    ++ List.map (\s -> s.badge ++ " " ++ s.title ++ " " ++ s.summary ++ " " ++ s.ctaLabel ++ " " ++ s.ctaHref) initialSnap.onboardingSteps
                    ++ List.map (\c -> c.eyebrow ++ " " ++ c.title ++ " " ++ c.body ++ " " ++ c.ctaLabel ++ " " ++ c.ctaHref) initialSnap.scopeCards
                )

        honestCopyOk =
            String.contains "16 of 242" initialSnap.heroScopeNoteText
                && String.contains "40 of 417" initialSnap.heroScopeNoteText
                && String.contains "28-second" allCopyBlob
                && String.contains "unqualified" allCopyBlob
                && String.contains "Read source build instructions" allCopyBlob
                && List.length initialSnap.onboardingSteps == 3
                && not (String.contains "15 / 242" allCopyBlob)
                && not (String.contains "ELM-UI-007" allCopyBlob)
                && not (String.contains "run-omarchy-mvp" allCopyBlob)

        fullHistory =
            [ Site.ToggleMobileNav
            , Site.EscapeMobileNav
            , Site.KeyboardStepSpotlight 1
            , Site.KeyboardJumpSpotlight Site.SurfaceFiles
            , Site.FocusSettled 3 (Site.FocusWorkbenchTab Site.SurfaceFiles) (Ok ())
            , Site.SelectTheme Site.ThemeDawn
            , Site.ToggleMotion
            , Site.SelectCategory Site.CategoryWindows
            ]

        replayA =
            stepMany fullHistory Site.initModel

        replayB =
            stepMany fullHistory Site.initModel

        deterministicDoubleReplayOk =
            replayA == replayB
    in
    [ ( "InitialRovingTabIndexInvariant", rovingValidFor Site.SurfaceTaskbar initialSnap.workbenchTabs )
    , ( "TabpanelBidirectionalLinkInvariant", allTabpanelsLinked )
    , ( "DecodeWorkbenchKeysArrowAndHomeEnd", arrowAndHomeEndOk )
    , ( "TabKeyNotTrappedInTablist", tabNotTrappedOk )
    , ( "ArrowRightFull8StepWrapWithDomFocus", arrowRightWrapOk )
    , ( "ArrowLeftWrapTaskbarToFilesWithDomFocus", arrowLeftWrapOk )
    , ( "HomeAndEndKeysEmitExactTabFocus", homeAndEndOk )
    , ( "PointerStepAndSelectNoDuplicateDomFocusEffect", pointerNoFocusHijackOk )
    , ( "DecodeEscapeKeyAndRejectNonEscape", decodeEscapeOk )
    , ( "EscapeOpenMobileNavRestoresToggleFocus", escapeRestoresToggleFocusOk )
    , ( "EscapeClosedMobileNavIsPureNoOp", escapeWhenClosedNoOpOk )
    , ( "DrawerLinkCloseMobileNavPreservesTargetNavigation", drawerLinkCloseNoHijackOk )
    , ( "StaleFocusSettledRejected", staleFocusRejectedOk )
    , ( "CurrentFocusNotFoundRecordedWithoutReplay", currentFocusMissAndClearOk )
    , ( "SkipLinkAndMainLandmarkContract", landmarksAndAriaLinksOk )
    , ( "AppearanceMotionCategoryCueAndOutcomeTransitions", uiControlsPureOk )
    , ( "HonestLedgerAnd28sLiveVmComponentCopy", honestCopyOk )
    , ( "DeterministicDoubleReplay", deterministicDoubleReplayOk )
    ]


result : E.Value
result =
    let
        passedAll =
            List.all Tuple.second checks
    in
    E.object
        [ ( "passed", E.bool passedAll )
        , ( "totalChecks", E.int (List.length checks) )
        , ( "passedChecks", E.int (List.length (List.filter Tuple.second checks)) )
        , ( "checks", E.object (List.map (\( name, ok ) -> ( name, E.bool ok )) checks) )
        , ( "scope", E.string "Pure Elm semantic keyboard/focus, roving tabindex, Escape disclosure restoration, and runnable-MVP onboarding replay against SiteMain; live browser layout/contrast, assistive technology speech, and native Omarchy acceptance remain separate Root gates." )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing result )
        , update = \_ model -> ( model, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
