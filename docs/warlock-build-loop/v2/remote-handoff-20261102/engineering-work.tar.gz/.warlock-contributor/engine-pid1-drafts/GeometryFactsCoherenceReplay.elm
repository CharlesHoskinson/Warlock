port module GeometryFactsCoherenceReplay exposing (main)

{-| Unexecuted QA draft. The only issuer here is a synthetic fixture: literal
protocol-3 facts go through Shell.Incoming and the real GeometryProjection
coherence decoder. Neither capability advertisement nor a valid row grants
native/window authority. Root owns integration and all compilation/execution.
Requires the accompanying SnapReplay typed-capability migration. -}

import Binding
import Json.Decode as D
import Json.Encode as E
import Platform
import Shell
import SnapReplay
import UInt64

port outgoing : E.Value -> Cmd msg

counter : String -> UInt64.Counter
counter raw = D.decodeValue UInt64.decoder (E.string raw) |> Result.withDefault UInt64.zero

negotiate = E.object [("protocolVersion",E.int 3),("kind",E.string "host-geometry-negotiate")]
caps = E.object [("observe",E.bool True),("effects",E.bool True),("effectProtocol",E.int 2),("operations",E.list E.string ["snap"]),("placementCapacity",E.int 256),("canonicalScene",E.bool False)]
geometryAttached request = E.object [("protocolVersion",E.int 3),("kind",E.string "geometry-attached"),("geometryProtocol",E.int 3),("binding",SnapReplay.bound),("requestId",request),("capabilities",caps)]

projection logical visual configure = E.object [("logical",E.list E.float logical),("visual",visual),("real",E.list E.float logical),("configure",E.list E.float configure)]
sizePolicy = E.object
    [("inputs",E.object [("profile",E.string "wayland-zero-origin-v1"),("rawMinimum",E.list E.float [1,1]),("rawMaximum",E.list E.float [0,0]),("layoutMinimum",E.list E.float [1,1]),("layoutMaximum",E.list E.float [10000,10000]),("geometryOrigin",E.list E.float [0,0]),("reservedTopLeft",E.list E.float [0,0]),("reservedBottomRight",E.list E.float [0,0]),("monitorScale",E.float 1)])
    ,("maximize",projection [0,0,800,600] E.null [800,600]),("restoreGeometry",projection [10,20,320,240] (E.list E.float [10,20,320,240]) [320,240])]

type alias Row = {inc : String, owner : Maybe String, workspace : String, workspaceGeneration : String, monitor : String, outputGeneration : String, workRevision : String, eligible : Bool, maximize : Bool}
root : Row
root = {inc="1",owner=Nothing,workspace="1",workspaceGeneration="4",monitor="0",outputGeneration="2",workRevision="3",eligible=True,maximize=False}
child : Row
child = {root | inc="2",owner=Just "1",eligible=False}
row item = E.object
    [("incarnation",E.string item.inc),("owner",Maybe.map E.string item.owner |> Maybe.withDefault E.null)
    ,("workspace",E.string item.workspace),("workspaceGeneration",E.string item.workspaceGeneration),("monitor",E.string item.monitor)
    ,("outputOwnershipGeneration",E.string item.outputGeneration),("workAreaRevision",E.string item.workRevision),("workArea",E.list E.float [0,0,800,600])
    ,("logicalGeometry",E.list E.float [10,20,320,240]),("visualGeometry",E.list E.float [10,20,320,240])
    ,("nativeMode",E.string "ordinary"),("clientMode",E.string "ordinary"),("minimized",E.bool False),("floating",E.bool True),("grouped",E.bool False),("fixedSize",E.bool False),("constrainedSize",E.bool True)
    ,("geometryEligible",E.bool item.eligible),("ordinaryPlacementKnown",E.bool False),("capabilities",E.object [("maximize",E.bool item.maximize),("restoreGeometry",E.bool False)])
    ,("sizePolicy",sizePolicy),("pin",E.object [("pinned",E.bool False),("eligible",E.bool False)])]

facts owner request sequence rows = E.object
    [("protocolVersion",E.int 3),("kind",E.string "geometry-facts"),("geometryProtocol",E.int 3),("binding",owner),("requestId",request)
    ,("sequence",E.string sequence),("revision",E.string sequence),("outputGeneration",E.string "1")
    ,("facts",E.object [("focused",E.string "1"),("inputBlocked",E.bool False),("windows",E.list row rows)])]

resultFor binding =
    let given = (SnapReplay.readyFor binding).windows.shell
        base = {given | geometry=Nothing,geometryCaps=Nothing,geometryExpected=Nothing,geometryAttachExpected=Nothing,attachNeeded=False,decoderRefusal=Nothing}
        (attaching,_) = Shell.update (Shell.Incoming negotiate) base
        attachId = attaching.geometryAttachExpected |> Maybe.map (UInt64.string >> E.string) |> Maybe.withDefault E.null
        (awaiting,_) = Shell.update (Shell.Incoming (geometryAttached attachId)) attaching
        factId = awaiting.geometryExpected |> Maybe.map (UInt64.string >> E.string) |> Maybe.withDefault E.null
        attempt owner request sequence rows = Shell.update (Shell.Incoming (facts owner request sequence rows)) awaiting
        accepted sequence =
            let (after,commands) = attempt SnapReplay.bound factId sequence [root,child]
            in after.geometryExpected==Nothing && after.decoderRefusal==Nothing && List.isEmpty commands
                && (after.geometry |> Maybe.map (\snapshot -> snapshot.binding==binding && snapshot.sequence==counter sequence && snapshot.context.revision==counter sequence && List.length snapshot.windows==2) |> Maybe.withDefault False)
        refused rows =
            let (after,commands) = attempt SnapReplay.bound factId "1" rows
            in after.geometry==Nothing && after.geometryExpected==awaiting.geometryExpected && after.effects==awaiting.effects
                && after.decoderRefusal==Just "Native envelope rejected: malformed fields." && List.isEmpty commands
        malformed =
            [ ("duplicateIncarnationRefused",[root,{child | inc="1",owner=Nothing}])
            , ("selfOwnerRefused",[{root | owner=Just "1",eligible=False},child])
            , ("ownerCycleRefused",[{root | owner=Just "2",eligible=False},child])
            , ("missingOwnerRefused",[root,{child | owner=Just "9"}])
            , ("sameOutputGenerationDifferentMonitorRefused",[root,{child | monitor="1"}])
            , ("sameWorkspaceGenerationDifferentWorkspaceRefused",[root,{child | workspace="2"}])
            , ("sameWorkspaceGenerationDifferentWorkRevisionRefused",[root,{child | workRevision="9"}])
            , ("unnegotiatedMaximizeFlagRefused",[{root | maximize=True},child])
            ]
        foreign = E.object [("lifetime",E.string "1"),("session",E.string "2"),("frontend",E.string "1")]
        (foreignAfter,foreignEffects) = attempt foreign factId "1" [root,child]
        (wrongAfter,wrongEffects) = attempt SnapReplay.bound (E.string "999") "1" [root,child]
        checks =
            [("negotiationProducedFactsRequest",attaching.geometryAttachExpected/=Nothing && awaiting.geometryExpected/=Nothing && awaiting.geometryCaps/=Nothing)
            ,("coherentFullWidthSequencesAccepted",List.all accepted ["1","9007199254740993","18446744073709551615"])
            ,("foreignBindingDropsValidObservation",foreignAfter==awaiting && List.isEmpty foreignEffects)
            ,("wrongRequestDropsValidObservation",wrongAfter==awaiting && List.isEmpty wrongEffects)]
            ++ List.map (\(name,rows) -> (name,refused rows)) malformed
    in E.object [("checks",E.object (List.map (\(name,ok) -> (name,E.bool ok)) checks)),("scope",E.string "Synthetic protocol fixture through actual Shell.Incoming/GeometryProjection; no real issuer, native placement, compositor or original acceptance.")]

result = case D.decodeValue Binding.decoder SnapReplay.bound of
    Ok binding -> resultFor binding
    Err _ -> E.object [("checks",E.object [("literalBindingDecodes",E.bool False)])]

main : Program () () Never
main = Platform.worker {init=\_ -> ((),outgoing result),update=\_ state -> (state,Cmd.none),subscriptions=\_ -> Sub.none}
