{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY. Unexecuted source control using actual PersistentOwner and the
-- package-private QA hook. The local action is pure config-shaped data, not a
-- Store acquisition or a claim of process/provider cleanup. Keep Probe and
-- any real prepublished StoreOwner in the same live host on all uncertainty.
module PrelivePublicationFaultControls (Probe, newProbe, runPositive, runAdmissionFault, runAfterWriteFault, runAfterGateFault) where

import Control.Exception (SomeException, displayException, try)
import Control.Monad (unless)
import Data.IORef
import Data.List (isInfixOf)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent.Internal
 (PersistentOwner, PersistentStatus(..), StartupStage(..), StartupAdmissionFailure(..),
  newPersistentOwner, persistentStatus, withPersistentStartupPublicationTestHook)

data Probe = Probe PersistentOwner (IORef (Maybe String)) (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("publication fault: " ++ label)))
claim :: Probe -> IO ()
claim (Probe _ _ _ used) = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single use" fresh

runPositive :: Probe -> IO ()
runPositive p@(Probe owner target hooks _) = do
 claim p
 outcome <- withPersistentStartupPublicationTestHook (pure ()) (modifyIORef' hooks (+1)) (pure ()) owner target
  (pure (StartupReady "validated" :: StartupStage String String))
 slot <- readIORef target
 count <- readIORef hooks
 status <- persistentStatus owner
 check "delivered success and actual value" $
  outcome == Right (Right ()) && slot == Just "validated" && count == 1 && status == PersistentAvailable

runAfterWriteFault :: Probe -> IO ()
runAfterWriteFault p@(Probe owner target hooks _) = do
 claim p
 result <- try (withPersistentStartupPublicationTestHook (pure ())
  (modifyIORef' hooks (+1) >> ioError (userError "injected after target write")) (pure ()) owner target
  (pure (StartupReady "unconfirmed" :: StartupStage String String)))
  :: IO (Either SomeException (Either StartupAdmissionFailure (Either String ())))
 slot <- readIORef target
 count <- readIORef hooks
 status <- persistentStatus owner
 check "fault is delivered and target is retained, not an authority receipt" $
  (case result of Left e -> "injected after target write" `isInfixOf` displayException e; Right _ -> False)
  && slot == Just "unconfirmed" && count == 1
  && (case status of PersistentQuarantined _ -> True; _ -> False)
 replay <- withPersistentStartupPublicationTestHook (pure ())
  (modifyIORef' hooks (+100)) (pure ()) owner target
  (pure (StartupReady "must-not-run" :: StartupStage String String))
 countAfter <- readIORef hooks
 check "quarantined owner refuses replay before callback" $
  replay == Left (StartupAdmissionRefused OwnerBusy) && countAfter == 1

-- Synthetic failure after registration but before phase publication. The
-- action was never entered; the owner remains quarantined, not reusable.
runAdmissionFault :: Probe -> IO ()
runAdmissionFault p@(Probe owner target hooks _) = do
 claim p
 result <- try (withPersistentStartupPublicationTestHook
  (modifyIORef' hooks (+1) >> ioError (userError "injected after admission"))
  (modifyIORef' hooks (+10)) (pure ()) owner target
  (modifyIORef' hooks (+100) >> pure (StartupReady "must-not-run" :: StartupStage String String)))
  :: IO (Either SomeException (Either StartupAdmissionFailure (Either String ())))
 slot <- readIORef target
 count <- readIORef hooks
 status <- persistentStatus owner
 check "interrupted admission preserves refusal and quarantine" $
  (case result of Left e -> "injected after admission" `isInfixOf` displayException e; Right _ -> False)
  && slot == Nothing && count == 1
  && (case status of PersistentQuarantined _ -> True; _ -> False)
 replay <- withPersistentStartupPublicationTestHook (pure ()) (pure ()) (pure ()) owner target
  (modifyIORef' hooks (+1000) >> pure (StartupReady "must-not-run" :: StartupStage String String))
 after <- readIORef hooks
 check "interrupted admission cannot be replayed" $
  replay == Left (StartupAdmissionRefused OwnerBusy) && after == 1

-- Gate is already published at this hook; owner phase still excludes all
-- public startup entries. The test does not claim the gate was reclosed.
runAfterGateFault :: Probe -> IO ()
runAfterGateFault p@(Probe owner target hooks _) = do
 claim p
 result <- try (withPersistentStartupPublicationTestHook (pure ()) (pure ())
  (modifyIORef' hooks (+1) >> ioError (userError "injected after gate commit")) owner target
  (pure (StartupReady "unconfirmed" :: StartupStage String String)))
  :: IO (Either SomeException (Either StartupAdmissionFailure (Either String ())))
 slot <- readIORef target
 count <- readIORef hooks
 status <- persistentStatus owner
 check "post-gate exception keeps slot unconfirmed and owner quarantined" $
  (case result of Left e -> "injected after gate commit" `isInfixOf` displayException e; Right _ -> False)
  && slot == Just "unconfirmed" && count == 1
  && (case status of PersistentQuarantined _ -> True; _ -> False)
 replay <- withPersistentStartupPublicationTestHook (pure ()) (pure ()) (pure ()) owner target
  (modifyIORef' hooks (+100) >> pure (StartupReady "must-not-run" :: StartupStage String String))
 after <- readIORef hooks
 check "post-gate exception cannot replay owner" $
  replay == Left (StartupAdmissionRefused OwnerBusy) && after == 1
