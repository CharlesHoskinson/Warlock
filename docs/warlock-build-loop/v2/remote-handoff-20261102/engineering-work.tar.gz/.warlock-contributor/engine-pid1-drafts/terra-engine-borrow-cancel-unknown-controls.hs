{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, unexecuted. Build held-document in isolation with
-- -DWARLOCK_BORROW_QA and the separate QA seam; never ship the seam.
-- acquireAndRetain must publish each independently resolver-issued HeldExecutable
-- into Root's registry before returning. In particular the deliberately poisoned
-- held object and its descriptor must remain retained; no unknown close/retry.
module BorrowCancelUnknownControls (Probe, newProbe, probeRetained, runPositive, runCancellation, runUnknown) where

import Control.Concurrent (ThreadId, forkFinally, killThread, yield)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import GHC.Conc (ThreadStatus(..), BlockReason(..), threadStatus)
import System.Timeout (timeout)
import Warlock.Platform.Executable.Internal
 (HeldExecutable, borrowHeldInterruptible, qaHoldHeldGate, qaForceHeldUnknown,
  qaHeldBorrowCount)

-- Root retains Probe and each held capability before starting any worker.
data Probe = Probe { heldRef :: IORef (Maybe HeldExecutable), holderRef :: IORef (Maybe ThreadId),
 releaseThread :: IORef (Maybe ThreadId), killerRef :: IORef (Maybe ThreadId),
 releaseCap :: IORef (Maybe (IO Bool)), legacyCap :: IORef (Maybe (IO ())),
 holderDone :: MVar (Either SomeException ()), releaseDone :: MVar (Either SomeException Bool),
 killerDone :: MVar (Either SomeException ()), used :: IORef Bool }
newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
                 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False

-- Retain this Probe in Root throughout; actions are capabilities, not receipts.
-- Never invoke either action on unknown custody.
probeRetained :: Probe -> IO (Maybe HeldExecutable, Maybe (IO Bool), Maybe (IO ()))
probeRetained p = (,,) <$> readIORef (heldRef p) <*> readIORef (releaseCap p) <*> readIORef (legacyCap p)

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("borrow QA: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 2000000 action >>= maybe (ioError (userError (label ++ ": retain all fixture owners"))) pure
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

-- Existing retained references must outlive all completion callbacks. The Root
-- fixture owns disposal only after independently proving safe descriptor custody.
-- Acquisition and publication run masked as one capability transfer; the
-- caller publishes the held object before its fallible acquisition returns.
prepare :: Probe -> IO HeldExecutable -> IO (HeldExecutable, IO Bool)
prepare probe acquireAndRetain = mask $ \restore -> do
 already <- atomicModifyIORef' (used probe) (\x -> (True,x))
 check "one-shot probe" (not already)
 held <- restore acquireAndRetain
 writeIORef (heldRef probe) (Just held)
 (_, releaseNow, legacyRelease) <- must =<< borrowHeldInterruptible held
 writeIORef (releaseCap probe) (Just releaseNow)
 writeIORef (legacyCap probe) (Just legacyRelease)
 pure (held, releaseNow)

runPositive :: Probe -> IO HeldExecutable -> IO ()
runPositive probe acquireAndRetain = do
 (held, releaseNow) <- prepare probe acquireAndRetain
 before <- qaHeldBorrowCount held
 once <- releaseNow
 twice <- releaseNow
 after <- qaHeldBorrowCount held
 check "proven release decrements exactly once" (before == Just 1 && once && twice && after == Just 0)

runCancellation :: Probe -> IO HeldExecutable -> IO ()
runCancellation probe acquireAndRetain = mask $ \restore -> do
 (held, releaseNow) <- prepare probe acquireAndRetain
 gateEntered <- newEmptyMVar
 unlock <- newEmptyMVar
 let finish = do
       void (tryPutMVar unlock ())
       mh <- readIORef (holderRef probe)
       mr <- readIORef (releaseThread probe)
       mk <- readIORef (killerRef probe)
       case mh of Nothing -> pure (); Just _ -> void (timeout 2000000 (readMVar (holderDone probe)))
       case mr of Nothing -> pure (); Just _ -> void (timeout 2000000 (readMVar (releaseDone probe)))
       case mk of Nothing -> pure (); Just _ -> void (timeout 2000000 (readMVar (killerDone probe)))
     run = do
       _ <- mask_ $ do
        holderTid <- forkFinally (restore (qaHoldHeldGate held (putMVar gateEntered ()) (readMVar unlock))) (putMVar (holderDone probe))
        writeIORef (holderRef probe) (Just holderTid)
        pure holderTid
       within "holder acquired real gate" (readMVar gateEntered)
       tid <- mask_ $ do
        worker <- forkFinally (restore releaseNow) (putMVar (releaseDone probe))
        writeIORef (releaseThread probe) (Just worker)
        pure worker
       -- ThreadBlocked is sampled only while this fixture holds the real gate;
       -- no other thread owns this borrow's release cell. Thus this is not just
       -- an acknowledgement that the worker was started.
       let awaitBlocked = do
            status <- threadStatus tid
            case status of
             ThreadBlocked BlockedOnMVar -> pure ()
             ThreadFinished -> ioError (userError "release returned while gate held")
             ThreadDied -> ioError (userError "release died before blocked observation")
             _ -> yield >> awaitBlocked
       within "release blocked on held gate" awaitBlocked
       _ <- mask_ $ do
        worker <- forkFinally (killThread tid) (putMVar (killerDone probe))
        writeIORef (killerRef probe) (Just worker)
        pure worker
       stopped <- within "blocked release accepts cancellation" (readMVar (releaseDone probe))
       _ <- within "cancellation delivery returned" (readMVar (killerDone probe))
       check "release observed cancellation" (case stopped of Left _ -> True; Right _ -> False)
       void (tryPutMVar unlock ())
       _ <- within "holder returned" (readMVar (holderDone probe))
       intact <- qaHeldBorrowCount held
       released <- within "retry after cancellation" releaseNow
       finalCount <- qaHeldBorrowCount held
       check "cancellation preserved borrow and retry decremented once"
        (intact == Just 1 && released && finalCount == Just 0)
 restore run `finally` finish

runUnknown :: Probe -> IO HeldExecutable -> IO ()
runUnknown probe acquireAndRetain = do
 (held, releaseNow) <- prepare probe acquireAndRetain
 before <- qaHeldBorrowCount held
 qaForceHeldUnknown held
 first <- within "uncertain release" releaseNow
 second <- within "repeated uncertain release" releaseNow
 after <- within "retained uncertain held state" (qaHeldBorrowCount held)
 check "unknown remains unknown and both release receipts refuse"
  (before == Just 1 && not first && not second && after == Nothing)
 -- Do not call legacy release, retireHeld or any close on this unknown object.
