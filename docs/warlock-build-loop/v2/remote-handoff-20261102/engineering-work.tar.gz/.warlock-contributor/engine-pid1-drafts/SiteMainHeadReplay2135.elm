port module SiteMainHeadReplay2135 exposing (main)

import Browser.Dom as Dom
import Json.Decode as Decode
import Json.Encode as Encode
import Platform
import SiteMain
    exposing
        ( AppearanceTheme(..)
        , FocusTarget(..)
        , Model
        , MotionMode(..)
        , Msg(..)
        , SurfaceCategory(..)
        , SurfaceId(..)
        )


port replayReport : Encode.Value -> Cmd msg


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), replayReport buildReport )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }


type alias CheckResult =
    { name : String
    , passed : Bool
    , detail : String
    }


expectedOrderedSurfaces : List ( SurfaceId, String )
expectedOrderedSurfaces =
    [ ( SurfaceTaskbar, "wl-tab-taskbar" )
    , ( SurfaceLauncher, "wl-tab-launcher" )
    , ( SurfaceSwitcher, "wl-tab-switcher" )
    , ( SurfaceTaskView, "wl-tab-task-view" )
    , ( SurfaceSnap, "wl-tab-snap" )
    , ( SurfaceNotifications, "wl-tab-notifications" )
    , ( SurfaceSettings, "wl-tab-settings" )
    , ( SurfaceFiles, "wl-tab-files" )
    ]


initialModel : Model
initialModel =
    Tuple.first (SiteMain.init ())


decodeJson : Decode.Decoder a -> String -> Result Decode.Error a
decodeJson =
    Decode.decodeString


validateTabTargetList : List String -> Bool
validateTabTargetList ids =
    List.length ids == 8 && uniqueCount ids == 8


uniqueCount : List String -> Int
uniqueCount items =
    case items of
        [] ->
            0

        first :: rest ->
            if List.member first rest then
                uniqueCount rest

            else
                1 + uniqueCount rest


stepEightRight : Int -> Model -> List ( SurfaceId, List FocusTarget )
stepEightRight remaining current =
    if remaining <= 0 then
        []

    else
        let
            ( next, effects ) =
                SiteMain.transition (KeyboardStepSpotlight 1) current
        in
        ( next.spotlight, effects ) :: stepEightRight (remaining - 1) next


allChecks : List CheckResult
allChecks =
    [ let
        m =
            initialModel
      in
      { name = "initDefaultsNightStandardClosedTaskbar"
      , passed =
            (m.theme == ThemeNight)
                && (m.motion == MotionStandard)
                && (m.mobileNavOpen == False)
                && (m.spotlight == SurfaceTaskbar)
                && (m.tabFocusSeq == 0)
                && (m.lastTabFocusMiss == Nothing)
                && (m.category == CategoryAll)
      , detail = "Initial homepage model starts on Night, Standard motion, closed mobile drawer, and Taskbar spotlight."
      }
    , let
        ( opened, openFx ) =
            SiteMain.transition ToggleMobileNav initialModel

        ( escaped, escFx ) =
            SiteMain.transition EscapeMobileNav opened
      in
      { name = "escapeWhenDrawerOpenClosesAndFocusesToggle"
      , passed =
            opened.mobileNavOpen
                && (openFx == [])
                && (escaped.mobileNavOpen == False)
                && (escaped.tabFocusSeq == 1)
                && (escFx == [ FocusElement "wl-home-nav-toggle" ])
                && (SiteMain.mobileNavToggleDomId == "wl-home-nav-toggle")
      , detail = "Escape while mobile drawer is open closes drawer and emits FocusElement wl-home-nav-toggle."
      }
    , let
        ( untouched, fx ) =
            SiteMain.transition EscapeMobileNav initialModel
      in
      { name = "escapeWhenDrawerClosedIsPureNoOp"
      , passed = (untouched == initialModel) && (fx == [])
      , detail = "Escape while mobile drawer is closed neither increments tabFocusSeq nor steals focus."
      }
    , let
        ( opened, _ ) =
            SiteMain.transition ToggleMobileNav initialModel

        ( closedByLink, linkFx ) =
            SiteMain.transition CloseMobileNav opened
      in
      { name = "closeMobileNavOnLinkClickDoesNotStealFocus"
      , passed = (closedByLink.mobileNavOpen == False) && (closedByLink.tabFocusSeq == 0) && (linkFx == [])
      , detail = "Primary nav link click closes drawer without competing Dom.focus task."
      }
    , let
        steps =
            stepEightRight 8 initialModel

        expectedSequence =
            [ ( SurfaceLauncher, [ FocusElement "wl-tab-launcher" ] )
            , ( SurfaceSwitcher, [ FocusElement "wl-tab-switcher" ] )
            , ( SurfaceTaskView, [ FocusElement "wl-tab-task-view" ] )
            , ( SurfaceSnap, [ FocusElement "wl-tab-snap" ] )
            , ( SurfaceNotifications, [ FocusElement "wl-tab-notifications" ] )
            , ( SurfaceSettings, [ FocusElement "wl-tab-settings" ] )
            , ( SurfaceFiles, [ FocusElement "wl-tab-files" ] )
            , ( SurfaceTaskbar, [ FocusElement "wl-tab-taskbar" ] )
            ]
      in
      { name = "keyboardStepRightWrapsAllEightTabsAndEmitsFocus"
      , passed = steps == expectedSequence
      , detail = "ArrowRight/ArrowDown wraps deterministically across all 8 tabs with exact Dom.focus targets."
      }
    , let
        ( wrappedLeft, fxLeft ) =
            SiteMain.transition (KeyboardStepSpotlight -1) initialModel
      in
      { name = "keyboardStepLeftFromTaskbarWrapsToFilesAndEmitsFocus"
      , passed =
            (wrappedLeft.spotlight == SurfaceFiles)
                && (wrappedLeft.tabFocusSeq == 1)
                && (fxLeft == [ FocusElement "wl-tab-files" ])
      , detail = "ArrowLeft from Taskbar wraps to Files and focuses wl-tab-files."
      }
    , let
        ( jumpedEnd, fxEnd ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceFiles) initialModel

        ( jumpedHome, fxHome ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceTaskbar) jumpedEnd
      in
      { name = "keyboardHomeAndEndJumpAndEmitExactFocusTargets"
      , passed =
            (jumpedEnd.spotlight == SurfaceFiles)
                && (fxEnd == [ FocusElement "wl-tab-files" ])
                && (jumpedHome.spotlight == SurfaceTaskbar)
                && (fxHome == [ FocusElement "wl-tab-taskbar" ])
                && (jumpedHome.tabFocusSeq == 2)
      , detail = "Home and End jump to first/last workbench tab and emit matching FocusElement."
      }
    , let
        ( clicked, clickFx ) =
            SiteMain.transition (SelectSpotlight SurfaceSnap) initialModel

        ( stepped, stepFx ) =
            SiteMain.transition (StepSpotlight 1) clicked
      in
      { name = "pointerSelectAndStepDoNotEmitProgrammaticFocus"
      , passed =
            (clicked.spotlight == SurfaceSnap)
                && (clickFx == [])
                && (stepped.spotlight == SurfaceNotifications)
                && (stepFx == [])
      , detail = "Pointer tab selection and Previous/Next buttons update spotlight without stealing keyboard focus."
      }
    , let
        ( moved, _ ) =
            SiteMain.transition (KeyboardJumpSpotlight SurfaceFiles) initialModel

        ( afterStale, _ ) =
            SiteMain.transition (FocusSettled 999 "wl-tab-files" (Err (Dom.NotFound "wl-tab-files"))) moved

        ( afterWrongId, _ ) =
            SiteMain.transition (FocusSettled moved.tabFocusSeq "wl-tab-taskbar" (Err (Dom.NotFound "wl-tab-taskbar"))) afterStale

        ( afterMiss, _ ) =
            SiteMain.transition (FocusSettled moved.tabFocusSeq "wl-tab-files" (Err (Dom.NotFound "wl-tab-files"))) afterWrongId

        ( afterOk, _ ) =
            SiteMain.transition (FocusSettled moved.tabFocusSeq "wl-tab-files" (Ok ())) afterMiss
      in
      { name = "focusSettledGuardsSequenceAndTargetIdentity"
      , passed =
            (afterStale.lastTabFocusMiss == Nothing)
                && (afterWrongId.lastTabFocusMiss == Nothing)
                && (afterMiss.lastTabFocusMiss == Just "wl-tab-files")
                && (afterOk.lastTabFocusMiss == Nothing)
      , detail = "FocusSettled ignores stale sequence or non-current target IDs and records/clears matching Dom.NotFound."
      }
    , let
        escMinimal =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\"}"

        escValid =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":false,\"keyCode\":27}"

        tabMinimal =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowRight\"}"

        tabValid =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"Home\",\"isComposing\":false,\"keyCode\":36}"
      in
      { name = "missingOptionalFieldsDefaultCleanlyOnEscapeAndWorkbench"
      , passed =
            (escMinimal == Ok EscapeMobileNav)
                && (escValid == Ok EscapeMobileNav)
                && (tabMinimal == Ok ( KeyboardStepSpotlight 1, True ))
                && (tabValid == Ok ( KeyboardJumpSpotlight SurfaceTaskbar, True ))
      , detail = "Genuinely missing optional fields default to non-composing (False / 0), and valid non-composing events succeed."
      }
    , let
        escNullComposing =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":null}"

        escNullKeyCode =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"keyCode\":null}"

        tabNullComposing =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowRight\",\"isComposing\":null}"

        tabNullKeyCode =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"End\",\"keyCode\":null}"
      in
      { name = "explicitNullOptionalFieldsStrictlyRejected"
      , passed =
            isErr escNullComposing
                && isErr escNullKeyCode
                && isErr tabNullComposing
                && isErr tabNullKeyCode
      , detail = "Present explicit JSON null on isComposing or keyCode fails strict missing-only decoding."
      }
    , let
        escStringBool =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":\"false\"}"

        escNumberBool =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":0}"

        tabStringInt =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowLeft\",\"keyCode\":\"37\"}"

        tabFloatInt =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowLeft\",\"keyCode\":37.5}"
      in
      { name = "wrongTypedOptionalFieldsStrictlyRejected"
      , passed =
            isErr escStringBool
                && isErr escNumberBool
                && isErr tabStringInt
                && isErr tabFloatInt
      , detail = "Present wrong-typed non-null values on isComposing or keyCode fail decoding instead of silently defaulting."
      }
    , let
        escIme =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":true,\"keyCode\":27}"

        tabIme =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowRight\",\"isComposing\":true,\"keyCode\":39}"
      in
      { name = "imeComposingTrueRejectedOnEscapeAndWorkbench"
      , passed = isErr escIme && isErr tabIme
      , detail = "Active IME composition (isComposing=true) is rejected on both Escape and workbench keys."
      }
    , let
        esc229 =
            decodeJson (SiteMain.decodeEscapeKey EscapeMobileNav) "{\"key\":\"Escape\",\"isComposing\":false,\"keyCode\":229}"

        tab229 =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"ArrowDown\",\"isComposing\":false,\"keyCode\":229}"

        processKey =
            decodeJson SiteMain.decodeNonComposingKey "{\"key\":\"Process\",\"isComposing\":false,\"keyCode\":0}"
      in
      { name = "imeKeyCode229AndProcessKeyRejected"
      , passed = isErr esc229 && isErr tab229 && isErr processKey
      , detail = "IME keyCode 229 and Process key are rejected across keyboard decoders."
      }
    , let
        tabForward =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"Tab\",\"isComposing\":false,\"keyCode\":9}"

        tabReverse =
            decodeJson SiteMain.decodeWorkbenchTabKey "{\"key\":\"Tab\",\"shiftKey\":true,\"isComposing\":false,\"keyCode\":9}"
      in
      { name = "tabAndShiftTabLeaveWorkbenchUntrapped"
      , passed = isErr tabForward && isErr tabReverse
      , detail = "Tab and Shift+Tab fail decodeWorkbenchTabKey so preventDefaultOn never traps browser tab order."
      }
    , let
        ( dawnModel, _ ) =
            SiteMain.transition (SelectTheme ThemeDawn) initialModel

        ( hcModel, _ ) =
            SiteMain.transition (SelectTheme ThemeHighContrast) dawnModel

        ( reducedModel, _ ) =
            SiteMain.transition ToggleMotion hcModel
      in
      { name = "themeAndMotionTransitionsPreserveSpotlightAndCues"
      , passed =
            (dawnModel.theme == ThemeDawn)
                && (hcModel.theme == ThemeHighContrast)
                && (reducedModel.motion == MotionReduced)
                && (reducedModel.spotlight == initialModel.spotlight)
                && (reducedModel.cues == initialModel.cues)
      , detail = "Theme (Night/Dawn/HighContrast) and ReducedMotion transitions preserve spotlight and cue state."
      }
    , let
        ids =
            List.map (\( sid, _ ) -> SiteMain.surfaceTabDomId sid) expectedOrderedSurfaces

        expectedIds =
            List.map Tuple.second expectedOrderedSurfaces

        doc =
            SiteMain.viewDocument initialModel
      in
      { name = "surfaceTabIdsAndDocumentContractExact"
      , passed =
            (ids == expectedIds)
                && validateTabTargetList ids
                && String.contains "Warlock" doc.title
                && (List.length doc.body == 1)
      , detail = "All 8 surfaceTabDomId values match exact wl-tab-* contract and viewDocument produces single root view."
      }
    , let
        duplicateMutation =
            [ "wl-tab-taskbar", "wl-tab-taskbar", "wl-tab-switcher", "wl-tab-task-view", "wl-tab-snap", "wl-tab-notifications", "wl-tab-settings", "wl-tab-files" ]

        truncatedMutation =
            List.take 7 (List.map Tuple.second expectedOrderedSurfaces)
      in
      { name = "validatorSensitivityRejectsBrokenTabTargetMutations"
      , passed = not (validateTabTargetList duplicateMutation) && not (validateTabTargetList truncatedMutation)
      , detail = "Negative control confirms tab-ID uniqueness/cardinality validator rejects duplicate or missing tabs."
      }
    ]


isErr : Result e a -> Bool
isErr res =
    case res of
        Ok _ ->
            False

        Err _ ->
            True


buildReport : Encode.Value
buildReport =
    let
        passedCount =
            List.length (List.filter .passed allChecks)

        totalCount =
            List.length allChecks
    in
    Encode.object
        [ ( "suite", Encode.string "SiteMainHeadReplay2135" )
        , ( "targetPreimageGitBlob", Encode.string "a18279ecd6ddf2678cf1fdd5f9732aaa58959a75" )
        , ( "targetPostimageGitBlob", Encode.string "2a56dc0841d72bd6f4ea2a5088e89264a126a39e" )
        , ( "allPassed", Encode.bool (passedCount == totalCount) )
        , ( "passedCount", Encode.int passedCount )
        , ( "totalCount", Encode.int totalCount )
        , ( "checks"
          , Encode.list
                (\c ->
                    Encode.object
                        [ ( "name", Encode.string c.name )
                        , ( "passed", Encode.bool c.passed )
                        , ( "detail", Encode.string c.detail )
                        ]
                )
                allChecks
          )
        ]
