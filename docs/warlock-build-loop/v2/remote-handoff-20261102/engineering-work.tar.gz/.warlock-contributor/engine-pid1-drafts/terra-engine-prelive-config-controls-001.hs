{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Actual PersistentOwner/CallbackGate control; the
-- action represents a retained pre-live config acquisition, not Store I/O.
-- Root must retain each Probe and its preowned actual StoreOwner separately.
-- No new application deadline, native effect, or cleanup receipt is implied.
module PreliveConfigControls
 (Probe, newProbe, runPositive, runStoppedBefore, runStopDuring,
  runConcurrent, runException) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_, try)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), StopReceipt(..), StartupAdmissionFailure(..),
  newPersistentOwner, persistentStatus, requestSessionStop, stopBudgetMicros,
  withPersistentStartupPublication)

type Result = Either SomeException (Either StartupAdmissionFailure ())
data Probe = Probe PersistentOwner (IORef (Maybe String)) (IORef (Maybe String))
 (IORef (Maybe ThreadId)) (MVar Bool) (MVar ()) (MVar ()) (MVar Result)
 (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("prelive config: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and host"))) pure
begin :: Probe -> IO ()
begin (Probe _ _ _ _ _ _ _ _ _ used) = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single-use Probe" fresh

runPositive :: Probe -> IO ()
runPositive p@(Probe owner target _ _ _ _ _ _ calls _) = do
 begin p
 result <- withPersistentStartupPublication owner target $ do
  modifyIORef' calls (+1)
  pure (Right "validated" :: Either String String)
 value <- readIORef target
 count <- readIORef calls
 check "one admitted action publishes exact value" (result == Right () && value == Just "validated" && count == 1)
 again <- withPersistentStartupPublication owner target $ do
  modifyIORef' calls (+1)
  pure (Right "replay" :: Either String String)
 after <- readIORef calls
 check "occupied target refuses replay before action" (again == Left (StartupAdmissionRefused OwnerBusy) && after == 1)

runStoppedBefore :: Probe -> IO ()
runStoppedBefore p@(Probe owner target _ _ _ _ _ _ calls _) = do
 begin p
 budget <- need (stopBudgetMicros 1000000)
 receipt <- requestSessionStop owner budget
 result <- withPersistentStartupPublication owner target $ do
  modifyIORef' calls (+1)
  pure (Right "unexpected" :: Either String String)
 value <- readIORef target
 count <- readIORef calls
 check "first stop wins before config entry" $
  receipt == StopLatchedBeforeLive && result == Left (StartupAdmissionRefused SessionClosed) && value == Nothing && count == 0

runStopDuring, runConcurrent :: Probe -> IO ()
runStopDuring = runHeld True
runConcurrent = runHeld False
runHeld :: Bool -> Probe -> IO ()
runHeld stopFirst p@(Probe owner target other worker decision entered resume done calls _) = mask $ \restore -> do
 begin p
 let action = do
      modifyIORef' calls (+1)
      putMVar entered ()
      readMVar resume
      pure (Right "validated" :: Either String String)
     finish = do
      void (tryPutMVar resume ())
      tid <- readIORef worker
      case tid of Nothing -> pure (); Just _ -> void (tryPutMVar decision False) >> void (timeout 3000000 (readMVar done))
     body = do
      _ <- mask_ $ do
       tid <- forkFinally (do
        allowed <- readMVar decision
        if allowed then restore (withPersistentStartupPublication owner target action)
         else ioError (userError "worker cancelled before publication")) (putMVar done)
       writeIORef worker (Just tid)
       putMVar decision True
       pure tid
      within "actual action entered" (readMVar entered)
      if stopFirst then do
       budget <- need (stopBudgetMicros 1000000)
       receipt <- requestSessionStop owner budget
       check "same owner latched first stop" (receipt == StopLatchedBeforeLive)
      else do
       competing <- withPersistentStartupPublication owner other $ do
        modifyIORef' calls (+100)
        pure (Right "competing" :: Either String String)
       check "concurrent pre-live action refused before entry" (competing == Left (StartupAdmissionRefused OwnerBusy))
      void (tryPutMVar resume ())
      result <- within "actual action result" (readMVar done)
      value <- readIORef target
      count <- readIORef calls
      if stopFirst then do
       phase <- persistentStatus owner
       check "stop during entered action prevents config publication" $
        value == Nothing && count == 1 &&
        (case result of Right (Left StartupAdmissionUnknown) -> True; _ -> False) &&
        (case phase of PersistentQuarantined _ -> True; _ -> False)
      else check "uncontended original action publishes exactly once" $
       value == Just "validated" && count == 1 && case result of Right (Right ()) -> True; _ -> False
 restore body `finally` finish

runException :: Probe -> IO ()
runException p@(Probe owner target _ _ _ _ _ _ calls _) = do
 begin p
 outcome <- try (withPersistentStartupPublication owner target $ do
  modifyIORef' calls (+1)
  ioError (userError "injected acquisition failure") :: IO (Either String String))
  :: IO (Either SomeException (Either StartupAdmissionFailure ()))
 value <- readIORef target
 count <- readIORef calls
 phase <- persistentStatus owner
 check "thrown acquisition is not a clean publication" $
  value == Nothing && count == 1 && (case outcome of Left _ -> True; _ -> False) &&
  (case phase of PersistentQuarantined _ -> True; _ -> False)
