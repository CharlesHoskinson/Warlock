{-# LANGUAGE ForeignFunctionInterface #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- PREPARATION DRAFT: uncompiled, untested, not linked or accepted.
-- Proposed protocol-package PUBLIC owner facade; it uses private recvmsg/ancillary reader
-- and existing bounded outer-frame parser, not a new process executor.
-- EngineCustody is the sole reaper. Its trusted guard must close over the
-- actual owned host PID and pidfd, expected mapped UID/GID, endpoint identity,
-- original absolute deadline D, and admission/retirement state. A caller PID,
-- socketpair SO_PEERCRED, JSON or a cookie is never an identity authority.
-- Child PIDns receiver may see its outside parent as PID 0; this receiver is
-- broker-side only, refuses PID 0, and does NOT positively authenticate parent.
module Warlock.Protocol.EngineCredentials.Draft
  ( EngineOwner, EngineFailure(..), GuardFailure(..), SendOutcome(..)
  , OfferResult(..), OwnerStatus(..), newEngineOwner, offerEngineSocket
  , receiveOwnedFrame, sendOwnedFrame, retireEngineOwner, engineOwnerStatus ) where

#define _GNU_SOURCE 1
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/uio.h>
import Control.Concurrent.MVar (MVar, newMVar, withMVar, modifyMVar, readMVar)
import Control.Exception (IOException, SomeException, SomeAsyncException, fromException, mask, throwIO, try)
import Data.Bits ((.|.))
import qualified Data.ByteString as B
import Data.IORef (IORef, newIORef, readIORef, writeIORef)
import Foreign
import Foreign.C
import qualified Network.Socket as S
import System.Posix.IO (getFdOption, FdOption(CloseOnExec))
import System.Posix.Types (Fd(..))
import System.Timeout (timeout)
import Warlock.Protocol.CredentialGuard (CredentialGuard(..))
import qualified Warlock.Transport.PeerCredentials as P
import Warlock.Transport.Frame (FrameError, headerLengthWithLimit, prefixWithLimit)

foreign import ccall unsafe "sendmsg" c_sendmsg :: CInt -> Ptr () -> CInt -> IO (#{type ssize_t})
foreign import ccall unsafe "getsockopt" c_getsockopt :: CInt -> CInt -> CInt -> Ptr CInt -> Ptr (#{type socklen_t}) -> IO CInt

-- Maximum inner frame from the engine protocol; outer header adds 4 bytes.
-- Length is checked before body collection/allocation; max recv chunk is the
-- existing reader's 65536-byte limit, not a single socket packet size.
engineLimit :: Int
engineLimit = 393732
chunkLimit :: Int
chunkLimit = 65536

data GuardFailure refusal = InvisiblePid | Refused refusal deriving (Show)
data EngineFailure refusal
  = InvalidSocket | ReceiverRetired | DeadlineExpired | StreamEnded
  | BadFrame FrameError | CredentialRejected P.CredentialError
  | CredentialChanged | CredentialRefused (GuardFailure refusal)
  | CallbackOrTransportException deriving (Show)
data SendOutcome = Sent | SendWouldBlock | SendUncertain deriving (Eq,Show)

-- Exclusively borrowed socket from its sole lifecycle owner, no competing
-- readers or close/replacement. SO_PASSCRED must be enabled *before* any sender
-- byte can enter the stream; checking the current option cannot prove history.
-- Both endpoint ownership and actual original D are integration obligations.
data EngineReceiver refusal = EngineReceiver
  !S.Socket !P.CredentialReader !(CredentialGuard refusal)
  !(IO Int) !(B.ByteString -> IO ()) !(MVar ()) !(MVar ()) !(IORef Bool)

-- Opaque public owner: no raw reader, peer-credential constructor, socket,
-- descriptor or process handle escapes. Accepted ownership is published before
-- offer returns; on asynchronous exception caller must query this SAME owner
-- before doing anything to the socket. Refused offer leaves ownership with the
-- caller. A producer must never close/reuse an accepted socket independently.
data OfferResult = OfferAccepted | OfferRefused | OfferInvalid deriving (Eq,Show)
data OwnerStatus = Empty | Live | Retiring | Closing | Closed | CloseUnknown deriving (Eq,Show)
data EngineOwner refusal = EngineOwner !(MVar (OwnerStatus,Maybe (EngineReceiver refusal)))
newEngineOwner :: IO (EngineOwner refusal)
newEngineOwner = EngineOwner <$> newMVar (Empty,Nothing)
engineOwnerStatus :: EngineOwner refusal -> IO OwnerStatus
engineOwnerStatus (EngineOwner state) = fst <$> readMVar state

socketReady :: S.Socket -> IO Bool
socketReady sock = do
 address <- S.getSocketName sock
 (kind, passcred, cloexec) <- S.withFdSocket sock $ \fd -> do
   let option name = alloca $ \pValue -> alloca $ \pLen -> do
        poke pValue 0
        poke pLen (fromIntegral (sizeOf (undefined :: CInt)))
        rc <- c_getsockopt fd #{const SOL_SOCKET} name pValue pLen
        len <- peek pLen
        val <- peek pValue
        pure (rc == 0 && len == fromIntegral (sizeOf (undefined :: CInt)), val)
   (validType, typ) <- option #{const SO_TYPE}
   (validPass, pass) <- option #{const SO_PASSCRED}
   closeOnExec <- getFdOption (Fd fd) CloseOnExec
   pure (validType && typ == #{const SOCK_STREAM}, validPass && pass == 1, closeOnExec)
 pure $ kind && passcred && cloexec && case address of S.SockAddrUnix _ -> True; _ -> False

-- Internal owner-only composition. CredentialGuard is a control-flow
-- interface, not authentication by itself. `remaining` is microseconds until
-- original D, never a renewed timeout. `onEvent` must decode/check the bounded
-- payload and deliver only a read-only immutable notification: arbitrary IO
-- is not made safe by this type. Existing broker policy alone grants effects.
newEngineReceiver :: S.Socket -> CredentialGuard refusal -> IO Int -> (B.ByteString -> IO ())
                  -> IO (Either (EngineFailure refusal) (EngineReceiver refusal))
newEngineReceiver sock guard remaining onEvent = do
 checked <- try (socketReady sock) :: IO (Either IOException Bool)
 case checked of
  Right True -> do
   reader <- P.newCredentialReader
   gate <- newMVar ()
   writeGate <- newMVar ()
   dead <- newIORef False
   pure (Right (EngineReceiver sock reader guard remaining onEvent gate writeGate dead))
  _ -> pure (Left InvalidSocket)

-- Creation/validation happens while the caller owns the socket. The masked
-- state publication is the ownership transfer; exactly one exclusive caller
-- may offer and exactly one offer is accepted.
-- Ownership after a pending/ambiguous exception must be resolved by consulting
-- this owner, not by a second closer. Existing production owner publication
-- and exception paths need adaptation and independent review before use.
offerEngineSocket :: EngineOwner refusal -> S.Socket -> CredentialGuard refusal
                  -> IO Int -> (B.ByteString -> IO ()) -> IO OfferResult
offerEngineSocket (EngineOwner state) sock guard remaining onEvent = mask $ \restore -> do
  prepared <- restore (newEngineReceiver sock guard remaining onEvent)
  case prepared of
   Left _ -> pure OfferInvalid
   Right receiver -> modifyMVar state $ \old@(status,_) ->
    if status == Empty then pure ((Live,Just receiver),OfferAccepted)
    else pure (old,OfferRefused)

-- `retire` must first revoke the EngineCustody admission scope, so a receiver
-- racing between this snapshot and its read cannot gain a new callback lease.
-- A prior admitted callback is drained as required by that same owner.
receiveOwnedFrame :: EngineOwner refusal -> IO (Either (EngineFailure refusal) ())
receiveOwnedFrame (EngineOwner state) = do
 (status,receiver) <- readMVar state
 case (status,receiver) of
  (Live,Just active) -> receiveEngineFrame active
  _ -> pure (Left ReceiverRetired)

-- One writer, separate from the read gate, so a reply may be sent after an
-- admitted read. Recheck lifecycle inside the writer gate: a stale Live
-- snapshot cannot send after retirement. Unknown partial send publishes
-- Retiring and requires the owner to revoke custody and close without replay.
sendOwnedFrame :: EngineOwner refusal -> B.ByteString -> IO SendOutcome
sendOwnedFrame (EngineOwner state) bytes = do
 (_,receiver) <- readMVar state
 case receiver of
  Nothing -> pure SendUncertain
  Just (EngineReceiver sock _ _ remaining _ _ writeGate dead) ->
   withMVar writeGate $ \_ -> mask $ \restore -> do
    (status,_) <- readMVar state
    poisoned <- readIORef dead
    if status /= Live || poisoned then pure SendUncertain else do
     result <- try (restore (sendEngineFrame sock remaining bytes)) :: IO (Either SomeException SendOutcome)
     case result of
      Right Sent -> pure Sent
      Right SendWouldBlock -> pure SendWouldBlock
      other -> do
       -- Publish quarantine without waiting on a lock before any further
       -- interruptible state publication. Both read and write reject it.
       writeIORef dead True
       _ <- modifyMVar state $ \old@(current,r) ->
        if current == Live then pure ((Retiring,r),()) else pure (old,())
       case other of
        Left exception -> case fromException exception :: Maybe SomeAsyncException of
         Just _ -> throwIO exception
         Nothing -> pure SendUncertain
        _ -> pure SendUncertain

-- Idempotent owner retirement; revoke the custody guard BEFORE calling this.
-- Waiting for an active receiver is interruptible. Retiring is already
-- published, retains the owner and may be revisited under original D. After
-- claiming Closing, any interrupted/failed close is uncertain and NEVER retried
-- by numeric descriptor. Caller must bound waiting, handle in-flight callbacks,
-- and retain/report Retiring/Closing/CloseUnknown rather than claim cleanup.
retireEngineOwner :: EngineOwner refusal -> IO OwnerStatus
retireEngineOwner (EngineOwner state) = mask $ \restore -> do
 selected <- modifyMVar state $ \old@(status,receiver) -> case status of
  Empty -> pure ((Closed,Nothing),Nothing)
  Live -> pure ((Retiring,receiver),receiver)
  Retiring -> pure (old,receiver)
  _ -> pure (old,Nothing)
 case selected of
  Nothing -> fst <$> readMVar state
  Just (EngineReceiver sock _ _ _ _ gate writeGate _) -> do
   withMVar gate $ \_ -> withMVar writeGate $ \_ -> do
    claimed <- modifyMVar state $ \old@(status,receiver) ->
     if status == Retiring then pure ((Closing,receiver),True) else pure (old,False)
    if not claimed then fst <$> readMVar state else do
     result <- try (restore (S.close sock)) :: IO (Either SomeException ())
     let final = either (const CloseUnknown) (const Closed) result
     _ <- modifyMVar state $ \(_,receiver) -> pure ((final,receiver),())
     case result of
      Left exception -> case fromException exception :: Maybe SomeAsyncException of
       Just _ -> throwIO exception
       Nothing -> pure final
      Right () -> pure final

-- Every header/body recvmsg fragment must have one actual SCM_CREDENTIALS,
-- match the first credential for this frame, and pass the real custody guard.
-- The retained existing reader rejects truncation, malformed/duplicate or
-- missing credentials and rights, and keeps its descriptor quarantine ledger.
-- No PID 0 may pass in the broker receiver. After a complete bounded frame,
-- admission must recheck owner/child/pidfd/endpoint/D and serialize retirement.
-- A live observation is not a promise that child cannot die a moment later.
-- EOF, invalid input, refused admission, D, or uncertainty poisons this reader;
-- sole owner retires endpoint exactly once and never replays unknown work.
receiveEngineFrame :: forall refusal. EngineReceiver refusal -> IO (Either (EngineFailure refusal) ())
receiveEngineFrame (EngineReceiver sock reader guard remaining onEvent gate _ dead) =
 withMVar gate $ \_ -> mask $ \restore -> do
  retired <- readIORef dead
  if retired then pure (Left ReceiverRetired) else do
   let poison = writeIORef dead True
       readPieces :: Int -> Maybe P.PeerCredential -> [B.ByteString]
                  -> IO (Either (EngineFailure refusal) (B.ByteString,P.PeerCredential))
       readPieces need first chunks
        | need == 0 = case first of
            Nothing -> pure (Left StreamEnded)
            Just credential -> pure (Right (B.concat (reverse chunks),credential))
        | otherwise = do
            left <- remaining
            if left <= 0 then pure (Left DeadlineExpired) else do
             incoming <- P.receiveCredentialChunk reader sock (min need chunkLimit)
             case incoming of
              Left err -> pure (Left (CredentialRejected err))
              Right P.EndOfStream -> pure (Left StreamEnded)
              Right (P.CredentialChunk bytes credential)
               | P.peerPid credential <= 0 -> pure (Left (CredentialRefused InvisiblePid))
               | B.null bytes || B.length bytes > need -> pure (Left StreamEnded)
               | maybe False (/= credential) first -> pure (Left CredentialChanged)
               | otherwise -> do
                   approved <- checkFragment guard credential
                   case approved of
                    Left err -> pure (Left (CredentialRefused (Refused err)))
                    Right () -> readPieces (need - B.length bytes) (Just credential) (bytes:chunks)
       frame = do
        header <- readPieces 4 Nothing []
        case header of
         Left err -> pure (Left err)
         Right (raw,credential) -> case headerLengthWithLimit engineLimit raw of
          Left err -> pure (Left (BadFrame err))
          Right size -> do
           body <- readPieces size (Just credential) []
           case body of
            Left err -> pure (Left err)
            Right (bytes,finalCredential) -> do
             left <- remaining
             if left <= 0 then pure (Left DeadlineExpired) else do
              admitted <- withCredentialAdmission guard finalCredential (onEvent bytes)
              pure $ either (Left . CredentialRefused . Refused) Right admitted
   outcome <- try (restore $ do
      left <- remaining
      if left <= 0 then pure (Left DeadlineExpired) else do
       result <- timeout left frame
       pure (maybe (Left DeadlineExpired) id result))
       :: IO (Either SomeException (Either (EngineFailure refusal) ()))
   case outcome of
    Left exception -> do
     poison
     case fromException exception :: Maybe SomeAsyncException of
      Just _ -> throwIO exception
      Nothing -> pure (Left CallbackOrTransportException)
    Right (Left failure) -> poison >> pure (Left failure)
    Right (Right ()) -> pure (Right ())

-- One framed send over a STREAM, no SCM_RIGHTS or caller-provided credentials.
-- Guarded one-at-a-time by the owning sender and bounded by the original D.
-- `SendWouldBlock` is safe only if ZERO bytes were written. Any partial frame,
-- deadline or socket error returns `SendUncertain`. An exception can escape
-- after partial progress: the owner must classify that as uncertain as well,
-- retire the channel without replay and never start the frame again.
-- This draft does not implement a queue, blocking retry loop, or PID authority.
sendEngineFrame :: S.Socket -> IO Int -> B.ByteString -> IO SendOutcome
sendEngineFrame sock remaining body = case prefixWithLimit engineLimit body of
 Left _ -> pure SendUncertain
 Right framed -> mask $ \_ -> S.withFdSocket sock $ \fd ->
  B.useAsCStringLen framed $ \(base,total) -> do
   let loop offset = do
        left <- remaining
        if left <= 0 then pure SendUncertain else
         allocaBytes #{size struct msghdr} $ \msg -> allocaBytes #{size struct iovec} $ \iov -> do
          fillBytes msg 0 #{size struct msghdr}
          fillBytes iov 0 #{size struct iovec}
          #{poke struct iovec, iov_base} iov (castPtr (base `plusPtr` offset) :: Ptr ())
          #{poke struct iovec, iov_len} iov (fromIntegral (total-offset) :: CSize)
          #{poke struct msghdr, msg_iov} msg (castPtr iov :: Ptr ())
          #{poke struct msghdr, msg_iovlen} msg (1 :: CSize)
          sent <- c_sendmsg fd (castPtr msg) (#{const MSG_DONTWAIT} .|. #{const MSG_NOSIGNAL})
          if sent > 0 then let next = offset + fromIntegral sent
            in if next == total then pure Sent else if next < total then loop next else pure SendUncertain
          else if sent < 0 then do
            errno <- getErrno
            pure $ if offset == 0 && (errno == eAGAIN || errno == eWOULDBLOCK)
              then SendWouldBlock else SendUncertain
          else pure SendUncertain
   loop 0
