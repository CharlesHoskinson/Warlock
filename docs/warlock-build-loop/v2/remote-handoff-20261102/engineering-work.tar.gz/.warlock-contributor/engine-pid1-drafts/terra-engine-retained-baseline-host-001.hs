{-# LANGUAGE RankNTypes #-}
-- ROOT ONLY, UNEXECUTED. Runs the nine barrier-corrected baseline test
-- modules inside the caller's existing same-process retained QA host. This
-- adapter is not a guardian, process supervisor or evidence of cleanup.
module TerraRetainedBaselineHost (Host(..), runBaselineControls) where

import Control.Exception (mask)
import Warlock.Capture.Process.Persistent (PersistentOwner, newPersistentOwner)
import Warlock.Platform.Executable (HeldExecutable)
import qualified PreownedStopGateBusyControls as BeforeBorrow
import qualified PostborrowStopGateBusyControls as AfterBorrow
import qualified ReservationStopGateControls as ReserveBusy
import qualified ReservationExpiredFreeControls as ReserveExpired
import qualified PreownedStopReleaseControls as StopRelease
import qualified PreownedExceptionControls as Exceptions
import qualified HeldPreownedStatusControls as Held
import qualified SecurityFinalStopRaceControls as FinalStop
import qualified SecurityFinishGateBusyControls as FinishGates

-- The host registers a strong root before keep returns and keeps it through
-- failure, cancellation and timeout until an independently justified disposal.
-- acquire pins verified fixture ancestry and the resolver guard before issuing
-- its HeldExecutable; its returned object is pre-retained by the same host.
-- Root separately owns a guardian for any child, including expected no-spawn.
data Host = Host
 { keep :: forall a. a -> IO ()
 , acquire :: PersistentOwner -> IO HeldExecutable
 }

runBaselineControls :: Host -> IO ()
runBaselineControls host = do
 owned BeforeBorrow.newProbe BeforeBorrow.runStopGateBusy
 owned AfterBorrow.newProbe AfterBorrow.runPostborrowStopGateBusy
 owned ReserveBusy.newProbe ReserveBusy.runReservationStopGateBusy
 owned ReserveExpired.newProbe ReserveExpired.runExpiredFree
 owned StopRelease.newProbe StopRelease.runNoStop
 owned StopRelease.newProbe StopRelease.runLateStop
 owned Exceptions.newProbe Exceptions.runSyncFault
 owned Exceptions.newProbe Exceptions.runAsyncCancel
 owned Exceptions.newProbe Exceptions.runStopAfterNoAcquire
 owned FinalStop.newProbe FinalStop.runNoStop
 owned FinalStop.newProbe FinalStop.runLateStop
 owned FinishGates.newProbe FinishGates.runRawBusy
 owned FinishGates.newProbe FinishGates.runPhaseBusy
 owned FinishGates.newProbe FinishGates.runStopBusy
 borrow Held.newProbe Held.runPositive
 borrow Held.newProbe Held.runCancel
 borrow Held.newProbe Held.runInterrupted
 where
  owned :: IO p -> (p -> (PersistentOwner -> IO HeldExecutable) -> IO ()) -> IO ()
  owned make action = mask $ \restore -> do
   probe <- make
   keep host probe
   restore (action probe (acquire host))
  borrow :: IO p -> (p -> IO HeldExecutable -> IO ()) -> IO ()
  borrow make action = mask $ \restore -> do
   owner <- newPersistentOwner
   keep host owner
   probe <- make
   keep host probe
   restore (action probe (acquire host owner))
