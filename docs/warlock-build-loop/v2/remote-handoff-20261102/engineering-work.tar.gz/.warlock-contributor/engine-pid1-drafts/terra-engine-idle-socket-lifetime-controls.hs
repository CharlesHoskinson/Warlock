-- Root-only source fixture. AF_UNIX readiness/retire seam only; no SCM,
-- selected-child/pidfd, native, provider cleanup or scenario acceptance.
-- Root must compile the draft module with -DWARLOCK_IDLE_TEST.
-- It has not been compiled or run by the source author.
module Main (main) where

import Control.Concurrent (ThreadId, forkFinally, newEmptyMVar, putMVar, readMVar)
import Control.Concurrent.STM (atomically, retry)
import Control.Exception (SomeException, mask_)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import GHC.Clock (getMonotonicTimeNSec)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Timeout (timeout)
import Warlock.Transport.IdleSocketLifetime

-- Keep owner/socket and worker strongly retained on every uncertain path; this
-- local fixture registry does not prove product quarantine or survive exit.
-- Empty registry cells are published before resource acquisition. Acquisition
-- and worker publication stay masked, so async cancellation cannot strand a
-- returned pair or a newly forked worker outside the retained cells.
data Retained = Retained (IORef (Maybe (S.Socket, S.Socket)))
                         (IORef (Maybe IdleSocketLifetime)) (IORef [ThreadId])
type Registry = IORef [Retained]
fixture :: Registry -> IO (IdleSocketLifetime, S.Socket, S.Socket, IORef [ThreadId])
fixture registry = mask_ $ do
  sockets <- newIORef Nothing
  owner <- newIORef Nothing
  workers <- newIORef []
  atomicModifyIORef' registry (\xs -> (Retained sockets owner workers : xs, ()))
  (owned, peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  writeIORef sockets (Just (owned, peer))
  gate <- newIdleSocketLifetime owned (S.close owned)
  writeIORef owner (Just gate)
  pure (gate, owned, peer, workers)

start :: IORef [ThreadId] -> IO a -> IO (IO (Either SomeException a))
start workers action = mask_ $ do
  done <- newEmptyMVar
  tid <- forkFinally action (putMVar done)
  atomicModifyIORef' workers (\xs -> (tid : xs, ()))
  pure (readMVar done)

checkIO :: String -> Bool -> IO ()
checkIO label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 2000000 action >>= maybe (ioError (userError label)) pure
future :: Integer -> IO Integer
future ns = (+ ns) . toInteger <$> getMonotonicTimeNSec
receiveExactly :: S.Socket -> Int -> IO B.ByteString
receiveExactly sock = go [] where
  go chunks 0 = pure (B.concat (reverse chunks))
  go chunks n = do
    part <- N.recv sock n
    if B.null part then ioError (userError "unexpected EOF")
      else go (part : chunks) (n - B.length part)

main :: IO ()
main = do
  registry <- newIORef []
  -- Real registered socket: stream bytes remain intact and exactly one close
  -- follows its deregistration. No assertion that readability proves a frame.
  (gate1, owned1, peer1, workers1) <- fixture registry
  probe1 <- newIdleTestProbe
  done1 <- start workers1 (waitIdleWithProbe gate1 probe1 retry :: IO (Maybe (IdleWake ())))
  within "registration" (atomically (probeRegisteredSTM probe1))
  releaseTestProbe probe1
  N.sendAll peer1 (B.pack [11,22,33])
  wake1 <- within "readiness" done1
  checkIO "readable" (case wake1 of Right (Just SocketReadable) -> True; _ -> False)
  bytes <- within "preserved bytes" (receiveExactly owned1 3)
  checkIO "nonconsuming" (bytes == B.pack [11,22,33])
  deadline1 <- future 1000000000
  result1 <- retireIdleSocket gate1 deadline1
  permit1 <- case result1 of Drained p -> pure p; _ -> ioError (userError "drain failed")
  closed1 <- closeAfterDrain permit1
  duplicate <- closeAfterDrain permit1
  checkIO "single close" (closed1 == CloseCompleted && duplicate == ClosePermitUsed)
  S.close peer1

  -- Registered quiet wait must wake on retirement and unregister before permit.
  (gate2, _owned2, peer2, workers2) <- fixture registry
  probe2 <- newIdleTestProbe
  done2 <- start workers2 (waitIdleWithProbe gate2 probe2 retry :: IO (Maybe (IdleWake ())))
  within "quiet registration" (atomically (probeRegisteredSTM probe2))
  releaseTestProbe probe2
  deadline2 <- future 1000000000
  result2 <- within "retirement" (retireIdleSocket gate2 deadline2)
  permit2 <- case result2 of Drained p -> pure p; _ -> ioError (userError "quiet drain failed")
  wake2 <- within "retire wake" done2
  checkIO "retire wake" (case wake2 of Right (Just IdleRetiring) -> True; _ -> False)
  closed2 <- closeAfterDrain permit2
  checkIO "quiet close" (closed2 == CloseCompleted)
  S.close peer2

  -- Retirement before registration rejects a later waiter before it can touch
  -- the socket. Its registration probe must therefore remain unset.
  (gate3, _owned3, peer3, _workers3) <- fixture registry
  deadline3 <- future 1000000000
  result3 <- retireIdleSocket gate3 deadline3
  permit3 <- case result3 of Drained p -> pure p; _ -> ioError (userError "early drain failed")
  probe3 <- newIdleTestProbe
  late <- waitIdleWithProbe gate3 probe3 retry :: IO (Maybe (IdleWake ()))
  registered3 <- timeout 10000 (atomically (probeRegisteredSTM probe3))
  checkIO "retire before wait" (case late of Nothing -> registered3 == Nothing; _ -> False)
  closed3 <- closeAfterDrain permit3
  checkIO "early close" (closed3 == CloseCompleted)
  S.close peer3

  -- A blocked registration probe deliberately withholds its borrow until after
  -- D. No permit or guessed close; even after release there is no second retire.
  (gate4, _owned4, _peer4, workers4) <- fixture registry
  probe4 <- newIdleTestProbe
  done4 <- start workers4 (waitIdleWithProbe gate4 probe4 retry :: IO (Maybe (IdleWake ())))
  within "blocked registration" (atomically (probeRegisteredSTM probe4))
  deadline4 <- future 30000000
  result4 <- retireIdleSocket gate4 deadline4
  checkIO "blocked drain must timeout" (case result4 of DrainTimedOut -> True; _ -> False)
  releaseTestProbe probe4
  _ <- within "blocked worker release" done4
  again <- retireIdleSocket gate4 deadline4
  checkIO "no re-retirement" (case again of DrainAlreadyStarted -> True; _ -> False)
  -- gate4 and both sockets intentionally remain strongly retained in registry.
  retained <- readIORef registry
  checkIO "fixture registry retained" (length retained == 4)
  putStrLn "idle socket lifetime source controls passed"
