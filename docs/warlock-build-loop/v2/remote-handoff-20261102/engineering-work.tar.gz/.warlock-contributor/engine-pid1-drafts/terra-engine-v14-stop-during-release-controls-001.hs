{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY unexecuted direct-route fixture. Requires v14 and both BORROW_QA
-- seams, resolver-held supplier, verified fixture ancestors and a separate
-- Root-owned guardian for every case (including expected-no-spawn cases).
-- The caller roots Probe and the supplied HeldExecutable before execution.
-- Timeout leaves Probe/worker/custody retained and is never a clean receipt.
module StopDuringReleaseControls (Probe, newProbe, runNoStop, runLateStop) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import Data.List (isPrefixOf)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 ( PersistentOwner, PersistentStatus(..), SessionExit(..), StopReceipt(..)
 , StopDeadlineObservation(..), newPersistentOwner, persistentStatus
 , persistentUnderlyingStatus, persistentHeldNoInput, requestSessionStop
 , startBudgetAfter, startBudgetDeadline, stopBudgetMicros
 , tryPersistentStopDeadline )
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)
import Warlock.Platform.Executable (HeldExecutable)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe
 { owner :: PersistentOwner, held :: IORef (Maybe HeldExecutable)
 , worker :: IORef (Maybe ThreadId), done :: MVar Result
 , retained :: MVar (), resumeRetained :: MVar ()
 , releaseEntered :: MVar (), resumeRelease :: MVar ()
 , spawnCalls :: IORef Int, used :: IORef Bool }

newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newIORef 0 <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("stop-during-release: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and owned guardian"))) pure
awaitExpiry :: AdmissionDeadline -> IO ()
awaitExpiry deadline = do
 left <- remainingMicros deadline
 if left <= 0 then pure () else threadDelay (min 1000 left) >> awaitExpiry deadline

runNoStop, runLateStop :: Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runNoStop = runCase False
runLateStop = runCase True

runCase :: Bool -> Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runCase lateStop p acquireAndRetain = mask $ \restore -> do
 already <- atomicModifyIORef' (used p) (\v -> (True,v))
 check "single-use probe" (not already)
 let hook stage
      | stage == "qa-startup-borrow-retained" = putMVar (retained p) () >> readMVar (resumeRetained p)
      | "qa-before-held-borrow-release:" `isPrefixOf` stage = putMVar (releaseEntered p) () >> readMVar (resumeRelease p)
      | stage == "persistent-before-spawn" = atomicModifyIORef' (spawnCalls p) (\n -> (n+1,()))
      | otherwise = pure ()
     finish = do
      void (tryPutMVar (resumeRetained p) ())
      void (tryPutMVar (resumeRelease p) ())
      child <- readIORef (worker p)
      case child of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar (done p)))
     run = do
      lease <- restore (acquireAndRetain (owner p))
      writeIORef (held p) (Just lease)
      selection <- need (persistentHeldNoInput lease [] [("LANG","C"),("LC_ALL","C")])
      start <- startBudgetAfter 1000000 >>= need
      configuredStop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally
        (restore (withPersistentOwnerHook (owner p) selection 4096 start configuredStop
          (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook))
        (putMVar (done p))
       writeIORef (worker p) (Just tid)
       pure tid
      within "actual borrow retained" (readMVar (retained p))
      within "original startup deadline expires" (awaitExpiry (startBudgetDeadline start))
      void (tryPutMVar (resumeRetained p) ())
      within "actual bounded release entered" (readMVar (releaseEntered p))
      if lateStop then do
       budget <- need (stopBudgetMicros 40000)
       receipt <- requestSessionStop (owner p) budget
       first <- tryPersistentStopDeadline (owner p)
       check "stop latched while release is in flight" (receipt == StopLatchedBeforeLive)
       stopD <- case first of
        StopDeadlineLatched d -> pure d
        _ -> ioError (userError "stop deadline unavailable: preserve Unknown")
       within "same stop deadline expires" (awaitExpiry stopD)
       again <- tryPersistentStopDeadline (owner p)
       check "immutable stop deadline" (again == StopDeadlineLatched stopD)
      else pure ()
      void (tryPutMVar (resumeRelease p) ())
      result <- within "owner result" (readMVar (done p))
      spawns <- readIORef (spawnCalls p)
      phase <- persistentStatus (owner p)
      raw <- persistentUnderlyingStatus (owner p)
      check "never entered spawn" (spawns == 0)
      if lateStop then
       check "late stop cannot claim in-deadline clean retirement" $
        case result of
         Right (Left (ExitUncertain _ _)) -> case (phase,raw) of
          (PersistentQuarantined _,Quarantined _) -> True
          _ -> False
         _ -> False
      else
       check "no-stop pre-spawn expiry positive control" $
        phase == PersistentRetired && raw == Available &&
        case result of Right (Left (StartupRefused TimedOut)) -> True; _ -> False
 restore run `finally` finish
