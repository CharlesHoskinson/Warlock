port module TeaSiteMainSubscriptionsReplay exposing (main)

{-| QA-only single-root observer for the 9th Browser.element root (SiteMain + SiteBetaStatus)
under ELM-TEA-004 (`0655` gated pendingFocus + PendingFocusFrame subscription lifecycle).
Complete SiteMain.Model (including pendingFocus and opaque child SiteBetaStatus.Model),
complete SiteMain.subscriptionPlan (`[]` <-> `[ PendingFocusFrame ]`), and complete typed
SiteMain.SiteEffect lists pass unchanged through one Debug.log point.
Production SiteMain and SiteBetaStatus remain 100% Debug-free.
All inputs are fixture data; native, browser, and release behavior are separate.
-}

import Browser.Dom as Dom
import Json.Decode as D
import Json.Encode as E
import Platform
import SiteBetaStatus
import SiteMain


port incoming : (D.Value -> msg) -> Sub msg


port outgoing : E.Value -> Cmd msg


type alias ObservedState =
    { model : SiteMain.Model
    , subscriptions : List SiteMain.SiteSubscription
    }


type StepEffects
    = ResetEffects
    | SiteStepEffects (List SiteMain.SiteEffect)


type Msg
    = Input D.Value


type Command
    = Reset
    | KeyboardStep Int
    | SelectSpotlight SiteMain.SurfaceId
    | StepSpotlight Int
    | FlushPendingFocus
    | TabFocusSettled Int SiteMain.SurfaceId (Maybe String)
    | ToggleMobileNav
    | CloseMobileNav
    | EscapeMobileNav
    | MobileNavFocusSettled Int (Maybe String)
    | BetaSelectFilter SiteBetaStatus.TierFilter
    | BetaKeyboardStepMvp Int


type alias Request =
    { caseId : String
    , step : Int
    , command : Command
    }


strict : List String -> D.Decoder a -> D.Decoder a
strict fields child =
    D.keyValuePairs D.value
        |> D.andThen
            (\pairs ->
                if List.sort (List.map Tuple.first pairs) == List.sort fields then
                    child

                else
                    D.fail "unexpected command fields"
            )


surfaceIdDecoder : D.Decoder SiteMain.SurfaceId
surfaceIdDecoder =
    D.string
        |> D.andThen
            (\raw ->
                case raw of
                    "taskbar" ->
                        D.succeed SiteMain.SurfaceTaskbar

                    "launcher" ->
                        D.succeed SiteMain.SurfaceLauncher

                    "switcher" ->
                        D.succeed SiteMain.SurfaceSwitcher

                    "task-view" ->
                        D.succeed SiteMain.SurfaceTaskView

                    "snap" ->
                        D.succeed SiteMain.SurfaceSnap

                    "notifications" ->
                        D.succeed SiteMain.SurfaceNotifications

                    "settings" ->
                        D.succeed SiteMain.SurfaceSettings

                    "files" ->
                        D.succeed SiteMain.SurfaceFiles

                    _ ->
                        D.fail "unsupported surface"
            )


tierFilterDecoder : D.Decoder SiteBetaStatus.TierFilter
tierFilterDecoder =
    D.string
        |> D.andThen
            (\raw ->
                case raw of
                    "all" ->
                        D.succeed SiteBetaStatus.FilterAll

                    "whole" ->
                        D.succeed SiteBetaStatus.FilterWholeAccepted

                    "runtime" ->
                        D.succeed SiteBetaStatus.FilterRuntimeAndTrials

                    "native-gates" ->
                        D.succeed SiteBetaStatus.FilterOpenNativeGates

                    _ ->
                        D.fail "unsupported filter"
            )


focusOutcomeFromMaybe : Maybe String -> Result Dom.Error ()
focusOutcomeFromMaybe maybeMissing =
    case maybeMissing of
        Nothing ->
            Ok ()

        Just missingId ->
            Err (Dom.NotFound missingId)


requestDecoder : D.Decoder Request
requestDecoder =
    let
        nonnegative =
            D.int |> D.andThen (\value -> if value >= 0 then D.succeed value else D.fail "negative step")

        caseId =
            D.string |> D.andThen (\value -> if String.isEmpty value then D.fail "empty caseId" else D.succeed value)

        request fields command =
            strict ("caseId" :: "step" :: "kind" :: fields)
                (D.map3 Request (D.field "caseId" caseId) (D.field "step" nonnegative) command)
    in
    D.field "kind" D.string
        |> D.andThen
            (\kind ->
                case kind of
                    "reset" ->
                        request [] (D.succeed Reset)

                    "keyboard-step" ->
                        request [ "delta" ] (D.map KeyboardStep (D.field "delta" D.int))

                    "select-spotlight" ->
                        request [ "surface" ] (D.map SelectSpotlight (D.field "surface" surfaceIdDecoder))

                    "step-spotlight" ->
                        request [ "delta" ] (D.map StepSpotlight (D.field "delta" D.int))

                    "flush-pending-focus" ->
                        request [] (D.succeed FlushPendingFocus)

                    "tab-focus-settled" ->
                        request [ "seq", "surface", "missingDomId" ]
                            (D.map3 TabFocusSettled
                                (D.field "seq" nonnegative)
                                (D.field "surface" surfaceIdDecoder)
                                (D.field "missingDomId" (D.nullable D.string))
                            )

                    "toggle-mobile-nav" ->
                        request [] (D.succeed ToggleMobileNav)

                    "close-mobile-nav" ->
                        request [] (D.succeed CloseMobileNav)

                    "escape-mobile-nav" ->
                        request [] (D.succeed EscapeMobileNav)

                    "mobile-nav-focus-settled" ->
                        request [ "seq", "missingDomId" ]
                            (D.map2 MobileNavFocusSettled
                                (D.field "seq" nonnegative)
                                (D.field "missingDomId" (D.nullable D.string))
                            )

                    "beta-select-filter" ->
                        request [ "filter" ] (D.map BetaSelectFilter (D.field "filter" tierFilterDecoder))

                    "beta-keyboard-step-mvp" ->
                        request [ "delta" ] (D.map BetaKeyboardStepMvp (D.field "delta" D.int))

                    _ ->
                        D.fail "unsupported command"
            )


ack : String -> Int -> Bool -> String -> Cmd Msg
ack caseId step ok reason =
    outgoing
        (E.object
            [ ( "caseId", E.string caseId )
            , ( "step", E.int step )
            , ( "ok", E.bool ok )
            , ( "error", E.string reason )
            ]
        )


observe : Request -> SiteMain.Model -> StepEffects -> ( SiteMain.Model, Cmd Msg )
observe request model effects =
    let
        observed : ObservedState
        observed =
            { model = model
            , subscriptions = SiteMain.subscriptionPlan model
            }

        ( capturedState, _ ) =
            Debug.log "TEA_SUBSCRIPTIONS_OBSERVE_V1" ( observed, effects )
    in
    ( capturedState.model, ack request.caseId request.step True "" )


applySiteMsg : Request -> SiteMain.Msg -> SiteMain.Model -> ( SiteMain.Model, Cmd Msg )
applySiteMsg request siteMsg model =
    let
        ( nextModel, siteEffects ) =
            SiteMain.step siteMsg model
    in
    observe request nextModel (SiteStepEffects siteEffects)


update : Msg -> SiteMain.Model -> ( SiteMain.Model, Cmd Msg )
update (Input raw) model =
    case D.decodeValue requestDecoder raw of
        Err problem ->
            let
                caseId =
                    D.decodeValue (D.field "caseId" D.string) raw |> Result.withDefault ""

                step =
                    D.decodeValue (D.field "step" D.int) raw |> Result.withDefault -1
            in
            ( model, ack caseId step False (D.errorToString problem) )

        Ok request ->
            case request.command of
                Reset ->
                    observe request SiteMain.initialModel ResetEffects

                KeyboardStep delta ->
                    applySiteMsg request (SiteMain.KeyboardStepSpotlight delta) model

                SelectSpotlight surfaceId ->
                    applySiteMsg request (SiteMain.SelectSpotlight surfaceId) model

                StepSpotlight delta ->
                    applySiteMsg request (SiteMain.StepSpotlight delta) model

                FlushPendingFocus ->
                    applySiteMsg request SiteMain.FlushPendingFocus model

                TabFocusSettled seq surfaceId maybeMissing ->
                    applySiteMsg
                        request
                        (SiteMain.TabFocusSettled seq surfaceId (focusOutcomeFromMaybe maybeMissing))
                        model

                ToggleMobileNav ->
                    applySiteMsg request SiteMain.ToggleMobileNav model

                CloseMobileNav ->
                    applySiteMsg request SiteMain.CloseMobileNav model

                EscapeMobileNav ->
                    applySiteMsg request SiteMain.EscapeMobileNav model

                MobileNavFocusSettled seq maybeMissing ->
                    applySiteMsg
                        request
                        (SiteMain.MobileNavFocusSettled seq (focusOutcomeFromMaybe maybeMissing))
                        model

                BetaSelectFilter chosenFilter ->
                    applySiteMsg
                        request
                        (SiteMain.BetaStatusMsg (SiteBetaStatus.SelectTierFilter chosenFilter))
                        model

                BetaKeyboardStepMvp delta ->
                    applySiteMsg
                        request
                        (SiteMain.BetaStatusMsg (SiteBetaStatus.KeyboardStepMvpTrack delta))
                        model


main : Program () SiteMain.Model Msg
main =
    Platform.worker
        { init = \_ -> ( SiteMain.initialModel, Cmd.none )
        , update = update
        , subscriptions = \_ -> incoming Input
        }
