# Compiled Three-Role Elm Visual & Accessibility Audit + Live Screenshot Readiness

- **Author**: `gemini-gui` (`warlock-20261031-setup`)
- **Coordinator**: `lead` (Root)
- **Status**: **Preparation audit & screenshot-inspection readiness only** (`nativeAcceptance = false`, `guiAcceptance = false`, `releaseAccepted = false`, `protectedQaAccepted = false`)
- **Ground Truth**: **No actual Warlock window screenshot exists yet**; zero screenshots or native inputs are invented or claimed; `nativeOperations: []`; `15 / 242` whole requirements and `39 / 417` scenarios unchanged.

---

## 1. Audited Compiled Elm Artifacts (`haskell-cpu-1793547720897141427` GREEN) & Styling Patches

| Artifact | Path | Bytes | SHA-256 | Wrapper & CSP Verification |
| --- | --- | ---: | --- | --- |
| **Compiled `Controller` role** | `.warlock-contributor/haskell-cpu-1793547720897141427/haskell-build/frontend/HttpMain.html` | `1,064,883` | `60aa950faa9b405ea71267487e906eef11f614e1beda69a8ad09f7fb4b1f13f1` | Exact `validateCompilerShape`: `<style>body { padding: 0; margin: 0; }</style>` + `<pre id="elm"></pre>` replaced by `Elm.HttpMain.init` |
| **Compiled `Bar` role** | `.warlock-contributor/haskell-cpu-1793547720897141427/haskell-build/frontend/HttpBar.html` | `280,039` | `a79e3fecc5d741dbba926f780f206d3fad658c689c978718a564837db1e8be98` | `_VirtualDom_applyStyles` writes `domNode.style[key] = styles[key]` via CSSOM (zero `setAttribute("style", ...)` CSP violations under single-hash `style-src`) |
| **Compiled `Popup` role** | `.warlock-contributor/haskell-cpu-1793547720897141427/haskell-build/frontend/HttpPopup.html` | `507,128` | `4713fbf12dcc597af389b2800f9fc69b30718fafe7fd421e3446ff722b9e1f30` | Same CSSOM property path (`74` distinct `Html.Attributes.style` keys; zero `attribute "style"` occurrences) |
| **Base layout/styling patch** | `.warlock-contributor/engine-pid1-drafts/MvpLayout.patch` | `39,353` | `23e2e1469450fe0126dccef5cb20c5c5a47880fb60e14b588718652d1b97e2fd` | `GtkOverlay` `1×1` `cView`, `56px` `bView`, `480×360` `pView`, dark shell wrappers, `Application Workspace` closed card |
| **Incremental a11y/visual fix** | `.warlock-contributor/engine-pid1-drafts/MvpLayoutA11yFollowup.diff` | `4,992` | `d784e13768e957ab2422ec7046750834105159a9e7bcef53c4852b255f26ea88` | Applies cleanly (`patch -p1 --dry-run`) on top of `MvpLayout.patch`; fixes Findings F2, F5, and F6 below without breaking browser QA |

---

## 2. Concrete Visual & Accessibility Risks Found in the Three Compiled Elm Roles & `MvpLayout.patch`

### F1 — Unstyled `.shell-announcement` Bleeds Visible Black-on-White Duplicate Text in Unpatched `HttpBar.html` / `HttpPopup.html`
- **Source & Compiled Fact**: Legacy `assets/bar.html` / `assets/popup.html` loaded `assets/shell.css:135` (`.shell-announcement { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap }`). Standalone `HttpBar.html` and `HttpPopup.html` carry **only** `<style>body { padding: 0; margin: 0; }</style>`, and `Announcement.elm:47` emits `<span class="shell-announcement" role="status" aria-live="polite" aria-atomic="true">` with **zero inline styles**.
- **Visual Impact in Unpatched `1793547720897141427` Builds**: Whenever an announcement message is active (`model.active == True` and `message /= Nothing`), `Bar.elm:141-145` renders `.shell-announcement` **below `.surface-bar`** (`wy + 56 .. wy + 72` inside the `72px` `bView`), and `Popup.elm:54` renders `.shell-announcement` **below the `100vh` `.surface-popup`** on an unstyled white `#ffffff` `<body>` background, creating both visible duplicate text and an outer `<body>` vertical scrollbar.
- **Status**: Eliminated by `SurfaceTheme.liveAnnouncementStyles` in `MvpLayout.patch` (`23e2e146`) + F2 anchor fix in `MvpLayoutA11yFollowup.diff` (`d784e137`).

### F2 — `MvpLayout.patch` `liveAnnouncementStyles` Omitted `top: 0; left: 0`, Leaving a `100vh + 1px` Root Vertical Scrollbar in `HttpPopup`
- **Source Fact**: In `Popup.elm:54`, `.shell-announcement` is the second sibling *after* `.surface-popup` (`height: 100vh; min-height: 100vh`). In `MvpLayout.patch:636-647`, `liveAnnouncementStyles` set `position: absolute; width: 1px; height: 1px; ...` with `top: auto; left: auto`.
- **Visual Risk**: Under CSS Positioned Layout in WebKit6, `position: absolute` with `top: auto` resolves to the element's static position at **`y = 100vh`**, making `documentElement.scrollHeight = 100vh + 1px` and triggering a `1px` outer vertical scrollbar on `pView` alongside `.surface-popup`'s own `overflow-y: auto` scrollport.
- **Fix in `MvpLayoutA11yFollowup.diff` (`d784e137`)**: Adds `style "top" "0"`, `style "left" "0"`, and `style "pointer-events" "none"` to `liveAnnouncementStyles`.

### F3 — `SurfaceTheme.elm:272` `0 100vh 0 100vh #100e0e` `bView` Shadow Band vs Pre-First-Frame / `effectsOff` White `#ffffff` Band
- **Compiled Fact**: In unpatched `HttpBar.html` (`bView` size request `(-1, 72)` vs `.surface-bar` `calc(3em + 8px) = 56px`), `SurfaceTheme.barRootStyles` (`L272`) sets `box-shadow: inset 0 -1px 0 #3b3335, 0 1px 0 #786c6e, 0 100vh 0 100vh #100e0e` when `softEffectsEnabled == True`.
- **Screenshot Diagnostic Consequence**:
  1. **Before first `/events` `presentation` arrives** (or on `UiHttp.problem` `role="alert"`), `Bar.view` / `Popup.view` emit `text ""` on unstyled `<body>`, flashing raw **`#ffffff` white** across `bView` and `pView` in unpatched builds (fixed by `httpBarShellStyles` / `httpPopupShellStyles` in `MvpLayout.patch`).
  2. **After first `presentation` in unpatched `HEAD` (`Night` default, `effectsOff == False`)**: `wy .. wy + 56` is `.surface-bar` (`#191516`), `wy + 56` is a `1px` `#786c6e` shadow line, and **`wy + 57 .. wy + 72` (`15px`) is painted `#100e0e` by `bView`'s outer `box-shadow`** (`pView` itself does not begin until `wy + 72`!). However, if `effectsOff == True` or `theme == HighContrast`, `backdropShadow` becomes `"none"`, exposing raw **`#ffffff` white** across `wy + 56 .. wy + 72`! (`MvpLayout.patch` sets `bView` to `56px`, eliminating that `16px` band in every theme/effects mode.)

### F4 — Omitted Inline `outline-style` Leaves Focus Rings Dependent on WebKitGTK 2.54.1 UA `:focus-visible` Heuristics
- **Compiled Fact**: `assets/shell.css:1,31,41,88` provided `:focus-visible { outline: 3px solid ... }`. Standalone `HttpBar.html` and `HttpPopup.html` lack `shell.css`, and `SurfaceTheme.elm` (`L375-377`, `L601-609`, `L869-871`, `L1183-1191`) sets `outline-width` (`3px` / `2px`), `outline-color` (`#8ec8ff` in `Night`, `#ffff00` in `HighContrast`), and `outline-offset` **without `outline-style`**.
- **WebKit6 Visual/Accessibility Risk**:
  - When WebKit's UA `:focus-visible { outline-style: auto }` matches (keyboard `Tab`), `outline-style: auto` paints WebKitGTK's platform focus ring, which can ignore custom `outline-color` (affecting `HighContrast` `#ffff00`).
  - When `Browser.Dom.focus` runs **programmatically after a pointer click** (e.g., `HttpPopup.elm:57` focusing `#launcher-search` after clicking `"Applications"` with the mouse, or programmatic focus on `<span id="warlock-bar-status-scroll-*" tabindex="0">`), if WebKit is in pointer modality so `:focus-visible` does not match, UA `outline-style` stays `none`, rendering a **`0px` invisible focus contour** even though `document.activeElement` is `#launcher-search` (keyboard typing still works!).
  - *(Note: Setting `outline-style: solid` unconditionally inline would draw permanent 3px rings on every unfocused button; if deterministic custom rings are needed without changing `<style>` / `validateCompilerShape`, track `focusedDomId : Maybe String` via Elm `on "focus"` / `on "blur"` and emit `style "outline-style" "solid"` only on the active element.)*

### F5 — Missing `lang="en"` Root Attribute & Missing Accessible Name on `.surface-controls[role="group"]` (Plus Two Preserved QA Invariants)
- **Compiled Fact**:
  1. `HttpMain.html:2`, `HttpBar.html:2`, and `HttpPopup.html:2` emit bare `<html>` without `lang`, pinned byte-for-byte by `Warlock.Http.Document.validateCompilerShape` (`Document.hs:64`). Screen readers (Orca / ATSPI2) lack WCAG 3.1.1 language metadata unless `lang="en"` is placed on the Elm root containers.
  2. `SurfaceRenderer.elm:145` gives `.surface-controls[role="group"]` an `aria-label` in `"switcher"` mode (`"Window switcher controls"`), but leaves `role="group"` **unlabeled** in `"applications"`, `"closed"`, `"overview"`, `"settings"`, `"files"`, `"notifications"`, `"system"`, `"jump"`, `"snap"`, and `"picker"` modes.
- **Fix in `MvpLayoutA11yFollowup.diff` (`d784e137`)**: Adds `attribute "lang" "en"` to `HttpBar`, `HttpPopup`, `.surface-bar`, and `.surface-popup`, and adds `attribute "aria-label" (popupHeadingText ++ " controls")` (`"Task View controls"` in `overview`) to `.surface-controls[role="group"]`.
- **Two Preserved Browser-QA Contracts (Do NOT Alter)**:
  - Keep `aria-current="false"` on inactive controls (`implementation/warlock/qa/attention-browser.mjs:34` explicitly asserts `getAttribute('aria-current') === 'false'`).
  - Keep `.surface-status` width `flex: 0 0 clamp(180px, 40vw, 360px)` (`SurfaceTheme.elm:344`) so `200%` text-scale status-scroll line counts stay within the bounded Arrow-key reachability oracle.

### F6 — Exact WCAG 2.1 Contrast Audit (`Settings.Night` & `Settings.Dawn`) + `2.30:1 -> 8.10:1` Inner Accent Fix
- **Verified Passing Contrast Ratios (`SurfaceTheme.elm:80-138`)**:
  - `Night` `#f6efe8` text on `#100e0e` (`16.89:1`), `#191516` (`15.89:1`), `#262022` (`14.05:1`), `#351c1f` (`13.78:1`); `#c6bab7` detail text on `#351c1f` (`8.31:1`); `#9a8e8b` disabled text on `#131011` (`5.96:1`).
  - `Night` `#786c6e` control/search border on `#191516` (`3.59:1`) & `#100e0e` (`3.82:1`); `#8ec8ff` focus ring on `#100e0e` (`10.87:1`) & `#351c1f` (`8.87:1`).
  - `Dawn` `#181314` text on `#f6f1ea` (`16.36:1`); `#524846` detail on `#fce8e4` (`7.50:1`); `#6e625f` border on `#f6f1ea` (`5.23:1`); `#14539a` focus ring (`6.51:1`–`6.84:1`).
- **Single Non-Text Contrast Defect Found & Fixed in `MvpLayoutA11yFollowup.diff` (`d784e137`)**:
  - `Night` `actionFill` (`#b02026`) inset stripe against `surfaceSelected` (`#351c1f`) on `bar:applications`, `pin:<headId>`, and active `control-group` measured **`2.30:1`** (`< 3.0:1` WCAG 1.4.11, though mitigated by outer `1px`/`4px` `#fca399` border at `8.10:1`). Replaced inner stripe token with `brandAccent` / `activeContour` (`#fca399` in `Night` -> **`8.10:1`**; `#a11d22` in `Dawn` -> **`6.56:1`**).

### F7 — WebKitGTK 2.54.1 `<input type="search">` Cancel Glyph & Narrow `620px` Non-Overlay Scrollbar Squeeze
- **Search Cancel Pseudo-Element (`SurfaceRenderer.elm:128`)**: When `#launcher-search` (`type="search"`) has non-empty text, WebKitGTK paints its native `::-webkit-search-cancel-button` (`×`) at the right edge of the input box (unstyleable without modifying `<style>`). Meanwhile, physical `Escape` is intercepted by `Warlock/Ui/Mvp.hsc` at `GTK_PHASE_CAPTURE` before WebKit's search-clear handler runs, closing `Popup` (`data-mode="closed"`) in one keypress.
- **Narrow `600..630px` Horizontal Scrollbar in `.surface-actions`**: At `620px` width, `.surface-status` takes `40vw = 248px` and `.surface-actions` takes `372px` (`overflow-x: auto; overflow-y: hidden; height: 56px`). When disabled utility/pin buttons exceed `372px`, if GTK4/WebKit6 uses non-overlay scrollbars inside `bView`, the horizontal scrollbar track occupies the bottom `~6..10px` of `.surface-actions`, visually tightening bottom padding on taskbar buttons.

### F8 — `HttpMain` `cView` `1×1` Bottom Scanline (`wy + wh - 1`) & AT-SPI `DOCUMENT_WEB` Exposure
- **Bottom `1px` Adwaita Scanline (`Warlock/Ui/Mvp.hsc:851-859`)**: `attachMvpWindow` appends `cView` (`HttpMain.html`, `size-request = 1×1`, `opacity = 0.0`, `visible = 1`) as the third vertical child of `GtkBox`. In unpatched builds (`MvpLayout.patch` removes the `1px` flow allocation by using `GtkOverlay` or `size-request 0×0` review), row `wy + wh - 1` across the entire window width exposes the underlying `GtkWindow` Adwaita background (`#fafafa` in `LANG=C.UTF-8` default light theme or `#242424` in dark theme) rather than `pView`'s `#191516`/`#100e0e`.
- **AT-SPI Tree (`HttpMain.elm:55`, `frontend/HttpMain.html:5`)**: `HttpMain.elm` renders `text ""` (zero duplicate interactive controls or landmarks), so `cView` contributes no spurious focusable DOM nodes, though `visible = 1` without `GTK_ACCESSIBLE_STATE_HIDDEN` still exposes an empty `DOCUMENT_WEB` node titled `"HttpMain"` to AT-SPI2.

### F9 — Unstyled `<div role="alert">` Fallback in `HttpBar.elm:60` & `HttpPopup.elm:74` During Shutdown Drain or Transport Error
- **Exact Source (`HttpBar.elm:60`, `HttpPopup.elm:74`, `HttpPopup.elm:34`)**: When `UiHttp.problem model.http` becomes `Just reason` (e.g., if `/events` SSE/long-poll disconnects during the `EngineEntrypoint.hs:325` final `1.0s` deadline drain before `gtkWindowDestroy`, or if an unsupported preview effect triggers `UiHttp.stop`), both roles render `div [attribute "role" "alert"] [text (reason ++ " Restart this view to reconnect.")]` with **zero inline styles**.
- **Visual Consequence in Standalone WebKitGTK**: Without `assets/shell.css`, `<div role="alert">` replaces the themed dark surface with raw `#000000` 16px default serif text on a `#ffffff` white WebView background. Screenshots captured inside the final `< 1.0s` shutdown drain window must distinguish this expected post-stop alert fallback from steady-state UI rendering.

---

## 3. Ready-to-Execute Inspection Protocol When Root Supplies First Actual Screenshots

Immediately upon receiving actual PNG paths from `lead`, `gemini-gui` will inspect every image directly via `read_file` (plus bounded pixel/geometry measurements if helpful) against these exact criteria:

1. **Frontend Variant Identification (First Glance)**:
   - **Unpatched `1793547720897141427`**: Closed `Popup` shows `Choose a window` with empty body below status banner; `15px` `#100e0e` shadow band (`wy + 57 .. wy + 72`) or `#ffffff` band between `Bar` and `Popup`; `1px` bottom `cView` seam; possible visible `.shell-announcement` duplicate text if an announcement fired.
   - **With `MvpLayout.patch` (`+ MvpLayoutA11yFollowup.diff`)**: Closed `Popup` shows `Application Workspace` + `Standalone Application Catalog & Taskbar Pins` card; crisp `56px` `Bar` directly abutting `Popup` (`0px` gap, `0px` bottom seam, `0px` outer `<body>` scrollbar).
2. **Real Desktop & `Foot` Non-Interference**:
   - Pre-existing Omarchy `Foot` terminal remains visible/intact in its dwindle tile (`Virtual-1` `1280×800`), undecorated Warlock window occupies its exact `[wx, wy, ww, wh]` tile without CSD titlebar.
3. **App-Only Capability Honesty (`nativeOperations: []`)**:
   - `Bar`: Only `"Applications"` appears enabled (`#351c1f` / `#fca399`); `"Task View"`, `"Switch windows"`, `"Notifications"`, `"Files"`, `"System"`, `"Settings"`, and any prepended `"Pinned launcher"` chip appear disabled (`#131011` / `#9a8e8b` dashed).
   - `Popup` (`Applications`): `#launcher-search`, `"Windows"`, `"Refresh"`, and `"Pin <HeadApp>"` / `"Unpin <App>"` appear enabled; `"Actions for <HeadApp>"` and all `"Open <App>"` cards appear disabled.
4. **Visual Defects Watchlist**:
   - Check for any `#ffffff` white flash/strip, `.shell-announcement` duplicate text bleed, double vertical scrollbars in `pView`, clipped button labels or scrollbar overlap in `bView` at `~620px`, focus ring visibility on `#launcher-search` (F4), and clean return to closed workspace after physical `Escape`.
