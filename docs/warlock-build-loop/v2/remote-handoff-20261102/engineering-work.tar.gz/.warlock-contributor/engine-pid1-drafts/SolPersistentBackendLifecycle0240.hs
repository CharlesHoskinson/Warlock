{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- Unexecuted public-production-library QA. Root retains this opaque case and
-- its private namespace BEFORE runCase; failure never kills or cleans a process.
module SolPersistentBackendLifecycle0240
  (Mode(..), Retained, newRetained, runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (IOException, SomeException, fromException, mask, try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.IORef
import Data.List (sortOn)
import qualified Data.Text.Encoding as TE
import GHC.Clock (getMonotonicTimeNSec)
import System.Directory (doesFileExist)
import System.FilePath (isAbsolute)
import System.IO (IOMode(ReadMode), withBinaryFile)
import System.IO.Error (ioeGetErrorString, isUserError)
import System.Timeout (timeout)
import Warlock.Backend
import Warlock.Bootstrap (newCurrentSessions, PersistentBootstrapResult(..))
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P
import qualified Warlock.Protocol.StrictJson as J

data Mode = Confirmed | ExpiredRetirement deriving (Eq, Show)
data Retained = Retained PersistentBackendOwner (IORef Bool)
  (MVar ()) (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId))

-- This is a NEW QA cap, not an original/native threshold. The same immutable
-- budget is selected once before startup; Root's existing QA D is independent.
stopMicros :: Int
stopMicros = 500000

newRetained :: IO Retained
newRetained = do
  current <- newCurrentSessions
  budget <- must (P.stopBudgetMicros stopMicros)
  owner <- newPersistentBackendOwner current budget
  Retained owner <$> newIORef False <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("backend lifecycle: " ++ label)))
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

within :: AdmissionDeadline -> String -> IO a -> IO a
within original label action = do
  left <- remainingMicros original
  check (label ++ ": original QA D remains") (left > 0)
  observed <- timeout left action
  value <- maybe (ioError (userError (label ++ ": QA timeout; retain case"))) pure observed
  final <- remainingMicros original
  check (label ++ ": completed inside original QA D") (final > 0)
  pure value

-- Literal complete semantic expectation derived from Catalog.readCatalog's
-- first empty inventory, PinStore.readAt's absent taskbar.json, and the gateway
-- schema. No production encoder/reducer is called to manufacture the oracle.
expectedReply :: B.ByteString
expectedReply = "{\"bridgeProtocol\":1,\"kind\":\"native-event\",\"payload\":{\"protocolVersion\":3,\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"kind\":\"application-catalog\",\"requestId\":\"7\",\"snapshot\":{\"catalogProtocol\":2,\"lifetime\":\"1\",\"generation\":\"1\",\"entries\":[]},\"preferences\":{\"revision\":\"1\",\"identities\":[]}}}"

decode :: B.ByteString -> IO J.Json
decode bytes = do
  limits <- must (J.bounds 4096 16)
  must (J.decodeStrict limits bytes)

-- decodeStrict refuses duplicate object keys. Preserve EVERY value, array
-- order and primitive spelling; sort object keys recursively for full semantic
-- comparison instead of accidentally testing encoder key serialization order.
canonical :: J.Json -> J.Json
canonical value = case value of
  J.JObject fields -> J.JObject (sortOn fst [(key,canonical child) | (key,child) <- fields])
  J.JArray children -> J.JArray (map canonical children)
  primitive -> primitive

awaitReceipt :: AdmissionDeadline -> FilePath -> IO B.ByteString
awaitReceipt original path = within original "complete peer receipt" loop
 where
  loop = do
    exists <- doesFileExist path
    if not exists then threadDelay 1000 >> loop else do
      bytes <- withBinaryFile path ReadMode (\input -> B.hGet input 4097)
      check "bounded complete receipt" (B.length bytes <= 4096)
      _ <- decode bytes
      pure bytes

-- This delay is an observation, NOT a newly minted admission/stop deadline.
-- A real StopSignalSent receipt proves the original stop latch already exists.
-- Sampling AFTER that receipt and waiting more than its fixed budget makes the
-- same owner's original StopD expired, even if delivery itself took time.
awaitExpiredBudget :: AdmissionDeadline -> IO ()
awaitExpiredBudget original = do
  afterReceipt <- toInteger <$> getMonotonicTimeNSec
  let expiredAfter = afterReceipt + toInteger stopMicros * 1000 + 1000000
      loop = do
        now <- toInteger <$> getMonotonicTimeNSec
        if now > expiredAfter then pure () else threadDelay 1000 >> loop
  within original "original StopBudget elapsed after actual latch" loop

-- Root config preconditions: binding 1/2/3; applicationAttachment false;
-- catalogRoots []; valid owned empty pinsRoot (taskbar.json absent), locale C;
-- exact artifact-pinned SolPersistentBackendPeer0240 with [receiptPath].
-- Root preserves startup D, artifact/private namespace pins and independent
-- process guardian. receiptPath and .writing must both be fresh owned names.
-- The caller retains Retained even on exceptions/timeouts; no force cleanup,
-- raw PID, new process authority, private constructor or fault hook is used.
runCase :: Mode -> Retained -> BackendConfig -> AdmissionDeadline -> FilePath -> IO ()
runCase mode (Retained owner used startBarrier completed threadCell) config original receiptPath = mask $ \restore -> do
  previous <- atomicModifyIORef' used (\old -> (True,old))
  check "one-shot fixture" (not previous)
  check "absolute owned receipt name" (isAbsolute receiptPath)
  exists <- doesFileExist receiptPath
  pending <- doesFileExist (receiptPath ++ ".writing")
  check "fresh complete and in-progress receipt names" (not exists && not pending)
  remaining <- remainingMicros original
  check "Root original QA D remains before starting" (remaining > 0)
  worker <- forkIOWithUnmask $ \unmask -> do
    -- No Backend work starts until its actual worker identity is published in
    -- the already retained case. Failure before release leaves it blocked;
    -- callers retain that barrier/worker, never guess a safe kill or cleanup.
    result <- try (unmask (takeMVar startBarrier >> runPersistentBackend owner config))
    putMVar completed result
  writeIORef threadCell (Just worker)
  putMVar startBarrier ()
  restore $ do
    bytes <- awaitReceipt original receiptPath
    actual <- decode bytes
    expected <- decode expectedReply
    -- Exact outer shape and COMPLETE nested object, without field projections
    -- or a raw JSON key-order requirement. Unexpected fields fail equality.
    case actual of
      J.JObject [("received", J.JString value)] -> do
        nested <- decode (TE.encodeUtf8 value)
        check "complete reply semantic equality" (canonical nested == canonical expected)
      _ -> check "exact receipt shape" False
    -- Child publishes after receiving the real Backend reply and stays alive
    -- until TERM. StopSignalSent is distinct from an ACK or natural child exit.
    receipt <- within original "same-owner explicit stop" (requestPersistentBackendStop owner)
    check "actual selected live child stop signal" (receipt == P.StopSignalSent)
    result <- within original "actual Backend run return" (readMVar completed)
    run <- either (ioError . userError . ("actual Backend exception; retain case: " ++) . show) pure result
    check "one complete checked callback and one actual domain read"
      (persistentBackendCounts run == (1,1))
    check "actual selected leader reaped, not inferred from stop ACK" $ case persistentBackendOutcome run of
      Right (PersistentBootstrapObserved (Right (_,P.LeaderReaped _))) -> True
      _ -> False
    case mode of
      Confirmed -> do
        clean <- within original "first same-owner retirement" (retirePersistentBackend owner)
        check "core confirmed and both stores already settled" clean
        again <- within original "historical retirement receipt" (retirePersistentBackend owner)
        check "confirmed historical receipt is stable" again
      ExpiredRetirement -> do
        awaitExpiredBudget original
        clean <- within original "expired first retirement" (retirePersistentBackend owner)
        again <- within original "sticky unconfirmed observation" (retirePersistentBackend owner)
        check "expired StopD never becomes successful retirement" (not clean && not again)
    duplicateStop <- within original "duplicate same-owner stop" (requestPersistentBackendStop owner)
    check "duplicate stop does not create a new live session" (duplicateStop == P.StopAlreadyRequested)
    duplicate <- within original "same-owner run replay refusal"
      (try (runPersistentBackend owner config) :: IO (Either SomeException PersistentBackendRun))
    check "exact one-shot refusal before second Backend work" $ case duplicate of
      Left problem -> case fromException problem :: Maybe IOException of
        Just refusal -> isUserError refusal && ioeGetErrorString refusal == "persistent backend owner already used"
        Nothing -> False
      Right _ -> False
    putStrLn ("backend lifecycle observation: " ++ show (mode,receipt,persistentBackendCounts run,duplicateStop))
    -- Exact caller-visible observations only. Expired False is NOT evidence
    -- that descriptors/workers drained, nor a close-count/no-retry proof.
