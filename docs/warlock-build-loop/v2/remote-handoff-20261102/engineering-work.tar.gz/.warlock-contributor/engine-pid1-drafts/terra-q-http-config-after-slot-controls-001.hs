{-# LANGUAGE OverloadedStrings #-}
-- QA ONLY. Build in a SEPARATE isolated source unit with Engine publication
-- hook003 and q-http after-slot overlay001, Store seam002 and Backend observer003.
-- The overlay always throws AFTER the actual config cell write and BEFORE the
-- actual gate receipt. Never ship these hooks. Root MUST retain Case strongly
-- before runCase and retain it after all exceptions; use the existing protected
-- launcher/original external deadline. No spawned child, kill, or cleanup claim.
module QHttpConfigAfterSlotControls (Case,newCase,runCase) where

import Control.Exception (SomeException,fromException,try)
import Control.Monad (unless)
import qualified Data.Text as T
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.IO.Error (isUserError,ioeGetErrorString)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
  loadPersistentBackendConfig,runPersistentBackend,qaPersistentConfigState)
import Warlock.Backend.Store (qaStoreClearHooks,qaStoreEntryCount,qaStoreRawCount)
import Warlock.Bootstrap (newCurrentSessions)
import qualified Warlock.Capture.Process.Persistent as P

newtype Case = Case PersistentBackendOwner
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
newCase :: IO Case
newCase = do
  current <- newCurrentSessions
  budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
  Case <$> newPersistentBackendOwner current budget

-- This branch is a positive real Store read followed by a deterministic
-- synthetic exception in the actual prelive-publication path; it is not a
-- simulated file read, a real process execution, or evidence of FD drainage.
runCase :: Case -> FilePath -> IO ()
runCase (Case owner) path = do
  exists <- doesPathExist path
  check "owned valid absolute config" (isAbsolute path && exists)
  qaStoreClearHooks
  outcome <- try (loadPersistentBackendConfig owner path) :: IO (Either SomeException (Either T.Text ()))
  state <- qaPersistentConfigState owner
  entries <- qaStoreEntryCount
  raws <- qaStoreRawCount
  check "exact injected fault observed after actual slot write" $ case outcome of
    Left problem -> case fromException problem :: Maybe IOError of
      Just e -> isUserError e && ioeGetErrorString e == "qa-after-config-slot-write"
      Nothing -> False
    Right _ -> False
  check "actual Store was entered and slot written without confirmed receipt"
    (entries>0 && raws>0 && state==(True,True,True,False,0))
  runOutcome <- try (runPersistentBackend owner) :: IO (Either SomeException PersistentBackendRun)
  check "unconfirmed slot cannot launch Backend" $ case runOutcome of
    Left problem -> case fromException problem :: Maybe IOError of
      Just e -> isUserError e && ioeGetErrorString e == "persistent owner has no verified config"
      Nothing -> False
    Right _ -> False
  repeatResult <- loadPersistentBackendConfig owner path
  after <- qaStoreEntryCount
  check "one-shot config read is not replayed after written-but-unknown"
    (repeatResult==Left "persistent config owner already used" && after==entries)
