// Proposed, unexecuted production Popup browser component test.
// Root-owned harness must create a fresh isolated Popup page, expose the actual
// compiled Popup as window.testApp and capture its actions port in window.actions.
// Before invoking, the harness must verify/report source and compiled artifact
// hashes, serve only its reviewed origin, and supply bounded evaluate/until/check.
// Synthetic DOM input exercises Elm rendering, not physical input, native IME,
// assistive technology, guest presentation or any latency requirement.
export async function pendingQueryFeedback({ evaluate, until, check, assertSourceIdentity }) {
  await assertSourceIdentity();
  const noMatch = 'No matching applications. Change your search or Refresh.';
  const pending = 'Results may not match current input. Previous: ' + noMatch;
  const frame = (publication, query) => ({
    surfaceProtocol: 2, publication, lease: '7', mode: 'applications', status: noMatch,
    bar: [], popup: [{ id: 'control:search', domId: 'search', label: query,
      ariaLabel: 'Search applications', detail: '', enabled: true }]
  });
  const queryEffect = (publication, query) => ({
    surfaceProtocol: 2, kind: 'surface-query', surface: 'popup', publication,
    lease: '7', id: 'control:search', query
  });
  const sendFrame = async value => {
    await evaluate(`window.testApp.ports.presentation.send(${JSON.stringify(value)})`);
  };
  const inspect = () => evaluate(`(() => {
    const root = document.querySelector('.surface-popup');
    const field = root && root.querySelector('[data-surface-field="control:search"]');
    const status = root && root.querySelector('[role="status"]');
    return { publication: root?.dataset.publication, value: field?.value,
      status: status?.textContent, live: status?.getAttribute('aria-live'),
      focused: document.activeElement === field, sameField: field === window.heldSearch,
      selectionStart: field?.selectionStart, selectionEnd: field?.selectionEnd,
      composing: root?.parentElement?.getAttribute('data-input-composing'),
      actions: window.actions };
  })()`);
  const exact = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  await sendFrame(frame('1', 'qv'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication === '1'`);
  await evaluate(`(() => { window.actions.length = 0; window.heldSearch = document.querySelector('[data-surface-field="control:search"]'); window.heldSearch.focus(); })()`);
  let seen = await inspect();
  check('baseline status and focus', seen.status === noMatch && seen.value === 'qv' && seen.focused && seen.sameField && seen.live === 'off', seen);
  await evaluate(`(() => { const f=window.heldSearch; f.value='qvxz9'; f.setSelectionRange(5,5); f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'x'})); })()`);
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(pending)} && window.actions.length === 1`);
  seen = await inspect();
  check('pending input displays previous result and preserves field', seen.status === pending && seen.value === 'qvxz9' && seen.focused && seen.sameField && seen.selectionStart === 5 && seen.selectionEnd === 5 && exact(seen.actions, [queryEffect('1', 'qvxz9')]), seen);
  await sendFrame(frame('2', 'qv'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication === '2' && window.actions.length === 2`);
  seen = await inspect();
  check('intermediate frame remains pending and rebases query', seen.status === pending && seen.value === 'qvxz9' && seen.focused && seen.sameField && exact(seen.actions, [queryEffect('1', 'qvxz9'), queryEffect('2', 'qvxz9')]), seen);
  await sendFrame(frame('3', 'qvxz9'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication === '3' && document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(noMatch)}`);
  seen = await inspect();
  check('matching accepted frame clears pending status', seen.status === noMatch && seen.value === 'qvxz9' && seen.focused && seen.sameField && seen.actions.length === 2, seen);
  await evaluate(`(() => { const f=window.heldSearch; f.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true,data:''})); f.value='qvxz9漢'; f.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'漢'})); })()`);
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(pending)} && document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing') === 'true'`);
  seen = await inspect();
  check('synthetic preedit does not dispatch query', seen.value === 'qvxz9漢' && seen.focused && seen.sameField && seen.composing === 'true' && seen.actions.length === 2, seen);
  await evaluate(`(() => { const f=window.heldSearch; f.value='qvxz9'; f.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:''})); })()`);
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(noMatch)} && document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing') === 'false'`);
  seen = await inspect();
  check('cancelled synthetic preedit restores accepted status', seen.value === 'qvxz9' && seen.focused && seen.sameField && seen.actions.length === 2, seen);
}
