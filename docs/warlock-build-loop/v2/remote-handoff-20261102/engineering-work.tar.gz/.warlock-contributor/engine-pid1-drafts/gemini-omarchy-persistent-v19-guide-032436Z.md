# Converged Persistent Runtime & Backend Stack (`v19`, Wave `032436Z`)

- **Author**: `gemini-omarchy`
- **Status**: `CANDIDATE SOURCE ONLY; UNEXECUTED BY WORKER` — Root alone integrates and executes protected compilers, models, tests, native binaries, VM, and browser runs.
- **Canonical Base `HEAD`**: `a327c8f7fe63e40a8b3b21bd558c47429ade4c6d` (includes Root's published `Store.hsc` / `Catalog.hs` / `PinStore.hs` `v3`; zero files in `v19` touch `Store.hsc`, `Catalog.hs`, `PinStore.hs`, `qa/store-retirement/*`, or `site/*`).
- **Patch Verification**: Every patch below verified with `patch -p1 --fuzz=0` against fresh `HEAD` (`a327c8f7fe63e40a8b3b21bd558c47429ade4c6d`), `0323`, and `014` trees.

## Deliverables & Exact Disk SHA-256 Digests

1. **`gemini-omarchy-prelive-custody-fixes-032436Z.patch`** (`d0896b6df36216889690dd5ae9042313d7dc19cbb508cc7e28e2bd88049c09d3`)
   - Applies `--fuzz=0` atop `terra-graph-v17-prelive-0323.patch` (`03f94ec35dde99989c045fe51187204b6b47559b0c4bf24ccd18cd6f9a7ec194`).
   - Pure production (zero `#ifdef WARLOCK_OWNER_QA` pollution).
   - `Transfer/Internal.hs`: `de3cfc758f9ee41e3d66c917853e5e7fe9c4476acff2db4a3f36cf366a83edb6` -> `60f16a4bc88009162b342abba7c9a4ada29b679f51e19d5f3ccd5e05883ba9bb` (exact `terra-engine` `008` `tryClaimTransferRetained`).
   - `Owner.hs`: `e6a0ace0ee2cac335065acf5a528c9df49eb0a0542fecc82452ba168e2f3cb85` -> `f9b5dae3fc7172f29a18dade35ca179b7923ee3503fa7140665e4660cec59f03` (composes `terra-security` `001` gated `ownerPending` + `tryOwnerPending`, `terra-security` `002` `trySettleChildBefore` rebased cleanly onto pure production `Owner.hs` with pre-clear poison so `rawOwner` never remains `Active` when `PersistentOwner` becomes `PhaseQuarantined`, plus nonblocking `tryQuarantineChild`).
   - `Persistent/Internal.hs`: `c566fa5011a552fa6b7c58e5459913d557a6a667b785ceac6d47ebc298a2c5e1` -> `9a21c4766c6f11e0e0470a60a7f4db3259aff27143037a050d2ce41535024461` (composes `terra-engine` `006` async input-close cancellation rethrow, `terra-engine` `007` `pendingRecordHandle` before `newChild`/`publish`, `terra-engine` `008` `claimStartupInput` under `cbGate` distinguishing failed stop-deadline mint `Just (Left _) -> Left CleanupUncertain` vs `Just (Right _) -> Left SessionClosed`, `terra-security` `003` bounded `tryReleaseRetainedHeld` receipt inside `releaseBorrowBounded`, and `terra-security` `002` `finishOwnedChild` with `uninterruptibleMask_` reverse-order `gate -> phaseVar` publication and `tryQuarantineChild` synchronization).

2. **`gemini-omarchy-bootstrap-backend-015-032436Z.patch`** (`b65b0beadd736a7ad70f66d0733e18fddcd56e2f05bd5d08ae83d70845691828`)
   - Applies `--fuzz=0` atop `terra-portable-config-receipt-014.patch` (`9bae568dc8c67003ee6fb5dcb177c339e389abc7e71121012b614cae28ae407e`): `Bootstrap/Aggregate.hs` `9efb0abd58d1e56650b2b9a0057acd68478d4d59ab330249ea9fe7571beb52ea` -> `ff664ac0106de5f4f7c3b4e27e77ee591db6eb199bd34f929cdd7479f82a6fe1`; `Backend.hs` remains `742c17341c5db2a131f2342613fcf4fa6ed6344bf363627dfa0c2ed1259f0349`.
   - Wires nonblocking `tryRetireRegistrationBefore deadline registration` (`Just ScopeRetired`) inside `cleanupWork`.
   - Sets sticky `atomicWriteIORef uncertain True` both on `forkFinally` launch `Left err` and inside `forkFinally`'s completion callback whenever the worker result is not `Right True`, before `putMVar done`, and checks `not sticky && left > 0` before every sub-step and after `leaseResult`.
   - Resolves `terra-portable`'s two-observer contention finding in `persistentBootstrapReadiness`: `tryReadMVar cleanup == Nothing` reports `BootstrapNotReady` (never `BootstrapUncertain`), so a racing `retirePersistentBackend` observer returns `False` without poisoning `BackendRetireActive` to `BackendRetireUnknown`.

3. **`gemini-omarchy-persistent-foundation-v19-032436Z.patch`** (`df0cd609e69d45573bd4bf281fc59f10b2a037ada0c677ebb9d622d4ab278c42`)
   - Self-contained 18-file `held-document` + `process-custody` + `protocol` pure-production patch applying `--fuzz=0` directly to canonical `HEAD` (`a327c8f7fe63e40a8b3b21bd558c47429ade4c6d`).

4. **`gemini-omarchy-full-persistent-backend-v19-032436Z.patch`** (`d99dc01efe1ede0ea81c708950eaa2f97911b13da7e16711445f81a05aa01c1a`)
   - Complete 25-file converged pure-production stack (`held-document` + `process-custody` + `protocol` + `runtime` `001..015`) applying `--fuzz=0` directly to canonical `HEAD` (`a327c8f7fe63e40a8b3b21bd558c47429ade4c6d`).

5. **`GeminiOmarchyConvergedLifecycleControls032436Z.hs`** (`26c9851c10a14d1a548dbaa3df73f0fedd9d7a5b86eff196ec0f37fd0d87a93c`)
   - Direct source-bound Haskell lifecycle control module (single-use `StablePtr` host root + pre-allocated `MVar Bool` worker publication barriers) covering:
     - `controlTwoObserverBackendRetireContention`
     - `controlExpiredStopStickyBackendUncertain`
     - `controlTicketStopGateRefusalBeforeClaim`
     - `controlSameOwnerConfigGuards`

## Explicit Limits

- Zero universal approval gates or replacement `StopD` deadlines are invented; `PhaseRetired` in `requestSessionStop` is untouched.
- Worker ran zero protected compilers, models, tests, native binaries, VM, or browser checks; all controls are source-reviewed and unexecuted pending Root's protected harness.
- No native, GUI, provider, AT, IME, hardware, resource, or release acceptance is claimed.
