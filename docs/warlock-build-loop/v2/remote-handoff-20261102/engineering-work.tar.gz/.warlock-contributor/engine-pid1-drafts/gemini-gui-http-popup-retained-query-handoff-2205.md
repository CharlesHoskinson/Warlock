# `gemini-gui` Wave `2205` Final Handoff — Frozen `HttpPopup` Retained-Query-on-Transport-Failure + Existing-Harness Fixture (`d6becb72`)

- **Owner / Identity**: `gemini-gui` (`did:key:z6Mkrcc8RjEN24HqB6sSQoRcsSxfHrM8RWjMbAURibZF1Erc`)
- **Run / Cutoff**: `warlock-20261031-setup` / `2026-11-01T22:33:28.905352+00:00`
- **Verified Committed `HEAD`**: `d6becb72c4b261739a84325a55aac07a984ab1e4` (all pending-query/reversal files `Popup.elm` `9761aa5d...`, `SurfaceRenderer.elm` `58119053...`, `SurfaceSnapshot.elm` `9c85362e...`, `LocalFieldReplay.elm` `66db4f41...`, `typed-state.cjs` `5731d925...` preserved untouched)
- **Execution Boundary**: Worker performed **zero** canonical mutations and **zero** compiler, Quint, Node, browser, native, or VM executions.

---

## 1. Frozen Primary Deliverables (Exact `d6becb72` Preimages)

| Deliverable | Path in `.warlock-contributor/engine-pid1-drafts/` | Patch SHA-256 | Target & Preimage -> Postimage SHA-256 |
| --- | --- | --- | --- |
| **Elm Source Patch** | `gemini-gui-http-popup-retained-query-source-2205.patch` | `fcf8f9c0803ef723cf8284ed4a91126a138cdedc8add8def3750ae746c66d3df` | `implementation/warlock/src/HttpPopup.elm`: `4185692e...` (`4,051` B) -> `e814d56f212765154436c1ab01cc2657b669a6d5d68f5c6d2180ccb64c9eeeb3` (`5,679` B) |
| **Existing-Harness QA Fixture** | `gemini-gui-http-popup-retained-query-qa-2205.patch` | `08748bbe5cb046beecc3de53de97aa7350fcc9b729cb038a3edb271c372bb6dc` | `implementation/warlock/qa/ui-http.cjs`: `66630f5b...` (`47,193` B) -> `da32ed550a2afeaa062367ab4cf366e985fe469bf43f223a0301b3da4725933a` (`59,118` B) |
| **Combined Atomic Bundle** | `gemini-gui-http-popup-retained-query-bundle-2205.patch` | `30a0eb4a8e1e1c53580fecf10ee5f1f5d59bef29b7939729f2aec9121757b783` | Applies both `fcf8f9c0...` and `08748bbe...` cleanly on `d6becb72` |

### Positive / Error / Recovery Coverage in `httpPopupRetainedQueryOnFailure()` (`08748bbe...`)
1. **Positive Live Route**: Initial `applications` presentation, live `control:search` edit (`'foot'`) -> single `POST /actions`, `204` transport receipt, matching `publication: "2"` acknowledgement -> live interactive field (`!readOnly`), zero `role="alert"`, zero `#http-popup-retained-query`.
2. **Confirmed Query Error**: Active `GET /events` failure -> exact alert `'UI event transport unavailable. Actions were not retried. Restart this view to reconnect.'`, interactive `[data-surface-field]`/`[data-surface-control]` removed, read-only `#http-popup-retained-query` (`readOnly=true`, `value='foot'`, `data-retained-query-state='confirmed'`, zero event listeners), zero reconnect across `tick(10000)`.
3. **Unconfirmed Draft Error (`error`, `timeout`, `status500`)**: Draft edit + queued `control:refresh` followed by `POST /actions` failure -> exact alert `'UI delivery is unconfirmed. The action will not be repeated. Restart this view to reconnect.'`, active GET aborted, read-only `#http-popup-retained-query` retains `'foot-draft-<kind>'` as `unconfirmed-draft`, zero repeat or queued refresh across `tick(10000)`.
4. **Explicit View-Restart Recovery**: Copies retained draft from `#http-popup-retained-query.value`, closes failed view, launches fresh `HttpPopup` (verifies zero automatic POST replay), delivers fresh `(publication: "6", lease: "10")`, re-enters draft -> single `surface-query` POST on new scope + clean settlement on `publication: "7"`.
5. **Files Mode IME Preedit & Negative Controls**: `files` mode (`control:files-path`, `'folder path'`) retains active IME preedit `'/home/charl/漢字'` as `unconfirmed-draft` on GET timeout; pre-snapshot `Nothing`, `system` mode, and `applications` without `control:search` (`(Nothing, Nothing)`) fabricate zero `<input>` and preserve bare `div[role="alert"]`.

---

## 2. Four Independent Peer Reviews Received

1. **`sol-docs` (Sol HIGH Advisor)** — `01M6CJTXPJ3Q1D561TEDQC4Q3K`: Concurs on `fcf8f9c0` + `08748bbe`; verified exact preimage matches, `unconfirmed-draft` vs `confirmed` vs `(Nothing, Nothing) -> []` guards, terminal `UiHttp` stop, and zero replay.
2. **`terra-browser` (15th UX/Perf Owner)** — `01M6CJQSBZZ0QVZJVCSEJFTPS3`: Concurs on `fcf8f9c0` + `08748bbe`; documented focus/selection reset on `<input>` replacement, unprocessed IME buffer boundary, bare HTML contrast/200%-scale check for Root, and `ui-http.cjs` tail merge with `b7355f4c`.
3. **`terra-q-http` (Quint HTTP Reviewer)** — `01M6CJR4QJPG6RNQ5WXR8PACRN`, `01M6CJTPA30J2TRZBN49B193SE`, `01M6CK30BBCD0437BBCTMK0YBQ`: Concurs on `fcf8f9c0` + `08748bbe`; authored companion Quint model `terra-q-http-popup-loss-2213.qnt` (`57b69c0f...`) and sequential late-`View` QA patch `terra-q-http-popup-late-view-2218.patch` (`0a1b3245...`, verified sequential postimage `63b542a6...` atop `08748bbe` and `959378fe...` atop `8bad4c3c`).
4. **`terra-q-front` (Quint Frontend Reviewer)** — `01M6CJR9E98CV50XADM38CHQHM`: Concurs on `fcf8f9c0` + `08748bbe` source correspondence and scope caveats.

---

## 3. Companion Conflict-Free Merge Helpers (Strictly Separate Drafts)

- **Pre-merged `Bar` + `HttpPopup` `qa/ui-http.cjs` Diff**: `gemini-gui-ui-http-combined-bar-and-retained-query-2205.patch` (`sha256:8bad4c3cb95a3d320601e9e627db14f6c78e513e8fff6db894460dd565c0bbec`, `66630f5b...` -> `89dce73d88c177ebde69875c7120817a0ea241bdc05d4b7335a7d2363bd10b06`) — merges `terra-browser-bar-waiting-dom-2210.patch` (`b7355f4c...`) + `08748bbe...` + `q-http`'s undelivered-IME boundary check cleanly on `d6becb72`.
- **Separate Screenshot-Driven `Surface.elm` App-Only Matching Status Patch** (`positive-foot.png`): `gemini-gui-surface-app-only-matching-status-2216.patch` (`sha256:522d858ca3a0e022ab660a2990005333d3ee777119178d0c3a631ad2ecda5856`, `Surface.elm` `91d38d81...` -> `e04957068d0ac04cb142421309bc5b16dd5b949313bb34ba836305daf45c1302`), peer-reviewed by `terra-browser` (`01M6CJZZC8EX3714H3CJ2PF7KA`) and paired with `terra-browser-app-only-guidance-fixture-2216.patch` (`20c0d925...`).
