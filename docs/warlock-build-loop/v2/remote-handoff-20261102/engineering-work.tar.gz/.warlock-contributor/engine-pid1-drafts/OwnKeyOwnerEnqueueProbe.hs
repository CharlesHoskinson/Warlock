{-# LANGUAGE OverloadedStrings #-}
-- QA-only, unexecuted helper for the separately hashed Owner source copy with
-- terra-q-origin-owner-enqueue-counter.patch. Its monotonic count includes all
-- successful queue insertions, even if subsequently dequeued. Counter updates
-- are extra instrumentation, not proof of identical scheduling or performance.
-- One fresh owner per negative, original deadline unchanged. Independently
-- exclude competing issuers during the probe; retain eventual UiResult and
-- cleanup separately. This checks Owner defense in depth, not the earlier
-- EngineAdapter's distinct malformed-before-RPC exception.
module OwnKeyOwnerEnqueueProbe (Probe(..), PositiveProbe(..), probeMalformedFresh, probeValidFresh) where

import Data.Text (Text)
import qualified Warlock.Protocol.StrictJson as J
import qualified Warlock.Ui.Owner as Owner
import Warlock.Ui.Policy (Role(..))

data Probe = Probe
  { wasLive :: Bool
  , before :: (Integer, [(Role,Int)])
  , refusal :: Either Text ()
  , after :: (Integer, [(Role,Int)])
  , stopsAfterRefusal :: Bool
  , observedExpectedBoundary :: Bool
  } deriving (Eq, Show)

data PositiveProbe = PositiveProbe
  { positiveWasLive :: Bool
  , positiveBefore :: (Integer, [(Role,Int)])
  , positiveResult :: Either Text ()
  , positiveAfter :: (Integer, [(Role,Int)])
  , positiveStillLive :: Bool
  , observedPositiveBoundary :: Bool
  } deriving (Eq, Show)

-- Controlled one-view literal from OwnKeyApprovedBoundary, separate fresh
-- owner and independently excluded competing issuers. One accepted enqueue
-- is a positive control for the monotonic observer, not proof of delivery to
-- Elm or of a GTK/native issuer. Count remains valid if a dequeue occurred.
probeValidFresh :: Owner.UiEndpoints -> IO (Integer,[(Role,Int)])
  -> (Owner.TrustedOwnerEvent -> IO (Either Text ())) -> J.Json -> IO PositiveProbe
probeValidFresh endpoints snapshot emit payload = do
  live <- not <$> Owner.uiShouldStop endpoints
  first <- snapshot
  result <- emit (Owner.OwnerTopology payload)
  lastSample <- snapshot
  stillLive <- not <$> Owner.uiShouldStop endpoints
  let correct = live && lookup Controller (snd first) == Just 0
        && result == Right () && fst lastSample == fst first + 1 && stillLive
  pure (PositiveProbe live first result lastSample stillLive correct)

probeMalformedFresh :: Owner.UiEndpoints -> IO (Integer,[(Role,Int)])
  -> (Owner.TrustedOwnerEvent -> IO (Either Text ())) -> J.Json -> IO Probe
probeMalformedFresh endpoints snapshot emit payload = do
  live <- not <$> Owner.uiShouldStop endpoints
  first <- snapshot
  result <- emit (Owner.OwnerTopology payload)
  lastSample <- snapshot
  stopped <- Owner.uiShouldStop endpoints
  let correct = live && lookup Controller (snd first) == Just 0
        && result == Left "UnexpectedFields" && fst first == fst lastSample && stopped
  pure (Probe live first result lastSample stopped correct)
