-- QA ONLY; compile in a SEPARATE isolated after-slot fault overlay build.
-- Root keeps this process and its roots alive after any result/exception, under
-- the existing external guardian and original QA deadline. A StablePtr has no
-- meaning after process termination and does not prove descriptor retirement.
module QHttpAfterSlotRetainedHost (Roots,newRoots,runHosted) where

import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef (IORef,atomicModifyIORef',newIORef)
import Foreign.StablePtr (StablePtr,newStablePtr)
import qualified QHttpConfigAfterSlotControls as Control

data Roots = Roots (IORef Bool) (IORef [StablePtr Control.Case])
-- Root creates exactly one Roots per isolated process. A Roots is single-use
-- even on failure; no subsequent test may reset a possibly live global hook.
newRoots :: IO Roots
newRoots = Roots <$> newIORef False <*> newIORef []

-- Allocate and root the actual owner before read, fault or any process work.
-- Never free the root or interpret a synchronous exception as clean custody.
runHosted :: Roots -> FilePath -> IO (Either SomeException ())
runHosted (Roots used roots) path = mask $ \restore -> do
  first <- atomicModifyIORef' used (\wasUsed -> (True,not wasUsed))
  unless first (ioError (userError "QA config host already used"))
  retained <- Control.newCase
  root <- newStablePtr retained
  atomicModifyIORef' roots (\old -> (root:old,()))
  outcome <- try (restore (Control.runCase retained path))
  case outcome of
    Left problem -> case fromException problem :: Maybe SomeAsyncException of
      Just _ -> throwIO problem
      Nothing -> pure (Left problem)
    Right () -> pure (Right ())
