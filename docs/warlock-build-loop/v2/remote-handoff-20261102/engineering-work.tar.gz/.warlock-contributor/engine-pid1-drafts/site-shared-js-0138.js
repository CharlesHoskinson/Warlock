const root = document.documentElement;
const toggle = document.querySelector('[data-theme-toggle]');
const key = 'warlock-doc-theme-v1';
const themes = ['night', 'dawn', 'high-contrast'];
const nextThemeMeta = {
 night: { next: 'dawn', text: 'Light theme', aria: 'Use light theme' },
 dawn: { next: 'high-contrast', text: 'High contrast', aria: 'Use high contrast theme' },
 'high-contrast': { next: 'night', text: 'Dark theme', aria: 'Use dark theme' }
};
let saved;
try { saved = localStorage.getItem(key); } catch { /* storage is optional */ }
if (themes.includes(saved)) root.dataset.theme = saved;
function labelTheme() {
 if (!toggle) return;
 const meta = nextThemeMeta[root.dataset.theme] || nextThemeMeta.night;
 toggle.textContent = meta.text;
 toggle.setAttribute('aria-label', meta.aria);
}
labelTheme();
toggle?.addEventListener('click', () => {
 const meta = nextThemeMeta[root.dataset.theme] || nextThemeMeta.night;
 root.dataset.theme = meta.next;
 try { localStorage.setItem(key, root.dataset.theme); } catch { /* theme remains usable */ }
 labelTheme();
});
const navButton = document.querySelector('[data-nav-toggle]');
const nav = document.getElementById('site-nav');
if (navButton && nav) {
 const narrow = matchMedia('(max-width: 799px)');
 const update = () => { navButton.hidden = !narrow.matches; nav.hidden = narrow.matches && navButton.getAttribute('aria-expanded') !== 'true'; };
 navButton.addEventListener('click', () => { navButton.setAttribute('aria-expanded', String(navButton.getAttribute('aria-expanded') !== 'true')); update(); });
 document.addEventListener('keydown', e => {
  if ((e.key === 'Escape' || e.key === 'Esc') && !e.isComposing && e.keyCode !== 229 && narrow.matches && navButton.getAttribute('aria-expanded') === 'true') {
   navButton.setAttribute('aria-expanded', 'false'); update(); navButton.focus();
  }
 });
 narrow.addEventListener('change', update); update();
}
const search = document.querySelector('body[data-page=search] input[data-search]');
if (search && document.querySelector('[data-search-results]') && document.querySelector('[data-search-status]')) {
 const list = document.querySelector('[data-search-results]');
 const status = document.querySelector('[data-search-status]');
 fetch(`${document.body.dataset.root}assets/shared/routes.json`).then(r => { if (!r.ok) throw Error('registry'); return r.json(); }).then(data => {
  const routes = data.routes;
  function render() {
   const q = search.value.trim().toLocaleLowerCase();
   list.replaceChildren();
   if (!q) { status.textContent = 'Enter a word to search the guide.'; return; }
   const words = q.split(/\s+/).filter(Boolean);
   const matches = routes.filter(route => {
    const hay = `${route.title} ${route.section} ${(route.keywords || []).join(' ')}`.toLocaleLowerCase();
    return words.every(w => hay.includes(w));
   });
   status.textContent = matches.length ? `${matches.length} results` : 'No results. Try another word or browse the sections below.';
   for (const section of [...new Set(matches.map(x => x.section))]) {
    const heading = document.createElement('h3'); heading.textContent = section; list.append(heading);
    const ul = document.createElement('ul');
    for (const route of matches.filter(x => x.section === section)) { const li = document.createElement('li'); const a = document.createElement('a'); a.href = document.body.dataset.root + route.path; a.textContent = route.title; li.append(a); ul.append(li); }
    list.append(ul);
   }
  }
  search.addEventListener('input', e => { if (!e.isComposing) render(); });
  search.addEventListener('compositionend', render);
  render();
 }).catch(() => { status.textContent = 'Search is unavailable here. Browse the complete section links below.'; });
}
