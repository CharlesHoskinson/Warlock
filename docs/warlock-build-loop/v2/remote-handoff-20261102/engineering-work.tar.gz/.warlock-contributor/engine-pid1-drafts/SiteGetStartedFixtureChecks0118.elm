port module SiteGetStartedFixtureChecks0118 exposing (main)

{-| Pure-Elm deterministic replay & contract fixture for
`SiteGetStartedCssFree0118.elm` (`site/src/SiteGetStarted.elm`).
Worker executes zero compiler/Node/browser/VM commands; Root compiles and runs
in an isolated staging directory alongside `SiteGetStarted.elm`.
-}

import Browser.Dom as Dom
import Json.Decode as Decode
import Json.Encode as Encode
import Platform
import SiteGetStarted
    exposing
        ( AppearanceTheme(..)
        , FocusTarget(..)
        , Model
        , MotionMode(..)
        , Msg(..)
        , OnboardingTrack(..)
        , decodeEscapeMenu
        , decodeTrackTabKey
        , initialModel
        , onboardingTracks
        , stepTrack
        , trackTabDomId
        , update
        )


port outgoing : Encode.Value -> Cmd msg


keyEvent : List ( String, Encode.Value ) -> Encode.Value
keyEvent pairs =
    Encode.object pairs


decodesOk : Decode.Decoder a -> Encode.Value -> Bool
decodesOk decoder raw =
    case Decode.decodeValue decoder raw of
        Ok _ ->
            True

        Err _ ->
            False


decodesErr : Decode.Decoder a -> Encode.Value -> Bool
decodesErr decoder raw =
    not (decodesOk decoder raw)


checks : List ( String, Bool )
checks =
    let
        -- 1. Four onboarding tracks enumerate exact unavailable operations & no-binary truth
        tracksContentOk =
            List.length onboardingTracks
                == 4
                && List.any
                    (\t ->
                        t.track
                            == TrackOmarchyBetaTrial
                            && List.any (String.contains "bar:overview") t.unavailableOrGated
                            && List.any (String.contains "FileNotFoundError") t.unavailableOrGated
                    )
                    onboardingTracks
                && List.any
                    (\t ->
                        t.track
                            == TrackDesignFoundations
                            && List.any (String.contains "ELM-DEL-011") t.unavailableOrGated
                    )
                    onboardingTracks

        -- 2. Roving 4-tab wrap, Home, and End navigation
        rovingOk =
            stepTrack 1 TrackSimulatedBrowser
                == TrackSourceVerification
                && stepTrack -1 TrackSimulatedBrowser
                == TrackDesignFoundations
                && stepTrack 1 TrackDesignFoundations
                == TrackSimulatedBrowser
                && trackTabDomId TrackOmarchyBetaTrial
                == "wl-start-tab-omarchy-beta-trial"

        -- 3. Cross-widget & ABA stale FocusSettled guard
        ( stepped1, _ ) =
            update (KeyboardStepTrack 1) initialModel

        ( stepped2, _ ) =
            update (KeyboardJumpTrack TrackDesignFoundations) stepped1

        ( staleIgnored, _ ) =
            update
                (FocusSettled stepped1.tabFocusSeq (FocusTrackTab TrackSourceVerification) (Err (Dom.NotFound "stale")))
                stepped2

        ( currentRecorded, _ ) =
            update
                (FocusSettled stepped2.tabFocusSeq (FocusTrackTab TrackDesignFoundations) (Err (Dom.NotFound "curr")))
                staleIgnored

        focusGuardOk =
            staleIgnored.lastFocusMiss
                == Nothing
                && currentRecorded.lastFocusMiss
                == Just "wl-start-tab-design-foundations"

        -- 4. IME composition (isComposing=True, keyCode=229, key="Process") strictly ignored
        imeGuardOk =
            decodesErr decodeTrackTabKey
                (keyEvent [ ( "key", Encode.string "ArrowRight" ), ( "isComposing", Encode.bool True ) ])
                && decodesErr decodeTrackTabKey
                    (keyEvent [ ( "key", Encode.string "ArrowRight" ), ( "keyCode", Encode.int 229 ) ])
                && decodesErr decodeTrackTabKey
                    (keyEvent [ ( "key", Encode.string "Process" ) ])
                && decodesErr decodeTrackTabKey
                    (keyEvent [ ( "key", Encode.string "Tab" ) ])
                && decodesOk decodeTrackTabKey
                    (keyEvent [ ( "key", Encode.string "End" ) ])
                && decodesErr decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ), ( "keyCode", Encode.int 229 ) ])
                && decodesOk decodeEscapeMenu
                    (keyEvent [ ( "key", Encode.string "Escape" ) ])

        -- 5. Three-theme & reduced-motion transitions
        ( hcModel, _ ) =
            update (SelectTheme ThemeHighContrast) initialModel

        ( rmModel, _ ) =
            update (SelectMotion MotionReduced) hcModel

        appearanceOk =
            hcModel.theme == ThemeHighContrast && rmModel.motion == MotionReduced
    in
    [ ( "fourOnboardingTracksEnumerateUnavailableOpsAndNoBinary", tracksContentOk )
    , ( "rovingFourTabWrapHomeAndEnd", rovingOk )
    , ( "staleAndCrossTargetFocusSettledRejected", focusGuardOk )
    , ( "imeComposing229ProcessIgnoredAndTabNeverTrapped", imeGuardOk )
    , ( "threeThemeHighContrastAndReducedMotionTransitions", appearanceOk )
    ]


payload : Encode.Value
payload =
    let
        allPassed =
            List.all Tuple.second checks
    in
    Encode.object
        [ ( "fixture", Encode.string "SiteGetStartedFixtureChecks0118" )
        , ( "passed", Encode.bool allPassed )
        , ( "checkCount", Encode.int (List.length checks) )
        , ( "checks"
          , Encode.object
                (List.map (\( name, ok ) -> ( name, Encode.bool ok )) checks)
          )
        ]


main : Program () () Never
main =
    Platform.worker
        { init = \_ -> ( (), outgoing payload )
        , update = \_ state -> ( state, Cmd.none )
        , subscriptions = \_ -> Sub.none
        }
