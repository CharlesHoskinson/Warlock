# First Mapped Omarchy Wayland Window Visual & Source Audit (`engine-display-20261101T163508Z`)

- **Reviewer**: `gemini-gui` (`warlock-20261031-setup`)
- **Timestamp (UTC)**: `2026-11-01T16:47:00Z` (governing availability cutoff `2026-11-01T16:56:00Z`)
- **Evidence Directory Inspected (Read-Only)**:
  `/home/charl/vm/omarchy/evidence/warlock-ui-mvp-20261101/actual-app-20261101T1058Z/engine-display-20261101T163508Z/`
- **Scope & Honesty Boundaries**:
  - Bounded app-only native-on-VM diagnostic (`nativeOperations: []`, `physicalInputs: []`, `nativeAccepted: false`, `releaseAccepted: false`, `protectedQaAccepted: false`, `providerCleanupQualified: false`).
  - All `242` original requirements / `417` scenarios (`15 / 242` whole and `39 / 417` scenarios historical source-scoped), `HOSTSTOP2`, original deadlines `D`, and stopped histories remain unchanged.

---

## 1. Inspected Screenshots & Runtime Artifacts

| Artifact | Size | SHA-256 / Key Fields |
|---|---|---|
| `live-00.png` | `296,984 B` | `d6592a8262eca09cf225d3dd48144eb243746b529dedfdc0fa1f6260752365aa` (`at = 61518.7433s`, `+0.80s` post-launch, `+0.14s` post-map) |
| `live-01.png` | `324,023 B` | `0a9e25a720deb71751c9958bcbe810cbf760bc1ea6dcc6459c0e9c57fd3483ef` (`at = 61521.9489s`, `+4.01s` post-launch — **hydrated Elm Lacquer UI**) |
| `warlock-ui-owner` | `700,496 B` | `7ed083bd270776183ee9569e7715438d89f93296a117f382457e0fbf4260943c` (`dev=58, ino=36472`) |
| `warlock-ui-backend` | `24,080 B` | `0c42a97eca6f55dcbe607f0b371150d5e7073d62db1bff5ba68ec40f11c71b45` (`dev=58, ino=36473`) |
| `HttpMain.html` / `HttpBar.html` / `HttpPopup.html` | `1.06 MB` / `280 KB` / `507 KB` | `60aa950f...` / `a79e3fec...` / `4713fbf1...` |
| `backend.stdout` | `246 B` | `callbacks: 3, operations: 1, credentialRows: 9, selectedPid: 100516, cleanup: true, passed: false, auth: CredentialFrameRejected (CredentialTransport TimedOut)` |
| `trial-result.json` | `1,127 B` | `observedMappedWindow: true, elapsed: 7.4451s, forcedAtOriginalDeadline: false, exit: 1` |

### Process Custody & Pre-Existing `Foot` Preservation
- **Owned PID-1 Display Engine Window**:
  - `warlock-ui-backend` (`PID 100509`, `NSpid=[100509]`) -> `warlock-ui-owner` broker (`PID 100516`, `NSpid=[100516]`) -> `warlock-ui-owner --engine-only` (`PID 100517`, `dev=58, ino=36472`, **`NSpid=[100517, 1]`**), plus `WebKitNetworkProcess` (`100529`) and 3 `bwrap`/`WebKitWebProcess` sandboxes (`100568`, `100580`, `100588`, each `NSpid=[..., 2]`).
  - Hyprland client `address: "0x55fad1594fe0"` (`stableId: "1800001f"`): `pid: 100517`, `xwayland: false` (pure Wayland), `mapped: true`, `visible: true`, `acceptsInput: true`, tiled at **`at: [647, 38], size: [621, 750]`** on workspace `1` (`1280x800` monitor `0`).
- **Session & `Foot` Isolation**:
  - Pre-existing `foot` (`pid: 2095`, `address: "0x55fad233fd80"`, `stableId: "18000005"`) remained intact on the left half during execution and returned to exact `at: [12, 38], size: [1256, 750]` after exit (`preservation-after.json`).
  - `preservation-after.json` confirms `unitMembers: []` (`ActiveState=inactive, SubState=dead`) and `idle-restoration.json` confirms `exit: 0` (`enabled: true`).

---

## 2. Pixel-Level Visual Audit of `live-00.png` and `live-01.png`

### `live-00.png` (`61518.743s`, ~`144ms` After First Hyprland Map Observation)
- **Layout**: `1280x800` Omarchy desktop with top Waybar (`Sunday 09:39`), untouched `Foot` terminal tiled left (`[12, 38]`..`633`), and Warlock's undecorated Wayland window tiled right (`[647, 38], 621x750`) with Hyprland's active light-blue focus border.
- **Chrome Check (`ELM-ARC-002`)**: Zero GTK headerbar, titlebar, close button, or native GTK widget text (`gtkWindowSetDecorated win 0` verified). Shows neutral dark gray (`~#2f2f2e`) initial WebKitGTK surface prior to first Elm paint.

### `live-01.png` (`61521.949s`, `+3.21s` Later — Hydrated Elm Lacquer UI Across All 3 Views)
- **End-to-End 3-Role Hydration Confirmed Visually & by `backend.stdout`**:
  - `callbacks: 3, operations: 1` proves:
    1. `HttpMain.elm` (`cView`) loaded over `NO_PROXY` `127.0.0.1`, emitted initial GDK-topology commit, and received `application-attached` (`protocolVersion: 3, nativeOperations: []`).
    2. `HttpMain.elm` emitted `catalog-request` (`CatalogRead` -> `operations: 1` over the 63 regular `.desktop` files in `catalog-regular-0` + `pins`), received `catalog-snapshot`, and fanned out snapshots over `Warlock.Ui.Owner` SSE `/events` to `HttpBar.elm` (`bView`) and `HttpPopup.elm` (`pView`).
  - **Top `HttpBar` Strip (`bView`, `621px × 72px`)**:
    - Renders in Lacquer Night tokens (`#191516` / `#100E0E` surface, `#F6EFE8` warm ivory text, `#FCA399` / `#B02026` lacquer accent) with zero GTK widgets:
      - **`Applications`**: **Enabled**, crisp `#F6EFE8` bold label inside a rounded lacquer-accented border.
      - **`Task View`**: **Disabled** (`disabled` dashed `#706562` border, muted `#BDB2AF` text).
      - **`Switch windows`**: **Disabled** (`disabled` dashed `#706562` border, muted `#BDB2AF` text).
      - **Status callout (top-right)**: Vertical lacquer-coral left accent rule + 2-line wrapped text `"Applications connected. Window controls unavailable."` — unclipped at `100%` textScale.
  - **Lower `HttpPopup` Region (`pView`, `621px × 677px`)**:
    - Renders Lacquer Night `#100E0E` canvas with section heading **`"Choose a window"`** (left coral accent bar) and status card **`"Applications connected. Window controls unavailable."`** beneath it.

---

## 3. Concrete Visual & Runtime Defects Exposed by `engine-display-20261101T163508Z`

### `V1` — Visible `16px`–`17px` Unstyled Dark Gap Between `.surface-bar` Bottom Border and `Popup` Top (`Warlock/Ui/Mvp.hsc:835,840` vs `SurfaceTheme.elm:290`)
- In `live-01.png`, `.surface-bar` ends at `56px` (`height: calc(3em + 8px)` at `16px` root font, bounded by its visible `1px` bottom border), followed by a `16px`–`17px` blank dark band before `HttpPopup`'s top padding begins (`bView` `size-request = 72px` minus `56px` = `16px`, plus `cView`'s `1px` slot in the vertical `GtkBox`).
- As noted in `D1` (`elm-styling-qa-drafts-source-defect-review-1631.md`), simply hardcoding `56` (`MvpLayout.patch:108`) eliminates the gap at `textScale = 100` but vertically clips `.surface-bar` at `textScale` `125` (`68px`), `150` (`80px`), `175` (`92px`), and `200` (`104px`). Dynamic height sizing from `appearance.textScale` (plus `GtkOverlay` / non-box placement for `1x1` `cView`) resolves both.

### `V2` — Contradictory `"Choose a window"` Heading Directly Above `"Applications connected. Window controls unavailable."` in `live-01.png` (`SurfaceRenderer.elm:214`)
- `live-01.png` visually confirms the exact baseline UX defect in `HEAD` `SurfaceRenderer.elm:214`: when `Popup` starts in `mode == "closed"` under `applicationOnly == True`, the prominent pane heading instructs **"Choose a window"** right above **"Applications connected. Window controls unavailable."**, followed by ~`560px` of empty black canvas.
- When integrating `MvpLayout.patch` to replace this closed-mode app-only state with `"Application Workspace"` + guidance copy, apply fix `D2` (derive `isAppOnlyClosed` structurally from `snapshot.bar` disabled `bar:overview`/`bar:switcher` controls rather than `String.startsWith "Applications connected." snapshot.status`).

### `V3` — Actual Hyprland Tiled Width Is `621px` (Not `980px` Default), Leaving Near-Zero Horizontal Margin in `.surface-bar` for `textScale >= 125%`
- Because Hyprland tiles Warlock 50/50 beside `Foot` on `1280x800`, actual client geometry is **`621 × 750`** (`observations.json:473-476`), ignoring `gtkWindowSetDefaultSize win 980 680`.
- In `live-01.png` at `621px` width and `100%` textScale, the three `.surface-bar` buttons (`Applications`, `Task View`, `Switch windows`) plus the 2-line status banner already occupy ~98% of the `621px` width. At `textScale >= 125%` (`20px`–`32px` font), `.surface-bar` (`display: flex` without `flex-wrap: wrap` and fixed `height: calc(3em + 8px)`, `SurfaceTheme.elm:287-293`) will overflow `621px` horizontally unless `.surface-bar` permits wrapping (`flex-wrap: wrap; min-height: calc(3em + 8px); height: auto`).

### `V4` — Missing Wayland `app_id` / Window Title (`class: "GTK Application", title: ""` in `observations.json:483-486`)
- Hyprland reports `class: "GTK Application", initialClass: "GTK Application", title: "", initialTitle: ""` for `PID 100517` because `Warlock/Ui/Mvp.hsc:828-830` calls `gtkWindowNew` without `gtk_window_set_title` or a `GtkApplication` `application-id`. Setting an explicit title (e.g., `"Warlock"`) improves compositor/accessibility identification without adding GTK decorations (`gtkWindowSetDecorated win 0` remains unchanged).

### `V5` — Exact Source Cause of `elapsed: 7.445s` (`CredentialTransport TimedOut`) After `callbacks: 3, operations: 1`
- `backend.stdout` records `callbacks: 3, operations: 1, credentialRows: 9` followed by `CredentialFrameRejected (CredentialTransport TimedOut)` and clean teardown (`cleanup: true`, `forcedAtOriginalDeadline: false`).
- **Source trace**:
  - `Warlock/Bootstrap/Aggregate.hs:82-92` (`pump`) continuously calls `receiveCredentialIngress ingress guard` while the UI window is open.
  - `Warlock/Transport/Channel.hs:127-137` (`receiveCredentialFrame`) sets a hardcoded **`5,000,000,000` ns (`5.0s`) timeout BEFORE receiving even the first header byte** (`let deadline = toInteger start + 5000000000`, `timeout 5000000 (frame deadline)`) and calls `failFrame` -> `closeChannel channel` on timeout.
  - After the 3 startup commits settled at ~`2.445s` (`application-attached` + `CatalogRead` + settled snapshot), `physicalInputs: []` meant zero user commits arrived for `5.000s`, firing `CredentialTransport TimedOut` at **`2.445s + 5.000s = 7.445s`**. Keeping idle inter-frame wait bounded by the session's monotonic `AdmissionDeadline` `D` (while retaining the `5.0s` mid-frame assembly bound once byte 1 of a frame header is read) is required if interactive sessions must survive `> 5s` of user idle time.
