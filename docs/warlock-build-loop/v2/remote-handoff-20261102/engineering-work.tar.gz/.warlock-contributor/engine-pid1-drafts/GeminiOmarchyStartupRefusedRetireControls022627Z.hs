{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY, UNEXECUTED. Direct source-bound lifecycle controls for v18
-- post-StartupRefused one-shot StopD latching in PhaseRetired, non-poisoning
-- early readiness probes, and bounded Bootstrap retirement under StopD.
module GeminiOmarchyStartupRefusedRetireControls022627Z
  ( Probe
  , newProbe
  , runPreSpawnRefusedThenStopLatch
  , runPostSpawnRefusedThenStopLatch
  , runBootstrapEarlyProbeAndRefusedRetire
  ) where

import Control.Concurrent (ThreadId, forkFinally, threadDelay)
import Control.Concurrent.MVar
  ( MVar
  , newEmptyMVar
  , putMVar
  , readMVar
  , tryPutMVar
  )
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
  ( IORef
  , atomicModifyIORef'
  , modifyIORef'
  , newIORef
  , readIORef
  , writeIORef
  )
import Foreign.StablePtr (StablePtr, newStablePtr)
import System.Timeout (timeout)
import Warlock.Bootstrap
  ( CurrentSessions
  , PersistentBootstrapOwner
  , PersistentBootstrapReadiness(..)
  , PersistentBootstrapResult(..)
  , newCurrentSessions
  , newPersistentBootstrapOwner
  , persistentBootstrapReadiness
  , persistentBootstrapStopDeadline
  , requestPersistentBootstrapStop
  , retirePersistentBootstrap
  , runPersistentBootstrapWithArguments
  )
import Warlock.Capture.Process.Bootstrap
  ( deadlineAbsoluteNs
  )
import Warlock.Capture.Process.Internal
  ( OwnerStatus(..)
  , SessionObservation
  , ToolError(..)
  )
import Warlock.Capture.Process.Persistent
  ( PersistentOwner
  , PersistentStatus(..)
  , SessionExit(..)
  , StopBudget
  , StopDeadlineObservation(..)
  , StopReceipt(..)
  , newPersistentOwner
  , persistentHeldNoInput
  , persistentStatus
  , persistentUnderlyingStatus
  , requestSessionStop
  , startBudgetAfter
  , stopBudgetMicros
  , tryPersistentStopDeadline
  , withPersistentOwner
  )
import Warlock.Capture.Process.Persistent.Internal (withPersistentOwnerHook)
import Warlock.Platform.Executable (HeldExecutable)
import Warlock.Platform.Resolver (Link, Pin, Root)
import qualified Data.ByteString as B

type SessionResult = Either SomeException (Either SessionExit ((), SessionExit))

data Probe = Probe
  !PersistentOwner
  !(IORef (Maybe HeldExecutable))
  !(IORef (Maybe ThreadId))
  !(IORef Bool)
  !(IORef [StablePtr ()])
  !(MVar Bool)
  !(MVar SessionResult)

keepRoot :: IORef [StablePtr ()] -> a -> IO ()
keepRoot roots value = mask_ $ do
  ptr <- newStablePtr (value `seq` ())
  modifyIORef' roots (ptr :)

newProbe :: IO Probe
newProbe = do
  owner <- newPersistentOwner
  heldRef <- newIORef Nothing
  workerRef <- newIORef Nothing
  usedRef <- newIORef False
  rootsRef <- newIORef []
  startDecision <- newEmptyMVar
  doneVar <- newEmptyMVar
  let probe = Probe owner heldRef workerRef usedRef rootsRef startDecision doneVar
  keepRoot rootsRef owner
  keepRoot rootsRef probe
  pure probe

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("v18-retire-controls: " ++ label)))

need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure

within :: String -> IO a -> IO a
within label action =
  timeout 5000000 action
    >>= maybe (ioError (userError (label ++ ": timed out; retain Probe and guardian"))) pure

-- 1. Pre-spawn StartupRefused (StartD expired before borrow/spawn) enters
-- PhaseRetired with mStop == Nothing. Calling requestSessionStop afterward
-- must return StopNoLiveSession while latching the one-shot StopD so outer
-- Bootstrap/Backend cleanup can proceed, and a second call must return
-- StopAlreadyRequested without replacing StopD.
runPreSpawnRefusedThenStopLatch
  :: Probe
  -> (PersistentOwner -> IO HeldExecutable)
  -> IO ()
runPreSpawnRefusedThenStopLatch (Probe owner heldRef _ usedRef rootsRef _ _) supplier = mask $ \restore -> do
  firstUse <- atomicModifyIORef' usedRef (\v -> (True, not v))
  check "single-use Probe" firstUse
  image <- restore (supplier owner)
  keepRoot rootsRef image
  writeIORef heldRef (Just image)
  selection <- need (persistentHeldNoInput image [] [("LANG", "C"), ("LC_ALL", "C")])
  start <- startBudgetAfter 1000 >>= need
  threadDelay 5000
  configured <- need (stopBudgetMicros 500000)
  outcome <- restore (withPersistentOwner owner selection 4096 start configured (\_ -> pure (Right ())) (\_ -> pure ()))
  check "pre-spawn expired StartD returns StartupRefused TimedOut" $
    outcome == Left (StartupRefused TimedOut)
  pStatus <- persistentStatus owner
  uStatus <- persistentUnderlyingStatus owner
  check "owner settled to PersistentRetired / Available" $
    pStatus == PersistentRetired && uStatus == Available
  beforeStop <- tryPersistentStopDeadline owner
  check "StopD not yet latched before explicit post-refusal stop" $
    beforeStop == StopDeadlineNotLatched
  reqBudget <- need (stopBudgetMicros 400000)
  r1 <- requestSessionStop owner reqBudget
  check "first post-refusal requestSessionStop returns StopNoLiveSession" $
    r1 == StopNoLiveSession
  obs1 <- tryPersistentStopDeadline owner
  d1 <- case obs1 of
    StopDeadlineLatched d -> pure (deadlineAbsoluteNs d)
    other -> ioError (userError ("expected StopDeadlineLatched after r1, got: " ++ show other))
  narrowerBudget <- need (stopBudgetMicros 50000)
  r2 <- requestSessionStop owner narrowerBudget
  check "second post-refusal requestSessionStop returns StopAlreadyRequested" $
    r2 == StopAlreadyRequested
  obs2 <- tryPersistentStopDeadline owner
  d2 <- case obs2 of
    StopDeadlineLatched d -> pure (deadlineAbsoluteNs d)
    other -> ioError (userError ("expected StopDeadlineLatched after r2, got: " ++ show other))
  check "sticky StopD preserved across duplicate post-refusal stop" (d1 == d2)

-- 2. Post-spawn StartupRefused (verifyReady returns Left SpawnOrIO) runs
-- retireStartupOrLatchedStop, which closes CallbackGate admission (closed=True)
-- without polluting mStop with Left SessionClosed. Subsequent requestSessionStop
-- in PhaseRetired latches the one-shot StopD instead of failing with SessionClosed.
runPostSpawnRefusedThenStopLatch
  :: Probe
  -> (PersistentOwner -> IO HeldExecutable)
  -> IO ()
runPostSpawnRefusedThenStopLatch (Probe owner heldRef workerRef usedRef rootsRef startDecision doneVar) supplier = mask $ \restore -> do
  firstUse <- atomicModifyIORef' usedRef (\v -> (True, not v))
  check "single-use Probe" firstUse
  let verify (_ :: SessionObservation) = pure (Left SpawnOrIO)
      finish = do
        void (tryPutMVar startDecision False)
        mTid <- readIORef workerRef
        case mTid of
          Nothing -> pure ()
          Just _ -> void (timeout 3000000 (readMVar doneVar))
      body = do
        image <- restore (supplier owner)
        keepRoot rootsRef image
        writeIORef heldRef (Just image)
        selection <- need (persistentHeldNoInput image [] [("LANG", "C"), ("LC_ALL", "C")])
        start <- startBudgetAfter 4000000 >>= need
        configured <- need (stopBudgetMicros 2000000)
        _ <- mask_ $ do
          tid <- forkFinally
            (do
              allowed <- readMVar startDecision
              if allowed
                then restore (withPersistentOwnerHook owner selection 4096 start configured verify (\_ -> pure ()) (\_ -> pure ()))
                else ioError (userError "worker cancelled before start"))
            (putMVar doneVar)
          writeIORef workerRef (Just tid)
          putMVar startDecision True
          pure tid
        result <- within "post-spawn refusal completion" (readMVar doneVar)
        check "post-spawn refusal returns StartupRefused SpawnOrIO" $
          case result of
            Right (Left (StartupRefused SpawnOrIO)) -> True
            _ -> False
        beforeStop <- tryPersistentStopDeadline owner
        check "closeCallbackGate did not poison mStop with SessionClosed" $
          beforeStop == StopDeadlineNotLatched
        reqBudget <- need (stopBudgetMicros 400000)
        r1 <- requestSessionStop owner reqBudget
        check "first stop after post-spawn refusal returns StopNoLiveSession" $
          r1 == StopNoLiveSession
        obs1 <- tryPersistentStopDeadline owner
        d1 <- case obs1 of
          StopDeadlineLatched d -> pure (deadlineAbsoluteNs d)
          other -> ioError (userError ("expected StopDeadlineLatched, got: " ++ show other))
        r2 <- requestSessionStop owner reqBudget
        check "second stop after post-spawn refusal returns StopAlreadyRequested" $
          r2 == StopAlreadyRequested
        obs2 <- tryPersistentStopDeadline owner
        d2 <- case obs2 of
          StopDeadlineLatched d -> pure (deadlineAbsoluteNs d)
          other -> ioError (userError ("expected StopDeadlineLatched, got: " ++ show other))
        check "sticky StopD preserved" (d1 == d2)
  restore body `finally` finish

-- 3. End-to-end PersistentBootstrapOwner control: early readiness/retire probe
-- before Finished returns BootstrapNotReady / False without poisoning cleanup,
-- and after StartupRefused + requestPersistentBootstrapStop, retirePersistentBootstrap
-- succeeds under the latched StopD via tryRetireRegistrationBefore.
runBootstrapEarlyProbeAndRefusedRetire
  :: Root
  -> [Pin]
  -> B.ByteString
  -> [Link]
  -> Integer
  -> B.ByteString
  -> IO ()
runBootstrapEarlyProbeAndRefusedRetire root pins path links size digest = mask $ \restore -> do
  rootsRef <- newIORef ([] :: [StablePtr ()])
  sessions <- newCurrentSessions :: IO CurrentSessions
  keepRoot rootsRef sessions
  stopB <- need (stopBudgetMicros 1000000) :: IO StopBudget
  bOwner <- newPersistentBootstrapOwner sessions stopB :: IO PersistentBootstrapOwner
  keepRoot rootsRef bOwner
  ready0 <- persistentBootstrapReadiness bOwner
  check "fresh bootstrap owner reports BootstrapNotReady" (ready0 == BootstrapNotReady)
  earlyRetire <- retirePersistentBootstrap bOwner
  check "early retirePersistentBootstrap before run returns False" (not earlyRetire)
  start <- startBudgetAfter 1000 >>= need
  threadDelay 5000
  bootOut <- restore $
    runPersistentBootstrapWithArguments
      bOwner
      root
      pins
      path
      links
      size
      digest
      []
      start
      [("LANG", "C"), ("LC_ALL", "C")]
      4096
      (\_ _ _ -> pure ())
  check "expired StartD yields PersistentBootstrapObserved (Left (StartupRefused _))" $
    case bootOut of
      PersistentBootstrapObserved (Left (StartupRefused _)) -> True
      _ -> False
  ready1 <- persistentBootstrapReadiness bOwner
  check "finished bootstrap owner reports BootstrapReady" (ready1 == BootstrapReady)
  retireBeforeStop <- retirePersistentBootstrap bOwner
  check "retirePersistentBootstrap before explicit StopD latch returns False" (not retireBeforeStop)
  stopReceipt1 <- requestPersistentBootstrapStop bOwner
  check "first requestPersistentBootstrapStop after refusal returns StopNoLiveSession" $
    stopReceipt1 == StopNoLiveSession
  stopObs <- persistentBootstrapStopDeadline bOwner
  check "persistentBootstrapStopDeadline is latched after stop request" $
    case stopObs of
      StopDeadlineLatched _ -> True
      _ -> False
  stopReceipt2 <- requestPersistentBootstrapStop bOwner
  check "second requestPersistentBootstrapStop returns StopAlreadyRequested" $
    stopReceipt2 == StopAlreadyRequested
  retired1 <- retirePersistentBootstrap bOwner
  check "retirePersistentBootstrap succeeds under latched StopD" retired1
  retired2 <- retirePersistentBootstrap bOwner
  check "retirePersistentBootstrap is idempotent after clean retirement" retired2
