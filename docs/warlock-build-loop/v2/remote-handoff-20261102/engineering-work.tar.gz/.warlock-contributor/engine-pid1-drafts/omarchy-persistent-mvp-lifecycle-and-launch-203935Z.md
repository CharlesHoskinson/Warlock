# Persistent App-Only MVP Lifecycle, Distinct Immutable Per-Operation Deadlines & Safe Host Launch Callchain (`203935Z`)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **AgentBus Run**: `warlock-20261031-setup`
- **Inspected Git Commit**: `59a2f38ab2b26f6d76cad34039b59911a36188dc` (immutable Elm source `889e9458d1707c456f5bb6e9af560383b066229e`; `ELM-TEA-002` accepted; `16 / 242` whole requirements, `40 / 417` scenarios; `ELM-TEA-001` open; active Root slice `ui005-live-query-refresh`)
- **Hard Invariants Enforced**:
  1. **Diagnostic bootstrap cap (`AdmissionDeadline <= 30_000_000 us` / `30_000_000_000 ns`) is NEVER extended** (`Warlock.Capture.Process.Internal` lines `57-88` and `DeadlineStop.hs` lines `32-33` remain unchanged).
  2. **Distinct immutable per-operation deadline (`OperationDeadline`)**: minted once at operation entry from `CLOCK_MONOTONIC`, carried unchanged across every fragment/step/post-check of that operation, **never renewed, extended, or replayed** on expiry.
  3. **`"nativeOperations": []` remains empty** (`Warlock.Protocol.Desktop` line `200`, `Shell.elm` lines `180-183`).
  4. **`providerCleanup` / `engineCleanup` remains `False`** (`ui/Main.hs` line `75`, `Warlock.Ui.WebKit` lines `488-498`, `Warlock.Ui.EngineCustody` `productionCleanupFacts`), never fabricating provider callback/backing retirement or `nativeAcceptance`.
  5. **Zero worker compiler/model/VM/GPU execution and zero canonical/guest edits**.

---

## 1. Exact Source Map: Why the Current App-Only MVP Terminates at `<= 28s`

In `59a2f38ab2b26f6d76cad34039b59911a36188dc`, `AdmissionDeadline` (`Warlock/Capture/Process/Internal.hsc:56-88`) is a `<= 30s` (`30_000_000_000 ns`) diagnostic process-capture cap (`28s` live budget + `2s` cleanup headroom). Every Haskell layer currently reuses that single `AdmissionDeadline` for **three separate concerns** — (a) bootstrap admission, (b) idle session lifetime, and (c) individual IO operations:

1. **Process Custody & Bootstrap Supervisor**:
   - `Warlock/Capture/Process/Internal.hsc:439-449, 622-640`: `runSelectedDetailed` wraps the entire `conversation` in `timeout remaining` (`<= 30s`), treats `afterConversation == 0` as `TimedOut`, and `poll` kills/reaps the UI leader when `remainingMicros deadline == 0`.
   - `Warlock/Bootstrap/Aggregate.hs:84-86` -> `Warlock/Protocol/Ingress/Internal.hs:296-312` -> `Warlock/Transport/Channel.hs:140-169`: `receiveDesktopCredentialIngressAfterIdle` bounds the idle `threadWaitRead` between desktop commits by `original` (`<= 30s`), closing the channel with `CredentialTransport TimedOut` at `original`. (Notably, `Channel.hs:160` **already** defines a distinct `5s` per-frame deadline `frameDeadline = toInteger start + 5000000000`, currently clamped by `min frameDeadline original` at `L161`.)
2. **UI Owner, HTTP Listeners & Native Socket**:
   - `Warlock/Ui/Config.hs:47, 53-60`: `UiConfig` parses `"deadlineMonotonicNs"` via `deadlineFromAbsoluteNs` (`<= 30s`).
   - `Warlock/Ui/Owner.hs:136-137, 186-188, 230, 271-272` & `ui/Main.hs:88-89`: `stopping` becomes `True` when `remainingMicros deadline <= 0`; `Http.readRequest` and `Http.sendResponse` (`Warlock/Ui/Http.hs:63-88`) pass the session `AdmissionDeadline` instead of a per-HTTP-transaction deadline; `Owner.hs:272` and `ui/Main.hs:89` fail if `remainingMicros deadline <= 0` at exit.
   - `Warlock/Ui/Native.hs:44-72`: `sendCommit` and `receiveGateway` wrap socket IO (including idle wait for the next backend gateway frame!) in `bounded deadline`.
3. **Engine Broker, PID1 Entrypoint & WebKit Loop**:
   - `Warlock/Ui/EngineBroker.hs:69-75, 203, 272, 298-326`: `serveBrokerOnce` checks `remainingMicros (brokerDeadline broker) > 0` on every RPC even minutes into a user session; `Warlock/Ui/EngineProtocol.hs:259, 267` bounds `RemainingReply` to `0 .. 30000000`.
   - `Warlock/Ui/EngineEntrypoint.hs:279-283, 323-330` & `Warlock/Ui/WebKit.hs:459-462`: `startMonitors` spawns `deadlineThread` calling `exitImmediately (ExitFailure 127)` at `D`; `localStop` drains at `D - 1.0s`; `WebKit.loop` exits at `remaining <= 500000` (`D - 0.5s`).
   - `ui/Main.hs:75, 91` & `Owner.hs:294-297`: `runBroker` returns `EngineResult False False` (honestly recording unqualified provider cleanup), which makes `uiPassed == False` -> `exitFailure` (`exit 1`) -> `Backend.hs:227` `Left (Unsuccessful 1)`.
4. **Elm Frontend (`UiHttp.elm`, `DesktopPolicy.elm`, `OutputController.elm`)**:
   - `UiHttp.elm:61-70, 111` **already** uses per-request `timeout = Just 5000` (`5s`) on each HTTP `GET /events` and `POST /commit` / `POST /actions`, and `DesktopPolicy.elm:48-51` **already** uses per-operation `Delay` (`2000ms` / `10000ms`) with zero session-expiry timer.
   - The **only** Elm state that exhausts in a persistent app-only session is `OutputController.elm:296-300`: `OutputController.register` retains every bound request-bearing commit in `model.batches` and refuses at `List.length model.batches >= 16` because real `Owner.hs:211-218` emits `"native-event"` replies rather than synthetic `"view-disposition"` (`"admitted"`).

---

## 2. Minimal Concrete Elm/Haskell Source & API Patch Proposal

### 2.1 Core Types: `SessionMode` & Distinct Immutable `OperationDeadline`

Export from `Warlock.Capture.Process.Bootstrap` / `Internal.hsc` **without modifying `AdmissionDeadline`'s `<= 30s` smart constructors**:

```haskell
-- Constructor private. Minted ONCE at operation entry; NEVER extended or renewed.
newtype OperationDeadline = OperationDeadline Word64 deriving (Eq, Ord, Show)

-- Bounded per-operation budget in microseconds: 1 .. 30_000_000 (<= 30s).
newtype OperationBudget = OperationBudget Int deriving (Eq, Ord, Show)

operationBudgetMicros :: Int -> Either ToolError OperationBudget
operationBudgetMicros us
  | us <= 0 || us > 30000000 = Left BadArguments
  | otherwise = Right (OperationBudget us)

-- Mints one immutable absolute CLOCK_MONOTONIC cutoff for a single operation.
-- When an active AdmissionDeadline applies (DiagnosticBounded mode, or during
-- the Bootstrapping phase of PersistentApplicationOnly mode), caps by min admissionEnd.
mintOperationDeadline
  :: Maybe AdmissionDeadline
  -> OperationBudget
  -> IO OperationDeadline
mintOperationDeadline maybeAdmission (OperationBudget us) = do
  now <- getMonotonicTimeNSec
  let opEnd = now + fromIntegral us * 1000
      capped = case maybeAdmission of
        Nothing -> opEnd
        Just adm -> min opEnd (admissionEndNs adm) -- internal read-only Word64
  pure (OperationDeadline capped)

remainingOperationMicros :: OperationDeadline -> IO Int
remainingOperationMicros (OperationDeadline end) = do
  now <- getMonotonicTimeNSec
  pure $ if now >= end
    then 0
    else fromInteger (min 30000000 ((toInteger (end - now) + 999) `div` 1000))

data OperationCompletion = OperationInTime | OperationExpiredOutcomeUnknown
  deriving (Eq, Show)

checkOperationCompletion :: OperationDeadline -> IO OperationCompletion
checkOperationCompletion opD = do
  left <- remainingOperationMicros opD
  pure (if left <= 0 then OperationExpiredOutcomeUnknown else OperationInTime)
```

Define explicit session lifecycle mode (shared across `BackendConfig`, `UiConfig`, and `EngineProtocol.Startup`):

```haskell
data SessionMode
  = DiagnosticBounded          -- Default when "sessionMode" omitted: 100% existing behavior
  | PersistentApplicationOnly  -- Allowed ONLY when applicationAttachment == True && nativeOperations == []
  deriving (Eq, Show)
```

**Fixed Per-Operation Budgets (Non-Renewable)**:
- `startupAdmissionDeadline :: AdmissionDeadline`: unchanged `"deadlineMonotonicNs"` (`<= 30s` diagnostic bootstrap cap!). Bounds process spawn, binary/HTML pin resolution, peer credential admission, WebKit 3-view `WEBKIT_LOAD_FINISHED`, and first `"application-attached"` + initial catalog commit.
- `ipcFrameBudget`: `5_000_000 us` (`5s`, matching `Channel.hs:160, 239` today) — minted when the first byte of an inbound frame becomes readable or when an outbound commit write begins.
- `httpRequestBudget`: `2_000_000 us` (`2s`) — minted once per accepted loopback HTTP connection in `Owner.serve`, shared across `readRequestOp` + route admission + `sendResponseOp`.
- `engineRpcBudget`: `2_000_000 us` (`2s`) — minted once per `EngineEntrypoint` `makeRpc` call and once per `EngineBroker` `transaction` after socket readability wakes from idle.
- `teardownBudget`: `5_000_000 us` (`5s`) — minted once when stop/close begins, bounding `retireInOrder`, `closeBroker`, `stopEngineProcess`, `Owner` worker join, and `terminateReap`.

---

### 2.2 File-by-File Haskell Patch Specification

1. **`implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Internal.hsc` & `Bootstrap.hs`**:
   - **Leave `AdmissionDeadline`, `deadlineAfter`, `deadlineFromAbsoluteNs`, `deadlineFromAbsoluteNsAt`, `remainingMicros`, and `runSelectedDetailed` 100% unchanged.**
   - Export `OperationDeadline`, `OperationBudget`, `operationBudgetMicros`, `mintOperationDeadline`, `remainingOperationMicros`, `OperationCompletion(..)`, `checkOperationCompletion`, and `runSelectedPersistentDetailed`:
     ```haskell
     runSelectedPersistentDetailed
       :: Owner
       -> SelectedSpawn
       -> Int                                        -- stdout/stderr byte cap (1048576)
       -> AdmissionDeadline                          -- <= 30s startup bootstrap cap!
       -> OperationBudget                            -- per-observation/stop op budget (2s)
       -> (Session -> IO (Either ToolError a))       -- Phase 1: MUST finish before AdmissionDeadline
       -> (Session -> a -> IO (Either ToolError ())) -- Phase 2: steady-state until leader exits
       -> IO SelectedOutcome
     ```
   - Phase 1 runs under `timeout remaining` (`remainingMicros startupDeadline`) and verifies `remainingMicros startupDeadline > 0` immediately on completion; failure/expiry aborts, reaps, and returns `TimedOut`.
   - Phase 2 uses `inScopeOp scope opBudget` (minting a fresh immutable `OperationDeadline` per single `/proc` observation or one-shot `requestStop` `SIGTERM`) and `pollPersistent` (10ms nonblocking pipe cap + `WNOWAIT` check) until leader exit, followed by the unchanged `2s`-bounded `closeSessionScope` -> `drainSessionScope` -> `terminateReap` -> pipe join/close sequence.

2. **`implementation/warlock/haskell/protocol/src/Warlock/Transport/Channel.hs` & `Warlock/Protocol/Ingress/Internal.hs`**:
   - Add `receiveCredentialFrameAfterIdlePersistent` (`Channel.hs`) and `receiveDesktopCredentialIngressPersistent` (`Ingress/Internal.hs`, restricted to `profile == desktopProfile`):
     - Waits on `S.withFdSocket sock (threadWaitRead . fromIntegral)` without wall-clock expiry while idle between commits (wakes immediately on client bytes or `withLeaderExit`'s `shutdownPeerWrite` EOF).
     - The instant `threadWaitRead` wakes, `run` samples `start <- getMonotonicTimeNSec` **once** and fixes `frameDeadline = toInteger start + 5000000000` (`5s`), enforcing `frameDeadline` across `timeout 5000000 (frame frameDeadline)` and `G.dispatchUntil gateValue direction bytes frameDeadline`. Partial/stalled frames fail closed at `5s` and retire the channel without replay.

3. **`implementation/warlock/haskell/runtime/src/Warlock/Bootstrap/Aggregate.hs` & `Warlock/Backend.hs`**:
   - `Aggregate.hs`: add `runBootstrapPersistentWithArguments`:
     - Phase 1 (`admitStartup`, bounded by `startupDeadline :: AdmissionDeadline`): acquires executable lease, claims transfer ticket, observes session PID, opens `withApprovedOwnedPeer`, and requires the **first** `receiveCredentialIngress ingress guard` (`CredentialDelivered`, emitting `"application-attached"` with `"nativeOperations": []`) to complete before `startupDeadline`.
     - Phase 2 (`runConversation`, inside `withLeaderExit`): loops `receiveDesktopCredentialIngressPersistent ingress guard` until clean `CredentialFrameRejected (CredentialTransport StreamEOF)` upon leader exit, then `awaitLeader session`.
   - `Backend.hs` (`decodeConfig` at `L58-76`, `runBackend` at `L129-235`):
     - Accept optional `"sessionMode": "diagnostic-bounded" | "persistent-application-only"` (defaults to `DiagnosticBounded`).
     - Refuse `"persistent-application-only"` unless `attachment == True` (`Left "persistent session requires applicationAttachment"`).
     - Keep `"deadlineMonotonicNs"` mandatory and validated via unchanged `deadlineFromAbsoluteNs` (`<= 30s`).
     - Route `DiagnosticBounded` -> `runBootstrapWithArguments` (unchanged) and `PersistentApplicationOnly` -> `runBootstrapPersistentWithArguments`.
     - `D.applicationAttached` continues to emit `"nativeOperations": []` unconditionally.

4. **`implementation/warlock/haskell/runtime/src/Warlock/Ui/Config.hs`, `Http.hs`, `Native.hs`, `Owner.hs` & `ui/Main.hs`**:
   - `Ui/Config.hs`: parse optional `"sessionMode"` (`uiSessionMode :: UiConfig -> SessionMode`, default `DiagnosticBounded`); keep `uiDeadline :: UiConfig -> AdmissionDeadline` (`<= 30s` startup cap).
   - `Ui/Http.hs`: add `readRequestOp :: OperationDeadline -> S.Socket -> IO (Either HttpError Request)` and `sendResponseOp :: OperationDeadline -> S.Socket -> ... -> IO Bool` using `remainingOperationMicros`. Keep existing `readRequest`/`sendResponse` wrappers for compatibility.
   - `Ui/Native.hs`:
     - Store `IORef Bool` `startupDone` (flipped once by `markNativeStartupComplete :: Native -> IO ()` after initial commit/gateway handshake in `PersistentApplicationOnly` mode).
     - `sendCommit`: mints one immutable `OperationDeadline` (`5s`, capped by `Just startupDeadline` while `not startupDone`, `Nothing` once `startupDone` in `PersistentApplicationOnly`).
     - `receiveGateway`: when `PersistentApplicationOnly && startupDone`, waits on `S.withFdSocket socket (threadWaitRead . fromIntegral)` before reading byte `0`, then mints one immutable `OperationDeadline` (`5s`) for the complete 4-byte length + payload + strict `decodeDesktopGateway` check.
   - `Ui/Owner.hs` & `ui/Main.hs` — **Honest `providerCleanup = False` Separation**:
     - Keep `engineCleanup = False` in `ui/Main.hs:75`! Add explicit `engineSessionCompleted :: Bool` to `EngineResult` (or `uiSessionCompleted :: Bool` on `UiResult`) and `"providerCleanup": false` to `uiResultJson`:
       - `ui/Main.hs:75`: returns `EngineResult { enginePassed = False, engineCleanup = False, engineSessionCompleted = cleanLoopStop }` — **never** setting `engineCleanup = True` or `providerCleanup = True`!
       - In `DiagnosticBounded` mode: `uiPassed` and `ui/Main.hs:91` exit code remain **100% unchanged** (requiring `enginePassed && clean`).
       - In `PersistentApplicationOnly` mode: `Owner.serve` mints one immutable `2s` `OperationDeadline` per accepted HTTP connection; `stopping` stops enforcing `startupDeadline` once initial projection/commit completes before `startupDeadline`; teardown mints one immutable `5s` `OperationDeadline` for worker/socket/engine retirement; and `ui/Main.hs` exits `0` iff `uiSessionCompleted && uiOwnerSocketsClean && uiFailure == Nothing`, while printing `"passed": false, "sessionCompleted": true, "providerCleanup": false, "engineCleanup": false, "nativeAcceptance": false, "releaseAccepted": false`.

5. **`Warlock/Ui/EngineProtocol.hs`, `EngineBroker.hs`, `EngineEntrypoint.hs` & `WebKit.hs`**:
   - Add persistent mode flag to `EngineProtocol.Startup` (optional `"sessionMode": "persistent-application-only"`, keeping default wire bytes 100% identical for existing tests!) and `--engine-persistent` mode to `EngineEntrypoint.classifyMode`.
   - **Startup gate (`<= 30s` `startupDeadline` still enforced!)**:
     - `EngineBroker.completeStartup` (`L190-255`) still runs under `withinOriginalDeadline startupDeadline`.
     - `EngineEntrypoint.startMonitors` (`L271-284`) enforces `startupDeadline` until all 3 WebKit views reach `loadReady` (`WebKit.hs:465`); if 3-view load has not succeeded before `startupDeadline`, `deadlineThread` still calls `exitImmediately (ExitFailure 127)`.
   - **Post-startup per-operation deadlines in `PersistentApplicationOnly`**:
     - `EngineEntrypoint.makeRpc`: each `Idle -> Busy` RPC call mints one immutable `OperationDeadline` (`2s`, capped by `startupDeadline` prior to `loadReady`). Any timeout/post-check expiry marks `RpcState = Dead` permanently with **zero replay**.
     - `EngineBroker.serveBrokerOnce`: waits for socket readability (`threadWaitRead`) or broker retirement while `Ready`, then mints one immutable `OperationDeadline` (`2s`) bounding `readFrame` + `withCredentialAdmission` + `Adapter.serveRequest` + `sendAll` + post-write check.
     - `WebKit.hs:457-470`: once `loaded` before `startupDeadline` in `PersistentApplicationOnly`, `loop mvp` runs until `stopped || any loadFailed active || mvpCloseRequested mvp` (no `remaining <= 500000` cutoff), then mints one immutable `5s` teardown `OperationDeadline` for `retireInOrder` (`L405`) and `stopCustody` (`L483`), returning `wholeClean = False` (`providerCleanup = False`) honestly via `productionCleanupFacts`.

---

### 2.3 Minimal Concrete Elm Patch for Persistent App-Only Sessions (`OutputController.elm`)

Incorporating `sol-docs` (`01M6CD0ZRGQRHQ74T2S80Q1F8B`) and `terra-browser` (`01M6CCY2Y73AEY9PYHMWZ8FYK7`) exact correlation rules:

- **Exact scope of existing 16-batch limit**: `OutputController.register` (`OutputController.elm:295-301`) appends to `model.batches` only on **bound commits with non-empty `requests`** (not on keystrokes like `SearchQuery`, which carry `requests = []`). On `889e9458d`, `"application-attached"` emits `0` startup prelude batches (`Shell.elm:187` emits `[]`, `Desktop.syncMotion` `L708` short-circuits on `applicationOnly`); opening `Applications` adds `1` batch (`catalog-request`), and each subsequent bound `RefreshApplications` / `TogglePin` / `MovePin` commit on the same `binding` adds `1` batch until reaching `16` (`>= 16` refuses).
- **Concrete pure Elm patch (`implementation/warlock/src/OutputController.elm`)**:

```elm
-- L37: track bound pin writes alongside catalogs in Batch:
type alias Batch =
    { scope : Scope
    , revision : Counter
    , publication : Counter
    , lease : Counter
    , binding : Binding.Binding
    , wire : String
    , observations : List ( String, Counter )
    , operations : List UnsentOperation.Key
    , catalogs : List CatalogRequest
    , pins : List CatalogRequest
    }

-- L109-133: after applying Desktop.Incoming raw, retire pure-application
-- batches whose bound catalog/pin requests all received authoritative replies.
-- Mixed/native batches, mismatched bindings/requestIds, and Pins/Launch
-- Unknown/no-replay domain state are never cleared here.
retireSettledApplicationBatches : D.Value -> Model -> Model
retireSettledApplicationBatches raw ((Model model) as current) =
    case (Controller.desktop model.controller).windows.shell.binding of
        Nothing ->
            current

        Just activeBinding ->
            let
                catalogMatch =
                    D.decodeValue
                        (D.map3 (\v kind ( b, r ) -> ( v, kind, ( b, r ) ))
                            (D.field "protocolVersion" D.int)
                            (D.field "kind" D.string)
                            (D.map2 Tuple.pair (D.field "binding" Binding.decoder) (D.field "requestId" UInt64.decoder))
                        )
                        raw

                pinsMatch =
                    D.decodeValue
                        (D.map4 (\v kind ( b, r ) status -> ( v, kind, ( b, r ), status ))
                            (D.field "protocolVersion" D.int)
                            (D.field "kind" D.string)
                            (D.map2 Tuple.pair (D.field "binding" Binding.decoder) (D.field "requestId" UInt64.decoder))
                            (D.field "status" D.string)
                        )
                        raw

                stepBatch batch =
                    if not (List.isEmpty batch.observations) || not (List.isEmpty batch.operations) || batch.binding /= activeBinding then
                        Just batch
                    else
                        let
                            nextCatalogs =
                                case catalogMatch of
                                    Ok ( 3, "application-catalog", ( b, reqId ) ) ->
                                        if b == activeBinding && reqId /= UInt64.zero then
                                            List.filter (\item -> not (item.binding == b && item.request == reqId)) batch.catalogs
                                        else
                                            batch.catalogs

                                    _ ->
                                        batch.catalogs

                            nextPins =
                                case pinsMatch of
                                    Ok ( 3, "taskbar-pins-outcome", ( b, reqId ), status ) ->
                                        if b == activeBinding && reqId /= UInt64.zero && List.member status [ "Saved", "Refused", "Unknown" ] then
                                            List.filter (\item -> not (item.binding == b && item.request == reqId)) batch.pins
                                        else
                                            batch.pins

                                    _ ->
                                        batch.pins
                        in
                        if List.isEmpty nextCatalogs && List.isEmpty nextPins then
                            Nothing
                        else
                            Just { batch | catalogs = nextCatalogs, pins = nextPins }
            in
            Model { model | batches = List.filterMap stepBatch model.batches }
```

---

## 3. Why `Open <Name>` Is Disabled on `889e9458d` & Actual Safe Host Launch Callchain

### 3.1 Why Disabled `Open <Name>` Is Observed in Live Omarchy Today (`889e9458d` / `59a2f38ab`)

If Root observes disabled `Open <Name>` (`entry:<id>`) buttons in the live Omarchy `Applications` popup on `889e9458d`, **that is exact expected fail-closed behavior of the current source tuple**:

1. `Warlock/Backend.hs:193-196` -> `Warlock/Protocol/Desktop.hs:200` emits `{"protocolVersion":3,"kind":"application-attached","binding":...,"nativeOperations":[]}`.
2. `Shell.elm:179-188` sets `model.windows.shell.applicationOnly = True`.
3. Even though `Desktop.elm:430` (`Launch.bind`) and `Desktop.elm:1091` (`Launch.catalog`) **already** populate `model.launch`, `Surface.elm:310-314` computes:
   ```elm
   ready = not model.windows.shell.applicationOnly && not (List.member (Launch.status model.launch) ["Pending","Unknown"])
   ```
   forcing `ready == False`, `choice == Nothing`, `"enabled": false`, and `message == Nothing` on every `entry:<id>` control.
4. Three additional gates also currently block `"application-launch"` behind `Surface.elm:310`:
   - `Desktop.elm:621, 732-742` (`PointerOwnership.elm:25-33`): `PointerOwnership.blocked` is `True` without a native pointer observer, and `applicationGesture` omits `Start _`.
   - `OutputController.elm:274`: `applicationOnly` oversize check omits `"application-launch"`.
   - `Warlock/Protocol/Desktop.hs:21-30, 117-123` & `Warlock/Backend.hs:151-185`: `"application-launch"` is rejected with `Left "unsupported desktop request kind"` (`Owner.hs:210` `HTTP 400`), and `Backend` has no launch authority yet.

### 3.2 Actual Safe Host Application Launch Callchain (Corrected for Cgroup & Exec-Confirmation Boundaries)

Incorporating `sol-docs` (`01M6CCZCXKAWVVHGZ700KT1D4P`) boundary review:
- **Boundary Fact 1 (Cgroup Custody)**: When `warlock-ui-backend` runs inside `qa-harness.scope` (or a Warlock unit cgroup), `fork()` + `setsid()` inside `warlock-ui-backend` **does NOT leave that Linux cgroup v2** — tearing down the UI trial scope would kill the launched app, or a lingering app would block scope cleanup.
- **Boundary Fact 2 (Pipe `EOF` != `execve` Success)**: `EOF` (`0` bytes) on a `CLOEXEC` status pipe proves only that all writers closed the descriptor; a child killed by signal/crash *before* `execve` also produces `EOF` and must **never** be misclassified as `Submitted`.
- **Boundary Fact 3 (`ELM-UI-004` Taskbar Pin Separation)**: Taskbar `bar:pin:<id>` (`Surface.elm:409`) and `NewInstance` (`Desktop.elm:1375`) **must remain disabled** while `Shell.available == False` (`nativeOperations == []`) because `ELM-UI-004` forbids launching duplicate windows when a pinned app already has open windows (unknowable without compositor window observation). Only explicit catalog `entry:<id>` (`Open <Name>`) inside `Applications` may launch.

**Safe End-to-End Callchain**:
1. **Attachment Capability (`Shell.elm` + `Warlock.Protocol.Desktop`)**:
   - Replace raw `Shell.Model.applicationOnly : Bool` with closed `AttachmentMode = WindowShellMode | ApplicationOnlyMode HostLaunchCapability` (`HostLaunchUnavailable | HostDesktopLaunch`), keeping `"nativeOperations": []` and `Shell.available == False`.
   - Default 4-field `"application-attached"` decodes to `ApplicationOnlyMode HostLaunchUnavailable` (100% byte-identical for all existing tests); 5-field `"application-attached"` with `"hostLaunch": true` is emitted only when `BackendConfig` enables `"applicationLaunch": true` **and** a verified external user-session launch driver is bound.
2. **Elm Dispatch (`Surface.elm:310` -> `Desktop.elm:621, 732, 1383-1391` -> `OutputController.elm` -> `Owner.hs` -> `Backend.hs`)**:
   - `Surface.elm:310` checks `Shell.catalogLaunchAvailable model.windows.shell`; `Desktop.elm:732` permits `Start _` under `Shell.catalogLaunchAvailable`; `Desktop.Start` emits `"application-launch"` (`request`, `lifetime`, `generation`, `entry`) and arms Elm's single `10s` `Desktop.Arm` timer (`Settled intent Unknown` on expiry, requiring explicit `"control:acknowledge"`, zero retry).
3. **Backend High-Water Reservation & Race Verification (`Warlock.Backend` + `Warlock.Backend.Catalog`)**:
   - Check `reqBinding == bound && launchLifetime == lifetime bound` (`RetiredAuthority`), exact `(lastId, lastIntent)` idempotent cached reply resend (**zero replay**), `request == lastId && intent /= lastIntent` (`RequestReuse`), `request < lastId` (`RetiredRequest`).
   - Verify `launchCatalog == activeCatalog.generation` (`CatalogUnavailable` / `StaleCatalog`) and re-verify all catalog root `directoryStamp`s + winning `.desktop` file `(dev, ino, size, mtime, sha256)` via `O_NOFOLLOW` (`RemovedEntry` / `DesktopEntryRaced`) + direct XDG `Exec` argv vector (`Terminal=false`, valid quoting, resolved regular executable, **zero `/bin/sh`**; else `NativeEntryUnavailable`).
   - **Persist `LaunchUnknown` (`"submission-not-confirmed"`) in `lastLaunch` BEFORE invoking the external session launcher** under a distinct immutable `OperationDeadline` (`mintOperationDeadline activeAdmission launchBudget`).
4. **Outside-Cgroup Execution & Verified `execve` Receipt (`HostLaunchDriver`)**:
   - Rather than in-cgroup `fork`+`setsid`+pipe-`EOF`, `warlock-ui-backend` submits `(execPath, argv, workingDir, allowlistedDesktopEnv)` over the ordinary user session's `systemd --user` D-Bus manager (`org.freedesktop.systemd1.Manager.StartTransientUnit`, transient `.service` with **`Type=exec`** under `app.slice`, completely outside `qa-harness.scope` and outside `warlock-ui-owner`'s private namespaces, with zero inherited Warlock FDs):
     - **`Type=exec` `JobRemoved("done")` received before `opDeadline`**: `systemd --user` confirms actual kernel `execve()` of `execPath` in the external user unit -> update `lastLaunch` to `LaunchSubmitted` (`"native-submission-accepted"`).
     - **Explicit pre-exec refusal / `JobRemoved("failed")` before `opDeadline`**: update `lastLaunch` to `LaunchRefused NativeEntryUnavailable`.
     - **`opDeadline` expiry, D-Bus disconnect, or unconfirmed state**: leave `LaunchUnknown` (`"submission-not-confirmed"`) in `lastLaunch` and return `LaunchUnknown` (never replayed).

---

## 4. Verified Canonical Source & QA SHA-256 Inventory (`HEAD = 59a2f38ab2b26f6d76cad34039b59911a36188dc`)

### Authored Elm Production Sources (`889e9458d1707c456f5bb6e9af560383b066229e`)
- `6f6a63168d1d39da6e85290b564074ca21f7c719140aacee939973e3706ad094`  `implementation/warlock/src/Shell.elm`
- `91d38d818e40523cd395d3622633676149c42b8b9b0be3a40223a13bdf45d9ca`  `implementation/warlock/src/Surface.elm`
- `91223c94074f8ff908b2ed66f52e8025c8afcb78a977d4a5f3daf44df8ce7af4`  `implementation/warlock/src/Desktop.elm`
- `dcd7260248ccb0b5bc6001c49319dd51af8c2fae98888919a308ac025ed273a2`  `implementation/warlock/src/Launch.elm`
- `fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae`  `implementation/warlock/src/OutputController.elm`
- `018934fe4762e8357665ce7c37cb289883c6cdd1bad31d6592402b369d7bad3e`  `implementation/warlock/src/DesktopPolicy.elm`
- `3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419`  `implementation/warlock/src/UiHttp.elm`
- `58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9`  `implementation/warlock/src/HttpMain.elm`
- `74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8`  `implementation/warlock/src/HttpBar.elm`
- `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354`  `implementation/warlock/src/HttpPopup.elm`

### Authored Haskell Production & Preparation Sources
- `dc8273cb33d6f23757b20f16f7cefc83d00fc8ab4d00520149744928bbd1a461`  `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Bootstrap.hs`
- `f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f`  `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Internal.hsc`
- `239baa18beb62f837dafa64fd552775835f7737ed98f836958b8c40c51765169`  `implementation/warlock/haskell/protocol/src/Warlock/Protocol/Desktop.hs`
- `8aef3a3a1ac06806afc330fa4d677a3264f8a504315edc87223e6511b4308bfc`  `implementation/warlock/haskell/protocol/src/Warlock/Protocol/Ingress/Internal.hs`
- `f97fad97579df5e9bd8156b8a0ecc54daffeea9872666220aa6fcf38f47c4868`  `implementation/warlock/haskell/protocol/src/Warlock/Transport/Channel.hs`
- `6d26e1f8362f96d9894143c719a79ade7610f9c444101eb9f9c4e52ad5da8099`  `implementation/warlock/haskell/runtime/src/Warlock/Backend.hs`
- `4d5046a6a3c646196ab354553bc368c55046815831f982477f67c164c238ee83`  `implementation/warlock/haskell/runtime/src/Warlock/Backend/Catalog.hs`
- `fdf9b224707611600919b349e868fd2883dbc637e9d5707750191dbd21a9a824`  `implementation/warlock/haskell/runtime/src/Warlock/Bootstrap/Aggregate.hs`
- `e737412f400ae5a9d53625152a23bbc8883bb6558d85770dd8e14bcb4bb8f969`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/Config.hs`
- `63cebd1a5ec38b7faa6b713dacec64f62b1e15e5cda8dbc1284dd757e6d29a04`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/EngineBroker.hs`
- `e4c842070ec57eea368f50519081668433a92874c93d0a13983f154c3a4b0182`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/EngineDeadline.hs`
- `1684af2c7eeee727fc3007e6dcda90da52ad48fe9926a22a9ed489bf6050b1e0`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/Http.hs`
- `a3467864d1f675d7943c6799d5b192f7a36f5494792fb6e2cb9f1671d6053665`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/Native.hs`
- `a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9`  `implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs`
- `50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7`  `implementation/warlock/haskell/runtime/ui/Main.hs`
- `5028eed1eae2df6f066d3868777af686aa0ddb889a651159b26cb3369c4129de`  `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc`
- `941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080`  `implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineEntrypoint.hs`
- `57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6`  `implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc`
- `b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a`  `implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs`

### Formal Spec & QA Suites Inspected
- `0ab50a535e453613c1ae32b64e7f0958f4b79549c8a658db2d1a257548f36eab`  `implementation/warlock/haskell/runtime/formal/ui-standalone-bootstrap.qnt`
- `73d44888cd349224663790847e2ac593c3fb60ec27cd07fcbfef9b130cc00166`  `implementation/warlock/haskell/process-custody/test/DeadlineStop.hs`
- `fbecd69382db445e055cb78f89fde88dafed74a091d91856a934dce18408ff6a`  `implementation/warlock/haskell/protocol/test-desktop/Main.hs`
- `e5cbed6fa0951ea8cc4cd880b76ade7c35c432a5656bb102c47337cb6e668c5f`  `implementation/warlock/haskell/runtime/test-persistent/Main.hs`
- `59734f573a693289be3dc74e0880cb66be5e155d226a96b529a9be70bdd2dffd`  `implementation/warlock/haskell/runtime/test-ui-mvp/Main.hs`
- `9ea25d4d20a7cc6c63f865b4bafd20f1356d021d1f3ca58ef5b9d78df7a72bed`  `implementation/warlock/haskell/runtime/test-ui-origin/Main.hs`
- `b5741ca909729a17c529c24e41e47359e7b2dc02b6cbd5b506fb4fb48c1ef74a`  `implementation/warlock/haskell/runtime/test-ui-engine-protocol/DesktopIdleControls.hs`
