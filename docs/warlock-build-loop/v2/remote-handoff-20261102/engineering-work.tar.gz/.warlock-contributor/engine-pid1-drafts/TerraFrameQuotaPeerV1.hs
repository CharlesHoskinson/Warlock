{-# LANGUAGE OverloadedStrings #-}
-- Root builds this private owned child. It emits one checked desktop frame,
-- then stays alive until its caller-owned marker is removed. No native action.
module Main (main) where

import Control.Concurrent (threadDelay)
import Control.Monad (unless)
import qualified Data.ByteString as B
import qualified Data.ByteString.Char8 as C
import System.Directory (doesFileExist)
import System.Environment (getArgs)
import System.IO (BufferMode(NoBuffering), hClose, hFlush, hSetBinaryMode, hSetBuffering)
import System.Posix.IO (fdToHandle)
import System.Posix.Types (Fd(..))
import qualified Warlock.Protocol.Framing as F

packet :: Int -> B.ByteString
packet n = B.concat
 [ "{\"viewProtocol\":1,\"kind\":\"view-commit\",\"projection\":{\"viewProtocol\":1,\"kind\":\"view-frame\",\"revision\":\"1\",\"views\":[],\"focusOwner\":null,\"popupOwner\":null,\"frame\":{\"surfaceProtocol\":2,\"publication\":\"1\",\"lease\":\"0\",\"mode\":\"closed\",\"status\":\"QA\",\"bar\":[{\"id\":\"qa:focus-valid\",\"domId\":\"focus-valid\",\"label\":\"QA control\",\"ariaLabel\":\"QA control\",\"detail\":\"\",\"enabled\":true,\"focusOnly\":false}],\"popup\":[]},\"announcer\":null,\"announcement\":null},\"requests\":["
 , B.intercalate "," (map request [1..n]), "],\"focus\":[]}"
 ]
 where
  request i = B.concat ["{\"protocolVersion\":3,\"kind\":\"catalog-request\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"requestId\":\"", C.pack (show i), "\"}"]

waitRemoval :: FilePath -> Int -> IO Bool
waitRemoval marker attempts = do
 exists <- doesFileExist marker
 if not exists then pure True
 else if attempts <= 0 then pure False
 else threadDelay 10000 >> waitRemoval marker (attempts - 1)

main :: IO ()
main = do
 args <- getArgs
 (marker,n) <- case args of
  [path,"16"] | not (null path) && head path == '/' -> pure (path,16)
  [path,"17"] | not (null path) && head path == '/' -> pure (path,17)
  _ -> ioError (userError "expected owned marker and 16 or 17")
 framed <- either (ioError . userError . show) pure (F.desktopCommitPrefix (packet n))
 h <- fdToHandle (Fd 0)
 hSetBinaryMode h True
 hSetBuffering h NoBuffering
 -- Separate writes do not assume kernel recvmsg fragmentation boundaries.
 let (first,rest) = B.splitAt 3 framed
 B.hPut h first
 B.hPut h rest
 hFlush h
 removed <- waitRemoval marker 1000
 unless removed (ioError (userError "caller-owned marker remained present"))
 hClose h
