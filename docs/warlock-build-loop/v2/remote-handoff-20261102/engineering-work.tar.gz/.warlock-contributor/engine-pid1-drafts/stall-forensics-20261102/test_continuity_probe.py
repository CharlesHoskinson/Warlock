"""Unexecuted source tests for the non-launching continuity proposal."""
import unittest
from continuity_probe import evaluate


class ContinuityTests(unittest.TestCase):
    def snapshot(self, **changes):
        data = dict(goalStatus="active", goalObservedEpoch=1000,
                    checkpointEpoch=1000, censusEpoch=1000, workerCount=1,
                    protectedJobLive=False, leadActionLive=False,
                    coordinatorCount=1, internalRepairPending=False)
        data.update(changes)
        return data

    def test_internal_failure_is_attention_without_launch(self):
        result = evaluate(self.snapshot(goalStatus="blocked", internalRepairPending=True), 1010)
        self.assertEqual(result["state"], "attention")
        self.assertFalse(result["mayLaunch"])

    def test_current_busy_wave_is_not_called_idle(self):
        self.assertEqual(evaluate(self.snapshot(), 1010)["state"], "observed")

    def test_empty_actual_wave_detected_only_with_actual_job_observations(self):
        self.assertEqual(evaluate(self.snapshot(workerCount=0), 1010)["state"], "attention")
        s = self.snapshot(workerCount=0); del s["leadActionLive"]
        self.assertEqual(evaluate(s, 1010)["state"], "observed")

    def test_stale_or_future_goal_is_unknown(self):
        for observed in (0, 2000, None, True):
            result = evaluate(self.snapshot(goalObservedEpoch=observed), 1010)
            self.assertEqual(result["state"], "unknown")
            self.assertFalse(result["mayLaunch"])

    def test_pause_and_complete_never_resume(self):
        for status in ("paused", "complete"):
            result = evaluate(self.snapshot(goalStatus=status, workerCount=0), 1010)
            self.assertEqual(result["state"], "quiescent")
            self.assertFalse(result["mayLaunch"])

    def test_duplicate_coordinator_never_launches(self):
        result = evaluate(self.snapshot(coordinatorCount=2), 1010)
        self.assertEqual(result["state"], "attention")
        self.assertFalse(result["mayLaunch"])

    def test_external_blocker_does_not_hide_stale_checkpoint(self):
        result = evaluate(self.snapshot(goalStatus="blocked", checkpointEpoch=0), 1010)
        self.assertEqual(result["state"], "attention")
        self.assertFalse(result["acceptanceInferred"])


if __name__ == "__main__":
    unittest.main()
