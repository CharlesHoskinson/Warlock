"""Pure continuity diagnosis proposal. Never launches, renews, writes or accepts work.

Input is a sanitized normalized snapshot supplied by the existing lead collector.
Installing a scheduler or an actual lead wake channel is separate work, not done here.
No keys, transcript bodies, shell commands, arbitrary subprocesses or env reads.
"""
import json
import sys


def evaluate(snapshot, now):
    reasons = []
    status = snapshot.get("goalStatus", "unknown")
    goal_age = age(snapshot.get("goalObservedEpoch"), now)
    if goal_age is None or goal_age > 120:
        return {"state": "unknown", "reasons": ["Need fresh actual goal observation"],
                "mayLaunch": False, "acceptanceInferred": False}
    if status in ("complete", "paused"):
        return {"state": "quiescent", "reasons": [], "mayLaunch": False,
                "acceptanceInferred": False}
    if status not in ("active", "blocked"):
        reasons.append("Unknown actual goal status")
    checkpoint_age = age(snapshot.get("checkpointEpoch"), now)
    if checkpoint_age is None or checkpoint_age > 300:
        reasons.append("Checkpoint stale or unavailable")
    census_age = age(snapshot.get("censusEpoch"), now)
    if census_age is None or census_age > 120:
        reasons.append("Worker census stale or unavailable")
    if status == "blocked" and snapshot.get("internalRepairPending") is True:
        reasons.append("Internal repair remains; reported blocked needs lead attention")
    # An external-blocker label never authorizes restart or suppresses stale evidence.
    if (status == "active" and census_age is not None and census_age <= 120
            and snapshot.get("workerCount") == 0
            and snapshot.get("protectedJobLive") is False
            and snapshot.get("leadActionLive") is False):
        reasons.append("Active goal has no observed current work")
    if snapshot.get("coordinatorCount", 0) > 1:
        reasons.append("Duplicate coordinators observed; refuse launch")
    return {"state": "attention" if reasons else "observed",
            "reasons": reasons, "mayLaunch": False, "acceptanceInferred": False}


def age(epoch, now):
    if type(epoch) not in (int, float) or not 0 <= epoch <= now:
        return None
    return now - epoch


if __name__ == "__main__":
    # An explicit timestamp keeps the evaluator reproducible and has no side effects.
    data = json.load(sys.stdin)
    result = evaluate(data["snapshot"], data["nowEpoch"])
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(20 if result["state"] in ("attention", "unknown") else 0)
