'use strict';
// QA ONLY. Root compiles SolScopedPopup0438 WITHOUT --optimize.
// Usage (ROOT ONLY): node sol-scoped-popup-0440.cjs /absolute/SolScopedPopup0438.js /absolute/repository
// The compiled fixture invokes Debug.log on exactly the unchanged tuple returned
// by Popup.transition. The sole temporary in-memory insertion intercepts
// that marker before Elm formats it. It does not change reducer functions,
// compiled source on disk, ports, values, or product build inputs. Both exact
// bundle hashes and the reversible byte patch are reported. No native claim.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const { isDeepStrictEqual } = require('node:util');
const MARKER = 'SOL_SCOPED_POPUP_COMPLETE_V1';
const HOOK = '__solScopedPopupCaptureV1';
const WAIT_MS = 10000;
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
function insist(condition, message) { if (!condition) throw new Error(message); }
const trustedPrototypes = new WeakMap();
function registerPrototype(proto, kind) {
  const descriptors = Object.getOwnPropertyDescriptors(proto);
  trustedPrototypes.set(proto, { kind, descriptors });
}
function registerRealm(context) {
  const intrinsics = vm.runInContext('({object: Object.prototype, array: Array.prototype})', context);
  registerPrototype(intrinsics.object, 'object');
  registerPrototype(intrinsics.array, 'array');
}
function checkPrototype(proto, kind, where) {
  if (proto === null && kind === 'object') return;
  const saved = trustedPrototypes.get(proto);
  insist(saved && saved.kind === kind, `${where}: untrusted prototype`);
  const now = Object.getOwnPropertyDescriptors(proto);
  const keys = Reflect.ownKeys(saved.descriptors);
  insist(keys.length === Reflect.ownKeys(now).length, `${where}: changed intrinsic prototype`);
  for (const key of keys) {
    const before = saved.descriptors[key];
    const after = now[key];
    insist(after && ['value', 'get', 'set', 'writable', 'enumerable', 'configurable']
      .every(field => Object.is(before[field], after[field])), `${where}: changed intrinsic prototype member`);
  }
}
registerPrototype(Object.prototype, 'object');
registerPrototype(Array.prototype, 'array');

// Preserve every own data field, including constructor tags, list cells,
// tuples, opaque wrappers and JSON values. Functions, cycles, accessors, sparse
// arrays, exotic prototypes, non-finite or non-JSON numbers and symbols fail:
// the harness must never silently shrink a model or a typed effect.
function full(value, where = '$', active = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    insist(Number.isFinite(value) && !Object.is(value, -0), `${where}: unsupported number`);
    return value;
  }
  insist(typeof value === 'object', `${where}: unsupported ${typeof value}`);
  insist(!active.has(value), `${where}: cyclic value`);
  insist(Object.getOwnPropertySymbols(value).length === 0, `${where}: symbol property`);
  active.add(value);
  try {
    const descriptors = Object.getOwnPropertyDescriptors(value);
    if (Array.isArray(value)) {
      checkPrototype(Object.getPrototypeOf(value), 'array', where);
      const keys = Object.keys(descriptors).filter(key => key !== 'length');
      insist(keys.length === value.length && keys.every((key, i) => key === String(i)), `${where}: sparse or extended array`);
      return keys.map(key => {
        const d = descriptors[key];
        insist(d && 'value' in d && d.enumerable, `${where}[${key}]: non-data property`);
        return full(d.value, `${where}[${key}]`, active);
      });
    }
    checkPrototype(Object.getPrototypeOf(value), 'object', where);
    const out = Object.create(null);
    for (const key of Object.keys(descriptors).sort()) {
      const d = descriptors[key];
      insist(d && 'value' in d && d.enumerable, `${where}.${key}: accessor or hidden property`);
      Object.defineProperty(out, key, { value: full(d.value, `${where}.${key}`, active), enumerable: true });
    }
    return out;
  } finally { active.delete(value); }
}

function instrument(original) {
  // Anchor to the actual non-optimized Elm debug implementation, not the
  // _UNUSED placeholder. Reject compiler layout changes rather than guessing.
  const definition = /var _Debug_log\s*=\s*F2\(function\s*\(tag,\s*value\)\s*\{/g;
  const matches = [...original.matchAll(definition)];
  insist(matches.length === 1, 'expected exactly one Elm _Debug_log definition');
  const begin = matches[0].index + matches[0][0].length;
  const end = original.indexOf('});', begin);
  insist(end > begin && end - begin < 1000, 'unrecognized _Debug_log body');
  const body = original.slice(begin, end);
  insist(body.includes('_Debug_toString(value)') && /return\s+value\s*;/.test(body), 'fixture must be unoptimized debug Elm');
  insist(original.split(MARKER).length === 2, 'expected exactly one fixture observation marker');
  insist(!original.includes(HOOK), 'capture hook already present');
  const insertion = `\nif (tag === ${JSON.stringify(MARKER)}) { globalThis.${HOOK}(value); }\n`;
  const changed = original.slice(0, begin) + insertion + original.slice(begin);
  insist(changed.slice(0, begin) + changed.slice(begin + insertion.length) === original, 'instrumentation not exactly reversible');
  return { changed, insertionOffset: begin, insertedBytes: Buffer.byteLength(insertion) };
}

// Independent SOURCE transcriptions. No expected field is read from Elm,
// copied from a captured result, or omitted from the complete model/effects.
// Debug constructor/Dict/JSON layouts are predictions pinned for Root's
// actual nonoptimized compiler artifact; unsupported layouts fail closed.
const ctor = (name, ...values) => Object.fromEntries([
  ['$', name], ...values.map((value, index) => [String.fromCharCode(97 + index), value]),
]);
const nothing = () => ctor('Nothing');
const just = value => ctor('Just', value);
const counter = value => ctor('Counter', value);
const nil = () => ctor('[]');
const list = values => values.reduceRight((tail, head) => ctor('::', head, tail), nil());
const dictEmpty = () => ctor('RBEmpty_elm_builtin');
const jsonValue = value => ({ $: 0, a: value });
const binding = { lifetime: '1', session: '2', frontend: '3' };
const domain = { binding, receiverEpoch: '4' };
const nativeDomain = { lifetime: counter('1'), session: counter('2'),
  frontend: counter('3'), receiverEpoch: counter('4') };
const grant = { domain: nativeDomain, capacity: 1 };
const reconcile = { kind: 'reconcile', binding };
const intent = { identity: 'binding:1:2:3', command: jsonValue(reconcile) };
const row = { identity: 'binding:1:2:3', commands: [reconcile] };
const envelope = rows => ({ previewProtocol: 3, kind: 'preview-proposals',
  binding, receiverEpoch: '4', entries: rows });
function popup(enrolled = false, closing = false, pending = false) {
  const maybeGrant = enrolled ? just(grant) : nothing();
  const policy = ctor('Model', dictEmpty(), nothing(), {
    observed: nothing(), settled: nothing(),
    channel: enrolled ? just('1:2:3') : nothing(), processed: counter('0'),
  }, { grant: maybeGrant, closing, closed: false, processed: counter('0'), completed: dictEmpty() });
  return {
    announcements: ctor('Model', { last: counter('0'), active: false, message: nothing() }),
    presentation: ctor('Model', { last: counter('0'), lease: counter('0'), snapshot: nothing() }),
    previews: ctor('Model', policy, maybeGrant,
      enrolled ? just(ctor('Model', grant, list(pending ? [intent] : []))) : nothing(), nil()),
    paintGate: ctor('Model', counter('0'), dictEmpty()),
    pendingQuery: nothing(), composition: ctor('Idle'), lastQuery: nothing(),
  };
}
const effects = rows => list([
  ctor('PreviewCommand', jsonValue(envelope(rows))), ctor('PaintRequest', jsonValue([])),
]);
function input(name, kind, value) { return { name, kind, value }; }
function issued(ordinal, packetOrdinal, changed = {}) {
  // Literal native ticket wire, supplied as fixture input, never generated
  // from reducer output. This is NOT proof an actual native issuer sent it.
  const wire = JSON.stringify({ previewProtocol: 3, kind: 'preview-commands',
    binding, receiverEpoch: '4', controlOrdinal: packetOrdinal, entries: [row] });
  return { previewProtocol: 3, kind: 'preview-control-ticket', binding,
    receiverEpoch: '4', controlOrdinal: ordinal, alreadyDelivered: false, wire, ...changed };
}
const popupCases = [
  { input: input('initial-hidden', 'reset', null), state: popup(), effects: nil() },
  { input: input('valid-native-grant-hidden', 'grant', { ...domain, capacity: 1 }),
    state: popup(true), effects: nil() },
  { input: input('hidden-quarantine-reconcile-preserves-envelope', 'quarantine', domain),
    state: popup(true, true, true), effects: effects([row]) },
  { input: input('duplicate-quarantine-retains-same-unissued-intent', 'quarantine', domain),
    state: popup(true, true, true), effects: effects([row]) },
  { input: input('mismatched-issued-ordinal-does-not-clear', 'issued', issued('2', '1')),
    state: popup(true, true, true), effects: nil() },
  { input: input('foreign-issued-domain-does-not-clear', 'issued', issued('1', '1', { receiverEpoch: '5' })),
    state: popup(true, true, true), effects: nil() },
  { input: input('exact-issued-clears-only-matching-intent', 'issued', issued('1', '1')),
    state: popup(true, true), effects: nil() },
  { input: input('hidden-retry-retains-empty-domain-envelope', 'retry', domain),
    state: popup(true, true), effects: effects([]) },
  { input: input('foreign-retry-cannot-resurrect-work', 'retry', { ...domain, receiverEpoch: '5' }),
    state: popup(true, true), effects: effects([]) },
  { input: input('foreign-quarantine-cannot-resurrect-work', 'quarantine', { ...domain, receiverEpoch: '5' }),
    state: popup(true, true), effects: effects([]) },
  { input: input('malformed-quarantine-keeps-complete-state', 'quarantine', null),
    state: popup(true, true), effects: list([
      ctor('PreviewCommand', jsonValue([])), ctor('PaintRequest', jsonValue([])),
    ]) },
];

// A second named fixture drives the ACTUAL Gate.queue/painted functions.
// Its independent opaque Gate model and the entire unchanged Popup model
// remain observed together. No production model constructor is exposed.
const job = { binding: 'owned-preview-source', context: 'same-context', request: '1',
  origin: '1', clock: '7', deadline: '5000' };
const acquire = { kind: 'acquire', job };
const cancel = { kind: 'cancel', job };
const legacy = command => [{ identity: 'family:1', commands: [command] }];
const scoped = (command, epoch = '4') => ({ previewProtocol: 3, kind: 'preview-proposals',
  binding, receiverEpoch: epoch, entries: legacy(command) });
const gateEffects = (commands, requests = []) => list([
  ctor('PreviewCommand', jsonValue(commands)), ctor('PaintRequest', jsonValue(requests)),
]);
const paintedEffects = commands => list([ctor('PreviewCommand', jsonValue(commands))]);
function gate(ordinal = '0', pending = null, realm = null) {
  const dict = pending === null ? dictEmpty() : ctor('RBNode_elm_builtin', ctor('Black'), ordinal, {
    identity: 'family:1', job: JSON.stringify(job), command: jsonValue(acquire),
    realm: realm === null ? nothing() : just(realm),
  }, dictEmpty(), dictEmpty());
  return ctor('Model', counter(ordinal), dict);
}
const scopedEmpty = { ...envelope([]) };
const gateCases = [
  { input: input('gate-fixture-reset', 'reset', null), state: gate(), effects: nil() },
  { input: input('scoped-acquire-waits-for-paint', 'gate-queue', scoped(acquire)),
    state: gate('1', true, nativeDomain), effects: gateEffects(scopedEmpty, [{ ticket: '1' }]) },
  { input: input('different-realm-cancel-cannot-retire-pending', 'gate-queue', scoped(cancel, '5')),
    state: gate('1', true, nativeDomain), effects: gateEffects(scoped(cancel, '5')) },
  { input: input('legacy-cancel-cannot-retire-scoped-pending', 'gate-queue', legacy(cancel)),
    state: gate('1', true, nativeDomain), effects: gateEffects(legacy(cancel)) },
  { input: input('extra-paint-fields-cannot-release', 'gate-painted', { ticket: '1', extra: true }),
    state: gate('1', true, nativeDomain), effects: paintedEffects([]) },
  { input: input('exact-paint-preserves-original-realm-job-and-D', 'gate-painted', { ticket: '1' }),
    state: gate('1'), effects: paintedEffects(scoped(acquire)) },
  { input: input('duplicate-paint-never-replays', 'gate-painted', { ticket: '1' }),
    state: gate('1'), effects: paintedEffects([]) },
  { input: input('fresh-scoped-acquire-new-ticket', 'gate-queue', scoped(acquire)),
    state: gate('2', true, nativeDomain), effects: gateEffects(scopedEmpty, [{ ticket: '2' }]) },
  { input: input('exact-realm-cancel-retires-unsent-acquire', 'gate-queue', scoped(cancel)),
    state: gate('2'), effects: gateEffects(scoped(cancel)) },
  { input: input('cancelled-late-paint-cannot-release', 'gate-painted', { ticket: '2' }),
    state: gate('2'), effects: paintedEffects([]) },
  { input: input('legacy-acquire-keeps-legacy-envelope', 'gate-queue', legacy(acquire)),
    state: gate('3', true), effects: gateEffects([], [{ ticket: '3' }]) },
  { input: input('scoped-cancel-cannot-retire-legacy-pending', 'gate-queue', scoped(cancel)),
    state: gate('3', true), effects: gateEffects(scoped(cancel)) },
  { input: input('legacy-paint-remains-legacy', 'gate-painted', { ticket: '3' }),
    state: gate('3'), effects: paintedEffects(legacy(acquire)) },
  { input: input('scoped-extra-envelope-fields-fail-closed', 'gate-queue', { ...scoped(cancel), extra: true }),
    state: gate('3'), effects: gateEffects([]) },
  { input: input('scoped-extra-row-fields-cannot-be-silently-stripped', 'gate-queue', {
    ...scoped(cancel), entries: [{ ...legacy(cancel)[0], extra: true }],
  }), state: gate('3'), effects: gateEffects([]) },
  { input: input('acquire-without-job-cannot-bypass-paint', 'gate-queue', scoped({ kind: 'acquire' })),
    state: gate('3'), effects: gateEffects(scopedEmpty) },
  // A NEW named fixture, not a production counter reset or an observed trace.
  // The QA-only fixed initializer uses the existing validated UInt64 decoder;
  // no constructor/mutator is added to the shipping source/export list.
  { input: input('finite-counter-fixture-reset', 'reset', null), state: gate(), effects: nil() },
  { input: input('near-exhaustion-named-GIVEN', 'gate-near-exhaustion', null),
    state: gate('18446744073709551614'), effects: nil() },
  { input: input('last-valid-ticket-keeps-full-width-string', 'gate-queue', scoped(acquire)),
    state: gate('18446744073709551615', true, nativeDomain),
    effects: gateEffects(scopedEmpty, [{ ticket: '18446744073709551615' }]) },
  { input: input('last-ticket-still-requires-exact-paint', 'gate-painted', { ticket: '18446744073709551615' }),
    state: gate('18446744073709551615'), effects: paintedEffects(scoped(acquire)) },
  { input: input('exhaustion-never-emits-unpainted-acquire', 'gate-queue', scoped(acquire)),
    state: gate('18446744073709551615'), effects: gateEffects(scopedEmpty) },
  { input: input('exhaustion-never-wraps-or-restarts-on-repeat', 'gate-queue', scoped(acquire)),
    state: gate('18446744073709551615'), effects: gateEffects(scopedEmpty) },
];
const cases = popupCases.map(spec => ({ ...spec, state: { popup: spec.state, gate: gate() } }))
  .concat(gateCases.map(spec => ({ ...spec, state: { popup: popup(), gate: spec.state } })));

function load(source, captures) {
  const context = { console: { log() {}, warn() {}, error() {} }, setTimeout, clearTimeout };
  context[HOOK] = value => {
    const tuple = full(value);
    insist(tuple && Object.keys(tuple).sort().join(',') === '$,a,b' && tuple.$ === '#2', 'complete tuple absent');
    captures.push(full({ state: tuple.a, effects: tuple.b }));
  };
  vm.createContext(context);
  registerRealm(context);
  new vm.Script(source, { filename: 'SolScopedPopup0438.observed.js' }).runInContext(context, { timeout: WAIT_MS });
  insist(context.Elm && context.Elm.SolScopedPopup0438, 'actual compiled QA worker absent');
  const app = context.Elm.SolScopedPopup0438.init({ flags: null });
  insist(app.ports && app.ports.incoming && app.ports.outgoing, 'QA ports absent');
  return app;
}
function exchange(app, value) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => finish(new Error('QA response timeout; no native/product D claim')), WAIT_MS);
    const receive = result => finish(null, result);
    function finish(error, result) {
      clearTimeout(timer);
      app.ports.outgoing.unsubscribe(receive);
      if (error) reject(error); else resolve(result);
    }
    app.ports.outgoing.subscribe(receive);
    try { app.ports.incoming.send(value); } catch (error) { finish(error); }
  });
}
async function run(source) {
  const captures = [];
  const app = load(source, captures);
  const traces = [];
  for (const spec of cases) {
    const count = captures.length;
    const reply = await exchange(app, spec.input);
    insist(reply && reply.name === spec.input.name && !reply.error, `${spec.input.name}: wrong reply`);
    insist(captures.length === count + 1, `${spec.input.name}: expected exactly one COMPLETE capture`);
    const actual = captures[count];
    const expected = full({ state: spec.state, effects: spec.effects });
    insist(isDeepStrictEqual(actual, expected), `${spec.input.name}: complete state/effects differ`);
    traces.push(actual);
  }
  return traces;
}
async function main() {
  insist(process.argv.length === 4, 'Root usage: node fixture.cjs compiled-worker.js repository');
  const bundle = path.resolve(process.argv[2]);
  const repository = path.resolve(process.argv[3]);
  const original = fs.readFileSync(bundle, 'utf8');
  const observed = instrument(original);
  const first = await run(observed.changed);
  const second = await run(observed.changed);
  insist(isDeepStrictEqual(first, second), 'fresh-run replay differs AFTER literal assertions');
  const sourcePaths = [
    'implementation/warlock/src/Popup.elm', 'implementation/warlock/src/PreviewPaintGate.elm',
    'implementation/warlock/src/NativePreviewRealm.elm', 'implementation/warlock/src/NativePreviewProposalIngress.elm',
    'implementation/warlock/src/RetainedPreviewPresenter.elm', 'implementation/warlock/src/PreviewPresenter.elm',
    'implementation/warlock/src/NativeActorRetirement.elm', 'implementation/warlock/src/Announcement.elm',
    'implementation/warlock/src/Presentation.elm', 'implementation/warlock/src/UInt64.elm',
  ];
  console.log(JSON.stringify({ ok: true, scope: 'source-only COMPLETE Popup and Gate transport-boundary replay',
    literalStepsPerRun: cases.length, freshRuns: 2,
    setupGivensPerRun: cases.filter(spec => ['reset', 'gate-near-exhaustion'].includes(spec.input.kind)).length,
    testedTransitionsPerRun: cases.filter(spec => !['reset', 'gate-near-exhaustion'].includes(spec.input.kind)).length,
    sourceInputs: sourcePaths.map(relative => ({ path: relative, sha256: hash(fs.readFileSync(path.join(repository, relative))) })),
    artifacts: { compiledOriginal: hash(original), instrumentedInMemory: hash(observed.changed),
      insertionOffset: observed.insertionOffset, insertedBytes: observed.insertedBytes,
      literalOracle: hash(fs.readFileSync(__filename)) },
    limits: ['no actual subscription-runtime observation', 'no native issuer or provider observation',
      'Gate cases are named component fixtures; Popup transition cases cover hidden quarantine/issued/retry, not a native producer',
      'near-exhaustion fixed named GIVEN requires the separate QA-only exact source overlay; never shipping',
      'not complete TEA004 acceptance or whole-EARS closure', 'Root must separately bind compiled artifact to exact input manifest'],
  }));
}
main().catch(error => { console.error(JSON.stringify({ ok: false, error: error.message, nativeAcceptance: false })); process.exitCode = 1; });

