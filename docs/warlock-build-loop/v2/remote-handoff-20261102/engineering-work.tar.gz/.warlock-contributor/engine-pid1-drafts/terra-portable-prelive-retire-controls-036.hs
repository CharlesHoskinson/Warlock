{-# LANGUAGE OverloadedStrings #-}
-- ROOT-ONLY source draft, not run. One mode per isolated, externally guarded
-- process. The real configured actor, same opaque owner and original StopD are
-- exercised; the watchdog only reports a stuck control and never retries IO.
module PortablePreliveRetireControls (Mode(..), Case, newCase, release, runCase) where

import Control.Concurrent (ThreadId, forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException, mask, throwIO, try)
import Control.Monad (unless, void)
import Data.IORef (IORef, atomicModifyIORef', newIORef, writeIORef)
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner, PersistentBackendRun,
 newPersistentBackendOwner, loadPersistentBackendConfig, runPersistentBackend,
 requestPersistentBackendStop, retirePersistentBackend, persistentBackendCounts,
 persistentBackendStartupRefusal, qaFirstStepHooks, qaFirstStepObservations)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P

data Mode = StopBeforeRegistration | StopBeforeAcquisition | UnknownEnteredStep
 deriving (Eq, Show)
data Case = Case PersistentBackendOwner (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException PersistentBackendRun)) (IORef (Maybe ThreadId)) (IORef Bool)

newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
release :: Case -> IO ()
release (Case _ _ _ barrier _ _ _) = void (tryPutMVar barrier ())
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain owner, worker and guardian"))) pure

runCase :: Case -> Mode -> FilePath -> IO ()
runCase c@(Case owner start entered barrier done worker used) mode config = mask $ \restore -> do
 first <- atomicModifyIORef' used (\prior -> (True, not prior))
 check "case used once" first
 exists <- doesPathExist config
 check "absolute real trusted config" (isAbsolute config && exists)
 before <- qaFirstStepObservations
 check "isolated process has no prior step" (before == (0, Nothing))
 loaded <- restore (within "load actual config" (loadPersistentBackendConfig owner config))
 check "same owner config loaded" (loaded == Right ())
 let pause = putMVar entered () >> readMVar barrier
 case mode of
  StopBeforeRegistration -> qaFirstStepHooks (pure ()) (pure ())
  StopBeforeAcquisition -> qaFirstStepHooks pause (pure ())
  UnknownEnteredStep -> qaFirstStepHooks (pure ()) pause
 case mode of
  StopBeforeRegistration -> do
   receipt <- restore (within "stop before actor" (requestPersistentBackendStop owner))
   check "pre-live stop latched" (receipt == P.StopLatchedBeforeLive)
  _ -> pure ()
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar done result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  case mode of
   StopBeforeRegistration -> pure ()
   _ -> do
    within "actual first-step barrier" (readMVar entered)
    observed <- qaFirstStepObservations
    case mode of
     StopBeforeAcquisition -> check "first display step has not entered" (observed == (0,Nothing))
     UnknownEnteredStep -> check "actual first display step entered" (observed == (1,Nothing))
     _ -> pure ()
    receipt <- within "stop same owner" (requestPersistentBackendStop owner)
    check "stop latched in preparation" (receipt == P.StopLatchedBeforeLive)
    release c
  observed <- within "actor returns" (readMVar done) >>= either throwIO pure
  check "no callbacks or operations" (persistentBackendCounts observed == (0,0))
  case mode of
   UnknownEnteredStep -> do
    check "entered interrupted step stays Unknown" (persistentBackendStartupRefusal observed == Just P.StartupAdmissionUnknown)
    retired <- within "observe unknown retirement" (retirePersistentBackend owner)
    check "uncertain work cannot report clean retirement" (not retired)
   _ -> do
    let known = case persistentBackendStartupRefusal observed of
         Just (P.StartupAdmissionRefused _) -> True
         _ -> False
    check "known stop is a typed refusal" known
    case mode of
     StopBeforeAcquisition -> check "pre-step refusal is SessionClosed" (persistentBackendStartupRefusal observed == Just (P.StartupAdmissionRefused SessionClosed))
     _ -> pure ()
    retired <- within "same owner settlement" (retirePersistentBackend owner)
    check "known unused resources retire once under original StopD" retired
    again <- within "repeat observation" (retirePersistentBackend owner)
    check "confirmed retirement remains idempotent" again
