# Wave 18 (`1719`) Elm-Only Patch Revision: Canonical `Surface` Authority, `pendingQuery` Gate & Exact Preimage Audit

**Status**: Draft preparation only (`no production source edits`, `no compiler/model/VM/GPU runs`, `nativeOperations = []` preserved).
**Patch Path**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/AppOnlyHierarchyEmptyState.patch` (`sha256:ef1bb568ae123152b6e17d12abe5e1def81f987f236d16a80cf6837f6e2b50b8`, `324` lines; verified clean via `git apply --check`)
**Base Revision**: `HEAD` (`e63cd930d`)

## 1. Exact Preimages Inspected

| Target File | Exact Base SHA-256 (`HEAD` `e63cd930d`) | Hunk Preimage Lines |
| --- | --- | --- |
| `implementation/warlock/src/Popup.elm` | `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58` | `51–57` (`view` line `54` only) |
| `implementation/warlock/src/SurfaceRenderer.elm` | `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98` | `1–4`, `74–87`, `142–148` |
| `implementation/warlock/src/SurfaceTheme.elm` | `be9d20b763275987d0706ec6edadea3853162bb28731a3da642b50fce0529d4c` | `10–16`, `226–232`, `269–275`, `390–396`, `409–432`, `454–470` |

GTK4 window geometry/packing in `implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc` (`805–862`) and wire snapshot encoding/decoding in `implementation/warlock/src/SurfaceSnapshot.elm` (`1–87`) are **untouched**.

## 2. Reviewer Findings Addressed (`sol-docs` + `terra-q-front`)

1. **Removed all view-side `entry:*` and substring/catch-all search inference (`sol-docs` `01M6C1RCTZZAEB4KM1Z98W8TP8`)**:
   - `Surface.elm:325-342` paginates `prefix` (`jump ++ pinFirst ++ List.concat (List.indexedMap pinRows pinIds)`) ahead of `entries`, so page 0 can have zero `entry:*` rows while `Catalog.search model.query` has matches; conversely, zero matches can still render `pinRows`.
   - `SurfaceRenderer.elm` now strips only the single fixed `Surface.elm:442` `presentationCapacity` prefix (`"Compact presentation; open Applications, search or use pages for every application and pin action. · "`) into `canonicalContextStatus` (never splitting on `"·"` or matching arbitrary window labels) and matches **exact** `Surface.elm:483` literals (`"Loading applications…"`, `"Application list unavailable. Refresh to try again."`, `"No matching applications. Change your search or Refresh."`; `_ -> []`).
   - `<p role="status">[text snapshot.status]</p>` remains 100% verbatim and authoritative.

2. **Suppressed supplementary query-result cards during uncommitted local `pendingQuery` or IME `composition` (`terra-q-front` `01M6C2GXAA5WEPX4KYN74TF9ET` caveat 1)**:
   - `Popup.view` (`Popup.elm:54`) overlays `model.pendingQuery` via `SurfaceRenderer.pendingQuery` while `snapshot.status` still reflects the prior accepted publication.
   - `Popup.view` now passes `queryConfirmed = (model.pendingQuery == Nothing && not (isComposing model))` to `SurfaceRenderer.viewWithPreviewAndQueryState` (`SurfaceRenderer.view` and `SurfaceRenderer.viewWithPreview` keep exact existing signatures with `queryConfirmed = True`). When `queryConfirmed == False`, `popupEmptyEntries` in `mode == "applications"` evaluates to `[]`, so an old-publication no-match/loading/unavailable card never lingers over newly typed local text or IME preedit, while `<p role="status">` remains verbatim.

3. **Removed `data-surface-scope` and control-enabledness capability heuristics (`terra-q-front` `01M6C2GXAA5WEPX4KYN74TF9ET` caveat 2)**:
   - Removed `data-surface-scope` completely and removed `isAppOnlySession` inference from `bar:applications` / `bar:settings` enabledness.
   - Closed-mode `"Application workspace"` heading and `"empty:closed-app-only"` guidance trigger **only** on exact `canonicalContextStatus == "Applications connected. Window controls unavailable."` (`Shell.elm:187`), with neutral control-grounded copy that never asserts capability policy from rendered buttons.

## 3. Source-Only Fixture Coverage Matrix (for Root Replay Suite)

| Case | `mode` | `queryConfirmed` | `snapshot.popup` shape | `snapshot.status` | Expected `<p role="status">` | Expected `popupEmptyEntries` |
| --- | --- | --- | --- | --- | --- | --- |
| 1. Pin-only page 0 with matches on page 1 | `"applications"` | `True` | `search`, `close`, `refresh`, `paging`, `jump`, `pinFirst`, `pinRows` (`0` `entry:*`) | `"Type to search applications."` (or `"Choose a matching application."`) | Verbatim | `[]` (no false no-match) |
| 2. True empty `Catalog.search` with existing pins | `"applications"` | `True` | `search`, `close`, `refresh`, `pinRows` (`0` `entry:*`) | `"No matching applications. Change your search or Refresh."` | Verbatim | `[("empty:applications-no-match", ...)]` after `pinRows` |
| 3. Local `pendingQuery /= Nothing` or `isComposing` after prior no-match | `"applications"` | `False` | `search` (`label = newQuery`), `close`, `refresh`, `pinRows` | `"No matching applications. Change your search or Refresh."` (prior pub) | Verbatim | `[]` (suppressed until verified `Present`) |
| 4. Override notices (`pins.notice` Unknown/Refused, `Launch` status, `catalogFailure`, `windowNotice`) | `"applications"` | `True` | Any | Exact override notice from `Surface.elm:445,473-482` | Verbatim | `[]` (never masks higher-priority status) |
| 5. `presentationCapacity` compact prefix + canonical `483` literal | `"applications"` | `True` | Compact page | `"Compact presentation; ... · No matching applications. Change your search or Refresh."` | Verbatim | `[("empty:applications-no-match", ...)]` |
| 6. Closed app-only (`live-01`) vs closed window-shell | `"closed"` | `True` | `[]` | `"Applications connected. Window controls unavailable."` vs `"Connected"` | Verbatim | `h1="Application workspace"` + `empty:closed-app-only` vs `h1="Choose a window"` + `empty:closed-idle` |

## 4. Peer & Advisor Review Receipts
- **`sol-docs` (`01M6C1RCTZZAEB4KM1Z98W8TP8` -> `01M6C2KJJ5CWTK1BVD8HB326PX`, `01M6C2MNYVEVM2DS8PFBMT1E9G`)**: Confirmed removal of `entry:*` and `else -> no-match` view-side search policy, preservation of override notices via default `[]`, unchanged keyed control prefix, and untouched GTK/wire contracts; advised removing `data-surface-scope` authority claims and addressing `pendingQuery` echo (or optionally omitting open-mode query cards altogether if Root prefers a closed-only subset).
- **`terra-q-front` (`01M6C2GXAA5WEPX4KYN74TF9ET` -> `01M6C2Q6KRF2FQ3JZWG39VMBCR` on exact `ef1bb568ae123152b6e17d12abe5e1def81f987f236d16a80cf6837f6e2b50b8`, plus `no-match-pagination-review.md` `sha256:47b81a2a24d53e2332decfdebbaa7ec3e33e8acd5c7e5829d7cab4cf9e41c004`)**: Confirmed both concrete caveats are addressed in `ef1bb568` (`pendingQuery == Nothing && composition == Idle` gate on supplementary `applications` cards; `data-surface-scope` and control-enabledness heuristics removed; verbatim `snapshot.status` and keyed `#launcher-search` identity retained).

## 5. Preserved Invariants
- Zero new `.elm` files (`qa/check-snapshot-contracts.py:58`); `SurfaceSnapshot` wire schema untouched (`qa/SurfaceSnapshotContracts.elm:17-26`).
- Direct-child DOM (`> h1`, `> p[role="status"]`, `> .surface-controls`) under `.surface-popup` preserved (`assets/shell.css:1,44,45`, `assets/popup-adapter.js`).
- `.surface-bar` `height: calc(3em + 8px)` preserved (`qa/settings-browser.mjs:90`, `qa/feedback-context-browser.mjs:179`), with `100vh` `bView` lower shadow using `palette.surfaceRecessed`.
- `.surface-popup` `box-shadow: none` & `opacity: 1` preserved; `.surface-controls` `snapShadow` gated on `softEffectsEnabled && surfaceMode /= "closed"` (`qa/layer-appearance-browser.mjs:41`).
- Keyed `("control:search", ...)` `#launcher-search` node precedes `popupEmptyEntries`, preserving DOM identity, focus, and IME composition (`qa/feedback-context-browser.mjs:305`).
