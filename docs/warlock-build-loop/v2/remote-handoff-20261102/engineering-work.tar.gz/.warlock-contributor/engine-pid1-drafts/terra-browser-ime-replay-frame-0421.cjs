// QA-only adapter: emit the current compiled ImeReplay prelude for the
// stopped-transport browser fixture. This is not an independent EARS oracle.
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const [compiled, expectedSha, output] = process.argv.slice(2);
if (process.argv.length !== 5 || !/^[0-9a-f]{64}$/.test(expectedSha))
  throw Error('usage: node adapter COMPILED_IME_REPLAY.js SHA256 NEW_OUTPUT.json');
const source = fs.readFileSync(compiled);
if (crypto.createHash('sha256').update(source).digest('hex') !== expectedSha)
  throw Error('compiled ImeReplay hash mismatch');
const expectedChecks = [
  'startBlocksBeforeFirstPreedit', 'preeditNeverMarksQuerySent',
  'sameFieldRefreshPreservesPreedit', 'MatchingObservationCannotAcknowledgeUnsentPreedit',
  'commitSetsOneCurrentScopedQuery', 'finalInputDoesNotChangeSentQuery',
  'nativeAcknowledgementClearsPending', 'cancelClearsPreeditWithoutQuery',
  'oldPublicationCannotCommitComposition', 'closeRetiresLocalComposition',
  'fieldReplacementDoesNotInheritPreedit', 'finalInputBeforeEndRemainsPreedit'
];
let completed = false;
const timer = setTimeout(() => { if (!completed) { console.error('ImeReplay did not emit'); process.exitCode = 1; } }, 3000);
try {
  const sandbox = {console, setTimeout, clearTimeout};
  vm.createContext(sandbox);
  vm.runInContext(source.toString('utf8'), sandbox, {timeout:1500});
  sandbox.Elm.ImeReplay.init().ports.outgoing.subscribe(value => {
    if (completed) { console.error('ImeReplay emitted twice'); process.exitCode = 1; return; }
    completed = true;
    clearTimeout(timer);
    try {
      const packet = JSON.parse(JSON.stringify(value));
      const keys = Object.keys(packet.checks || {}).sort();
      if (JSON.stringify(keys) !== JSON.stringify([...expectedChecks].sort()) ||
          expectedChecks.some(k => packet.checks[k] !== true))
        throw Error('ImeReplay check set missing or failed');
      if (!packet.frame || packet.frame.publication !== '1' || packet.frame.lease !== '1')
        throw Error('initial frame is not publication 1 / lease 1');
      // Preserve the complete packet expected by the existing fixture, not a
      // reconstructed frame. Exclusive creation preserves previous evidence.
      fs.writeFileSync(output, JSON.stringify(packet, null, 2) + '\n', {flag:'wx'});
    } catch (error) { console.error(String(error)); process.exitCode = 1; }
  });
} catch (error) { clearTimeout(timer); console.error(String(error)); process.exitCode = 1; }
