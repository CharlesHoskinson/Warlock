{-# LANGUAGE OverloadedStrings #-}
-- Source-only QA draft; NOT executed. Requires Gemini persistent-owner v3 API:
-- withLiveSessionWakeSTM :: LiveSession -> (STM LiveWakeReason -> IO a)
--                        -> IO (Either ToolError a)
-- and LiveWakeLeaderExited. Verify names/types and owner cleanup before staging.
-- Parent retains one end of an actual socketpair while its direct selected
-- child owns a duplicated copy on stdin. No numeric PID is signalled/reaped by
-- this fixture. Readiness and timeout bounds here are test observations, not
-- extensions or resets of the product startup or operation deadlines.
module EnginePidfdDeathReplay (ProbeResult(..), QuarantinedFixture, PidfdRegistry, newPidfdRegistry, registeredFixtureCount, runPidfdDeath, runPidfdDeathChild) where

import Control.Concurrent.MVar (MVar, modifyMVar_, newMVar, readMVar)
import Control.Exception (SomeAsyncException, SomeException, bracket, finally, fromException, mask, onException, throwIO, try)
import Control.Monad (unless)
import qualified Data.ByteString as B
import Data.Unique (Unique, newUnique)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import GHC.Conc (atomically, threadWaitReadSTM)
import System.Environment (getExecutablePath)
import System.IO (Handle, hClose, hIsClosed, stdin)
import System.Posix.IO (closeFd, dup, fdToHandle, fdWrite)
import System.Posix.Types (Fd(..))
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..), ToolError(..))
import Warlock.Capture.Process.Persistent.Internal
  ( LiveWakeReason(..), PersistentOwner, PersistentStatus(..), SessionExit(..), newPersistentOwner
  , persistentStatus, persistentUnderlyingStatus, persistentFixture
  , startBudgetAfter, stopBudgetMicros, withLiveSessionWakeSTM
  , withPersistentOwner )

isAsync :: SomeException -> Bool
isAsync ex = case fromException ex :: Maybe SomeAsyncException of
  Just _ -> True
  Nothing -> False

check :: String -> Bool -> IO ()
check name ok = unless ok (ioError (userError ("pidfd-death: " ++ name)))

-- No bytes and no EOF. threadWaitReadSTM readiness is observed, never consumed.
-- The cleanup returned by the runtime unregisters the exact borrowed fd watch.
quiet :: S.Socket -> IO Bool
quiet sock = S.withFdSocket sock $ \raw ->
  bracket (threadWaitReadSTM (Fd raw)) snd $ \(ready, _) -> do
    observed <- timeout 150000 (atomically ready)
    pure (case observed of Nothing -> True; Just () -> False)

bounded :: String -> IO a -> IO a
bounded label operation = do
  result <- timeout 2000000 operation
  maybe (ioError (userError ("pidfd-death: timed out " ++ label))) pure result

runPidfdDeathChild :: IO ()
runPidfdDeathChild = do
  -- fd 0 is a test-only dup of the selected socket endpoint. This byte proves
  -- that the actual child entered and that the peer direction works.
  n <- fdWrite (Fd 0) "R"
  check "child ready byte written" (n == 1)
  command <- B.hGet stdin 1
  check "child received its explicit exit command" (command == "X")
  -- Return normally. Only the parent owner later reaps its direct child.

-- An uncertain result contains live ownership references. The integrating
-- runner MUST retain QuarantinedFixture in its caller-owned quarantine registry
-- and must not report clean shutdown or drop it while ownership is unsettled.
-- The owner alone decides any subsequent cleanup; this module exposes no raw
-- PID, pidfd, signaling, forced reap, or manual quarantine release operation.
data QuarantinedFixture = QuarantinedFixture PersistentOwner S.Socket S.Socket Handle

data ProbeResult = ProbePassed | ProbeUncertain QuarantinedFixture

-- Root retains this registry for the whole owning test process and its
-- supervised recovery. No API here exposes unsafe release of uncertain FDs.
newtype PidfdRegistry = PidfdRegistry (MVar [(Unique, QuarantinedFixture)])

newPidfdRegistry :: IO PidfdRegistry
newPidfdRegistry = PidfdRegistry <$> newMVar []

-- Counts active as well as uncertain entries; not a cleanup verdict.
registeredFixtureCount :: PidfdRegistry -> IO Int
registeredFixtureCount (PidfdRegistry registry) = length <$> readMVar registry

-- The QA executable must dispatch its exact --owned-pidfd-death-child mode to
-- runPidfdDeathChild before running the parent case. Root owns this wiring.
-- The caller passes an already-live registry and must keep it strongly reachable
-- across exceptions, runner exit decisions, and explicit Root supervision.
runPidfdDeath :: PidfdRegistry -> IO ProbeResult
runPidfdDeath (PidfdRegistry registry) = mask $ \restore -> do
  self <- getExecutablePath
  owner <- newPersistentOwner
  start <- startBudgetAfter 4000000 >>= either (ioError . userError . show) pure
  stop <- either (ioError . userError . show) pure (stopBudgetMicros 2000000)
  (host, retainedPeer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  let closePair = S.close host `finally` S.close retainedPeer
  -- Both allocation and installation of the ownership reference are masked.
  -- Before owner adoption, a conversion failure closes only the fresh duplicate.
  childInput <- (S.withFdSocket retainedPeer $ \raw -> do
    copy <- dup (Fd raw)
    fdToHandle copy `onException` closeFd copy) `onException` closePair
  let closeInput = do closed <- hIsClosed childInput; unless closed (hClose childInput)
      fixture = QuarantinedFixture owner host retainedPeer childInput
      closeUnadopted = closeInput `finally` closePair
  token <- newUnique `onException` closeUnadopted
  modifyMVar_ registry (\entries -> pure ((token, fixture) : entries)) `onException` closeUnadopted
  let unregister = modifyMVar_ registry (pure . filter ((/= token) . fst))
  -- After this call begins, never release a socket or input handle solely due
  -- to an exception: only a confirmed owner retirement plus drained wake
  -- capability permits release. An uncertain path fails without explicit fd
  -- close; Root must retain the returned quarantine object in its owned registry.
  outcome <- try (restore (withPersistentOwner owner
    (persistentFixture self ["--owned-pidfd-death-child"] childInput) 4096 start stop
    (\_ -> do
      ready <- bounded "child ready byte" (N.recv host 1)
      pure (if ready == "R" then Right () else Left SpawnOrIO))
    (\session -> do
      firstQuiet <- quiet host
      check "peer open and socket not readable before death" firstQuiet
      wakeResult <- withLiveSessionWakeSTM session $ \wake -> do
        premature <- timeout 150000 (atomically wake)
        check "live selected child does not wake as dead" (premature == Nothing)
        N.sendAll host "X"
        observed <- bounded "selected child death wake" (atomically wake)
        check "wake is selected leader exit, not explicit stop" (observed == LiveWakeLeaderExited)
        stillQuiet <- quiet host
        check "retained peer suppresses EOF after child death" stillQuiet
        N.sendAll retainedPeer "P"
        positive <- bounded "retained peer positive byte" (N.recv host 1)
        check "retained endpoint remains live and carries bytes" (positive == "P")
      check "wake capability borrowed without scope error" (wakeResult == Right ())
      pure ()))) :: IO (Either SomeException (Either SessionExit ((), SessionExit)))
  states <- try ((,) <$> persistentStatus owner <*> persistentUnderlyingStatus owner)
    :: IO (Either SomeException (PersistentStatus, OwnerStatus))
  let drained = case (outcome, states) of
        (Right (Right ((), LeaderReaped _)), Right (PersistentRetired, Available)) -> True
        _ -> False
  if not drained
    then case (outcome, states) of
      (Left ex, _) | isAsync ex -> throwIO ex
      (_, Left ex) | isAsync ex -> throwIO ex
      _ -> pure (ProbeUncertain fixture)
    else do
      -- The owner and wake scope have both retired before touching retained FDs.
      (do
        closeInput
        S.shutdown retainedPeer S.ShutdownSend
        eof <- bounded "EOF after retained writer shutdown" (N.recv host 1)
        check "EOF only after retained writer shutdown" (B.null eof)) `finally` closePair
      unregister
      pure ProbePassed
