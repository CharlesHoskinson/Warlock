'use strict';
/* Source-only QA draft. Root supplies two compiled Elm files and independently
 * frozen SHA-256 digests. This does not compile Elm, infer source provenance,
 * authenticate a native sender, or replace protected runner deadlines.
 * Usage: node captured-action-result-runner.cjs boundary.js SHA required.js SHA
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const boundaryNames = [
  'fixtureOpensRealPicker','currentFrameAccepted','pointerEntryOriginPreserved',
  'keyboardEntryOriginPreserved','absentEntryDefaultsKeyboard','typedBarPointer',
  'typedBarKeyboard','typedBarAbsent','typedPopupPointer','typedPopupKeyboard',
  'typedPopupAbsent','barPointerExactWire','barKeyboardExactWire','barAbsentTriggerExactWire',
  'popupPointerExactWire','popupKeyboardExactWire','popupAbsentTriggerExactWire',
  'presentNullTriggerRefused','unknownTriggerRefused','emptyTriggerRefused','nonStringTriggerRefused',
  'popupPresentNullTriggerRefused','popupUnknownTriggerRefused','popupEmptyTriggerRefused',
  'popupNonStringTriggerRefused','foreignSurfaceRefused','extraFieldRefused','emptyIdentityRefused',
  'zeroTextIdentityAcceptedButNotCurrentControl','numericIdentityRefused','emptyPublicationRefused',
  'paddedPublicationRefused','oversizedIdentityRefused','boundary512IdentityAccepted',
  'controlCharacterIdentityRefused','deleteCharacterDecodePreserved','zeroPublicationRefused',
  'zeroLeaseDecodedButNotCurrent','currentBarZeroLeaseExactWire','publicationOverflowRefused',
  'leaseOverflowRefused','fullWidthCountersPreserved','stalePublicationNotDispatched',
  'futurePublicationNotDispatched','oldLeaseNotDispatched','futureLeaseNotDispatched',
  'popupAsBarNotDispatched','barAsPopupNotDispatched','unknownIdentityNotDispatched'
];
const requiredNames = [
  'positive_literal_wire_and_both_routes','wrong_kind','wrong_version','unknown_surface',
  'extra_field','present_null_trigger','unknown_trigger',
  ...['missing:','null:','wrong-type:'].flatMap(prefix =>
    ['surface','surfaceProtocol','kind','publication','lease','id'].map(field => prefix + field))
];
function exactKeys(value, expected, context) {
  if (value === null || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    throw new Error(context + ': expected a plain object');
  const actual = Reflect.ownKeys(value);
  if (actual.some(name => typeof name !== 'string')) throw new Error(context + ': symbol field');
  actual.sort();
  const wanted = [...expected].sort();
  if (actual.length !== wanted.length || actual.some((name, i) => name !== wanted[i]))
    throw new Error(context + ': missing or unexpected fields');
  const descriptors = Object.getOwnPropertyDescriptors(value);
  for (const name of wanted) {
    const descriptor = descriptors[name];
    if (!descriptor || !descriptor.enumerable || !Object.prototype.hasOwnProperty.call(descriptor, 'value'))
      throw new Error(context + ': hidden or accessor field ' + name);
  }
  return descriptors;
}
function trueChecks(value, expected, context) {
  const fields = exactKeys(value, expected, context);
  for (const name of expected) if (fields[name].value !== true) throw new Error(context + ': ' + name + ' is not true');
}
function verifyBoundary(value) {
  const fields = exactKeys(value, ['scope','checks'], 'boundary result');
  if (fields.scope.value !== 'Elm CapturedAction and current-frame dispatch; synthetic fixture')
    throw new Error('boundary result: unexpected scope');
  trueChecks(fields.checks.value, boundaryNames, 'boundary checks');
}
function verifyRequired(value) {
  const fields = exactKeys(value, ['scope','sequences'], 'required-fields result');
  if (fields.scope.value !== 'Synthetic Elm decode and current-frame dispatch; not native authentication')
    throw new Error('required-fields result: unexpected scope');
  const sequences = fields.sequences.value;
  if (!Array.isArray(sequences) || Object.getPrototypeOf(sequences) !== Array.prototype || sequences.length !== 32)
    throw new Error('required-fields result: expected 32 seeds');
  const keys = Reflect.ownKeys(sequences);
  const wanted = ['length', ...Array.from({length:32}, (_, i) => String(i))];
  if (keys.some(key => typeof key !== 'string') || keys.length !== wanted.length ||
      wanted.some(key => !keys.includes(key))) throw new Error('required-fields result: sparse or extra array keys');
  const slots = Object.getOwnPropertyDescriptors(sequences);
  for (let index = 0; index < 32; index++) {
    const slot = slots[String(index)];
    if (!slot || !slot.enumerable || !Object.prototype.hasOwnProperty.call(slot, 'value'))
      throw new Error('required-fields result: hidden or accessor array slot');
    const sequence = exactKeys(slot.value, ['seed','checks'], 'sequence ' + (index + 1));
    if (sequence.seed.value !== index + 1) throw new Error('sequence: missing, duplicate, or reordered seed');
    trueChecks(sequence.checks.value, requiredNames, 'seed ' + sequence.seed.value);
  }
}
function loadWorker(filename, expectedHash, moduleName) {
  if (!/^[a-f0-9]{64}$/.test(expectedHash)) throw new Error(moduleName + ': invalid SHA-256');
  const absolute = path.resolve(filename);
  const digest = crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex');
  if (digest !== expectedHash) throw new Error(moduleName + ': compiled artifact hash mismatch');
  const exported = require(absolute);
  const worker = exported && exported.Elm && exported.Elm[moduleName];
  if (!worker || typeof worker.init !== 'function') throw new Error(moduleName + ': missing Elm worker');
  const app = worker.init({flags:null});
  if (!app.ports || !app.ports.outgoing || typeof app.ports.outgoing.subscribe !== 'function')
    throw new Error(moduleName + ': missing outgoing port');
  return {app, digest, absolute};
}
let completed = false;
process.on('beforeExit', () => {
  if (!completed) {
    fs.writeSync(2, 'CapturedAction QA: worker exited without both results\n');
    process.exitCode = 1;
  }
});
async function main() {
  if (process.argv.length !== 6) throw new Error('expected boundary.js boundary_sha256 required.js required_sha256');
  const a = loadWorker(process.argv[2], process.argv[3], 'CapturedActionBoundaryReplay');
  const b = loadWorker(process.argv[4], process.argv[5], 'CapturedActionRequiredFieldsReplay');
  // This QA-only observation window checks duplicate emissions within 25 ms
  // after both results. It is not a product deadline or a proof about later events.
  const [boundary, required] = await new Promise((resolve, reject) => {
    const values = [undefined, undefined];
    const seen = [0, 0];
    let timer = null;
    [a, b].forEach((worker, index) => worker.app.ports.outgoing.subscribe(value => {
      seen[index]++;
      if (seen[index] !== 1) {
        if (timer !== null) clearTimeout(timer);
        reject(new Error('duplicate worker output within observation window'));
        return;
      }
      values[index] = value;
      if (seen[0] === 1 && seen[1] === 1 && timer === null)
        timer = setTimeout(() => resolve(values), 25);
    }));
  });
  verifyBoundary(boundary);
  verifyRequired(required);
  completed = true;
  process.stdout.write(JSON.stringify({scope:'synthetic Elm action boundaries; not native authentication',
    boundary:{artifact:a.absolute,sha256:a.digest,checks:boundaryNames.length},
    required:{artifact:b.absolute,sha256:b.digest,seeds:32,checksPerSeed:requiredNames.length},
    duplicateObservationWindowMs:25}) + '\n');
}
main().catch(error => {
  completed = true;
  fs.writeSync(2, 'CapturedAction QA: ' + String(error && error.message || error) + '\n');
  process.exitCode = 1;
});
