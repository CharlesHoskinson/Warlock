# Website `2325` Bounded Read-Only Search Upgrade, Published Screenshot Coordination & UI-Origin Source Review

- **Author**: `gemini-site` (`did:key:z6MkhUsGnXmVj1LcBBwGeJsqQmhTCcgW8zkrg89WkkXwR8fv`)
- **Run / Turn / Cutoff**: `warlock-20261031-setup` · `20261101T232546Z` · Cutoff `2026-11-02T00:21:46.277494+00:00`
- **Canonical Baseline (`HEAD`)**: `e5ce2487c8ec67ced1405dc0d3219c6f39effc5a`
- **Foreign Dirty Working Draft Untouched**: `site/src/SiteMain.elm` (`sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb`)
- **Prior `2255` Website Patch Preserved Untouched**: `SiteMainHeadProd2255.patch` (`sha256:eac813a141c1a55a7dd3586208a654abad336231420290b55fd500831df89222`) & `SiteMainHeadProd2255.elm` (`sha256:7d3b290df79853b61189d7e938dfaff7afb5a3a0f8ca13629ff5dabdcd50feed`)

---

## 1. Website `2325` Beta Capability Copy & `#mvp-evidence` Layout Upgrade

### What Changed (`SiteMainProd2255To2325Delta.patch` · `sha256:2dd50844a8470bde7b4340b5075a8fe62b3121cde50fab69ef5a1ffce0a2d6bb`)

1. **Accurate Shell-vs-Compositor Framing (Hero, Scope, Workbench, Principles)**:
   - Clarifies that Warlock designs an Elm + Haskell **desktop shell** atop Hyprland—**not** a replacement window manager—and separates the 16-scenario simulated browser stage from the live Omarchy `--application-only` beta, which exercises **bounded read-only application catalog search** inside a Hyprland-tiled GTK4 / WebKitGTK 6 window without verified window management, catalog receipts, or restart recovery.
   - Removes the `2255` overstatement in `#wl-run-omarchy-trial` (`"durable pin writes, physical Escape, and read-only draft retention on HTTP failure work"`) and replaces it with exact `e5ce2487c` bounds (`nativeOperations = []`, `HOSTSTOP2`, `17` guarded QMP inputs `foot -> footz -> Refresh`, no catalog receipt or physical IME, no transport-loss/reload recovery, and retained `exit -9` at `27.88s` + `warlock-ui-backend` `exited 1`).
2. **Updated `e5ce2487c` Verification Matrix (`#wl-mvp-matrix`)**:
   - Updates `wl-mvp-row-contracts` to `HEAD e5ce2487c`: `7,293` HTTP/DOM checks (`7,177` preserved + `116` added), `130` typed controls (`43` `LocalField`, `4` pre-fix RED retained), `58` policy histories, `57` named Quint runs (`51` preserved), `10,000` `seed=20261101` traces, while noting `17 / 242` whole EARS and `41 / 417` scenarios remain unchanged (`ELM-UI-005` partial; `ELM-TEA-001` 37-module typed domain in integration; `GET /index.html` leaves drained `/events` at `204`).
   - Updates `wl-mvp-row-omarchy-vm` badge to `Failed 28s lifecycle retained (exit -9 / exit 1)` (`is-open` tone rather than `is-scoped`), recording the `17` guarded QMP inputs alongside the forced `27.88s` pinned-guard `exit -9` and earlier `exit 1`.
3. **New All-Elm Actual MVP Evidence Section (`#mvp-evidence` / `viewMvpEvidenceSection`)**:
   - **`#wl-mvp-tiled-layout`**: Token-styled two-pane workspace anatomy matching the `1280x800` Omarchy guest captures: stock Omarchy Waybar + Hyprland compositor across the top, `#wl-mvp-pane-foot` (preserved left-half `Foot` terminal), and `#wl-mvp-pane-warlock` (right-half stacked `HttpBar` + `HttpPopup` read-only `Applications` surface). Collapses cleanly to 1 column at `<= 900px` (`0` overflow at `320px`).
   - **`#wl-mvp-evidence-grid` (`mvpEvidenceCards`, 4 cards)**:
     - `#wl-evidence-foot`: `positive-foot.png` (`96244014…`) — `foot` lists `Actions for Foot`, `Pin Foot`, and dashed disabled `Open Foot*` rows (`63` regular entries, `8` symlinks skipped, `nativeOperations = []`).
     - `#wl-evidence-footz`: `negative-footz.png` (`23c8a41a…`) & `after-refresh-footz.png` (`120ab65e…`) — `footz` and `No matching applications. Change your search or Refresh.` persist across `17` guarded QMP inputs including a `Refresh` click without proving a backend catalog receipt or physical IME.
     - `#wl-evidence-lifecycle`: `vm-journey.json` (`0d4feade…`) — late pinned guard assertion (`guestExit = -9` at `27.88s / 28s`) retained alongside `warlock-ui-backend` `exit 1` (`passed=false`).
     - `#wl-evidence-no-restart`: `Popup.elm` (`a9f188f9…`), `HttpPopup.elm` (`e814d56f…`), `Owner.hs` (`a780a828…`) — read-only retained query on HTTP loss has **no** automatic reconnect, action replay, or reload/restart recovery.

---

## 2. Published Screenshot & Semantics Coordination (`gemini-gui` & `terra-browser`)

Direct inspection of `implementation/warlock/qa/evidence/cancel-query-20261101/{positive-foot,negative-footz,after-refresh-footz}.png` (`1280x800`) against `HttpBar.elm`, `HttpPopup.elm`, and `SurfaceRenderer.elm`:

1. **Duplicate Status Copy Across Stacked `HttpBar` + `HttpPopup` WebViews**:
   - In `positive-foot.png`, `"Choose a matching application."` renders simultaneously in the top-right `HttpBar` status box AND in the blue-accented `HttpPopup` callout ~`12px` below it; in `negative-footz.png` and `after-refresh-footz.png`, `"No matching applications. Change your search or Refresh."` likewise appears twice.
   - **Semantic / UX coordination note**: Because `Warlock/Ui/WebKit.hs` stacks `Bar` directly above `Popup` inside the standalone `--application-only` window, projecting identical surface status text into both subviews creates visual duplication and potential duplicate AT live-region announcements if both roles announce on the same frame—though `Owner.hs:381` (`"deliver", J.JBool (announcer == recipient)`) restricts `announcement-projection` delivery to the single `announcer` recipient, visible text remains duplicated. No duplicate broad style prototype is minted here; flagged for `gemini-gui` and `terra-browser` when `ELM-UI-005` / surface layout is next touched.
2. **Dashed Disabled Rows vs Enabled Local Controls (`nativeOperations = []`)**:
   - `Task View` and `Switch windows` in `Bar` render muted/disabled, while `Actions for Foot`, `Open Foot`, `Open Foot Server`, and `Open Foot Client` render dashed borders (`item.enabled == False`), contrasting with solid-bordered `Applications`, `Windows`, `Refresh`, and `Pin Foot`. Website `#wl-mvp-pane-warlock` and `#wl-evidence-foot` now mirror this exact visual distinction so users never mistake listed `Open Foot*` rows for active process launch capability.
3. **Post-`Refresh` Visual Indistinguishability (`after-refresh-footz.png`)**:
   - Aside from the pointer hand cursor over `Refresh` and the unfocused input caret (`footz` without `|`), `after-refresh-footz.png` is visually identical to `negative-footz.png`—confirming visually why screen capture alone proves non-loss of `footz`, not a correlated backend catalog-generation receipt.

---

## 3. Source Peer Review: `test-ui-origin/Main.hs` Reload-Gap & Queued-`Document` Non-Mutation (`gemini-gui` `2323` + `sol-docs` `2324`)

- **Base preimage (`HEAD e5ce2487c`)**: `implementation/warlock/haskell/runtime/test-ui-origin/Main.hs` (`sha256:0b0f1780ed2ac5731bdcdf5405e48eddfec40407ff8cd194e8f0c67218e5e7ea`)
- **Patch 1 (`gemini-gui`)**: `.warlock-contributor/engine-pid1-drafts/gemini-gui-ui-origin-popup-reload-gap-witness-2323.patch` (`sha256:a2b578374d9483d7b9b50bb6a8c8fc90e3d6426431f495b91a1522d1f6def14f` -> postimage `9cc085575d50de0ad35d5dd9c357059d52cd4a76e08b67a29c19a0363955e029`)
- **Patch 2 (`sol-docs`, stacked on `9cc08557…`)**: `.warlock-contributor/engine-pid1-drafts/sol-ui-document-no-bootstrap-2324.patch` (`sha256:0134e6b174069f93152b1eda07d84ea72f7f581521bfe25c13d865202a0a3070` -> postimage `f37e9447408dfd74a90dd37d3fbadfb9b3e0abe75aaf38382d4f6e9f4d5dff40`)

### Independent Source Verification Findings (`CONCUR`)
1. **Zero-offset Sequential Patch Application**: Verified `git apply --check -v` at `0` offset from `0b0f1780…` -> `9cc08557…` -> `f37e9447…` in an isolated temporary repository.
2. **Exact `J.Json` Structural & Field-Order Correspondence**:
   - Checked `Warlock.Protocol.Desktop.decodeDesktopCommit` / `commitProjection` (`Desktop.hs:124-144`): `commitProjection` returns the raw decoded `JObject` without key reordering, so `newerFrame` (`Main.hs:306`, where `replaceJson` prepends `"lease"` then `"publication"`) retains identical key order through `Owner.presentation` (`Owner.hs:360-384`).
   - Checked `Owner.gateway` (`Owner.hs:48`: `["bridgeProtocol","kind","payload"]`) and `announcement` (`Owner.hs:380-381`: `["announcementProtocol","kind","recipient","announcer","publication","lease","message","deliver"]`, with `announcer = JNull`, `message = JNull`, `deliver = JBool False` for `projection` at `Main.hs:203`). All 8 `expectedPopupPackets` in `0134e6b1…` match `Owner.hs` byte-for-byte and key-order-for-key-order (`packet == expectedPacket`).
3. **Preserved `Owner` Counters & `RetireThrows` Fence**:
   - Neither `GET /index.html` (`17` pre-drain + `1` post-drain + `20` burst) nor `GET /events` mutates `uiCommitCount` (`4` in `Ordinary`, `5` in `RetireThrows`, `Main.hs:430, 435`) or `uiActionCount` (`1`), and `uiRequestCount == 0` is checked only in `NoNetwork` (`Main.hs:436`). `budget` (`Main.hs:51-52`) is an unbounded monotonic passed-assertion counter.
   - **Bounded-deadline note**: Adding `38` synchronous loopback `Document` `GET`s + `11` `Events` `GET`s inside `exerciseOwner` runs twice (`Ordinary` and `RetireThrows`) within `Owner`'s existing `uiDeadline`; if Root's protected run hits a real request-timeout ceiling, that observation must be retained without lengthening deadlines.
   - **Verdict**: **CONCUR** on `a2b57837…` + `0134e6b1…`, and **CONCUR** that `Reload view` (`04b7cb38…`) must remain unadopted.

---

## 4. Frozen `2325` Deliverables & Digests

| Artifact | SHA-256 | Bytes |
| :--- | :--- | ---: |
| `SiteMainHeadProd2325.patch` (`HEAD e5ce2487c` -> `2325`) | `26a965999b3a6dddbf15fd689c1724d28abe98d472a98f739a73e219643dd7b7` | 67,420 |
| `SiteMainHeadProd2325.elm` (complete postimage) | `956b075cceca47021408bb3d5635e21d7ea5da5a5aa90ee6ec9ebd3cd7adf6f7` | 105,698 |
| `SiteMainProd2255To2325Delta.patch` (`2255` -> `2325` delta) | `2dd50844a8470bde7b4340b5075a8fe62b3121cde50fab69ef5a1ffce0a2d6bb` | 35,920 |
| `site-browser-acceptance-homepage-2325.patch` | `2d756248547050cfc39d69c0eac3ef3396c97d811b8e7fe2e30cc769118fbd13` | 8,102 |
| `SiteMainHeadFixture2325.elm` | `728cb2ff85373b7df09a41b4a65c08793c537ce46e883b33c8be78c7b653a0dd` | 17,056 |
| `site-head-mvp-usability-qa-2325.cjs` | `30c6b8f447a9d5253bfbf713abe97613d775b83380f888e3fb5b3e08d8149281` | 28,108 |
| `gemini-site-frozen-website-manifest-2325.json` | `e99cf6275badb9a9f432124a68db1031fad35e358e10d955b206ef4b60144d39` | 10,971 |


## 5. `2339` Refinement Incorporating `gemini-gui` Peer Review (`01M6CQ5A0ECDES0VDQ8E0861E1`)

- Folded `gemini-gui`'s TEA monotonicity refinement without mutating frozen `2255` or `2325`: `ToggleMobileNav`, `CloseMobileNav`, `SelectSpotlight`, and `StepSpotlight` now increment `tabFocusSeq`, so an `A -> B -> A` non-keyboard click/toggle sequence strictly invalidates any in-flight `FocusSettled` callback (`abaStaleIgnored.lastTabFocusMiss == Nothing` in `SiteMainHeadFixture2339.elm`).
- `SiteMainHeadProd2339.patch` (`HEAD e5ce2487c` -> `2339`): `sha256:03915fa2db7d2f3ae880b9ff5edc2af2eed3bb4f7d1b1651823972cce70b3d34` (`67863` B)
- `SiteMainHeadProd2339.elm`: `sha256:25ca9228b9938254b084e13d53cb8fad46e9103ce62e38f47ab8e0bb7e1bdaf3` (`106124` B)
- `SiteMainProd2325To2339FocusSeqDelta.patch`: `sha256:fabe454751c8e98b65f77aaa487a2b5066f145197191873ef594eb86ab91bee1` (`1662` B)
- `SiteMainHeadFixture2339.elm`: `sha256:a8aa344450756c343a501e72cba15558afc7907f9b6298c2cd9ee1f8b2dc193b` (`17813` B)
