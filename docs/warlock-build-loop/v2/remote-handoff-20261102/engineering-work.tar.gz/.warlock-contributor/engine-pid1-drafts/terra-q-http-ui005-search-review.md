# UI005 search-no-match: source-bound review

2026-11-01, terra-q-http. Read-only preparation; no compiler, model, native or VM execution. This is not acceptance. Current port observations and source must be bound to the actual trial. Original ledger `ELM-UI-005/search-no-match` oracle remains: “no-match message and query remain reachable without launch.” Its earlier accepted native tuple and evidence are retained; they do not establish this port's behavior.

## Actual path and observations

1. `SurfaceRenderer.elm:126-128`: the popup input sends `surface-query` on an ordinary non-composing input, with protocol 2, popup role, publication, lease, field id and full query. Composition emits preedit until completion.
2. `Popup.elm:54,73-100`: a local pending query can already appear in the field before a controller round trip. A visible query alone does not prove controller acceptance. Duplicate and unchanged query dispatches are suppressed; preedit is not the committed query.
3. `HttpPopup.elm:31-40`, `UiHttp.elm:62-69`, `Policy.hs:33-37`: popup dispatch posts to `/actions`; polling uses `/events`. The 5-second HTTP limits are not a replacement for the original trial deadline.
4. `Owner.hs:200-226,400-419`: role/admission and strict action decode precede enqueue of `view-action` to the controller. The owner checks closed fields, protocol, role, counters and text bounds; it does not itself prove a current Elm search update. `Surface.elm:559,575` enforces current publication/lease, open popup and `control:search`; `Desktop.elm:1334-1336` requires the captured current stamp, rejects controls and over-256-character queries, and updates query/page with no effects.
5. `Surface.elm:483`: no-match text depends on an open application surface and a present catalog whose search returns no results, with earlier loading/failure states taking precedence. Observe query and no-match together on the current actual source/window, and no launch during the interval. The actual physical focus/typing and no-match outcome are not yet observed in this review.

One successful Apps click at (715,65) is a positive physical control. The (715,77) non-response despite painted button pixels is a separate observation, not proof of the cause. No synthetic browser mutation, Enter or launch is needed to resolve this original scenario; use root's physical trial and unchanged identity, geometry, deadline and cleanup fences.

## Source correspondence (SHA-256)

```
d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98  implementation/warlock/src/SurfaceRenderer.elm
fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58  implementation/warlock/src/Popup.elm
745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396  implementation/warlock/src/Presentation.elm
3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419  implementation/warlock/src/UiHttp.elm
4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354  implementation/warlock/src/HttpPopup.elm
c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb  implementation/warlock/src/Surface.elm
273622ad7a83a5538896b43831ffc705e3c38df9c1419ee0ec43cd5f81bec2c8  implementation/warlock/src/Desktop.elm
a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9  implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs
5c5d063cdd550a077aedce803656996fc63be34030df5ba635219ffed0d61d40  implementation/warlock/haskell/runtime/src/Warlock/Ui/Policy.hs
```

Quint source-intake distinction: local popup state, controller state, HTTP action queue and visible frame are distinct state holders; admission/enqueue is not a rendered-state or native-observation witness. No new model was written or executed.
