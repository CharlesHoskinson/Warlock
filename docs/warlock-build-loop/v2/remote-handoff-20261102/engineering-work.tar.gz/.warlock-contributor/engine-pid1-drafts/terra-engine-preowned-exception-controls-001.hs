{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT-ONLY, UNEXECUTED. New preowned route; the old raw-aborted hook tests
-- remain separate historical evidence. Root retains each Probe, resolver
-- guard, every worker and an independent guardian even on timeout/exception.
module PreownedExceptionControls (Probe, newProbe, runSyncFault, runAsyncCancel, runStopAfterNoAcquire) where

import Control.Concurrent (ThreadId, forkFinally, killThread)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Internal (OwnerStatus(..), SessionObservation, ToolError(..))
import Warlock.Capture.Process.Persistent
 (PersistentOwner, PersistentStatus(..), SessionExit(..), StopReceipt(..),
  StopDeadlineObservation(..), newPersistentOwner, persistentStatus,
  persistentUnderlyingStatus, persistentHeldNoInput, requestSessionStop,
  startBudgetAfter, stopBudgetMicros, tryPersistentStopDeadline)
import Warlock.Capture.Process.Persistent.Internal
 (withPersistentOwnerHook, qaPersistentPendingIssues)
import Warlock.Platform.Executable (HeldExecutable, qaHoldHeldGate, qaHeldBorrowCount)

type Result = Either SomeException (Either SessionExit ((), SessionExit))
data Probe = Probe PersistentOwner (IORef (Maybe HeldExecutable))
 (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId)) (IORef (Maybe ThreadId))
 (MVar ()) (MVar ()) (MVar ()) (MVar ()) (MVar ()) (MVar ())
 (MVar (Either SomeException ())) (MVar (Either SomeException ())) (MVar Result)
 (IORef Int) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("preowned exception: " ++ label)))
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure

data Mode = SyncFault | AsyncCancel | StopAfterNoAcquire
runSyncFault, runAsyncCancel, runStopAfterNoAcquire :: Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
runSyncFault = run SyncFault
runAsyncCancel = run AsyncCancel
runStopAfterNoAcquire = run StopAfterNoAcquire
run :: Mode -> Probe -> (PersistentOwner -> IO HeldExecutable) -> IO ()
run mode (Probe owner held ownerTid heldTid killerTid preowned resumePreowned noAcquire resumeNoAcquire gateEntered gateUnlock gateDone killerDone ownerDone spawns used) supplier = mask $ \restore -> do
 first <- atomicModifyIORef' used (\v -> (True,not v))
 check "single-use probe" first
 let hook stage = case stage of
      "qa-startup-cap-preowned" -> case mode of
       SyncFault -> ioError (userError "injected preowned failure")
       AsyncCancel -> putMVar preowned () >> readMVar resumePreowned
       StopAfterNoAcquire -> pure ()
      "qa-startup-not-acquired" -> case mode of
       StopAfterNoAcquire -> putMVar noAcquire () >> readMVar resumeNoAcquire
       _ -> pure ()
      "persistent-before-spawn" -> atomicModifyIORef' spawns (\n -> (n+1,()))
      _ -> pure ()
     finish = do
      void (tryPutMVar resumePreowned ())
      void (tryPutMVar resumeNoAcquire ())
      void (tryPutMVar gateUnlock ())
      let waitOne ref done = do
           worker <- readIORef ref
           case worker of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
      waitOne heldTid gateDone
      waitOne ownerTid ownerDone
      waitOne killerTid killerDone
     action = do
      image <- restore (supplier owner)
      writeIORef held (Just image)
      selection <- need (persistentHeldNoInput image [] [("LANG","C"),("LC_ALL","C")])
      case mode of
       StopAfterNoAcquire -> do
        _ <- mask_ $ do
         tid <- forkFinally (restore (qaHoldHeldGate image (putMVar gateEntered ()) (readMVar gateUnlock))) (putMVar gateDone)
         writeIORef heldTid (Just tid)
         pure tid
        within "held gate actually locked" (readMVar gateEntered)
       _ -> pure ()
      start <- startBudgetAfter (case mode of StopAfterNoAcquire -> 300000; _ -> 2000000) >>= need
      stop <- need (stopBudgetMicros 1000000)
      _ <- mask_ $ do
       tid <- forkFinally (restore (withPersistentOwnerHook owner selection 4096 start stop
         (\(_ :: SessionObservation) -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook)) (putMVar ownerDone)
       writeIORef ownerTid (Just tid)
       pure tid
      latched <- case mode of
       SyncFault -> pure Nothing
       AsyncCancel -> do
        within "exact cap already preowned" (readMVar preowned)
        target <- readIORef ownerTid >>= maybe (ioError (userError "owner worker unavailable")) pure
        _ <- mask_ $ do
         tid <- forkFinally (killThread target) (putMVar killerDone)
         writeIORef killerTid (Just tid)
         pure tid
        pure Nothing
       StopAfterNoAcquire -> do
        within "terminal not-acquired before finish" (readMVar noAcquire)
        firstStop <- requestSessionStop owner stop
        deadline <- tryPersistentStopDeadline owner
        check "first stop latches" (firstStop == StopLatchedBeforeLive)
        case deadline of StopDeadlineLatched d -> pure (Just d); _ -> ioError (userError "stop D unconfirmed")
      case mode of StopAfterNoAcquire -> void (tryPutMVar resumeNoAcquire ()); _ -> pure ()
      result <- within "owner disposition" (readMVar ownerDone)
      count <- readIORef spawns
      phase <- persistentStatus owner
      raw <- persistentUnderlyingStatus owner
      pending <- qaPersistentPendingIssues owner
      case mode of
       StopAfterNoAcquire -> do
        second <- tryPersistentStopDeadline owner
        check "stop owns unchanged deadline and settled terminal no-acquire" $
         count == 0 && phase == PersistentRetired && raw == Available && maybe True (const False) pending &&
         (case (result,latched,second) of
           (Right (Left (StartupRefused SessionClosed)), Just d, StopDeadlineLatched d2) -> d == d2
           _ -> False)
       SyncFault -> check "sync failure preserves preowned custody as Unknown" $
        count == 0 && maybe False (const True) pending &&
        (case (result,phase,raw) of
          (Right (Left (ExitUncertain _ _)),PersistentQuarantined _,Quarantined _) -> True
          _ -> False)
       AsyncCancel -> check "async cancellation rethrows and retains owner" $
        count == 0 && maybe False (const True) pending &&
        (case (result,phase,raw) of
          (Left _,PersistentQuarantined _,Quarantined _) -> True
          _ -> False)
      void (tryPutMVar gateUnlock ())
      case mode of
       StopAfterNoAcquire -> do
        done <- within "gate holder completed" (readMVar gateDone)
        remaining <- qaHeldBorrowCount image
        check "no image borrow was committed" (remaining == Just 0 && case done of Right () -> True; _ -> False)
       _ -> pure ()
 restore action `finally` finish
