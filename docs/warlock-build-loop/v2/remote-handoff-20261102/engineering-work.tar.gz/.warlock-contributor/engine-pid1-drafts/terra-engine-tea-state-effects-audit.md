# TEA-001/002 source-state and typed-effect map (preparation only)

Tuple: original slice `.warlock-contributor/tea-model-effects.json`, source revision
31a92dce92538f5282643c006854e23294b15bbe. No reducer, compiler, model,
protected check, native, VM or GPU execution by this worker. This file is not
an acceptance decision and does not establish complete lifecycle coverage.

## Owning reducer and complete direct fields

`DesktopPolicy.Model` is exactly `{controller : OutputController.Model}`.
The following source excerpts preserve every direct field. Recursion into every
nested value is mandatory for complete state comparison; do not mistake this
outer map for a full deep serializer or for a sanctioned constructor export.

### OutputController.elm

```elm
type Scope = Scope Counter Counter

type Model = Model
    { announcements : OutcomeAnnouncements.Model
    , controller : Controller.Model
    , revision : Counter
    , highest : Counter
    , views : List Scope
    , locations : List {scope : Scope, box : Shortcuts.Box}
    , selected : Maybe Scope
    , batches : List Batch
    , batchExhausted : Bool
    , capacityRefused : Bool
    }

type alias CatalogRequest = { binding : Binding.Binding, request : Counter }
type alias Batch = { scope : Scope, revision : Counter, publication : Counter, lease : Counter, binding : Binding.Binding, wire : String, observations : List (String,Counter), operations : List UnsentOperation.Key, catalogs : List CatalogRequest }
```

### SurfaceController.elm

```elm
type Model = Model { recovery : Recovery.Model, desktop : Desktop.Model, publication : Counter, lease : Counter, exhausted : Bool }
```

### Desktop.elm

```elm
type alias Model =
    { windows : TaskbarShell.Model
    , choice : Maybe Choice
    , choiceNotice : String
    , popupOrigin : PopupOrigin
    , returnFocus : Maybe FocusTarget
    , menuOrigin : Maybe FocusTarget
    , ownerScope : Maybe {outputId : Counter, providerId : Counter}
    , ownerExhausted : Bool
    , launch : Launch.Model
    , launchFromApplications : Bool
    , applications : Maybe Catalog.Snapshot
    , applicationPage : Int
    , presentationCapacity : Bool
    , pins : Pins.Model
    , pointer : PointerOwnership.Model
    , shortcuts : Shortcuts.Model
    , jumpList : JumpList.Model
    , jumpEntry : Maybe String
    , jumpOpening : Bool
    , jumpExpected : Maybe Counter
    , jumpBack : Bool
    , files : Files.Model
    , filesOpen : Bool
    , filesOpening : Bool
    , filesExpected : Maybe Counter
    , systemMenu : SystemMenu.Model
    , systemMenuOpen : Bool
    , systemMenuOpening : Bool
    , systemMenuExpected : Maybe Counter
    , systemMenuConfirmation : Maybe SystemMenu.Intent
    , notifications : Notifications.Model
    , notificationsOpen : Bool
    , notificationsOpening : Bool
    , notificationsExpected : Maybe Counter
    , motionExpected : Maybe Counter
    , motion : Motion.Model
    , settings : Settings.Model
    , settingsOpen : Bool
    , settingsOpening : Bool
    , settingsExpected : Maybe Counter
    , shortcutPreferences : ShortcutPreferences.Model
    , shortcutExpected : Maybe Counter
    , settingsHelp : Bool
    , query : String
    , open : Bool
    , overview : Bool
    , overviewWorkspace : Maybe String
    , workspaceNavigation : WorkspaceNavigation.Model
    , workspaceInventory : Maybe WorkspaceInventory.Snapshot
    , overviewRecovery : OverviewRecovery.Model
    , overviewTransfer : Maybe Counter
    , snap : Maybe Snap.Choice
    , switcher : Switcher.Model
    , nativeSwitcher : Maybe NativeChord
    , switcherOrigin : Maybe Counter
    , switcherExpected : Maybe Counter
    , switcherHistory : Maybe {context : {lifetime : Counter, epoch : Counter, output : Counter, revision : Counter}, roots : List Counter}
    , request : Counter
    , presentation : Maybe Counter
    , expected : Maybe Counter
    , adapterNotice : Maybe AdapterNotice.Notice
    , catalogFailure : Maybe { binding : Binding.Binding, request : Counter }
    , catalogOpening : Bool
    }

type PopupOrigin = PointerEntry | KeyboardEntry

type FocusDestination = TaskbarGroup String | OverviewOpener
type alias FocusTarget = {binding : Binding.Binding, destination : FocusDestination, output : Maybe Counter}

type alias NativeChord = {generation : Counter, roots : List Counter, history : List Counter, origin : Maybe Counter, steps : List Switcher.Direction, released : Bool, cancelled : Bool, consumed : Bool}

type ChoiceToken = ChoiceToken Binding.Binding Counter

type alias Choice = { chord : Maybe Counter, binding : Binding.Binding, output : Counter, root : Counter, application : String, token : ChoiceToken, placement : Maybe Snap.Proposal, transfer : Maybe Transfer.Proposal }

choiceToken : Model -> Maybe ChoiceToken
choiceToken model = model.choice |> Maybe.map .token

type ViewStamp = ViewStamp (Maybe Binding.Binding) Counter
```

## Required nested state and opaque identities

* `TaskbarShell.Model` is `{shell,picker,generation,menus}`; `Shell.Model` has
  all 21 fields at Shell.elm:35 (including pending expectations, receipts,
  `issued`, transport/refusal/retry flags, geometry and native observation).
* `Effects.Model` holds `connected`, `observed`, `request`, `generation`,
  `transaction`, `unresolved`; operation variants include snap and workspace
  proposals, and outcome statuses are Pending/Committed/Refused/Cancelled/
  Unknown. A terminal receipt does not prove an observed scene transition.
* `Launch.Model` is opaque `{host,snapshot,revision,request,phase}`;
  phases are Idle, Pending host+intent, Settled intent+Submitted/Refused/Unknown.
  The intent includes request/lifetime/generation/entry. Catalog.Snapshot,
  MenuBridge.Model, Switcher.Model, OutcomeAnnouncements.Model, Scope,
  binding, Counter and multiple choices/tokens are also opaque. Nested
  catalogs, lists, maps, options and full-width counters must remain complete.
* `ReconciliationTracking.Model` contains `slots`, `legacy`, `informational`;
  each slot retains record/proof/actionRequest/geometryRequest/action/geometry/
  released. Batch `wire` is the exact stored serialized commit string, not just
  its digest or a reconstructed projection.
* `UInt64.Counter` is a canonical decimal string, up to 18446744073709551615;
  `Binding` owns three nonzero Counters. Never round through JS Number.
* Desktop's private `Choice`, `FocusTarget`, `NativeChord`, and typed token
  fields occur in the quoted model and must not be lost merely because an
  accessor or UI projection does not expose them. No mutator or opaque
  constructor should be exported to make a fixture pass.

## Exact policy effect and interpreter route

`DesktopPolicy.update` maps a sanitized gateway to `OutputController.update`,
then ALWAYS calls `OutputController.register effects updated`. Registration can
change batches/refusal/exhaustion and other state before `effectsFor`; it can
also emit an optional full commit. The result list places that `Publish` first,
then timers in original controller-effect order. Full JSON semantics of each
Publish includes the complete output projection, requests and focus; compare
all values and array order, not just effect tags, selected fields or counts.

| Reached source effect | Policy effect |
| --- | --- |
| `Desktop.WindowEffect (Shell.ArmPrepared token)` | `Delay 2000 (Desktop.Window (TaskbarShell.ExpirePrepared token))` |
| `Desktop.ArmWorkspaceNavigation intent` | `Delay 2000 (Desktop.WorkspaceNavigationDeadline intent)` |
| `Desktop.ArmChoice token` | `Delay 2000 (Desktop.ChoiceDeadline token)` |
| `Desktop.Arm token` | `Delay 10000 (Desktop.Deadline token)` |

Prepared token is a canonical Counter. Workspace intent includes request,
generation, source, destination and context. ChoiceToken contains a complete
Binding and Counter. Launch.PendingToken contains the host and full Intent.
An actual matching input history must reach each tested effect; a constructed
tag-only stand-in is insufficient.

`Main.interpret` sends Publish to `surfaceCommits` and turns Delay into
`Process.sleep duration` followed by `Policy.Deadline message`. `Cmd.batch`
is an interpreter command, not proof of native side effect or execution order.
`HttpMain.effects` instead enqueues Publish using `UiHttp.enqueue`; its local
`lost` reducer discards returned effects after `TransportLost`. A 204 Posted
response permits the next queued POST, not a native action/receipt. Report these
as distinct actual routes; do not conflate transport and pure policy effects.

## Oracle and evidence constraints

Compare complete resulting state and every effect across identical sanitized
histories and against independent literal expected transitions; a second reducer
run or a filtered projection alone cannot meet that obligation. A compiled
read-only inspection approach needs exact compiler/artifact/source binding,
complete schema (including opaque constructors and JSON), supported values,
no reducer mutation, and explicit refusal for unknown/unobservable functions
or representations. `Debug.toString` is not complete JSON/function evidence.
Do not use this document's excerpts as auto-generated expected outcomes.
Normal commit/refusal, mismatched receipt, pending/disconnect Unknown/no replay,
stale/malformed data, rebind and full-width identity histories remain required.
Native, provider, GUI, release and original whole-EARS verdicts are separate.
