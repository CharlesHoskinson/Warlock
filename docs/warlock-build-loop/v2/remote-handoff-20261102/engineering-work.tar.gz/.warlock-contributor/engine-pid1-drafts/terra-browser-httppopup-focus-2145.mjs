// Proposed UNRUN real-browser component fixture for actual compiled HttpPopup.
// This is distinct from the 32-seed ui-http.cjs synthetic DOM campaign.
// Root must bind the ENTIRE source/dependency closure, actual generated HTML/JS,
// compiler and harness hashes; these named hashes are minimum preconditions.
//
// Required harness interface:
//   assertSourceIdentity(minimumHashes): verifies those bytes and complete closure.
//   assertNetworkIsolation(): fails unless all /events and /actions XHR are
//     intercepted in the browser with no native owner or network passthrough.
//   deliverPresentation(frame): waits for actual HttpPopup GET /events then
//     fulfills it with HTTP 200 JSON {bridgeProtocol:1,kind:'presentation',payload:frame}.
//   actions(): returns every complete captured POST /actions JSON body in order.
//   waitForActionCount(n): bounded wait for the nth intercepted request, not a latency measurement.
//   respondAction(index,204,''): fulfills that actual intercepted POST, once.
//   evaluate, until, check: bounded real browser DOM/CDP controls and assertions.
// Browser synthetic events and fake responses do NOT prove native keyboard/IME,
// AT announcements, gateway acceptance, shown compositor frame, timing or release.
export async function httpPopupFocus2145({assertSourceIdentity,assertNetworkIsolation,deliverPresentation,actions,waitForActionCount,respondAction,evaluate,until,check}) {
  await assertSourceIdentity({
    'implementation/warlock/src/HttpPopup.elm':'4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354',
    'implementation/warlock/src/UiHttp.elm':'3a649f51ff0f783a19fa8bb427bdc0ebb7b3eb7473428044d88a54f78b9da419',
    'implementation/warlock/src/Presentation.elm':'745a143ac94ab15a27a2c8d494bf66c167a42816cdddd71ffe877ba3627b3396',
    'implementation/warlock/src/Popup.elm':'ebb12fa83349dcfbdc4e7f67f63daf3738d25f25960d6541c0f432abacad85b1',
    'implementation/warlock/src/SurfaceSnapshot.elm':'9c85362ec27496438eb5a159e2c162704ef2922ba41df172a17e81787203913a',
    'implementation/warlock/src/SurfaceRenderer.elm':'58119053ca9eb07ebe261af2152da4db3cf4bc32713c224b11975d1f3418485e'
  });
  await assertNetworkIsolation();
  const row=(id,domId,label,name)=>({id,domId,label,ariaLabel:name,detail:'',enabled:true});
  const frame=(publication,query,status)=>({surfaceProtocol:2,publication,lease:'7',mode:'applications',status,bar:[],popup:[
    row('control:search','launcher-search',query,'Search applications'),
    row('control:close','close-applications','Windows','Close applications and return to windows'),
    row('control:refresh','refresh-applications','Refresh','Refresh applications'),
    row('entry:org.example.Foot','entry-foot','Foot','Open Foot')
  ]});
  const read=()=>evaluate(`(() => {const root=document.querySelector('.surface-popup');const field=root?.querySelector('[data-surface-field="control:search"]');const entry=root?.querySelector('[data-surface-control="entry:org.example.Foot"]');return {publication:root?.dataset.publication,lease:root?.dataset.lease,query:field?.value,selectionStart:field?.selectionStart,selectionEnd:field?.selectionEnd,focused:document.hasFocus()&&document.activeElement===field,sameField:field===window.heldSearch,status:root?.querySelector('[role="status"]')?.textContent,live:root?.querySelector('[role="status"]')?.getAttribute('aria-live'),composing:root?.parentElement?.getAttribute('data-input-composing'),entryDisabled:entry?.disabled,entryAriaDisabled:entry?.getAttribute('aria-disabled')};})()`);
  const exact=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const pending='Results may not match current input. Previous: Type to search applications.';
  await deliverPresentation(frame('1','','Type to search applications.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='1'`);
  await evaluate(`(() => {window.heldSearch=document.querySelector('[data-surface-field="control:search"]');window.heldSearch.focus();})()`);
  let state=await read();
  check('real browser initial input is the focused element',state.focused&&state.sameField&&state.query===''&&state.entryDisabled===false,state);
  await evaluate(`(() => {const f=window.heldSearch;f.value='foot';f.setSelectionRange(2,2);f.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:'t'}));})()`);
  await until(`document.querySelector('.surface-popup [role="status"]')?.textContent === ${JSON.stringify(pending)}`);
  await waitForActionCount(1);
  let wires=await actions();
  state=await read();
  const query={surfaceProtocol:2,kind:'surface-query',surface:'popup',publication:'1',lease:'7',id:'control:search',query:'foot'};
  check('pending renderer retains focus/caret and disables stale entry',state.query==='foot'&&state.focused&&state.sameField&&state.selectionStart===2&&state.selectionEnd===2&&state.status===pending&&state.live==='off'&&state.entryDisabled===true&&state.entryAriaDisabled==='true'&&exact(wires,[query]),{state,wires});
  await evaluate(`document.querySelector('[data-surface-control="entry:org.example.Foot"]').click()`);
  check('disabled entry cannot emit intercepted action',exact(await actions(),[query]));
  await respondAction(0,204,'');
  await evaluate(`(() => {const f=window.heldSearch;f.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true,data:''}));f.value='foot漢';f.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:'漢'}));})()`);
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='true'`);
  state=await read();wires=await actions();
  check('synthetic preedit retains field without a new request',state.composing==='true'&&state.query==='foot漢'&&state.focused&&state.sameField&&state.entryDisabled===true&&exact(wires,[query]),{state,wires});
  await evaluate(`(() => {const f=window.heldSearch;f.value='foot';f.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:''}));})()`);
  await until(`document.querySelector('.surface-popup')?.parentElement?.getAttribute('data-input-composing')==='false' && document.querySelector('[data-surface-field="control:search"]')?.value==='foot'`);
  await evaluate(`window.heldSearch.setSelectionRange(2,2)`);
  await deliverPresentation(frame('2','foot','Choose a matching application.'));
  await until(`document.querySelector('.surface-popup')?.dataset.publication==='2' && document.querySelector('.surface-popup [role="status"]')?.textContent==='Choose a matching application.'`);
  state=await read();wires=await actions();
  check('matching publication preserves same focused element and caret',state.publication==='2'&&state.lease==='7'&&state.query==='foot'&&state.selectionStart===2&&state.selectionEnd===2&&state.focused&&state.sameField&&state.status==='Choose a matching application.'&&state.entryDisabled===false&&state.entryAriaDisabled==='false'&&exact(wires,[query]),{state,wires});
}
