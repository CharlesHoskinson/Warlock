# Wave 16 Source-Bound Defect Review: Existing Elm Styling & QA Drafts (`display-capture-1631`)

- **Reviewer**: `gemini-gui` (`warlock-20261031-setup`)
- **Timestamp (UTC)**: `2026-11-01T16:42:00Z` (governing availability cutoff `2026-11-01T16:56:00Z`)
- **Scope & Honesty Boundaries**:
  - Read-only source audit of existing Elm styling, QA, and checklist drafts under `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/` against actual repository sources (`implementation/warlock/src/*.elm`, `implementation/warlock/haskell/runtime/src/Warlock/Ui/{Display.hs,Mvp.hsc}`, `implementation/warlock/haskell/runtime/ui/Main.hs`, `implementation/warlock/qa/*.{mjs,cjs,py}`, `site/src/SiteMain.elm`).
  - **Zero existing drafts were rewritten or modified.** Zero repository production, model, or tool files were edited. Zero compilers, tests, Quint models, browser harnesses, VM/QMP commands, or GPU tools were executed.
  - **No actual Warlock Wayland window has been observed yet** (`nativeOperations: []`; `15 / 242` whole requirements and `39 / 417` scenarios remain fixed historical source-scoped records; `HOSTSTOP2`, original deadlines `D`, and stopped histories are preserved).
  - Pre-display-fix component report `1793547720897141427` is historical for the changed display-capture bytes (`Display.hs`, `ui/Main.hs`, `test-ui-display/Main.hs`, `runtime.cabal`); requalified report `1793550462035880723` (`sha256:d2a6b3a8bb8eec181a3e9bc5e4bdc1b820092245101d870b7c492d2ae8c4e6f2`) is offline component evidence (`passed: true, nativeAccepted: false, releaseAccepted: false`) while Root conducts the isolated Omarchy VM display trial (`engine-display-20261101T163508Z`).

---

## 1. Unchanged Existing Drafts Audited (SHA-256)

All existing drafts below were inspected strictly read-only and retain their exact pre-audit digests:

| Draft File | SHA-256 | Patch / Symbol Baseline Check |
|---|---|---|
| `MvpLayout.patch` | `23e2e1469450fe0126dccef5cb20c5c5a47880fb60e14b588718652d1b97e2fd` | `git apply --check` clean against `HEAD`; all qualified Elm symbols resolve; **2 new source defects (`D1`, `D2`)** |
| `MvpLayoutA11yFollowup.diff` | `d784e13768e957ab2422ec7046750834105159a9e7bcef53c4852b255f26ea88` | Post-`MvpLayout.patch` accessibility delta; **inherits `D1` & `D2`** |
| `EngineMvpJourney.elm` | `71946785ce4804669220aefc1a8a63813e0b333045470447906bee67536cc082` | `82` qualified imports valid; pre-trim `Result D.Error` `(==)` compile defect + **3 new source/protocol defects (`D3`, `D4`, `D5`)** |
| `EngineMvpJourneyTrim.patch` | `b344b4cda241dfe505e327cbc645ec71087c184da7ecca8b87ecb5ceb60df897` | Fixes `Result D.Error` `(==)` and trims unused imports (`78` valid); **still retains `D3`, `D4`, `D5`** |
| `SourceStatusUpdate.diff` | `b3ffd99097aa768f067ad2ce9226ac401e17169df34f6191079660ebdda6d53b` | `git apply --check` clean against `site/src/SiteMain.elm`; **2 source/status & focus defects (`D6`, `D7`)** |
| `HomepageCandidate.elm` | `3770ea32ed1ee923c4219c75e2366beb68b068c6007085c4f771013cdd3fba29` | Standalone site candidate; **stale architecture/status & focus defect (`D6`, `D7`)** |
| `HomepageCandidateFollowup.diff` | `3d245a20ee94781cd14430e50cdc33fd336fe586aead59f16c6ba54432d41787` | Delta over `HomepageCandidate.elm`; **stale 8-suite/Quint-FAIL copy & unapplied layout claims + hidden-button focus no-op (`D6`, `D7`)** |
| `engine-window-observation-checklist.md` | `df106158ebfc5567eadf6b22db164087d52f5230a53e78e702398afd0b7126f0` | **Route typo (`POST /action` vs `POST /actions`) & stale binary/display citations (`D8`)** |

---

## 2. Specific New Source Defects Found (Excluding Previously Reported Issues)

### `D1` — `MvpLayout.patch:107-108` (`Warlock/Ui/Mvp.hsc`) Hardcodes `gtkWidgetSetSizeRequest bView (-1) 56`, Vertically Clipping `.surface-bar` at `textScale > 100`
- **Draft location**: `MvpLayout.patch:107-108` (`gtkWidgetSetSizeRequest bView (-1) 56`, replacing `HEAD` `Warlock/Ui/Mvp.hsc:840` `72`).
- **Actual Elm & QA source**:
  - `implementation/warlock/src/SurfaceTheme.elm:284,290` sets `.surface-bar` `font-size: scaledRootFontSize appearance.textScale` (`16px` at `100`, `20px` at `125`, `24px` at `150`, `28px` at `175`, `32px` at `200`) and `height: calc(3em + 8px)`:
    - `100%` -> `56px`
    - `125%` -> `68px`
    - `150%` -> `80px`
    - `175%` -> `92px`
    - `200%` -> `104px`
  - Confirmed by `implementation/warlock/qa/settings-browser.mjs:90` (`expectedBarHeight = (scale) => 3 * ((16 * scale) / 100) + 8`) and `implementation/warlock/qa/feedback-context-browser.mjs:179`.
- **Failure mechanism**: `WebKitWebView` reports `0` natural height to `GtkWidgetClass.measure()`, and `bView` is packed into `GtkBox` with `vexpand = 0` (`Warlock/Ui/Mvp.hsc:838`). Locking `bView`'s GTK size request to `56px` caps its Wayland/WebKit viewport at `56px`, vertically clipping the bottom `12px` (`125%`), `24px` (`150%`), `36px` (`175%`), or `48px` (`200%`) of `.surface-bar` (note: unpatched `HEAD` `72px` already clips `150%`/`175%`/`200%`, while `56px` additionally regresses `125%`).
- **Integration fix for Root**: Parse `appearance.textScale` alongside `SurfaceLease` in `Warlock/Ui/Mvp.hsc` (default `100`, clamped to `{100,125,150,175,200}`) and set `gtkWidgetSetSizeRequest bView (-1) (3 * ((16 * textScale) `div` 100) + 8)`.

### `D2` — `MvpLayout.patch:286-304` (`SurfaceRenderer.elm`) Uses Brittle `String.startsWith "Applications connected." snapshot.status` for `isAppOnlyClosed`
- **Draft location**: `MvpLayout.patch:286-304` (`renderPopup` in `implementation/warlock/src/SurfaceRenderer.elm`).
- **Actual Elm source**:
  - `MvpLayout.patch:286` defines:
    ```elm
    isAppOnlyClosed =
        snapshot.mode == "closed"
            && List.isEmpty snapshot.popup
            && String.startsWith "Applications connected." snapshot.status
    ```
  - In `implementation/warlock/src/Shell.elm` and `Desktop.elm`, whenever an `applicationOnly` session receives a `taskbar-pins-outcome` (`"Refused"` or `"Unknown"`) or catalog read failure notice and the user subsequently closes `Popup` (`Escape` or `"Windows"`), `snapshot.status` retains that pin/catalog outcome message rather than `"Applications connected."`.
- **Failure mechanism**: `isAppOnlyClosed` evaluates to `False` even though `Shell.applicationOnly` is still `True`, causing the `Popup` pane to snap from `"Application Workspace"` + guidance card back to the misleading empty `"Choose a window"` heading.
- **Integration fix for Root**: Derive `isAppOnlyClosed` structurally from `snapshot.bar` capability flags instead of `snapshot.status` prefix matching:
  ```elm
  isAppOnlyBar =
      List.any (\c -> c.identity == "bar:applications" && c.enabled) snapshot.bar
          && List.all
              (\c -> not (List.member c.identity [ "bar:overview", "bar:switcher" ]) || not c.enabled)
              snapshot.bar
  ```

### `D3` — `EngineMvpJourney.elm` & `EngineMvpJourneyTrim.patch` Silently Exhaust `controllerHttp` (`UiHttp.Lost`) on Commit #17 Inside `allChecks`
- **Draft location**: `EngineMvpJourney.elm:307-308, 625-626, 678-680` (unchanged after `EngineMvpJourneyTrim.patch`, shifting to post-trim `L303-304, 621-622, 674-676`).
- **Actual Elm source**:
  - `implementation/warlock/src/UiHttp.elm:83-84` caps `retained` (`active` + `pending`) at `maxPendingActions = 16`. When `retained >= 16`, `UiHttp.enqueue` transitions `UiHttp.Model` to `Lost reason` (`"UI transport capacity exceeded. No action was retried."`) and returns `( nextModel, Cmd.none, Just (UiHttp.Lost reason) )`.
  - In production `implementation/warlock/src/HttpMain.elm:27-29`, `Just (UiHttp.Lost _)` immediately invokes `Policy.update Policy.TransportLost`, entering `host-disconnected`.
- **Failure mechanism**:
  1. `EngineMvpJourney` calls `UiHttp.enqueue` on `state.controllerHttp` for all **25** commits in `allChecks` without ever calling `UiHttp.update (UiHttp.Posted (Ok ""))` (`UiHttp.elm:121`, simulating `Warlock.Ui.Http` `204` completion).
  2. Every call site (`fanOutCommit`, `stepBarRawAction`, `applyPopupMessage`) discards the third tuple element `Maybe UiHttp.Event` via `( nextHttp, _, _ ) = UiHttp.enqueue ...`, never forwarding `Just (UiHttp.Lost _)` to `Policy.update Policy.TransportLost` and never asserting `UiHttp.problem finalState.controllerHttp == Nothing`.
  3. Consequently, **`state.controllerHttp` silently poisons with `Lost "UI transport capacity exceeded. No action was retried."` on commit #17 (`unpinForUnknownStep`, post-trim `L1239`)**, and commits #17–#25 silently drop transport enqueueing while `allChecks` still reports `True`.
- **Integration fix for Root**: Route `Just (UiHttp.Lost _)` into `Policy.update Policy.TransportLost` (matching `HttpMain.elm:27-29`), settle each in-flight HTTP `POST /actions` via `UiHttp.update (UiHttp.Posted (Ok ""))` when simulating `204` acknowledgement, and assert `UiHttp.problem state.controllerHttp == Nothing` on healthy steps (plus add a dedicated negative check verifying the 17th unsettled enqueue triggers `Policy.TransportLost`).

### `D4` — `EngineMvpJourney.elm` & `EngineMvpJourneyTrim.patch` Leak Unretired `Outputs.Model.batches` (`0 -> 9`) by Omitting `"view-disposition"` Settlement
- **Draft location**: `EngineMvpJourney.elm:304-512` (`fanOutCommit`).
- **Actual Elm & QA source**:
  - `implementation/warlock/src/OutputController.elm:296` appends a `Batch` for every commit with non-empty `requests` (`catalog-request` / `taskbar-pins-write`) and refuses capacity (`batchExhausted = True`, `capacityRefused = True`) once `List.length model.batches >= 16`.
  - Batches are retired only when `Warlock.Ui.Owner` emits `"view-disposition"` (`"batch-disposition"`, `disposition = "admitted"`, `OutputController.elm:345-361`; cf. `implementation/warlock/qa/ui-http.cjs:269-271`).
- **Failure mechanism**: `fanOutCommit` fans out `barSnapshot`, `popupSnapshot`, and `announcement`, and callers manually inject `"catalog-snapshot"` / `"taskbar-pins-outcome"`, without ever delivering `"view-disposition"`. Across `allChecks`, `9` batches remain leaked in `Outputs.Model.batches`; extending the journey past `16` domain requests will spuriously trigger `capacityRefused`.
- **Integration fix for Root**: Emit the matching `"view-disposition"` (`disposition = "admitted"`) frame in the simulated broker helper whenever `Warlock.Ui.Owner` admits a request batch.

### `D5` — `EngineMvpJourney.elm` Hardcodes Unapplied `MvpLayout.patch` Geometry (`56 / 480 / 360`) Instead of `HEAD` `Warlock/Ui/Mvp.hsc` (`72 / 640 / 480`), Plus `elm.json` `source-directories` Constraint
- **Draft location**: `EngineMvpJourney.elm:103-105` (`barHeightRequestPx = 56, popupMinWidthPx = 480, popupMinHeightPx = 360`).
- **Actual Haskell & Elm build config**:
  - Current `implementation/warlock/haskell/runtime/src/Warlock/Ui/Mvp.hsc:840,847` sets `bView` `(-1, 72)` and `pView` `(640, 480)`.
  - `implementation/warlock/elm.json` declares `"source-directories": [ "src" ]` only; compiling any `qa/*.elm` module requires a temporary `elm.json` with `["src", "qa"]` (as `implementation/warlock/qa/check-snapshot-contracts.py:41` already constructs).

### `D6` — `SourceStatusUpdate.diff` & `HomepageCandidateFollowup.diff` Carry Superseded Component-Report & Unapplied-Layout Claims
- **`SourceStatusUpdate.diff:15-18, 34, 53, 75-76, 165, 174-178`**: Cites component check `1793547720897141427`'s `10-suite / 248-model PASS` prior to Root's pre-namespace `DisplayEnvironment` fix (`Display.hs`, `ui/Main.hs`, `test-ui-display/Main.hs`, `runtime.cabal`), which Root marked historical for the changed display bytes after guest `run-01` failed closed before GUI mapping (subsequently requalified in `1793550462035880723`, still offline component scope only).
- **`HomepageCandidateFollowup.diff:89-96, 168, 178-179, 215`**: Two waves stale — still asserts component `1793544641421564031` (`"8 Haskell suites & 197 old model cases PASS; new UI-engine Quint profile retains FAIL on 3 missing positive witnesses"`) AND describes unapplied `MvpLayout.patch` (`GtkOverlay`, `56px` `Bar`, `480x360` `Popup` at `L90`) rather than actual `Warlock/Ui/Mvp.hsc` (`GtkBox`, `72px` `Bar`, `640x480` `Popup`).

### `D7` — Mobile Nav `Escape` Focus Handling Defect in Both `SiteMain.elm` (`SourceStatusUpdate.diff`) and `HomepageCandidateFollowup.diff`
- **`site/src/SiteMain.elm:795, 1632` (unchanged in `SourceStatusUpdate.diff`)**: At `<= 900px`, pressing `Escape` while keyboard focus is inside `#wl-home-nav-drawer` dispatches `CloseMobileNav`, flipping `.wl-home-drawer` to `display: none` (`SiteMain.elm:1632`) without `Dom.focus` restoration — dropping active focus onto `document.body`.
- **`HomepageCandidateFollowup.diff:43-61, 133`**: `EscapeMobileNav` unconditionally runs `Task.attempt NavToggleFocused (Dom.focus "wl-home-nav-toggle")` whenever `currentModel.mobileNavOpen == True`. If the user opened the drawer at `<= 900px`, widened the viewport past `900px` (where `.wl-home-mobile-actions` is `display: none`, `HomepageCandidate.elm:1810`), and pressed `Escape` inside `<header>`, `#wl-home-nav-toggle` exists in the DOM (`Dom.NotFound` does NOT fire) while HTML `element.focus()` silently no-ops on a `display: none` ancestor (`NavToggleFocused (Ok ())` clears `lastNavFocusMiss` without moving focus).

### `D8` — `engine-window-observation-checklist.md` Has a `POST /action` Singular Route Typo and Pre-Integration Binary/Display Citations
- **`engine-window-observation-checklist.md:60-62, 71, 77`**: Writes `POST /action` (singular), whereas actual `Warlock/Ui/Http.hs`, `implementation/warlock/src/UiHttp.elm:68`, and `implementation/warlock/qa/ui-http.cjs:75,102` use **`POST /actions` (plural)**.
- **`engine-window-observation-checklist.md:12-13, 15-16, 139`**: Still references a separate `warlock-ui-engine` binary (`--ui-engine-bin`) / `Warlock.Capture.Process.Owner` (`HeldExecutable`) instead of same-ELF `warlock-ui-owner --engine-only` (`Warlock.Ui.EngineCustody` + `EngineEntrypoint.hs:70`), and cites pre-fix `Display.hs:13-40` rather than `ui/Main.hs:81` `captureDisplayEnvironment` before `enterPrivateNetwork` (`ui/Main.hs:83`).

---

## 3. Post-Display-Capture GTK4 / Elm Visual Context for First Guest Screenshot (`Main.hs:46-47, 81-86`, `Display.hs:19-57`)

- `ui/Main.hs:81` now captures `DisplayEnvironment` **before** `enterPrivateNetwork` (`ui/Main.hs:83`), validating root-owned `/run` and `/run/user` while UID `0` still maps to `0` without relaxing any socket/ancestor ownership or `0700` mode check.
- `startUnreadyEngine` (`ui/Main.hs:46-47`) launches the PID-1 `EngineOnly` child with **exact 4 environment variables**:
  - `LANG=C.UTF-8`
  - `LC_ALL=C.UTF-8`
  - `XDG_RUNTIME_DIR=<validated dir>`
  - `WAYLAND_DISPLAY=<validated socket name>`
- Because `HOME`, `PATH`, `XDG_DATA_DIRS`, `GTK_THEME`, and `GSETTINGS_SCHEMA_DIR` are intentionally absent in the `EngineOnly` child, GTK4 / WebKitGTK 6.0 uses compiled-in Adwaita widget defaults + `/usr/share` XDG fallback while Elm's `SurfaceTheme.elm` supplies self-contained inline CSS tokens (Lacquer Night default, `system-ui` font stack) inside the undecorated `980x680` `GtkBox` (`72px` `bView` over `vexpand=1` `640x480`-min `pView`, plus `1x1` untargetable `cView`).
- Standing ready to inspect Root's first post-display-fix guest screenshots immediately upon AgentBus receipt.
