{-# LANGUAGE ScopedTypeVariables #-}
-- Source-only integration control. Call from the existing runtime test target
-- while an actual selected LiveSession and owned endpoint are still lexical.
-- Both credentials must be obtained from real SCM_CREDENTIALS receives: the
-- selected child and a separately controlled foreign sender. This helper does
-- not create a Session, PID, credential, socket, or process from test strings.
module PersistentScopeControls (checkLiveScope) where

import Control.Concurrent (forkFinally, threadDelay)
import Control.Concurrent.MVar (newEmptyMVar, putMVar, takeMVar)
import Control.Monad (unless, void)
import Data.IORef (modifyIORef', newIORef, readIORef, writeIORef)
import System.Posix.Types (Fd)
import System.Timeout (timeout)
import Warlock.Bootstrap.CurrentSessions
import Warlock.Bootstrap.ScopedPeer
import Warlock.Capture.Process.Bootstrap (deadlineAfter)
import Warlock.Capture.Process.Persistent (LiveSession)
import Warlock.Platform.Executable (LeaseRole)
import Warlock.Platform.Resolver (Identity)
import Warlock.Protocol.PeerCredential (PeerCredential)

checkLiveScope :: LiveSession -> Fd -> Identity -> LeaseRole -> PeerCredential -> PeerCredential -> IO ()
checkLiveScope session peer image role selected foreignCredential = do
  authority <- newCurrentSessions
  registration <- newRegistration authority
  escaped <- newIORef Nothing
  callbacks <- newIORef (0 :: Int)
  deadline <- deadlineAfter 1000000 >>= either (ioError . userError . show) pure
  result <- withApprovedOwnedLivePeer registration session peer image role $ \scope -> do
    writeIORef escaped (Just scope)
    valid <- authenticateLiveFragment deadline scope selected
    require "real selected SCM fragment authenticates" (valid == Right ())
    foreignResult <- withLiveAdmission deadline scope foreignCredential (modifyIORef' callbacks (+100))
    require "foreign real SCM credential cannot reach callback" (either (const True) (const False) foreignResult)
    done <- newEmptyMVar
    void (forkFinally (authenticateLiveFragment deadline scope selected) (putMVar done))
    wrongThread <- timeout 1000000 (takeMVar done)
    require "selected credentials on another thread refuse" (case wrongThread of Just (Right (Left WrongThread)) -> True; _ -> False)
    missingD <- authenticateFragment scope selected
    require "persistent scope fails closed when frame deadline omitted" (missingD == Left ScopeUnavailable)
    admitted <- withLiveAdmission deadline scope selected (modifyIORef' callbacks (+1))
    require "live selected callback is admitted once" (admitted == Right ())
    short <- deadlineAfter 20000 >>= either (ioError . userError . show) pure
    threadDelay 40000
    late <- withLiveAdmission short scope selected (modifyIORef' callbacks (+10))
    require "expired original frame deadline cannot enter callback" (either (const True) (const False) late)
  require "selected live scope published" (result == Right ())
  count <- readIORef callbacks
  require "only selected and timely callback executed" (count == 1)
  saved <- readIORef escaped >>= maybe (ioError (userError "scope was never published")) pure
  after <- authenticateLiveFragment deadline saved selected
  require "escaped scope is retired after lexical action" (after == Left ScopeClosed)
  retired <- retireRegistration registration
  require "registration retirement does not retain callbacks" (retired == ScopeRetired)
 where
  require label ok = unless ok (ioError (userError label))
