# Independent `Popup.pendingQuery` & Composition UX Audit and Queued `UI005` Preparation (`1936` Wave)

- **Author**: `gemini-gui` (`warlock-20261031-setup`)
- **Base Commits Verified**: `59a2f38ab` (`ELM-TEA-002` acceptance) / `889e9458d` (immutable Elm source)
- **Scope**: Queued preparation for current port original `UI005` (`search-no-match`) only. Root's active `WIP=1` remains `ELM-TEA-001`. Canonical counts (`16` whole EARS / `40` scenarios, `242` requirements / `417` scenarios, `nativeAcceptance: false`, `nativeOperations: []`, `HOSTSTOP2`) and all canonical files remain untouched. Both patches are ignored drafts verified read-only via `git apply --check`; Elm/Node execution remains reserved for Root's serialized protected runner.

---

## 1. Complete Ordered Transport & Desktop Publication Proof (No Unauthorized `Desktop` Mutation)

Tracing every message from `Popup.elm` through `UiHttp.elm` / native WebKit FIFO transport to `OutputController.elm`, `Surface.elm`, `Desktop.elm`, and `SurfaceController.elm` proves **zero unauthorized `Desktop` state mutation occurs**:

1. **Active IME Composition (`isComposing model == True`, `Popup.elm:88-98, 101`)**:
   - `surface-composition-start` and `surface-preedit` update `Popup.composition = Preediting ...` and `Popup.pendingQuery = Just query` locally with `[]` effects (`Popup.elm:89, 98`).
   - `Popup.elm:101` (`else if isComposing model || ... then (model, [])`) drops **every** non-field `Action` / `LocalAction` inside `Popup` before `Presentation.dispatch`. Zero button action leaves `Popup` during IME preedit.

2. **Committed Unacknowledged Query (`isComposing model == False` and `model.pendingQuery == Just query`)**:
   - Every transition in `Popup.elm` (`lines 83, 95, 96, 115`) that leaves `isComposing == False` and `pendingQuery == Just query` has **already** emitted `Dispatch(surface-query, pub=P, lease=L, query=query)` onto the FIFO transport (`UiHttp.enqueue` FIFO queue in `UiHttp.elm:85-87`, or native WebKit FIFO handler per `qa/query-delivery.qnt:4`) for a `query /= SurfaceRenderer.queryValue snapshot`.
   - `Presentation.query` (`Presentation.elm:54-58`) enforces the exact same character and byte/code-unit bounds (`<= 256` for `"applications"`, `<= 512` for `"files"`, no `< 32` or `127`) as `Desktop.SearchQuery` (`Desktop.elm:1367`) and `Files.edit` / `Files.textValid` (`Files.elm:20, 39`; `Desktop.elm:1155`).
   - Therefore, when `surface-query(pub=P, lease=L, query=query)` arrives at `OutputController.Renderer` (`OutputController.elm:185`) -> `Surface.resolve` (`Surface.elm:575`):
     - **If `Desktop` is still at `publication = P`**: `Desktop.SearchQuery` (`Desktop.elm:1368`) or `Desktop.EditFilesPath` (`Desktop.elm:1156`) calls `advance` because `query` differs from `model.query` / `model.files.draft`, changing `Surface.packet` (`control:search` / `control:files-path` `label`), and `SurfaceController.applyOrdinary` (`SurfaceController.elm:55-58`) **increments `publication` to `P + 1`**. Every subsequent `surface-action(pub=P, lease=L, ...)` arriving later in FIFO fails `event.shown /= publication` (`P /= P + 1`) in `Surface.resolveAction` (`Surface.elm:542`), returning `Nothing`.
     - **If `Desktop` had already advanced past `P` before `surface-query(pub=P)` arrived**: `Desktop`'s `publication` is already `>= P + 1`, so both `surface-query(pub=P)` and any `surface-action(pub=P)` fail `shown == publication` (`Surface.elm:542, 555`), and `Popup.Present` (`Popup.elm:115`) re-sends only `surface-query(pub=P', query)`.

---

## 2. Actual UX & View-Transition Mismatch Confirmed

Although `Surface.resolveAction` protects `Desktop` from stale mutations, `Popup.elm` (`lines 54, 101`) and `SurfaceSnapshot.elm` (`lines 74-75`) have an actual **UX affordance and view-transition mismatch**:

1. **Stale Target Controls Left Visibly Enabled During `pendingQuery` (`mode == "applications"` and `"files"`)**:
   - In `Surface.elm:309-346`:
     - `pin:<id>` (`"Pin <First Match>"`, `line 317`) and `jump:open:<id>` (`"Actions for <First Match>"`, `line 324`) are computed directly from `List.head (Catalog.search model.query)` of the **prior** acknowledged query.
     - `unpin:<id>`, `pin-left:<id>`, `pin-right:<id>` (`lines 318-322`) and `control:page-previous` / `control:page-next` (`lines 341-342`) are paginated across `prefix ++ entries` at `model.applicationPage` (which `Desktop.SearchQuery` resets to `0` at `Desktop.elm:1368`).
   - `SurfaceSnapshot.pendingQuery` (`SurfaceSnapshot.elm:75`) and `Popup.elm:101` previously duplicated a 4-branch list covering only `entry:*`, `files:open-path`, `files:collection:*`, and `files:home`.
   - Consequently, while a new query is pending (including a `UI005` no-match query that will remove `pin:<id>` and `jump:open:<id>` completely once acknowledged), `Popup.view` renders the new query in `control:search` alongside **visibly enabled** (`disabled=false`, `aria-disabled="false"`, click handler attached) stale `"Pin <Old Match>"`, `"Actions for <Old Match>"`, `unpin:*`, `pin-left:*`, `pin-right:*`, `control:page-*`, `control:close`, `control:refresh`, `control:acknowledge`, and `files:refresh` buttons. Clicking any of them enqueues a doomed `POST /actions` (`pub=P`) into `UiHttp`'s 16-slot FIFO queue that `Surface.resolveAction` (`P /= P + 1`) silently drops.

2. **Direct View vs `Popup.transition` Asymmetry During IME Preedit (`isComposing model == True`)**:
   - While `isComposing model == True`, `Popup.elm:101` (`if isComposing model`) rejects **every** non-field popup action inside `Popup.transition`, yet `Popup.view` (`Popup.elm:54`) only called `SurfaceRenderer.pendingQuery`, leaving `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `jump:open:*`, `control:page-*`, `control:close`, `control:refresh`, `control:acknowledge`, and `files:refresh` visibly enabled (`disabled=false`, `aria-disabled="false"`) in the DOM while `Popup` dropped clicks on them.

---

## 3. Minimal Atomic Patch & Production-View QA Extension

### Base Canonical File Hashes (Untouched)
- `implementation/warlock/src/Popup.elm`: `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58`
- `implementation/warlock/src/SurfaceSnapshot.elm`: `58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7`
- `implementation/warlock/qa/ui-http.cjs`: `8ec7289e83fe7cadc9e2b238766255aa56ebb06e3f97cec86a238a4d82a285f3`
- `implementation/warlock/qa/LocalFieldReplay.elm`: `64f0114398fbff8a1f2f42d0e824727531316660f725edb1c96bfb7de241d09f`

### Ignored Draft Deliverables
1. **Production Source Ignored Patch**:
   - Path: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-popup-pending-query-mvp-1936.patch`
   - SHA-256: `2dcce34d4a7a7b02f97bd1eea6bd59aed718b7d69a1f71840713b55ce79c157a`
   - Design:
     - Defines a **single shared pure predicate** `SurfaceSnapshot.pendingQueryBlocked : String -> Bool` covering all authored non-field interactive popup controls in `"applications"` and `"files"` (`entry:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `jump:open:*`, `control:page-previous`, `control:page-next`, `control:close`, `control:refresh`, `control:acknowledge`, `files:open-path`, `files:collection:*`, `files:home`, `files:refresh`), plus `SurfaceSnapshot.composing : Snapshot -> Snapshot`.
     - Eliminates the duplicate predicate in `Popup.elm:101` by calling `SurfaceSnapshot.pendingQueryBlocked`, and composes `SurfaceSnapshot.composing` in `Popup.view` when `isComposing model` holds.
     - Preserves: live query/preedit draft (`value item.label`), IME composition state and `data-input-composing`, keyed `<input>` identity (`"control:control:search"` / `"control:control:files-path"`) and active DOM keyboard focus, `Preview.visual` lookup on the authoritative `Snapshot`, pending feedback and literal canonical `snapshot.status`, `ui-frontend-delivery.qnt` / `query-delivery.qnt` correspondence, and all 221 differential cases in `SurfaceSnapshotContracts.elm` / `snapshot-contracts.cjs`.

2. **Existing Production-View & Reducer QA Extension Ignored Patch**:
   - Path: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-popup-pending-query-qa-1936.patch`
   - SHA-256: `2abf70a537da2a8426bbb1b157d274c450f12b50190f5e64f907369e8feac35b`
   - Coverage:
     - Extends `implementation/warlock/qa/ui-http.cjs` (`pendingQueryControls()`, run automatically by `tools/check_elm_cpu.py` against `--optimize` compiled `HttpPopup.js` DOM + `XHR`) to verify across `"applications"` and `"files"` modes:
       - Active IME preedit (`compositionstart` + `input` with `isComposing: true`): `data-input-composing="true"`, retained keyed `<input>` DOM node and `document.activeElement`, preedit draft, verbatim `[role="status"]` text, zero `POST /actions`, and `disabled === true` / `aria-disabled === "true"` / removed `click` listener on all `jump:open:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `entry:*`, `control:page-*`, and popup buttons.
       - Cancelled unchanged IME composition (`compositionend` at baseline): `data-input-composing="false"`, controls restored to enabled without `POST`.
       - Committed pending query (`no-match-query`) + interim unacknowledged `presentation` refresh (`publication: '2'`) + authoritative matching no-match `presentation` (`publication: '3'`): exact `surface-query` POSTs, preserved draft/focus/literal canonical `status`, disabled stale Pin/Jump/Entry/Paging/Popup buttons until authoritative acknowledgement, and re-enabled `unpin:org.mozilla.firefox` dispatching `surface-action` on `publication: '3'`.
     - Extends `implementation/warlock/qa/LocalFieldReplay.elm` with 4 direct `Popup.transition (Popup.Action ...)` checks (`pendingQueryBlocksPinJumpAndActions`, `composingBlocksPinJumpAndActions`, `acknowledgedQueryReenablesPinJumpAndActions`, `pendingFilesPathBlocksFilesActions`).
