{-# LANGUAGE OverloadedStrings #-}
-- QA ONLY: selected Backend candidate plus root-retire-race-015 overlay.
-- One process, one case; the surrounding protected host must strong-root the
-- actual owner, worker, child custody and original guardian before starting.
-- Feed the receipt returned by the SAME owner's real stop, after a real peer
-- request/reply. This module neither starts nor kills a process. A timeout or
-- failed assertion leaves all owners, barriers and workers with that host.
module PortableRootRetireRace015 (checkRootRetireRace) where

import Control.Concurrent.MVar (MVar, readMVar)
import Control.Exception (SomeException)
import Control.Monad (unless)
import System.Timeout (timeout)
import Warlock.Backend
  (PersistentBackendOwner, PersistentBackendRun, persistentBackendOutcome,
   qaAwaitRootExit, qaReleaseRootExit, retirePersistentBackend)
import Warlock.Bootstrap (PersistentBootstrapResult(..))
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline, remainingMicros)
import qualified Warlock.Capture.Process.Persistent as P

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))

-- Reuses the caller's existing absolute QA deadline; it does not mint StopD.
within :: AdmissionDeadline -> String -> IO a -> IO a
within original label action = do
  remaining <- remainingMicros original
  check (label ++ ": original QA deadline expired") (remaining > 0)
  result <- timeout remaining action
  maybe (ioError (userError (label ++ ": original QA deadline elapsed"))) pure result

checkRootRetireRace :: AdmissionDeadline -> PersistentBackendOwner -> P.StopReceipt
  -> MVar (Either SomeException PersistentBackendRun) -> IO ()
checkRootRetireRace original owner stop completed = do
  check "real same-owner stop selected live child" (stop == P.StopSignalSent)
  -- The QA seam is after the actual bootstrap call returns, inside the actual
  -- root callback and before its release. It does not simulate a root close.
  within original "actual lexical root exit boundary" qaAwaitRootExit
  premature <- within original "retire while actual root callback is held"
    (retirePersistentBackend owner)
  check "bootstrap completion alone cannot retire the held resolver" (not premature)
  qaReleaseRootExit
  outcome <- within original "actual Backend worker completion" (readMVar completed)
  run <- either (ioError . userError . ("actual Backend worker exception: " ++) . show) pure outcome
  check "actual selected leader reaped" $ case persistentBackendOutcome run of
    Right (PersistentBootstrapObserved (Right (_, P.LeaderReaped _))) -> True
    _ -> False
  -- This positive is legitimate only when the real stop budget still admits
  -- and confirms ALL owner cleanup, including resolver and every store.
  clean <- within original "retire after actual lexical resolver exit"
    (retirePersistentBackend owner)
  check "same-owner retirement confirms all tracked custody" clean
  again <- within original "historical same-owner retirement receipt"
    (retirePersistentBackend owner)
  check "confirmed retirement remains stable" again
