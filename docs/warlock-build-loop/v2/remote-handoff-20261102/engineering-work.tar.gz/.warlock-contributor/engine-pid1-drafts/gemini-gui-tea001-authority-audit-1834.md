# ELM-TEA-001 Whole-Contract GUI Authority, Custom-Type & Style-Draft Audit (`1834`)

- **Author**: `gemini-gui`
- **Run**: `warlock-20261031-setup`
- **Source Revision**: `31a92dce92538f5282643c006854e23294b15bbe`
- **Active Slice**: `.warlock-contributor/tea-model-effects.json` (`ELM-TEA-001` / `tea-typed-model` and `ELM-TEA-002` / `tea-pure-update`)
- **Status**: Read-only source/type audit and proposed Root diffs only. Zero production edits, zero compiler/test/model/VM/native execution, and zero native/AT/IME/release acceptance (`15 / 242` whole and `39 / 417` scenarios historical source-scoped; `HOSTSTOP2` preserved).

---

## 1. Original `ELM-TEA-001` Contract Audited

> **ELM-TEA-001 (`tea-typed-model`)**: *"The Elm frontend SHALL represent lifecycle, receipt and operation state with custom types, keep native observations separate from desired UI state and derive projections from one authoritative snapshot without duplicated native authority."*

Audited owning roots (pinned in `.warlock-contributor/tea-model-effects.json`):
- `implementation/warlock/src/Main.elm` (`sha256:a63de0a105e1a13edc5eb67359b665032acba662650659b3a24d4f1999058b66`)
- `implementation/warlock/src/HttpMain.elm` (`sha256:58a3b1f274bc69b053ca31ece17bcd6b65a593d5722ba65a7728b3d22471d5a9`)
- `implementation/warlock/src/Bar.elm` (`sha256:aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7`)
- `implementation/warlock/src/HttpBar.elm` (`sha256:74d4b6b80267e9b22065b2087ee2b5318a3ce1fe346e1897c99ced6031183af8`)
- `implementation/warlock/src/Popup.elm` (`sha256:fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58`)
- `implementation/warlock/src/HttpPopup.elm` (`sha256:4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354`)
- Shared policy/projection chain: `DesktopPolicy.elm` (`018934fe`), `OutputController.elm` (`fdf7b444`), `SurfaceController.elm` (`2e86781c`), `Desktop.elm` (`273622ad`), `Shell.elm` (`6f6a6316`), `ReconciliationFrame.elm`, `ReconciliationTracking.elm`, `Surface.elm`, `Presentation.elm`, `SurfaceSnapshot.elm`, `SurfaceRenderer.elm`, `UiHttp.elm`, `Effects.elm`, `Launch.elm`, `WorkspaceNavigation.elm`, `Pins.elm`, `Files.elm`, `JumpList.elm`, `SystemMenu.elm`, `Notifications.elm`, `Settings.elm`, `ShortcutPreferences.elm`, `MotionPreferences.elm`.

---

## 2. Six-Root Authority & Projection Source Separation Audit

### 2.1 Single Policy Authority (`Main` / `HttpMain` -> `DesktopPolicy` -> `OutputController` -> `SurfaceController` -> `Desktop`)

1. **Identical Pure Policy Core Across Transports**:
   - `Main.elm:15-28` (ports) and `HttpMain.elm:20-55` (`UiHttp.controller`) both run `DesktopPolicy.update : Policy.Msg -> Policy.Model -> (Policy.Model, List Policy.Effect)` (`DesktopPolicy.elm:55-66`) with `view = \_ -> text ""`.
   - `Policy.Model` (`{ controller : OutputController.Model }`) holds a single opaque `OutputController.Model` (`OutputController.elm:23`), which wraps a single opaque `SurfaceController.Model` (`SurfaceController.elm:18`), which wraps `Desktop.Model`.
   - `Policy.Effect` (`DesktopPolicy.elm:15`) has two typed constructors: `Publish E.Value` (emitted solely from `OutputController.register` as a bounded `view-commit` containing `projection`, `requests`, and `focus`) and `Delay Float Desktop.Msg` (retaining exact typed tokens: `TaskbarShell.ExpirePrepared Counter`, `Desktop.WorkspaceNavigationDeadline WorkspaceNavigation.Intent`, `Desktop.ChoiceDeadline ChoiceToken`, `Desktop.Deadline Launch.PendingToken` at `DesktopPolicy.elm:47-52`).
2. **HTTP Delivery vs Native Receipt Separation (`HttpMain.elm:15-30, 46-50`, `UiHttp.elm:121-127`)**:
   - `UiHttp.Posted (Ok "")` (`204 No Content`) advances only `UiHttp.Model`'s `16`-slot transport queue (`active` / `pending`) and returns `Nothing` for `Maybe UiHttp.Event` — HTTP delivery never fabricates a native or presentation receipt.
   - Transport failure (`UiHttp.Lost _`) maps strictly to `Policy.TransportLost` (`DesktopPolicy.elm:60` -> `host-disconnected`), transitioning pending operations to `Unknown` / `Shell.Detached` without replaying mutations.

### 2.2 Passive Renderer Isolation (`Bar` / `HttpBar` & `Popup` / `HttpPopup`)

1. **Zero Policy / Native State in Renderers**:
   - `Bar.Model` (`Bar.elm:30-34`) holds only opaque `{ presentation : Presentation.Model, announcements : Announcement.Model, statusScroll : StatusScroll.Model }`. It cannot import or call `Desktop.update`.
   - `Popup.Model` (`Popup.elm:37`) holds `{ announcements, presentation, previews : Preview.Model, paintGate : PreviewPaintGate.Model, pendingQuery : Maybe String, composition : Composition, lastQuery : Maybe (String, Counter, Counter) }`.
   - `HttpBar.elm:37-49` and `HttpPopup.elm:50-62` enforce `UiHttp.Role = Renderer` (`allowed` = `["presentation", "announcements", "focus"]` at `UiHttp.elm:102`) and fail closed (`UiHttp.stop`) on any unexpected event or non-empty preview command in the HTTP profile (`HttpPopup.elm:19-25, 33-35`).
2. **One Authoritative Snapshot Source (`Surface.packet` -> `SurfaceSnapshot.Snapshot` -> `Presentation.accept`)**:
   - `Surface.packet publication lease desktop` (`Surface.elm:517-531`) derives `mode`, `status`, `appearance`, `motion`, `keyboardParent`, `bar`, and `popup` controls together from a single `Desktop.Model` snapshot.
   - `Presentation.accept` (`Presentation.elm:38-44`) validates the snapshot with `SurfaceSnapshot.decode` (`SurfaceSnapshot.elm:29-50`, opaque `Snapshot`) and requires `publication > model.last` and `lease >= model.lease`.
   - `SurfaceRenderer.elm` (`117, 125-128`) emits no commands or native intents; its DOM callbacks emit only `surface-action` / `surface-query` / `surface-preedit` / `surface-composition-*` envelopes stamped with the accepted snapshot's `(publication, lease)`, re-validated by `Presentation.dispatch` / `editQuery` / `localEdit` locally and again by `OutputController` (`175-192`) + `Surface.resolve` (`546-603`) against the controller's live `(publication, lease)` and `Desktop.capture` stamp.
   - `HttpBar.elm:41-45` and `HttpPopup.elm:53-59` execute `Browser.Dom.focus` only when `Presentation.focusTarget` (`Presentation.elm:19-36`) verifies exact `(surface, publication, lease)` and enabled/`focusOnly` control membership, and `HttpPopup.elm:54` suppresses focus tasks whenever `current.popup.composition /= Popup.Idle`.

### 2.3 Observation vs Desired UI State Separation & Action-Gating Findings

- **Verified Separation in `Desktop` / `Shell` / `Effects`**:
  - Observed native facts are confined to validated `Maybe Snapshot` records (`Effects.Model.observed` wrapping `Scene.Admitted`, `Shell.Model.geometry`, `Desktop.Model.applications`, `Pins.Model.snapshot`, `Files.Model.snapshot`, `JumpList.Model.snapshot`, `SystemMenu.Model.snapshot`, `Notifications.Model.snapshot`, `Settings.Model.snapshot`, `ShortcutPreferences.Model.snapshot`/`inventory`, `WorkspaceInventory.Snapshot`, `Motion.Model`).
  - Terminal receipts in `Effects.apply` (`Effects.elm:116-129`) update only `transaction` / `unresolved` status (`Pending -> Committed | Refused | Cancelled | Unknown`) and never mutate `observed` window scene state.
  - Desired UI state (`open`, `query`, `applicationPage`, `overview`, `overviewWorkspace`, `snap`, `switcher`, `jumpEntry`, `filesOpen`/`files.draft`, `systemMenuOpen`/`systemMenuConfirmation`, `notificationsOpen`/`notifications.policy`, `settingsOpen`/`settings.draft`, `shortcutPreferences.draft`, `motion.preferences.draft`) is never overwritten by a rejected/stale native read.
- **Finding A1 (Known Local Renderer Source-Admission Gap — `Popup.elm:101`, `SurfaceSnapshot.elm:74-75`, `Surface.elm:317, 324`)**:
  - When `Popup.Model.pendingQuery == Just q` (user has edited search locally ahead of the next accepted `Presentation` snapshot), `SurfaceSnapshot.pendingQuery` (`SurfaceSnapshot.elm:75`) and `Popup.transition` (`Popup.elm:101`) disable and drop `entry:*`, `files:open-path`, `files:home`, and `files:collection:*`.
  - **Gap**: `Surface.controls` (`Surface.elm:317, 324`) also derives two **first-search-result-dependent** controls from `entries |> List.head`: **`pin:<id>`** (`"Pin <first match>"`) and **`jump:open:<id>`** (`"Actions for <first match>"`). Neither `SurfaceSnapshot.pendingQuery` nor `Popup.elm:101` disables/blocks `String.startsWith "pin:"` or `String.startsWith "jump:open:"`.
  - **Boundary & Mandatory Pairing Analysis**: Under normal accepted-query FIFO ordering (`UiHttp` -> `Owner.hs` controller queue), an enqueued valid `surface-query` increments `publication` in `SurfaceController` before a trailing `surface-action` is resolved, so `Surface.resolveAction` (`542`) drops the stale `publication` (backend mutation remains unproven; this is a local renderer source-admission gap). **Critical `UX-PERFORMANCE-ACCEPTANCE.md:52` pairing rule**: `Popup.elm:101` MUST NOT drop `String.startsWith "pin:"` / `String.startsWith "jump:open:"` unless `SurfaceSnapshot.elm:75` (`SurfaceSnapshot.pendingQuery`) simultaneously sets `enabled = False` on `pin:` and `jump:open:`; patching `Popup.elm:101` alone would leave `Pin <app>` and `Actions for <app>` rendered `enabled = True` in `Popup.view` while silently dropping clicks. Existing pinned rows (`unpin:<id>`, `pin-left:<id>`, `pin-right:<id>` at `Surface.elm:320-322`) derive from `Desktop.pinIdentities` rather than `Catalog.search model.query` and must remain untouched.

---

## 3. Complete Lifecycle, Receipt & Operation Custom-Type Audit (`ELM-TEA-001`)

### 3.1 Verified Custom-Type Coverage (Compliant Modules)

| Module | Lifecycle / Receipt / Operation Custom Types | Constructor / Decoder Discipline |
| :--- | :--- | :--- |
| `Effects.elm:12-13` | `Operation` (10 constructors), `Status = Pending \| Committed \| Refused \| Cancelled \| Unknown` | Strict `operationDecoder` / `statusDecoder`; `Scene.Admitted` opaque |
| `Shell.elm:12, 31-34` | `Phase = Detached \| Reconciling \| Ready \| Exhausted`, `RecoveryFailure` (5 constructors), `Stamp`, `Effect` | `Stamp` constructor unexported; `recoveryDecoder` closed |
| `WorkspaceNavigation.elm:10` | `Status = Pending \| Unknown \| Committed \| Refused` | Closed `statusDecoder` (`20-25`) |
| `Menu.elm:1-90` | Opaque `WindowId`, `AppId`, `ProviderId`, `OutputId`, `DeclaredActionId`, `MenuId`, `IntentId`, `Binding`; custom `Target`, `Action`, `Navigation`, `Outcome`, `Status` | Opaque validated constructors |
| `Switcher.elm:7-9` | `Direction = Forward \| Reverse`, `Phase = Idle \| Waiting \| Browsing \| Resolved \| Cancelled`, opaque `Model` | Opaque `Model` |
| `Launch.elm:13-45` | Internal `ResultState = Submitted \| Refused \| Unknown`, `Phase = Idle \| Pending String Intent \| Settled Intent ResultState`; opaque `Model`, `PendingToken`, `Acknowledgement`, `Selection` | Opaque tokens; see **3.2.C** on exported `Launch.status : Model -> String` |
| `SystemMenu.elm:7` | `Operation = Volume \| Mute \| Network \| Suspend \| Reboot \| PowerOff \| Lock \| Logout` | Custom operation; see **3.2.A** / **3.2.B** on retained capabilities & `receive` `String` |
| `Settings.elm:7, 10` | `Theme = Night \| Dawn \| HighContrast`, `SaveOutcome = Saved \| Refused \| Unconfirmed` | Stored `SaveOutcome` custom type; see **3.2.B.1** on `receive` input `String` |
| `ShortcutPreferences.elm:7` | `Choice = Undecided \| Keep \| Default \| Alternate` | Custom `Choice`; see **3.2.B.1** on `receive` input `String` |
| `MotionPreferences.elm:7` | `Override = System \| Reduce \| Full` | Custom `Override`; see **3.2.B.1** on `receive` input `String` |
| `Pins.elm:8` | `Confirmation = Saving \| Unconfirmed (Maybe Counter)` | Custom pending confirmation; see **3.2.B.2** on `receive` input `String` |
| `Bar.elm` / `Popup.elm` / `StatusScroll.elm` / `UiHttp.elm` | `Bar.Effect`, `Popup.Composition`, `Popup.Effect`, opaque `StatusScroll.Epoch`/`Model`, opaque `UiHttp.Model`/`Role` | Closed custom types |

### 3.2 Three-Way Classification of Remaining `String` Surfaces Under `ELM-TEA-001`

To avoid conflating retained `Model` representations, boundary decoders, and derived string projections, remaining `String` surfaces separate cleanly into three distinct categories:

#### 3.2.A Retained `Model` Finite Lifecycle, Receipt & Operation States Stored as `String` (True `TEA001` Model-Representation Gaps)
These finite domain states are stored directly inside retained `Model` / `Snapshot` records as `String` rather than Elm custom types, and must be converted to custom ADTs before claiming whole-`ELM-TEA-001` closure:
1. **`Notifications.elm:10-13, 27, 51-76`**:
   - **Lifecycle (`Entry.state : String`)**: `"live" | "expired" | "invoked" | "dismissed" | "closed" | "disconnected" | "unknown" | "unavailable"` retained in `Snapshot.entries` (`27`) and string-matched across `Notifications.elm` (`35, 46, 49, 59, 84, 100, 112, 120`) and `Surface.elm:423`. Should be `type EntryState = Live | Expired | Invoked | Dismissed | Closed | Disconnected | UnknownState | Unavailable`.
   - **Operation (`Target.verb : String`)**: `"invoke" | "dismiss"` retained in `Model.pending` and `Model.outcome` (`Notifications.elm:12-13, 51, 59, 113`). Should be `type Verb = Invoke | Dismiss` (or `ActionTarget = Invoke Counter String | Dismiss Counter`).
   - **Receipt (`Model.outcome : Maybe { request : Counter, target : Target, status : String, expired : Bool }`)**: `"Dispatched" | "Refused" | "Unknown"` retained in `Notifications.Model.outcome` (`Notifications.elm:13, 68-76`). Should be `type OutcomeStatus = Dispatched | Refused | UnknownOutcome`.
2. **`ReconciliationFrame.elm:10, 31-36` (Retained in `ReconciliationTracking.Model` at `ReconciliationTracking.elm:11-12` & `Shell.Model`)**:
   - `Proof` retains finite domain strings `operation : String` (`"observe" | "retire"`), `grantState : String` (`"Retired"`), and `kind : String` (`"binding-retirement"`), stored inside `Slot = Retired ReconciliationFrame.Proof | ...` and `informational : List ReconciliationFrame.Proof`. Should be custom types `ProofOperation = Observe | Retire`, `GrantState = GrantRetired`, and `ProofKind = BindingRetirement`.
3. **`JumpList.elm:6, 15`**:
   - `Action.kind : String` (`"desktop" | "recent"`) retained in `JumpList.Snapshot.actions`. Should be `type ActionKind = DesktopAction | RecentItem`.
4. **`SystemMenu.elm:12-14, 28-29`**:
   - `Snapshot` retains finite capability/permission enums as `String`: `permission : String` (`"yes" | "no" | "auth"`) and `suspend`/`reboot`/`powerOff` (`"yes" | "no" | "na" | "challenge"`). Should be custom types `NetworkPermission` and `PowerCapability`.

#### 3.2.B Boundary Wire-Admission Defect & Transient `String` `receive` Parameters
1. **Defect 3.2.B.1 (HIGH — Live Malformed Receipt Mutation in `Desktop.elm:887, 1027, 1043` -> `MotionPreferences`, `ShortcutPreferences`, `Settings`)**:
   - **Locations**:
     - `Desktop.elm:887-894` (`"motion-preferences-outcome"`) -> `MotionPreferences.receive` (`MotionPreferences.elm:62-70`)
     - `Desktop.elm:1027-1033` (`"shortcut-preferences-outcome"`) -> `ShortcutPreferences.receive` (`ShortcutPreferences.elm:106-115`)
     - `Desktop.elm:1043-1049` (`"shell-settings-outcome"`) -> `Settings.receive` (`Settings.elm:55-63`)
   - **Exact Defect**: All three branches in `Desktop.elm` decode `(D.field "status" D.string)` **without** closed-set validation, and `MotionPreferences.receive` (`67-70`), `ShortcutPreferences.receive` (`110-115`), and `Settings.receive` (`60-63`) treat **any unrecognized `status` string** in their `else` branch as `"Unknown"` / `Unconfirmed`! When a save is pending (`pending = Just { request = r, ... }`), a malformed native frame with matching `binding` and `requestId = r` and `"status": "bogus"` mutates `Model` (`Settings.Model.outcome := Just { request = r, result = Unconfirmed }` + `notice`, advancing `Desktop.presentation` and emitting `Policy.Publish`) instead of failing closed with `(model, [])`.
   - **Fix Scope**:
     - **Immediate `Desktop.elm`-only boundary guard**: `Tea001DesktopPopupGuard.patch` (Section 5.3) decodes `"status"` into closed `SaveReceipt` / `ShortcutSaveReceipt` custom types across all three `Desktop.Incoming` branches (`887, 1027, 1043`) so any malformed status fails decoding cleanly (`Err _ -> (model, [])`), while converting back to canonical `String` at the `*.receive` call site because `MotionPreferences.elm`, `ShortcutPreferences.elm`, `Settings.elm`, and `LayerAppearanceReplay.elm:25` are outside `.warlock-contributor/tea-model-effects.json` `paths`.
     - **Full child-module typing (when slice `paths` are expanded)**: Type `Settings.receive` (`SaveOutcome`), `MotionPreferences.receive` (`ReceiptStatus`), and `ShortcutPreferences.receive` (`ReceiptStatus`) directly to eliminate the canonical `String` round-trip and wildcard `else` branch.
2. **Transient `String` `receive` / `requested` Parameters (Guarded Against Malformed Wire Values, Un-typed Function Signatures)**:
   - `Pins.receive` (`Pins.elm:65`, `"Saved"|"Refused"|"Unknown"`), `Files.receive` (`Files.elm:52`, `"Opened"|"Refused"|"Unknown"`), `JumpList.receive` (`JumpList.elm:30`, `"Submitted"|"Refused"|"Unknown"`), `SystemMenu.receive` (`SystemMenu.elm:73`, `"Committed"|"Submitted"|"Refused"|"Unknown"`), `Notifications.receiveReason` (`Notifications.elm:67`, `reason : String`), `ReconciliationTracking.requested` (`ReconciliationTracking.elm:38`, `"projection-request"|"geometry-facts-request"`), and `OutputController.receiveDisposition` (`OutputController.elm:355`, `"preflight-unsent"|"admitted"|"uncertain"`) guard valid values via `List.member`/equality, so malformed wire strings do not mutate `Model`, but their Elm parameter types remain `String` rather than custom receipt/request ADTs.

#### 3.2.C Derived Presentation / Wire String Projections (NOT Retained `Model` Lifecycle Gaps)
- **`Launch.status : Model -> String` (`Launch.elm:1`)**: Derived read-only string projection over already-typed internal `Launch.Phase = Idle | Pending String Intent | Settled Intent ResultState` (`Launch.elm:13-14`). This is **not** a retained `String` lifecycle field in `Launch.Model`, though `Desktop.elm:1079-1080` and `Surface.elm:81-84, 310, 476-481` match `Launch.status model.launch` against string literals (`"Pending"`, `"Unknown"`, `"Submitted"`, `"Refused"`); exporting a typed `Launch.Status` ADT or `Launch.ready : Model -> Bool` helper eliminates those string comparisons.
- **`Surface.mode : Desktop.Model -> String` (`Surface.elm:62`) & `SurfaceSnapshot.Details` (`SurfaceSnapshot.elm:10`)**: Derived wire/projection strings computed from `Desktop.Model` for `SurfaceSnapshot` transport serialization, and `SurfaceRenderer.elm:109-114, 129` `item.detail` substring presentation hints (zero policy authority).

---

## 4. Style & Empty-State Draft Verification (`AppOnlyHierarchyEmptyState.patch`)

Re-verified `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/AppOnlyHierarchyEmptyState.patch` (`sha256:ef1bb568ae123152b6e17d12abe5e1def81f987f236d16a80cf6837f6e2b50b8`):
- **Clean Apply Check on `31a92dce92538f5282643c006854e23294b15bbe`**: `git -C /home/charl/code/Warlock apply --check` exits `0`.
- **Canonical Status Preserved**: Both `.surface-popup` `<p role="status" aria-live="off">` and `.surface-bar` `<span class="surface-status" role="status">` render **unmodified `snapshot.status`** from `Surface.packet`.
- **Zero Extra Search Authority or View-Derived Effects**:
  - `SurfaceRenderer` never calls `Catalog.search` and never inspects control lists to infer match counts (`hasLauncherEntries` / `hasPinActions` absent).
  - Supplementary `div.surface-empty-state` cards are static presentation nodes (`no id`, `no tabindex`, `no role="status"`, `no aria-live`, `no Html.Events.on` attributes) gated on exact `canonicalContextStatus` + `queryConfirmed` (`model.pendingQuery == Nothing && not (isComposing model)`).
- **Focus, IME & Identities Preserved**:
  - `data-input-composing`, `compositionstart` / `compositionend` / `input` (`isComposing` -> `"surface-preedit"`), `HttpPopup.elm:54` `Popup.Idle` focus gate, `StatusScroll.reservedDomPrefix` DOM ID escaping (`controlDomId`), and all `"control:" ++ item.identity` `Keyed.node` keys, `data-surface-control`, `data-surface-field`, `data-publication`, and `data-lease` attributes remain unchanged.

---

## 5. Concrete Proposed Diff Sketches for Root (If Selected in Slice)

### 5.1 Close `Defect 3.2.B.1` & Child-Module Receipt Typing (`Settings`, `MotionPreferences`, `ShortcutPreferences`)

- **`Settings.elm`**: Export `outcomeDecoder : D.Decoder SaveOutcome` mapping `"Saved" -> Saved`, `"Refused" -> Refused`, `"Unknown" -> Unconfirmed` (failing closed on all other strings), and change `receive : Counter -> SaveOutcome -> Maybe Snapshot -> Model -> Model` so exhaustive `case status of` handles `Saved`, `Refused`, `Unconfirmed` with zero wildcard catch-all.
- **`MotionPreferences.elm`**: Add `type ReceiptStatus = SavedReceipt | RefusedReceipt | UnknownReceipt` + `receiptStatusDecoder`, and change `receive : Counter -> ReceiptStatus -> Maybe Snapshot -> Model -> Model`.
- **`ShortcutPreferences.elm`**: Add `type ReceiptStatus = SavedReceipt | StoredReceipt | RefusedReceipt | UnknownReceipt` + `receiptStatusDecoder`, and change `receive : Counter -> ReceiptStatus -> Maybe Snapshot -> Maybe Inventory -> Model -> Model`.
- **`Desktop.elm:887, 1027, 1043`**: Replace `(D.field "status" D.string)` with closed receipt custom-type decoders across all three outcome branches so malformed status strings fail decoding cleanly (`Err _ -> (model, [])`).

### 5.2 Close `Finding A1` Only as an Atomic Pair (`SurfaceSnapshot.elm:75` + `Popup.elm:101`)

- **`SurfaceSnapshot.elm:75` AND `Popup.elm:101` (must be updated together per `UX-PERFORMANCE-ACCEPTANCE.md:52`)**: Extend the pending-query result-action predicate identically in both files:
  ```elm
  isResultDerivedAction : String -> Bool
  isResultDerivedAction identity =
      String.startsWith "entry:" identity
          || String.startsWith "pin:" identity
          || String.startsWith "jump:open:" identity
          || identity == "files:open-path"
          || identity == "files:home"
          || String.startsWith "files:collection:" identity
  ```

### 5.3 Ready-to-Review Ignored Diff Candidate (`Tea001DesktopPopupGuard.patch`) & Scope Boundaries

- **Proposed Ignored Patch**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/Tea001DesktopPopupGuard.patch` (`sha256:d6fa51eca42fe55e44662d51a77224436aead2519557b9fce748ecfc9c5b679e`, `git apply --check` exits `0` against `31a92dce92538f5282643c006854e23294b15bbe`).
  - **What it fixes**: Stays strictly inside `.warlock-contributor/tea-model-effects.json` (`implementation/warlock/src/Desktop.elm` only) and closes **Defect 3.2.B.1** at the `Desktop.Incoming` boundary across **all three** outcome branches (`motion-preferences-outcome` at `887`, `shortcut-preferences-outcome` at `1027`, and `shell-settings-outcome` at `1043`) via closed `SaveReceipt` and `ShortcutSaveReceipt` custom types and decoders, converting back to canonical `String` only at the `*.receive` call site so out-of-slice `MotionPreferences.elm`, `ShortcutPreferences.elm`, `Settings.elm`, and `implementation/warlock/qa/LayerAppearanceReplay.elm:25` remain untouched.
  - **What it intentionally omits / does not claim**:
    1. Omits `Popup.elm:101` because `SurfaceSnapshot.elm:75` is outside `.warlock-contributor/tea-model-effects.json` `paths`, and patching `Popup.elm:101` without `SurfaceSnapshot.elm:75` would render `Pin <app>` and `Actions for <app>` as `enabled = True` while silently dropping clicks (`UX-PERFORMANCE-ACCEPTANCE.md:52`).
    2. Guards wire admission in `Desktop.Incoming` only — it **does not** by itself convert Category **3.2.A** retained `Model` `String` fields (`Notifications.elm`, `ReconciliationFrame.elm`, `JumpList.elm`, `SystemMenu.elm`) to custom types, which requires expanding slice `paths` to those child modules for literal whole-`ELM-TEA-001` closure.

### 5.4 Complete-Model / Every-Effect QA Replay Note (`TeaContractReplay.elm`)

- Because `Policy.Publish E.Value` and internal opaque models (`OutputController.Model`, `SurfaceController.Model`, `ReconciliationTracking.Model`, `OutcomeAnnouncements.Model`, `TaskbarShell.Model`, `MenuBridge.Model`, `Menu.Model`, `Launch.Model`, `Switcher.Model`, `PointerOwnership.Model`, `Shortcuts.Model`, `Motion.Model`, `OverviewRecovery.Model`) hide state from `OutputController.frame` and `Debug.toString` replaces `Json.Encode.Value` with `<internals>`, `TEA001`/`TEA002` complete-model and every-effect comparison requires a **read-only structural JSON observer** (exposing zero constructors or mutators) that serializes every field of `Policy.Model` and both `Policy.Publish packet` (verbatim `E.Value`) and `Policy.Delay ms msg` (exact `Float` + structured `Desktop.Msg` token) for comparison against independently authored literal expectations.
- Include negative boundary test cases for `"shell-settings-outcome"`, `"motion-preferences-outcome"`, and `"shortcut-preferences-outcome"` carrying `"status": "invalid"` while a save is pending to regression-lock **Defect 3.2.B.1**.
