{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; UNEXECUTED. A QA-only double-fault witness against candidate031.
-- Expected RED until root-part confirmation cannot survive failed gate publish
-- AND failed demotion. Real selected root/owner, sticky StopD and independent
-- process guardian are mandatory; no fd is guessed or cleanup implied.
module QHttpRootDoubleFault031 (Mode(..),Case,newCase,runCase) where
import Control.Exception (mask)
import Control.Monad (unless)
import Data.IORef
import System.Posix.Files (deviceID,fileID,getFileStatus)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,ToolError(..),remainingMicros)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,PersistentStatus(..),StopBudget,StopReceipt(..),StopDeadlineObservation(..),
  newPersistentOwner,newPersistentRootCustody,closePersistentRootPart,persistentStatus,
  requestSessionStop,tryPersistentStopDeadline)
import Warlock.Capture.Process.Persistent.Internal (qaDoubleFaultHook,qaRootPartMark,qaGateBusy)
import Warlock.Platform.Resolver (Identity(..),RootCustody,RootPart(..),RootStepResult(..),withRetainedRoot)
import Warlock.Platform.Resolver.Internal (QaRootSlot(..),qaRootSlots)

data Mode = NormalConfirmation | PublishFault | PublishAndDemoteFault deriving (Eq,Show)
data Case = Case PersistentOwner (IORef (Maybe RootCustody)) (IORef Bool) (IORef [String])
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False <*> newIORef []
check :: String -> Bool -> IO ()
check label good = unless good (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
need :: Show e => Either e a -> IO a
need = either (ioError . userError . show) pure
runCase :: Case -> Mode -> AdmissionDeadline -> StopBudget -> (PersistentOwner -> IO ()) -> IO ()
runCase (Case owner slot used seen) mode startD stopBudget drive = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 remainingMicros startD >>= check "startup D live" . (>0)
 root <- newPersistentRootCustody owner >>= need
 writeIORef slot (Just root)
 st <- getFileStatus "/"
 let ident = Identity (toInteger (deviceID st)) (toInteger (fileID st))
 actual <- restore $ within "actual root and owner lifecycle" $ withRetainedRoot root "/" ident $ \_ -> do
  within "real lifecycle" (drive owner)
  phase <- within "real owner phase" (persistentStatus owner)
  check "retired" (phase == PersistentRetired)
 check "actual pair" (actual == Right ())
 stop <- within "same owner first stop" (requestSessionStop owner stopBudget)
 first <- tryPersistentStopDeadline owner
 check "first stop retained" (stop == StopUncertain CleanupUncertain && case first of StopDeadlineLatched _ -> True; _ -> False)
 qaDoubleFaultHook $ \stage -> do
  atomicModifyIORef' seen (\xs -> (stage:xs,()))
  let inject = case mode of
       NormalConfirmation -> False
       PublishFault -> stage=="gate-publish"
       PublishAndDemoteFault -> stage=="gate-publish" || stage=="demote"
  if inject then ioError (userError ("injected " ++ stage)) else pure ()
 receipt <- restore $ within "actual root close" (closePersistentRootPart owner RootAnchor)
 marks <- qaRootPartMark owner RootAnchor
 gateBusy <- qaGateBusy owner
 currentPhase <- within "phase after fault" (persistentStatus owner)
 calls <- reverse <$> readIORef seen
 slots <- qaRootSlots root
 case mode of
  NormalConfirmation -> check "independent normal receipt" $
   receipt==Right RootStepClosed && marks==Just 2 && not gateBusy && calls==["gate-publish"] && slots==(QaSlotClosed,QaSlotOpen)
  PublishFault -> check "failed publish successfully demoted" $
   receipt==Left CleanupUncertain && marks==Just 1 && gateBusy && calls==["gate-publish","demote"] && slots==(QaSlotClosed,QaSlotOpen) &&
   (case currentPhase of PersistentQuarantined _ -> True; _ -> False)
  PublishAndDemoteFault -> check "failed publish and demotion cannot claim confirmed" $
   receipt==Left CleanupUncertain && marks==Just 1 && gateBusy && calls==["gate-publish","demote"] && slots==(QaSlotClosed,QaSlotOpen) &&
   (case currentPhase of PersistentQuarantined _ -> True; _ -> False)
 -- Gate can be unavailable after injected publication fault: never refill it.
 after <- qaGateBusy owner
 observedD <- tryPersistentStopDeadline owner
 check "normal keeps D; fault leaves D unobservable rather than recreated" $
  case mode of
   NormalConfirmation -> observedD==first && not after
   _ -> observedD==StopDeadlineBusy && after
