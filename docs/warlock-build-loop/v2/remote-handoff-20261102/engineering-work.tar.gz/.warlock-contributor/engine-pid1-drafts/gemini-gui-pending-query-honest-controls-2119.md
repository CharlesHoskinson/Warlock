# Pending-Query Honest Controls, `HttpPopup` DOM QA, Transport-Failure Retained Query & `Bar.view` Connecting Placeholder (`20261101T211913Z`)

- **Agent**: `gemini-gui` (`did:key:z6Mkrcc8RjEN24HqB6sSQoRcsSxfHrM8RWjMbAURibZF1Erc`)
- **Run**: `warlock-20261031-setup`
- **Canonical Baseline (`HEAD`)**: `45ba9ad19bade1187c07690aa8c8245990e0fb6c` (`17 / 242` whole EARS, `41 / 417` scenarios; whole `ELM-TEA-005` accepted; zero canonical edits, zero worker compiler/Node/browser/native/VM execution)

---

## 1. Delivered Draft Artifacts & Preimage Inventory

### Draft Patches & Review Note

| Role | Draft Path | SHA-256 |
| --- | --- | --- |
| **1. Primary Atomic Production Elm Patch** (`SurfaceSnapshot.elm`, `SurfaceRenderer.elm`, `Popup.elm`) | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-pending-query-honest-controls-2119.patch` | `47e7599f62ca60ca18ecd7c20a6160aebad6b10e1348a224e22fb942937816d4` |
| **2. Compiled `HttpPopup` DOM + `LocalFieldReplay` QA Patch** (`qa/ui-http.cjs`, `qa/LocalFieldReplay.elm`) | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-pending-query-ui-http-qa-2119.patch` | `99501be0a371042bf7ab466e022a47f19e0e1ec0f8aa39e0b11702f7b83f1c9a` |
| **3. Separate Optional Read-Only `HttpPopup.view` Retained-Query + Alert Patch** (`HttpPopup.elm`) | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-http-popup-transport-retained-query-2119.patch` | `e505cc140ca63eb94a637b74261f3be31652171d7e74182a038fae0d4c4b2f5d` |
| **4. Separate Next UX Candidate: `Bar.view` Connecting Placeholder** (`Bar.elm`, per `lead` `01M6CG1RWCXERAMS1YE84R8A9R`) | `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/gemini-gui-bar-connecting-placeholder-2119.patch` | `fb22ac232f8292233a01c8d01738962335a5e601bb1c8fab7ec1ed55f03fec43` |

### Canonical Preimages (`HEAD` `45ba9ad19`)

| Canonical File | Preimage SHA-256 |
| --- | --- |
| `implementation/warlock/src/SurfaceSnapshot.elm` | `58298ea43fffba3da6bcc64f1456b47bcde3607d476ef99465be0c98c2b433d7` |
| `implementation/warlock/src/SurfaceRenderer.elm` | `d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98` |
| `implementation/warlock/src/Popup.elm` | `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58` |
| `implementation/warlock/src/HttpPopup.elm` | `4185692e3613f2bc52eefa896e3c0d57cd796afe090a0a994877d27a52cff354` |
| `implementation/warlock/src/Bar.elm` | `aa3cd927c33f9624364b8ba04bc3ceb31c3a13541b6fd1044c9f7ac978d871b7` |
| `implementation/warlock/qa/ui-http.cjs` | `33891cb1822933680115f1a10d0c3b7f3071a63f12c7f3561aafd49c6a9ec009` |
| `implementation/warlock/qa/LocalFieldReplay.elm` | `64f0114398fbff8a1f2f42d0e824727531316660f725edb1c96bfb7de241d09f` |

All four patches verified with `git -C /home/charl/code/Warlock apply --check` and `patch -d /home/charl/code/Warlock -p1 --dry-run -s` both individually and all four together (`rc=0`, zero offsets, zero warnings).

---

## 2. Primary Atomic Production Elm Patch (`47e7599f...`)

### Reconciled Gap & Single-Authority Design

In canonical `Popup.elm` (`fb24afed`), `SurfaceSnapshot.elm` (`58298ea4`), and `SurfaceRenderer.elm` (`d6cc2985`):
1. **Stale-generation / mutation affordances stayed enabled while `pendingQuery /= Nothing`**:
   - Only `entry:*`, `files:open-path`, `files:home`, and `files:collection:*` were disabled/blocked, while `jump:open:<id>` (`Actions`), `pin:<id>` (`Pin`), `unpin:<id>` (`Unpin`), `pin-left:<id>` (`Move earlier`), `pin-right:<id>` (`Move later`), `control:page-previous`, and `control:page-next` remained `disabled = False`, `aria-disabled = "false"`, and clickable against the old query's snapshot.
   - Meanwhile, `<p role="status">` continued showing the old query's status (e.g., `"Type to search applications."` or an earlier no-match string) with no indication that displayed entries lagged behind the unacknowledged input.
2. **All non-field popup buttons stayed visually enabled during active IME preedit (`isComposing model == True`)**:
   - `Popup.transition` line 101 (`if isComposing model ... then (model, [])`) makes **every** non-field popup action inert during composition, yet `Popup.view` rendered `control:close`, `control:refresh`, `control:acknowledge`, `pin:*`, `jump:open:*`, etc. with `disabled = False`, `aria-disabled = "false"`, and an attached `click` listener.
3. **Preserving `SurfaceSnapshotContracts.elm` differential parity (`36c804af2`)**:
   - `implementation/warlock/qa/SurfaceSnapshotContracts.elm:23` checks `same (Old.encode (Old.pendingQuery "typed" a)) (New.encode (New.pendingQuery "typed" b))` against frozen `36c804af2:implementation/warlock/src/SurfaceRenderer.elm`.
   - `gemini-gui-pending-query-honest-controls-2119.patch` (`47e7599f...`) keeps `SurfaceSnapshot.pendingQuery` and `SurfaceRenderer.pendingQuery` byte-compatible for historical differential tests, and introduces:
     - `SurfaceSnapshot.pendingQueryBlocked : String -> Bool` (re-exported on `SurfaceRenderer`), covering `entry:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `jump:open:*`, `control:page-previous`, `control:page-next`, `files:open-path`, `files:collection:*`, and `files:home`.
     - `SurfaceSnapshot.honestPendingQuery : String -> Snapshot -> Snapshot` (re-exported on `SurfaceRenderer`), overlaying the live query onto `fieldIdentity` in `["applications", "files"]` and setting `enabled = False` on `pendingQueryBlocked` controls while keeping `control:close`, `control:refresh`, `control:acknowledge`, and `files:refresh` enabled when enabled in the accepted snapshot.
     - `SurfaceSnapshot.composingPopup : Snapshot -> Snapshot` (re-exported on `SurfaceRenderer`), disabling every popup item except the active `fieldIdentity` `<input>` during `isComposing model`.
     - `SurfaceRenderer.viewWithPreviewPending`, rendering `displayedStatus = if pending then "Results may not match current input." ++ (if String.isEmpty snapshot.status then "" else " Previous: " ++ snapshot.status) else snapshot.status` on `<p role="status" aria-live="off">` (reconciled with `terra-browser-pending-query-feedback.patch` `d38d4d64`).
     - `Popup.view` and `Popup.transition` (`Action`) both consume `SurfaceRenderer.pendingQueryBlocked` / `honestPendingQuery` / `composingPopup`, guaranteeing 1:1 agreement between DOM `disabled` / `aria-disabled` / `click`-listener presence and reducer message admission.
   - Zero app-only styling, empty-state card changes, or frame/receipt/authority edits are mixed in; `Presentation.elm`, `UiHttp.elm`, and `SurfaceSnapshot.decode` are untouched.

---

## 3. Compiled `HttpPopup` DOM + `LocalFieldReplay` QA Patch (`99501be0...`)

- Coordinated with `terra-browser` and `terra-q-http` (`01M6CG0GV1S2TD9F934263BDEG`: `terra-q-http` confirmed zero overlap with `qa/ui-http.cjs`; note per Root/cutoff scope that Root selects whether/when to stage `qa/ui-http.cjs` additions alongside active `ELM-TEA-001` Motion vs `ELM-UI-005` slice declarations).
- Appends `pendingQueryHonestControls()` to `implementation/warlock/qa/ui-http.cjs` (`33891cb1...`) using the existing `harness(popupFile, 'HttpPopup')` DOM/XHR harness (leaving all existing `5262` checks untouched):
  1. Verifies baseline `applications` frame (`publication: '1'`, `lease: '7'`) paints `control:search`, safe recovery buttons (`control:close`, `control:refresh`, `control:acknowledge`), and all 8 mutation affordances (`jump:open:*`, `pin:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `entry:*`, `control:page-previous`, `control:page-next`) enabled with `aria-disabled="false"` and `click` listeners.
  2. Dispatches real DOM `input` (`'foot'`, `isComposing: false`): verifies single `/actions` `surface-query` POST, literal status `'Results may not match current input. Previous: Type to search applications.'` (`aria-live="off"`), all 8 mutation buttons `disabled === true` + `aria-disabled === 'true'` + `listeners.click === undefined`, and all 3 safe buttons enabled (`control:refresh` click emits exact `surface-action` POST while keeping `'foot'` pending).
  3. Dispatches `compositionstart` + `input` (`'foot漢'`, `isComposing: true`): verifies `data-input-composing="true"`, zero network POSTs, `<input>` enabled, and **all 11** non-field popup buttons disabled (`listeners.click === undefined`).
  4. Dispatches `compositionend` (`'foot'` cancel): verifies `data-input-composing="false"`, zero duplicate POSTs, safe recovery buttons re-enabled, and all 8 mutation buttons still disabled.
  5. Delivers unacknowledged `publication: '2'` (`query: ''`, `status: ''`): verifies rebased `surface-query` POST for `publication: '2'`, empty-prior-status branch `'Results may not match current input.'`, and continued mutation disabling.
  6. Delivers matching `publication: '3'` (`query: 'foot'`, `status: 'Choose a matching application.'`): verifies status restoration, re-enabling of all 11 buttons, and positive `pin:org.gnome.TextEditor` `/actions` POST; also verifies acknowledged-baseline preedit + cancel and `files` mode (`control:files-path` `'/tmp'`) disabling `files:open-path`, `files:home`, `files:collection:documents` while preserving `control:close` and `files:refresh`.
- Also adds 5 pure reducer/overlay parity checks to `implementation/warlock/qa/LocalFieldReplay.elm` (`64f01143...`).

---

## 4. Separate `HttpPopup.view` Transport-Failure Gap & Read-Only Proposal (`e505cc14...`)

- **Observed Source Gap (`implementation/warlock/src/HttpPopup.elm:70-75`)**:
  - When `UiHttp.problem model.http` transitions to `Just reason` (e.g., `/actions` POST timeout/HTTP failure after typing a query, `/events` disconnect, or unexpected gateway packet), `HttpPopup.view` replaces `Popup.view model.popup` with `div [attribute "role" "alert"] [text (reason++" Restart this view to reconnect.")]`.
  - Although `model.popup.pendingQuery` and `Presentation.current model.popup.presentation` still retain the user's query in Elm state, the DOM removes `<input data-surface-field="control:search">` (or `control:files-path`), hiding the typed query from sight and copy/selection. This leaves an `ELM-UI-005` query-preservation gap on HTTP renderer transport failure (`search-unavailable` / `search-refused` recovery).
- **Smallest Read-Only Retained-Query + Alert Proposal (`gemini-gui-http-popup-transport-retained-query-2119.patch`, `e505cc14...`)**:
  - Kept strictly separate from `47e7599f...`.
  - When `UiHttp.problem model.http == Just reason` and `Presentation.current model.popup.presentation` has mode `"applications"` or `"files"`, renders `<div role="alert"><reason> Restart this view to reconnect.</div>` followed by a labelled `<input type="text" readonly value=retained data-retained-surface-field=fieldId>` preferring `model.popup.pendingQuery` over `SurfaceRenderer.queryValue snapshot`.
  - Attaches **zero** event handlers, emits **zero** `Cmd`s, and performs **no** automatic XHR replay or reconnect; preserves `roots()` alert text and `env.posts().length === 1` in `qa/ui-http.cjs:104`.

---

## 5. Separate Next UX Candidate: `Bar.view` Startup White-Frame Source Analysis & Connecting Placeholder (`fb22ac23...`)

Per `lead` message `01M6CG1RWCXERAMS1YE84R8A9R` (*"Root directly viewed attempt02/001: toolbar completely white while popup already rendered... Separate next real UX candidate: Bar.view renders empty text when Presentation.current is Nothing"*):

1. **Verified Initial DOM & Source Pipeline**:
   - In the HTTP architecture, `HttpBar` is compiled as standalone Elm 0.19.2 HTML (`elm make src/HttpBar.elm --optimize --output=.../HttpBar.html`) and verified by `Warlock/Http/Document.hs:62-73` (`validateCompilerShape`), which requires the exact standalone Elm wrapper (`<!DOCTYPE HTML>...<body>\n\n<pre id="elm"></pre>\n\n<script>...</script>\n\n</body>\n</html>`) with **no external `shell.css`**.
   - Until `SurfaceTheme.barRootStyles` mounts on `.surface-bar` (painting `background-color: #191516` and full-viewport `box-shadow: ... 0 100vh 0 100vh #100e0e`), `<body>` has WebKit's default `#ffffff` white background.
   - Because `Bar.view` (`implementation/warlock/src/Bar.elm:137-146`) returned `text ""` whenever `Presentation.current model.presentation == Nothing`, `Elm.HttpBar.init` replaced `<pre id="elm"></pre>` with an empty `#text("")` node, leaving the entire toolbar viewport `#ffffff` white from Elm `init` until the first `GET /events` `presentation` payload arrived!
2. **Separate Atomic Candidate (`gemini-gui-bar-connecting-placeholder-2119.patch`, `fb22ac23...`)**:
   - Modifies **only** `implementation/warlock/src/Bar.elm` (`aa3cd927...`) — preserves `Warlock/Http/Document.hs` `validateCompilerShape` and avoids `SurfaceTheme.elm` `unmappedProductPaths`.
   - Replaces `Maybe.withDefault (text "")` in `Bar.view` with `connectingPlaceholder`: a `<div class="surface-bar surface-bar-connecting" data-bar-state="connecting" ...>` styled with `SurfaceTheme.barRootStyles Settings.defaults "reduced"` and `SurfaceTheme.barActionsStyles`, containing a plain `<span>Connecting to desktop…</span>`.
   - **Invariants preserved**:
     - Zero `<button>`s, zero event listeners, zero `tabindex`, zero `data-publication` / `data-lease` / `data-surface-control`, zero authority.
     - Zero `role="status"` / `role="alert"` / `aria-live` attributes — preserves `Announcement.elm` as the single live AT announcement owner.
     - **Honest scope limit**: Paints the themed dark toolbar surface immediately once Elm JS `init` runs (closing the post-JS / pre-first-`presentation` white-toolbar gap observed in `attempt-02/001`), while **not** claiming removal of pre-JS native GTK/WebKit white frames prior to `<script>` execution.

---

## 6. Peer Review of `terra-browser-pending-affordance-view-2114.mjs` (`sha256:9065fa0d...`)

- **Reviewed Artifact**: `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/terra-browser-pending-affordance-view-2114.mjs`
- **Bound SHA-256**: `9065fa0d1fe3ec3e949bb2845490fdca1ef7aa40595c65d6695b7179959375fe` (superseding `20d7d6ee...` per `01M6CG263HAP3H43MG7MMVAZ49`)
- **Source-Bound Review Verdict**: **CONCUR (1:1 compatible with `gemini-gui-pending-query-honest-controls-2119.patch` `47e7599f...`, with proper component-only qualification)**:
  1. **Exact Status & `aria-live` Match (lines 10-12, 45-47, 58, 61-63)**: Expects `'Results may not match current input. Previous: Type to search applications.'` with `aria-live === 'off'` while pending/preediting, and `'Choose a matching application.'` once `publication: '2'` arrives with `query: 'foot'`. Matches `SurfaceRenderer.viewWithPreviewPending` + `Popup.view` byte-for-byte.
  2. **Stale Disabled-Click Negatives & Safe Escape Controls (lines 47-50)**: Asserts `entry:org.example.Foot`, `pin:org.example.Foot`, and `control:page-next` have `disabled === true` and `aria-disabled === 'true'` and emit zero actions when `.click()`ed in DOM, while `control:refresh` and `control:close` remain `disabled === false`. Matches `SurfaceSnapshot.pendingQueryBlocked` / `honestPendingQuery` and `Popup.transition`.
  3. **Composition & Cancel Lifecycle (lines 51-58)**: Asserts `compositionstart` + `isComposing: true` sets `data-input-composing="true"` and disables `entry`, `refresh`, and `close` with zero new port actions, and `compositionend` returning to `'foot'` restores `data-input-composing="false"` and re-enables `refresh` + `close` while keeping `entry` disabled. Matches `SurfaceSnapshot.composingPopup` + `Popup.transition` lines 88-96.
  4. **Current Publication Positive Action Envelope & Non-Overclaim (lines 1-7, 64-69)**: Verifies exact `{surface:'popup', surfaceProtocol:2, kind:'surface-action', publication:'2', lease:'7', id:'entry:org.example.Foot'}` at the isolated port after matching acknowledgement, and explicitly disclaims native input, real IME, physical focus, AT speech, latency, and release acceptance.
  5. **Minor Coverage Note (Complemented by `99501be0...`)**: `9065fa0d` tests `Popup` via ports (`window.testApp.ports.presentation.send`) on `entry:*`, `pin:*`, and `control:page-next`; our `gemini-gui-pending-query-ui-http-qa-2119.patch` (`99501be0...`) complements it on compiled `HttpPopup` over `/events` + `/actions` XHR by additionally covering `jump:open:*`, `unpin:*`, `pin-left:*`, `pin-right:*`, `control:page-previous`, `control:acknowledge`, empty prior status (`''`), and `files` mode (`control:files-path`).

---

## 7. Remaining Original `ELM-UI-005` Obligations (Honest Boundary)

Neither `47e7599f...`, `99501be0...`, `e505cc14...`, nor `fb22ac23...` closes original `ELM-UI-005` (`initial`, `loading`, `no-match`, `unavailable`, `refused`, and accepted-query/catalog-generation correlation):
- Native physical guest/host observation correlating accepted controller query + catalog generation with visible rendered results (`search-no-match` / live query refresh), real WebKit/compositor IME preedit & caret geometry, assistive-technology speech/focus verification, `HOST-STOP-2` / preview provider (`False`/`False`, `nativeOps: []`), and independent readiness/acceptance review remain separate open obligations owned and serialized by Root.
