-- ROOT ONLY, UNEXECUTED. QA-only exception hooks enter the actual Owner's
-- CallbackGate functions. They simulate synchronous publication faults; they
-- do not establish a real clock failure, worker cleanup, or native behavior.
-- Root must retain each Probe in the same live QA host until disposition.
module GatePublicationFaultControls
 (Probe, newProbe, runPriorContainmentFault, runPreHandoffFault,
  runNewContainmentFault, runStopBeforeMintFault, runStopAfterNotifyFault,
  runPositive) where

import Control.Exception (IOException, try)
import Control.Monad (unless, when)
import Data.IORef
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent (PersistentOwner, newPersistentOwner)
import Warlock.Capture.Process.Persistent.Internal
 (QaContainment(..), QaGateSnapshot(..), qaGateSnapshot, qaContainmentStep,
  qaExplicitStopStep, qaTryCallback)

type Seen = Maybe (Either ToolError AdmissionDeadline)
data Probe = Probe PersistentOwner (IORef Seen) (IORef Bool)
newProbe :: IO Probe
newProbe = Probe <$> newPersistentOwner <*> newIORef Nothing <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("gate publication: " ++ label)))
noHook :: String -> Seen -> IO ()
noHook _ _ = pure ()
failAt :: IORef Seen -> String -> String -> Seen -> IO ()
failAt ref target stage observed = when (stage == target) $ do
 writeIORef ref observed
 ioError (userError ("QA injected " ++ target))
start :: Probe -> IO ()
start (Probe _ _ used) = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single-use Probe" fresh
snapshot :: PersistentOwner -> IO QaGateSnapshot
snapshot owner = qaGateSnapshot owner >>= maybe (ioError (userError "gate busy: retain Unknown")) pure
fault :: IO a -> IO ()
fault action = do
 result <- try (action >> pure ()) :: IO (Either IOException ())
 check "injected exception propagated" (case result of Left _ -> True; _ -> False)
checkDenied :: PersistentOwner -> IO ()
checkDenied owner = do
 allowed <- qaTryCallback owner
 check "closed actual gate denies callback entry" (not allowed)
checkNoContainmentRetry :: PersistentOwner -> IO ()
checkNoContainmentRetry owner = do
 (hadStop,result) <- qaContainmentStep owner noHook 1000000
 check "unknown containment cannot mint a new deadline" (not hadStop && result == Left SpawnOrIO)

runPriorContainmentFault :: Probe -> IO ()
runPriorContainmentFault p@(Probe owner seen _) = do
 start p
 (_,selected) <- qaContainmentStep owner noHook 1000000
 original <- case selected of Right d -> pure d; _ -> ioError (userError "initial containment unavailable")
 fault (qaContainmentStep owner (failAt seen "containment-after-notify") 1000000)
 captured <- readIORef seen
 state <- snapshot owner
 check "prior exact containment retained after notification fault" $
  captured == Just (Right original) && state == QaGateSnapshot True Nothing False (QaUnknown (Just (Right original))) True True
 checkDenied owner
 checkNoContainmentRetry owner

runPreHandoffFault :: Probe -> IO ()
runPreHandoffFault p@(Probe owner seen _) = do
 start p
 fault (qaContainmentStep owner (failAt seen "containment-before-handoff") 1000000)
 captured <- readIORef seen
 state <- snapshot owner
 check "unhanded local clock value is not published as a receipt" $
  (case captured of Just (Right _) -> True; _ -> False) && state == QaGateSnapshot True Nothing False (QaUnknown Nothing) False False
 checkDenied owner
 checkNoContainmentRetry owner

runNewContainmentFault :: Probe -> IO ()
runNewContainmentFault p@(Probe owner seen _) = do
 start p
 fault (qaContainmentStep owner (failAt seen "containment-after-notify") 1000000)
 captured <- readIORef seen
 state <- snapshot owner
 check "new handed-off result retained across notification failure" $
  case captured of Just (Right d) -> state == QaGateSnapshot True Nothing False (QaUnknown (Just (Right d))) True True; _ -> False
 checkDenied owner
 checkNoContainmentRetry owner

runStopBeforeMintFault :: Probe -> IO ()
runStopBeforeMintFault p@(Probe owner seen _) = do
 start p
 fault (qaExplicitStopStep owner (failAt seen "stop-before-mint") 1000000)
 state <- snapshot owner
 check "no observed stop deadline is a sticky failed marker" $
  state == QaGateSnapshot True (Just (Left SpawnOrIO)) True QaUnselected False False
 checkDenied owner
 (already,result) <- qaExplicitStopStep owner noHook 1000000
 check "duplicate stop does not mint a new deadline" (already && result == Left SpawnOrIO)

runStopAfterNotifyFault :: Probe -> IO ()
runStopAfterNotifyFault p@(Probe owner seen _) = do
 start p
 fault (qaExplicitStopStep owner (failAt seen "stop-after-notify") 1000000)
 captured <- readIORef seen
 state <- snapshot owner
 original <- case captured of Just (Right d) -> pure d; _ -> ioError (userError "no selected StopD")
 check "exact selected stop retained even though exception rethrows" $
  state == QaGateSnapshot True (Just (Right original)) True QaUnselected True True
 checkDenied owner
 (already,result) <- qaExplicitStopStep owner noHook 1000000
 check "duplicate stop reuses exact first deadline" (already && result == Right original)

runPositive :: Probe -> IO ()
runPositive p@(Probe owner _ _) = do
 start p
 (hadStop,selected) <- qaContainmentStep owner noHook 1000000
 own <- case selected of Right d -> pure d; _ -> ioError (userError "positive containment unavailable")
 state <- snapshot owner
 check "successful containment retains the actual first result" $
  not hadStop && state == QaGateSnapshot True Nothing False (QaKnown (Right own)) True True
 checkDenied owner
 (already,stopResult) <- qaExplicitStopStep owner noHook 1000000
 check "first explicit stop after containment mints once" $
  not already && case stopResult of Right _ -> True; _ -> False
