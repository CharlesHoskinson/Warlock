-- ROOT-ONLY source fixture; NOT EXECUTED. Requires isolated held-document
-- borrow-qa flag, v15 held source, opaque-release patch, and existing
-- qaHoldHeldGate/qaForceHeldUnknown/qaHeldBorrowCount CPP-only seams. The
-- caller must retain each Probe, supplier acquisition, and independent guardian
-- through success, timeout, exception, and Unknown. No process/native claim.
module HeldOpaqueReleaseControls (Probe, newProbe, runBusyThenRelease, runUnknown) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Platform.Executable
 (HeldExecutable, HeldBorrow, LeaseError(..), borrowHeldWhile, tryReleaseHeld, releaseHeldBorrow, retireHeld,
  qaHoldHeldGate, qaForceHeldUnknown, qaHeldBorrowCount)

data Probe = Probe
 { held :: IORef (Maybe HeldExecutable), attempt :: IORef (Maybe HeldBorrow)
 , blockingRelease :: IORef (Maybe (IO Bool)), worker :: IORef (Maybe ThreadId)
 , entered :: MVar (), unlock :: MVar (), done :: MVar (Either SomeException ())
 , used :: IORef Bool }
newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("held-release: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 3000000 action >>= maybe (ioError (userError (label ++ ": retain Probe and guardian"))) pure

data Acquisition = Acquisition HeldExecutable HeldBorrow (IO Bool)
acquire :: Probe -> IO HeldExecutable -> IO Acquisition
acquire p supply = mask $ \restore -> do
 wasUsed <- atomicModifyIORef' (used p) (\value -> (True,value))
 check "single-use probe" (not wasUsed)
 cap <- restore supply
 writeIORef (held p) (Just cap)
 result <- borrowHeldWhile cap (pure False) (pure ())
 case result of
  Just (Right (_, releaseNow, _, releaseCapability)) -> do
   writeIORef (blockingRelease p) (Just releaseNow)
   writeIORef (attempt p) (Just releaseCapability)
   pure (Acquisition cap releaseCapability releaseNow)
  _ -> ioError (userError "expected real held borrow")

runBusyThenRelease :: Probe -> IO HeldExecutable -> IO ()
runBusyThenRelease p supply = mask $ \restore -> do
 let finish = do
      void (tryPutMVar (unlock p) ())
      tid <- readIORef (worker p)
      case tid of Nothing -> pure (); Just _ -> void (timeout 2000000 (readMVar (done p)))
     run = do
      Acquisition cap releaseCapability releaseNow <- acquire p supply
      count0 <- qaHeldBorrowCount cap
      check "one real retained borrow" (count0 == Just 1)
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldHeldGate cap (putMVar (entered p) ()) (readMVar (unlock p)))) (putMVar (done p))
       writeIORef (worker p) (Just tid)
       pure tid
      within "actual held gate occupied" (readMVar (entered p))
      busy <- within "try release returns while gate remains held" (tryReleaseHeld releaseCapability)
      check "busy yields definite no-commit" (busy == Nothing)
      void (tryPutMVar (unlock p) ())
      ended <- within "holder completes" (readMVar (done p))
      check "holder returned" (case ended of Right () -> True; _ -> False)
      count1 <- qaHeldBorrowCount cap
      check "busy did not decrement" (count1 == Just 1)
      first <- tryReleaseHeld releaseCapability
      count2 <- qaHeldBorrowCount cap
      second <- tryReleaseHeld releaseCapability
      legacy <- releaseNow
      releaseHeldBorrow releaseCapability
      count3 <- qaHeldBorrowCount cap
      check "one shared release, stable across APIs" $
       first == Just True && second == Just True && legacy && count2 == Just 0 && count3 == Just 0
      closed <- retireHeld cap
      check "retire only after known release" (closed == Right ())
 restore run `finally` finish

runUnknown :: Probe -> IO HeldExecutable -> IO ()
runUnknown p supply = mask $ \restore -> restore $ do
 Acquisition cap releaseCapability releaseNow <- acquire p supply
 count0 <- qaHeldBorrowCount cap
 check "one retained borrow before injected fault" (count0 == Just 1)
 qaForceHeldUnknown cap
 unknown <- tryReleaseHeld releaseCapability
 again <- tryReleaseHeld releaseCapability
 legacy <- releaseNow
 closed <- retireHeld cap
 check "unknown remains sticky, no successful release or close" $
  unknown == Just False && again == Just False && not legacy && closed == Left LeaseCloseUncertain
