-- ROOT-ONLY QA source proposal. No compiler or test execution here.
-- Root must strongly root each distinct FixtureGuard and InterruptProbe BEFORE
-- invoking a case. Cases never spawn a child. They exercise actual withRoot
-- exceptional unwinding after held publication; they do not inject closeFd
-- failure or establish root-close, process, event-manager or reap receipts.
module TerraGraphRetainedFixtureFaultControls0028
 (InterruptProbe, CallbackObservation(..), newInterruptProbe, callbackObservation, runPostIssuedIOException, runPostIssuedAsync) where

import Control.Concurrent (ThreadId, forkFinally, killThread)
import Control.Concurrent.MVar (MVar, newEmptyMVar, putMVar, readMVar, takeMVar, tryPutMVar)
import Control.Exception (AsyncException(..), IOException, SomeException, finally, fromException, mask, mask_, try)
import Control.Monad (unless, void)
import Data.IORef (IORef, atomicModifyIORef', newIORef, readIORef, writeIORef)
import System.Timeout (timeout)
import TerraGraphRetainedFixture0026
 (FixtureDisposition(..), FixtureGuard, fixtureDisposition, validatedRetainedFixtureWithHook)
import Warlock.Platform.Executable (HeldExecutable)

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("retained fixture fault: " ++ label)))

within :: String -> IO a -> IO a
within label action = do
 r <- timeout 3000000 action
 maybe (ioError (userError (label ++ " watchdog; retain guard/probe"))) pure r

-- A fault in a QA hook occurs after actual held publication and while inside
-- withRoot. Root retains this single-use guard even though the call fails.
runPostIssuedIOException :: FixtureGuard -> FilePath -> FilePath -> IO ()
runPostIssuedIOException guard rootDir name = do
 outcome <- try (validatedRetainedFixtureWithHook guard rootDir name
  (ioError (userError "fixture-post-issued-io"))) :: IO (Either IOException HeldExecutable)
 disposition <- fixtureDisposition guard
 check "IOException propagated after held publication" $
  case outcome of Left _ -> disposition == GuardHasHeld; Right _ -> False

-- Completion of a forkFinally callback is not a thread join or cleanup proof.
-- The externally rooted Probe keeps the exact guard and worker identity on
-- every outcome. CallbackUnknown is sticky finalizer evidence for Root, not
-- a completion or thread join. It never closes or hands out the held capability.
data CallbackObservation = WorkerNotStarted | CallbackObserved | CallbackUnknown
 deriving (Eq, Show)
data InterruptProbe = InterruptProbe FixtureGuard (IORef (Maybe ThreadId))
 (IORef CallbackObservation) (IORef Bool) (MVar ()) (MVar ()) (MVar (Either SomeException HeldExecutable))

callbackObservation :: InterruptProbe -> IO CallbackObservation
callbackObservation (InterruptProbe _ _ observation _ _ _ _) = readIORef observation

newInterruptProbe :: FixtureGuard -> IO InterruptProbe
newInterruptProbe guard = InterruptProbe guard <$> newIORef Nothing <*> newIORef WorkerNotStarted <*> newIORef False
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar

runPostIssuedAsync :: InterruptProbe -> FilePath -> FilePath -> IO ()
runPostIssuedAsync (InterruptProbe guard workerRef observation used entered release done) rootDir name = mask $ \restore -> do
 already <- atomicModifyIORef' used (\x -> (True,x))
 check "one-shot interrupt probe" (not already)
 let hook = putMVar entered () >> takeMVar release
     finish = do
      void (tryPutMVar release ())
      worker <- readIORef workerRef
      case worker of
       Nothing -> writeIORef observation WorkerNotStarted
       Just _ -> do
        observed <- timeout 3000000 (readMVar done)
        writeIORef observation $ case observed of
         Nothing -> CallbackUnknown
         Just _ -> CallbackObserved
     run = do
      tid <- mask_ $ do
       worker <- forkFinally
        (restore (validatedRetainedFixtureWithHook guard rootDir name hook))
        (putMVar done)
       writeIORef workerRef (Just worker)
       pure worker
      within "post-issued hook entered" (readMVar entered)
      -- Target is in an interruptible test-owned barrier; timeout is a fixture
      -- watchdog, not a product deadline. No retry if delivery is uncertain.
      within "async delivery" (killThread tid)
      outcome <- within "supplier completion callback" (readMVar done)
      disposition <- fixtureDisposition guard
      check "actual async interruption preserves held capability" $
       case outcome of
        Left e -> (fromException e :: Maybe AsyncException) == Just ThreadKilled
                    && disposition == GuardHasHeld
        Right _ -> False
 restore run `finally` finish
