#!/usr/bin/env python3
"""PREPARATION ONLY: root-reviewed guest build/observation controller; NOT RUN.

Root-only interface (separate invocations):
  python3 -B engine-vm-trial.py build /absolute/reviewed-config.json
  python3 -B engine-vm-trial.py trial /absolute/reviewed-config.json
Config is reviewed per frozen source cut, stored outside the checkout. Required:
  evidence_dir: fresh absolute path outside repo; parent must already exist
  source_root: absolute staged source tree; source_manifest: absolute JSON
  source_manifest_sha256: digest of the exact reviewed manifest
  gate_receipt: absolute frozen gate receipt; gate_receipt_sha256: digest
  build_steps: [{argv:[...], cwd:absolute, timeout_seconds:positive}, ...]
  artifacts: [{path:absolute, sha256:hex}, ...] (includes binaries, DSOs, 3 HTML)
  guest_manifest: absolute existing mvp-guest-manifest.json (trial only)
  ui_config: absolute reviewed ui.json with the same original deadline
  backend_config: absolute reviewed backend.json with that same deadline
  backend_argv: absolute backend executable plus reviewed config arguments
  foot: [{pid:int, birth:str}, ...] (fresh root observation; nonempty)
  engine_exe: expected real executable path for actual mapped engine PID
Build records exact steps/logs and checks hashes; reviewed steps must use root's
protected resource/custody wrapper. A timeout leaves descendant cleanup unknown.
Trial consumes the original
manifest deadline; it NEVER generates/resets a deadline, sends keyboard/mouse
input, stops a scope, or declares acceptance. It restores the captured idle
enabled state if it drifted, records the action, and flags other idle changes.
Root must use the
protected launcher/gates and separately handle scope cleanup and any reviewed
QMP actions. This is a QA draft, not production Python or a native campaign.
"""
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import time
import uuid
from pathlib import Path

REPO = Path('/home/charl/code/Warlock')
CGROOT = Path('/sys/fs/cgroup')


class PreservationViolation(Exception):
    pass


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def absolute(value):
    path = Path(value)
    need(path.is_absolute(), 'absolute path required')
    need('check_auth_cpu.py' not in path.parts, 'foreign tool excluded')
    return path


def sha(path):
    digest = hashlib.sha256()
    with absolute(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def checked_file(path, expected):
    need(re.fullmatch(r'[0-9a-f]{64}', expected) is not None, 'invalid digest')
    need(sha(path) == expected, 'hash mismatch: ' + str(path))


def command(argv, timeout, env=None):
    need(isinstance(argv, list) and bool(argv) and all(isinstance(x, str) for x in argv), 'bad argv')
    if env is None:
        env = dict(os.environ, OMARCHY_PATH='/usr/share/omarchy', LANG='C.UTF-8', LC_ALL='C.UTF-8')
        env.pop('DISPLAY', None)
        env.pop('XAUTHORITY', None)
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=timeout, check=False, env=env)


def observation(argv, timeout):
    result = command(argv, timeout)
    need(result.returncode == 0, 'query failed: ' + argv[0])
    return result.stdout.decode('utf-8', errors='strict')


def proc(pid):
    p = Path('/proc') / str(int(pid))
    st = (p / 'stat').read_text()
    fields = st[st.rfind(')') + 2:].split()
    need(len(fields) > 19, 'short proc stat')
    status = (p / 'status').read_text().splitlines()
    namespaces = [line.split()[1:] for line in status if line.startswith('NSpid:')]
    need(len(namespaces) == 1 and namespaces[0], 'unknown namespace PID')
    return {'pid': int(pid), 'birth': fields[19], 'uid': p.stat().st_uid,
            'namespacePids': [int(value) for value in namespaces[0]]}


def scope_members(unit):
    need(re.fullmatch(r'warlock-engine-[0-9a-f]{32}\.scope', unit) is not None, 'invalid scope')
    group = observation(['systemctl', '--user', 'show', unit, '--property=ControlGroup', '--value'], 2).strip()
    need(group.startswith('/') and group != '/', 'unknown scope cgroup')
    root = (CGROOT / group.lstrip('/')).resolve(strict=True)
    need(root.is_relative_to(CGROOT) and root != CGROOT, 'invalid cgroup')
    def walk_error(exc):
        raise exc
    paths = [Path(directory) / 'cgroup.procs'
             for directory, _, _ in os.walk(root, onerror=walk_error, followlinks=False)]
    need(bool(paths), 'no cgroup membership files')
    pids = {int(item) for path in paths for item in path.read_text().split()}
    return group, [proc(pid) for pid in sorted(pids)]


def clients():
    data = json.loads(observation(['hyprctl', 'clients', '-j'], 2))
    need(isinstance(data, list), 'unknown client list')
    return data


def idle():
    value = json.loads(observation(['omarchy-shell', 'idle', 'status'], 2))
    need(type(value.get('enabled')) is bool, 'unknown idle state')
    need(type(value.get('stayAwake')) is bool, 'unknown stay-awake state')
    return value


def preserved_foot(expected):
    need(isinstance(expected, list) and expected, 'fresh Foot identity required')
    result = []
    for item in expected:
        current = proc(item['pid'])
        need(current['birth'] == str(item['birth']), 'Foot PID changed')
        current['exe'] = os.readlink('/proc/%d/exe' % current['pid'])
        need(Path(current['exe']).name.lower().startswith('foot'), 'Foot executable changed')
        result.append(current)
    return result


def fresh_evidence(config):
    dest = absolute(config['evidence_dir'])
    need(not dest.exists() and dest.parent.resolve(strict=True).is_dir(), 'evidence dir must be fresh')
    need(not dest.parent.resolve().is_relative_to(REPO.resolve()), 'raw evidence must be outside repo')
    dest.mkdir(mode=0o700)
    return dest


def save(out, name, value):
    with (out / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def check_inputs(config):
    checked_file(config['source_manifest'], config['source_manifest_sha256'])
    checked_file(config['gate_receipt'], config['gate_receipt_sha256'])
    manifest = json.loads(absolute(config['source_manifest']).read_text())
    files = manifest['files']
    need(isinstance(files, list) and files, 'source manifest has no files')
    root = absolute(config['source_root']).resolve(strict=True)
    for item in files:
        need(item.get('present') is True, 'source absent')
        need('check_auth_cpu.py' not in Path(item['path']).parts, 'foreign tool excluded')
        source = (root / item['path']).resolve(strict=True)
        need(source.is_relative_to(root), 'source outside staged root')
        checked_file(source, item['sha256'])


def check_artifacts(config):
    items = config['artifacts']
    need(isinstance(items, list) and len(items) >= 4, 'incomplete artifact inventory')
    for item in items:
        checked_file(item['path'], item['sha256'])


def build(config, out):
    check_inputs(config)
    steps = config['build_steps']
    need(isinstance(steps, list) and steps, 'no reviewed build steps')
    records = []
    for i, step in enumerate(steps):
        argv = step['argv']
        need(isinstance(argv, list) and argv and all(isinstance(v, str) for v in argv), 'bad build argv')
        need(all('check_auth_cpu.py' not in v for v in argv), 'foreign tool excluded')
        cwd = absolute(step['cwd']).resolve(strict=True)
        need(cwd.is_relative_to(absolute(config['source_root']).resolve(strict=True)), 'build cwd outside stage')
        seconds = int(step['timeout_seconds'])
        need(0 < seconds <= 1800, 'invalid build timeout')
        status = {'argv': argv, 'cwd': str(cwd), 'exit': None, 'timeout': False}
        with (out / ('build-%02d.stdout' % i)).open('xb') as stdout, \
             (out / ('build-%02d.stderr' % i)).open('xb') as stderr:
            try:
                result = subprocess.run(argv, cwd=cwd, stdin=subprocess.DEVNULL,
                                        stdout=stdout, stderr=stderr,
                                        timeout=seconds, check=False)
                status['exit'] = result.returncode
            except subprocess.TimeoutExpired:
                status['timeout'] = True
                status['descendantCleanup'] = 'unknown; root must inspect owned build scope'
        save(out, 'build-%02d-status.json' % i, status)
        records.append(status)
        need(not status['timeout'] and status['exit'] == 0, 'build step failed or timed out')
    check_inputs(config)
    check_artifacts(config)
    save(out, 'build-record.json', {'steps': records, 'artifacts': config['artifacts'],
                                    'acceptance': False})


def trial(config, out):
    check_inputs(config)
    check_artifacts(config)
    manifest = json.loads(absolute(config['guest_manifest']).read_text())
    deadline = int(manifest['deadlineMonotonicNs'])
    ui = json.loads(absolute(config['ui_config']).read_text())
    need(int(ui['deadlineMonotonicNs']) == deadline, 'UI deadline differs from manifest')
    backend_config = absolute(config['backend_config']).resolve(strict=True)
    backend = json.loads(backend_config.read_text())
    need(int(backend['deadlineMonotonicNs']) == deadline, 'backend deadline differs from manifest')
    need(backend.get('applicationAttachment') is True, 'application-only attachment not configured')
    need(backend.get('nativeOperations', []) == [], 'unexpected native operations')
    documents = ui['documents']
    need(set(documents) == {'controller', 'bar', 'popup'}, 'unexpected document roles')
    artifact_hashes = {str(absolute(item['path']).resolve(strict=True)): item['sha256']
                       for item in config['artifacts']}
    for document in documents.values():
        document_path = str(absolute(document['path']).resolve(strict=True))
        need(artifact_hashes.get(document_path) == document['sha256'], 'document absent from artifact inventory')
        checked_file(document_path, document['sha256'])
    now = time.monotonic_ns()
    need(0 < deadline - now <= 28_000_000_000, 'original 28s deadline missing or expired')
    need(observation(['omarchy-shell', 'lock', 'isLocked'], 2).strip() == 'false', 'locked or unknown session')
    before_idle = idle()
    foot_before = preserved_foot(config['foot'])
    before_clients = clients()
    unit = 'warlock-engine-' + uuid.uuid4().hex + '.scope'
    args = config['backend_argv']
    need(isinstance(args, list) and args and all(isinstance(x, str) for x in args), 'bad backend argv')
    need(len(args) == 2 and absolute(args[1]).resolve(strict=True) == backend_config, 'unexpected backend arguments')
    need(absolute(args[0]).resolve(strict=True) in [absolute(x['path']).resolve(strict=True) for x in config['artifacts']], 'backend not pinned')
    engine_exe = absolute(config['engine_exe']).resolve(strict=True)
    need(str(engine_exe) in artifact_hashes, 'engine not pinned')
    engine_stat = engine_exe.stat()
    engine_identity = (engine_stat.st_dev, engine_stat.st_ino)
    env = dict(os.environ, OMARCHY_PATH='/usr/share/omarchy', LANG='C.UTF-8', LC_ALL='C.UTF-8', GDK_BACKEND='wayland')
    env.pop('DISPLAY', None)
    env.pop('XAUTHORITY', None)
    need(os.getuid() != 0 and os.getuid() == os.geteuid(), 'unexpected UI identity')
    for ancestor in (Path('/run'), Path('/run/user')):
        ancestor_stat = ancestor.lstat()
        need(stat.S_ISDIR(ancestor_stat.st_mode) and ancestor_stat.st_uid in (0, os.getuid())
             and stat.S_IMODE(ancestor_stat.st_mode) & 0o022 == 0, 'unsafe runtime ancestor')
    runtime_dir = Path('/run/user') / str(os.getuid())
    need(env.get('XDG_RUNTIME_DIR') == str(runtime_dir), 'unexpected Wayland runtime directory')
    runtime_stat = runtime_dir.lstat()
    need(stat.S_ISDIR(runtime_stat.st_mode) and runtime_stat.st_uid == os.getuid()
         and stat.S_IMODE(runtime_stat.st_mode) == 0o700,
         'Wayland runtime directory owner or mode mismatch')
    display = env.get('WAYLAND_DISPLAY', '')
    need(len(display) <= 64 and re.fullmatch(r'wayland-[A-Za-z0-9_-]+', display) is not None,
         'invalid Wayland display')
    socket_stat = (runtime_dir / display).lstat()
    need(stat.S_ISSOCK(socket_stat.st_mode) and socket_stat.st_uid == os.getuid(),
         'Wayland display socket owner or type mismatch')
    prlimit = Path('/usr/bin/prlimit').resolve(strict=True)
    need(str(prlimit) in artifact_hashes, 'prlimit not pinned in artifact inventory')
    save(out, 'before.json', {'idle': before_idle, 'foot': foot_before, 'clients': before_clients,
                              'unit': unit, 'deadlineMonotonicNs': str(deadline), 'inputEnabled': False})
    launcher = None
    rows = []
    seen = set()
    error = None
    with (out / 'backend.stdout').open('xb') as stdout, (out / 'backend.stderr').open('xb') as stderr:
        try:
            need(time.monotonic_ns() < deadline, 'deadline elapsed before launch')
            launcher = subprocess.Popen(['systemd-run', '--user', '--scope', '--quiet', '--unit=' + unit,
                                         '--property=MemoryMax=2G', '--', str(prlimit), '--core=1:1', '--', *args], stdin=subprocess.DEVNULL,
                                        stdout=stdout, stderr=stderr, env=env, start_new_session=True)
            while launcher.poll() is None and time.monotonic_ns() < deadline:
                try:
                    group, members = scope_members(unit)
                    seen.update((member['pid'], member['birth']) for member in members)
                    by_pid = {v['pid']: v for v in members}
                    if set(by_pid).intersection(v['pid'] for v in foot_before):
                        raise PreservationViolation('Foot entered scope')
                    mapped = []
                    for client in clients():
                        pid = client.get('pid')
                        if (pid in by_pid and client.get('mapped') and by_pid[pid]['uid'] == os.getuid()
                                and by_pid[pid]['namespacePids'][-1] == 1):
                            exe_stat = os.stat('/proc/%d/exe' % pid)
                            if (exe_stat.st_dev, exe_stat.st_ino) != engine_identity:
                                continue
                            first = by_pid[pid]
                            again_group, again = scope_members(unit)
                            if again_group == group and any(x['pid'] == pid and x['birth'] == first['birth'] for x in again):
                                mapped.append({'client': client, 'process': first})
                    now = time.monotonic_ns()
                    if now < deadline:
                        rows.append({'atMonotonicNs': str(now), 'group': group,
                                     'members': members, 'ownedEngineWindows': mapped})
                except (OSError, ValueError, subprocess.SubprocessError, RuntimeError) as exc:
                    rows.append({'atMonotonicNs': str(time.monotonic_ns()), 'known': False,
                                 'error': type(exc).__name__ + ': ' + str(exc)})
                time.sleep(min(.2, max(0, (deadline - time.monotonic_ns()) / 1e9)))
        except Exception as exc:
            error = type(exc).__name__ + ': ' + str(exc)
    try:
        group, after_members = scope_members(unit)
        scope_after = {'known': True, 'group': group, 'members': after_members}
    except Exception as exc:
        scope_after = {'known': False, 'error': type(exc).__name__ + ': ' + str(exc)}
    # Supplemental observations aid root review; they do not prove a complete
    # descendant census or turn a missing transient cgroup into clean exit.
    try:
        scope_after['systemdState'] = observation(
            ['systemctl', '--user', 'show', unit, '--property=LoadState',
             '--property=ActiveState', '--property=SubState', '--property=ControlGroup', '--property=Result'], 2)
    except Exception as exc:
        scope_after['systemdStateError'] = type(exc).__name__ + ': ' + str(exc)
    identities = []
    for pid, birth in sorted(seen):
        try:
            current = proc(pid)
            state = 'same-incarnation' if current['birth'] == birth else 'reused-pid'
        except FileNotFoundError:
            state = 'absent'
        except Exception:
            state = 'unknown'
        identities.append({'pid': pid, 'birth': birth, 'state': state})
    scope_after['observedIdentities'] = identities
    foot_after = None
    foot_error = None
    try:
        foot_after = preserved_foot(config['foot'])
    except Exception as exc:
        foot_error = type(exc).__name__ + ': ' + str(exc)
    try:
        idle_after = idle()
        restore = None
        if idle_after['enabled'] != before_idle['enabled']:
            action = 'enable' if before_idle['enabled'] else 'disable'
            result = command(['omarchy-shell', 'idle', action], 2)
            restore = {'action': action, 'exit': result.returncode,
                       'stderr': result.stderr.decode('utf-8', errors='replace')}
            idle_after = idle()
        preservation = {'known': foot_error is None, 'foot': foot_after, 'footError': foot_error, 'idle': idle_after,
                        'idleRestore': restore,
                        'idleEnabledUnchanged': idle_after['enabled'] == before_idle['enabled'],
                        'stayAwakeUnchanged': idle_after.get('stayAwake') == before_idle.get('stayAwake')}
    except Exception as exc:
        preservation = {'known': False, 'error': type(exc).__name__ + ': ' + str(exc)}
    save(out, 'trial-result.json', {'unit': unit, 'deadlineMonotonicNs': str(deadline),
         'launcherPID': launcher.pid if launcher else None,
         'launcherExit': launcher.poll() if launcher else None, 'error': error,
         'observations': rows, 'scopeAfter': scope_after, 'preservation': preservation,
         'forcedCleanup': False, 'inputSent': False, 'nativeAccepted': False, 'releaseAccepted': False,
         'cleanupNote': 'No scope stop attempted; root must investigate unknown/live owned members.'})
    need(error is None and preservation.get('known') and preservation.get('idleEnabledUnchanged')
         and preservation.get('stayAwakeUnchanged')
         and (preservation.get('idleRestore') is None or preservation['idleRestore']['exit'] == 0),
         'trial or preservation unknown')
    need(scope_after.get('known') and not scope_after['members'], 'scope cleanup unqualified')


def main():
    need(len(sys.argv) == 3 and sys.argv[1] in ('build', 'trial'), 'usage: engine-vm-trial.py build|trial /absolute/config.json')
    path = absolute(sys.argv[2])
    config = json.loads(path.read_text())
    out = fresh_evidence(config)
    save(out, 'controller-input.json', {'configSHA256': sha(path), 'mode': sys.argv[1],
                                      'preparationOnly': True, 'nativeAccepted': False})
    if sys.argv[1] == 'build':
        build(config, out)
    else:
        trial(config, out)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        sys.exit(1)
