{-# LANGUAGE OverloadedStrings #-}
-- Root-only unexecuted controls for outbound-pin-followup.patch, after 74b.
-- Real AF_UNIX sends, test-only local deadline + hook. No selected child,
-- provider, native operation, peer receipt or original-scenario acceptance.
-- Registry is process-local: on standalone exit the OS disposes descriptors;
-- Root must embed these cases in a retained owner process for custody claims.
module Main (main) where

import Control.Concurrent (ThreadId, forkFinally)
import Control.Concurrent.MVar (MVar, newEmptyMVar, putMVar, readMVar, tryPutMVar)
import Control.Exception (SomeException, finally, mask, mask_, try)
import Control.Monad (unless, void)
import qualified Data.ByteString as B
import Data.IORef
import GHC.Clock (getMonotonicTimeNSec)
import qualified Network.Socket as S
import qualified Network.Socket.ByteString as N
import System.Timeout (timeout)
import Warlock.Protocol.Ingress.Internal
import qualified Warlock.Protocol.Framing as Framing

data Retained = Retained (IORef (Maybe CredentialIngress)) (IORef (Maybe (S.Socket,S.Socket)))
                         (IORef (Maybe ThreadId)) (IORef (Maybe (MVar (Either SomeException PersistentSendResult))))
type Registry = IORef [Retained]
data Fixture = Fixture CredentialIngress S.Socket (IORef (Maybe ThreadId)) (IORef (Maybe (MVar (Either SomeException PersistentSendResult))))

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 2000000 action >>= maybe (ioError (userError label)) pure
future :: Integer -> IO Integer
future delta = (+ delta) . toInteger <$> getMonotonicTimeNSec
must :: Show e => Either e a -> IO a
must = either (ioError . userError . show) pure

fixture :: Registry -> IO Fixture
fixture registry = mask_ $ do
  owner <- newIORef Nothing
  sockets <- newIORef Nothing
  worker <- newIORef Nothing
  completion <- newIORef Nothing
  atomicModifyIORef' registry (\xs -> (Retained owner sockets worker completion : xs,()))
  binding <- must (ingressBinding "1" "2" "3")
  ingress <- newDesktopCredentialIngress binding FromElm (\_ -> pure ()) (\_ -> pure ())
  writeIORef owner (Just ingress)
  (owned,peer) <- S.socketPair S.AF_UNIX S.Stream S.defaultProtocol
  writeIORef sockets (Just (owned,peer))
  offered <- transferCredentialSocket ingress owned
  check "offered" (offered == OfferAccepted)
  active <- activateCredentialIngress ingress
  check "activated" (active == ActivationLive)
  pure (Fixture ingress peer worker completion)

payload :: B.ByteString
payload = "{\"bridgeProtocol\":1,\"kind\":\"native-event\",\"payload\":{\"protocolVersion\":3,\"kind\":\"application-attached\",\"binding\":{\"lifetime\":\"1\",\"session\":\"2\",\"frontend\":\"3\"},\"nativeOperations\":[]}}"
queue :: CredentialIngress -> IO ()
queue ingress = enqueueCredentialIngress ingress Control payload >>= check "queue" . (== Right ())
receiveExactly :: S.Socket -> Int -> IO B.ByteString
receiveExactly socket = go [] where
 go chunks 0 = pure (B.concat (reverse chunks))
 go chunks n = do
  part <- N.recv socket n
  if B.null part then ioError (userError "unexpected EOF")
   else go (part:chunks) (n-B.length part)

main :: IO ()
main = mask $ \restore -> do
 registry <- newIORef []
 -- Positive: one locally completed framed write, exact bytes at peer, and
 -- normal endpoint close. Peer bytes are a fixture observation, not an ACK.
 Fixture ok peerOk _ _ <- fixture registry
 queue ok
 deadlineOk <- future 1000000000
 sent <- restore (within "positive send" (sendPersistentCredentialIngress deadlineOk ok))
 expected <- must (Framing.desktopGatewayPrefix payload)
 actual <- restore (within "positive bytes" (receiveExactly peerOk (B.length expected)))
 check "local write plus exact peer bytes" (sent == WrittenLocally && actual == expected)
 retiredOk <- retireCredentialIngress ok
 check "positive endpoint closed" (endpoint retiredOk == Just EndpointConfirmed)
 S.close peerOk

 -- Expired original D refuses before any write; the framed queue stays present.
 Fixture expired peerExpired _ _ <- fixture registry
 queue expired
 past <- future (-1)
 refused <- restore (within "expired send" (sendPersistentCredentialIngress past expired))
 retained <- retainedCredentialIngressFrames expired
 readAny <- restore (timeout 30000 (N.recv peerExpired 1))
 check "expired is unsent" (refused == SendRefused TimedOut && length retained == 1 && readAny == Nothing)
 retiredExpired <- retireCredentialIngress expired
 check "expired endpoint closed" (endpoint retiredExpired == Just EndpointConfirmed)
 S.close peerExpired

 -- Controlled close against a pin before the send syscall. The hook is private
 -- QA-only. Retirement must leave EndpointUncertain, and upon release the send
 -- sees the closed channel before touching the socket. No partial-write claim.
 Fixture raced peerRaced worker completion <- fixture registry
 queue raced
 entered <- newEmptyMVar
 release <- newEmptyMVar
 done <- newEmptyMVar :: IO (MVar (Either SomeException PersistentSendResult))
 writeIORef completion (Just done)
 deadlineRace <- future 1500000000
 tid <- forkFinally
  (restore (sendPersistentCredentialIngressWithHook (putMVar entered () >> readMVar release) deadlineRace raced))
  (putMVar done)
 writeIORef worker (Just tid)
 let unblock = do
       void (tryPutMVar release ())
       void (timeout 2000000 (readMVar done))
     exercise = do
       within "send entered" (readMVar entered)
       closeResult <- within "raced retire" (retireCredentialIngress raced)
       check "raced close uncertain" (endpoint closeResult == Just EndpointUncertain)
       void (tryPutMVar release ())
       result <- within "raced send returned" (readMVar done)
       check "no send after close latch" (case result of Right (SendRefused Closed) -> True; _ -> False)
       peerSilence <- timeout 30000 (N.recv peerRaced 1)
       check "peer observed no bytes" (peerSilence == Nothing)
       still <- retainedCredentialIngressFrames raced
       check "raced frame retained" (length still == 1)
 restore exercise `finally` unblock
 -- An exception at the controlled pre-send hook is conservative Unknown:
 -- the Channel is poisoned before returning and the retained queue cannot be
 -- retried through either persistent send or a new owner status observation.
 Fixture fault peerFault _ _ <- fixture registry
 queue fault
 deadlineFault <- future 1000000000
 failed <- restore (within "hook failure" (sendPersistentCredentialIngressWithHook (ioError (userError "injected before syscall")) deadlineFault fault))
 retryResult <- restore (within "no resend" (sendPersistentCredentialIngress deadlineFault fault))
 untouched <- retainedCredentialIngressFrames fault
 noBytes <- restore (timeout 30000 (N.recv peerFault 1))
 check "failure unknown without replay" (failed == SendUnknown OutputUncertain && retryResult == SendRefused Closed && length untouched == 1 && noBytes == Nothing)
 -- A blocked hook consumes the same original D. The timeout outcome is Unknown
 -- and pins stay retained even though this controlled hook precedes syscall.
 Fixture stalled peerStalled _ _ <- fixture registry
 queue stalled
 hold <- newEmptyMVar
 shortD <- future 100000000
 timed <- restore (within "hook deadline" (sendPersistentCredentialIngressWithHook (readMVar hold) shortD stalled))
 repeated <- restore (within "timed no replay" (sendPersistentCredentialIngress shortD stalled))
 zero <- restore (timeout 30000 (N.recv peerStalled 1))
 check "one original D and no replay" (timed == SendUnknown OutputUncertain && repeated == SendRefused Closed && zero == Nothing)
 -- Actual full bytes reach the peer, then the private post-write hook throws
 -- before classification. Exception propagates to the owner as Unknown; the
 -- poisoned channel retains the frame and rejects replay. This is a full-write
 -- fault, not evidence of any particular partial-write schedule or peer ACK.
 Fixture wrote peerWrote _ _ <- fixture registry
 queue wrote
 deadlineWrote <- future 1000000000
 outcome <- try (restore (within "post-write fault" (sendPersistentCredentialIngressWithHooks (pure ()) (ioError (userError "injected after write")) deadlineWrote wrote))) :: IO (Either SomeException PersistentSendResult)
 visible <- restore (within "actual post-write bytes" (receiveExactly peerWrote (B.length expected)))
 retryWrote <- restore (within "post-write no replay" (sendPersistentCredentialIngress deadlineWrote wrote))
 kept <- retainedCredentialIngressFrames wrote
 check "visible bytes and no replay after fault" (case outcome of Left _ -> visible == expected && retryWrote == SendRefused Closed && length kept == 1; _ -> False)
 -- raced/fault/stalled/wrote owners and peers stay retained; no blind cleanup.
 holders <- readIORef registry
 check "all owner cells retained" (length holders == 6)
 putStrLn "outbound pin source controls completed"
