# Source, Engine-Phase & Accessibility / `600px` / `200%` Review of `HomepageCandidate.elm`

> **Scope & Honesty Notice (`engine-live-1504` Preparation Review)**
> - **Classification**: Read-only audit + surgical follow-up diff under `.warlock-contributor/engine-pid1-drafts/`. **Not** product source modification, compiler/model/VM execution, progress reset, or original-scenario / native / release acceptance (`nativeAccepted: false`, `releaseAccepted: false`).
> - **Untouched Candidate Rule**: Per Root instruction (*"Do not rewrite whole candidate repeatedly"*), `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/HomepageCandidate.elm` remains untouched at **`sha256:3770ea32ed1ee923c4219c75e2366beb68b068c6007085c4f771013cdd3fba29`** (`85,823` B, `1,949` L), and repository `site/*` files remain untouched (`SiteMain.elm` `f05a3768...`, `elm.json` `ffe9bc4f...`, `index.html` `2e5730d2...`).
> - **Surgical Follow-Up Diff**: Concrete semantic and contrast/cascade/`600px`/`200%` defects identified below are packaged as a `git apply --check`-verified unified patch in `/home/charl/code/Warlock/.warlock-contributor/engine-pid1-drafts/HomepageCandidateFollowup.diff` (`28,177` B, `370` L, **`sha256:3d245a20ee94781cd14430e50cdc33fd336fe586aead59f16c6ba54432d41787`**; expected post-apply candidate digest: **`sha256:97ab4cae214251199bb2f2e4c32300df8c25b323401b8cb91ce3440229e8e4ce`**, `90,021` B, `2,021` L).

---

## 1. Audited Baseline & Reference Evidence

| Input | Path / Record | Observed State / Digest |
| --- | --- | --- |
| Homepage Elm candidate | `.warlock-contributor/engine-pid1-drafts/HomepageCandidate.elm` | `85,823` B / `1,949` L · `sha256:3770ea32ed1ee923c4219c75e2366beb68b068c6007085c4f771013cdd3fba29` (untouched) |
| Frozen repo homepage source | `site/src/SiteMain.elm` | `68,121` B / `1,663` L · `sha256:f05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb` (untouched) |
| Shared website CSS cascade | `site/assets/shared/{layers,tokens,site,landing,effects}.css` | `@layer legacy, reset, tokens, base, layouts, components, states, effects, accessibility;` |
| Site accessibility contract | `site/foundations/accessibility/index.html` | Text `>= 4.5:1`, essential boundaries `>= 3.0:1`, `100`–`200%` root scale + `320px`/`600px` reflow, `6px` focus ring clearance, focus return on popup close, High-Contrast / forced-colors opaque with zero backdrop blur |
| Active slice declaration | `.warlock-contributor/engine-pid1.json` | `engine-pid1-ownership` (`ELM-ARC-002` / `ownership-presentation`); **no actual Warlock window yet**, `nativeOperations: []`; Root integrating owned early-fork engine |
| Latest Haskell component check | `.warlock-contributor/haskell-cpu-1793544641421564031/report.json` | **`passed: true`** across **all `8` Haskell/component suites** + **`197` prior model cases** (`nativeAccepted: false`, `releaseAccepted: false`) |
| Latest UI-engine Quint model check | `.warlock-contributor/haskell-cpu-1793545191214305889/report.json` | **`passed: false` retained** — `21` named tests PASS & `10,000` safety traces (`0` safety violations), **but `3` missing positive witnesses** (e.g. `ui-engine-rpc required broad witness zero for None`) |
| Owned early-fork engine drafts | `.warlock-contributor/engine-pid1-drafts/{EngineCustodyMerged.hsc,EngineCustodyParent.hs,EngineEntrypoint.hs,MvpLayout.patch}` | Early single-threaded `unshare(CLONE_NEWPID)` + `forkProcess` inside `Warlock.Ui.EngineCustody` (`Custody` / `waitid(P_PIDFD)` sole reaper) + `execveat(..., AT_EMPTY_PATH)` into `--engine-only` of the **same held ELF** |

---

## 2. Verified Passing Contracts in `HomepageCandidate.elm` (`3770ea32...`)

1. **Canonical Ledger & Agent-Census Discipline (`PASS`)**:
   - Preserves fixed historical **`15 / 242` whole requirements** and **`39 / 417` scenarios** (`ARC-024` capability branch historical/partial, whole `ELM-ARC-024` and `ELM-DEL-014` OPEN, stopped `ui-origin` history retained without reset, `HOSTSTOP2`, `NativeOps []`, and original monotonic deadlines `D`).
   - Contains **zero unverified live agent-census claims** (no mention of live worker counts or unverified process liveness).
2. **Drop-In `SiteMain` Compile & Asset Contract (`PASS`)**:
   - Exports the exact `SiteMain` symbol set required by `tools/check_haskell_cpu.py --site` (`tools/haskell_build.py:302`), uses only `site/elm.json` direct packages (`elm/browser`, `elm/core`, `elm/html`, `elm/json`), emits zero ports / zero new JavaScript, and resolves all `35` internal `#id` anchors and `43` `./` routes/assets to regular files under `site/`.
3. **Roving Tablist, Simulated Stage Disclosures & Core Text Contrast (`PASS`)**:
   - `viewWorkbenchTab` (`L1304-1334`) + `TabFocusSettled` (`L209-220`) preserve monotonic `tabFocusSeq` stale-result protection, `ArrowLeft`/`ArrowRight`/`ArrowUp`/`ArrowDown`/`Home`/`End` keyboard roving focus, and explicit `(simulated)` / `(simulated stage)` CTA labels.
   - Core Lacquer foreground/surface text pairs (`--wl-sys-color-text` and `--wl-sys-color-text-secondary` on `canvas`, `surface`, `surface-recessed`, and `surface-selected`, plus `--wl-sys-color-on-action` on `action-fill`) all exceed **`4.5:1`** across `Night`, `Dawn`, and `High-Contrast`.

---

## 3. Concrete Semantic & Engine-Phase Defects (`S1`–`S3`)

### `S1` (High) — Stale `7`-Suite Count & Undisclosed New Quint Profile `FAIL` (`3` Missing Witnesses)
- **Locations**: `HomepageCandidate.elm:1084-1086` (`readinessTiers`) and `L1648-1650` (`viewArchitectureSection`).
- **Observed Defect**:
  - `L1085` states `"7 offline Haskell suites & Quint models; ELM-ARC-002 & broker/PID1 split active"` and `L1649` lists `ui-engine-topology, ui-engine-rpc` alongside `process-custody, ui-origin, files-ops` without status qualification.
  - Actual component report `1793544641421564031` now passes **all `8` Haskell/component suites and `197` old model cases**, whereas the current UI-engine Quint profile (`1793545191214305889`) **retains `passed: false` (`FAIL`)** (`21` named tests PASS and `10,000` safety traces with `0` safety failures, **but `3` missing positive witnesses**). Grouping `"Quint models"` with passing suites overstates formal model readiness.
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Updates `readinessTiers`, `.wl-hero-note`, `#wl-trial-app-only`, and `#architecture` to report **`8` Haskell suites & `197` old model cases PASS** while explicitly disclosing that the **new UI-engine Quint profile retains `FAIL` on `3` missing positive witnesses** (`21` named PASS / `10,000` safety traces `0` violations).

### `S2` (High) — Separate `warlock-ui-engine` / `O_NOFOLLOW` `HeldExecutable` Wording vs Concrete Owned Early-Fork Same-ELF Engine
- **Locations**: `HomepageCandidate.elm:486-488`, `524`, `529`, `547-557`, `1023`, `1044`, `1052`, `1155`, `1644-1652`.
- **Observed Defect**:
  - `HomepageCandidate.elm` describes a separate `warlock-ui-engine` executable, an `O_NOFOLLOW` `HeldExecutable` lease, and a `warlock-process-custody` child reaper (`EngineSpawn`).
  - In the concrete owned early-fork engine Root is now integrating (`EngineCustodyMerged.hsc:453-459, 758-843`, `EngineCustodyParent.hs:18-62`, `EngineEntrypoint.hs:68-76`), non-threaded `warlock-ui-owner` verifies `PROC_SUPER_MAGIC` on `/proc` (`O_NOFOLLOW` is intentionally **not** applied to kernel magic link `/proc/self/exe`), pins held self-ELF `(dev, ino, size, SHA-256)`, calls `unshare(CLONE_NEWPID)` + `forkProcess` before worker threads, drops all capabilities after `CLONE_NEWNS` + private `/proc`, and `execveat(..., AT_EMPTY_PATH)`s `--engine-only` of that **same held ELF** under **`Warlock.Ui.EngineCustody`'s sole `Custody` / `waitid(P_PIDFD)` reaper**.
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Replaces separate-binary / `O_NOFOLLOW` / `process-custody` wording with the exact owned early-fork `Warlock.Ui.EngineCustody` + `--engine-only` same-held-ELF custody contract.

### `S3` (Medium-High) — Present-Indicative Standalone Window Phrasing While Zero Actual Warlock Window Exists Yet
- **Locations**: `HomepageCandidate.elm:522-531` (`#wl-trial-app-only`), `L1052` (`.wl-hero-note`), and `L1155` (`viewTrialSection`).
- **Observed Defect**:
  - Present-tense phrasing (*"On an isolated Omarchy Wayland session, Warlock's beta path attaches... Three real WebKit views: One undecorated GtkWindow..."*) risks implying a runnable native window has already been observed on Omarchy, whereas **no actual Warlock window exists yet** (`engine-pid1.json:39-40`; `nativeOperations: []`).
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Badges `#wl-trial-app-only` as `APPLICATION-ONLY BETA · NativeOps [] · NO WINDOW YET`, labels the `980x680` `GtkOverlay` layout as the **target** three-view window contract, and states explicitly in `.wl-hero-note`, `readinessTiers`, `#trial`, and `#architecture` that **no actual Warlock window is observed yet**.

---

## 4. Concrete Accessibility, Contrast, Cascade & `600px` / `200%` Defects (`A1`–`A5`)

### `A1` (High) — WCAG 1.4.11 (`< 3.0:1`) Non-Text Boundary Contrast Failures Across `Night`, `Dawn`, and `High-Contrast`
- **Locations**: `site/assets/shared/landing.css:19-20, 26` + `HomepageCandidate.elm:860, 1895, 1906, 1941-1946`.
- **Measured Contrast Ratios (Before vs After `HomepageCandidateFollowup.diff`)**:

| Selector / Boundary | Night (Before -> After) | Dawn (Before -> After) | High-Contrast (Before -> After) | Contract (`>= 3.0:1`) |
| --- | --- | --- | --- | --- |
| `.wl-hero-actions .wl-doc-button:not(.wl-doc-button-primary)` border (`landing.css:26` `22%` text mix vs `--wl-sys-color-border-essential`) | **`1.87:1` FAIL** -> **`6.39:1` PASS** | **`1.61:1` FAIL** -> **`5.01:1` PASS** | **`1.79:1` FAIL** -> **`21.00:1` PASS** | Fixed in `@layer components` `(0,3,0)` |
| `.wl-hero-eyebrow` border (`landing.css:20` `12%` text mix) | **`~1.35:1` FAIL** -> **`6.39:1` PASS** | **`~1.28:1` FAIL** -> **`5.01:1` PASS** | **`~1.31:1` FAIL** -> **`21.00:1` PASS** | Fixed via `.wl-home-root .wl-hero-eyebrow` |
| `.wl-home-dl` container border (`L1895` `10%` text mix on `surface`) | **`1.23:1` FAIL** -> **`6.01:1` PASS** | **`1.45:1` FAIL** -> **`5.55:1` PASS** | **`1.21:1` FAIL** -> **`21.00:1` PASS** | Replaced `10%` mix with `--wl-sys-color-border-essential` |
| `.wl-home-pill.is-active` border on `.wl-doc-card` in Dawn (`L1906` `#FFFDF9` on `#FFFDF9`) | `14.12:1` PASS -> `14.12:1` PASS | **`1.00:1` FAIL** -> **`7.62:1` PASS** | `21.00:1` PASS -> `21.00:1` PASS | Added `.wl-home-root[data-theme="dawn"] .wl-home-pill.is-active` (`brand-text`) + `forced-colors` `Highlight` rule |
| `.wl-doc-skip` focused skip-link border (`site.css:11` no border) | **`1.07:1` FAIL** -> **`6.39:1` PASS** | `1.12:1` -> **`5.01:1` PASS** | **`1.00:1` FAIL** -> **`21.00:1` PASS** | Added `1px solid var(--wl-sys-color-border-essential)` |

### `A2` (High) — High-Contrast & Forced-Colors Opaque-Surface / `backdrop-filter: none` Violation
- **Locations**: `landing.css:4-6, 50, 52` vs `site/foundations/accessibility/index.html#motion` (*"High contrast and forced colors use effects-off. Opaque surfaces remain opaque with no backdrop blur or client dimming"*).
- **Observed Defect**:
  - `body.wl-landing-page .wl-doc-header` (`(0,2,1)` in `@layer components`) keeps a `72%` translucent background, `backdrop-filter: blur(18px) saturate(140%)`, and a `10%` border (`1.21:1`) when `.wl-home-root[data-theme="high-contrast"]` or `@media (forced-colors: active)` is active; `.wl-band .wl-doc-card` (`(0,2,0)`) likewise stays `80%` translucent, and `.wl-band` / `.wl-home-workbench-bar` / `.wl-home-filter-bar` / `.wl-home-directory` keep `8%`–`12%` translucent divider lines.
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Overrides header (`(0,3,1)` `body.wl-landing-page .wl-home-root[data-theme="high-contrast"] .wl-doc-header`), cards, hero buttons/eyebrow, and section dividers in `high-contrast` and `forced-colors: active` to solid `Canvas` / `#000000` backgrounds, solid `#FFFFFF` / `CanvasText` borders (`2px` on `.wl-home-tonal-cta`), and `backdrop-filter: none`.

### `A3` (Medium) — `@layer states` Hover Cascade Regression on `.wl-home-tonal-cta` & `901px–960px` Dawn Hero Scrim Gap
- **Locations**: `site.css:13` vs `HomepageCandidate.elm:1817, 1915, 1924, 1931-1933` and `landing.css:54-56`.
- **Observed Defect**:
  1. `@layer states` follows `@layer components` (`layers.css:1`), so `site.css:13` `.wl-doc-button:not(.wl-doc-button-primary):hover` overrides `.wl-home-tonal-cta`'s `--wl-sys-color-surface-selected` fill with neutral `--wl-sys-color-surface-hover` instead of `--wl-sys-color-surface-selected-hover` / `--wl-sys-color-surface-selected-pressed`.
  2. `landing.css:54` collapses `.wl-hero` to 1 column at `@media (max-width: 960px)`, whereas `HomepageCandidate.elm:1915, 1924` switches `.wl-home-root[data-theme="dawn"] .wl-hero` to its `180deg` vertical scrim only at `@media (max-width: 900px)`, leaving `901px–960px` 1-column Dawn hero text over a `90deg` (`transparent 75%`) horizontal gradient.
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Adds `.wl-doc-button.wl-home-tonal-cta:hover` / `:active` in `@layer states` (`12.47:1`–`21.00:1` text contrast) and moves the Dawn `180deg` hero scrim media query to `@media (max-width: 960px)`.

### `A4` (High) — `600px` & `200%` Root Text/Page Zoom Reflow, Sticky-Header Target Obscuration & Open-Drawer Viewport Trap
- **Locations**: `HomepageCandidate.elm:1789, 1830, 1864-1866, 1892-1893, 1910, 1915-1922`.
- **Observed Defects**:
  1. **Fixed-`px` Grid Minimums Crush Columns at `200%` Root Font Scale (`foundations/accessibility#scale`)**: Grid track minimums were specified in `px` (`200px`, `220px`, `250px`, `280px`, `300px`, `310px`). When root `font-size` is scaled to `200%` (`1rem = 32px`), at `600px` (`552px` inner width) `220px` and `250px` tracks still form **2 columns (`268px`–`271px` outer / `~220px` inner = 6–8 chars/line at `32px`)**, and at `960px` (`883px` inner) `200px` tracks form **4 columns (`208.8px` outer / `160.8px` inner = ~5 chars/line)**; meanwhile `h1, h2, h3, p, li` lacked `overflow-wrap: break-word` for `80px` (`2.5rem @ 200%`) compound headings.
  2. **Zero `scroll-margin-top` Under `position: sticky` Header (`WCAG 2.4.11 Focus Not Obscured`)**: Activating `#main` (`Skip to content`), `#scope`, `#trial`, `#workbench`, `#wl-workbench-panel`, or `#architecture` scrolls the target to `top: 0` directly behind the `64px–116px` sticky `.wl-doc-header`—especially severe on `1200x800` / `1280x800 @ 200%` browser zoom (`600x400` / `640x400` CSSpx).
  3. **Unbounded Sticky Mobile Drawer Height at `200%` Zoom (`600x400` / `320x400` CSSpx)**: Opening `#wl-home-nav-drawer` inside sticky `.wl-home-header` on a `400px`-tall `200%` zoomed viewport had no `max-height` or `overflow-y: auto`, risking unreachable bottom appearance controls (`High contrast`, `Reduced motion`).
- **Surgical Fix in `HomepageCandidateFollowup.diff`**:
  - Converts all responsive grid minimums to `rem` (`13.75rem`, `15.5rem`, `17.5rem`, `18.75rem`, `19.375rem`), preserving identical `100%` layouts (`2` cols at `600px`/`621px`, `1` col at `320px`) while cleanly reflowing to **1 spacious `552px` column at `600px` + `200%` root font scale** and **2 columns at `1280px` + `200%` root font scale**, plus `.wl-home-root :where(h1, h2, h3, p, li) { overflow-wrap: break-word; }`.
  - Adds `.wl-home-root :is(main[id], section[id], article[id], div[id]) { scroll-margin-top: 6.5rem; }`.
  - Adds `max-height: calc(100dvh - 8px); overflow-y: auto; overscroll-behavior: contain;` on `body.wl-landing-page .wl-home-root[data-nav-open="true"] .wl-home-header` under `@media (max-width: 900px)`.

### `A5` (Medium) — Mobile Drawer `Escape` Drops Focus to `<body>` Instead of Returning to Opener (`foundations/accessibility#names`)
- **Locations**: `HomepageCandidate.elm:107-108, 159-163, 914, 938-944`.
- **Observed Defect**:
  - Pressing `Escape` while keyboard focus is inside `#wl-home-nav-drawer` at `<= 900px` (`320px` / `600px`) dispatched `CloseMobileNav` with `Cmd.none`, setting `.wl-home-drawer { display: none; }` while focus was inside it and resetting `document.activeElement` to `<body>` instead of the menu button.
- **Surgical Fix in `HomepageCandidateFollowup.diff`**: Adds `Attr.id "wl-home-nav-toggle"` to the menu opener button and separates `EscapeMobileNav` (which closes only when `mobileNavOpen == True` and issues `Task.attempt NavToggleFocused (Dom.focus "wl-home-nav-toggle")`, recording any `Dom.NotFound` in `lastNavFocusMiss : Maybe String`) from link-click `CloseMobileNav` (which leaves fragment target navigation undisturbed).

---

## 5. Root Application & Verification Command Sequence

When Root chooses to fold these fixes into `HomepageCandidate.elm` before running the protected `--site` build:

```bash
# 1. Verify clean patch applicability against untouched HomepageCandidate.elm (3770ea32...)
git -C /home/charl/code/Warlock apply --check \
  .warlock-contributor/engine-pid1-drafts/HomepageCandidateFollowup.diff

# 2. Apply surgical diff (expected result: 90,021 B, 2,021 L, sha256:97ab4cae214251199bb2f2e4c32300df8c25b323401b8cb91ce3440229e8e4ce)
git -C /home/charl/code/Warlock apply \
  .warlock-contributor/engine-pid1-drafts/HomepageCandidateFollowup.diff
```
