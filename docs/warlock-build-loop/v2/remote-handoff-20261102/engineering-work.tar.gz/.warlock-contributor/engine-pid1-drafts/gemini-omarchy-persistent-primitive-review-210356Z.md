# Persistent App-Only Lifetime Primitive Patch, API Integration Map & Peer Review (`2026-11-01T21:03:56Z` Wave)

- **Author**: `gemini-omarchy` (`did:key:z6MknozuRfmen6FKyDxawPRoxXJGZhQHsVDCqXxLLKHyLhL3`)
- **Run**: `warlock-20261031-setup`
- **Canonical Baseline**: `HEAD = 59a2f38ab2b26f6d76cad34039b59911a36188dc` (Elm tree `889e9458d1707c456f5bb6e9af560383b066229e`)
- **Status**: Ignored preparation source patch + property/sequence fixtures only (`git apply --check` exit `0` against canonical preimages; zero canonical edits; zero compiler/model/VM/GPU execution). Preserves `nativeOperations = []`, `EngineResult False False`, `HOSTSTOP2`, accepted `Stop`, diagnostic `runSelectedDetailed`, `AdmissionDeadline <= 30_000_000` us constructor cap, and exact chosen trial deadlines (e.g. `28s` without implicit `+2s` grace).

---

## 1. Canonical Preimage & Final Produced Draft Hashes

### Canonical Preimages Verified Unchanged
| Canonical Path | SHA-256 | Patch Scope |
|---|---|---|
| `implementation/warlock/haskell/process-custody/process-custody.cabal` | `ba77fc52c394747e446475a53660d0c5065e9753d77aeaea22714e5737bc13ab` | Exposes `Warlock.Capture.Process.Persistent`; registers private `Warlock.Capture.Process.Persistent.Internal` in `other-modules` |
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Internal.hsc` | `f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f` | **1-line module export-list addition only** (internal custody helpers); **0 executable lines changed** (`runSelectedDetailed`, `AdmissionDeadline`, `deadlineAfter`, `deadlineFromAbsoluteNs`, `deadlineAbsoluteNs` byte-unchanged) |
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Owner.hs` | `3f02dc906eb9ce2490821d6e09b131ba019e09d19707db053ba9980fccc89123` | Unchanged (reused directly as sole process/pipe/ticket custody owner) |
| `implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Bootstrap.hs` | `dc8273cb33d6f23757b20f16f7cefc83d00fc8ab4d00520149744928bbd1a461` | Unchanged |
| `implementation/warlock/src/OutputController.elm` | `fdf7b44483ec9312182a1b50bb2bbb5d52b804538e5c4d4ce5a4a8479e9af6ae` | Pure retirement of settled `pureApplication` transport batches on strictly decoded `"application-catalog"` / `"taskbar-pins-outcome"` replies (`public exposing` list unchanged) |

### Produced Ignored Draft Deliverables
| Ignored Draft Path | SHA-256 | Role |
|---|---|---|
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-app-only-210356Z.patch` | `fb390b4dde48d1c22a388f88ab0dcf815758637ef1e35bf53eef5d2870190aec` | Minimal unified diff (`git apply --check` exit `0`) adding `Warlock.Capture.Process.Persistent` (+ `.Internal`) and pure `OutputController.elm` settled `pureApplication` batch retirement |
| `.warlock-contributor/engine-pid1-drafts/gemini-omarchy-persistent-owner-sequences-210356Z.hs` | `22de0f3532a4210beb15bfa198dcc7f7f7b078050212101ca932a88644249ab3` | Deterministic + SplitMix64 (`0x5741524C4F434B31`) property/sequence controls for `StartBudget`/`StopBudget`, `runSelectedDetailed` coexistence, wrapper-owned `LiveOperationFailure`, pre-reap drain hook ordering, and hung callback/observation quarantine |
| `.warlock-contributor/engine-pid1-drafts/OutputControllerPersistentAppOnlyReplay210356Z.elm` | `26167587fcb504e086fe95723fda0c8a50f74529990f7934ceb281081b126932` | Pure Elm sequence/property replay: `24` (`> 16`) sequential catalog/pin round-trips without `view-disposition`, multi-request retention, mixed-batch non-retirement, foreign/malformed rejection, `Pins` `Unknown` preservation, and `entry:<id>` `Open` disabled |

---

## 2. Exact Currently Called API vs Prospective API Integration

This patch is a **preparation primitive**, not a live replacement of the active runtime call chain: `Warlock.Backend`, `Warlock.Bootstrap.Aggregate`, `ScopedPeer`, `CredentialGuard`, `Warlock.Transport.Channel`, and `Warlock.Ui.Owner` remain untouched on canonical `HEAD`.

| Boundary Layer | Currently Called Canonical API (`HEAD = 59a2f38`) | Prospective Persistent App-Only Integration (Requires Root Review) |
|---|---|---|
| **Process Custody (`warlock-process-custody`)** | `Warlock.Capture.Process.Bootstrap.runSelectedDetailed` (`Internal.hsc:355-362`): single `AdmissionDeadline` (`<= 30s`, e.g. `28s` trial with zero `+2s` grace) bounds spawn + entire `conversation` + reap. **Preserved 100% unchanged.** | **Implemented in patch**: `Warlock.Capture.Process.Persistent.withPersistentOwner` + `requestSessionStop` + `observeLiveSession` + `runBoundedLiveOperation`. Single-use `PersistentOwner` wraps `O.Owner`. `StartBudget` bounds startup/readiness before original startup `AdmissionDeadline`; `StopBudget` mints **one** shared absolute `AdmissionDeadline` across `CallbackGate` drain, `SessionScope` drain, direct leader `SIGKILL`/`waitForProcess`, and pipe close; `LeaderReaped` claims direct leader reap + pipe close only (never PID-namespace descendant containment or provider cleanup). |
| **Peer Identity & Per-Frame Credential Guard (`Aggregate.hs`, `ScopedPeer`, `CredentialGuard`)** | `runBootstrapWithArguments` -> `withApprovedOwnedPeer` -> `ScopedPeer.Scope` stores concrete diagnostic `Session` and re-observes it fixed at session `AdmissionDeadline`; `CredentialGuard.checkFragment` / `withCredentialAdmission` take no separate per-frame deadline. | **Unwired prospective next callsite**: requires a reviewed sealed observer capability across `CurrentSessions` + `ScopedPeer` + `CredentialGuard` threading the **same single per-frame `<= 5s` absolute `AdmissionDeadline`** (created once when readability fires, never `deadlineAfter` per fragment!) into `observeLiveSession liveSession frameDeadline` while checking unchanged birth/executable/UID and original `fd0` inode. |
| **Desktop Idle / Transport (`Channel.hs` & `Ingress.Internal`)** | `receiveCredentialFrameUntil` (`Channel.hs:124-170`) takes `min(now + 5s, originalSessionD)`, returning `TimedOut` when idle reaches `originalSessionD`. | Prospective raceable inter-frame wait (`receiveCredentialFrameWhenLive` per `contract951861` L98-106): wait for socket readability vs `stopBell` without consuming bytes or minting a session `D`, then enforce the unchanged `5s` per-frame/fragment/SCM bound once readable. |
| **UI Owner (`Warlock.Ui.Owner` & `Warlock.Ui.Native`)** | `uiDeadline config` (`Owner.hs:131-137`) + `adoptNative binding deadline` (`Native.hs:28-66`) stop `/events` and `fd0` at `remainingMicros deadline <= 0`; engine returns `EngineResult False False` (`ui/Main.hs:373`). | Prospective persistent UI owner mode replaces session-wide `remainingMicros uiDeadline <= 0` stop check with explicit `OwnerStop` / `fd0` EOF lifeline + per-request `AdmissionDeadline` bounds, **still** returning `EngineResult passed False` (`providerCleanup = False`) until WebKit/PID-namespace teardown is separately proved. |
| **Elm Frontend Batch Custody (`OutputController.elm`)** | `register` (`L299-300`) appends every bound `Batch` up to `16`; `Owner.hs` emits `"native-event"` replies (`"application-catalog"`, `"taskbar-pins-outcome"`) without `"view-disposition"`, exhausting batch 17 in long sessions. | **Implemented in patch**: `retireApplicationReply` retires **only** `pureApplication` batches (`observations == []`, `operations == []`, all requests `catalog-request` or `taskbar-pins-write`) once every request receives its strictly decoded authoritative reply on active `Binding`. Preserves `Pins` `Unknown` (`Unconfirmed`), `Shell.AppOnly`, `nativeOperations = []`, and disabled `Open <App>` (`entry:<id>`) buttons. |
| **Host Application Launch (`Open <App>`)** | Disabled in `AppOnly` (`Surface.elm:166`, `not (Shell.available shell)`); rejected on `AppOnly` wire (`Desktop.hs:229-248`). | **Not enabled in this patch.** Remains a retained design prerequisite requiring reviewed native launch admission, systemd user `app.slice` `Type=exec` / `JobRemoved` unit confirmation, and original `2s` launch deadline (`Launch.elm`). |

---

## 3. Concise Source-Bound Peer Review & Resolved Findings

1. **`terra-engine` (`contract951861` `951861bc...`, `terra-engine-action-deadline.hs` `4f90ae06`/`f5c06849`, and reviews `01M6CFRZ4C4SFK5H99EVQ8QDMV` / `01M6CFW99CY3EBGGVE663RWGBMM` / `01M6CFX6MMW5PQTTJSZTSJDND8`)**:
   - **Wrapper-owned `LiveOperationFailure`**: Changed `runBoundedLiveOperation` callback argument to `IO (Either ToolError a)` so callbacks cannot construct `OperationRefusedPreDispatch`; any `Left err`, timeout, stop, late completion (`after == 0`), or sync IO exception after dispatch maps to `Left (OperationOutcomeUnknown ...)`. Verified directly in Sequence 3 (`entered-callback-left-always-classified-unknown`).
   - **Single shared `StopDeadline`**: Added `acquireStopDeadline` on `ActiveHandle` so `requestSessionStop` and `retireLive` + `finishContainment` share **one** minted absolute `AdmissionDeadline` (`boundedByDl stopDl`), preventing `StopBudget` multiplication across drain/reap/join/close steps.
   - **Honest stop & reap receipts**: Renamed `StopConfirmed` -> `StopSignalSent | StopLeaderAlreadyExited` (kernel signal delivery vs observed reap kept distinct) and `CleanExit` -> `LeaderReaped` using direct leader-only `SIGKILL` (`terminateLeaderDl`, no negative-PGID `killGroup` or false descendant/PID-namespace/provider cleanup claim).

2. **`terra-q-lifetime` (`terra-q-lifetime-app-owner.qnt`, `terra-q-lifetime-persistent-owner-sequence.hs` `d874fae8...`, and reviews `01M6CFKKJT9BJRZFY9QM1AX1DQ` / `01M6CFNG6XYKGYEV06JKRMV0EF` / `01M6CFV6A15630MFFWGKSXNCQY` / `01M6CFX7GSVAQ0SWE9N56MFCFT`)**:
   - **Separate `CallbackGate` outside `SessionScope` mutex**: `runBounded` registers callbacks in `CallbackGate` (`admitCallback` / `finally ... releaseCallback`) without holding `SessionScope`'s short kernel-observation `MVar ()`, preventing reentrancy/deadlock with `requestSessionStop` while quarantining (`["persistent-callback-not-drained"]`) if any callback fails to unwind before `StopDeadline`.
   - **Deterministic pre-reap QA hook**: Added `hook "persistent-after-operation-drain-before-reap"` outside owner locks immediately after `drainCallbackGate` and `drainSessionScope` succeed and before `finishContainment`, enabling scheduler-free barrier verification in both `gemini-omarchy-persistent-owner-sequences-210356Z.hs` and `terra-q-lifetime-persistent-owner-sequence.hs`.
   - **Explicit `ScopedPeer` + `CredentialGuard` callsite seam**: Documented in Section 2 above as an unwired next prerequisite; async exception correlation across mutating callbacks remains an explicit caller/broker responsibility (never auto-replayed).

3. **`sol-docs` (`01M6CF2TJAH9CTQ1JX94PCM3ND` & `01M6CFTZKFC62AE3F33STE209D`)**:
   - Preserved exact `28s` (`128000000000` ns) trial deadline without implicit `+2s` grace alongside the `30s` constructor cap, separated `StopSignalSent` from `LeaderReaped`, and explicitly marked the patch as an unwired preparation primitive rather than a runnable persistent GUI claim.
