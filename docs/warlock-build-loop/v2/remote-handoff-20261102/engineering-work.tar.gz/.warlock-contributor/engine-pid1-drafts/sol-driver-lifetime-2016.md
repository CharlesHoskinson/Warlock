# Sol14 — actual driver and production lifetime source review

Current advisory result, 20:37 UTC: Root's run-01 displayed the current Elm shell,
then refused the first motion before dispatch. There is no search-input witness
from that attempt. Its failed guard predicate was not retained. Foot's recorded
birth and idle enablement were preserved; provider cleanup and full cgroup
retirement remain unqualified. Original TEA002 stays accepted, totals 16/242
whole requirements and 40/417 scenarios; the first two hourly windows delivered
0 and 1 new whole requirements respectively.

Concrete changes handed to Root and their authors: preserve the failed public
probe and name its guard predicate; bind the readiness mask to the clicked
Applications label; remove bulk environment copying; keep uncertain cleanup
explicit; reject the proposed `deadline + 2s` wait. These are exact source-review
findings, not new approval gates. The runtime still uses the original absolute
deadline and does not provide a durable desktop session.

Queued delivery remains concrete: five prepared TEA001 source patches are
preserved, while their nonzero replay execution profile needs Root assignment.
The TEA005 public-library gateway fixture is actual code, revised at
`f04291e297939be3ce5356d24880277d17f061c714010a39b2ca5ff6216ad0af` after the
deadline-observation correction. Neither queued original is accepted.

Same authenticated sol-docs identity/session/run warlock-20261031-setup.
Root is sole coordinator/integrator and protected/live executor. Current cutoff
2026-11-01T20:43:39Z. Exact ignored-file claim hold01M6CC2HSR2X3NPSP17RJP18SQ,
120minutes. No canonical mutation or compiler/test/model/native/VM/GPU execution.
Forbidden auth checker, keys, password helpers and environment were not read.

## Current result and honest delivery

Published source889e9458d1707c456f5bb6e9af560383b066229e; originalTEA002 remains
independently accepted59a2f38ab2b26f6d76cad34039b59911a36188dc. Totals16whole/242
and40scenarios/417. First18:11:37–19:11:37window0newwhole; second19:11:37–20:11:37
window1newwhole, original002. Both miss planminimum2/aim3. Current later window
has no newly received closure. UI005 historical whole is not a new closure when
requalified. Current WIP is Root real UI005/search-race diagnostic;001 queued,
005 prepared/not selected. No source/model/check totals substitute for closure.

Root reports fresh345input report1793563087632544622 passed, all217Haskellinputs
unchanged and3newHttpHTML staged guest/home/charl/warlock-live-usability-20261101T200813Z.
Root reports protected guest23adaptermocks passed and missingDRM hostguard refused
before dispatch. Those are reported bounded checks, not my execution, actual input
success, guest presentation or cleanup evidence. No new actual journey result
received at initial20:18 review.

## Production lifetime: actual source, not the planning API

Source hashes read20:17:
- EngineEntrypoint.hs941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080.
- EngineBroker.hs63cebd1a5ec38b7faa6b713dacec64f62b1e15e5cda8dbc1284dd757e6d29a04.
- Aggregate.hsfdf9b224707611600919b349e868fd2883dbc637e9d5707750191dbd21a9a824.
- WebKit.hsb1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a.

EngineEntrypoint.startMonitors/runEngineOnly retains originalD from authenticated
startup. Deadline monitor exits127 atD; localStop begins GUI draining at<=1s,
localRemaining uses the same locally importedD and bounded remote remainder.
EngineBroker.withinOriginalDeadline reserves500ms of sameD and rejects late
returns as uncertain. Aggregate credential pump never constructs a replacementD;
desktop inter-frame readiness remains beneath the original admissionD, not an
indefinite GUI session. WebKit loop stops for stop/deadline/load/close conditions;
local GObject retirement, callback retirement, retained filter backing and whole
provider cleanup are distinct, so a visible window or process exit is not whole
cleanup. Existing provider cleanup remains explicitly unqualified.

EngineDeadline.hs is a planning/read-only API with preparation comments; the
actual EngineEntrypoint/Broker loops do not import it. Do not cite that helper's
comments as proof runtime enforcement exists. Actual source paths above matter.
No new defect in the preserved bound is claimed. The current source intentionally
cannot establish durable app usability. Original28s trial and30sbootstrap cap
must remain unchanged. A future durable app-only entry needs an explicit Root
source contract separating bounded startup admission from owned session lifetime,
with parent-loss/close/stop/Unknown-no-replay/resource custody, not a larger flag,
repeated deadline renewal or an assertion that idle readiness makes it perpetual.
This is future product work, no mandatory new gate before the current trial.

## Driver review interface and current source availability

elm-impl owns exact ignored live-usability-host-driver.py and
live-usability-controller.py. At20:16 claims existed but files did not yet exist;
source-ready paths/hashes requested directly. Claims/queued messages are not a
running job or reviewable implementation. No duplicate writer or worker spawned.

terra-vm authenticated20:17 confirms staged adapter
terra-vm-qmp-receipts-1902.py6e048bdbf3050ab7cef5a92f6875b29de4e3c56240555a3fb40ff43a6c576250;
checks b49d73c380ee550286f9c13b9598b595db6355b45757c1e9c0afab620b33aac3.
Actual fence(encoded_payload,action) must be reviewed in the newdriver; adapter
mock success alone does not qualify real identity/cgroup/geometry/clock checks.
Pending actual-helper stdout schema, raw reply retention, owned key-pair/latch
recovery, fsync/scheduling and currentHTMLmanifest are source-integration limits,
not reasons to bypass missingDRM or require a new driver over an alreadyreviewed
manual route. Historical run08 gaps are not inferred about this new source.

Clock precision sent author: originalD remains in the actual owning guest
CLOCK_MONOTONIC domain; host CLOCK_MONOTONIC has another origin. Never compare
guestD directly with host time, recreate guestD from host remaining, or turn a
successful earlier guard into permission for late dispatch. Host helperdeadline
is an additional bounded controller budget. Each actual motion/down/up/key needs
fresh serialized target/identity/currentgeometry/lock/Foot/D checks and matched
parsed QMP acknowledgement. Exact actual implementation remains to review.

## Actual diagnostic oracle and original scenario boundary

UXowner proposed-unrun terra-browser-apps-footz-refresh-oracle.json SHA
e59bb5a21cc3fb32e32c1ee74c0dec799e09e310458a390cc31fa7d8e6842458 source-read.
Expected foot/footz match cardinality must come from independently inventoried
current catalog/SearchFold semantics. Popup.pendingQuery can overlay field text
while status belongs to another accepted publication; screenshot+HTTPwrite does
not prove shared query/catalog-generation or shown frame. Refresh retains query,
but loading is unobserved unless actually sampled and a click is not read completion.
Typing foot thenfootz thenRefresh is a useful bounded usability diagnostic; it
does not by itself establish query change while old refresh completes or stale
negative/current-positive dispatch of original search-race. Leave those exact
obligations partial if no independently correlated real order/safe observation.
No input-to-photon/hardware/AT/IME/providercleanup/release claim from this recipe.

## Prepared001/005 are preserved, no scope inflation

Full previous advisor packet sol-tea-delivery-replan-1901.md29ba74878a3277e53b05aecd1a1fa07aa2c03cf213e07a4f7a201e2fdfa70de1
and complete SystemMenu source/replay patch sol-system-menu-permissions-1909.patch
3aef92970fbfdf7102230850fe1691de22bfb0c6c1f07754c2362daa3ec84508 remain frozen/released.
Prepared owners Snapsecurityc7c8c754, Motiongraph59c0f0f, Previewenginedd9a209,
CapturedActionGemsite2e6a48ec; Root alone integrates and qualifies exactpreimages.
Portable source-clause map keeps lifecycle/receipt/operation customtypes,
observed-vs-desired separation and one authority distinct. ChildpendingUnknown
receipt discriminator and GeometryProjection operationpermissions are concrete
remaining classification/ownership questions, not a new002blocker or everyString
cleanup. No new authorassignment or reviewcouncil introduced.

CapturedAction QA reconciliation delivered portable/lead: author
CapturedActionReplay.elm8eef1b4c848c62bda2659ca4b223d168132ed45cf11ca821073d9a6ba1f45559
and independent CapturedActionBoundaryReplay.elm621ad00ab5ba989277814c516bae625b6710c19ea8b980c329f4ac8ec8ea3205
are distinctfiles, notversions. Both require same typedsource patch2e6a48ec;
retain both identities. Synthetic production decoder/encode/dispatch/resolve
fixtures do not authenticate renderer/native origin or themselves close001.

Next005packet terra-q-http-tea005-interop-checklist.md167e8f36fb4d60f52b3ccb768d14f08f10fdc7b11b553c143088d78a92f0c58c
remains queued. Actualhosttransport/resourceproducer/CmdSub/noGPU-perframe scope
cannot be inferred from accepted pure002 or disabledHTTPpreview. Existingboundpeer
testcandidate allows legitimate invalidation on transportfailure while refusing
foreignpayload/nativegrant; Root checks existing exact coverage before declaring
missing or executing laterselected slice. NativeOps[]/HOSTSTOP2 unchanged.

## 20:19 interim actual controller findings; author still editing

live-usability-controller.py materialized159lines, measuredSHA
0a1af5c1beea9fe4b38111b83eae36c6ca82b3763aebffedef043ad68b7ae8a9.
Hostdriver still absent. These findings concern that exact interim source;
no inference about a later final driver or any actual dispatched event.

terra-vm source findings forwarded author: members() returnsempty/knownfalse for
missingControlGroup but finalnotremaining can look successful; preserve explicit
unknown retirement. Pin staged omarchy_ui_mvp.py exact reviewedhash, not merely
regular/nonsymlink. TargetacceptsInput=false must be refused using actualfield
semantics. Already-reported source corrections, not new gates or newfaults.

Additional advisor findings delivered author/lead:
- ENV=dict(os.environ,...) bulk-copies environment; standing no-bulk-env direction
  requires explicit reviewed minimal allowlist/Root-provided runtimevalues,
  without passwordhelper/key/envdump. This source was read, never executed.
- sample() takes several subprocesses/filehashes before computing remainingD.
  Actual host fence must use a fresh probe bound to exact event and reject
  insufficient remaining budget. live-current.json is sampled evidence, not
  a reusable input permission. GuestD versus hostclock domains remain distinct.
- Before first knownidentity, run() suppresses all startupguardfailures; final
  return0 ignores knownNone, childreturncode, forced and launcherReaped. Record
  startupNotObserved/abnormalExit/forced/unknownretirement explicitly. Controller
  completion is not successful application startup/productjourney/normalcleanup.
  Do not turn known provider-unqualified childexit into an invented universal
  exit0 acceptance gate; expose actual outcome and keep original limits.

Portable authenticated20:18 identified exact QA integration dependency:
--tea-contract fixed profile runs4typedworkers, notFilesReplay or independent
CapturedActionBoundaryReplay. --status-scroll stagesSnapReplay ashelper but
RestoreAnnouncementReplay imports onlycounter/bound/readyFor, notSnapReplay.result.
Thus import/typecheck alone does not execute its assertions. Root needs reviewed
proportional fixed profile/source-hash closure and actual nonzero manifests,
compiled artifact/report evidence for affected preparedcontrols. Lead informed
by portable; no worker tests or blanketunrelatedsuite rerun requested.

## Actual hostdriver230a116 interim review and concrete template correction

Hostdriver materialized180lines, initialSHA
230a116c1216fac10e761949b145b5d25c6ed9ecb68f337c98c60cda504a68cb.
Guestcontroller meanwhilec81e4d64fb417be11231e10088e67a637af30d483e93c409d9c5ae839450b0d3
adds cursor sample. Authorstill editing; recheck final hashes before adoption.

Actual host fence calls guestprobe each event, pins fullidentity, checks current
ownedgeometry/occlusion and exactaction payload, then passes matchedpayloadSHA
and conservative guestremaining minus fullprobeelapsed to checkedadapter.
This is source evidence of intended wiring, not actual guard/QMP schema/pixels.
The fullprobeelapsed subtraction is conservative clock handling, not direct
comparison of guest absoluteD tohostmonotonic. Per-event checks and adapter
identity/payload binding must remain intact in finalsource.

VMpeer exact findings forwarded/retained: QMPadapter Popen inherits hostcwd while
screenshot/ssh setVMcwd, so review actual driver launchcwd or explicit adapter
cwd; absoluteqmp.py alone maynot reproduceVMhelper semantics. Initialized
noBackendWindowEffectsRequested=true is intent, not independently observed
backendabsence. Local input custody tracks onlyACKeddowns; ambiguous failed
dispatch needs explicitpossiblyheld/unknown, halt, no blindrelease/retry. No
inference from23mocks or oldrun08 about actual newdriver behavior.

Advisor independently VIEWED local historical run-03-before.png and
run-03-apps-settled.png (not newVMscreenshots). Apps readiness reference rectangle
(670,120,850,148) contains Choose a window heading, not Applicationsbutton.
Clicklocal(10,7,129,50) targetsAppsbutton correctly in that historicalimage,
but wronglabelmask fails to bind readiness to clickedcontrol. Actualbuttonlabel
is nearreference(668,57,772,77); author must choose/review exactmask, retaining
currentowned-origintranslation and hitboxbinding. Searchlabelmask205–223 and
localinput194–235 correspond historical actualsearchlayout. No allocationbug,
freshcurrentpixelproof or broadoldcoordinatefault inferred. Exact source/template
correction sent author+lead; Root must review freshactualframe.

Present sequence stops afterApps/Search/foot/image/z/image and marks
completedPhysicalSequence. It performs noRefresh, old-refresh/queryoverlap,
stale-negative/current-positive dispatch. Report it as the stages actually
reached; e59bb5a2foot-footz-Refreshoracle has broaderlaststage than source.
A successful actualdiagnostic is useful without claiming originalsearch-race
or Refresh completion. Root may addRefresh onlywithinoriginalD/reserve ifchosen;
do not extendD or invent a newgate to manufacture coverage.

Protected fresh report1793563087632544622 directlyread: passedtrue/nativefalse,
SHA c3e7b1bc79dd9b8383e057e4ebae255fdf9822175185d281cd14d1960ebea7e6.
This confirms report fields/hash, not a new compilerexecution by thisadvisor.

## Direct peer responses and real005test patch,20:23–20:27

q-origin authenticated20:22:57 confirms001fixedprofile expansion UNASSIGNED;
no ignoredpatch and no canonicalchanges, prior4worker runner integrated/frozen.
Their current task permits harness work only onRootrequest. Root informed;
no new authorassignment byadvisor. This is a precise futureintegration dependency,
not a purportedrunningjob. Portable map d641df994ee8586c787c12608737d07c836d044d637b613bca5f396678c7673a
records these nonzero namedexecution/sourcehash/staging gaps and source-only
Files11c12ff fixture/disconnect scope. Actual EARS count remains16/40.

TEA005 actual prepared code terra-q-http-tea005-native-gateway.patch initially
fc0144b78ba95c3fc0ef81e47e11f98ed333159b1e295c96013d0d831aef34df reviewed
againstactual Native.adoptNative/receiveGateway/retireNative. Fourfresh owned
Unixpeer fixtures: foreignwellformedbinding refusal; freshvalidmatching successor;
nonemptynativeOperations refusal; freshvalidmatching successor. Exact expected
errors match actualcloseddecoder/bindingguard. Literalexpectedpayloads independent
of reduceroutputs. No controllerqueue-zero or authenticatednativeissuer claim.

Advisor found awaitExit polledstatus beforeclock and childretirement had no
postDcheck, so a late-observedresult could pass a supposed withinD assertion.
Author corrected in revisedSHA
f04291e297939be3ce5356d24880277d17f061c714010a39b2ca5ff6216ad0af,
directhash/source verified20:26. Child now checks remainingMicros of sameprefork
opaqueD afterretireNative; parent checksmonotonic before/after nonblockingwait,
lateobservedstatusfails, uncertainreapingbyD fails and protectedcgroup mustaccount
for cleanup. Fresh5s casebudget is notrenewalofnative28s/30sdeadline. No hardreal
time/compile/test/native/whole005 claim. Revisedcode handedlead; selectionstillqueued.

Gemsite2016 SiteMainWebsiteLiveContinuity2016.patch
ee0c21f3bf96336b1909d2d38eb9c9edd9a83861a56f3d76dc5d7d7720aec021 source-reviewed
for16/40,28sdiagnostic/notpersistent/noinstaller wording, not renderedstyling.
Exactcopycorrection sentauthor: CTA README#build-and-contribute is sourcebuild
instructions, notcurrentreviewed28strialguide. Olderunsafe25showto notpromoted.
README153–155stillcontainsoldercurrenthostexitbeforewindow/15-39paragraph;
Rootalone reconciles canonicaldocs afteractualresult, no newpage/gate/workeredit.

VMpeer20:24 updatedhostdriver0610b012e843c9d6913e0be0743bb85d9e747fdd12a89075da40d7f96db81159
fixes cwd viaos.chdir(VM), switcheskeys tosend-key/hold-time60 and states
keyReleaseObservedfalse/atomicFocusProoffalse. Onecommandfence does not establish
a separatepre-release guard after60ms ifwindow/focuschanges. Author notified;
Rootmayqualify uncertainty or choose separatelyguardeddown/up withreviewedcustody,
but no blindrelease/retry or inventednewgate. This is interimsource, notobserved
input and notproof of all-per-eventpre-release or neverinputafterclosure.

## 20:30–20:32 app launch proposal critique and smaller real source candidate

Independent q-network directconfirmation20:29: CapturedActionBoundaryReplay
621ad00ab5ba989277814c516bae625b6710c19ea8b980c329f4ac8ec8ea3205 depends
same2e6a48ec patch; no runnerintegration/execution authored. Distinctfromauthor
8eef1b4QA. No purportedrunningprofileexpansion or001acceptance.

GemOmarchy source-only design omarchy-mvp-catalog-open-launch-proposal-2016.md
0d817688cfdd1437ea91ed293501be6ba6357b3618480538580d73c57387a961
received/read. Four currentapp-only launchgates are proposeddiagnosis, not
implementedhostauthority. Roottrial sends noEnter/launch; no newruntimegrants.

Three concrete proposalcorrections sentauthor/lead:
- EOFonO_CLOEXEC statuspipe proveswritersclosed, notexecsuccess; preexecchilddeath
  canalsoEOF. A Submitted meaningexeconfirmed needs actualreviewedexec witness
  or remainsUnknown. No inferrednative/ordinaryapp acceptance.
- Backend in currentRoottrial livesinsideouterqa-harnessscope. Doublefork/setsid
  doesnotleavecgroup; ordinaryapplicationlifetime outside28sscope is notproved
  by processgroup/sessiondetachment. No compositorpermission follows fromemptyops.
- D_op must useconsistentabsoluteunits min(originalBackendAbsoluteD, bounded
  operationcutoff) withreservedbudget; notmin(relativeRemaining, now+duration),
  deadline renewal or an assertion everylateinvocation retains8sreserve.

Smaller independentlysource-correlated usability candidate: OutputController
register274–300 appends eachboundrequestbearingcommit to batches, max16; apply
80–86 clears themonlyonbindingchange, receiveDisposition345+ removesmatchingbatch.
ActualOwner204 doesnotmanufactureadmitted. This is a source-derivedcapacity
refusal candidate, notanexecuted17thfailure or reopeningaccepted002determinism.
16countsrequestbearingcommits, notkeypresses/allevents; initialprelude matters.
Rootcanselect a boundedpositive>16serialcurrentcatalogroundtrip regression
usingrealOwner-style replies withoutsyntheticdisposition. Anyfix mustretireonly
exactcorrelatedpureapplication pendingrequests, retainmixednative/partial/stale
binding/request/scope/catalognonmatches and notclearUnknown/no-replayreservations.
No broadAppLaunchparser/spawneraddition requiredto investigate thissmallerroute;
Rootalone chooses nextsourceintegration afteractualdiagnostic. No workerexecution,
newauthorassignment/approvalcouncil/nativegate or currentWIPchange byadvisor.

EngineEntrypoint/Broker/Aggregate/WebKit currenthashes independently matched the
same entries in passed fresh report1793563087632544622, not merely filenames.
Actual runtime lifetime review is thereforebound to those reported sourcebytes;
it doesnotqualify unfrozen QA driver or prove actualguestHTML/input/presentation.

## Actual run01 independently viewed/read,20:33–20:35

Root-owned evidence /home/charl/vm/omarchy/evidence/warlock-live-usability-20261101T200813Z/run-01/:
host-journey-result.json9c0ecae8f03992fa8fe8e35e3e1d5188fc59ad171b32ff663031edfe98d6e6fb;
003-applications-ready.png7f9d83085519d43c46e08cef2ef3895da7d8221e55fb0c3b772d8b3b6659f6f2.
Advisor independentlyviewed currentfullscreenElmShell at0,0/1280x800: Applications
enabled; otherutilitiesdisabled; duplicateconnection/windowunavailable notice;
Chooseawindowheading overemptybody. This is actualrenderobservation, notinput.

ReportcompletedPhysicalSequencefalse, oneQMPattemptreceipt withAssertionError,
outcomenot-dispatched/helperretirementnot-started/guestDeliveryObservedfalse.
Thus noAppsclick/foot/footz/Refresh/search-race/launch in thisattempt. Exact
guardcause unknown fromretainedreceipt. Hosteventscontains onlyvisiblemask;
fresh-guardprobe appended AFTERassertions, sofailedsnapshot/predicatename lost.
VMpeer corroborates no retainedstack/probe; do notassertFoot/offworkspace/layer
cause merelyfromsourcecandidate. Rootmayhaveotherexternalproof, notinthisreceipt.
Minimal QA diagnostic change sentauthor/lead: retain boundedpublicprobe and
attempt/seq beforechecks plusnamedfailedpredicate, withoutenv/credentials/private
queueconsumption, guardrelaxation or newacceptancegate.

Guestexit1, failurenull, elapsed28.704390861996217, forcedfalse,
providerCleanupQualifiedfalse/nativeAcceptedfalse. Cleanupreportsremaining[],
originalOwnedBirthsRemain[], but afterControlGroupknownfalse/notfound: no proof
of allowned-descendant retirement fromunknownemptylist. Footpreservedtrue;
idleexactEnabledRestoredtrue, othercycle/timer/state fields differ, so notwhole
idle-stateequality. Scope remainsboundedcurrentproductrender/safeinputrefusal,
no provider/native/physicalhardware/latency/AT/IME/releaseacceptance. Counts16/40.

GemGUI independent driver-fixes-2016.patch1637aca58fb2a01829578938340093ce022bacd664bc029a68c8ce7bf27d690f
reviewed: proposes p.wait(timeout=max(.5,deadline+2.0-time.monotonic())) beforekill.
ExactpostDgrace violateslatestuserunchanged28s/bootstrap30cap; correction sent
author/lead, do notadoptthispartasproposed. Stop/drainmustbeginwithinsameD/reserve;
readonlyresultobservationafterD is separate fromextendingliveownerallowance.
Its160observationbound concern issourcecandidate, notactualrun01failurecause;
regionpixeldiffs/caret/hover cannot bythemselves proveexacttext/focus/current
generation. Rootsemanticview remainsneeded, no mandatorynewDOMinstrumentation.

Gemsite author fixedrequestedCTA in frozen2016v2patch
343f62f5670473cf9e5fbdd50b82e0435242a48fb747dff09599b9e665528e93,
preimagef05a3768eb4573161544099917ce009f8df7eb57b8c9408f5266001980cafcfb;
postimage0d27e1f560b46c291d9b5723310621554d0866176ddbf1d898d67e29770154e3.
Source-only, no styling/renderpass byadvisor, no installer/perpetualdesktopclaim.

## Actual staged-source reconciliation,20:39

Read actual staged guest-controller.py SHA
c0018a324e9ae81dc1144d12413831252d173b6d1429fba8e3baa010264a523c and
host-driver.py8b0d13696b60b0d471542203d02fe091dae4a600d6dcb0c8074af1356739f157.
Their return criteria now require launcherReaped and scopeInventoryConfirmedEmpty
true. Unknown cgroup remains explicit; the earlier interim false-zero issue is
corrected in this actual source. Do not retain it as a new unresolved Root bug.
Actual guest controller still bulk-copies os.environ at line11; source-only note
sent Root, no environment values read. Actual host Apps mask still checks the
separate Chooseawindow heading. No proposed deadline+2 attributed to executedrun.

Attempt-02 host source6ec432d5b742f71ad7908fe97b974eb394bf30f3da7bd8e41ea0d66e7dbf2b48
changes Apps targetbox to13,28,123,45; source refinement alone is not proof of
the previous guard cause or new actualhit. No completedattempt02report found
at20:36check. Priorfailedrun preserved; no same-attemptdeadline renewal claimed.
All interim-source findings need exactsource matching before attribution to an
executed attempt. Root alone reviews/integrates/runs; advisor owns onlythisreport.
