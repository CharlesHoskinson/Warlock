-- QA ONLY; compile in a SEPARATE isolated after-slot fault overlay build.
-- Root keeps this process and its roots alive after any result/exception, under
-- the existing external guardian and original QA deadline. A StablePtr has no
-- meaning after process termination and does not prove descriptor retirement.
module QHttpAfterSlotRetainedHost (Roots,newRoots,runHosted) where

import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Data.IORef (IORef,atomicModifyIORef',newIORef)
import Foreign.StablePtr (StablePtr,newStablePtr)
import qualified QHttpConfigAfterSlotControls as Control

newtype Roots = Roots (IORef [StablePtr Control.Case])
newRoots :: IO Roots
newRoots = Roots <$> newIORef []

-- Allocate and root the actual owner before read, fault or any process work.
-- Never free the root or interpret a synchronous exception as clean custody.
runHosted :: Roots -> FilePath -> IO (Either SomeException ())
runHosted (Roots roots) path = mask $ \restore -> do
  retained <- Control.newCase
  root <- newStablePtr retained
  atomicModifyIORef' roots (\old -> (root:old,()))
  outcome <- try (restore (Control.runCase retained path))
  case outcome of
    Left problem -> case fromException problem :: Maybe SomeAsyncException of
      Just _ -> throwIO problem
      Nothing -> pure (Left problem)
    Right () -> pure (Right ())
