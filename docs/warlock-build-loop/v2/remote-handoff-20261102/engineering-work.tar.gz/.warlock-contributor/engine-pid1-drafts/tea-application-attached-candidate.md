# Source-derived application attachment / unmatched disposition candidate

This is a source-review candidate, not an executed test, native observation, or acceptance. It starts with the independently source-transcribed complete Policy.initial, then the reviewed one-view topology `{bridgeProtocol:1,kind:"view-topology",payload:{viewProtocol:1,kind:"view-topology",revision:"1",views:[{id:"1",generation:"1"}]}}`. Its complete preceding expected state must retain every initial sibling and use the separately reviewed eight topology changes: OutputController revision/highest 1, views `[Scope 1 1]`, selected `Just (Scope 1 1)`, SurfaceController publication 3, Desktop ownerScope `Just {outputId=1,providerId=1}`, presentation `Just 2`, Launch revision 2. Lease remains 0.

Next input (literal JSON):

```json
{"bridgeProtocol":1,"kind":"native-event","payload":{"protocolVersion":3,"kind":"application-attached","binding":{"lifetime":"1","session":"1","frontend":"1"},"nativeOperations":[]}}
```

This is an assumed trusted owner-delivered application-domain message, not proof of native operations or peer authentication. Define `B` as the valid opaque Binding for `(1,1,1)` and `S` as valid Scope `(1,1)` via existing decoders; do not expose constructors or add mutators in production. Semantic expected full-state changes from the one-view given are:

* Shell `applicationOnly=False→True`, `binding=Nothing→Just B`, `phase=Detached→Reconciling`, `reconnecting=True→False`, `notice="Connecting…"→"Applications connected. Window controls unavailable."`; other Shell fields including `effects.connected=False`, `effects.transaction=Nothing`, unresolved=[], issued=[], `request=0`, `expected=Nothing` remain as pinned.
* Desktop `presentation=Just 2→Just 3`, `request=0→1`, `expected=Nothing→Just 1`, `workspaceNavigation.binding=Nothing→Just B`; Launch host `Nothing→Just "{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}"` and Launch revision `2→4`. Desktop ownerScope remains Just `(1,1)`. SurfaceController publication `3→4`, lease remains 0.
* OutputController adds exactly one batch at the head: `{scope=S, revision=1, publication=4, lease=0, binding=B, wire=W, observations=[], operations=[], catalogs=[{binding=B,request=1}]}`. All counters above are `UInt64.Counter` values, not JSON numbers. All other complete model state is unchanged relative to the one-view given, subject to independent check against the exact pinned initial and actual fixture artifact.
* The entire typed effect list is `[Publish C]`, no Delay. `C` is the literal commit specified below; `W` is its exact compact JSON serialization in the **source insertion order**, independently built from that literal (not recorded from implementation output). `OutputController.commit`, `frame`, `Surface.packet`, `Binding.encode`, and `Desktop.catalogRequest` define the indicated field order. The observer must compare the complete unwrapped and wrapped payload without dropping JSON or constructor details.

`C`, with fields deliberately in source insertion order:

```json
{
  "viewProtocol":1,
  "kind":"view-commit",
  "projection":{
    "viewProtocol":1,
    "kind":"view-frame",
    "revision":"1",
    "views":[{"id":"1","generation":"1"}],
    "focusOwner":{"id":"1","generation":"1"},
    "popupOwner":null,
    "frame":{
      "surfaceProtocol":2,
      "keyboardParent":true,
      "motion":"reduced",
      "appearance":{"theme":"night","textScale":100,"effectsOff":false,"reducedTransparency":false},
      "publication":"4",
      "lease":"0",
      "mode":"closed",
      "status":"Applications connected. Window controls unavailable.",
      "bar":[
        {"id":"bar:applications","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:control:opener","label":"Applications","ariaLabel":"Open applications","detail":"","enabled":true,"focusOnly":false},
        {"id":"bar:overview","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:control:overview-opener","label":"Task View","ariaLabel":"Open Task View","detail":"","enabled":false,"focusOnly":false},
        {"id":"bar:switcher","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:control:switcher-opener","label":"Switch windows","ariaLabel":"Open window switcher","detail":"","enabled":false,"focusOnly":false},
        {"id":"bar:notifications","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:notifications:opener","label":"Notifications","ariaLabel":"Open notifications","detail":"","enabled":false,"focusOnly":false},
        {"id":"bar:files","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:files:opener","label":"Files","ariaLabel":"Open Files menu","detail":"","enabled":false,"focusOnly":false},
        {"id":"bar:system","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:system:opener","label":"System","ariaLabel":"Open system menu","detail":"","enabled":false,"focusOnly":false},
        {"id":"bar:settings","domId":"applications:{\"lifetime\":\"1\",\"session\":\"1\",\"frontend\":\"1\"}:3:settings:opener","label":"Settings","ariaLabel":"Open settings","detail":"","enabled":false,"focusOnly":false}
      ],
      "popup":[]
    },
    "announcer":{"scope":{"id":"1","generation":"1"},"surface":"bar"},
    "announcement":null
  },
  "requests":[{"protocolVersion":3,"kind":"catalog-request","binding":{"lifetime":"1","session":"1","frontend":"1"},"requestId":"1"}],
  "focus":[]
}
```

Call the complete independently specified state after attachment `MP`. For each **independent** next step from MP, use an exact-shape `view-disposition` payload:

```text
viewProtocol = 1; kind = "batch-disposition"; disposition = "preflight-unsent";
scope = {id:"1",generation:"1"}; revision = "1"; publication = "4";
lease = "0"; binding = {lifetime:"1",session:"1",frontend:"1"}; batch = W.
```

Separately change exactly one valid field: scope id `"2"`, revision `"2"`, publication `"5"`, lease `"1"`, binding frontend `"2"`, or batch `W + " "`. Wrap in `{bridgeProtocol:1,kind:"view-disposition",payload:<certificate>}`. For **each** mismatch the complete expected state is exactly `MP` and the entire effect list exactly `[]`; the retained batch and pending catalog request remain. Follow with the matching disposition in a separate history, with fully independent literal expected refusal state and effects; do not use this no-op case to claim the match's result. Native-peer identity, actual delivery, and native execution remain outside this pure Elm fixture.

Corroboration: OutputController.elm `Topology`, `register`, `receiveDisposition`; DesktopPolicy.elm `incomingEvent`, `effectsFor`, `update`; Desktop.elm `host`, `windowBase`, `PresentationOwner`; Shell.elm `application-attached`; Launch.elm `bind`/`disconnect`; SurfaceController.elm `applyOrdinary`; Surface.elm `packet`/`barControls`; OutcomeAnnouncements.elm `observe`. Source hashes and final artifact must be pinned by the oracle owner. Open reviewer checks: all unchanged fields, `SurfaceSnapshot.decode` acceptance, independent static JSON key order/escaping, debug constructor layout; fail closed on any discrepancy. No compiler, tests, model, VM, or native actions performed.
