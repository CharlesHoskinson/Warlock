# Applications no-match and pagination: source review

Preparation for independent review only. No source/test/model/GTK/VM execution
or original acceptance is asserted. Peer GUI patch is separately owned; this
review does not alter or approve it. The original `search-no-match` oracle is:
given query and catalog fixture, when no entries match, no-match message and
query remain reachable without launch. Follow its named verification and frozen
source/identity evidence; no single screenshot closes whole ELM-UI-005.

## Authority and counterexample

`Surface.elm` SHA256 `c1a34f50b3b1da96f732d63fe9fb9f0e7022735881385ed5419aca8e76796ccb`:
`entries` is the full `Catalog.search model.query` result. `prefix` combines
jump/pin controls ahead of entries; page `visiblePrefix` and `visibleEntries`
are sliced separately under the existing capacity bound. For a nonempty full
search result and enough pin controls to fill page one, visible entry count is
zero despite real matches. Conversely, when full search returns no matches,
stored pin controls may still be visible. Therefore neither zero visible
`entry:` identities nor popup emptiness can decide the no-match condition.

The current canonical status is `Surface.contextNotice`, included in the frame
through `notice`/`capacityStatus`. It checks pin notice, launch disposition,
catalog failure and pending/unavailable states before full `Catalog.search`
emptiness. `SurfaceRenderer.elm` SHA256
`d6cc2985db97749633af2ab33748e98fbc5d482e08fb0e333e3ea6576ae9dd98`
shows the accepted `snapshot.status`. A view-only alternative that derives a
second no-match status from page contents or a locally overlaid uncommitted
query invents competing authority and may mask loading, unavailable, refused,
unknown or pin feedback. If an independent visual empty-state element is
wanted, it must be derived from an explicit authoritative full-result fact or
canonical status, and preserve those higher-priority states and semantics;
never change the published status locally based on sliced controls.

`Popup.elm` SHA256 `fb24afed07ee6396633efb987b3202e57e0dfe52642a8150987e75648c944c58`
keeps `pendingQuery` as a local display overlay; accepted `Present` retains it
only for the same lease, mode and enabled field. `Presentation.localEdit`
rebases admissible older-publication query edits to the current publication,
never a launch; composing or an unconfirmed local query blocks entry dispatch.
Preedit is retained while composing and changed text is dispatched at end;
same-baseline end sends no query. Stale or different field/lease must not gain
authority. App-only entries are disabled by `Surface`, `nativeOperations=[]`,
and pin unknown retains its reservation: no Enter-triggered launch, native
effect or automatic replay should be invented.

## Focus and source-bound validation

DOM field focus and the GTK owning surface are distinct observations. An exact
current publication/lease target that is enabled or explicitly focus-only, and
the Popup's non-composing guard, control whether focus can be requested; a focus
command, HTML attribute, or screenshot is not a physical focus/IME receipt.
Do not steal focus during preedit or an
explicit refresh; do not claim typing/clicks from a static window capture.

Recommended cases for root's existing production-route replays and independent
runtime observation (all presently unexecuted by this worker):

1. Current catalog with a matching entry on a later page; enough pins to fill
   the visible page. Preserve canonical non-no-match status and navigation.
2. Actual empty full search with existing pins. Preserve canonical no-match
   guidance and query while allowing the pin controls actually present.
3. Loading, unavailable, pin Unknown/refusal, launch feedback and compact
   status precedence. A local pending query must not replace those statuses.
4. Same-field same-lease refresh and stale old-publication edit, different
   lease/field refusal, IME preedit/end/cancel and no Enter dispatch while
   pending or composing; preserve original no-replay semantics.
5. Exact physical target, visible query/status, current publication/lease,
   actual correlated catalog reply and observed GTK/DOM focus; verify empty
   nativeOperations and no launch. Original keyboard/AT/IME observations remain
   separate when applicable. Use pinned source/artifact hashes and original D.

No counts from Quint or component replays prove browser, native, AT or IME
behavior. Preserve all 242/417, stopped histories, HOSTSTOP2, main desktop and
prior failures; root alone integrates and runs protected checks.
