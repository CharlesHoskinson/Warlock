# Engine retirement witness sequence — source-only preparation

This is a review aid for a future claim that **actual whole-engine cleanup** is
qualified. It is not a prerequisite for observing the current MVP, an extra
original-scenario or release gate, a runtime receipt, or evidence that cleanup
occurred. Keep the present `EngineResult False False`, all original deadlines,
failed observations, and the actual provider/backing/callback uncertainty.
Root owns any source change, execution, provider qualification and evidence.

Reviewed checkout hashes (2026-11-01; rebind before any later use):

- `runtime/ui/Warlock/Ui/WebKit.hs` `b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a`
- `runtime/ui/Warlock/Ui/EngineCustody.hsc` `5028eed1eae2df6f066d3868777af686aa0ddb889a651159b26cb3369c4129de`
- `runtime/ui/Warlock/Ui/EngineEntrypoint.hs` `941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080`
- `runtime/ui/Main.hs` `50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7`
- `runtime/formal/ui-engine-lifetime.qnt` `4d9dc045213c038d12f68c46941fd72b6357222536122e7a693f910edfc9be8d`
- `runtime/formal/ui-engine-topology.qnt` `2d8dee2443cc0416f7c74ce15c85ce3e67702a62633579ce6bdc8a94e3915fa6`

## Actual source boundary

The model's `qualified`, `callbackHeld`, `nsExit`, `reaped`, `backingHeld`
and `clean` are bounded contract states, not imported GLib/kernel receipts.
The source calls `runWebKit` without a `Custody` in the exec-PID1 engine.
`productionCleanupFacts` starts `CallbackPending`, `ProviderUnqualified` and
`custodyBeforeDeadline=False`; WebKit does not set those fields to qualified.
Its `backings` retains filter store references and private directories and no
positive whole-clean path is currently implemented. `Main.prepareSelected`
returns `EngineResult False False` after the loop. The green component and
model runs do not change these facts.

`connectOwnedSignal` requests disconnect once; its `GClosureNotify` attempts
callback release, marking retired only if release succeeds. A disconnect
request alone is not that notification or a completed release. The notifier
function pointer remains allocated for process lifetime; its own lifetime is
separate. `compileFilter` cancellation is a request, not completion: the
callback result must be observed after owned default-context dispatch returns
before its callback pointer, cancellable and source bytes can be released.
`retireInOrder` stops on error or when the original-D reserve is exhausted;
synchronous foreign calls have no established timing bound. Backings are kept
when the callback or provider cannot be qualified.

The broker's `stopCustody` closes lifeline, verifies the exact child pidfd,
attempts pidfd-targeted SIGKILL, polls and performs one `waitid(P_PIDFD)` reap;
its Boolean success cannot be described as a natural exit merely because the
reap succeeded. Engine monitors can force `_exit` on lifeline/D and may be
unscheduled while unsafe FFI blocks the nonthreaded runtime. A future witness
must distinguish natural exit, requested termination and forced exit.

## Concrete observation sequence for a future classification

1. Bind the session, immutable original D, held executable identity, and the
   exact directly owned engine PID/birth/pidfd and namespace incarnation. Record
   the selected provider/version and the actual helper-creation route. Treat
   scope membership, PID1 exit and provider confinement as separate facts;
   unsupported or externally spawned routes are unqualified. Kernel, provider,
   credentials and process identity assumptions require independent evidence.
2. Before or during stopping, record each outstanding filter task and signal
   closure. A cancellation/disconnect request changes intent only. Keep all
   dependent callbacks, notifier storage, objects and backings live until the
   corresponding actual completion/notification and release are observed.
3. Under the source's owned default context, observe each async task's result
   and that callback dispatch returned; only then record its callback pointer,
   cancellable and bytes retired. For each signal, separately record disconnect
   request, any already-active invocation returning, actual closure notifier,
   successful callback release, and remaining notifier lifetime. Exception,
   missing notification, unknown callback or unavailable original-D reserve
   remains quarantine, not a success or retry of a possibly freed pointer.
4. Record retirement of managers/views/session and the provider's exact helper
   route and all resources that can retain filter stores. Demonstrate the
   provider-specific confinement/retirement premise rather than equating local
   GObject unrefs or namespace exit with all external helpers gone. A partial
   provider census or external helper cannot qualify this fact.
5. Only after all helpers and callbacks can no longer use each backing, record
   release of its owning store reference and actual directory cleanup. Existing
   source deliberately retains these and has no such positive receipt today.
   A retained store/directory or an uncertain release cannot count as clean.
6. Independently observe the exact owned child exit and sole successful reap,
   plus whether termination was natural or requested/forced, all under the
   original deadline and existing reserves. A process exit or empty observed
   scope alone proves neither steps 2–5 nor complete descendant enumeration.
7. Classify each axis independently: owned child exit/reap; async callback and
   signal/notifier retirement; provider/helper confinement; backing release;
   timing; and launcher/observer integrity. Only an implementation with explicit
   trustworthy receipts for every required axis can consider a whole-clean
   classification. Missing/failed/late/ambiguous evidence stays unknown/false.
   It is not permissible to flip the existing false facts based on visibility,
   model counts, success of a local write, or an empty cgroup snapshot.

## Counterexample traces for root-owned review/tests

- Filter started -> cancel requested -> no completion -> namespace exits:
  callback and backing remain held/unknown; no whole-clean receipt.
- Signal callback active -> disconnect requested -> notifier delayed or
  release fails: later unrefs/backing removal are quarantined; do not equate
  disconnect request with retirement. An invocation admitted before disconnect
  may finish afterward.
- Local namespace exits and pidfd is reaped while an external provider/helper
  exists: the provider/backing axis is unqualified; local exit is not global
  provider cleanup.
- Exact child observed exited after a SIGKILL attempt: report the attempt and
  reap separately; unless a trustworthy status establishes cause, do not label
  the exit as either natural or caused by that signal.
- D or reserve expires during an in-flight unsafe FFI/callback: no timeout
  assertion may manufacture completion; hold/quarantine and classify unknown.
- Process/FD identity is lost, owner changed, reap fails, a cgroup query is
  unknown, or the observer cannot establish absence of unobserved helpers:
  no unrelated signal, guessed close, or false whole-clean classification.

## Model correspondence and limits

`ui-engine-lifetime`: `cancel` vs `callbackDone` vs `retireCallback`,
`disconnectSignal` vs `signalNotify` vs `retireSignal`, `observeExit` vs
`reap`, and `externalSpawn` vs direct provider. `ui-engine-topology` additionally
models broker/exec-PID1 ownership, unknown callbacks and original-D order.
Both use fixed bounded summaries and conditional evidence inputs. Their clean
witnesses show only modeled reachability under those premises; they do not
certify the real provider, memory safety, cleanup, the guest, or EARS behavior.
Do not weaken either invariant to manufacture a positive witness.
