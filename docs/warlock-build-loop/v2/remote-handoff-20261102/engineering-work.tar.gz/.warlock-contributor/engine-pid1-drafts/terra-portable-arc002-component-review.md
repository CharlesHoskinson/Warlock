# ARC002 ownership-presentation: component evidence review

Status: source-bound component evidence only; neither original scenario nor ARC002 is accepted. No Warlock window is established by this report. Preserve all 242 requirements, 417 scenarios, original deadlines, failed records, HOSTSTOP2 and `NativeOperations: []`.

## Original oracle and remaining observations

`openspec/changes/elm-desktop-pivot/specs/elm-host/spec.md:15` assigns Elm DOM and all GUI elements, Haskell Wayland surface lifetime and backend/native integration, and application-window effects to one Haskell-owned native authority. `ownership-presentation` requires a pinned Elm/native host, a view and its Wayland surface created and retired, and observation of all three ownership boundaries. `architecture-002` independently requires an application-window action and observation that only the native authority mutates the application window; its verification permits a native or bridge trace with artifact hashes and matching scenario receipts. Both remain open: observing a component test, compiling Elm, or receiving an HTTP/backend reply cannot establish the real view/surface lifetime or a window effect. `NativeOperations: []` supplies no application-window action witness.

Still needed for the declared `ownership-presentation` slice: root-owned, source/asset and host/compositor-pinned observation of the actual Warlock Elm views and corresponding Haskell/Wayland surface creation, ownership and retirement; distinguish any provider or helper from the authority; independently observe the selected process, protocol and cleanup/quarantine facts under the original D, with matching retained artifacts/receipts. A visible window alone is not proof of DOM ownership or clean retirement. Native window-effect authority for `architecture-002`, accessibility/IME, and release qualification remain separate obligations. No main-desktop change, new acceptance, or bypass is implied.

## Evidence inspected

- `.warlock-contributor/haskell-cpu-1793547720897141427/report.json`, SHA-256 `36b2a0adfcbf71c5f0449b8f55eb739757f6cad7722e8f912b3cf6f3267aaf02`, reports the actual offline build and ten of ten controlled component suites passing. `nativeAccepted`, `releaseAccepted`, and `originalAcceptance` are false. UI-origin reports 6,427 checks, seed 20261101; the test says `engineExecuted=false` and `nativeAcceptance=false`.
- Eight model pairs report 248 named cases. Broad and directed/focused campaigns are distinct: lifetime broad `witnessClean=0` while its guided witness is 10,000; RPC broad request/response, owner-event and callback witnesses are 0 while `guidedConversationStep` reports 10,000 / 9,540 / 10,000 respectively; topology broad visible-unqualified-cleanup and clean witnesses are 0 while its guided clean step reports 10,000 each. Focused scheduling excludes failure/time schedules; do not convert guided reachability into broad positive coverage, runtime liveness or cleanup proof. Private-network broad campaign uses 100,000 samples; others listed in the report use 10,000. These results do not adjudicate original scenarios.
- Actual `test-ui-engine-exec/Main.hs` covers five bounded selected-process cases: zero-session refusal, held exec for session 1 and max with sole reap, post-proof parent death, and early parent death with phase unknown. Its test-only selected image sends a private probe after `prepareEngine`; this is not the production `runEngineOnly` handshake or a window. `test-ui-engine-broker/Main.hs` exercises real socketpair/SCM and seven methods with a mock guard, including negative controls. The joined real held-child + production entrypoint + held-pidfd guard + broker startup route is not established by combining these separate tests.
- Protocol replay and boundary controls exercise typed operations, refusal/poison, and valid JSON depth/size limits through the component API. Owner/HTTP controls exercise prepared owner and private listener behavior. The WebKit control suite is component evidence; no window or provider acceptance is asserted.

## Retirement fence and preserved failure

`test-ui-origin/Main.hs:374` adds a real controller catalog request ID 97 after preceding frames and requires its matching authenticated catalog reply before the controlled retirement exception. This is an ordering fence, not a presentation acknowledgement. The selected `RetireThrows` observation reports 94 checks, owner `passed=false`, `cleanup=false`, `engineCleanup=false`, five locally forwarded commits and one action. The backend independently records `passed=true`, `cleanup=true`, five admitted callbacks, two catalog operations and `CredentialDelivered`. The owner correctly refuses a cleanup receipt despite prior successful engine-result fixture; `engineExecuted=false`.

The preceding report `.warlock-contributor/haskell-cpu-1793547235010381451/report.json`, SHA-256 `c633babd200efe1559761cf1087fa733e1d3e5a1cbee7fe10f49d15674cff01a`, remains failed and retained: `RetireThrows` reached three of four backend callbacks and `CredentialAdmissionRejected EndpointChanged`. The current fence run passes its component test; it does not retroactively change that evidence or prove the precise earlier fd replacement.

## Source binding

The report's `sourceHashes` match these inspected current files at review time:

| Source | SHA-256 |
| --- | --- |
| `runtime/src/Warlock/Ui/Owner.hs` | `a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9` |
| `runtime/test-ui-origin/Main.hs` | `dadce72f2a713950e744fb0d37586cafa7c50e26ec02276173c967906aad1943` |
| `runtime/test-ui-engine-exec/Main.hs` | `7a5c90aec72f862a06afee78fe9d16399c2f561efe555e05f7ef7f6ddc3998b0` |
| `runtime/test-ui-engine-broker/Main.hs` | `25fb10fe6f63630454da88f7cdd956c068a6d534dd6c159a27fd142a3903d0d1` |
| `runtime/src/Warlock/Ui/EngineProtocol.hs` | `c9191618a8006b9bfb1f62b09a918bd1bde409cfa7a4b9771a928493af977105` |
| `runtime/ui/Main.hs` | `5df812de63c32881bf50b5e2109e06c6259192b0f9188a0f84a22efc1d7209b0` |

Paths in the table are relative to `implementation/warlock/haskell/`. The actual main wiring deliberately returns `EngineResult False False` (`runtime/ui/Main.hs:75`): component success is not provider callback retirement or native acceptance. Review is read-only apart from this ignored draft; this worker ran no compilers, tests, models, VM, native or GPU operations. Graph navigation was stale for two inputs and all material claims above were checked against the report and source.

## Later display requalification (separate source wave)

Root reports guest run-01 and FD2-only diagnostic run-02 as explicit private-display transport refusals: no window/input, with unchanged Foot and idle restoration. A later correction captures the validated display environment before user-namespace entry; it changes the bytes covered by the earlier green component report. The separate requalification report `.warlock-contributor/haskell-cpu-1793549996721738691/report.json`, SHA-256 `18ddd1ba42ee36d021a7da63182e2cd8a476127f5100d597f61b77804ae346f1`, is failed: nine of ten suites pass; `ui-display-controls` exits 1 without timeout/forced cleanup. Its log passes the actual owned socket check and fails the forked namespace-survival check. The retained check does not report the child exception or status, so its precise cause is unknown. A missing `-with-rtsopts=-V0` on that suite is a source-based hypothesis only; diagnose the real child before drawing conclusions. The old ten-suite pass remains valid only for its original hashes, and no scenario or native acceptance follows from either run.
