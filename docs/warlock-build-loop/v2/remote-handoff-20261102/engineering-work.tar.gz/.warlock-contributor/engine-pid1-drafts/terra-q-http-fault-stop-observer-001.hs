-- ROOT ONLY; UNEXECUTED. Additive observer after the real same-owner root
-- double-fault case. The host must root Probe BEFORE start and retain its
-- worker, owner, fds and independent guardian for every outcome. In
-- particular a timeout here is Unknown, never evidence that the worker ended.
module QHttpFaultStopObserver (Probe,Observation(..),newProbe,start,observe) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,try)
import Control.Monad (unless)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Capture.Process.Persistent
 (PersistentOwner,StopBudget,StopReceipt(..),requestSessionStop)

data Observation = WaitingUnknown | ExceptionUnknown | RetainedStop deriving (Eq,Show)
data Probe = Probe PersistentOwner StopBudget (MVar ()) (MVar ())
 (MVar (Either SomeException StopReceipt)) (IORef (Maybe ThreadId)) (IORef Bool)
newProbe :: PersistentOwner -> StopBudget -> IO Probe
newProbe owner budget = Probe owner budget <$> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newIORef Nothing <*> newIORef False
start :: Probe -> IO ()
start (Probe owner budget begin entered done worker used) = mask $ \_ -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 unless fresh (ioError (userError "fault-stop probe reused"))
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try $ unmask $ do
   readMVar begin
   putMVar entered ()
   requestSessionStop owner budget
  putMVar done result
 writeIORef worker (Just tid)
 putMVar begin ()
-- micros bounds observation only, not a new operation or cleanup deadline.
-- A false no-live or signal-sent receipt is a hard failure, never acceptance.
observe :: Int -> Probe -> IO Observation
observe micros (Probe _ _ _ entered done _ _) = do
 started <- timeout micros (readMVar entered)
 case started of
  Nothing -> pure WaitingUnknown
  Just () -> do
   result <- timeout micros (readMVar done)
   case result of
    Nothing -> pure WaitingUnknown
    Just (Left _) -> pure ExceptionUnknown
    Just (Right StopAlreadyRequested) -> pure RetainedStop
    Just (Right (StopUncertain _)) -> pure RetainedStop
    Just (Right other) -> ioError (userError ("false or unexpected stop receipt: " ++ show other))
