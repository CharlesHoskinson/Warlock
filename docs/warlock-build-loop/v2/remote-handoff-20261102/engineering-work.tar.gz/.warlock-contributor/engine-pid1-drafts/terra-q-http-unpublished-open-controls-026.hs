{-# LANGUAGE OverloadedStrings #-}
-- ROOT ONLY; UNEXECUTED. This deliberately faults after a real open returned
-- and before the descriptor was stored. The original numeric fd is UNKNOWN.
-- Independent guardian must contain the isolated host on all paths; never
-- guess, retry, free or assert cleanup of that descriptor. Retain the Case.
module QHttpUnpublishedOpenFault (Case,newCase,runCase) where
import Control.Concurrent (ThreadId,forkIOWithUnmask)
import Control.Concurrent.MVar
import Control.Exception (SomeException,mask,throwIO,try)
import Control.Monad (unless)
import Data.IORef (IORef,newIORef,readIORef,writeIORef,atomicModifyIORef')
import System.Directory (doesPathExist)
import System.FilePath (isAbsolute)
import System.Timeout (timeout)
import Warlock.Backend (PersistentBackendOwner,PersistentBackendRun,newPersistentBackendOwner,
 loadPersistentBackendConfig,runPersistentBackend,persistentBackendCounts,persistentBackendStartupRefusal,
 qaDrainSlots,qaDrainActive,qaDrainStopD,qaDrainCloseRoot,qaDrainReceipts)
import Warlock.Bootstrap (newCurrentSessions)
import Warlock.Capture.Process.Bootstrap (ToolError(..))
import qualified Warlock.Capture.Process.Persistent as P
import Warlock.Platform.Resolver (RootPart(..))
import Warlock.Platform.Resolver.Internal (QaRootSlot(..),qaBeforeFirstOpenPublication)

data Case = Case PersistentBackendOwner (MVar ()) (MVar (Either SomeException PersistentBackendRun))
 (IORef (Maybe ThreadId)) (IORef Int) (IORef Bool)
newCase :: IO Case
newCase = do
 sessions <- newCurrentSessions
 budget <- either (ioError . userError . show) pure (P.stopBudgetMicros 1000000)
 owner <- newPersistentBackendOwner sessions budget
 Case owner <$> newEmptyMVar <*> newEmptyMVar <*> newIORef Nothing <*> newIORef 0 <*> newIORef False
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError label))
within :: String -> IO a -> IO a
within label action = timeout 5000000 action >>= maybe (ioError (userError (label ++ ": retain Case and guardian"))) pure
runCase :: Case -> FilePath -> IO ()
runCase (Case owner start completed worker faultCount used) path = mask $ \restore -> do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single isolated case" fresh
 exists <- doesPathExist path
 check "real config" (isAbsolute path && exists)
 loaded <- restore (within "same-owner config" (loadPersistentBackendConfig owner path))
 check "config loaded" (loaded==Right ())
 qaBeforeFirstOpenPublication $ do
  atomicModifyIORef' faultCount (\n -> (n+1,()))
  ioError (userError "injected after actual open, before owner slot publication")
 tid <- forkIOWithUnmask $ \unmask -> do
  result <- try (unmask (takeMVar start >> runPersistentBackend owner))
  putMVar completed result
 writeIORef worker (Just tid)
 putMVar start ()
 restore $ do
  actual <- within "actor result" (readMVar completed) >>= either throwIO pure
  faults <- readIORef faultCount
  slots <- qaDrainSlots
  active <- qaDrainActive owner
  stopD <- qaDrainStopD owner
  receipts <- qaDrainReceipts
  check "unknown slot and entered close reservation remain retained" $
   faults==1 && slots==Just (QaSlotUnknown,QaSlotUnused) && active==Just 1 &&
   (case stopD of P.StopDeadlineLatched _ -> True; _ -> False) &&
   receipts==[Left CleanupUncertain] &&
   persistentBackendStartupRefusal actual==Just P.StartupAdmissionUnknown && persistentBackendCounts actual==(0,0)
  duplicate <- within "same owner refuses repeat" (qaDrainCloseRoot owner RootAnchor)
  after <- qaDrainSlots
  check "no repeated attempt and no guessed descriptor" (duplicate==Left OwnerBusy && after==slots)
