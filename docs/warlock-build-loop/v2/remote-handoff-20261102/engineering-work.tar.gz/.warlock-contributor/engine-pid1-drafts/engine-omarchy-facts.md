# Engine PID 1 Split: Omarchy Guest, Library, QA Trace & Source Inventory Facts

Status: **preparation draft only** (`2026-11-01`). This document records read-only source observations, guest build/runtime constraints, and integration proof obligations for the proposed broker / `exec` PID 1 `warlock-ui-engine` split. It is **not** an implementation, compiler/test/model/VM execution result, original-scenario acceptance, or release approval.

All 242 requirements and 417 scenarios (`15/242` whole, `39/417` scenarios; only the capability scenario of `ARC-024` accepted, whole `ARC-024` partial/OPEN, `DEL-014` OPEN), original absolute `CLOCK_MONOTONIC` deadlines `D` (`28s` MVP isolated trial, `15s` positive security, `4.5s` `< 5.0s` negative security), retained failure records (`selected 79290` GLib `pthread_create` `EINVAL`/`SIGTRAP` on `security-negative-04-trace`, `01`/`03` missing child receipts, `HOSTSTOP2` `EngineResult False False`), main desktop `Foot`, and guest `omarchy-shell` idle state remain strictly preserved. Warlock-authored production code remains **Elm and Haskell (`.hs`/`.hsc`) only**; no separate C helper binary or non-Elm/Haskell production component is authorized.

---

## 1. Audited Frozen Source Baseline (Read-Only SHA-256)

Local HEAD at review: `0d0bfd8595680096c4c1c145f553be0931cdd2f0` (*Refuse incompatible GTK thread namespaces before native initialization*; user-reported 7 protected runtime suites PASS + real guest controlled refusal). Kernel/GLib/loader behaviors below that have not yet been exercised in an isolated split binary are explicitly marked as **hypotheses requiring Root-owned runtime verification**.

Paths relative to `/home/charl/code/Warlock/`:

```text
3a8504a5dd8fb4dac2b7c721da5e141cf571dae18f5c814dfd11bb5ebb8f3e2f  implementation/warlock/haskell/runtime/src/Warlock/Ui/ThreadNamespace.hs
b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a  implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs
a7e6cfdbe7fc780e7e3137a58dedff3a83ebfa9edd07f2df64455bf05005616e  implementation/warlock/haskell/runtime/ui/Main.hs
57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6  implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc
e8fa295690356aef8621e04ad5d28665dfe195189baa7536b76245b295696070  implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc
2205761421203a631a1dc861c55501c8356e5630e96de3206dc00f986531fd2b  implementation/warlock/haskell/runtime/src/Warlock/Ui/PrivateNetwork.hsc
3f47831db3149b3ede3904b414812efb0da514f0d8eeaa9f7aa5b345ff4dca92  implementation/warlock/haskell/runtime/src/Warlock/Ui/Display.hs
e737412f400ae5a9d53625152a23bbc8883bb6558d85770dd8e14bcb4bb8f969  implementation/warlock/haskell/runtime/src/Warlock/Ui/Config.hs
e6100f7ae8b5512c66b9cbde2a81a167719f6415c1e92fc33570974d5b69ad2f  implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs
985f63f65079b1bbc8dc997f8188bc4051b48015c55b36117d7759a34dc9fa07  implementation/warlock/haskell/runtime/runtime.cabal
578448d677c41473d1c2f1095cc97d7ad791b4d0278c75dcace0a5e0d317d949  implementation/warlock/haskell/runtime/test-ui-security/Parent.hs
c373717c77ae9dab682b57c112ef5ed1d934a8e2def63fb207d9bd6d0b1ff954  implementation/warlock/haskell/runtime/test-ui-security/Main.hs
1bd4e87275a0c3b69839a0dd7ef3351405350754afafa57a15ffb738a9af717a  implementation/warlock/haskell/held-document/src/Warlock/Platform/Executable/Internal.hs
62775261c983b9b2f8f256734c731fee492f1f4a327ceab845370bd6e82da416  implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Whitelist.hsc
61d9a84a4a41037fcf6464fa56153c9b2ec26986be676d2f84fb21d9ff14c2c5  tools/omarchy_ui_mvp.py
```

---

## 2. Engine Child `exec` / PIDns / GTK4 / Wayland Constraints & Independent Contracts

### 2.1 Root Cause Recap & `ThreadNamespace` Guard
- In `security-negative-04-trace`, `startCustody` (`EngineCustody.hsc`) called `unshare(CLONE_NEWPID)` in the single-process owner (`pid 79290`), diverging `/proc/thread-self/ns/pid` from `/proc/thread-self/ns/pid_for_children`. Subsequent `gtk_init` -> GLib `g_system_thread_new` -> `pthread_create` (`clone3` with `CLONE_THREAD`) failed with `EINVAL` per Linux `clone(2)` and aborted via `g_error` (`SIGTRAP`) before writing any child receipt.
- `Warlock.Ui.ThreadNamespace.requireThreadCompatibleNamespace` (`ThreadNamespace.hs:1-50`, called at `WebKit.hs:379`) now checks `(dev, ino)` equality of `/proc/thread-self/ns/pid` and `/proc/thread-self/ns/pid_for_children` and fails closed before `gtkInit`.
- In the proposed split, the broker remains nonthreaded and never initializes GTK/WebKit. The direct child enters the new PID namespace as local **PID 1** (`ns/pid == ns/pid_for_children`) and `exec`s the pinned `warlock-ui-engine` ELF image, satisfying `requireThreadCompatibleNamespace` prior to `gtkInit`.

### 2.2 Alignment with Independent Process, Credential, Held-Exec & Callback Contracts
1. **Sole Reaper Authority (`process-custody` `Owner`)**:
   - `Warlock.Capture.Process.Owner` in the broker is the **sole** lifecycle owner, signaler, and reaper of the direct engine child (retaining group-before-final-wait discipline and explicit cleanup uncertainty propagation). No competing `EngineCustody` `waitid`/signal/reap path or second `ProcessHandle` may operate on the engine child.
   - Inside the `exec`'d PID 1 `warlock-ui-engine`, `SIGCHLD` must be explicitly reset to `SIG_DFL` before `exec` (note `Whitelist.hsc:122` resets `[SIGPIPE, SIGINT, SIGQUIT, SIGHUP, SIGTERM]` to `SIG_DFL` but currently **omits `SIGCHLD`**), and engine code must **never** issue wildcard `waitpid(-1)` / `waitid(P_ALL)` calls that could steal `WebKitNetworkProcess` / `WebKitWebProcess` / `bwrap` exit statuses from GLib `GChildWatchSource`.
2. **Per-Fragment `SCM_CREDENTIALS` Authentication (Broker Ingress)**:
   - Pre-fork `socketpair` `SO_PEERCRED` identifies the creator (broker), **not** the post-`exec` engine sender. Broker must enable `SO_PASSCRED` on its `CLOEXEC` Unix socket endpoint before any peer bytes can be queued (`Warlock.Transport.PeerCredentials` wrapped in a narrow `Protocol`-owned `EngineIngress` facade) and validate `SCM_CREDENTIALS` on **every received fragment**: `ucred.pid` (translated by the kernel into the broker's outer PID namespace) must equal the broker's retained direct-child host PID, `uid`/`gid` must match the established mapping, and final admission must recheck `pidfd` incarnation, direct-child liveness, active scope, and original `D`.
   - Child-side `getppid() == 0` (or translated `PID 0` credentials when the parent resides in an ancestor PID namespace) is **never** proof of parent liveness or parent authentication.
3. **Held Executable Pinning, Private `/proc` & `Whitelist.hsc` Gap (Hypotheses Marked)**:
   - **Existing source fact**: `Whitelist.hsc:69-133` wraps path-based `posix_spawn` with `dup2` + `addclosefrom(floorFd)` (`L115`) and has no `CLONE_NEWPID`/`CLONE_NEWNS`, child mount, or `PR_SET_PDEATHSIG` hook. `borrowHeld` (`Executable/Internal.hs:127-139`) returns `"/proc/" ++ show brokerPid ++ "/fd/" ++ show fd`, which worked under `posix_spawn` only because the child still saw the outer `/proc` mount when resolving `<brokerPid>`.
   - **Kernel capability & `/proc` hypothesis (requires Root runtime verification)**: `PrivateNetwork.hsc:113` maps UID `1000 -> 1000` (`euid == 1000 != 0` inside `CLONE_NEWUSER`). Under Linux `capabilities(7)` (`cap_bprm_creds_from_file`), `execve()` by a non-root `euid` with empty file/ambient capabilities clears `CapPrm` and `CapEff` to `0`. While this yields least-privilege post-`exec` GTK4/WebKitGTK (`CapEff == 0`, `CAP_SYS_ADMIN` and `CAP_NET_ADMIN` dropped), it means `unshare(CLONE_NEWNS)` + `mount("none", "/", NULL, MS_REC | MS_PRIVATE, NULL)` + `mount("proc", "/proc", "proc", MS_NOSUID | MS_NODEV | MS_NOEXEC, NULL)` (needed so GLib/WebKit/`bwrap` `/proc/self` and `/proc/1` lookups inside PIDns `1` do not read host PID `1` `systemd` metadata) must execute **pre-`exec`** inside an owned Haskell `.hsc` spawn pathway.
   - **Held-image `exec` constraint**: Once inner `/proc` is mounted in the child, outer `"/proc/<brokerPid>/fd/<fd>"` no longer resolves (`ENOENT`), and an unconditional `close_range(floorFd, ~0U, 0)` before `exec` would close the borrowed executable FD in the child. The owned `.hsc` spawn pathway must retain the `HeldExecutable` lease across launch, exclude only the fixed child FD manifest (`0, 1, 2` harmless `/dev/null` or approved diag sink; `3` child RPC socket end via controlled pre-`exec` inheritance; `4` read-only parent lifeline pipe) plus any dedicated `O_CLOEXEC` held-image scratch FD required for `execveat(execScratchFd, "", argp, envp, AT_EMPTY_PATH)` (executable-format dependent: valid only for pinned native `\x7fELF` binaries with guest `/lib64/ld-linux-x86-64.so.2`, never `#!` scripts — must be verified by Root on guest). Immediately upon engine startup, before GTK or any thread/helper creation, the engine must re-arm and verify `FD_CLOEXEC` on its inherited RPC (`fd 3`) and lifeline (`fd 4`) descriptors and verify its exact FD census (zero backend `fd 0`, zero HTTP listeners, zero lifeline writer).
4. **Parent-Death Race & Lifeline**:
   - Pre-`exec` child setup installs `prctl(PR_SET_PDEATHSIG, SIGKILL)` (checking `== 0`) and verifies the read-only lifeline (`poll` for `POLLIN | POLLHUP == 0`) both after installation and immediately before sending startup-ready, then monitors the lifeline continuously on the GLib main context. Broker retains the sole `FD_CLOEXEC` lifeline writer; note Linux `execve` clears `pdeath_signal` only on setuid/setgid/capability-elevating binaries, which must still be verified directly by Root parent-death kill controls before/during/after `exec`.
5. **Read-Only Observation Callbacks & RPC Framing (Peer Proposals Reconciled for Root Selection)**:
   - Broker retains `fd 0` (`Native`), `PeerNetwork` witness, all three localhost HTTP listeners, and sole Elm/Owner policy authority (`nativeOperations: []`).
   - All three `Owner.hs:33-34,106` observation callbacks (`uiShouldStop`, `uiRemainingMicros`, `uiLastProjection`) plus `TrustedOwnerEvent` (`topology`, `dismiss`, `escape`, `reflow`) flow over the framed IPC channel with standalone `lastProjection <= 393,216` B (`3 * 131,072` B, depth `<= 15`), MVP topology `<= 295` B, canonical `Word64` decimal counters, zero `Owner` locks held across IPC, stale application refusal kept distinct from permanent transport poisoning, and all operations consuming the single original monotonic `D`.
   - **Envelope framing reconciliation item for Root**: `engine-rpc-budget.md` proposes a fixed `16`-byte binary header (`393,232` B max physical frame), whereas `EngineProtocol.hs` (`d0228c5...`) encodes a `4`-byte header-length prefix + `<= 512`-byte JSON header + `<= 393,216`-byte standalone payload (`393,732` B max inner envelope before outer stream length framing). Root must select one canonical outer framing prior to source integration.

### 2.3 GTK4, GHC RTS, Wayland & Guest QMP Ownership Constraints
- **GHC RTS / GTK Thread Affinity**: Link `warlock-ui-engine` non-threaded (or with `-with-rtsopts=-V0` if threaded RTS is ever required by a dependency, though non-threaded RTS is strongly preferred) so every GTK4/WebKitGTK FFI call and `FunPtr` signal callback runs on the single OS thread owning `g_main_context_default()`, preserving callback cancellation/drain before cleanup under `D`.
- **Wayland Socket Visibility Across `CLONE_NEWNET`**: Filesystem `AF_UNIX` (`${XDG_RUNTIME_DIR}/${WAYLAND_DISPLAY}`, `/run/user/1000/wayland-1`) is scoped to the VFS mount namespace rather than the network namespace (unlike abstract `@` sockets). Pass only `Display.hs`-validated `LANG=C`, `LC_ALL=C`, `XDG_RUNTIME_DIR`, and `WAYLAND_DISPLAY`; pass **zero** `WEBKIT_DISABLE_*`, `*PROXY*`, `SNAP*`, or `FLATPAK_ID` variables (`WebKit.hs:202-214`).
- **Hyprland / QMP Outer-PID Correlation**: Guest `hyprctl clients -j` reports `client.pid` in the **outer host PID namespace** (`PID_ENGINE`, matching `NSpid:\t<PID_ENGINE>\t1` in `/proc/<PID_ENGINE>/status`, verified together with `/proc/<PID_ENGINE>/stat` field 22 `starttime` birth and membership in the owned `.scope/cgroup.procs`) — **not** `PID_BROKER` and not inner PID `1`. Every QMP click/key must re-verify positive remaining `D`, live `PID_ENGINE` + birth, owned `.scope`, mapped client geometry, and active focus immediately prior to injection, never touching `Foot` or synthesizing DOM events.

---

## 3. Old QA `trace` 64-Row Eviction (`Owner.hs:130`) & `vm-security` Remaining Items

1. **Confirmed 64-Row Trace Eviction Mechanism**:
   - In `security-negative-04-trace/producer/ui.json`, `security-negative-manifest-02.json` pointed `controller` to `HttpMain+probes.js` (`1,070,141` B) and `bar`/`popup` to full `HttpBar.html`/`HttpPopup.html`.
   - `UiHttp.elm:111` (`Time.every 66 PollTick`) causes `HttpBar` + `HttpPopup` to issue `~30 req/s` of `GET /events` (`~120` trace entries in `4.0s`).
   - `Owner.hs:130` (`recordTrace` -> `take 64 (entry : current)`) retains only the newest 64 HTTP trace entries, evicting load-time `POST /commit` probe reports from `probes.js` after `~2.13s` (`64 / 30 s`).
2. **QA-Only HTML Fixture Remedy (Zero Production Weakening)**:
   - Keep `Owner.hs:130` (`take 64`) and the `4.5s` negative deadline (`< 5.0s` `Channel.hs:128` native correlation timeout) completely unchanged.
   - Stage three minimal compiler-shaped QA HTML files for `security-negative` that satisfy `Warlock.Platform.Document` (`Document.hs:53-89`: exact `<!DOCTYPE html><html><head><meta charset="utf-8"><title>...</title></head><body><div id="app"></div><script>...</script></body></html>` with **zero trailing newline** after `</html>` and `<title>` matching `[A-Za-z0-9_.]{1,128}`):
     - `qa-bar.html` / `qa-popup.html`: `"use strict";` (zero background `/events` polling).
     - `qa-controller.html`: sets `window.WARLOCK_QA_REPORT_ROUTE = "/commit"; window.WARLOCK_QA_REMOTE_URL = "<permissive.remoteURI>";` followed by `probes.js` (`5,210` B), generating `~13` total trace rows (`<< 64`) over `4.5s`.
3. **Remaining `vm-security` Proof Obligations**:
   - Retain the passing permissive 5-tag positive control (`remoteHits >= 1`) and observe real negative `01` (production CSP) and `03` (mismatched remote port) **with actual child receipts**, `executedTags`, `refusedTags`, `remoteHits == 0`, and clean retirement within each case's fixed `4.5s` deadline. Zero tags or missing child receipts never prove CSP enforcement.
   - `Parent.hs` (`578448d6...`) `StrictJson` manifest parser requires exact field order `["path", "device", "inode", "size", "sha256"]` with decimal strings for `device`, `inode`, and `size`.

---

## 4. Source, Binary, Cabal & Guest DSO Inventory Requirements

1. **`implementation/warlock/haskell/runtime/runtime.cabal` (`985f63f6...`)**:
   - Remove `webkitgtk-6.0, gtk-4, gobject-2.0, gio-2.0, glib-2.0, soup-3.0` `pkgconfig-depends` and GTK/WebKit modules from `executable warlock-ui-owner` and `executable ui-security-child` so the broker binary contains **zero** GTK/WebKit/GLib `.init_array` or thread-spawning library dependencies.
   - Add dedicated `executable warlock-ui-engine` owning GTK4/WebKitGTK `pkgconfig-depends` and `Warlock.Ui.{WebKit,Mvp,ThreadNamespace}` under a single reviewed engine-only mode shared by `warlock-ui-owner` and `ui-security-child`.
2. **Configuration, Manifest & Helper Inventory (`Config.hs`, `Parent.hs`, `tools/omarchy_ui_mvp.py`)**:
   - Extend `UiConfig` (`Config.hs`, `e737412f...`) and `Parent.hs` (`578448d6...`) to require a pinned `HeldExecutable` + `ancestors` directory chain for `warlock-ui-engine` (`O_NOFOLLOW`, verified `device`/`inode`/`size`/`sha256`).
   - Update `tools/omarchy_ui_mvp.py` (`61d9a84a...`):
     - Extend `MVP_SOURCE_PATHS` closure (currently 93 repo inputs; 73 Elm files unchanged) with `ThreadNamespace.hs`, `Native.hs`, `Http.hs`, `Policy.hs`, `Protocol` credential/engine modules, process-custody engine spawn module, and `warlock-ui-engine` `Main.hs`.
     - Add `--ui-engine-bin` pinning (`O_NOFOLLOW` held FD + `ancestors`) to `cmd_guest_config` and update `print-guest-recipe` / `print-root-plan` to stage and verify all **three** executables (`warlock-ui-backend`, `warlock-ui-owner`, `warlock-ui-engine`).
     - Isolate `os.readlink(f"/proc/{pid}/exe")` in its own `try/except OSError` when collecting guest `/proc` census records: an `exec`'d PID 1 inside private `CLONE_NEWUSER`/`CLONE_NEWNS` can return `EACCES` on outer `/proc/<pid>/exe` to an unprivileged observer, which must be recorded explicitly without aborting `status`/`stat`/`cgroup` capture or masking scope state as empty.
3. **Guest Arch GHC `9.6.7` Dynamic Build & DSO Provenance**:
   - Guest Arch GHC `9.6.7` ships `.dyn_hi`/`.so` libraries only (vanilla `.hi`/`.a` absent). Both `cabal build` and `cabal list-bin` must pass `--offline --enable-shared --disable-library-vanilla --enable-executable-dynamic` for `warlock-ui-backend`, `warlock-ui-owner`, `warlock-ui-engine`, `ui-security-parent`, and `ui-security-child`.
   - Before any isolated guest trial, Root records immutable SHA-256s, `readelf -d` (`NEEDED` + `RUNPATH`, confirming broker executables do **not** list `libwebkitgtk-6.0.so` or `libgtk-4.so`), and `env -i LANG=C LC_ALL=C ldd` resolution for all staged executables, `/lib64/ld-linux-x86-64.so.2`, Cabal-built `libHSwarlock-*.so` DSOs, and guest system WebKitGTK/GTK4/GLib/libsoup DSOs in a fresh outside-repository evidence directory without overwriting prior binaries or evidence.
