# ARC002 surface lifetime and DEL021 closure — source review

This is a source-bound preparation review, not a native/original/release acceptance or a new gate. Preserve the original 242 requirements/417 scenarios, deadlines, HOSTSTOP2, empty `nativeOperations`, historical evidence and all failed runs. Root reported an actual owned Elm window and catalog, followed by the old idle timeout; that observation does not establish complete lifetime/authority/normal cleanup. This worker ran no compiler, test, model, VM or native tool.

## Exact original oracles

* `docs/warlock-build-loop/v2/requirement-ledger.json:32-60` retains `ELM-ARC-002` / `ownership-presentation`: "Elm owns DOM state, native host owns surface lifetime and native authority alone owns application effects". Its disposition remains partial. The separate `architecture-002` oracle is "only native authority mutates the application window" and remains unadjudicated.
* The same ledger `:2664-2676` retains `ELM-DEL-021` / `delivery-021`: "closure receipts prove order and normal termination". Its disposition remains partial; historical source-bound picker shutdown evidence, original 500ms drain and applicable normal-cleanup requirements are not altered by this review.

## Observable lifetime events

`runtime/ui/Warlock/Ui/Mvp.hsc:845-907` attaches the three WebKit views to the owned GTK window and calls `gtkWindowPresent`. A subsequent `ViewMapped` is an actual observation requiring GTK widget mapping, non-null native/surface handles, GDK surface mapping and positive measured dimensions; it is not derived from requested size. `stepFreshMap` (`:1040-1050`) emits the native owner topology and writes the mapped state only when that event is accepted. A visible compositor-mapped, owned PID1 window plus current Elm contents is a useful positive observation of this path, not proof of application-effect authorization or lifetime closure.

On a mapped close/unmap transition, `stepRetireOrClose` (`:965-1030`) can emit the current lease-bound dismiss, then an empty `OwnerTopology` at the next revision, committing the retired topology only on accepted response. A stale dismiss is not treated as success and does not suppress the empty topology; other refusal remains fatal. Do not assert an accepted topology event until the actual owning-route receipt is observed. The ledger oracle does not prescribe this particular packet as its sole proof.

`WebKit.hs:458-476` can leave its loop directly on a stop/deadline condition and proceed to cleanup. `retireMvpWindow` (`Mvp.hsc:1146-1160`) marks retirement, disconnects signals, and destroys/unrefs the GTK container only after required closure notifiers; it does not itself emit empty topology. Thus the source does not establish an accepted empty topology on every deadline-stop path. This is a concrete path distinction, not an observed violation or a new mandated packet. A visible unmap/window disappearance, socket close or pidfd exit alone does not prove ordered closure of all owned resources.

## Missing receipt and next implementation

1. `Mvp.hsc:711-756` ties handler free to `GClosureNotify`, disconnects signal closures before dependent GTK object destruction, and quarantines objects on uncertainty. `WebKit.hs:294-360` retains async filter callback, cancellable, bytes and backing until completion; cancellation is not completion. `retireInOrder` checks the existing original D and quarantines the remaining LIFO chain on failure/uncertainty; synchronous foreign-call duration is not proven by this check. These are local mechanisms, not whole-provider receipts.
2. `WebKit.hs:389,424-431,480-491` populates filter-store `backings`, reads them at retirement and requires `null retained` for `wholeClean`; this source has no clearing/release path. `runWebKit` calls `runWebKitInternal Nothing`; `EngineCustody.hsc:278-295` starts from `CallbackPending`, `ProviderUnqualified`, `custodyBeforeDeadline=False`, and the current WebKit update supplies only setup/exit/owner facts. A namespace exit, local reference unref, or successful document load cannot fill those missing facts.
3. The current split has no authenticated terminal cleanup/result message in `EngineProtocol.hs:51-56`: it carries stop/remaining/projection and owner event request/replies. `runtime/ui/Main.hs:73-75` intentionally returns `EngineResult False False` and does not interpret an observed window as retirement. Therefore child-local cleanups and callback outcomes cannot currently be conveyed as a qualified terminal result to the broker. Preserve this conservative result until the facts exist; do not substitute a boolean or silently mark success.

The next concrete implementation is an ordered, identity- and source-bound terminal receipt over the already authenticated owner/engine channel (or another reviewed existing custody path), coupled to actual local signal disconnect/`GClosureNotify`, async callback completion or cancellation with observed drain, filter store/backing release, the qualified provider/helper confinement route, and independent sole-reaper/pidfd exit observation. Bind every part to the same owned engine/session and original absolute D; verify it before success, never introduce a successor deadline, inferred capability or replay. Treat absent, late, mismatched, duplicate, failed, or ambiguous receipts as Unknown/failed and retain unsafe backing where needed. The exact encoding and implementation require source review and tests; this statement introduces neither a new approval requirement nor a permanent timer budget.

## Existing-oracle checks for root

* Observe an owned mapped surface and Elm content, then a real close/unmap or actual supported lifecycle action. Capture the causal native owner event, matching scope/generation and state transition; preserve physical input/authority and nativeOperations `[]`. A static screenshot or component trace alone does not accept ARC002.
* In the same owning path, retain ordered receipts for cancel/drain, callback completion/closure notify, dependent object/store release, provider-helper retirement, owner and selected-process cleanup/reap. Independently observe normal exit before the original D. Exercise failure/late/missing/duplicate receipts and verify quarantine, uncertainty, no replay and no false `EngineResult` clean claim. Do not change the original DEL021 closure oracle or historic 500ms drain.
* Only root executes and records protected/native/VM checks. Source/model counts and provisional successful rendering are separate from original and release acceptance.

## Source SHA-256

```
b1f00b0db2370fee7442cbfa30ebfb6ed06911a704b4299a4f1f61f3650ea79a  implementation/warlock/haskell/runtime/ui/Warlock/Ui/WebKit.hs
57b150fd2b9652049141a911d75126d1e88452cc14b57462104e327067e5dce6  implementation/warlock/haskell/runtime/ui/Warlock/Ui/Mvp.hsc
5028eed1eae2df6f066d3868777af686aa0ddb889a651159b26cb3369c4129de  implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineCustody.hsc
941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080  implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineEntrypoint.hs
50d9ebd707026536cb95054414cf587602adb2c845ca8f207145e999c757eda7  implementation/warlock/haskell/runtime/ui/Main.hs
c9191618a8006b9bfb1f62b09a918bd1bde409cfa7a4b9771a928493af977105  implementation/warlock/haskell/runtime/src/Warlock/Ui/EngineProtocol.hs
```

## Normal-termination receipt detail

On the reviewed `EngineCustody.hsc:245-260` path, `stopCustody` closes the lifeline, verifies the owned pidfd and unconditionally attempts pidfd-targeted `SIGKILL`, discarding the signal result. `reapChild :162-169` checks only that `si_pid > 0`; it does not retain `si_code` or exit status. Its Boolean can indicate an owned reap, but cannot establish a natural/normal exit or whether the attempted signal caused exit. The concrete missing DEL021 fact is a trustworthy termination-path and exit-status receipt from the same sole reaper, with graceful/natural, forced, attempted-but-uncertain and unknown outcomes kept distinct. A voluntary normal-exit path must operate under the same original D and preserve existing owned pidfd/child protections; no extra permanent timeout or approval is introduced. The peer's independent witness-sequence review reached the same separation. No execution was performed.
