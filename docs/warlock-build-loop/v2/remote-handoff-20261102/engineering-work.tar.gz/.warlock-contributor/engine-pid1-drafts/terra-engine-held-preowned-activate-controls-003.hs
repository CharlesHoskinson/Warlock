-- ROOT-ONLY source fixture, not executed. Requires v15 + opaque 002 + preowned
-- 003 and the rebased held-document borrow-qa flag/seam. Each Probe, exact
-- resolver-held image, pre-owned capability and worker must stay rooted by Root;
-- an independent guardian and verified fixture ancestors remain required.
module HeldPreownedActivateControls (Probe, newProbe, runPositive, runCancel, runInterrupted) where

import Control.Concurrent (ThreadId, forkFinally, killThread)
import Control.Concurrent.MVar
import Control.Exception (SomeException, finally, mask, mask_)
import Control.Monad (unless, void)
import Data.IORef
import System.Timeout (timeout)
import Warlock.Platform.Executable
 ( HeldExecutable, HeldBorrow, LeaseError(..), prepareHeldBorrow, activateHeldBorrowWhile
 , tryHeldBorrowNotAcquired, tryReleaseHeld, retireHeld, qaHoldHeldGate, qaHeldBorrowCount )

type Result = Either SomeException (Maybe (Either LeaseError FilePath))
data Probe = Probe
 { image :: IORef (Maybe HeldExecutable), capability :: IORef (Maybe HeldBorrow)
 , ownerWorker :: IORef (Maybe ThreadId), gateWorker :: IORef (Maybe ThreadId)
 , killerWorker :: IORef (Maybe ThreadId), entered :: MVar (), unlock :: MVar ()
 , busy :: MVar (), proceed :: MVar (), gateDone :: MVar (Either SomeException ())
 , ownerDone :: MVar Result, killerDone :: MVar (Either SomeException ())
 , cancelled :: IORef Bool, used :: IORef Bool }
newProbe :: IO Probe
newProbe = Probe <$> newIORef Nothing <*> newIORef Nothing <*> newIORef Nothing
 <*> newIORef Nothing <*> newIORef Nothing <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar
 <*> newEmptyMVar <*> newIORef False <*> newIORef False

check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("preowned activation: " ++ label)))
within :: String -> IO a -> IO a
within label action = timeout 4000000 action >>= maybe (ioError (userError (label ++ ": retain probe/guardian"))) pure
prepare :: Probe -> IO HeldExecutable -> IO (HeldExecutable,HeldBorrow)
prepare p supplier = mask $ \restore -> do
 old <- atomicModifyIORef' (used p) (\v -> (True,v))
 check "single-use probe" (not old)
 held <- restore supplier
 writeIORef (image p) (Just held)
 cap <- prepareHeldBorrow held
 writeIORef (capability p) (Just cap)
 notYet <- tryHeldBorrowNotAcquired cap
 check "new capability has no terminal cancellation receipt" (not notYet)
 pure (held,cap)

runPositive :: Probe -> IO HeldExecutable -> IO ()
runPositive p supplier = mask $ \restore -> do
 (held,cap) <- prepare p supplier
 result <- restore (activateHeldBorrowWhile cap (pure False) (pure ()))
 count <- qaHeldBorrowCount held
 again <- activateHeldBorrowWhile cap (pure False) (pure ())
 release <- tryReleaseHeld cap
 after <- qaHeldBorrowCount held
 close <- retireHeld held
 check "actual one-shot increment, release and retirement" $
  (case result of Just (Right path) -> not (null path) && head path == '/'; _ -> False)
  && count == Just 1 && again == Just (Left LeaseBusy) && release == Just True
  && after == Just 0 && close == Right ()

runCancel, runInterrupted :: Probe -> IO HeldExecutable -> IO ()
runCancel = runBlocked False
runInterrupted = runBlocked True
runBlocked :: Bool -> Probe -> IO HeldExecutable -> IO ()
runBlocked interrupt p supplier = mask $ \restore -> do
 let finish = do
      void (tryPutMVar (proceed p) ())
      void (tryPutMVar (unlock p) ())
      let waitOne ref done = do
           current <- readIORef ref
           case current of Nothing -> pure (); Just _ -> void (timeout 3000000 (readMVar done))
      waitOne (gateWorker p) (gateDone p)
      waitOne (ownerWorker p) (ownerDone p)
      waitOne (killerWorker p) (killerDone p)
     run = do
      (held,cap) <- prepare p supplier
      _ <- mask_ $ do
       tid <- forkFinally (restore (qaHoldHeldGate held (putMVar (entered p) ()) (readMVar (unlock p)))) (putMVar (gateDone p))
       writeIORef (gateWorker p) (Just tid)
       pure tid
      within "real held gate locked" (readMVar (entered p))
      _ <- mask_ $ do
       tid <- forkFinally (restore (activateHeldBorrowWhile cap (readIORef (cancelled p))
        (putMVar (busy p) () >> readMVar (proceed p)))) (putMVar (ownerDone p))
       writeIORef (ownerWorker p) (Just tid)
       pure tid
      within "activation has observed held gate busy" (readMVar (busy p))
      interim <- tryHeldBorrowNotAcquired cap
      check "active operation cannot claim no-borrow" (not interim)
      if interrupt then do
       target <- readIORef (ownerWorker p) >>= maybe (ioError (userError "missing worker")) pure
       _ <- mask_ $ do
        tid <- forkFinally (killThread target) (putMVar (killerDone p))
        writeIORef (killerWorker p) (Just tid)
        pure tid
       pure ()
      else writeIORef (cancelled p) True >> void (tryPutMVar (proceed p) ())
      outcome <- within "activation completion" (readMVar (ownerDone p))
      noBorrow <- tryHeldBorrowNotAcquired cap
      void (tryPutMVar (unlock p) ())
      heldResult <- within "gate holder completion" (readMVar (gateDone p))
      check "gate holder returned" (case heldResult of Right () -> True; _ -> False)
      count <- qaHeldBorrowCount held
      if interrupt then
       check "interrupted activation retains uncertainty without decrement" $
        (case outcome of Left _ -> True; _ -> False) && not noBorrow && count == Just 0
      else do
       retry <- activateHeldBorrowWhile cap (pure False) (pure ())
       close <- retireHeld held
       check "confirmed cancelled activation has zero borrow and no replay" $
        (case outcome of Right Nothing -> True; _ -> False) && noBorrow && count == Just 0
        && retry == Just (Left LeaseBusy) && close == Right ()
 restore run `finally` finish
