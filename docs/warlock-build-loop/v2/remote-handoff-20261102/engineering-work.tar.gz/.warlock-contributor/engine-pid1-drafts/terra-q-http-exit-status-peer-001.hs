-- QA-ONLY selected process. Root compiles and launches it under the actual
-- owned-child lifecycle; this file is not shipped or a native acceptance.
-- An independently owned guardian retains the child and original trial D.
module Main (main) where
import Control.Concurrent (threadDelay)
import Control.Monad (unless)
import System.Directory (doesFileExist)
import System.Environment (getArgs)
import System.Exit (ExitCode(..),exitWith)
import System.FilePath (isAbsolute)
import System.IO (hFlush,stdout)

main :: IO ()
main = do
 args <- getArgs
 (trigger,actualExit) <- case args of
  [p,"0"] | isAbsolute p -> pure (p,ExitSuccess)
  [p,"1"] | isAbsolute p -> pure (p,ExitFailure 1)
  _ -> ioError (userError "expected private precreated absolute trigger and natural exit 0 or 1")
 present <- doesFileExist trigger
 unless present (ioError (userError "missing owned trigger"))
 putStrLn "READY"
 hFlush stdout
 let await = do
      stillPresent <- doesFileExist trigger
      if stillPresent then threadDelay 10000 >> await else pure ()
 await
 -- Normal exit is observable only after Root removes its real private marker;
 -- signal termination, timeout and unknown handle are separate outcomes.
 exitWith actualExit
