{-# LANGUAGE ScopedTypeVariables #-}
-- ROOT ONLY: SOURCE DRAFT, UNEXECUTED. Requires the companion QA-only hook
-- against the exact published preimage. One guarded process per case; retain
-- Case and its worker/process handles on every exception or observation timeout.
-- A hook raises before the actual kill after the first StopD, so this witness
-- must not send a signal or extend authorization beyond that deadline.
module TerraEngineStartupStopRace
 (Case,newCase,runGapWitness,retainedWorkers,retainedResult) where

import Control.Concurrent (ThreadId, forkIOWithUnmask, threadDelay)
import Control.Concurrent.MVar
import Control.Exception (SomeAsyncException,SomeException,fromException,mask,throwIO,try)
import Control.Monad (unless,when)
import Data.IORef
import System.IO (Handle)
import System.Timeout (timeout)
import Warlock.Capture.Process.Bootstrap (AdmissionDeadline,remainingMicros)
import Warlock.Capture.Process.Internal (ToolError(..))
import Warlock.Capture.Process.Persistent.Internal
 (PersistentOwner,StopBudget,StopReceipt(..),StopDeadlineObservation(..)
 ,newPersistentOwner,startBudgetFromDeadline,requestSessionStop
 ,tryPersistentStopDeadline,persistentFixture,withPersistentOwnerHook)

data Case = Case PersistentOwner (IORef Bool) (IORef [ThreadId])
 (MVar ()) (MVar ()) (MVar ()) (IORef Bool) (MVar (Either SomeException ()))
 (MVar (Either SomeException StopReceipt))
newCase :: IO Case
newCase = Case <$> newPersistentOwner <*> newIORef False <*> newIORef []
 <*> newEmptyMVar <*> newEmptyMVar <*> newEmptyMVar <*> newIORef False <*> newEmptyMVar <*> newEmptyMVar
retainedWorkers :: Case -> IO [ThreadId]
retainedWorkers (Case _ _ workers _ _ _ _ _ _) = readIORef workers
retainedResult :: Case -> IO (Maybe (Either SomeException ()))
retainedResult (Case _ _ _ _ _ _ _ done _) = tryReadMVar done
check :: String -> Bool -> IO ()
check label ok = unless ok (ioError (userError ("startup stop race: " ++ label)))

-- Only the supervisor's readMVar is timed; product work is never cancelled by
-- a test timeout. No replacement D or unbounded cleanup grace is created.
observe :: AdmissionDeadline -> String -> MVar a -> IO a
observe original label cell = do
 left <- remainingMicros original
 check (label ++ ": original D live") (left > 0)
 value <- timeout left (readMVar cell)
 case value of
  Nothing -> ioError (userError (label ++ ": Unknown, retain guardian"))
  Just x -> do
   after <- remainingMicros original
   check (label ++ ": original D still live") (after > 0)
   pure x

-- child and input are supplied and retained by the independent guarded host;
-- it must use the existing same-UID owned controlled child that stays alive.
-- The test is an expected-RED witness for the published preimage, not a fix.
runGapWitness :: Case -> AdmissionDeadline -> StopBudget -> FilePath -> Handle -> [String] -> IO ()
runGapWitness (Case owner used workers snapshot release killing unsafeBoundary done stopDone) original stopBudget child input args = do
 fresh <- atomicModifyIORef' used (\old -> (True,not old))
 check "single case" fresh
 gate <- newEmptyMVar
 _ <- mask $ \_ -> do
  tid <- forkIOWithUnmask $ \unmask -> do
   result <- try $ unmask $ do
    readMVar gate
    remainingMicros original >>= check "before actual startup" . (>0)
    let hook name
         | name == "qa-startup-after-stop-snapshot" = putMVar snapshot () >> readMVar release
         | name == "persistent-before-leader-kill" = do
            first <- tryPersistentStopDeadline owner
            case first of
             StopDeadlineLatched d -> do
              left <- remainingMicros d
              when (left <= 0) (writeIORef unsafeBoundary True)
             _ -> pure ()
            putMVar killing ()
            -- Always forbid the syscall, including unexpected schedules.
            ioError (userError "QA stopped before kill syscall")
         | otherwise = pure ()
    _ <- withPersistentOwnerHook owner (persistentFixture child args input) 4096
      (startBudgetFromDeadline original) stopBudget
      (\_ -> pure (Left SpawnOrIO)) (\_ -> pure ()) hook
    pure ()
   putMVar done result
   case result of
    Left ex -> case fromException ex :: Maybe SomeAsyncException of
     Just _ -> throwIO ex
     Nothing -> pure ()
    Right _ -> pure ()
  atomicModifyIORef' workers (\xs -> (tid:xs,()))
  putMVar gate ()
 _ <- observe original "snapshot reached before first stop" snapshot
 stopGate <- newEmptyMVar
 _ <- mask $ \_ -> do
  tid <- forkIOWithUnmask $ \unmask -> do
   result <- try (unmask (readMVar stopGate >> requestSessionStop owner stopBudget))
   putMVar stopDone result
  atomicModifyIORef' workers (\xs -> (tid:xs,()))
  putMVar stopGate ()
 stop <- observe original "actual first stop receipt" stopDone >>= either throwIO pure
 check "actual first stop latched in PhaseStarting" (stop == StopLatchedBeforeLive)
 first <- tryPersistentStopDeadline owner
 stopD <- case first of
  StopDeadlineLatched d -> pure d
  _ -> ioError (userError "actual first StopD not observed")
 let waitExpiry = do
      outer <- remainingMicros original
      left <- remainingMicros stopD
      check "original D must outlive witness" (outer > 0)
      when (left > 0) (threadDelay (min 1000 left) >> waitExpiry)
 waitExpiry
 same <- tryPersistentStopDeadline owner
 check "first StopD unchanged" (same == first)
 putMVar release ()
 _ <- observe original "post-StopD pre-syscall boundary" killing
 crossed <- readIORef unsafeBoundary
 check "published code reached kill hook after actual first StopD; syscall was blocked" crossed
 -- Keep Case/child/handles under the external guardian: no physical cleanup
 -- or successful lifecycle is inferred from this observation.
