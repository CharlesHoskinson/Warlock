# Original 28-second VM deadline — source-only review

Status: review of the listed source snapshots, not a VM run, protected test, scenario acceptance, or proof of a window/cleanup. Preserve all original requirements/scenarios, source-bound evidence, HOSTSTOP2, nativeOperations `[]`, and existing failures. The separate 4.5-second security fixture is not a replacement for this trial's original 28-second D.

## Concrete configuration discrepancy

`tools/omarchy_ui_mvp.py:590-618,962` accepts integer duration 1..28 seconds and mints `D = time.monotonic_ns() + duration * 1_000_000_000` once, after pinning assets and preparing catalogs. Its CLI default is **25**, and `docs/warlock/how-to/run-omarchy-mvp.md:209-212` explicitly supplies **25**. The separately owned `engine-vm-trial.py:210-232` checks that manifest, UI and backend contain the same D and that `0 < D-now <= 28s`; it does not establish an originally requested duration of exactly 28 seconds. A 25-second config can pass this ceiling check. For this specific 28-second trial, root must explicitly supply `--duration-seconds 28` when creating the original guest config, and retain/check `durationSeconds == 28` and `deadlineMonotonicNs - generatedMonotonicNs == 28000000000`, as well as exact equality of manifest/UI/backend D. This is verification of the one initial D, not authorization to mint a replacement if preparation or startup is slow. Preflight material before minting D where possible; all work after minting consumes it.

## Source path and limits

1. `runtime/src/Warlock/Backend.hs:203-209` imports configured absolute D and passes that opaque value into `runBootstrapWithArguments`; `runtime/src/Warlock/Ui/Config.hs:38-48` independently imports UI config's identical absolute text. The VM trial equality check binds those files; source alone does not establish what was supplied in an actual guest run.
2. `runtime/ui/Main.hs:34-60` takes `uiDeadline config`, encodes `deadlineAbsoluteNs deadline` into protocol startup and passes the same value to `startUnreadyEngine` and `prepareBroker`. Broker `prepareBroker` checks startup deadline equals its opaque D. `EngineEntrypoint.hs:137-175,302-318` imports `originalD`, checks exact startup deadline/incarnation and uses the same D for reads, writes and callback setup. These are code paths, not executed evidence.
3. `EngineEntrypoint.hs:321-330` samples remaining D and enters the local GUI-stop path at <=1,000,000us. `EngineBroker.hs:173-182` requires >500,000us and sets a transaction timeout to remaining minus 500,000us, without constructing a new D. Current child cutoff samples before remote callbacks: a delayed RPC can cross the 1s boundary before returning, and WebKit's separate stop/remaining reads add another interleaving. Existing independent review/test drafts cover those source counterexamples. Even with reserves, unsafe/nonthreaded provider calls or delayed timeout delivery are not proved to stop on time; no extra deadline or replay is allowed.
4. `EngineCustody.hsc:171-183,641-648` uses remaining original D for readiness/owned stop, including its existing stop/reap reserve. `Owner.hs:257-287` invokes engine retirement and worker cleanup, recomputing remaining D for joins; `Main.hs:87-90` requires positive remaining after UI witness. Backend `Backend.hs:210-212` calls `retireBootstrap`, `retireCatalog`, and `retirePinStore` after its conversation without passing a deadline; `Bootstrap/Aggregate.hs:152-156` calls `retireRegistration`, whose `CurrentSessions.hs:65-70` uses an uninterruptible mask and nested MVars. These facts do not demonstrate that backend retirement finishes by D; a late, stuck or unobserved retirement remains unknown/failed, not a reason to start a new cleanup budget or report clean success. This is a source limitation, not an observed failure.
5. VM trial post-loop process/idle/Foot observations can occur after D as evidence collection; they are not the engine's authorized lifetime, a renewed stop deadline, or proof that the engine retired by D. The draft trial records unknown/live scope and does not manufacture a stop receipt. Root must use owned custody and preserve any uncertainty, no unrelated process cleanup.

## Root-owned checks

* Before trial, compare generated duration and the original D across manifest/configs and recorded child startup. Check `CLOCK_MONOTONIC` domain, exact immutable identity and no D recomputation. Verify explicit 28 seconds, not the 25-second default or 4.5-second separate fixture.
* Use positive fast startup/GUI/stop plus controlled stage stalls spanning the child 1s cutoff, broker 500ms threshold, and original D. Assert refusal/unknown and no replay, preserve actual original D, avoid interpreting reserves as hard real-time guarantees. Independently observe process exit/reap and callback retirement; a local send/timeout or missing scope alone is not proof.
* Retain exact timestamps, paths, source hashes, original deadlines, previous failed evidence and separate component/model/VM/original acceptance statuses. Root alone runs protected checks; no test or VM execution in this review.

## Source hashes

```
61d9a84a4a41037fcf6464fa56153c9b2ec26986be676d2f84fb21d9ff14c2c5  tools/omarchy_ui_mvp.py
ba76a624c3eefef29e42f737dd15abfa14e32f1c37bf38c4dc86d78ad4eae693  .warlock-contributor/engine-pid1-drafts/engine-vm-trial.py (peer draft snapshot)
5df812de63c32881bf50b5e2109e06c6259192b0f9188a0f84a22efc1d7209b0  implementation/warlock/haskell/runtime/ui/Main.hs
6d26e1f8362f96d9894143c719a79ade7610f9c444101eb9f9c4e52ad5da8099  implementation/warlock/haskell/runtime/src/Warlock/Backend.hs
e737412f400ae5a9d53625152a23bbc8883bb6558d85770dd8e14bcb4bb8f969  implementation/warlock/haskell/runtime/src/Warlock/Ui/Config.hs
a780a828eff0c30b26707e4474b84b33f105a9fafcffd6b52f830725b9ad5ca9  implementation/warlock/haskell/runtime/src/Warlock/Ui/Owner.hs
941d77695c96f5456cfff9a2d5d452088a2668df58f0c96c0e3c830901f17080  implementation/warlock/haskell/runtime/ui/Warlock/Ui/EngineEntrypoint.hs
63cebd1a5ec38b7faa6b713dacec64f62b1e15e5cda8dbc1284dd757e6d29a04  implementation/warlock/haskell/runtime/src/Warlock/Ui/EngineBroker.hs
f13472d6da143a38d8aeaf5c944a1346b754844a7b8f67fae295d31733bbf11f  implementation/warlock/haskell/process-custody/src/Warlock/Capture/Process/Internal.hsc
```
